
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/resnest101e/resnest101e_backward_0/state_dict.pt'))

    
    
    def forward(self, convolution_default_121, mean_dim_20, getitem_294, getitem_295, getitem_331, primals_6, getitem_330, primals_240, relu__default_94, primals_236, primals_230, getitem_298, getitem_297, primals_235, relu__default_106, convolution_default_67, convolution_default_136, relu__default_95, getitem_334, primals_4, getitem_333, convolution_default_122, convolution_default_77, getitem_300, relu__default_107, primals_3, primals_229, primals_237, primals_232, convolution_default_137, primals_231, getitem_301, primals_5, relu__default_96, relu__default_52, primals_863, convolution_default_68, primals_879, getitem_349, primals_143, getitem_348, primals_864, primals_872, primals_870, relu__default_112, primals_880, primals_874, primals_868, getitem_169, primals_140, getitem_184, convolution_default_143, primals_876, getitem_168, primals_869, _softmax_default_14, mean_dim_27, getitem_351, primals_867, _softmax_default_27, view_default_135, getitem_352, relu__default_57, primals_875, relu__default_113, mean_dim_12, primals_881, view_default_60, getitem_381, getitem_400, getitem_382, relu__default_128, relu__default_123, primals_149, convolution_default_157, getitem_171, primals_144, primals_145, getitem_403, convolution_default_164, getitem_385, getitem_384, getitem_402, mean_dim_31, view_default_155, primals_148, relu__default_124, relu__default_129, primals_156, primals_155, primals_154, convolution_default_85, convolution_default_166, convolution_default_158, primals_159, _softmax_default_31, sum_dim_int_list_63, mean_dim_30, primals_151, view_default_150, getitem_387, primals_150, view_default_159, primals_297, getitem_49, primals_361, primals_421, view_default_94, primals_290, primals_301, primals_296, primals_303, primals_686, _softmax_default_1, getitem_204, getitem_34, getitem_48, view_default_79, primals_694, primals_302, getitem_250, mean_dim_1, relu__default_14, primals_366, primals_420, getitem_33, primals_685, primals_295, primals_365, primals_416, convolution_default_19, primals_409, primals_413, primals_683, relu__default_9, primals_419, primals_690, primals_411, primals_695, relu__default_78, primals_696, getitem_52, primals_410, getitem_51, getitem_249, primals_300, primals_691, getitem_246, primals_359, relu__default_15, primals_408, primals_291, primals_689, primals_415, getitem_240, primals_371, convolution_default_20, primals_370, primals_292, sum_dim_int_list_3, primals_372, convolution_default_102, view_default_9, primals_362, getitem_247, relu__default_79, convolution_default_101, getitem_54, getitem_55, convolution_default_13, primals_367, getitem_85, getitem_13, primals_705, _softmax_default_5, getitem_84, primals_100, primals_710, primals_101, relu__default_3, convolution_default_4, relu__default_25, primals_99, primals_102, primals_716, mean_dim_15, getitem_16, getitem_15, primals_712, primals_104, primals_701, relu__default_4, getitem_87, primals_702, sum_dim_int_list_11, primals_700, primals_110, convolution_default_34, primals_697, getitem_88, convolution_default_5, primals_106, primals_111, view_default_29, primals_706, mean_dim, primals_107, primals_707, view_default, convolution_default_35, primals_708, getitem_18, getitem_19, relu__default_26, primals_713, primals_112, getitem_66, getitem_418, getitem_417, view_default_95, getitem_67, mean_dim_19, primals_840, primals_832, relu__default_19, getitem_121, convolution_default_26, getitem_120, _softmax_default_19, relu__default_81, primals_831, view_default_164, relu__default_36, view_default_165, getitem_70, getitem_69, relu__default_70, primals_835, getitem_253, relu__default_134, getitem_252, primals_837, relu__default_20, relu__default_80, primals_836, convolution_default_91, convolution_default_48, convolution_default_106, t_default, mean_dim_8, view_default_40, getitem_123, view_default_100, convolution_default_27, primals_830, getitem_124, convolution_default_103, getitem_222, mean_dim_4, relu__default_37, primals_841, getitem_223, getitem_256, view_default_20, getitem_207, getitem_255, primals_799, primals_798, convolution_default_90, convolution_default_40, primals_724, relu__default_41, relu__default_30, primals_797, convolution_default_41, relu__default_65, getitem_138, getitem_139, primals_722, getitem_103, primals_803, primals_721, getitem_102, sum_dim_int_list_19, view_default_84, getitem_220, relu__default_31, convolution_default_55, primals_718, _softmax_default_9, primals_793, primals_789, primals_802, primals_794, primals_723, view_default_49, relu__default_42, primals_791, getitem_105, primals_727, getitem_106, primals_808, relu__default_69, relu__default_32, convolution_default_56, convolution_default_42, getitem_219, primals_717, primals_805, primals_804, view_default_35, mean_dim_7, primals_57, getitem_154, getitem_153, relu__default_86, primals_61, getitem_259, primals_678, relu__default_47, primals_62, primals_58, convolution_default_62, getitem_273, primals_56, primals_53, sum_dim_int_list_31, primals_505, mean_dim_11, primals_670, getitem_157, getitem_156, primals_681, convolution_default_111, primals_675, relu__default_48, convolution_default_72, primals_63, primals_680, primals_664, primals_52, primals_508, primals_669, primals_663, primals_679, relu__default_55, primals_668, primals_507, primals_667, primals_48, primals_51, primals_673, primals_674, getitem_180, convolution_default_63, primals_662, view_default_55, primals_506, primals_64, primals_459, primals_72, primals_458, getitem_304, primals_454, convolution_default_123, primals_77, primals_79, primals_457, primals_464, getitem_303, primals_68, mean_dim_23, view_default_115, primals_75, primals_453, relu__default_97, primals_69, primals_74, _softmax_default_23, primals_465, primals_463, primals_462, primals_67, sum_dim_int_list_47, primals_73, relu__default_51, view_default_119, convolution_default_125, getitem_337, getitem_336, relu__default_108, _softmax_default_26, convolution_default_138, getitem_340, getitem_192, getitem_339, mean_dim_26, view_default_130, getitem_193, relu__default_109, relu__default_60, convolution_default_145, getitem_354, convolution_default_80, sum_dim_int_list_55, primals_210, primals_216, getitem_355, view_default_139, primals_213, relu__default_114, primals_214, convolution_default_146, view_default_74, sum_dim_int_list_29, getitem_357, getitem_202, primals_215, getitem_198, getitem_358, convolution_default_147, relu__default_115, primals_600, relu__default_102, primals_490, primals_627, primals_635, primals_734, primals_497, primals_632, relu__default_62, primals_500, primals_728, convolution_default_116, primals_625, relu__default_90, getitem_319, getitem_318, primals_729, convolution_default_117, primals_599, primals_492, primals_740, getitem_286, primals_489, primals_732, getitem_285, primals_735, primals_631, primals_598, convolution_default_131, relu__default_91, primals_621, primals_629, getitem_322, primals_737, getitem_321, primals_593, getitem_199, primals_739, primals_496, primals_604, primals_502, primals_494, convolution_default_81, relu__default_103, primals_592, getitem_288, primals_594, convolution_default_118, getitem_289, convolution_default_132, primals_491, primals_605, relu__default_92, primals_597, primals_602, primals_626, primals_733, getitem_201, primals_501, primals_624, primals_29, primals_30, sum_dim_int_list_41, primals_171, getitem_271, primals_175, primals_166, primals_25, primals_24, view_default_104, primals_176, convolution_default_110, primals_31, primals_167, primals_177, primals_170, primals_172, primals_28, primals_23, primals_178, getitem_270, _softmax_default_20, primals_848, getitem_388, relu__default_5, primals_847, relu__default_16, relu__default_125, _softmax_default, primals_218, getitem_205, primals_845, convolution_default_97, getitem_21, _softmax_default_30, getitem_22, primals_843, getitem_58, convolution_default_21, primals_225, sum_dim_int_list_1, getitem_57, mean_dim_3, primals_862, sum_dim_int_list_61, view_default_15, convolution_default_7, primals_859, getitem_237, primals_842, avg_pool2d_default_4, primals_221, primals_858, convolution_default_160, relu__default_17, primals_857, primals_856, getitem_390, view_default_4, relu__default_6, convolution_default_8, relu__default_75, view_default_154, primals_224, primals_853, convolution_default_161, sum_dim_int_list_7, getitem_391, primals_226, getitem_238, _softmax_default_3, primals_852, primals_851, convolution_default_82, convolution_default_23, primals_220, getitem_24, view_default_19, avg_pool2d_default, avg_pool2d_default_5, primals_330, getitem_405, _softmax_default_7, getitem_406, primals_338, getitem_109, relu__default_119, primals_329, convolution_default_152, primals_46, primals_756, primals_327, primals_41, primals_247, getitem_108, primals_770, primals_34, primals_254, primals_332, getitem_373, primals_335, getitem_372, primals_47, relu__default_33, primals_248, primals_759, primals_242, relu__default_130, relu__default_120, primals_42, primals_328, convolution_default_167, primals_245, primals_760, primals_772, getitem_375, primals_36, getitem_409, getitem_408, primals_249, primals_764, primals_252, convolution_default_44, primals_241, primals_767, sum_dim_int_list_15, primals_771, convolution_default_153, relu__default_131, primals_766, primals_339, avg_pool2d_default_2, primals_762, primals_39, mean_dim_29, primals_761, view_default_145, convolution_default_168, primals_35, primals_340, getitem_376, primals_44, primals_243, primals_253, primals_40, view_default_39, primals_334, primals_194, getitem_73, view_default_70, getitem_37, convolution_default_75, relu__default_21, primals_197, convolution_default_14, getitem_36, getitem_72, relu__default_10, _softmax_default_4, relu__default_64, getitem_75, getitem_76, primals_83, primals_90, getitem_40, primals_85, sum_dim_int_list_27, getitem_39, convolution_default, sum_dim_int_list_9, primals_518, primals_198, primals_523, relu__default_11, primals_513, convolution_default_29, view_default_69, convolution_default_78, primals_516, convolution_default_15, mean_dim_14, view_default_24, primals_193, relu__default_22, primals_89, primals_519, primals_521, primals_88, primals_84, getitem_42, getitem_43, _softmax_default_13, convolution_default_30, primals_80, primals_512, relu__default_59, primals_517, relu__default_12, primals_199, primals_511, primals_91, getitem_126, getitem_127, getitem_91, getitem_90, primals_895, primals_896, sum_dim_int_list_17, primals_892, relu__default_27, getitem_258, primals_890, convolution_default_50, primals_891, convolution_default_36, _softmax_default_8, primals_900, primals_901, view_default_44, convolution_default_37, getitem_94, relu__default_38, getitem_93, primals_885, primals_884, relu__default_28, convolution_default_51, primals_886, primals_897, view_default_30, primals_889, getitem_129, mean_dim_6, getitem_130, getitem_141, getitem_159, _softmax_default_11, getitem_243, getitem_142, getitem_160, relu__default_43, relu__default_49, convolution_default_57, getitem_174, getitem_241, primals_284, primals_540, primals_539, getitem_145, getitem_144, convolution_default_98, getitem_162, relu__default_76, sum_dim_int_list_23, relu__default_44, primals_289, convolution_default_65, primals_544, view_default_90, primals_285, getitem_163, mean_dim_18, primals_538, view_default_59, primals_286, convolution_default_58, relu__default_50, mean_dim_10, convolution_default_66, primals_545, primals_543, view_default_50, getitem_147, primals_316, primals_311, primals_589, getitem_292, primals_586, primals_307, mean_dim_22, getitem_291, view_default_110, primals_313, primals_581, primals_308, relu__default_93, primals_305, primals_582, _softmax_default_22, primals_583, primals_587, primals_588, convolution_default_120, primals_312, sum_dim_int_list_45, view_default_114, primals_183, primals_566, sum_dim_int_list_37, primals_567, primals_554, primals_561, primals_559, convolution_default_100, primals_555, primals_187, mean_dim_16, primals_562, primals_182, primals_556, getitem_244, primals_565, primals_571, relu__default_77, primals_572, primals_189, primals_577, _softmax_default_18, primals_560, primals_191, primals_188, getitem_217, view_default_80, primals_573, primals_186, primals_575, primals_181, relu__default_68, primals_570, primals_578, primals_161, convolution_default_140, getitem_195, getitem_324, getitem_343, getitem_325, getitem_342, primals_356, _softmax_default_12, relu__default_104, sum_dim_int_list_53, primals_350, relu__default_110, convolution_default_73, convolution_default_133, getitem_196, view_default_134, getitem_328, relu__default_56, view_default_129, primals_160, getitem_327, mean_dim_25, primals_354, primals_357, view_default_125, primals_355, relu__default_53, convolution_default_141, primals_346, relu__default_105, primals_162, view_default_64, primals_351, getitem_345, primals_164, mean_dim_13, getitem_346, view_default_65, sum_dim_int_list_25, sum_dim_int_list_51, primals_344, convolution_default_70, relu__default_111, convolution_default_142, getitem_181, primals_349, convolution_default_135, primals_343, getitem_172, _softmax_default_25, primals_345, getitem_213, getitem_307, getitem_306, primals_323, primals_393, primals_322, convolution_default_9, getitem_25, convolution_default_10, relu__default_67, primals_643, convolution_default_105, primals_397, primals_392, primals_388, relu__default_98, primals_641, getitem_28, primals_636, convolution_default_87, primals_317, getitem_27, getitem_264, getitem_261, convolution_default_126, sum_dim_int_list_39, primals_389, relu__default_83, primals_648, relu__default_7, primals_319, primals_646, getitem_262, getitem_310, primals_318, getitem_309, view_default_99, getitem_214, relu__default_99, primals_642, primals_394, primals_637, getitem_30, convolution_default_127, primals_324, getitem_31, primals_386, primals_647, convolution_default_108, relu__default_8, convolution_default_11, view_default_5, getitem_312, convolution_default_107, primals_640, getitem_313, relu__default_121, getitem_378, getitem_379, getitem_361, getitem_360, primals_548, sum_dim_int_list_59, relu__default_116, getitem_190, convolution_default_155, _softmax_default_29, getitem_187, view_default_149, convolution_default_148, relu__default_122, primals_550, mean_dim_28, getitem_189, view_default_140, getitem_363, convolution_default_156, getitem_186, getitem_364, primals_546, relu__default_117, primals_551, getitem_412, getitem_411, primals_443, getitem_268, primals_438, relu__default_132, getitem_46, convolution_default_16, getitem_45, mean_dim_2, view_default_10, _softmax_default_32, convolution_default_169, primals_452, primals_440, getitem_415, relu__default_13, relu__default_85, primals_448, getitem_2, getitem_414, primals_442, mean_dim_32, primals_451, primals_447, getitem_1, view_default_160, _softmax_default_2, primals_437, relu__default, relu__default_133, primals_446, sum_dim_int_list_5, convolution_default_1, sum_dim_int_list_65, convolution_default_171, convolution_default_18, getitem_267, view_default_14, getitem_4, getitem_148, primals_620, getitem_79, primals_935, getitem_394, relu__default_45, getitem_78, relu__default_126, primals_934, primals_929, _softmax_default_10, getitem_393, relu__default_23, primals_615, getitem_150, getitem_151, primals_619, primals_932, convolution_default_162, convolution_default_31, view_default_75, sum_dim_int_list_21, primals_924, primals_936, mean_dim_5, getitem_82, getitem_397, getitem_81, convolution_default_60, getitem_396, primals_930, primals_609, primals_922, relu__default_24, primals_923, relu__default_127, primals_610, view_default_54, primals_614, relu__default_46, primals_613, convolution_default_163, primals_608, primals_927, convolution_default_32, primals_616, convolution_default_88, convolution_default_61, view_default_25, getitem_399, primals_928, relu__default_34, getitem_111, primals_131, primals_209, getitem_97, getitem_112, relu__default_18, _softmax_default_6, primals_138, getitem_61, getitem_96, getitem_60, avg_pool2d_default_3, convolution_default_45, primals_204, relu__default_29, primals_139, primals_134, convolution_default_83, getitem_115, primals_203, getitem_114, convolution_default_24, primals_202, avg_pool2d_default_1, getitem_64, primals_133, getitem_63, sum_dim_int_list_13, getitem_99, convolution_default_46, primals_208, primals_135, primals_129, getitem_117, convolution_default_25, convolution_default_39, view_default_34, getitem_118, getitem_100, convolution_default_47, primals_205, relu__default_35, relu__default_54, primals_470, relu__default_72, primals_94, convolution_default_93, getitem_265, getitem_178, getitem_175, primals_469, getitem_228, primals_467, primals_95, getitem_229, primals_96, relu__default_84, primals_473, primals_474, convolution_default_71, primals_475, getitem_177, primals_778, primals_486, primals_788, relu__default_39, convolution_default_52, getitem_166, primals_479, getitem_165, convolution_default_112, getitem_274, getitem_133, getitem_132, relu__default_87, relu__default_58, primals_18, primals_783, primals_781, relu__default_40, primals_15, convolution_default_76, primals_10, getitem_135, primals_782, convolution_default_113, primals_11, primals_480, primals_16, getitem_208, getitem_277, primals_478, primals_776, getitem_276, primals_786, primals_17, convolution_default_53, primals_777, relu__default_88, mean_dim_9, primals_484, view_default_45, primals_485, primals_481, primals_787, getitem_136, relu__default_82, view_default_105, mean_dim_21, primals_9, primals_12, primals_775, getitem_225, primals_527, primals_258, primals_534, relu__default_1, primals_532, primals_826, convolution_default_2, primals_825, primals_535, primals_824, relu__default_63, primals_376, getitem_9, primals_263, getitem_5, primals_382, primals_821, getitem_8, convolution_default_86, primals_820, getitem_7, getitem_231, primals_257, getitem_211, primals_533, mean_dim_17, primals_818, relu__default_73, relu__default_2, relu__default_66, primals_373, primals_528, view_default_85, getitem_10, primals_810, getitem_210, primals_262, primals_381, primals_264, primals_377, primals_809, getitem_232, primals_524, primals_813, primals_259, primals_814, primals_265, convolution_default_3, primals_383, primals_815, primals_384, primals_829, primals_816, primals_378, getitem_12, primals_529, _softmax_default_21, getitem_280, primals_751, primals_424, getitem_279, primals_398, getitem_235, primals_399, primals_750, primals_126, primals_404, convolution_default_95, primals_118, primals_400, primals_425, primals_745, primals_128, sum_dim_int_list_35, relu__default_89, primals_744, primals_116, primals_121, primals_749, primals_122, getitem_216, primals_405, relu__default_61, primals_430, view_default_89, primals_123, primals_436, primals_127, primals_432, sum_dim_int_list_33, primals_426, primals_754, _softmax_default_17, sum_dim_int_list_43, primals_117, getitem_183, _softmax_default_16, _softmax_default_15, relu__default_74, primals_755, primals_403, primals_435, getitem_234, primals_431, getitem_282, convolution_default_115, primals_748, convolution_default_96, primals_115, getitem_283, view_default_109, primals_427, primals_743, primals_275, getitem_366, relu__default_100, getitem_367, primals_276, primals_658, primals_273, relu__default_71, primals_280, primals_903, sum_dim_int_list_57, primals_278, primals_651, getitem_316, primals_912, convolution_default_128, convolution_default_150, primals_268, getitem_315, mean_dim_24, _softmax_default_28, primals_653, view_default_120, primals_908, primals_919, view_default_144, getitem_226, relu__default_101, primals_659, primals_656, relu__default_118, primals_916, primals_654, primals_902, primals_918, primals_281, primals_652, convolution_default_151, primals_907, _softmax_default_24, view_default_124, primals_913, convolution_default_130, primals_917, primals_269, primals_911, primals_274, convolution_default_92, getitem_369, primals_270, primals_905, sum_dim_int_list_49, getitem_370, tangents_1):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default_165);  t_default_2 = view_default_165 = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list_66 = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_166 = torch.ops.aten.view.default(sum_dim_int_list_66, [1000]);  sum_dim_int_list_66 = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_167 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_167, [128, 2048, 8, 8]);  view_default_167 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 64);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_134, torch.float32);  relu__default_134 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_139, to_dtype);  le_scalar = new_zeros_default_139 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_171, primals_918, primals_916, primals_917, getitem_417, getitem_418, True, 1e-05, [True, True, True]);  convolution_default_171 = primals_918 = primals_916 = primals_917 = getitem_417 = getitem_418 = None
        getitem_419 = native_batch_norm_backward_default[0]
        getitem_420 = native_batch_norm_backward_default[1]
        getitem_421 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_419, sum_dim_int_list_65, primals_935, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_419 = sum_dim_int_list_65 = primals_935 = None
        getitem_422 = convolution_backward_default[0]
        getitem_423 = convolution_backward_default[1];  convolution_backward_default = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(getitem_422, 1);  getitem_422 = None
        expand_default_1 = torch.ops.aten.expand.default(unsqueeze_default, [128, 2, 512, 8, 8]);  unsqueeze_default = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(expand_default_1, view_default_160);  view_default_160 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(expand_default_1, view_default_164);  expand_default_1 = view_default_164 = None
        sum_dim_int_list_67 = torch.ops.aten.sum.dim_IntList(mul_tensor_33, [3, 4], True);  mul_tensor_33 = None
        view_default_168 = torch.ops.aten.view.default(sum_dim_int_list_67, [128, 1024, 1, 1]);  sum_dim_int_list_67 = None
        view_default_169 = torch.ops.aten.view.default(view_default_168, [128, 1024]);  view_default_168 = None
        view_default_170 = torch.ops.aten.view.default(view_default_169, [128, 2, 1, 512]);  view_default_169 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_170, _softmax_default_32, 1, torch.float32);  view_default_170 = _softmax_default_32 = None
        transpose_int_33 = torch.ops.aten.transpose.int(_softmax_backward_data_default, 1, 2);  _softmax_backward_data_default = None
        view_default_171 = torch.ops.aten.view.default(transpose_int_33, [128, 1024, 1, 1]);  transpose_int_33 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(view_default_171, relu__default_133, primals_934, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_171 = primals_934 = None
        getitem_425 = convolution_backward_default_1[0]
        getitem_426 = convolution_backward_default_1[1]
        getitem_427 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_425, torch.float32);  getitem_425 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_133, torch.float32);  relu__default_133 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_140, to_dtype_3);  le_scalar_1 = new_zeros_default_140 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_169, primals_929, primals_927, primals_928, getitem_414, getitem_415, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_169 = primals_929 = primals_927 = primals_928 = getitem_414 = getitem_415 = None
        getitem_428 = native_batch_norm_backward_default_1[0]
        getitem_429 = native_batch_norm_backward_default_1[1]
        getitem_430 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_428, mean_dim_32, primals_932, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_428 = mean_dim_32 = primals_932 = None
        getitem_431 = convolution_backward_default_2[0]
        getitem_432 = convolution_backward_default_2[1]
        getitem_433 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_431, [128, 512, 8, 8]);  getitem_431 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_2, 64);  expand_default_2 = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(div_scalar_1, 1);  div_scalar_1 = None
        expand_default_3 = torch.ops.aten.expand.default(unsqueeze_default_1, [128, 2, 512, 8, 8]);  unsqueeze_default_1 = None
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_34, expand_default_3);  mul_tensor_34 = expand_default_3 = None
        view_default_172 = torch.ops.aten.view.default(add_tensor, [128, 1024, 8, 8]);  add_tensor = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_172, torch.float32);  view_default_172 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_132, torch.float32);  relu__default_132 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_141, to_dtype_6);  le_scalar_2 = new_zeros_default_141 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_168, primals_924, primals_922, primals_923, getitem_411, getitem_412, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_168 = primals_924 = primals_922 = primals_923 = getitem_411 = getitem_412 = None
        getitem_434 = native_batch_norm_backward_default_2[0]
        getitem_435 = native_batch_norm_backward_default_2[1]
        getitem_436 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_434, relu__default_131, primals_930, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_434 = primals_930 = None
        getitem_437 = convolution_backward_default_3[0]
        getitem_438 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_437, torch.float32);  getitem_437 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_131, torch.float32);  relu__default_131 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_142, to_dtype_9);  le_scalar_3 = new_zeros_default_142 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_167, primals_913, primals_911, primals_912, getitem_408, getitem_409, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_167 = primals_913 = primals_911 = primals_912 = getitem_408 = getitem_409 = None
        getitem_440 = native_batch_norm_backward_default_3[0]
        getitem_441 = native_batch_norm_backward_default_3[1]
        getitem_442 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_440, relu__default_130, primals_919, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_440 = primals_919 = None
        getitem_443 = convolution_backward_default_4[0]
        getitem_444 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_443);  to_dtype_2 = getitem_443 = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_130, torch.float32);  relu__default_130 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_143, to_dtype_12);  le_scalar_4 = new_zeros_default_143 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_166, primals_891, primals_889, primals_890, getitem_405, getitem_406, True, 1e-05, [True, True, True]);  convolution_default_166 = primals_891 = primals_889 = primals_890 = getitem_405 = getitem_406 = None
        getitem_446 = native_batch_norm_backward_default_4[0]
        getitem_447 = native_batch_norm_backward_default_4[1]
        getitem_448 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_446, sum_dim_int_list_63, primals_908, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_446 = sum_dim_int_list_63 = primals_908 = None
        getitem_449 = convolution_backward_default_5[0]
        getitem_450 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(getitem_449, 1);  getitem_449 = None
        expand_default_4 = torch.ops.aten.expand.default(unsqueeze_default_2, [128, 2, 512, 8, 8]);  unsqueeze_default_2 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(expand_default_4, view_default_155);  view_default_155 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(expand_default_4, view_default_159);  expand_default_4 = view_default_159 = None
        sum_dim_int_list_68 = torch.ops.aten.sum.dim_IntList(mul_tensor_35, [3, 4], True);  mul_tensor_35 = None
        view_default_173 = torch.ops.aten.view.default(sum_dim_int_list_68, [128, 1024, 1, 1]);  sum_dim_int_list_68 = None
        view_default_174 = torch.ops.aten.view.default(view_default_173, [128, 1024]);  view_default_173 = None
        view_default_175 = torch.ops.aten.view.default(view_default_174, [128, 2, 1, 512]);  view_default_174 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_175, _softmax_default_31, 1, torch.float32);  view_default_175 = _softmax_default_31 = None
        transpose_int_34 = torch.ops.aten.transpose.int(_softmax_backward_data_default_1, 1, 2);  _softmax_backward_data_default_1 = None
        view_default_176 = torch.ops.aten.view.default(transpose_int_34, [128, 1024, 1, 1]);  transpose_int_34 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(view_default_176, relu__default_129, primals_907, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_176 = primals_907 = None
        getitem_452 = convolution_backward_default_6[0]
        getitem_453 = convolution_backward_default_6[1]
        getitem_454 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_452, torch.float32);  getitem_452 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_129, torch.float32);  relu__default_129 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_144, to_dtype_15);  le_scalar_5 = new_zeros_default_144 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_164, primals_902, primals_900, primals_901, getitem_402, getitem_403, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_164 = primals_902 = primals_900 = primals_901 = getitem_402 = getitem_403 = None
        getitem_455 = native_batch_norm_backward_default_5[0]
        getitem_456 = native_batch_norm_backward_default_5[1]
        getitem_457 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_455, mean_dim_31, primals_905, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_455 = mean_dim_31 = primals_905 = None
        getitem_458 = convolution_backward_default_7[0]
        getitem_459 = convolution_backward_default_7[1]
        getitem_460 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_458, [128, 512, 8, 8]);  getitem_458 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_5, 64);  expand_default_5 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(div_scalar_2, 1);  div_scalar_2 = None
        expand_default_6 = torch.ops.aten.expand.default(unsqueeze_default_3, [128, 2, 512, 8, 8]);  unsqueeze_default_3 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_36, expand_default_6);  mul_tensor_36 = expand_default_6 = None
        view_default_177 = torch.ops.aten.view.default(add_tensor_2, [128, 1024, 8, 8]);  add_tensor_2 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_177, torch.float32);  view_default_177 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_128, torch.float32);  relu__default_128 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_145, to_dtype_18);  le_scalar_6 = new_zeros_default_145 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_163, primals_897, primals_895, primals_896, getitem_399, getitem_400, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_163 = primals_897 = primals_895 = primals_896 = getitem_399 = getitem_400 = None
        getitem_461 = native_batch_norm_backward_default_6[0]
        getitem_462 = native_batch_norm_backward_default_6[1]
        getitem_463 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_461, relu__default_127, primals_903, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_461 = primals_903 = None
        getitem_464 = convolution_backward_default_8[0]
        getitem_465 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_464, torch.float32);  getitem_464 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_127, torch.float32);  relu__default_127 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_146, to_dtype_21);  le_scalar_7 = new_zeros_default_146 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_162, primals_886, primals_884, primals_885, getitem_396, getitem_397, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_162 = primals_886 = primals_884 = primals_885 = getitem_396 = getitem_397 = None
        getitem_467 = native_batch_norm_backward_default_7[0]
        getitem_468 = native_batch_norm_backward_default_7[1]
        getitem_469 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_467, relu__default_126, primals_892, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_467 = primals_892 = None
        getitem_470 = convolution_backward_default_9[0]
        getitem_471 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(to_dtype_14, getitem_470);  to_dtype_14 = getitem_470 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_126, torch.float32);  relu__default_126 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_147, to_dtype_24);  le_scalar_8 = new_zeros_default_147 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_161, primals_881, primals_879, primals_880, getitem_393, getitem_394, True, 1e-05, [True, True, True]);  convolution_default_161 = primals_881 = primals_879 = primals_880 = getitem_393 = getitem_394 = None
        getitem_473 = native_batch_norm_backward_default_8[0]
        getitem_474 = native_batch_norm_backward_default_8[1]
        getitem_475 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_473, avg_pool2d_default_5, primals_876, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_473 = avg_pool2d_default_5 = primals_876 = None
        getitem_476 = convolution_backward_default_10[0]
        getitem_477 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_476, relu__default_122, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_476 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_160, primals_858, primals_856, primals_857, getitem_390, getitem_391, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_160 = primals_858 = primals_856 = primals_857 = getitem_390 = getitem_391 = None
        getitem_479 = native_batch_norm_backward_default_9[0]
        getitem_480 = native_batch_norm_backward_default_9[1]
        getitem_481 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_479, avg_pool2d_default_4, primals_875, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_479 = avg_pool2d_default_4 = primals_875 = None
        getitem_482 = convolution_backward_default_11[0]
        getitem_483 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_482, sum_dim_int_list_61, [3, 3], [2, 2], [1, 1], False, True, None);  getitem_482 = sum_dim_int_list_61 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(avg_pool2d_backward_default_1, 1);  avg_pool2d_backward_default_1 = None
        expand_default_7 = torch.ops.aten.expand.default(unsqueeze_default_4, [128, 2, 512, 16, 16]);  unsqueeze_default_4 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(expand_default_7, view_default_150);  view_default_150 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(expand_default_7, view_default_154);  expand_default_7 = view_default_154 = None
        sum_dim_int_list_69 = torch.ops.aten.sum.dim_IntList(mul_tensor_37, [3, 4], True);  mul_tensor_37 = None
        view_default_178 = torch.ops.aten.view.default(sum_dim_int_list_69, [128, 1024, 1, 1]);  sum_dim_int_list_69 = None
        view_default_179 = torch.ops.aten.view.default(view_default_178, [128, 1024]);  view_default_178 = None
        view_default_180 = torch.ops.aten.view.default(view_default_179, [128, 2, 1, 512]);  view_default_179 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_180, _softmax_default_30, 1, torch.float32);  view_default_180 = _softmax_default_30 = None
        transpose_int_35 = torch.ops.aten.transpose.int(_softmax_backward_data_default_2, 1, 2);  _softmax_backward_data_default_2 = None
        view_default_181 = torch.ops.aten.view.default(transpose_int_35, [128, 1024, 1, 1]);  transpose_int_35 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(view_default_181, relu__default_125, primals_874, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_181 = primals_874 = None
        getitem_485 = convolution_backward_default_12[0]
        getitem_486 = convolution_backward_default_12[1]
        getitem_487 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_485, torch.float32);  getitem_485 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_125, torch.float32);  relu__default_125 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_148, to_dtype_27);  le_scalar_9 = new_zeros_default_148 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_158, primals_869, primals_867, primals_868, getitem_387, getitem_388, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_158 = primals_869 = primals_867 = primals_868 = getitem_387 = getitem_388 = None
        getitem_488 = native_batch_norm_backward_default_10[0]
        getitem_489 = native_batch_norm_backward_default_10[1]
        getitem_490 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_488, mean_dim_30, primals_872, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_488 = mean_dim_30 = primals_872 = None
        getitem_491 = convolution_backward_default_13[0]
        getitem_492 = convolution_backward_default_13[1]
        getitem_493 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_491, [128, 512, 16, 16]);  getitem_491 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_8, 256);  expand_default_8 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(div_scalar_3, 1);  div_scalar_3 = None
        expand_default_9 = torch.ops.aten.expand.default(unsqueeze_default_5, [128, 2, 512, 16, 16]);  unsqueeze_default_5 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_38, expand_default_9);  mul_tensor_38 = expand_default_9 = None
        view_default_182 = torch.ops.aten.view.default(add_tensor_4, [128, 1024, 16, 16]);  add_tensor_4 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_182, torch.float32);  view_default_182 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_124, torch.float32);  relu__default_124 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_149, to_dtype_30);  le_scalar_10 = new_zeros_default_149 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_157, primals_864, primals_862, primals_863, getitem_384, getitem_385, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_157 = primals_864 = primals_862 = primals_863 = getitem_384 = getitem_385 = None
        getitem_494 = native_batch_norm_backward_default_11[0]
        getitem_495 = native_batch_norm_backward_default_11[1]
        getitem_496 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_494, relu__default_123, primals_870, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_494 = primals_870 = None
        getitem_497 = convolution_backward_default_14[0]
        getitem_498 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_497, torch.float32);  getitem_497 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_123, torch.float32);  relu__default_123 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_150, to_dtype_33);  le_scalar_11 = new_zeros_default_150 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_156, primals_853, primals_851, primals_852, getitem_381, getitem_382, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_156 = primals_853 = primals_851 = primals_852 = getitem_381 = getitem_382 = None
        getitem_500 = native_batch_norm_backward_default_12[0]
        getitem_501 = native_batch_norm_backward_default_12[1]
        getitem_502 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_500, relu__default_122, primals_859, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_500 = primals_859 = None
        getitem_503 = convolution_backward_default_15[0]
        getitem_504 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default, getitem_503);  avg_pool2d_backward_default = getitem_503 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_122, torch.float32);  relu__default_122 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_151, to_dtype_36);  le_scalar_12 = new_zeros_default_151 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_155, primals_615, primals_613, primals_614, getitem_378, getitem_379, True, 1e-05, [True, True, True]);  convolution_default_155 = primals_615 = primals_613 = primals_614 = getitem_378 = getitem_379 = None
        getitem_506 = native_batch_norm_backward_default_13[0]
        getitem_507 = native_batch_norm_backward_default_13[1]
        getitem_508 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_506, sum_dim_int_list_59, primals_632, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_506 = sum_dim_int_list_59 = primals_632 = None
        getitem_509 = convolution_backward_default_16[0]
        getitem_510 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(getitem_509, 1);  getitem_509 = None
        expand_default_10 = torch.ops.aten.expand.default(unsqueeze_default_6, [128, 2, 256, 16, 16]);  unsqueeze_default_6 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(expand_default_10, view_default_145);  view_default_145 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(expand_default_10, view_default_149);  expand_default_10 = view_default_149 = None
        sum_dim_int_list_70 = torch.ops.aten.sum.dim_IntList(mul_tensor_39, [3, 4], True);  mul_tensor_39 = None
        view_default_183 = torch.ops.aten.view.default(sum_dim_int_list_70, [128, 512, 1, 1]);  sum_dim_int_list_70 = None
        view_default_184 = torch.ops.aten.view.default(view_default_183, [128, 512]);  view_default_183 = None
        view_default_185 = torch.ops.aten.view.default(view_default_184, [128, 2, 1, 256]);  view_default_184 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_185, _softmax_default_29, 1, torch.float32);  view_default_185 = _softmax_default_29 = None
        transpose_int_36 = torch.ops.aten.transpose.int(_softmax_backward_data_default_3, 1, 2);  _softmax_backward_data_default_3 = None
        view_default_186 = torch.ops.aten.view.default(transpose_int_36, [128, 512, 1, 1]);  transpose_int_36 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(view_default_186, relu__default_121, primals_631, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_186 = primals_631 = None
        getitem_512 = convolution_backward_default_17[0]
        getitem_513 = convolution_backward_default_17[1]
        getitem_514 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_512, torch.float32);  getitem_512 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_121, torch.float32);  relu__default_121 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_152, to_dtype_39);  le_scalar_13 = new_zeros_default_152 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_153, primals_626, primals_624, primals_625, getitem_375, getitem_376, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_153 = primals_626 = primals_624 = primals_625 = getitem_375 = getitem_376 = None
        getitem_515 = native_batch_norm_backward_default_14[0]
        getitem_516 = native_batch_norm_backward_default_14[1]
        getitem_517 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_515, mean_dim_29, primals_629, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_515 = mean_dim_29 = primals_629 = None
        getitem_518 = convolution_backward_default_18[0]
        getitem_519 = convolution_backward_default_18[1]
        getitem_520 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_518, [128, 256, 16, 16]);  getitem_518 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_11, 256);  expand_default_11 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(div_scalar_4, 1);  div_scalar_4 = None
        expand_default_12 = torch.ops.aten.expand.default(unsqueeze_default_7, [128, 2, 256, 16, 16]);  unsqueeze_default_7 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_40, expand_default_12);  mul_tensor_40 = expand_default_12 = None
        view_default_187 = torch.ops.aten.view.default(add_tensor_6, [128, 512, 16, 16]);  add_tensor_6 = None
        to_dtype_42 = torch.ops.aten.to.dtype(view_default_187, torch.float32);  view_default_187 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_120, torch.float32);  relu__default_120 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_153, to_dtype_42);  le_scalar_14 = new_zeros_default_153 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_152, primals_621, primals_619, primals_620, getitem_372, getitem_373, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_152 = primals_621 = primals_619 = primals_620 = getitem_372 = getitem_373 = None
        getitem_521 = native_batch_norm_backward_default_15[0]
        getitem_522 = native_batch_norm_backward_default_15[1]
        getitem_523 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_521, relu__default_119, primals_627, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_521 = primals_627 = None
        getitem_524 = convolution_backward_default_19[0]
        getitem_525 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_524, torch.float32);  getitem_524 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_119, torch.float32);  relu__default_119 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_154, to_dtype_45);  le_scalar_15 = new_zeros_default_154 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_151, primals_610, primals_608, primals_609, getitem_369, getitem_370, True, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_151 = primals_610 = primals_608 = primals_609 = getitem_369 = getitem_370 = None
        getitem_527 = native_batch_norm_backward_default_16[0]
        getitem_528 = native_batch_norm_backward_default_16[1]
        getitem_529 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_527, relu__default_118, primals_616, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_527 = primals_616 = None
        getitem_530 = convolution_backward_default_20[0]
        getitem_531 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(to_dtype_38, getitem_530);  to_dtype_38 = getitem_530 = None
        to_dtype_48 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_118, torch.float32);  relu__default_118 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_155, to_dtype_48);  le_scalar_16 = new_zeros_default_155 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_150, primals_588, primals_586, primals_587, getitem_366, getitem_367, True, 1e-05, [True, True, True]);  convolution_default_150 = primals_588 = primals_586 = primals_587 = getitem_366 = getitem_367 = None
        getitem_533 = native_batch_norm_backward_default_17[0]
        getitem_534 = native_batch_norm_backward_default_17[1]
        getitem_535 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_533, sum_dim_int_list_57, primals_605, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_533 = sum_dim_int_list_57 = primals_605 = None
        getitem_536 = convolution_backward_default_21[0]
        getitem_537 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(getitem_536, 1);  getitem_536 = None
        expand_default_13 = torch.ops.aten.expand.default(unsqueeze_default_8, [128, 2, 256, 16, 16]);  unsqueeze_default_8 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(expand_default_13, view_default_140);  view_default_140 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(expand_default_13, view_default_144);  expand_default_13 = view_default_144 = None
        sum_dim_int_list_71 = torch.ops.aten.sum.dim_IntList(mul_tensor_41, [3, 4], True);  mul_tensor_41 = None
        view_default_188 = torch.ops.aten.view.default(sum_dim_int_list_71, [128, 512, 1, 1]);  sum_dim_int_list_71 = None
        view_default_189 = torch.ops.aten.view.default(view_default_188, [128, 512]);  view_default_188 = None
        view_default_190 = torch.ops.aten.view.default(view_default_189, [128, 2, 1, 256]);  view_default_189 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_190, _softmax_default_28, 1, torch.float32);  view_default_190 = _softmax_default_28 = None
        transpose_int_37 = torch.ops.aten.transpose.int(_softmax_backward_data_default_4, 1, 2);  _softmax_backward_data_default_4 = None
        view_default_191 = torch.ops.aten.view.default(transpose_int_37, [128, 512, 1, 1]);  transpose_int_37 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(view_default_191, relu__default_117, primals_604, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_191 = primals_604 = None
        getitem_539 = convolution_backward_default_22[0]
        getitem_540 = convolution_backward_default_22[1]
        getitem_541 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_539, torch.float32);  getitem_539 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_117, torch.float32);  relu__default_117 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_156, to_dtype_51);  le_scalar_17 = new_zeros_default_156 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_148, primals_599, primals_597, primals_598, getitem_363, getitem_364, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_148 = primals_599 = primals_597 = primals_598 = getitem_363 = getitem_364 = None
        getitem_542 = native_batch_norm_backward_default_18[0]
        getitem_543 = native_batch_norm_backward_default_18[1]
        getitem_544 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_542, mean_dim_28, primals_602, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_542 = mean_dim_28 = primals_602 = None
        getitem_545 = convolution_backward_default_23[0]
        getitem_546 = convolution_backward_default_23[1]
        getitem_547 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        expand_default_14 = torch.ops.aten.expand.default(getitem_545, [128, 256, 16, 16]);  getitem_545 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_14, 256);  expand_default_14 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(div_scalar_5, 1);  div_scalar_5 = None
        expand_default_15 = torch.ops.aten.expand.default(unsqueeze_default_9, [128, 2, 256, 16, 16]);  unsqueeze_default_9 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_42, expand_default_15);  mul_tensor_42 = expand_default_15 = None
        view_default_192 = torch.ops.aten.view.default(add_tensor_8, [128, 512, 16, 16]);  add_tensor_8 = None
        to_dtype_54 = torch.ops.aten.to.dtype(view_default_192, torch.float32);  view_default_192 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_116, torch.float32);  relu__default_116 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_157, to_dtype_54);  le_scalar_18 = new_zeros_default_157 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_147, primals_594, primals_592, primals_593, getitem_360, getitem_361, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_147 = primals_594 = primals_592 = primals_593 = getitem_360 = getitem_361 = None
        getitem_548 = native_batch_norm_backward_default_19[0]
        getitem_549 = native_batch_norm_backward_default_19[1]
        getitem_550 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_548, relu__default_115, primals_600, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_548 = primals_600 = None
        getitem_551 = convolution_backward_default_24[0]
        getitem_552 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_551, torch.float32);  getitem_551 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_115, torch.float32);  relu__default_115 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_158, to_dtype_57);  le_scalar_19 = new_zeros_default_158 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_146, primals_583, primals_581, primals_582, getitem_357, getitem_358, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_146 = primals_583 = primals_581 = primals_582 = getitem_357 = getitem_358 = None
        getitem_554 = native_batch_norm_backward_default_20[0]
        getitem_555 = native_batch_norm_backward_default_20[1]
        getitem_556 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_554, relu__default_114, primals_589, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_554 = primals_589 = None
        getitem_557 = convolution_backward_default_25[0]
        getitem_558 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(to_dtype_50, getitem_557);  to_dtype_50 = getitem_557 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_9, torch.float32);  add_tensor_9 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_114, torch.float32);  relu__default_114 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_159, to_dtype_60);  le_scalar_20 = new_zeros_default_159 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_145, primals_561, primals_559, primals_560, getitem_354, getitem_355, True, 1e-05, [True, True, True]);  convolution_default_145 = primals_561 = primals_559 = primals_560 = getitem_354 = getitem_355 = None
        getitem_560 = native_batch_norm_backward_default_21[0]
        getitem_561 = native_batch_norm_backward_default_21[1]
        getitem_562 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_560, sum_dim_int_list_55, primals_578, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_560 = sum_dim_int_list_55 = primals_578 = None
        getitem_563 = convolution_backward_default_26[0]
        getitem_564 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(getitem_563, 1);  getitem_563 = None
        expand_default_16 = torch.ops.aten.expand.default(unsqueeze_default_10, [128, 2, 256, 16, 16]);  unsqueeze_default_10 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(expand_default_16, view_default_135);  view_default_135 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(expand_default_16, view_default_139);  expand_default_16 = view_default_139 = None
        sum_dim_int_list_72 = torch.ops.aten.sum.dim_IntList(mul_tensor_43, [3, 4], True);  mul_tensor_43 = None
        view_default_193 = torch.ops.aten.view.default(sum_dim_int_list_72, [128, 512, 1, 1]);  sum_dim_int_list_72 = None
        view_default_194 = torch.ops.aten.view.default(view_default_193, [128, 512]);  view_default_193 = None
        view_default_195 = torch.ops.aten.view.default(view_default_194, [128, 2, 1, 256]);  view_default_194 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_195, _softmax_default_27, 1, torch.float32);  view_default_195 = _softmax_default_27 = None
        transpose_int_38 = torch.ops.aten.transpose.int(_softmax_backward_data_default_5, 1, 2);  _softmax_backward_data_default_5 = None
        view_default_196 = torch.ops.aten.view.default(transpose_int_38, [128, 512, 1, 1]);  transpose_int_38 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(view_default_196, relu__default_113, primals_577, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_196 = primals_577 = None
        getitem_566 = convolution_backward_default_27[0]
        getitem_567 = convolution_backward_default_27[1]
        getitem_568 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_566, torch.float32);  getitem_566 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_113, torch.float32);  relu__default_113 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_160, to_dtype_63);  le_scalar_21 = new_zeros_default_160 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_143, primals_572, primals_570, primals_571, getitem_351, getitem_352, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_143 = primals_572 = primals_570 = primals_571 = getitem_351 = getitem_352 = None
        getitem_569 = native_batch_norm_backward_default_22[0]
        getitem_570 = native_batch_norm_backward_default_22[1]
        getitem_571 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_569, mean_dim_27, primals_575, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_569 = mean_dim_27 = primals_575 = None
        getitem_572 = convolution_backward_default_28[0]
        getitem_573 = convolution_backward_default_28[1]
        getitem_574 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        expand_default_17 = torch.ops.aten.expand.default(getitem_572, [128, 256, 16, 16]);  getitem_572 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_17, 256);  expand_default_17 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(div_scalar_6, 1);  div_scalar_6 = None
        expand_default_18 = torch.ops.aten.expand.default(unsqueeze_default_11, [128, 2, 256, 16, 16]);  unsqueeze_default_11 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_44, expand_default_18);  mul_tensor_44 = expand_default_18 = None
        view_default_197 = torch.ops.aten.view.default(add_tensor_10, [128, 512, 16, 16]);  add_tensor_10 = None
        to_dtype_66 = torch.ops.aten.to.dtype(view_default_197, torch.float32);  view_default_197 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_112, torch.float32);  relu__default_112 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_161, to_dtype_66);  le_scalar_22 = new_zeros_default_161 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_142, primals_567, primals_565, primals_566, getitem_348, getitem_349, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_142 = primals_567 = primals_565 = primals_566 = getitem_348 = getitem_349 = None
        getitem_575 = native_batch_norm_backward_default_23[0]
        getitem_576 = native_batch_norm_backward_default_23[1]
        getitem_577 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_575, relu__default_111, primals_573, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_575 = primals_573 = None
        getitem_578 = convolution_backward_default_29[0]
        getitem_579 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_578, torch.float32);  getitem_578 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_111, torch.float32);  relu__default_111 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_162, to_dtype_69);  le_scalar_23 = new_zeros_default_162 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_141, primals_556, primals_554, primals_555, getitem_345, getitem_346, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_141 = primals_556 = primals_554 = primals_555 = getitem_345 = getitem_346 = None
        getitem_581 = native_batch_norm_backward_default_24[0]
        getitem_582 = native_batch_norm_backward_default_24[1]
        getitem_583 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_581, relu__default_110, primals_562, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_581 = primals_562 = None
        getitem_584 = convolution_backward_default_30[0]
        getitem_585 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_584);  to_dtype_62 = getitem_584 = None
        to_dtype_72 = torch.ops.aten.to.dtype(add_tensor_11, torch.float32);  add_tensor_11 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_110, torch.float32);  relu__default_110 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_163, to_dtype_72);  le_scalar_24 = new_zeros_default_163 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_140, primals_507, primals_505, primals_506, getitem_342, getitem_343, True, 1e-05, [True, True, True]);  convolution_default_140 = primals_507 = primals_505 = primals_506 = getitem_342 = getitem_343 = None
        getitem_587 = native_batch_norm_backward_default_25[0]
        getitem_588 = native_batch_norm_backward_default_25[1]
        getitem_589 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_587, sum_dim_int_list_53, primals_524, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_587 = sum_dim_int_list_53 = primals_524 = None
        getitem_590 = convolution_backward_default_31[0]
        getitem_591 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(getitem_590, 1);  getitem_590 = None
        expand_default_19 = torch.ops.aten.expand.default(unsqueeze_default_12, [128, 2, 256, 16, 16]);  unsqueeze_default_12 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(expand_default_19, view_default_130);  view_default_130 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(expand_default_19, view_default_134);  expand_default_19 = view_default_134 = None
        sum_dim_int_list_73 = torch.ops.aten.sum.dim_IntList(mul_tensor_45, [3, 4], True);  mul_tensor_45 = None
        view_default_198 = torch.ops.aten.view.default(sum_dim_int_list_73, [128, 512, 1, 1]);  sum_dim_int_list_73 = None
        view_default_199 = torch.ops.aten.view.default(view_default_198, [128, 512]);  view_default_198 = None
        view_default_200 = torch.ops.aten.view.default(view_default_199, [128, 2, 1, 256]);  view_default_199 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(view_default_200, _softmax_default_26, 1, torch.float32);  view_default_200 = _softmax_default_26 = None
        transpose_int_39 = torch.ops.aten.transpose.int(_softmax_backward_data_default_6, 1, 2);  _softmax_backward_data_default_6 = None
        view_default_201 = torch.ops.aten.view.default(transpose_int_39, [128, 512, 1, 1]);  transpose_int_39 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(view_default_201, relu__default_109, primals_523, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_201 = primals_523 = None
        getitem_593 = convolution_backward_default_32[0]
        getitem_594 = convolution_backward_default_32[1]
        getitem_595 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_593, torch.float32);  getitem_593 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_164, to_dtype_75);  le_scalar_25 = new_zeros_default_164 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_138, primals_518, primals_516, primals_517, getitem_339, getitem_340, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_138 = primals_518 = primals_516 = primals_517 = getitem_339 = getitem_340 = None
        getitem_596 = native_batch_norm_backward_default_26[0]
        getitem_597 = native_batch_norm_backward_default_26[1]
        getitem_598 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_596, mean_dim_26, primals_521, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_596 = mean_dim_26 = primals_521 = None
        getitem_599 = convolution_backward_default_33[0]
        getitem_600 = convolution_backward_default_33[1]
        getitem_601 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        expand_default_20 = torch.ops.aten.expand.default(getitem_599, [128, 256, 16, 16]);  getitem_599 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_20, 256);  expand_default_20 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(div_scalar_7, 1);  div_scalar_7 = None
        expand_default_21 = torch.ops.aten.expand.default(unsqueeze_default_13, [128, 2, 256, 16, 16]);  unsqueeze_default_13 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_46, expand_default_21);  mul_tensor_46 = expand_default_21 = None
        view_default_202 = torch.ops.aten.view.default(add_tensor_12, [128, 512, 16, 16]);  add_tensor_12 = None
        to_dtype_78 = torch.ops.aten.to.dtype(view_default_202, torch.float32);  view_default_202 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_165, to_dtype_78);  le_scalar_26 = new_zeros_default_165 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_137, primals_513, primals_511, primals_512, getitem_336, getitem_337, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_137 = primals_513 = primals_511 = primals_512 = getitem_336 = getitem_337 = None
        getitem_602 = native_batch_norm_backward_default_27[0]
        getitem_603 = native_batch_norm_backward_default_27[1]
        getitem_604 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_602, relu__default_107, primals_519, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_602 = primals_519 = None
        getitem_605 = convolution_backward_default_34[0]
        getitem_606 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_605, torch.float32);  getitem_605 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_166, to_dtype_81);  le_scalar_27 = new_zeros_default_166 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_136, primals_502, primals_500, primals_501, getitem_333, getitem_334, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_136 = primals_502 = primals_500 = primals_501 = getitem_333 = getitem_334 = None
        getitem_608 = native_batch_norm_backward_default_28[0]
        getitem_609 = native_batch_norm_backward_default_28[1]
        getitem_610 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_608, relu__default_106, primals_508, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_608 = primals_508 = None
        getitem_611 = convolution_backward_default_35[0]
        getitem_612 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(to_dtype_74, getitem_611);  to_dtype_74 = getitem_611 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_13, torch.float32);  add_tensor_13 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_167, to_dtype_84);  le_scalar_28 = new_zeros_default_167 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_135, primals_480, primals_478, primals_479, getitem_330, getitem_331, True, 1e-05, [True, True, True]);  convolution_default_135 = primals_480 = primals_478 = primals_479 = getitem_330 = getitem_331 = None
        getitem_614 = native_batch_norm_backward_default_29[0]
        getitem_615 = native_batch_norm_backward_default_29[1]
        getitem_616 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_614, sum_dim_int_list_51, primals_497, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_614 = sum_dim_int_list_51 = primals_497 = None
        getitem_617 = convolution_backward_default_36[0]
        getitem_618 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(getitem_617, 1);  getitem_617 = None
        expand_default_22 = torch.ops.aten.expand.default(unsqueeze_default_14, [128, 2, 256, 16, 16]);  unsqueeze_default_14 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(expand_default_22, view_default_125);  view_default_125 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(expand_default_22, view_default_129);  expand_default_22 = view_default_129 = None
        sum_dim_int_list_74 = torch.ops.aten.sum.dim_IntList(mul_tensor_47, [3, 4], True);  mul_tensor_47 = None
        view_default_203 = torch.ops.aten.view.default(sum_dim_int_list_74, [128, 512, 1, 1]);  sum_dim_int_list_74 = None
        view_default_204 = torch.ops.aten.view.default(view_default_203, [128, 512]);  view_default_203 = None
        view_default_205 = torch.ops.aten.view.default(view_default_204, [128, 2, 1, 256]);  view_default_204 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(view_default_205, _softmax_default_25, 1, torch.float32);  view_default_205 = _softmax_default_25 = None
        transpose_int_40 = torch.ops.aten.transpose.int(_softmax_backward_data_default_7, 1, 2);  _softmax_backward_data_default_7 = None
        view_default_206 = torch.ops.aten.view.default(transpose_int_40, [128, 512, 1, 1]);  transpose_int_40 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(view_default_206, relu__default_105, primals_496, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_206 = primals_496 = None
        getitem_620 = convolution_backward_default_37[0]
        getitem_621 = convolution_backward_default_37[1]
        getitem_622 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_620, torch.float32);  getitem_620 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_168, to_dtype_87);  le_scalar_29 = new_zeros_default_168 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_133, primals_491, primals_489, primals_490, getitem_327, getitem_328, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_133 = primals_491 = primals_489 = primals_490 = getitem_327 = getitem_328 = None
        getitem_623 = native_batch_norm_backward_default_30[0]
        getitem_624 = native_batch_norm_backward_default_30[1]
        getitem_625 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_623, mean_dim_25, primals_494, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_623 = mean_dim_25 = primals_494 = None
        getitem_626 = convolution_backward_default_38[0]
        getitem_627 = convolution_backward_default_38[1]
        getitem_628 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        expand_default_23 = torch.ops.aten.expand.default(getitem_626, [128, 256, 16, 16]);  getitem_626 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_23, 256);  expand_default_23 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(div_scalar_8, 1);  div_scalar_8 = None
        expand_default_24 = torch.ops.aten.expand.default(unsqueeze_default_15, [128, 2, 256, 16, 16]);  unsqueeze_default_15 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_48, expand_default_24);  mul_tensor_48 = expand_default_24 = None
        view_default_207 = torch.ops.aten.view.default(add_tensor_14, [128, 512, 16, 16]);  add_tensor_14 = None
        to_dtype_90 = torch.ops.aten.to.dtype(view_default_207, torch.float32);  view_default_207 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_169, to_dtype_90);  le_scalar_30 = new_zeros_default_169 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_132, primals_486, primals_484, primals_485, getitem_324, getitem_325, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_132 = primals_486 = primals_484 = primals_485 = getitem_324 = getitem_325 = None
        getitem_629 = native_batch_norm_backward_default_31[0]
        getitem_630 = native_batch_norm_backward_default_31[1]
        getitem_631 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_629, relu__default_103, primals_492, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_629 = primals_492 = None
        getitem_632 = convolution_backward_default_39[0]
        getitem_633 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_632, torch.float32);  getitem_632 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_170, to_dtype_93);  le_scalar_31 = new_zeros_default_170 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_131, primals_475, primals_473, primals_474, getitem_321, getitem_322, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_131 = primals_475 = primals_473 = primals_474 = getitem_321 = getitem_322 = None
        getitem_635 = native_batch_norm_backward_default_32[0]
        getitem_636 = native_batch_norm_backward_default_32[1]
        getitem_637 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_635, relu__default_102, primals_481, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_635 = primals_481 = None
        getitem_638 = convolution_backward_default_40[0]
        getitem_639 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(to_dtype_86, getitem_638);  to_dtype_86 = getitem_638 = None
        to_dtype_96 = torch.ops.aten.to.dtype(add_tensor_15, torch.float32);  add_tensor_15 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_171, to_dtype_96);  le_scalar_32 = new_zeros_default_171 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_130, primals_453, primals_451, primals_452, getitem_318, getitem_319, True, 1e-05, [True, True, True]);  convolution_default_130 = primals_453 = primals_451 = primals_452 = getitem_318 = getitem_319 = None
        getitem_641 = native_batch_norm_backward_default_33[0]
        getitem_642 = native_batch_norm_backward_default_33[1]
        getitem_643 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_641, sum_dim_int_list_49, primals_470, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_641 = sum_dim_int_list_49 = primals_470 = None
        getitem_644 = convolution_backward_default_41[0]
        getitem_645 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(getitem_644, 1);  getitem_644 = None
        expand_default_25 = torch.ops.aten.expand.default(unsqueeze_default_16, [128, 2, 256, 16, 16]);  unsqueeze_default_16 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(expand_default_25, view_default_120);  view_default_120 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(expand_default_25, view_default_124);  expand_default_25 = view_default_124 = None
        sum_dim_int_list_75 = torch.ops.aten.sum.dim_IntList(mul_tensor_49, [3, 4], True);  mul_tensor_49 = None
        view_default_208 = torch.ops.aten.view.default(sum_dim_int_list_75, [128, 512, 1, 1]);  sum_dim_int_list_75 = None
        view_default_209 = torch.ops.aten.view.default(view_default_208, [128, 512]);  view_default_208 = None
        view_default_210 = torch.ops.aten.view.default(view_default_209, [128, 2, 1, 256]);  view_default_209 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(view_default_210, _softmax_default_24, 1, torch.float32);  view_default_210 = _softmax_default_24 = None
        transpose_int_41 = torch.ops.aten.transpose.int(_softmax_backward_data_default_8, 1, 2);  _softmax_backward_data_default_8 = None
        view_default_211 = torch.ops.aten.view.default(transpose_int_41, [128, 512, 1, 1]);  transpose_int_41 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(view_default_211, relu__default_101, primals_469, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_211 = primals_469 = None
        getitem_647 = convolution_backward_default_42[0]
        getitem_648 = convolution_backward_default_42[1]
        getitem_649 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_647, torch.float32);  getitem_647 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_172, to_dtype_99);  le_scalar_33 = new_zeros_default_172 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_128, primals_464, primals_462, primals_463, getitem_315, getitem_316, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_128 = primals_464 = primals_462 = primals_463 = getitem_315 = getitem_316 = None
        getitem_650 = native_batch_norm_backward_default_34[0]
        getitem_651 = native_batch_norm_backward_default_34[1]
        getitem_652 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_650, mean_dim_24, primals_467, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_650 = mean_dim_24 = primals_467 = None
        getitem_653 = convolution_backward_default_43[0]
        getitem_654 = convolution_backward_default_43[1]
        getitem_655 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        expand_default_26 = torch.ops.aten.expand.default(getitem_653, [128, 256, 16, 16]);  getitem_653 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_26, 256);  expand_default_26 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(div_scalar_9, 1);  div_scalar_9 = None
        expand_default_27 = torch.ops.aten.expand.default(unsqueeze_default_17, [128, 2, 256, 16, 16]);  unsqueeze_default_17 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(mul_tensor_50, expand_default_27);  mul_tensor_50 = expand_default_27 = None
        view_default_212 = torch.ops.aten.view.default(add_tensor_16, [128, 512, 16, 16]);  add_tensor_16 = None
        to_dtype_102 = torch.ops.aten.to.dtype(view_default_212, torch.float32);  view_default_212 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_173, to_dtype_102);  le_scalar_34 = new_zeros_default_173 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_127, primals_459, primals_457, primals_458, getitem_312, getitem_313, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_127 = primals_459 = primals_457 = primals_458 = getitem_312 = getitem_313 = None
        getitem_656 = native_batch_norm_backward_default_35[0]
        getitem_657 = native_batch_norm_backward_default_35[1]
        getitem_658 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_656, relu__default_99, primals_465, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_656 = primals_465 = None
        getitem_659 = convolution_backward_default_44[0]
        getitem_660 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_659, torch.float32);  getitem_659 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_174, to_dtype_105);  le_scalar_35 = new_zeros_default_174 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_126, primals_448, primals_446, primals_447, getitem_309, getitem_310, True, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_126 = primals_448 = primals_446 = primals_447 = getitem_309 = getitem_310 = None
        getitem_662 = native_batch_norm_backward_default_36[0]
        getitem_663 = native_batch_norm_backward_default_36[1]
        getitem_664 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_662, relu__default_98, primals_454, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_662 = primals_454 = None
        getitem_665 = convolution_backward_default_45[0]
        getitem_666 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(to_dtype_98, getitem_665);  to_dtype_98 = getitem_665 = None
        to_dtype_108 = torch.ops.aten.to.dtype(add_tensor_17, torch.float32);  add_tensor_17 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_175, to_dtype_108);  le_scalar_36 = new_zeros_default_175 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_125, primals_426, primals_424, primals_425, getitem_306, getitem_307, True, 1e-05, [True, True, True]);  convolution_default_125 = primals_426 = primals_424 = primals_425 = getitem_306 = getitem_307 = None
        getitem_668 = native_batch_norm_backward_default_37[0]
        getitem_669 = native_batch_norm_backward_default_37[1]
        getitem_670 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_668, sum_dim_int_list_47, primals_443, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_668 = sum_dim_int_list_47 = primals_443 = None
        getitem_671 = convolution_backward_default_46[0]
        getitem_672 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(getitem_671, 1);  getitem_671 = None
        expand_default_28 = torch.ops.aten.expand.default(unsqueeze_default_18, [128, 2, 256, 16, 16]);  unsqueeze_default_18 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(expand_default_28, view_default_115);  view_default_115 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(expand_default_28, view_default_119);  expand_default_28 = view_default_119 = None
        sum_dim_int_list_76 = torch.ops.aten.sum.dim_IntList(mul_tensor_51, [3, 4], True);  mul_tensor_51 = None
        view_default_213 = torch.ops.aten.view.default(sum_dim_int_list_76, [128, 512, 1, 1]);  sum_dim_int_list_76 = None
        view_default_214 = torch.ops.aten.view.default(view_default_213, [128, 512]);  view_default_213 = None
        view_default_215 = torch.ops.aten.view.default(view_default_214, [128, 2, 1, 256]);  view_default_214 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(view_default_215, _softmax_default_23, 1, torch.float32);  view_default_215 = _softmax_default_23 = None
        transpose_int_42 = torch.ops.aten.transpose.int(_softmax_backward_data_default_9, 1, 2);  _softmax_backward_data_default_9 = None
        view_default_216 = torch.ops.aten.view.default(transpose_int_42, [128, 512, 1, 1]);  transpose_int_42 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(view_default_216, relu__default_97, primals_442, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_216 = primals_442 = None
        getitem_674 = convolution_backward_default_47[0]
        getitem_675 = convolution_backward_default_47[1]
        getitem_676 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_674, torch.float32);  getitem_674 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_176, to_dtype_111);  le_scalar_37 = new_zeros_default_176 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_123, primals_437, primals_435, primals_436, getitem_303, getitem_304, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_123 = primals_437 = primals_435 = primals_436 = getitem_303 = getitem_304 = None
        getitem_677 = native_batch_norm_backward_default_38[0]
        getitem_678 = native_batch_norm_backward_default_38[1]
        getitem_679 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_677, mean_dim_23, primals_440, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_677 = mean_dim_23 = primals_440 = None
        getitem_680 = convolution_backward_default_48[0]
        getitem_681 = convolution_backward_default_48[1]
        getitem_682 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        expand_default_29 = torch.ops.aten.expand.default(getitem_680, [128, 256, 16, 16]);  getitem_680 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_29, 256);  expand_default_29 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(div_scalar_10, 1);  div_scalar_10 = None
        expand_default_30 = torch.ops.aten.expand.default(unsqueeze_default_19, [128, 2, 256, 16, 16]);  unsqueeze_default_19 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(mul_tensor_52, expand_default_30);  mul_tensor_52 = expand_default_30 = None
        view_default_217 = torch.ops.aten.view.default(add_tensor_18, [128, 512, 16, 16]);  add_tensor_18 = None
        to_dtype_114 = torch.ops.aten.to.dtype(view_default_217, torch.float32);  view_default_217 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_177, to_dtype_114);  le_scalar_38 = new_zeros_default_177 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_122, primals_432, primals_430, primals_431, getitem_300, getitem_301, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_122 = primals_432 = primals_430 = primals_431 = getitem_300 = getitem_301 = None
        getitem_683 = native_batch_norm_backward_default_39[0]
        getitem_684 = native_batch_norm_backward_default_39[1]
        getitem_685 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_683, relu__default_95, primals_438, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_683 = primals_438 = None
        getitem_686 = convolution_backward_default_49[0]
        getitem_687 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_686, torch.float32);  getitem_686 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_178, to_dtype_117);  le_scalar_39 = new_zeros_default_178 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_121, primals_421, primals_419, primals_420, getitem_297, getitem_298, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_121 = primals_421 = primals_419 = primals_420 = getitem_297 = getitem_298 = None
        getitem_689 = native_batch_norm_backward_default_40[0]
        getitem_690 = native_batch_norm_backward_default_40[1]
        getitem_691 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_689, relu__default_94, primals_427, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_689 = primals_427 = None
        getitem_692 = convolution_backward_default_50[0]
        getitem_693 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(to_dtype_110, getitem_692);  to_dtype_110 = getitem_692 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_19, torch.float32);  add_tensor_19 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_179, to_dtype_120);  le_scalar_40 = new_zeros_default_179 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_120, primals_399, primals_397, primals_398, getitem_294, getitem_295, True, 1e-05, [True, True, True]);  convolution_default_120 = primals_399 = primals_397 = primals_398 = getitem_294 = getitem_295 = None
        getitem_695 = native_batch_norm_backward_default_41[0]
        getitem_696 = native_batch_norm_backward_default_41[1]
        getitem_697 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_695, sum_dim_int_list_45, primals_416, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_695 = sum_dim_int_list_45 = primals_416 = None
        getitem_698 = convolution_backward_default_51[0]
        getitem_699 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(getitem_698, 1);  getitem_698 = None
        expand_default_31 = torch.ops.aten.expand.default(unsqueeze_default_20, [128, 2, 256, 16, 16]);  unsqueeze_default_20 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(expand_default_31, view_default_110);  view_default_110 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(expand_default_31, view_default_114);  expand_default_31 = view_default_114 = None
        sum_dim_int_list_77 = torch.ops.aten.sum.dim_IntList(mul_tensor_53, [3, 4], True);  mul_tensor_53 = None
        view_default_218 = torch.ops.aten.view.default(sum_dim_int_list_77, [128, 512, 1, 1]);  sum_dim_int_list_77 = None
        view_default_219 = torch.ops.aten.view.default(view_default_218, [128, 512]);  view_default_218 = None
        view_default_220 = torch.ops.aten.view.default(view_default_219, [128, 2, 1, 256]);  view_default_219 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(view_default_220, _softmax_default_22, 1, torch.float32);  view_default_220 = _softmax_default_22 = None
        transpose_int_43 = torch.ops.aten.transpose.int(_softmax_backward_data_default_10, 1, 2);  _softmax_backward_data_default_10 = None
        view_default_221 = torch.ops.aten.view.default(transpose_int_43, [128, 512, 1, 1]);  transpose_int_43 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(view_default_221, relu__default_93, primals_415, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_221 = primals_415 = None
        getitem_701 = convolution_backward_default_52[0]
        getitem_702 = convolution_backward_default_52[1]
        getitem_703 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_701, torch.float32);  getitem_701 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_180, to_dtype_123);  le_scalar_41 = new_zeros_default_180 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_118, primals_410, primals_408, primals_409, getitem_291, getitem_292, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_118 = primals_410 = primals_408 = primals_409 = getitem_291 = getitem_292 = None
        getitem_704 = native_batch_norm_backward_default_42[0]
        getitem_705 = native_batch_norm_backward_default_42[1]
        getitem_706 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_704, mean_dim_22, primals_413, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_704 = mean_dim_22 = primals_413 = None
        getitem_707 = convolution_backward_default_53[0]
        getitem_708 = convolution_backward_default_53[1]
        getitem_709 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        expand_default_32 = torch.ops.aten.expand.default(getitem_707, [128, 256, 16, 16]);  getitem_707 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_32, 256);  expand_default_32 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(div_scalar_11, 1);  div_scalar_11 = None
        expand_default_33 = torch.ops.aten.expand.default(unsqueeze_default_21, [128, 2, 256, 16, 16]);  unsqueeze_default_21 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(mul_tensor_54, expand_default_33);  mul_tensor_54 = expand_default_33 = None
        view_default_222 = torch.ops.aten.view.default(add_tensor_20, [128, 512, 16, 16]);  add_tensor_20 = None
        to_dtype_126 = torch.ops.aten.to.dtype(view_default_222, torch.float32);  view_default_222 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_181, to_dtype_126);  le_scalar_42 = new_zeros_default_181 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_117, primals_405, primals_403, primals_404, getitem_288, getitem_289, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default_117 = primals_405 = primals_403 = primals_404 = getitem_288 = getitem_289 = None
        getitem_710 = native_batch_norm_backward_default_43[0]
        getitem_711 = native_batch_norm_backward_default_43[1]
        getitem_712 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_710, relu__default_91, primals_411, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_710 = primals_411 = None
        getitem_713 = convolution_backward_default_54[0]
        getitem_714 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_713, torch.float32);  getitem_713 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_182, to_dtype_129);  le_scalar_43 = new_zeros_default_182 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_116, primals_394, primals_392, primals_393, getitem_285, getitem_286, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_116 = primals_394 = primals_392 = primals_393 = getitem_285 = getitem_286 = None
        getitem_716 = native_batch_norm_backward_default_44[0]
        getitem_717 = native_batch_norm_backward_default_44[1]
        getitem_718 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_716, relu__default_90, primals_400, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_716 = primals_400 = None
        getitem_719 = convolution_backward_default_55[0]
        getitem_720 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(to_dtype_122, getitem_719);  to_dtype_122 = getitem_719 = None
        to_dtype_132 = torch.ops.aten.to.dtype(add_tensor_21, torch.float32);  add_tensor_21 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_183, to_dtype_132);  le_scalar_44 = new_zeros_default_183 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_115, primals_372, primals_370, primals_371, getitem_282, getitem_283, True, 1e-05, [True, True, True]);  convolution_default_115 = primals_372 = primals_370 = primals_371 = getitem_282 = getitem_283 = None
        getitem_722 = native_batch_norm_backward_default_45[0]
        getitem_723 = native_batch_norm_backward_default_45[1]
        getitem_724 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_722, sum_dim_int_list_43, primals_389, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_722 = sum_dim_int_list_43 = primals_389 = None
        getitem_725 = convolution_backward_default_56[0]
        getitem_726 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(getitem_725, 1);  getitem_725 = None
        expand_default_34 = torch.ops.aten.expand.default(unsqueeze_default_22, [128, 2, 256, 16, 16]);  unsqueeze_default_22 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(expand_default_34, view_default_105);  view_default_105 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(expand_default_34, view_default_109);  expand_default_34 = view_default_109 = None
        sum_dim_int_list_78 = torch.ops.aten.sum.dim_IntList(mul_tensor_55, [3, 4], True);  mul_tensor_55 = None
        view_default_223 = torch.ops.aten.view.default(sum_dim_int_list_78, [128, 512, 1, 1]);  sum_dim_int_list_78 = None
        view_default_224 = torch.ops.aten.view.default(view_default_223, [128, 512]);  view_default_223 = None
        view_default_225 = torch.ops.aten.view.default(view_default_224, [128, 2, 1, 256]);  view_default_224 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(view_default_225, _softmax_default_21, 1, torch.float32);  view_default_225 = _softmax_default_21 = None
        transpose_int_44 = torch.ops.aten.transpose.int(_softmax_backward_data_default_11, 1, 2);  _softmax_backward_data_default_11 = None
        view_default_226 = torch.ops.aten.view.default(transpose_int_44, [128, 512, 1, 1]);  transpose_int_44 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(view_default_226, relu__default_89, primals_388, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_226 = primals_388 = None
        getitem_728 = convolution_backward_default_57[0]
        getitem_729 = convolution_backward_default_57[1]
        getitem_730 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_728, torch.float32);  getitem_728 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_184, to_dtype_135);  le_scalar_45 = new_zeros_default_184 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_113, primals_383, primals_381, primals_382, getitem_279, getitem_280, True, 1e-05, [True, True, True]);  to_dtype_137 = convolution_default_113 = primals_383 = primals_381 = primals_382 = getitem_279 = getitem_280 = None
        getitem_731 = native_batch_norm_backward_default_46[0]
        getitem_732 = native_batch_norm_backward_default_46[1]
        getitem_733 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_731, mean_dim_21, primals_386, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_731 = mean_dim_21 = primals_386 = None
        getitem_734 = convolution_backward_default_58[0]
        getitem_735 = convolution_backward_default_58[1]
        getitem_736 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        expand_default_35 = torch.ops.aten.expand.default(getitem_734, [128, 256, 16, 16]);  getitem_734 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_35, 256);  expand_default_35 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(div_scalar_12, 1);  div_scalar_12 = None
        expand_default_36 = torch.ops.aten.expand.default(unsqueeze_default_23, [128, 2, 256, 16, 16]);  unsqueeze_default_23 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(mul_tensor_56, expand_default_36);  mul_tensor_56 = expand_default_36 = None
        view_default_227 = torch.ops.aten.view.default(add_tensor_22, [128, 512, 16, 16]);  add_tensor_22 = None
        to_dtype_138 = torch.ops.aten.to.dtype(view_default_227, torch.float32);  view_default_227 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_185, to_dtype_138);  le_scalar_46 = new_zeros_default_185 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_112, primals_378, primals_376, primals_377, getitem_276, getitem_277, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_112 = primals_378 = primals_376 = primals_377 = getitem_276 = getitem_277 = None
        getitem_737 = native_batch_norm_backward_default_47[0]
        getitem_738 = native_batch_norm_backward_default_47[1]
        getitem_739 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_737, relu__default_87, primals_384, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_737 = primals_384 = None
        getitem_740 = convolution_backward_default_59[0]
        getitem_741 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_740, torch.float32);  getitem_740 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_186, to_dtype_141);  le_scalar_47 = new_zeros_default_186 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_111, primals_367, primals_365, primals_366, getitem_273, getitem_274, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_111 = primals_367 = primals_365 = primals_366 = getitem_273 = getitem_274 = None
        getitem_743 = native_batch_norm_backward_default_48[0]
        getitem_744 = native_batch_norm_backward_default_48[1]
        getitem_745 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_743, relu__default_86, primals_373, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_743 = primals_373 = None
        getitem_746 = convolution_backward_default_60[0]
        getitem_747 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(to_dtype_134, getitem_746);  to_dtype_134 = getitem_746 = None
        to_dtype_144 = torch.ops.aten.to.dtype(add_tensor_23, torch.float32);  add_tensor_23 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_187, to_dtype_144);  le_scalar_48 = new_zeros_default_187 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_110, primals_345, primals_343, primals_344, getitem_270, getitem_271, True, 1e-05, [True, True, True]);  convolution_default_110 = primals_345 = primals_343 = primals_344 = getitem_270 = getitem_271 = None
        getitem_749 = native_batch_norm_backward_default_49[0]
        getitem_750 = native_batch_norm_backward_default_49[1]
        getitem_751 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_749, sum_dim_int_list_41, primals_362, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_749 = sum_dim_int_list_41 = primals_362 = None
        getitem_752 = convolution_backward_default_61[0]
        getitem_753 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(getitem_752, 1);  getitem_752 = None
        expand_default_37 = torch.ops.aten.expand.default(unsqueeze_default_24, [128, 2, 256, 16, 16]);  unsqueeze_default_24 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(expand_default_37, view_default_100);  view_default_100 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(expand_default_37, view_default_104);  expand_default_37 = view_default_104 = None
        sum_dim_int_list_79 = torch.ops.aten.sum.dim_IntList(mul_tensor_57, [3, 4], True);  mul_tensor_57 = None
        view_default_228 = torch.ops.aten.view.default(sum_dim_int_list_79, [128, 512, 1, 1]);  sum_dim_int_list_79 = None
        view_default_229 = torch.ops.aten.view.default(view_default_228, [128, 512]);  view_default_228 = None
        view_default_230 = torch.ops.aten.view.default(view_default_229, [128, 2, 1, 256]);  view_default_229 = None
        _softmax_backward_data_default_12 = torch.ops.aten._softmax_backward_data.default(view_default_230, _softmax_default_20, 1, torch.float32);  view_default_230 = _softmax_default_20 = None
        transpose_int_45 = torch.ops.aten.transpose.int(_softmax_backward_data_default_12, 1, 2);  _softmax_backward_data_default_12 = None
        view_default_231 = torch.ops.aten.view.default(transpose_int_45, [128, 512, 1, 1]);  transpose_int_45 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(view_default_231, relu__default_85, primals_361, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_231 = primals_361 = None
        getitem_755 = convolution_backward_default_62[0]
        getitem_756 = convolution_backward_default_62[1]
        getitem_757 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_755, torch.float32);  getitem_755 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_188, to_dtype_147);  le_scalar_49 = new_zeros_default_188 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_108, primals_356, primals_354, primals_355, getitem_267, getitem_268, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_108 = primals_356 = primals_354 = primals_355 = getitem_267 = getitem_268 = None
        getitem_758 = native_batch_norm_backward_default_50[0]
        getitem_759 = native_batch_norm_backward_default_50[1]
        getitem_760 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_758, mean_dim_20, primals_359, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_758 = mean_dim_20 = primals_359 = None
        getitem_761 = convolution_backward_default_63[0]
        getitem_762 = convolution_backward_default_63[1]
        getitem_763 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        expand_default_38 = torch.ops.aten.expand.default(getitem_761, [128, 256, 16, 16]);  getitem_761 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_38, 256);  expand_default_38 = None
        unsqueeze_default_25 = torch.ops.aten.unsqueeze.default(div_scalar_13, 1);  div_scalar_13 = None
        expand_default_39 = torch.ops.aten.expand.default(unsqueeze_default_25, [128, 2, 256, 16, 16]);  unsqueeze_default_25 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_58, expand_default_39);  mul_tensor_58 = expand_default_39 = None
        view_default_232 = torch.ops.aten.view.default(add_tensor_24, [128, 512, 16, 16]);  add_tensor_24 = None
        to_dtype_150 = torch.ops.aten.to.dtype(view_default_232, torch.float32);  view_default_232 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_189, to_dtype_150);  le_scalar_50 = new_zeros_default_189 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_107, primals_351, primals_349, primals_350, getitem_264, getitem_265, True, 1e-05, [True, True, True]);  to_dtype_152 = convolution_default_107 = primals_351 = primals_349 = primals_350 = getitem_264 = getitem_265 = None
        getitem_764 = native_batch_norm_backward_default_51[0]
        getitem_765 = native_batch_norm_backward_default_51[1]
        getitem_766 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_764, relu__default_83, primals_357, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_764 = primals_357 = None
        getitem_767 = convolution_backward_default_64[0]
        getitem_768 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_767, torch.float32);  getitem_767 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_190, to_dtype_153);  le_scalar_51 = new_zeros_default_190 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_106, primals_340, primals_338, primals_339, getitem_261, getitem_262, True, 1e-05, [True, True, True]);  to_dtype_155 = convolution_default_106 = primals_340 = primals_338 = primals_339 = getitem_261 = getitem_262 = None
        getitem_770 = native_batch_norm_backward_default_52[0]
        getitem_771 = native_batch_norm_backward_default_52[1]
        getitem_772 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_770, relu__default_82, primals_346, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_770 = primals_346 = None
        getitem_773 = convolution_backward_default_65[0]
        getitem_774 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(to_dtype_146, getitem_773);  to_dtype_146 = getitem_773 = None
        to_dtype_156 = torch.ops.aten.to.dtype(add_tensor_25, torch.float32);  add_tensor_25 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_191, to_dtype_156);  le_scalar_52 = new_zeros_default_191 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_105, primals_318, primals_316, primals_317, getitem_258, getitem_259, True, 1e-05, [True, True, True]);  convolution_default_105 = primals_318 = primals_316 = primals_317 = getitem_258 = getitem_259 = None
        getitem_776 = native_batch_norm_backward_default_53[0]
        getitem_777 = native_batch_norm_backward_default_53[1]
        getitem_778 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_776, sum_dim_int_list_39, primals_335, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_776 = sum_dim_int_list_39 = primals_335 = None
        getitem_779 = convolution_backward_default_66[0]
        getitem_780 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        unsqueeze_default_26 = torch.ops.aten.unsqueeze.default(getitem_779, 1);  getitem_779 = None
        expand_default_40 = torch.ops.aten.expand.default(unsqueeze_default_26, [128, 2, 256, 16, 16]);  unsqueeze_default_26 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(expand_default_40, view_default_95);  view_default_95 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(expand_default_40, view_default_99);  expand_default_40 = view_default_99 = None
        sum_dim_int_list_80 = torch.ops.aten.sum.dim_IntList(mul_tensor_59, [3, 4], True);  mul_tensor_59 = None
        view_default_233 = torch.ops.aten.view.default(sum_dim_int_list_80, [128, 512, 1, 1]);  sum_dim_int_list_80 = None
        view_default_234 = torch.ops.aten.view.default(view_default_233, [128, 512]);  view_default_233 = None
        view_default_235 = torch.ops.aten.view.default(view_default_234, [128, 2, 1, 256]);  view_default_234 = None
        _softmax_backward_data_default_13 = torch.ops.aten._softmax_backward_data.default(view_default_235, _softmax_default_19, 1, torch.float32);  view_default_235 = _softmax_default_19 = None
        transpose_int_46 = torch.ops.aten.transpose.int(_softmax_backward_data_default_13, 1, 2);  _softmax_backward_data_default_13 = None
        view_default_236 = torch.ops.aten.view.default(transpose_int_46, [128, 512, 1, 1]);  transpose_int_46 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(view_default_236, relu__default_81, primals_334, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_236 = primals_334 = None
        getitem_782 = convolution_backward_default_67[0]
        getitem_783 = convolution_backward_default_67[1]
        getitem_784 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_782, torch.float32);  getitem_782 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_192, to_dtype_159);  le_scalar_53 = new_zeros_default_192 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_103, primals_329, primals_327, primals_328, getitem_255, getitem_256, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_103 = primals_329 = primals_327 = primals_328 = getitem_255 = getitem_256 = None
        getitem_785 = native_batch_norm_backward_default_54[0]
        getitem_786 = native_batch_norm_backward_default_54[1]
        getitem_787 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_785, mean_dim_19, primals_332, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_785 = mean_dim_19 = primals_332 = None
        getitem_788 = convolution_backward_default_68[0]
        getitem_789 = convolution_backward_default_68[1]
        getitem_790 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        expand_default_41 = torch.ops.aten.expand.default(getitem_788, [128, 256, 16, 16]);  getitem_788 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_41, 256);  expand_default_41 = None
        unsqueeze_default_27 = torch.ops.aten.unsqueeze.default(div_scalar_14, 1);  div_scalar_14 = None
        expand_default_42 = torch.ops.aten.expand.default(unsqueeze_default_27, [128, 2, 256, 16, 16]);  unsqueeze_default_27 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_60, expand_default_42);  mul_tensor_60 = expand_default_42 = None
        view_default_237 = torch.ops.aten.view.default(add_tensor_26, [128, 512, 16, 16]);  add_tensor_26 = None
        to_dtype_162 = torch.ops.aten.to.dtype(view_default_237, torch.float32);  view_default_237 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_193, to_dtype_162);  le_scalar_54 = new_zeros_default_193 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_102, primals_324, primals_322, primals_323, getitem_252, getitem_253, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_102 = primals_324 = primals_322 = primals_323 = getitem_252 = getitem_253 = None
        getitem_791 = native_batch_norm_backward_default_55[0]
        getitem_792 = native_batch_norm_backward_default_55[1]
        getitem_793 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_791, relu__default_79, primals_330, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_791 = primals_330 = None
        getitem_794 = convolution_backward_default_69[0]
        getitem_795 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_794, torch.float32);  getitem_794 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_194, to_dtype_165);  le_scalar_55 = new_zeros_default_194 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_101, primals_313, primals_311, primals_312, getitem_249, getitem_250, True, 1e-05, [True, True, True]);  to_dtype_167 = convolution_default_101 = primals_313 = primals_311 = primals_312 = getitem_249 = getitem_250 = None
        getitem_797 = native_batch_norm_backward_default_56[0]
        getitem_798 = native_batch_norm_backward_default_56[1]
        getitem_799 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_797, relu__default_78, primals_319, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_797 = primals_319 = None
        getitem_800 = convolution_backward_default_70[0]
        getitem_801 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(to_dtype_158, getitem_800);  to_dtype_158 = getitem_800 = None
        to_dtype_168 = torch.ops.aten.to.dtype(add_tensor_27, torch.float32);  add_tensor_27 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_195, to_dtype_168);  le_scalar_56 = new_zeros_default_195 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_100, primals_291, primals_289, primals_290, getitem_246, getitem_247, True, 1e-05, [True, True, True]);  convolution_default_100 = primals_291 = primals_289 = primals_290 = getitem_246 = getitem_247 = None
        getitem_803 = native_batch_norm_backward_default_57[0]
        getitem_804 = native_batch_norm_backward_default_57[1]
        getitem_805 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_803, sum_dim_int_list_37, primals_308, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_803 = sum_dim_int_list_37 = primals_308 = None
        getitem_806 = convolution_backward_default_71[0]
        getitem_807 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        unsqueeze_default_28 = torch.ops.aten.unsqueeze.default(getitem_806, 1);  getitem_806 = None
        expand_default_43 = torch.ops.aten.expand.default(unsqueeze_default_28, [128, 2, 256, 16, 16]);  unsqueeze_default_28 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(expand_default_43, view_default_90);  view_default_90 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(expand_default_43, view_default_94);  expand_default_43 = view_default_94 = None
        sum_dim_int_list_81 = torch.ops.aten.sum.dim_IntList(mul_tensor_61, [3, 4], True);  mul_tensor_61 = None
        view_default_238 = torch.ops.aten.view.default(sum_dim_int_list_81, [128, 512, 1, 1]);  sum_dim_int_list_81 = None
        view_default_239 = torch.ops.aten.view.default(view_default_238, [128, 512]);  view_default_238 = None
        view_default_240 = torch.ops.aten.view.default(view_default_239, [128, 2, 1, 256]);  view_default_239 = None
        _softmax_backward_data_default_14 = torch.ops.aten._softmax_backward_data.default(view_default_240, _softmax_default_18, 1, torch.float32);  view_default_240 = _softmax_default_18 = None
        transpose_int_47 = torch.ops.aten.transpose.int(_softmax_backward_data_default_14, 1, 2);  _softmax_backward_data_default_14 = None
        view_default_241 = torch.ops.aten.view.default(transpose_int_47, [128, 512, 1, 1]);  transpose_int_47 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(view_default_241, relu__default_77, primals_307, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_241 = primals_307 = None
        getitem_809 = convolution_backward_default_72[0]
        getitem_810 = convolution_backward_default_72[1]
        getitem_811 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_809, torch.float32);  getitem_809 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_196, to_dtype_171);  le_scalar_57 = new_zeros_default_196 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_98, primals_302, primals_300, primals_301, getitem_243, getitem_244, True, 1e-05, [True, True, True]);  to_dtype_173 = convolution_default_98 = primals_302 = primals_300 = primals_301 = getitem_243 = getitem_244 = None
        getitem_812 = native_batch_norm_backward_default_58[0]
        getitem_813 = native_batch_norm_backward_default_58[1]
        getitem_814 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_812, mean_dim_18, primals_305, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_812 = mean_dim_18 = primals_305 = None
        getitem_815 = convolution_backward_default_73[0]
        getitem_816 = convolution_backward_default_73[1]
        getitem_817 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        expand_default_44 = torch.ops.aten.expand.default(getitem_815, [128, 256, 16, 16]);  getitem_815 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_44, 256);  expand_default_44 = None
        unsqueeze_default_29 = torch.ops.aten.unsqueeze.default(div_scalar_15, 1);  div_scalar_15 = None
        expand_default_45 = torch.ops.aten.expand.default(unsqueeze_default_29, [128, 2, 256, 16, 16]);  unsqueeze_default_29 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(mul_tensor_62, expand_default_45);  mul_tensor_62 = expand_default_45 = None
        view_default_242 = torch.ops.aten.view.default(add_tensor_28, [128, 512, 16, 16]);  add_tensor_28 = None
        to_dtype_174 = torch.ops.aten.to.dtype(view_default_242, torch.float32);  view_default_242 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_197, to_dtype_174);  le_scalar_58 = new_zeros_default_197 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_97, primals_297, primals_295, primals_296, getitem_240, getitem_241, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_97 = primals_297 = primals_295 = primals_296 = getitem_240 = getitem_241 = None
        getitem_818 = native_batch_norm_backward_default_59[0]
        getitem_819 = native_batch_norm_backward_default_59[1]
        getitem_820 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_818, relu__default_75, primals_303, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_818 = primals_303 = None
        getitem_821 = convolution_backward_default_74[0]
        getitem_822 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_821, torch.float32);  getitem_821 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_198, to_dtype_177);  le_scalar_59 = new_zeros_default_198 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_96, primals_286, primals_284, primals_285, getitem_237, getitem_238, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_96 = primals_286 = primals_284 = primals_285 = getitem_237 = getitem_238 = None
        getitem_824 = native_batch_norm_backward_default_60[0]
        getitem_825 = native_batch_norm_backward_default_60[1]
        getitem_826 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_824, relu__default_74, primals_292, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_824 = primals_292 = None
        getitem_827 = convolution_backward_default_75[0]
        getitem_828 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(to_dtype_170, getitem_827);  to_dtype_170 = getitem_827 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_29, torch.float32);  add_tensor_29 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_199, to_dtype_180);  le_scalar_60 = new_zeros_default_199 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_95, primals_264, primals_262, primals_263, getitem_234, getitem_235, True, 1e-05, [True, True, True]);  convolution_default_95 = primals_264 = primals_262 = primals_263 = getitem_234 = getitem_235 = None
        getitem_830 = native_batch_norm_backward_default_61[0]
        getitem_831 = native_batch_norm_backward_default_61[1]
        getitem_832 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_830, sum_dim_int_list_35, primals_281, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_830 = sum_dim_int_list_35 = primals_281 = None
        getitem_833 = convolution_backward_default_76[0]
        getitem_834 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        unsqueeze_default_30 = torch.ops.aten.unsqueeze.default(getitem_833, 1);  getitem_833 = None
        expand_default_46 = torch.ops.aten.expand.default(unsqueeze_default_30, [128, 2, 256, 16, 16]);  unsqueeze_default_30 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(expand_default_46, view_default_85);  view_default_85 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(expand_default_46, view_default_89);  expand_default_46 = view_default_89 = None
        sum_dim_int_list_82 = torch.ops.aten.sum.dim_IntList(mul_tensor_63, [3, 4], True);  mul_tensor_63 = None
        view_default_243 = torch.ops.aten.view.default(sum_dim_int_list_82, [128, 512, 1, 1]);  sum_dim_int_list_82 = None
        view_default_244 = torch.ops.aten.view.default(view_default_243, [128, 512]);  view_default_243 = None
        view_default_245 = torch.ops.aten.view.default(view_default_244, [128, 2, 1, 256]);  view_default_244 = None
        _softmax_backward_data_default_15 = torch.ops.aten._softmax_backward_data.default(view_default_245, _softmax_default_17, 1, torch.float32);  view_default_245 = _softmax_default_17 = None
        transpose_int_48 = torch.ops.aten.transpose.int(_softmax_backward_data_default_15, 1, 2);  _softmax_backward_data_default_15 = None
        view_default_246 = torch.ops.aten.view.default(transpose_int_48, [128, 512, 1, 1]);  transpose_int_48 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(view_default_246, relu__default_73, primals_280, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_246 = primals_280 = None
        getitem_836 = convolution_backward_default_77[0]
        getitem_837 = convolution_backward_default_77[1]
        getitem_838 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_836, torch.float32);  getitem_836 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_200, to_dtype_183);  le_scalar_61 = new_zeros_default_200 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_93, primals_275, primals_273, primals_274, getitem_231, getitem_232, True, 1e-05, [True, True, True]);  to_dtype_185 = convolution_default_93 = primals_275 = primals_273 = primals_274 = getitem_231 = getitem_232 = None
        getitem_839 = native_batch_norm_backward_default_62[0]
        getitem_840 = native_batch_norm_backward_default_62[1]
        getitem_841 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_839, mean_dim_17, primals_278, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_839 = mean_dim_17 = primals_278 = None
        getitem_842 = convolution_backward_default_78[0]
        getitem_843 = convolution_backward_default_78[1]
        getitem_844 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        expand_default_47 = torch.ops.aten.expand.default(getitem_842, [128, 256, 16, 16]);  getitem_842 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_47, 256);  expand_default_47 = None
        unsqueeze_default_31 = torch.ops.aten.unsqueeze.default(div_scalar_16, 1);  div_scalar_16 = None
        expand_default_48 = torch.ops.aten.expand.default(unsqueeze_default_31, [128, 2, 256, 16, 16]);  unsqueeze_default_31 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_64, expand_default_48);  mul_tensor_64 = expand_default_48 = None
        view_default_247 = torch.ops.aten.view.default(add_tensor_30, [128, 512, 16, 16]);  add_tensor_30 = None
        to_dtype_186 = torch.ops.aten.to.dtype(view_default_247, torch.float32);  view_default_247 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_201, to_dtype_186);  le_scalar_62 = new_zeros_default_201 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_92, primals_270, primals_268, primals_269, getitem_228, getitem_229, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_92 = primals_270 = primals_268 = primals_269 = getitem_228 = getitem_229 = None
        getitem_845 = native_batch_norm_backward_default_63[0]
        getitem_846 = native_batch_norm_backward_default_63[1]
        getitem_847 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_845, relu__default_71, primals_276, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_845 = primals_276 = None
        getitem_848 = convolution_backward_default_79[0]
        getitem_849 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_848, torch.float32);  getitem_848 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_202, to_dtype_189);  le_scalar_63 = new_zeros_default_202 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_91, primals_259, primals_257, primals_258, getitem_225, getitem_226, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_91 = primals_259 = primals_257 = primals_258 = getitem_225 = getitem_226 = None
        getitem_851 = native_batch_norm_backward_default_64[0]
        getitem_852 = native_batch_norm_backward_default_64[1]
        getitem_853 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_851, relu__default_70, primals_265, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_851 = primals_265 = None
        getitem_854 = convolution_backward_default_80[0]
        getitem_855 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(to_dtype_182, getitem_854);  to_dtype_182 = getitem_854 = None
        to_dtype_192 = torch.ops.aten.to.dtype(add_tensor_31, torch.float32);  add_tensor_31 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_203, to_dtype_192);  le_scalar_64 = new_zeros_default_203 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_90, primals_831, primals_829, primals_830, getitem_222, getitem_223, True, 1e-05, [True, True, True]);  convolution_default_90 = primals_831 = primals_829 = primals_830 = getitem_222 = getitem_223 = None
        getitem_857 = native_batch_norm_backward_default_65[0]
        getitem_858 = native_batch_norm_backward_default_65[1]
        getitem_859 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_857, sum_dim_int_list_33, primals_848, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_857 = sum_dim_int_list_33 = primals_848 = None
        getitem_860 = convolution_backward_default_81[0]
        getitem_861 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        unsqueeze_default_32 = torch.ops.aten.unsqueeze.default(getitem_860, 1);  getitem_860 = None
        expand_default_49 = torch.ops.aten.expand.default(unsqueeze_default_32, [128, 2, 256, 16, 16]);  unsqueeze_default_32 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(expand_default_49, view_default_80);  view_default_80 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(expand_default_49, view_default_84);  expand_default_49 = view_default_84 = None
        sum_dim_int_list_83 = torch.ops.aten.sum.dim_IntList(mul_tensor_65, [3, 4], True);  mul_tensor_65 = None
        view_default_248 = torch.ops.aten.view.default(sum_dim_int_list_83, [128, 512, 1, 1]);  sum_dim_int_list_83 = None
        view_default_249 = torch.ops.aten.view.default(view_default_248, [128, 512]);  view_default_248 = None
        view_default_250 = torch.ops.aten.view.default(view_default_249, [128, 2, 1, 256]);  view_default_249 = None
        _softmax_backward_data_default_16 = torch.ops.aten._softmax_backward_data.default(view_default_250, _softmax_default_16, 1, torch.float32);  view_default_250 = _softmax_default_16 = None
        transpose_int_49 = torch.ops.aten.transpose.int(_softmax_backward_data_default_16, 1, 2);  _softmax_backward_data_default_16 = None
        view_default_251 = torch.ops.aten.view.default(transpose_int_49, [128, 512, 1, 1]);  transpose_int_49 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(view_default_251, relu__default_69, primals_847, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_251 = primals_847 = None
        getitem_863 = convolution_backward_default_82[0]
        getitem_864 = convolution_backward_default_82[1]
        getitem_865 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        to_dtype_195 = torch.ops.aten.to.dtype(getitem_863, torch.float32);  getitem_863 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_204, to_dtype_195);  le_scalar_65 = new_zeros_default_204 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_88, primals_842, primals_840, primals_841, getitem_219, getitem_220, True, 1e-05, [True, True, True]);  to_dtype_197 = convolution_default_88 = primals_842 = primals_840 = primals_841 = getitem_219 = getitem_220 = None
        getitem_866 = native_batch_norm_backward_default_66[0]
        getitem_867 = native_batch_norm_backward_default_66[1]
        getitem_868 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_866, mean_dim_16, primals_845, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_866 = mean_dim_16 = primals_845 = None
        getitem_869 = convolution_backward_default_83[0]
        getitem_870 = convolution_backward_default_83[1]
        getitem_871 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        expand_default_50 = torch.ops.aten.expand.default(getitem_869, [128, 256, 16, 16]);  getitem_869 = None
        div_scalar_17 = torch.ops.aten.div.Scalar(expand_default_50, 256);  expand_default_50 = None
        unsqueeze_default_33 = torch.ops.aten.unsqueeze.default(div_scalar_17, 1);  div_scalar_17 = None
        expand_default_51 = torch.ops.aten.expand.default(unsqueeze_default_33, [128, 2, 256, 16, 16]);  unsqueeze_default_33 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_66, expand_default_51);  mul_tensor_66 = expand_default_51 = None
        view_default_252 = torch.ops.aten.view.default(add_tensor_32, [128, 512, 16, 16]);  add_tensor_32 = None
        to_dtype_198 = torch.ops.aten.to.dtype(view_default_252, torch.float32);  view_default_252 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_205, to_dtype_198);  le_scalar_66 = new_zeros_default_205 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_87, primals_837, primals_835, primals_836, getitem_216, getitem_217, True, 1e-05, [True, True, True]);  to_dtype_200 = convolution_default_87 = primals_837 = primals_835 = primals_836 = getitem_216 = getitem_217 = None
        getitem_872 = native_batch_norm_backward_default_67[0]
        getitem_873 = native_batch_norm_backward_default_67[1]
        getitem_874 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_872, relu__default_67, primals_843, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_872 = primals_843 = None
        getitem_875 = convolution_backward_default_84[0]
        getitem_876 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_875, torch.float32);  getitem_875 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_206, to_dtype_201);  le_scalar_67 = new_zeros_default_206 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_86, primals_826, primals_824, primals_825, getitem_213, getitem_214, True, 1e-05, [True, True, True]);  to_dtype_203 = convolution_default_86 = primals_826 = primals_824 = primals_825 = getitem_213 = getitem_214 = None
        getitem_878 = native_batch_norm_backward_default_68[0]
        getitem_879 = native_batch_norm_backward_default_68[1]
        getitem_880 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_878, relu__default_66, primals_832, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_878 = primals_832 = None
        getitem_881 = convolution_backward_default_85[0]
        getitem_882 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(to_dtype_194, getitem_881);  to_dtype_194 = getitem_881 = None
        to_dtype_204 = torch.ops.aten.to.dtype(add_tensor_33, torch.float32);  add_tensor_33 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_207, to_dtype_204);  le_scalar_68 = new_zeros_default_207 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_85, primals_804, primals_802, primals_803, getitem_210, getitem_211, True, 1e-05, [True, True, True]);  convolution_default_85 = primals_804 = primals_802 = primals_803 = getitem_210 = getitem_211 = None
        getitem_884 = native_batch_norm_backward_default_69[0]
        getitem_885 = native_batch_norm_backward_default_69[1]
        getitem_886 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_884, sum_dim_int_list_31, primals_821, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_884 = sum_dim_int_list_31 = primals_821 = None
        getitem_887 = convolution_backward_default_86[0]
        getitem_888 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        unsqueeze_default_34 = torch.ops.aten.unsqueeze.default(getitem_887, 1);  getitem_887 = None
        expand_default_52 = torch.ops.aten.expand.default(unsqueeze_default_34, [128, 2, 256, 16, 16]);  unsqueeze_default_34 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(expand_default_52, view_default_75);  view_default_75 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(expand_default_52, view_default_79);  expand_default_52 = view_default_79 = None
        sum_dim_int_list_84 = torch.ops.aten.sum.dim_IntList(mul_tensor_67, [3, 4], True);  mul_tensor_67 = None
        view_default_253 = torch.ops.aten.view.default(sum_dim_int_list_84, [128, 512, 1, 1]);  sum_dim_int_list_84 = None
        view_default_254 = torch.ops.aten.view.default(view_default_253, [128, 512]);  view_default_253 = None
        view_default_255 = torch.ops.aten.view.default(view_default_254, [128, 2, 1, 256]);  view_default_254 = None
        _softmax_backward_data_default_17 = torch.ops.aten._softmax_backward_data.default(view_default_255, _softmax_default_15, 1, torch.float32);  view_default_255 = _softmax_default_15 = None
        transpose_int_50 = torch.ops.aten.transpose.int(_softmax_backward_data_default_17, 1, 2);  _softmax_backward_data_default_17 = None
        view_default_256 = torch.ops.aten.view.default(transpose_int_50, [128, 512, 1, 1]);  transpose_int_50 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(view_default_256, relu__default_65, primals_820, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_256 = primals_820 = None
        getitem_890 = convolution_backward_default_87[0]
        getitem_891 = convolution_backward_default_87[1]
        getitem_892 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_890, torch.float32);  getitem_890 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_208, to_dtype_207);  le_scalar_69 = new_zeros_default_208 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_83, primals_815, primals_813, primals_814, getitem_207, getitem_208, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_83 = primals_815 = primals_813 = primals_814 = getitem_207 = getitem_208 = None
        getitem_893 = native_batch_norm_backward_default_70[0]
        getitem_894 = native_batch_norm_backward_default_70[1]
        getitem_895 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_893, mean_dim_15, primals_818, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_893 = mean_dim_15 = primals_818 = None
        getitem_896 = convolution_backward_default_88[0]
        getitem_897 = convolution_backward_default_88[1]
        getitem_898 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        expand_default_53 = torch.ops.aten.expand.default(getitem_896, [128, 256, 16, 16]);  getitem_896 = None
        div_scalar_18 = torch.ops.aten.div.Scalar(expand_default_53, 256);  expand_default_53 = None
        unsqueeze_default_35 = torch.ops.aten.unsqueeze.default(div_scalar_18, 1);  div_scalar_18 = None
        expand_default_54 = torch.ops.aten.expand.default(unsqueeze_default_35, [128, 2, 256, 16, 16]);  unsqueeze_default_35 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(mul_tensor_68, expand_default_54);  mul_tensor_68 = expand_default_54 = None
        view_default_257 = torch.ops.aten.view.default(add_tensor_34, [128, 512, 16, 16]);  add_tensor_34 = None
        to_dtype_210 = torch.ops.aten.to.dtype(view_default_257, torch.float32);  view_default_257 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_209, to_dtype_210);  le_scalar_70 = new_zeros_default_209 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_82, primals_810, primals_808, primals_809, getitem_204, getitem_205, True, 1e-05, [True, True, True]);  to_dtype_212 = convolution_default_82 = primals_810 = primals_808 = primals_809 = getitem_204 = getitem_205 = None
        getitem_899 = native_batch_norm_backward_default_71[0]
        getitem_900 = native_batch_norm_backward_default_71[1]
        getitem_901 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_899, relu__default_63, primals_816, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_899 = primals_816 = None
        getitem_902 = convolution_backward_default_89[0]
        getitem_903 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_902, torch.float32);  getitem_902 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_210, to_dtype_213);  le_scalar_71 = new_zeros_default_210 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_81, primals_799, primals_797, primals_798, getitem_201, getitem_202, True, 1e-05, [True, True, True]);  to_dtype_215 = convolution_default_81 = primals_799 = primals_797 = primals_798 = getitem_201 = getitem_202 = None
        getitem_905 = native_batch_norm_backward_default_72[0]
        getitem_906 = native_batch_norm_backward_default_72[1]
        getitem_907 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_905, relu__default_62, primals_805, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_905 = primals_805 = None
        getitem_908 = convolution_backward_default_90[0]
        getitem_909 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(to_dtype_206, getitem_908);  to_dtype_206 = getitem_908 = None
        to_dtype_216 = torch.ops.aten.to.dtype(add_tensor_35, torch.float32);  add_tensor_35 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_211, to_dtype_216);  le_scalar_72 = new_zeros_default_211 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_80, primals_777, primals_775, primals_776, getitem_198, getitem_199, True, 1e-05, [True, True, True]);  convolution_default_80 = primals_777 = primals_775 = primals_776 = getitem_198 = getitem_199 = None
        getitem_911 = native_batch_norm_backward_default_73[0]
        getitem_912 = native_batch_norm_backward_default_73[1]
        getitem_913 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_911, sum_dim_int_list_29, primals_794, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_911 = sum_dim_int_list_29 = primals_794 = None
        getitem_914 = convolution_backward_default_91[0]
        getitem_915 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        unsqueeze_default_36 = torch.ops.aten.unsqueeze.default(getitem_914, 1);  getitem_914 = None
        expand_default_55 = torch.ops.aten.expand.default(unsqueeze_default_36, [128, 2, 256, 16, 16]);  unsqueeze_default_36 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(expand_default_55, view_default_70);  view_default_70 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(expand_default_55, view_default_74);  expand_default_55 = view_default_74 = None
        sum_dim_int_list_85 = torch.ops.aten.sum.dim_IntList(mul_tensor_69, [3, 4], True);  mul_tensor_69 = None
        view_default_258 = torch.ops.aten.view.default(sum_dim_int_list_85, [128, 512, 1, 1]);  sum_dim_int_list_85 = None
        view_default_259 = torch.ops.aten.view.default(view_default_258, [128, 512]);  view_default_258 = None
        view_default_260 = torch.ops.aten.view.default(view_default_259, [128, 2, 1, 256]);  view_default_259 = None
        _softmax_backward_data_default_18 = torch.ops.aten._softmax_backward_data.default(view_default_260, _softmax_default_14, 1, torch.float32);  view_default_260 = _softmax_default_14 = None
        transpose_int_51 = torch.ops.aten.transpose.int(_softmax_backward_data_default_18, 1, 2);  _softmax_backward_data_default_18 = None
        view_default_261 = torch.ops.aten.view.default(transpose_int_51, [128, 512, 1, 1]);  transpose_int_51 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(view_default_261, relu__default_61, primals_793, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_261 = primals_793 = None
        getitem_917 = convolution_backward_default_92[0]
        getitem_918 = convolution_backward_default_92[1]
        getitem_919 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_917, torch.float32);  getitem_917 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_212, to_dtype_219);  le_scalar_73 = new_zeros_default_212 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_78, primals_788, primals_786, primals_787, getitem_195, getitem_196, True, 1e-05, [True, True, True]);  to_dtype_221 = convolution_default_78 = primals_788 = primals_786 = primals_787 = getitem_195 = getitem_196 = None
        getitem_920 = native_batch_norm_backward_default_74[0]
        getitem_921 = native_batch_norm_backward_default_74[1]
        getitem_922 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_920, mean_dim_14, primals_791, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_920 = mean_dim_14 = primals_791 = None
        getitem_923 = convolution_backward_default_93[0]
        getitem_924 = convolution_backward_default_93[1]
        getitem_925 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        expand_default_56 = torch.ops.aten.expand.default(getitem_923, [128, 256, 16, 16]);  getitem_923 = None
        div_scalar_19 = torch.ops.aten.div.Scalar(expand_default_56, 256);  expand_default_56 = None
        unsqueeze_default_37 = torch.ops.aten.unsqueeze.default(div_scalar_19, 1);  div_scalar_19 = None
        expand_default_57 = torch.ops.aten.expand.default(unsqueeze_default_37, [128, 2, 256, 16, 16]);  unsqueeze_default_37 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(mul_tensor_70, expand_default_57);  mul_tensor_70 = expand_default_57 = None
        view_default_262 = torch.ops.aten.view.default(add_tensor_36, [128, 512, 16, 16]);  add_tensor_36 = None
        to_dtype_222 = torch.ops.aten.to.dtype(view_default_262, torch.float32);  view_default_262 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_213, to_dtype_222);  le_scalar_74 = new_zeros_default_213 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_77, primals_783, primals_781, primals_782, getitem_192, getitem_193, True, 1e-05, [True, True, True]);  to_dtype_224 = convolution_default_77 = primals_783 = primals_781 = primals_782 = getitem_192 = getitem_193 = None
        getitem_926 = native_batch_norm_backward_default_75[0]
        getitem_927 = native_batch_norm_backward_default_75[1]
        getitem_928 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_926, relu__default_59, primals_789, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_926 = primals_789 = None
        getitem_929 = convolution_backward_default_94[0]
        getitem_930 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        to_dtype_225 = torch.ops.aten.to.dtype(getitem_929, torch.float32);  getitem_929 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_214, to_dtype_225);  le_scalar_75 = new_zeros_default_214 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_76, primals_772, primals_770, primals_771, getitem_189, getitem_190, True, 1e-05, [True, True, True]);  to_dtype_227 = convolution_default_76 = primals_772 = primals_770 = primals_771 = getitem_189 = getitem_190 = None
        getitem_932 = native_batch_norm_backward_default_76[0]
        getitem_933 = native_batch_norm_backward_default_76[1]
        getitem_934 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_932, relu__default_58, primals_778, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_932 = primals_778 = None
        getitem_935 = convolution_backward_default_95[0]
        getitem_936 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(to_dtype_218, getitem_935);  to_dtype_218 = getitem_935 = None
        to_dtype_228 = torch.ops.aten.to.dtype(add_tensor_37, torch.float32);  add_tensor_37 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_215, to_dtype_228);  le_scalar_76 = new_zeros_default_215 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_75, primals_750, primals_748, primals_749, getitem_186, getitem_187, True, 1e-05, [True, True, True]);  convolution_default_75 = primals_750 = primals_748 = primals_749 = getitem_186 = getitem_187 = None
        getitem_938 = native_batch_norm_backward_default_77[0]
        getitem_939 = native_batch_norm_backward_default_77[1]
        getitem_940 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_938, sum_dim_int_list_27, primals_767, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_938 = sum_dim_int_list_27 = primals_767 = None
        getitem_941 = convolution_backward_default_96[0]
        getitem_942 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        unsqueeze_default_38 = torch.ops.aten.unsqueeze.default(getitem_941, 1);  getitem_941 = None
        expand_default_58 = torch.ops.aten.expand.default(unsqueeze_default_38, [128, 2, 256, 16, 16]);  unsqueeze_default_38 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(expand_default_58, view_default_65);  view_default_65 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(expand_default_58, view_default_69);  expand_default_58 = view_default_69 = None
        sum_dim_int_list_86 = torch.ops.aten.sum.dim_IntList(mul_tensor_71, [3, 4], True);  mul_tensor_71 = None
        view_default_263 = torch.ops.aten.view.default(sum_dim_int_list_86, [128, 512, 1, 1]);  sum_dim_int_list_86 = None
        view_default_264 = torch.ops.aten.view.default(view_default_263, [128, 512]);  view_default_263 = None
        view_default_265 = torch.ops.aten.view.default(view_default_264, [128, 2, 1, 256]);  view_default_264 = None
        _softmax_backward_data_default_19 = torch.ops.aten._softmax_backward_data.default(view_default_265, _softmax_default_13, 1, torch.float32);  view_default_265 = _softmax_default_13 = None
        transpose_int_52 = torch.ops.aten.transpose.int(_softmax_backward_data_default_19, 1, 2);  _softmax_backward_data_default_19 = None
        view_default_266 = torch.ops.aten.view.default(transpose_int_52, [128, 512, 1, 1]);  transpose_int_52 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(view_default_266, relu__default_57, primals_766, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_266 = primals_766 = None
        getitem_944 = convolution_backward_default_97[0]
        getitem_945 = convolution_backward_default_97[1]
        getitem_946 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_944, torch.float32);  getitem_944 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_216, to_dtype_231);  le_scalar_77 = new_zeros_default_216 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_73, primals_761, primals_759, primals_760, getitem_183, getitem_184, True, 1e-05, [True, True, True]);  to_dtype_233 = convolution_default_73 = primals_761 = primals_759 = primals_760 = getitem_183 = getitem_184 = None
        getitem_947 = native_batch_norm_backward_default_78[0]
        getitem_948 = native_batch_norm_backward_default_78[1]
        getitem_949 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_947, mean_dim_13, primals_764, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_947 = mean_dim_13 = primals_764 = None
        getitem_950 = convolution_backward_default_98[0]
        getitem_951 = convolution_backward_default_98[1]
        getitem_952 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        expand_default_59 = torch.ops.aten.expand.default(getitem_950, [128, 256, 16, 16]);  getitem_950 = None
        div_scalar_20 = torch.ops.aten.div.Scalar(expand_default_59, 256);  expand_default_59 = None
        unsqueeze_default_39 = torch.ops.aten.unsqueeze.default(div_scalar_20, 1);  div_scalar_20 = None
        expand_default_60 = torch.ops.aten.expand.default(unsqueeze_default_39, [128, 2, 256, 16, 16]);  unsqueeze_default_39 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_72, expand_default_60);  mul_tensor_72 = expand_default_60 = None
        view_default_267 = torch.ops.aten.view.default(add_tensor_38, [128, 512, 16, 16]);  add_tensor_38 = None
        to_dtype_234 = torch.ops.aten.to.dtype(view_default_267, torch.float32);  view_default_267 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_217, to_dtype_234);  le_scalar_78 = new_zeros_default_217 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_72, primals_756, primals_754, primals_755, getitem_180, getitem_181, True, 1e-05, [True, True, True]);  to_dtype_236 = convolution_default_72 = primals_756 = primals_754 = primals_755 = getitem_180 = getitem_181 = None
        getitem_953 = native_batch_norm_backward_default_79[0]
        getitem_954 = native_batch_norm_backward_default_79[1]
        getitem_955 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_953, relu__default_55, primals_762, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_953 = primals_762 = None
        getitem_956 = convolution_backward_default_99[0]
        getitem_957 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_956, torch.float32);  getitem_956 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_218, to_dtype_237);  le_scalar_79 = new_zeros_default_218 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_71, primals_745, primals_743, primals_744, getitem_177, getitem_178, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_71 = primals_745 = primals_743 = primals_744 = getitem_177 = getitem_178 = None
        getitem_959 = native_batch_norm_backward_default_80[0]
        getitem_960 = native_batch_norm_backward_default_80[1]
        getitem_961 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_959, relu__default_54, primals_751, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_959 = primals_751 = None
        getitem_962 = convolution_backward_default_100[0]
        getitem_963 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(to_dtype_230, getitem_962);  to_dtype_230 = getitem_962 = None
        to_dtype_240 = torch.ops.aten.to.dtype(add_tensor_39, torch.float32);  add_tensor_39 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_219, to_dtype_240);  le_scalar_80 = new_zeros_default_219 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_70, primals_723, primals_721, primals_722, getitem_174, getitem_175, True, 1e-05, [True, True, True]);  convolution_default_70 = primals_723 = primals_721 = primals_722 = getitem_174 = getitem_175 = None
        getitem_965 = native_batch_norm_backward_default_81[0]
        getitem_966 = native_batch_norm_backward_default_81[1]
        getitem_967 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_965, sum_dim_int_list_25, primals_740, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_965 = sum_dim_int_list_25 = primals_740 = None
        getitem_968 = convolution_backward_default_101[0]
        getitem_969 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        unsqueeze_default_40 = torch.ops.aten.unsqueeze.default(getitem_968, 1);  getitem_968 = None
        expand_default_61 = torch.ops.aten.expand.default(unsqueeze_default_40, [128, 2, 256, 16, 16]);  unsqueeze_default_40 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(expand_default_61, view_default_60);  view_default_60 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(expand_default_61, view_default_64);  expand_default_61 = view_default_64 = None
        sum_dim_int_list_87 = torch.ops.aten.sum.dim_IntList(mul_tensor_73, [3, 4], True);  mul_tensor_73 = None
        view_default_268 = torch.ops.aten.view.default(sum_dim_int_list_87, [128, 512, 1, 1]);  sum_dim_int_list_87 = None
        view_default_269 = torch.ops.aten.view.default(view_default_268, [128, 512]);  view_default_268 = None
        view_default_270 = torch.ops.aten.view.default(view_default_269, [128, 2, 1, 256]);  view_default_269 = None
        _softmax_backward_data_default_20 = torch.ops.aten._softmax_backward_data.default(view_default_270, _softmax_default_12, 1, torch.float32);  view_default_270 = _softmax_default_12 = None
        transpose_int_53 = torch.ops.aten.transpose.int(_softmax_backward_data_default_20, 1, 2);  _softmax_backward_data_default_20 = None
        view_default_271 = torch.ops.aten.view.default(transpose_int_53, [128, 512, 1, 1]);  transpose_int_53 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(view_default_271, relu__default_53, primals_739, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_271 = primals_739 = None
        getitem_971 = convolution_backward_default_102[0]
        getitem_972 = convolution_backward_default_102[1]
        getitem_973 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        to_dtype_243 = torch.ops.aten.to.dtype(getitem_971, torch.float32);  getitem_971 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_220, to_dtype_243);  le_scalar_81 = new_zeros_default_220 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_245, convolution_default_68, primals_734, primals_732, primals_733, getitem_171, getitem_172, True, 1e-05, [True, True, True]);  to_dtype_245 = convolution_default_68 = primals_734 = primals_732 = primals_733 = getitem_171 = getitem_172 = None
        getitem_974 = native_batch_norm_backward_default_82[0]
        getitem_975 = native_batch_norm_backward_default_82[1]
        getitem_976 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_974, mean_dim_12, primals_737, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_974 = mean_dim_12 = primals_737 = None
        getitem_977 = convolution_backward_default_103[0]
        getitem_978 = convolution_backward_default_103[1]
        getitem_979 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        expand_default_62 = torch.ops.aten.expand.default(getitem_977, [128, 256, 16, 16]);  getitem_977 = None
        div_scalar_21 = torch.ops.aten.div.Scalar(expand_default_62, 256);  expand_default_62 = None
        unsqueeze_default_41 = torch.ops.aten.unsqueeze.default(div_scalar_21, 1);  div_scalar_21 = None
        expand_default_63 = torch.ops.aten.expand.default(unsqueeze_default_41, [128, 2, 256, 16, 16]);  unsqueeze_default_41 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(mul_tensor_74, expand_default_63);  mul_tensor_74 = expand_default_63 = None
        view_default_272 = torch.ops.aten.view.default(add_tensor_40, [128, 512, 16, 16]);  add_tensor_40 = None
        to_dtype_246 = torch.ops.aten.to.dtype(view_default_272, torch.float32);  view_default_272 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_221, to_dtype_246);  le_scalar_82 = new_zeros_default_221 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_67, primals_729, primals_727, primals_728, getitem_168, getitem_169, True, 1e-05, [True, True, True]);  to_dtype_248 = convolution_default_67 = primals_729 = primals_727 = primals_728 = getitem_168 = getitem_169 = None
        getitem_980 = native_batch_norm_backward_default_83[0]
        getitem_981 = native_batch_norm_backward_default_83[1]
        getitem_982 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_980, relu__default_51, primals_735, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_980 = primals_735 = None
        getitem_983 = convolution_backward_default_104[0]
        getitem_984 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_983, torch.float32);  getitem_983 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_222, to_dtype_249);  le_scalar_83 = new_zeros_default_222 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_66, primals_718, primals_716, primals_717, getitem_165, getitem_166, True, 1e-05, [True, True, True]);  to_dtype_251 = convolution_default_66 = primals_718 = primals_716 = primals_717 = getitem_165 = getitem_166 = None
        getitem_986 = native_batch_norm_backward_default_84[0]
        getitem_987 = native_batch_norm_backward_default_84[1]
        getitem_988 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_986, relu__default_50, primals_724, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_986 = primals_724 = None
        getitem_989 = convolution_backward_default_105[0]
        getitem_990 = convolution_backward_default_105[1];  convolution_backward_default_105 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(to_dtype_242, getitem_989);  to_dtype_242 = getitem_989 = None
        to_dtype_252 = torch.ops.aten.to.dtype(add_tensor_41, torch.float32);  add_tensor_41 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_223, to_dtype_252);  le_scalar_84 = new_zeros_default_223 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_65, primals_696, primals_694, primals_695, getitem_162, getitem_163, True, 1e-05, [True, True, True]);  convolution_default_65 = primals_696 = primals_694 = primals_695 = getitem_162 = getitem_163 = None
        getitem_992 = native_batch_norm_backward_default_85[0]
        getitem_993 = native_batch_norm_backward_default_85[1]
        getitem_994 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_992, sum_dim_int_list_23, primals_713, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_992 = sum_dim_int_list_23 = primals_713 = None
        getitem_995 = convolution_backward_default_106[0]
        getitem_996 = convolution_backward_default_106[1];  convolution_backward_default_106 = None
        unsqueeze_default_42 = torch.ops.aten.unsqueeze.default(getitem_995, 1);  getitem_995 = None
        expand_default_64 = torch.ops.aten.expand.default(unsqueeze_default_42, [128, 2, 256, 16, 16]);  unsqueeze_default_42 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(expand_default_64, view_default_55);  view_default_55 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(expand_default_64, view_default_59);  expand_default_64 = view_default_59 = None
        sum_dim_int_list_88 = torch.ops.aten.sum.dim_IntList(mul_tensor_75, [3, 4], True);  mul_tensor_75 = None
        view_default_273 = torch.ops.aten.view.default(sum_dim_int_list_88, [128, 512, 1, 1]);  sum_dim_int_list_88 = None
        view_default_274 = torch.ops.aten.view.default(view_default_273, [128, 512]);  view_default_273 = None
        view_default_275 = torch.ops.aten.view.default(view_default_274, [128, 2, 1, 256]);  view_default_274 = None
        _softmax_backward_data_default_21 = torch.ops.aten._softmax_backward_data.default(view_default_275, _softmax_default_11, 1, torch.float32);  view_default_275 = _softmax_default_11 = None
        transpose_int_54 = torch.ops.aten.transpose.int(_softmax_backward_data_default_21, 1, 2);  _softmax_backward_data_default_21 = None
        view_default_276 = torch.ops.aten.view.default(transpose_int_54, [128, 512, 1, 1]);  transpose_int_54 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(view_default_276, relu__default_49, primals_712, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_276 = primals_712 = None
        getitem_998 = convolution_backward_default_107[0]
        getitem_999 = convolution_backward_default_107[1]
        getitem_1000 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        to_dtype_255 = torch.ops.aten.to.dtype(getitem_998, torch.float32);  getitem_998 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_224, to_dtype_255);  le_scalar_85 = new_zeros_default_224 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_257, convolution_default_63, primals_707, primals_705, primals_706, getitem_159, getitem_160, True, 1e-05, [True, True, True]);  to_dtype_257 = convolution_default_63 = primals_707 = primals_705 = primals_706 = getitem_159 = getitem_160 = None
        getitem_1001 = native_batch_norm_backward_default_86[0]
        getitem_1002 = native_batch_norm_backward_default_86[1]
        getitem_1003 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1001, mean_dim_11, primals_710, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1001 = mean_dim_11 = primals_710 = None
        getitem_1004 = convolution_backward_default_108[0]
        getitem_1005 = convolution_backward_default_108[1]
        getitem_1006 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        expand_default_65 = torch.ops.aten.expand.default(getitem_1004, [128, 256, 16, 16]);  getitem_1004 = None
        div_scalar_22 = torch.ops.aten.div.Scalar(expand_default_65, 256);  expand_default_65 = None
        unsqueeze_default_43 = torch.ops.aten.unsqueeze.default(div_scalar_22, 1);  div_scalar_22 = None
        expand_default_66 = torch.ops.aten.expand.default(unsqueeze_default_43, [128, 2, 256, 16, 16]);  unsqueeze_default_43 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(mul_tensor_76, expand_default_66);  mul_tensor_76 = expand_default_66 = None
        view_default_277 = torch.ops.aten.view.default(add_tensor_42, [128, 512, 16, 16]);  add_tensor_42 = None
        to_dtype_258 = torch.ops.aten.to.dtype(view_default_277, torch.float32);  view_default_277 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_225, to_dtype_258);  le_scalar_86 = new_zeros_default_225 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_62, primals_702, primals_700, primals_701, getitem_156, getitem_157, True, 1e-05, [True, True, True]);  to_dtype_260 = convolution_default_62 = primals_702 = primals_700 = primals_701 = getitem_156 = getitem_157 = None
        getitem_1007 = native_batch_norm_backward_default_87[0]
        getitem_1008 = native_batch_norm_backward_default_87[1]
        getitem_1009 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1007, relu__default_47, primals_708, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1007 = primals_708 = None
        getitem_1010 = convolution_backward_default_109[0]
        getitem_1011 = convolution_backward_default_109[1];  convolution_backward_default_109 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_1010, torch.float32);  getitem_1010 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_226, to_dtype_261);  le_scalar_87 = new_zeros_default_226 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_61, primals_691, primals_689, primals_690, getitem_153, getitem_154, True, 1e-05, [True, True, True]);  to_dtype_263 = convolution_default_61 = primals_691 = primals_689 = primals_690 = getitem_153 = getitem_154 = None
        getitem_1013 = native_batch_norm_backward_default_88[0]
        getitem_1014 = native_batch_norm_backward_default_88[1]
        getitem_1015 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1013, relu__default_46, primals_697, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1013 = primals_697 = None
        getitem_1016 = convolution_backward_default_110[0]
        getitem_1017 = convolution_backward_default_110[1];  convolution_backward_default_110 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(to_dtype_254, getitem_1016);  to_dtype_254 = getitem_1016 = None
        to_dtype_264 = torch.ops.aten.to.dtype(add_tensor_43, torch.float32);  add_tensor_43 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_227, to_dtype_264);  le_scalar_88 = new_zeros_default_227 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_60, primals_669, primals_667, primals_668, getitem_150, getitem_151, True, 1e-05, [True, True, True]);  convolution_default_60 = primals_669 = primals_667 = primals_668 = getitem_150 = getitem_151 = None
        getitem_1019 = native_batch_norm_backward_default_89[0]
        getitem_1020 = native_batch_norm_backward_default_89[1]
        getitem_1021 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1019, sum_dim_int_list_21, primals_686, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1019 = sum_dim_int_list_21 = primals_686 = None
        getitem_1022 = convolution_backward_default_111[0]
        getitem_1023 = convolution_backward_default_111[1];  convolution_backward_default_111 = None
        unsqueeze_default_44 = torch.ops.aten.unsqueeze.default(getitem_1022, 1);  getitem_1022 = None
        expand_default_67 = torch.ops.aten.expand.default(unsqueeze_default_44, [128, 2, 256, 16, 16]);  unsqueeze_default_44 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(expand_default_67, view_default_50);  view_default_50 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(expand_default_67, view_default_54);  expand_default_67 = view_default_54 = None
        sum_dim_int_list_89 = torch.ops.aten.sum.dim_IntList(mul_tensor_77, [3, 4], True);  mul_tensor_77 = None
        view_default_278 = torch.ops.aten.view.default(sum_dim_int_list_89, [128, 512, 1, 1]);  sum_dim_int_list_89 = None
        view_default_279 = torch.ops.aten.view.default(view_default_278, [128, 512]);  view_default_278 = None
        view_default_280 = torch.ops.aten.view.default(view_default_279, [128, 2, 1, 256]);  view_default_279 = None
        _softmax_backward_data_default_22 = torch.ops.aten._softmax_backward_data.default(view_default_280, _softmax_default_10, 1, torch.float32);  view_default_280 = _softmax_default_10 = None
        transpose_int_55 = torch.ops.aten.transpose.int(_softmax_backward_data_default_22, 1, 2);  _softmax_backward_data_default_22 = None
        view_default_281 = torch.ops.aten.view.default(transpose_int_55, [128, 512, 1, 1]);  transpose_int_55 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(view_default_281, relu__default_45, primals_685, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_281 = primals_685 = None
        getitem_1025 = convolution_backward_default_112[0]
        getitem_1026 = convolution_backward_default_112[1]
        getitem_1027 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_1025, torch.float32);  getitem_1025 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_228, to_dtype_267);  le_scalar_89 = new_zeros_default_228 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_58, primals_680, primals_678, primals_679, getitem_147, getitem_148, True, 1e-05, [True, True, True]);  to_dtype_269 = convolution_default_58 = primals_680 = primals_678 = primals_679 = getitem_147 = getitem_148 = None
        getitem_1028 = native_batch_norm_backward_default_90[0]
        getitem_1029 = native_batch_norm_backward_default_90[1]
        getitem_1030 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1028, mean_dim_10, primals_683, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1028 = mean_dim_10 = primals_683 = None
        getitem_1031 = convolution_backward_default_113[0]
        getitem_1032 = convolution_backward_default_113[1]
        getitem_1033 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        expand_default_68 = torch.ops.aten.expand.default(getitem_1031, [128, 256, 16, 16]);  getitem_1031 = None
        div_scalar_23 = torch.ops.aten.div.Scalar(expand_default_68, 256);  expand_default_68 = None
        unsqueeze_default_45 = torch.ops.aten.unsqueeze.default(div_scalar_23, 1);  div_scalar_23 = None
        expand_default_69 = torch.ops.aten.expand.default(unsqueeze_default_45, [128, 2, 256, 16, 16]);  unsqueeze_default_45 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(mul_tensor_78, expand_default_69);  mul_tensor_78 = expand_default_69 = None
        view_default_282 = torch.ops.aten.view.default(add_tensor_44, [128, 512, 16, 16]);  add_tensor_44 = None
        to_dtype_270 = torch.ops.aten.to.dtype(view_default_282, torch.float32);  view_default_282 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_229, to_dtype_270);  le_scalar_90 = new_zeros_default_229 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_57, primals_675, primals_673, primals_674, getitem_144, getitem_145, True, 1e-05, [True, True, True]);  to_dtype_272 = convolution_default_57 = primals_675 = primals_673 = primals_674 = getitem_144 = getitem_145 = None
        getitem_1034 = native_batch_norm_backward_default_91[0]
        getitem_1035 = native_batch_norm_backward_default_91[1]
        getitem_1036 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1034, relu__default_43, primals_681, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1034 = primals_681 = None
        getitem_1037 = convolution_backward_default_114[0]
        getitem_1038 = convolution_backward_default_114[1];  convolution_backward_default_114 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_1037, torch.float32);  getitem_1037 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_230, to_dtype_273);  le_scalar_91 = new_zeros_default_230 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_56, primals_664, primals_662, primals_663, getitem_141, getitem_142, True, 1e-05, [True, True, True]);  to_dtype_275 = convolution_default_56 = primals_664 = primals_662 = primals_663 = getitem_141 = getitem_142 = None
        getitem_1040 = native_batch_norm_backward_default_92[0]
        getitem_1041 = native_batch_norm_backward_default_92[1]
        getitem_1042 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1040, relu__default_42, primals_670, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1040 = primals_670 = None
        getitem_1043 = convolution_backward_default_115[0]
        getitem_1044 = convolution_backward_default_115[1];  convolution_backward_default_115 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(to_dtype_266, getitem_1043);  to_dtype_266 = getitem_1043 = None
        to_dtype_276 = torch.ops.aten.to.dtype(add_tensor_45, torch.float32);  add_tensor_45 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_231, to_dtype_276);  le_scalar_92 = new_zeros_default_231 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_278, convolution_default_55, primals_642, primals_640, primals_641, getitem_138, getitem_139, True, 1e-05, [True, True, True]);  convolution_default_55 = primals_642 = primals_640 = primals_641 = getitem_138 = getitem_139 = None
        getitem_1046 = native_batch_norm_backward_default_93[0]
        getitem_1047 = native_batch_norm_backward_default_93[1]
        getitem_1048 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1046, sum_dim_int_list_19, primals_659, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1046 = sum_dim_int_list_19 = primals_659 = None
        getitem_1049 = convolution_backward_default_116[0]
        getitem_1050 = convolution_backward_default_116[1];  convolution_backward_default_116 = None
        unsqueeze_default_46 = torch.ops.aten.unsqueeze.default(getitem_1049, 1);  getitem_1049 = None
        expand_default_70 = torch.ops.aten.expand.default(unsqueeze_default_46, [128, 2, 256, 16, 16]);  unsqueeze_default_46 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(expand_default_70, view_default_45);  view_default_45 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(expand_default_70, view_default_49);  expand_default_70 = view_default_49 = None
        sum_dim_int_list_90 = torch.ops.aten.sum.dim_IntList(mul_tensor_79, [3, 4], True);  mul_tensor_79 = None
        view_default_283 = torch.ops.aten.view.default(sum_dim_int_list_90, [128, 512, 1, 1]);  sum_dim_int_list_90 = None
        view_default_284 = torch.ops.aten.view.default(view_default_283, [128, 512]);  view_default_283 = None
        view_default_285 = torch.ops.aten.view.default(view_default_284, [128, 2, 1, 256]);  view_default_284 = None
        _softmax_backward_data_default_23 = torch.ops.aten._softmax_backward_data.default(view_default_285, _softmax_default_9, 1, torch.float32);  view_default_285 = _softmax_default_9 = None
        transpose_int_56 = torch.ops.aten.transpose.int(_softmax_backward_data_default_23, 1, 2);  _softmax_backward_data_default_23 = None
        view_default_286 = torch.ops.aten.view.default(transpose_int_56, [128, 512, 1, 1]);  transpose_int_56 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(view_default_286, relu__default_41, primals_658, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_286 = primals_658 = None
        getitem_1052 = convolution_backward_default_117[0]
        getitem_1053 = convolution_backward_default_117[1]
        getitem_1054 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_1052, torch.float32);  getitem_1052 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_232, to_dtype_279);  le_scalar_93 = new_zeros_default_232 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_53, primals_653, primals_651, primals_652, getitem_135, getitem_136, True, 1e-05, [True, True, True]);  to_dtype_281 = convolution_default_53 = primals_653 = primals_651 = primals_652 = getitem_135 = getitem_136 = None
        getitem_1055 = native_batch_norm_backward_default_94[0]
        getitem_1056 = native_batch_norm_backward_default_94[1]
        getitem_1057 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1055, mean_dim_9, primals_656, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1055 = mean_dim_9 = primals_656 = None
        getitem_1058 = convolution_backward_default_118[0]
        getitem_1059 = convolution_backward_default_118[1]
        getitem_1060 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        expand_default_71 = torch.ops.aten.expand.default(getitem_1058, [128, 256, 16, 16]);  getitem_1058 = None
        div_scalar_24 = torch.ops.aten.div.Scalar(expand_default_71, 256);  expand_default_71 = None
        unsqueeze_default_47 = torch.ops.aten.unsqueeze.default(div_scalar_24, 1);  div_scalar_24 = None
        expand_default_72 = torch.ops.aten.expand.default(unsqueeze_default_47, [128, 2, 256, 16, 16]);  unsqueeze_default_47 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(mul_tensor_80, expand_default_72);  mul_tensor_80 = expand_default_72 = None
        view_default_287 = torch.ops.aten.view.default(add_tensor_46, [128, 512, 16, 16]);  add_tensor_46 = None
        to_dtype_282 = torch.ops.aten.to.dtype(view_default_287, torch.float32);  view_default_287 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_233, to_dtype_282);  le_scalar_94 = new_zeros_default_233 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_52, primals_648, primals_646, primals_647, getitem_132, getitem_133, True, 1e-05, [True, True, True]);  to_dtype_284 = convolution_default_52 = primals_648 = primals_646 = primals_647 = getitem_132 = getitem_133 = None
        getitem_1061 = native_batch_norm_backward_default_95[0]
        getitem_1062 = native_batch_norm_backward_default_95[1]
        getitem_1063 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1061, relu__default_39, primals_654, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1061 = primals_654 = None
        getitem_1064 = convolution_backward_default_119[0]
        getitem_1065 = convolution_backward_default_119[1];  convolution_backward_default_119 = None
        to_dtype_285 = torch.ops.aten.to.dtype(getitem_1064, torch.float32);  getitem_1064 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_234, to_dtype_285);  le_scalar_95 = new_zeros_default_234 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_287, convolution_default_51, primals_637, primals_635, primals_636, getitem_129, getitem_130, True, 1e-05, [True, True, True]);  to_dtype_287 = convolution_default_51 = primals_637 = primals_635 = primals_636 = getitem_129 = getitem_130 = None
        getitem_1067 = native_batch_norm_backward_default_96[0]
        getitem_1068 = native_batch_norm_backward_default_96[1]
        getitem_1069 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1067, relu__default_38, primals_643, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1067 = primals_643 = None
        getitem_1070 = convolution_backward_default_120[0]
        getitem_1071 = convolution_backward_default_120[1];  convolution_backward_default_120 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(to_dtype_278, getitem_1070);  to_dtype_278 = getitem_1070 = None
        to_dtype_288 = torch.ops.aten.to.dtype(add_tensor_47, torch.float32);  add_tensor_47 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_235, to_dtype_288);  le_scalar_96 = new_zeros_default_235 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_50, primals_534, primals_532, primals_533, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  convolution_default_50 = primals_534 = primals_532 = primals_533 = getitem_126 = getitem_127 = None
        getitem_1073 = native_batch_norm_backward_default_97[0]
        getitem_1074 = native_batch_norm_backward_default_97[1]
        getitem_1075 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1073, sum_dim_int_list_17, primals_551, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1073 = sum_dim_int_list_17 = primals_551 = None
        getitem_1076 = convolution_backward_default_121[0]
        getitem_1077 = convolution_backward_default_121[1];  convolution_backward_default_121 = None
        unsqueeze_default_48 = torch.ops.aten.unsqueeze.default(getitem_1076, 1);  getitem_1076 = None
        expand_default_73 = torch.ops.aten.expand.default(unsqueeze_default_48, [128, 2, 256, 16, 16]);  unsqueeze_default_48 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(expand_default_73, view_default_40);  view_default_40 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(expand_default_73, view_default_44);  expand_default_73 = view_default_44 = None
        sum_dim_int_list_91 = torch.ops.aten.sum.dim_IntList(mul_tensor_81, [3, 4], True);  mul_tensor_81 = None
        view_default_288 = torch.ops.aten.view.default(sum_dim_int_list_91, [128, 512, 1, 1]);  sum_dim_int_list_91 = None
        view_default_289 = torch.ops.aten.view.default(view_default_288, [128, 512]);  view_default_288 = None
        view_default_290 = torch.ops.aten.view.default(view_default_289, [128, 2, 1, 256]);  view_default_289 = None
        _softmax_backward_data_default_24 = torch.ops.aten._softmax_backward_data.default(view_default_290, _softmax_default_8, 1, torch.float32);  view_default_290 = _softmax_default_8 = None
        transpose_int_57 = torch.ops.aten.transpose.int(_softmax_backward_data_default_24, 1, 2);  _softmax_backward_data_default_24 = None
        view_default_291 = torch.ops.aten.view.default(transpose_int_57, [128, 512, 1, 1]);  transpose_int_57 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(view_default_291, relu__default_37, primals_550, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_291 = primals_550 = None
        getitem_1079 = convolution_backward_default_122[0]
        getitem_1080 = convolution_backward_default_122[1]
        getitem_1081 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_1079, torch.float32);  getitem_1079 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_236, to_dtype_291);  le_scalar_97 = new_zeros_default_236 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_293, convolution_default_48, primals_545, primals_543, primals_544, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  to_dtype_293 = convolution_default_48 = primals_545 = primals_543 = primals_544 = getitem_123 = getitem_124 = None
        getitem_1082 = native_batch_norm_backward_default_98[0]
        getitem_1083 = native_batch_norm_backward_default_98[1]
        getitem_1084 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1082, mean_dim_8, primals_548, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1082 = mean_dim_8 = primals_548 = None
        getitem_1085 = convolution_backward_default_123[0]
        getitem_1086 = convolution_backward_default_123[1]
        getitem_1087 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        expand_default_74 = torch.ops.aten.expand.default(getitem_1085, [128, 256, 16, 16]);  getitem_1085 = None
        div_scalar_25 = torch.ops.aten.div.Scalar(expand_default_74, 256);  expand_default_74 = None
        unsqueeze_default_49 = torch.ops.aten.unsqueeze.default(div_scalar_25, 1);  div_scalar_25 = None
        expand_default_75 = torch.ops.aten.expand.default(unsqueeze_default_49, [128, 2, 256, 16, 16]);  unsqueeze_default_49 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(mul_tensor_82, expand_default_75);  mul_tensor_82 = expand_default_75 = None
        view_default_292 = torch.ops.aten.view.default(add_tensor_48, [128, 512, 16, 16]);  add_tensor_48 = None
        to_dtype_294 = torch.ops.aten.to.dtype(view_default_292, torch.float32);  view_default_292 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_237 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_237, to_dtype_294);  le_scalar_98 = new_zeros_default_237 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_47, primals_540, primals_538, primals_539, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  to_dtype_296 = convolution_default_47 = primals_540 = primals_538 = primals_539 = getitem_120 = getitem_121 = None
        getitem_1088 = native_batch_norm_backward_default_99[0]
        getitem_1089 = native_batch_norm_backward_default_99[1]
        getitem_1090 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1088, relu__default_35, primals_546, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1088 = primals_546 = None
        getitem_1091 = convolution_backward_default_124[0]
        getitem_1092 = convolution_backward_default_124[1];  convolution_backward_default_124 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_1091, torch.float32);  getitem_1091 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_238 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_238, to_dtype_297);  le_scalar_99 = new_zeros_default_238 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_46, primals_529, primals_527, primals_528, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  to_dtype_299 = convolution_default_46 = primals_529 = primals_527 = primals_528 = getitem_117 = getitem_118 = None
        getitem_1094 = native_batch_norm_backward_default_100[0]
        getitem_1095 = native_batch_norm_backward_default_100[1]
        getitem_1096 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1094, relu__default_34, primals_535, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1094 = primals_535 = None
        getitem_1097 = convolution_backward_default_125[0]
        getitem_1098 = convolution_backward_default_125[1];  convolution_backward_default_125 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(to_dtype_290, getitem_1097);  to_dtype_290 = getitem_1097 = None
        to_dtype_300 = torch.ops.aten.to.dtype(add_tensor_49, torch.float32);  add_tensor_49 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_239 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_239, to_dtype_300);  le_scalar_100 = new_zeros_default_239 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_45, primals_254, primals_252, primals_253, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  convolution_default_45 = primals_254 = primals_252 = primals_253 = getitem_114 = getitem_115 = None
        getitem_1100 = native_batch_norm_backward_default_101[0]
        getitem_1101 = native_batch_norm_backward_default_101[1]
        getitem_1102 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1100, avg_pool2d_default_3, primals_249, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1100 = avg_pool2d_default_3 = primals_249 = None
        getitem_1103 = convolution_backward_default_126[0]
        getitem_1104 = convolution_backward_default_126[1];  convolution_backward_default_126 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_1103, relu__default_30, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_1103 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_44, primals_231, primals_229, primals_230, getitem_111, getitem_112, True, 1e-05, [True, True, True]);  to_dtype_302 = convolution_default_44 = primals_231 = primals_229 = primals_230 = getitem_111 = getitem_112 = None
        getitem_1106 = native_batch_norm_backward_default_102[0]
        getitem_1107 = native_batch_norm_backward_default_102[1]
        getitem_1108 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1106, avg_pool2d_default_2, primals_248, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1106 = avg_pool2d_default_2 = primals_248 = None
        getitem_1109 = convolution_backward_default_127[0]
        getitem_1110 = convolution_backward_default_127[1];  convolution_backward_default_127 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(getitem_1109, sum_dim_int_list_15, [3, 3], [2, 2], [1, 1], False, True, None);  getitem_1109 = sum_dim_int_list_15 = None
        unsqueeze_default_50 = torch.ops.aten.unsqueeze.default(avg_pool2d_backward_default_3, 1);  avg_pool2d_backward_default_3 = None
        expand_default_76 = torch.ops.aten.expand.default(unsqueeze_default_50, [128, 2, 256, 32, 32]);  unsqueeze_default_50 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(expand_default_76, view_default_35);  view_default_35 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(expand_default_76, view_default_39);  expand_default_76 = view_default_39 = None
        sum_dim_int_list_92 = torch.ops.aten.sum.dim_IntList(mul_tensor_83, [3, 4], True);  mul_tensor_83 = None
        view_default_293 = torch.ops.aten.view.default(sum_dim_int_list_92, [128, 512, 1, 1]);  sum_dim_int_list_92 = None
        view_default_294 = torch.ops.aten.view.default(view_default_293, [128, 512]);  view_default_293 = None
        view_default_295 = torch.ops.aten.view.default(view_default_294, [128, 2, 1, 256]);  view_default_294 = None
        _softmax_backward_data_default_25 = torch.ops.aten._softmax_backward_data.default(view_default_295, _softmax_default_7, 1, torch.float32);  view_default_295 = _softmax_default_7 = None
        transpose_int_58 = torch.ops.aten.transpose.int(_softmax_backward_data_default_25, 1, 2);  _softmax_backward_data_default_25 = None
        view_default_296 = torch.ops.aten.view.default(transpose_int_58, [128, 512, 1, 1]);  transpose_int_58 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(view_default_296, relu__default_33, primals_247, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_296 = primals_247 = None
        getitem_1112 = convolution_backward_default_128[0]
        getitem_1113 = convolution_backward_default_128[1]
        getitem_1114 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        to_dtype_303 = torch.ops.aten.to.dtype(getitem_1112, torch.float32);  getitem_1112 = None
        to_dtype_304 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_304, 0);  to_dtype_304 = None
        new_zeros_default_240 = torch.ops.aten.new_zeros.default(to_dtype_303, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_240, to_dtype_303);  le_scalar_101 = new_zeros_default_240 = to_dtype_303 = None
        to_dtype_305 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_305, convolution_default_42, primals_242, primals_240, primals_241, getitem_108, getitem_109, True, 1e-05, [True, True, True]);  to_dtype_305 = convolution_default_42 = primals_242 = primals_240 = primals_241 = getitem_108 = getitem_109 = None
        getitem_1115 = native_batch_norm_backward_default_103[0]
        getitem_1116 = native_batch_norm_backward_default_103[1]
        getitem_1117 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1115, mean_dim_7, primals_245, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1115 = mean_dim_7 = primals_245 = None
        getitem_1118 = convolution_backward_default_129[0]
        getitem_1119 = convolution_backward_default_129[1]
        getitem_1120 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        expand_default_77 = torch.ops.aten.expand.default(getitem_1118, [128, 256, 32, 32]);  getitem_1118 = None
        div_scalar_26 = torch.ops.aten.div.Scalar(expand_default_77, 1024);  expand_default_77 = None
        unsqueeze_default_51 = torch.ops.aten.unsqueeze.default(div_scalar_26, 1);  div_scalar_26 = None
        expand_default_78 = torch.ops.aten.expand.default(unsqueeze_default_51, [128, 2, 256, 32, 32]);  unsqueeze_default_51 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(mul_tensor_84, expand_default_78);  mul_tensor_84 = expand_default_78 = None
        view_default_297 = torch.ops.aten.view.default(add_tensor_50, [128, 512, 32, 32]);  add_tensor_50 = None
        to_dtype_306 = torch.ops.aten.to.dtype(view_default_297, torch.float32);  view_default_297 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_241 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_241, to_dtype_306);  le_scalar_102 = new_zeros_default_241 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_308, convolution_default_41, primals_237, primals_235, primals_236, getitem_105, getitem_106, True, 1e-05, [True, True, True]);  to_dtype_308 = convolution_default_41 = primals_237 = primals_235 = primals_236 = getitem_105 = getitem_106 = None
        getitem_1121 = native_batch_norm_backward_default_104[0]
        getitem_1122 = native_batch_norm_backward_default_104[1]
        getitem_1123 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1121, relu__default_31, primals_243, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1121 = primals_243 = None
        getitem_1124 = convolution_backward_default_130[0]
        getitem_1125 = convolution_backward_default_130[1];  convolution_backward_default_130 = None
        to_dtype_309 = torch.ops.aten.to.dtype(getitem_1124, torch.float32);  getitem_1124 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_242 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_242, to_dtype_309);  le_scalar_103 = new_zeros_default_242 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_40, primals_226, primals_224, primals_225, getitem_102, getitem_103, True, 1e-05, [True, True, True]);  to_dtype_311 = convolution_default_40 = primals_226 = primals_224 = primals_225 = getitem_102 = getitem_103 = None
        getitem_1127 = native_batch_norm_backward_default_105[0]
        getitem_1128 = native_batch_norm_backward_default_105[1]
        getitem_1129 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1127, relu__default_30, primals_232, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1127 = primals_232 = None
        getitem_1130 = convolution_backward_default_131[0]
        getitem_1131 = convolution_backward_default_131[1];  convolution_backward_default_131 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_2, getitem_1130);  avg_pool2d_backward_default_2 = getitem_1130 = None
        to_dtype_312 = torch.ops.aten.to.dtype(add_tensor_51, torch.float32);  add_tensor_51 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_243 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_243, to_dtype_312);  le_scalar_104 = new_zeros_default_243 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_314, convolution_default_39, primals_204, primals_202, primals_203, getitem_99, getitem_100, True, 1e-05, [True, True, True]);  convolution_default_39 = primals_204 = primals_202 = primals_203 = getitem_99 = getitem_100 = None
        getitem_1133 = native_batch_norm_backward_default_106[0]
        getitem_1134 = native_batch_norm_backward_default_106[1]
        getitem_1135 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(getitem_1133, sum_dim_int_list_13, primals_221, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1133 = sum_dim_int_list_13 = primals_221 = None
        getitem_1136 = convolution_backward_default_132[0]
        getitem_1137 = convolution_backward_default_132[1];  convolution_backward_default_132 = None
        unsqueeze_default_52 = torch.ops.aten.unsqueeze.default(getitem_1136, 1);  getitem_1136 = None
        expand_default_79 = torch.ops.aten.expand.default(unsqueeze_default_52, [128, 2, 128, 32, 32]);  unsqueeze_default_52 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(expand_default_79, view_default_30);  view_default_30 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(expand_default_79, view_default_34);  expand_default_79 = view_default_34 = None
        sum_dim_int_list_93 = torch.ops.aten.sum.dim_IntList(mul_tensor_85, [3, 4], True);  mul_tensor_85 = None
        view_default_298 = torch.ops.aten.view.default(sum_dim_int_list_93, [128, 256, 1, 1]);  sum_dim_int_list_93 = None
        view_default_299 = torch.ops.aten.view.default(view_default_298, [128, 256]);  view_default_298 = None
        view_default_300 = torch.ops.aten.view.default(view_default_299, [128, 2, 1, 128]);  view_default_299 = None
        _softmax_backward_data_default_26 = torch.ops.aten._softmax_backward_data.default(view_default_300, _softmax_default_6, 1, torch.float32);  view_default_300 = _softmax_default_6 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_softmax_backward_data_default_26, 1, 2);  _softmax_backward_data_default_26 = None
        view_default_301 = torch.ops.aten.view.default(transpose_int_59, [128, 256, 1, 1]);  transpose_int_59 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(view_default_301, relu__default_29, primals_220, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_301 = primals_220 = None
        getitem_1139 = convolution_backward_default_133[0]
        getitem_1140 = convolution_backward_default_133[1]
        getitem_1141 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        to_dtype_315 = torch.ops.aten.to.dtype(getitem_1139, torch.float32);  getitem_1139 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_244 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_244, to_dtype_315);  le_scalar_105 = new_zeros_default_244 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_317, convolution_default_37, primals_215, primals_213, primals_214, getitem_96, getitem_97, True, 1e-05, [True, True, True]);  to_dtype_317 = convolution_default_37 = primals_215 = primals_213 = primals_214 = getitem_96 = getitem_97 = None
        getitem_1142 = native_batch_norm_backward_default_107[0]
        getitem_1143 = native_batch_norm_backward_default_107[1]
        getitem_1144 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1142, mean_dim_6, primals_218, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1142 = mean_dim_6 = primals_218 = None
        getitem_1145 = convolution_backward_default_134[0]
        getitem_1146 = convolution_backward_default_134[1]
        getitem_1147 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        expand_default_80 = torch.ops.aten.expand.default(getitem_1145, [128, 128, 32, 32]);  getitem_1145 = None
        div_scalar_27 = torch.ops.aten.div.Scalar(expand_default_80, 1024);  expand_default_80 = None
        unsqueeze_default_53 = torch.ops.aten.unsqueeze.default(div_scalar_27, 1);  div_scalar_27 = None
        expand_default_81 = torch.ops.aten.expand.default(unsqueeze_default_53, [128, 2, 128, 32, 32]);  unsqueeze_default_53 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(mul_tensor_86, expand_default_81);  mul_tensor_86 = expand_default_81 = None
        view_default_302 = torch.ops.aten.view.default(add_tensor_52, [128, 256, 32, 32]);  add_tensor_52 = None
        to_dtype_318 = torch.ops.aten.to.dtype(view_default_302, torch.float32);  view_default_302 = None
        to_dtype_319 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_319, 0);  to_dtype_319 = None
        new_zeros_default_245 = torch.ops.aten.new_zeros.default(to_dtype_318, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_245, to_dtype_318);  le_scalar_106 = new_zeros_default_245 = to_dtype_318 = None
        to_dtype_320 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_320, convolution_default_36, primals_210, primals_208, primals_209, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  to_dtype_320 = convolution_default_36 = primals_210 = primals_208 = primals_209 = getitem_93 = getitem_94 = None
        getitem_1148 = native_batch_norm_backward_default_108[0]
        getitem_1149 = native_batch_norm_backward_default_108[1]
        getitem_1150 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1148, relu__default_27, primals_216, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1148 = primals_216 = None
        getitem_1151 = convolution_backward_default_135[0]
        getitem_1152 = convolution_backward_default_135[1];  convolution_backward_default_135 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_1151, torch.float32);  getitem_1151 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_246 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_246, to_dtype_321);  le_scalar_107 = new_zeros_default_246 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_323, convolution_default_35, primals_199, primals_197, primals_198, getitem_90, getitem_91, True, 1e-05, [True, True, True]);  to_dtype_323 = convolution_default_35 = primals_199 = primals_197 = primals_198 = getitem_90 = getitem_91 = None
        getitem_1154 = native_batch_norm_backward_default_109[0]
        getitem_1155 = native_batch_norm_backward_default_109[1]
        getitem_1156 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1154, relu__default_26, primals_205, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1154 = primals_205 = None
        getitem_1157 = convolution_backward_default_136[0]
        getitem_1158 = convolution_backward_default_136[1];  convolution_backward_default_136 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(to_dtype_314, getitem_1157);  to_dtype_314 = getitem_1157 = None
        to_dtype_324 = torch.ops.aten.to.dtype(add_tensor_53, torch.float32);  add_tensor_53 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_247 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_247, to_dtype_324);  le_scalar_108 = new_zeros_default_247 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_326, convolution_default_34, primals_177, primals_175, primals_176, getitem_87, getitem_88, True, 1e-05, [True, True, True]);  convolution_default_34 = primals_177 = primals_175 = primals_176 = getitem_87 = getitem_88 = None
        getitem_1160 = native_batch_norm_backward_default_110[0]
        getitem_1161 = native_batch_norm_backward_default_110[1]
        getitem_1162 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1160, sum_dim_int_list_11, primals_194, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1160 = sum_dim_int_list_11 = primals_194 = None
        getitem_1163 = convolution_backward_default_137[0]
        getitem_1164 = convolution_backward_default_137[1];  convolution_backward_default_137 = None
        unsqueeze_default_54 = torch.ops.aten.unsqueeze.default(getitem_1163, 1);  getitem_1163 = None
        expand_default_82 = torch.ops.aten.expand.default(unsqueeze_default_54, [128, 2, 128, 32, 32]);  unsqueeze_default_54 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(expand_default_82, view_default_25);  view_default_25 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(expand_default_82, view_default_29);  expand_default_82 = view_default_29 = None
        sum_dim_int_list_94 = torch.ops.aten.sum.dim_IntList(mul_tensor_87, [3, 4], True);  mul_tensor_87 = None
        view_default_303 = torch.ops.aten.view.default(sum_dim_int_list_94, [128, 256, 1, 1]);  sum_dim_int_list_94 = None
        view_default_304 = torch.ops.aten.view.default(view_default_303, [128, 256]);  view_default_303 = None
        view_default_305 = torch.ops.aten.view.default(view_default_304, [128, 2, 1, 128]);  view_default_304 = None
        _softmax_backward_data_default_27 = torch.ops.aten._softmax_backward_data.default(view_default_305, _softmax_default_5, 1, torch.float32);  view_default_305 = _softmax_default_5 = None
        transpose_int_60 = torch.ops.aten.transpose.int(_softmax_backward_data_default_27, 1, 2);  _softmax_backward_data_default_27 = None
        view_default_306 = torch.ops.aten.view.default(transpose_int_60, [128, 256, 1, 1]);  transpose_int_60 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(view_default_306, relu__default_25, primals_193, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_306 = primals_193 = None
        getitem_1166 = convolution_backward_default_138[0]
        getitem_1167 = convolution_backward_default_138[1]
        getitem_1168 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        to_dtype_327 = torch.ops.aten.to.dtype(getitem_1166, torch.float32);  getitem_1166 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_248 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_248, to_dtype_327);  le_scalar_109 = new_zeros_default_248 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_32, primals_188, primals_186, primals_187, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  to_dtype_329 = convolution_default_32 = primals_188 = primals_186 = primals_187 = getitem_84 = getitem_85 = None
        getitem_1169 = native_batch_norm_backward_default_111[0]
        getitem_1170 = native_batch_norm_backward_default_111[1]
        getitem_1171 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1169, mean_dim_5, primals_191, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1169 = mean_dim_5 = primals_191 = None
        getitem_1172 = convolution_backward_default_139[0]
        getitem_1173 = convolution_backward_default_139[1]
        getitem_1174 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        expand_default_83 = torch.ops.aten.expand.default(getitem_1172, [128, 128, 32, 32]);  getitem_1172 = None
        div_scalar_28 = torch.ops.aten.div.Scalar(expand_default_83, 1024);  expand_default_83 = None
        unsqueeze_default_55 = torch.ops.aten.unsqueeze.default(div_scalar_28, 1);  div_scalar_28 = None
        expand_default_84 = torch.ops.aten.expand.default(unsqueeze_default_55, [128, 2, 128, 32, 32]);  unsqueeze_default_55 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(mul_tensor_88, expand_default_84);  mul_tensor_88 = expand_default_84 = None
        view_default_307 = torch.ops.aten.view.default(add_tensor_54, [128, 256, 32, 32]);  add_tensor_54 = None
        to_dtype_330 = torch.ops.aten.to.dtype(view_default_307, torch.float32);  view_default_307 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_249 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_249, to_dtype_330);  le_scalar_110 = new_zeros_default_249 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_332, convolution_default_31, primals_183, primals_181, primals_182, getitem_81, getitem_82, True, 1e-05, [True, True, True]);  to_dtype_332 = convolution_default_31 = primals_183 = primals_181 = primals_182 = getitem_81 = getitem_82 = None
        getitem_1175 = native_batch_norm_backward_default_112[0]
        getitem_1176 = native_batch_norm_backward_default_112[1]
        getitem_1177 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1175, relu__default_23, primals_189, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1175 = primals_189 = None
        getitem_1178 = convolution_backward_default_140[0]
        getitem_1179 = convolution_backward_default_140[1];  convolution_backward_default_140 = None
        to_dtype_333 = torch.ops.aten.to.dtype(getitem_1178, torch.float32);  getitem_1178 = None
        to_dtype_334 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_334, 0);  to_dtype_334 = None
        new_zeros_default_250 = torch.ops.aten.new_zeros.default(to_dtype_333, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_250, to_dtype_333);  le_scalar_111 = new_zeros_default_250 = to_dtype_333 = None
        to_dtype_335 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_335, convolution_default_30, primals_172, primals_170, primals_171, getitem_78, getitem_79, True, 1e-05, [True, True, True]);  to_dtype_335 = convolution_default_30 = primals_172 = primals_170 = primals_171 = getitem_78 = getitem_79 = None
        getitem_1181 = native_batch_norm_backward_default_113[0]
        getitem_1182 = native_batch_norm_backward_default_113[1]
        getitem_1183 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_1181, relu__default_22, primals_178, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1181 = primals_178 = None
        getitem_1184 = convolution_backward_default_141[0]
        getitem_1185 = convolution_backward_default_141[1];  convolution_backward_default_141 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(to_dtype_326, getitem_1184);  to_dtype_326 = getitem_1184 = None
        to_dtype_336 = torch.ops.aten.to.dtype(add_tensor_55, torch.float32);  add_tensor_55 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_251 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_251, to_dtype_336);  le_scalar_112 = new_zeros_default_251 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_338, convolution_default_29, primals_150, primals_148, primals_149, getitem_75, getitem_76, True, 1e-05, [True, True, True]);  convolution_default_29 = primals_150 = primals_148 = primals_149 = getitem_75 = getitem_76 = None
        getitem_1187 = native_batch_norm_backward_default_114[0]
        getitem_1188 = native_batch_norm_backward_default_114[1]
        getitem_1189 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_1187, sum_dim_int_list_9, primals_167, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1187 = sum_dim_int_list_9 = primals_167 = None
        getitem_1190 = convolution_backward_default_142[0]
        getitem_1191 = convolution_backward_default_142[1];  convolution_backward_default_142 = None
        unsqueeze_default_56 = torch.ops.aten.unsqueeze.default(getitem_1190, 1);  getitem_1190 = None
        expand_default_85 = torch.ops.aten.expand.default(unsqueeze_default_56, [128, 2, 128, 32, 32]);  unsqueeze_default_56 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(expand_default_85, view_default_20);  view_default_20 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(expand_default_85, view_default_24);  expand_default_85 = view_default_24 = None
        sum_dim_int_list_95 = torch.ops.aten.sum.dim_IntList(mul_tensor_89, [3, 4], True);  mul_tensor_89 = None
        view_default_308 = torch.ops.aten.view.default(sum_dim_int_list_95, [128, 256, 1, 1]);  sum_dim_int_list_95 = None
        view_default_309 = torch.ops.aten.view.default(view_default_308, [128, 256]);  view_default_308 = None
        view_default_310 = torch.ops.aten.view.default(view_default_309, [128, 2, 1, 128]);  view_default_309 = None
        _softmax_backward_data_default_28 = torch.ops.aten._softmax_backward_data.default(view_default_310, _softmax_default_4, 1, torch.float32);  view_default_310 = _softmax_default_4 = None
        transpose_int_61 = torch.ops.aten.transpose.int(_softmax_backward_data_default_28, 1, 2);  _softmax_backward_data_default_28 = None
        view_default_311 = torch.ops.aten.view.default(transpose_int_61, [128, 256, 1, 1]);  transpose_int_61 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(view_default_311, relu__default_21, primals_166, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_311 = primals_166 = None
        getitem_1193 = convolution_backward_default_143[0]
        getitem_1194 = convolution_backward_default_143[1]
        getitem_1195 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        to_dtype_339 = torch.ops.aten.to.dtype(getitem_1193, torch.float32);  getitem_1193 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_252 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_252, to_dtype_339);  le_scalar_113 = new_zeros_default_252 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_27, primals_161, primals_159, primals_160, getitem_72, getitem_73, True, 1e-05, [True, True, True]);  to_dtype_341 = convolution_default_27 = primals_161 = primals_159 = primals_160 = getitem_72 = getitem_73 = None
        getitem_1196 = native_batch_norm_backward_default_115[0]
        getitem_1197 = native_batch_norm_backward_default_115[1]
        getitem_1198 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1196, mean_dim_4, primals_164, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1196 = mean_dim_4 = primals_164 = None
        getitem_1199 = convolution_backward_default_144[0]
        getitem_1200 = convolution_backward_default_144[1]
        getitem_1201 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        expand_default_86 = torch.ops.aten.expand.default(getitem_1199, [128, 128, 32, 32]);  getitem_1199 = None
        div_scalar_29 = torch.ops.aten.div.Scalar(expand_default_86, 1024);  expand_default_86 = None
        unsqueeze_default_57 = torch.ops.aten.unsqueeze.default(div_scalar_29, 1);  div_scalar_29 = None
        expand_default_87 = torch.ops.aten.expand.default(unsqueeze_default_57, [128, 2, 128, 32, 32]);  unsqueeze_default_57 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(mul_tensor_90, expand_default_87);  mul_tensor_90 = expand_default_87 = None
        view_default_312 = torch.ops.aten.view.default(add_tensor_56, [128, 256, 32, 32]);  add_tensor_56 = None
        to_dtype_342 = torch.ops.aten.to.dtype(view_default_312, torch.float32);  view_default_312 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_253 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_253, to_dtype_342);  le_scalar_114 = new_zeros_default_253 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_344, convolution_default_26, primals_156, primals_154, primals_155, getitem_69, getitem_70, True, 1e-05, [True, True, True]);  to_dtype_344 = convolution_default_26 = primals_156 = primals_154 = primals_155 = getitem_69 = getitem_70 = None
        getitem_1202 = native_batch_norm_backward_default_116[0]
        getitem_1203 = native_batch_norm_backward_default_116[1]
        getitem_1204 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1202, relu__default_19, primals_162, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1202 = primals_162 = None
        getitem_1205 = convolution_backward_default_145[0]
        getitem_1206 = convolution_backward_default_145[1];  convolution_backward_default_145 = None
        to_dtype_345 = torch.ops.aten.to.dtype(getitem_1205, torch.float32);  getitem_1205 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_254 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_254, to_dtype_345);  le_scalar_115 = new_zeros_default_254 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_347, convolution_default_25, primals_145, primals_143, primals_144, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_347 = convolution_default_25 = primals_145 = primals_143 = primals_144 = getitem_66 = getitem_67 = None
        getitem_1208 = native_batch_norm_backward_default_117[0]
        getitem_1209 = native_batch_norm_backward_default_117[1]
        getitem_1210 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1208, relu__default_18, primals_151, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1208 = primals_151 = None
        getitem_1211 = convolution_backward_default_146[0]
        getitem_1212 = convolution_backward_default_146[1];  convolution_backward_default_146 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(to_dtype_338, getitem_1211);  to_dtype_338 = getitem_1211 = None
        to_dtype_348 = torch.ops.aten.to.dtype(add_tensor_57, torch.float32);  add_tensor_57 = None
        to_dtype_349 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_349, 0);  to_dtype_349 = None
        new_zeros_default_255 = torch.ops.aten.new_zeros.default(to_dtype_348, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_255, to_dtype_348);  le_scalar_116 = new_zeros_default_255 = to_dtype_348 = None
        to_dtype_350 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_350, convolution_default_24, primals_140, primals_138, primals_139, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  convolution_default_24 = primals_140 = primals_138 = primals_139 = getitem_63 = getitem_64 = None
        getitem_1214 = native_batch_norm_backward_default_118[0]
        getitem_1215 = native_batch_norm_backward_default_118[1]
        getitem_1216 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(getitem_1214, avg_pool2d_default_1, primals_135, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1214 = avg_pool2d_default_1 = primals_135 = None
        getitem_1217 = convolution_backward_default_147[0]
        getitem_1218 = convolution_backward_default_147[1];  convolution_backward_default_147 = None
        avg_pool2d_backward_default_4 = torch.ops.aten.avg_pool2d_backward.default(getitem_1217, relu__default_14, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_1217 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_350, convolution_default_23, primals_117, primals_115, primals_116, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  to_dtype_350 = convolution_default_23 = primals_117 = primals_115 = primals_116 = getitem_60 = getitem_61 = None
        getitem_1220 = native_batch_norm_backward_default_119[0]
        getitem_1221 = native_batch_norm_backward_default_119[1]
        getitem_1222 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1220, avg_pool2d_default, primals_134, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1220 = avg_pool2d_default = primals_134 = None
        getitem_1223 = convolution_backward_default_148[0]
        getitem_1224 = convolution_backward_default_148[1];  convolution_backward_default_148 = None
        avg_pool2d_backward_default_5 = torch.ops.aten.avg_pool2d_backward.default(getitem_1223, sum_dim_int_list_7, [3, 3], [2, 2], [1, 1], False, True, None);  getitem_1223 = sum_dim_int_list_7 = None
        unsqueeze_default_58 = torch.ops.aten.unsqueeze.default(avg_pool2d_backward_default_5, 1);  avg_pool2d_backward_default_5 = None
        expand_default_88 = torch.ops.aten.expand.default(unsqueeze_default_58, [128, 2, 128, 64, 64]);  unsqueeze_default_58 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(expand_default_88, view_default_15);  view_default_15 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(expand_default_88, view_default_19);  expand_default_88 = view_default_19 = None
        sum_dim_int_list_96 = torch.ops.aten.sum.dim_IntList(mul_tensor_91, [3, 4], True);  mul_tensor_91 = None
        view_default_313 = torch.ops.aten.view.default(sum_dim_int_list_96, [128, 256, 1, 1]);  sum_dim_int_list_96 = None
        view_default_314 = torch.ops.aten.view.default(view_default_313, [128, 256]);  view_default_313 = None
        view_default_315 = torch.ops.aten.view.default(view_default_314, [128, 2, 1, 128]);  view_default_314 = None
        _softmax_backward_data_default_29 = torch.ops.aten._softmax_backward_data.default(view_default_315, _softmax_default_3, 1, torch.float32);  view_default_315 = _softmax_default_3 = None
        transpose_int_62 = torch.ops.aten.transpose.int(_softmax_backward_data_default_29, 1, 2);  _softmax_backward_data_default_29 = None
        view_default_316 = torch.ops.aten.view.default(transpose_int_62, [128, 256, 1, 1]);  transpose_int_62 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(view_default_316, relu__default_17, primals_133, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_316 = primals_133 = None
        getitem_1226 = convolution_backward_default_149[0]
        getitem_1227 = convolution_backward_default_149[1]
        getitem_1228 = convolution_backward_default_149[2];  convolution_backward_default_149 = None
        to_dtype_351 = torch.ops.aten.to.dtype(getitem_1226, torch.float32);  getitem_1226 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_256 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_256, to_dtype_351);  le_scalar_117 = new_zeros_default_256 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_353, convolution_default_21, primals_128, primals_126, primals_127, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_353 = convolution_default_21 = primals_128 = primals_126 = primals_127 = getitem_57 = getitem_58 = None
        getitem_1229 = native_batch_norm_backward_default_120[0]
        getitem_1230 = native_batch_norm_backward_default_120[1]
        getitem_1231 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1229, mean_dim_3, primals_131, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1229 = mean_dim_3 = primals_131 = None
        getitem_1232 = convolution_backward_default_150[0]
        getitem_1233 = convolution_backward_default_150[1]
        getitem_1234 = convolution_backward_default_150[2];  convolution_backward_default_150 = None
        expand_default_89 = torch.ops.aten.expand.default(getitem_1232, [128, 128, 64, 64]);  getitem_1232 = None
        div_scalar_30 = torch.ops.aten.div.Scalar(expand_default_89, 4096);  expand_default_89 = None
        unsqueeze_default_59 = torch.ops.aten.unsqueeze.default(div_scalar_30, 1);  div_scalar_30 = None
        expand_default_90 = torch.ops.aten.expand.default(unsqueeze_default_59, [128, 2, 128, 64, 64]);  unsqueeze_default_59 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(mul_tensor_92, expand_default_90);  mul_tensor_92 = expand_default_90 = None
        view_default_317 = torch.ops.aten.view.default(add_tensor_58, [128, 256, 64, 64]);  add_tensor_58 = None
        to_dtype_354 = torch.ops.aten.to.dtype(view_default_317, torch.float32);  view_default_317 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_257 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_257, to_dtype_354);  le_scalar_118 = new_zeros_default_257 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_356, convolution_default_20, primals_123, primals_121, primals_122, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_356 = convolution_default_20 = primals_123 = primals_121 = primals_122 = getitem_54 = getitem_55 = None
        getitem_1235 = native_batch_norm_backward_default_121[0]
        getitem_1236 = native_batch_norm_backward_default_121[1]
        getitem_1237 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(getitem_1235, relu__default_15, primals_129, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1235 = primals_129 = None
        getitem_1238 = convolution_backward_default_151[0]
        getitem_1239 = convolution_backward_default_151[1];  convolution_backward_default_151 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_1238, torch.float32);  getitem_1238 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_258 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_258, to_dtype_357);  le_scalar_119 = new_zeros_default_258 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_19, primals_112, primals_110, primals_111, getitem_51, getitem_52, True, 1e-05, [True, True, True]);  to_dtype_359 = convolution_default_19 = primals_112 = primals_110 = primals_111 = getitem_51 = getitem_52 = None
        getitem_1241 = native_batch_norm_backward_default_122[0]
        getitem_1242 = native_batch_norm_backward_default_122[1]
        getitem_1243 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(getitem_1241, relu__default_14, primals_118, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1241 = primals_118 = None
        getitem_1244 = convolution_backward_default_152[0]
        getitem_1245 = convolution_backward_default_152[1];  convolution_backward_default_152 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_4, getitem_1244);  avg_pool2d_backward_default_4 = getitem_1244 = None
        to_dtype_360 = torch.ops.aten.to.dtype(add_tensor_59, torch.float32);  add_tensor_59 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_259 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_259, to_dtype_360);  le_scalar_120 = new_zeros_default_259 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_362, convolution_default_18, primals_90, primals_88, primals_89, getitem_48, getitem_49, True, 1e-05, [True, True, True]);  convolution_default_18 = primals_90 = primals_88 = primals_89 = getitem_48 = getitem_49 = None
        getitem_1247 = native_batch_norm_backward_default_123[0]
        getitem_1248 = native_batch_norm_backward_default_123[1]
        getitem_1249 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_1247, sum_dim_int_list_5, primals_107, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1247 = sum_dim_int_list_5 = primals_107 = None
        getitem_1250 = convolution_backward_default_153[0]
        getitem_1251 = convolution_backward_default_153[1];  convolution_backward_default_153 = None
        unsqueeze_default_60 = torch.ops.aten.unsqueeze.default(getitem_1250, 1);  getitem_1250 = None
        expand_default_91 = torch.ops.aten.expand.default(unsqueeze_default_60, [128, 2, 64, 64, 64]);  unsqueeze_default_60 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(expand_default_91, view_default_10);  view_default_10 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(expand_default_91, view_default_14);  expand_default_91 = view_default_14 = None
        sum_dim_int_list_97 = torch.ops.aten.sum.dim_IntList(mul_tensor_93, [3, 4], True);  mul_tensor_93 = None
        view_default_318 = torch.ops.aten.view.default(sum_dim_int_list_97, [128, 128, 1, 1]);  sum_dim_int_list_97 = None
        view_default_319 = torch.ops.aten.view.default(view_default_318, [128, 128]);  view_default_318 = None
        view_default_320 = torch.ops.aten.view.default(view_default_319, [128, 2, 1, 64]);  view_default_319 = None
        _softmax_backward_data_default_30 = torch.ops.aten._softmax_backward_data.default(view_default_320, _softmax_default_2, 1, torch.float32);  view_default_320 = _softmax_default_2 = None
        transpose_int_63 = torch.ops.aten.transpose.int(_softmax_backward_data_default_30, 1, 2);  _softmax_backward_data_default_30 = None
        view_default_321 = torch.ops.aten.view.default(transpose_int_63, [128, 128, 1, 1]);  transpose_int_63 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(view_default_321, relu__default_13, primals_106, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_321 = primals_106 = None
        getitem_1253 = convolution_backward_default_154[0]
        getitem_1254 = convolution_backward_default_154[1]
        getitem_1255 = convolution_backward_default_154[2];  convolution_backward_default_154 = None
        to_dtype_363 = torch.ops.aten.to.dtype(getitem_1253, torch.float32);  getitem_1253 = None
        to_dtype_364 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_364, 0);  to_dtype_364 = None
        new_zeros_default_260 = torch.ops.aten.new_zeros.default(to_dtype_363, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_260, to_dtype_363);  le_scalar_121 = new_zeros_default_260 = to_dtype_363 = None
        to_dtype_365 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_365, convolution_default_16, primals_101, primals_99, primals_100, getitem_45, getitem_46, True, 1e-05, [True, True, True]);  to_dtype_365 = convolution_default_16 = primals_101 = primals_99 = primals_100 = getitem_45 = getitem_46 = None
        getitem_1256 = native_batch_norm_backward_default_124[0]
        getitem_1257 = native_batch_norm_backward_default_124[1]
        getitem_1258 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1256, mean_dim_2, primals_104, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1256 = mean_dim_2 = primals_104 = None
        getitem_1259 = convolution_backward_default_155[0]
        getitem_1260 = convolution_backward_default_155[1]
        getitem_1261 = convolution_backward_default_155[2];  convolution_backward_default_155 = None
        expand_default_92 = torch.ops.aten.expand.default(getitem_1259, [128, 64, 64, 64]);  getitem_1259 = None
        div_scalar_31 = torch.ops.aten.div.Scalar(expand_default_92, 4096);  expand_default_92 = None
        unsqueeze_default_61 = torch.ops.aten.unsqueeze.default(div_scalar_31, 1);  div_scalar_31 = None
        expand_default_93 = torch.ops.aten.expand.default(unsqueeze_default_61, [128, 2, 64, 64, 64]);  unsqueeze_default_61 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(mul_tensor_94, expand_default_93);  mul_tensor_94 = expand_default_93 = None
        view_default_322 = torch.ops.aten.view.default(add_tensor_60, [128, 128, 64, 64]);  add_tensor_60 = None
        to_dtype_366 = torch.ops.aten.to.dtype(view_default_322, torch.float32);  view_default_322 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_261 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_261, to_dtype_366);  le_scalar_122 = new_zeros_default_261 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_368, convolution_default_15, primals_96, primals_94, primals_95, getitem_42, getitem_43, True, 1e-05, [True, True, True]);  to_dtype_368 = convolution_default_15 = primals_96 = primals_94 = primals_95 = getitem_42 = getitem_43 = None
        getitem_1262 = native_batch_norm_backward_default_125[0]
        getitem_1263 = native_batch_norm_backward_default_125[1]
        getitem_1264 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(getitem_1262, relu__default_11, primals_102, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1262 = primals_102 = None
        getitem_1265 = convolution_backward_default_156[0]
        getitem_1266 = convolution_backward_default_156[1];  convolution_backward_default_156 = None
        to_dtype_369 = torch.ops.aten.to.dtype(getitem_1265, torch.float32);  getitem_1265 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_262 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_262, to_dtype_369);  le_scalar_123 = new_zeros_default_262 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_14, primals_85, primals_83, primals_84, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  to_dtype_371 = convolution_default_14 = primals_85 = primals_83 = primals_84 = getitem_39 = getitem_40 = None
        getitem_1268 = native_batch_norm_backward_default_126[0]
        getitem_1269 = native_batch_norm_backward_default_126[1]
        getitem_1270 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(getitem_1268, relu__default_10, primals_91, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1268 = primals_91 = None
        getitem_1271 = convolution_backward_default_157[0]
        getitem_1272 = convolution_backward_default_157[1];  convolution_backward_default_157 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(to_dtype_362, getitem_1271);  to_dtype_362 = getitem_1271 = None
        to_dtype_372 = torch.ops.aten.to.dtype(add_tensor_61, torch.float32);  add_tensor_61 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_263 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_263, to_dtype_372);  le_scalar_124 = new_zeros_default_263 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_374, convolution_default_13, primals_63, primals_61, primals_62, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  convolution_default_13 = primals_63 = primals_61 = primals_62 = getitem_36 = getitem_37 = None
        getitem_1274 = native_batch_norm_backward_default_127[0]
        getitem_1275 = native_batch_norm_backward_default_127[1]
        getitem_1276 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(getitem_1274, sum_dim_int_list_3, primals_80, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1274 = sum_dim_int_list_3 = primals_80 = None
        getitem_1277 = convolution_backward_default_158[0]
        getitem_1278 = convolution_backward_default_158[1];  convolution_backward_default_158 = None
        unsqueeze_default_62 = torch.ops.aten.unsqueeze.default(getitem_1277, 1);  getitem_1277 = None
        expand_default_94 = torch.ops.aten.expand.default(unsqueeze_default_62, [128, 2, 64, 64, 64]);  unsqueeze_default_62 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(expand_default_94, view_default_5);  view_default_5 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(expand_default_94, view_default_9);  expand_default_94 = view_default_9 = None
        sum_dim_int_list_98 = torch.ops.aten.sum.dim_IntList(mul_tensor_95, [3, 4], True);  mul_tensor_95 = None
        view_default_323 = torch.ops.aten.view.default(sum_dim_int_list_98, [128, 128, 1, 1]);  sum_dim_int_list_98 = None
        view_default_324 = torch.ops.aten.view.default(view_default_323, [128, 128]);  view_default_323 = None
        view_default_325 = torch.ops.aten.view.default(view_default_324, [128, 2, 1, 64]);  view_default_324 = None
        _softmax_backward_data_default_31 = torch.ops.aten._softmax_backward_data.default(view_default_325, _softmax_default_1, 1, torch.float32);  view_default_325 = _softmax_default_1 = None
        transpose_int_64 = torch.ops.aten.transpose.int(_softmax_backward_data_default_31, 1, 2);  _softmax_backward_data_default_31 = None
        view_default_326 = torch.ops.aten.view.default(transpose_int_64, [128, 128, 1, 1]);  transpose_int_64 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(view_default_326, relu__default_9, primals_79, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_326 = primals_79 = None
        getitem_1280 = convolution_backward_default_159[0]
        getitem_1281 = convolution_backward_default_159[1]
        getitem_1282 = convolution_backward_default_159[2];  convolution_backward_default_159 = None
        to_dtype_375 = torch.ops.aten.to.dtype(getitem_1280, torch.float32);  getitem_1280 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_264, to_dtype_375);  le_scalar_125 = new_zeros_default_264 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_11, primals_74, primals_72, primals_73, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  to_dtype_377 = convolution_default_11 = primals_74 = primals_72 = primals_73 = getitem_33 = getitem_34 = None
        getitem_1283 = native_batch_norm_backward_default_128[0]
        getitem_1284 = native_batch_norm_backward_default_128[1]
        getitem_1285 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1283, mean_dim_1, primals_77, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1283 = mean_dim_1 = primals_77 = None
        getitem_1286 = convolution_backward_default_160[0]
        getitem_1287 = convolution_backward_default_160[1]
        getitem_1288 = convolution_backward_default_160[2];  convolution_backward_default_160 = None
        expand_default_95 = torch.ops.aten.expand.default(getitem_1286, [128, 64, 64, 64]);  getitem_1286 = None
        div_scalar_32 = torch.ops.aten.div.Scalar(expand_default_95, 4096);  expand_default_95 = None
        unsqueeze_default_63 = torch.ops.aten.unsqueeze.default(div_scalar_32, 1);  div_scalar_32 = None
        expand_default_96 = torch.ops.aten.expand.default(unsqueeze_default_63, [128, 2, 64, 64, 64]);  unsqueeze_default_63 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(mul_tensor_96, expand_default_96);  mul_tensor_96 = expand_default_96 = None
        view_default_327 = torch.ops.aten.view.default(add_tensor_62, [128, 128, 64, 64]);  add_tensor_62 = None
        to_dtype_378 = torch.ops.aten.to.dtype(view_default_327, torch.float32);  view_default_327 = None
        to_dtype_379 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_379, 0);  to_dtype_379 = None
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(to_dtype_378, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_265, to_dtype_378);  le_scalar_126 = new_zeros_default_265 = to_dtype_378 = None
        to_dtype_380 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_380, convolution_default_10, primals_69, primals_67, primals_68, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  to_dtype_380 = convolution_default_10 = primals_69 = primals_67 = primals_68 = getitem_30 = getitem_31 = None
        getitem_1289 = native_batch_norm_backward_default_129[0]
        getitem_1290 = native_batch_norm_backward_default_129[1]
        getitem_1291 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(getitem_1289, relu__default_7, primals_75, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1289 = primals_75 = None
        getitem_1292 = convolution_backward_default_161[0]
        getitem_1293 = convolution_backward_default_161[1];  convolution_backward_default_161 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_1292, torch.float32);  getitem_1292 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_266, to_dtype_381);  le_scalar_127 = new_zeros_default_266 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_383, convolution_default_9, primals_58, primals_56, primals_57, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_383 = convolution_default_9 = primals_58 = primals_56 = primals_57 = getitem_27 = getitem_28 = None
        getitem_1295 = native_batch_norm_backward_default_130[0]
        getitem_1296 = native_batch_norm_backward_default_130[1]
        getitem_1297 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(getitem_1295, relu__default_6, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1295 = primals_64 = None
        getitem_1298 = convolution_backward_default_162[0]
        getitem_1299 = convolution_backward_default_162[1];  convolution_backward_default_162 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(to_dtype_374, getitem_1298);  to_dtype_374 = getitem_1298 = None
        to_dtype_384 = torch.ops.aten.to.dtype(add_tensor_63, torch.float32);  add_tensor_63 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_267, to_dtype_384);  le_scalar_128 = new_zeros_default_267 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_8, primals_53, primals_51, primals_52, getitem_24, getitem_25, True, 1e-05, [True, True, True]);  convolution_default_8 = primals_53 = primals_51 = primals_52 = getitem_24 = getitem_25 = None
        getitem_1301 = native_batch_norm_backward_default_131[0]
        getitem_1302 = native_batch_norm_backward_default_131[1]
        getitem_1303 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(getitem_1301, getitem_9, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1301 = primals_48 = None
        getitem_1304 = convolution_backward_default_163[0]
        getitem_1305 = convolution_backward_default_163[1];  convolution_backward_default_163 = None
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_7, primals_30, primals_28, primals_29, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  to_dtype_386 = convolution_default_7 = primals_30 = primals_28 = primals_29 = getitem_21 = getitem_22 = None
        getitem_1307 = native_batch_norm_backward_default_132[0]
        getitem_1308 = native_batch_norm_backward_default_132[1]
        getitem_1309 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(getitem_1307, sum_dim_int_list_1, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1307 = sum_dim_int_list_1 = primals_47 = None
        getitem_1310 = convolution_backward_default_164[0]
        getitem_1311 = convolution_backward_default_164[1];  convolution_backward_default_164 = None
        unsqueeze_default_64 = torch.ops.aten.unsqueeze.default(getitem_1310, 1);  getitem_1310 = None
        expand_default_97 = torch.ops.aten.expand.default(unsqueeze_default_64, [128, 2, 64, 64, 64]);  unsqueeze_default_64 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(expand_default_97, view_default);  view_default = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(expand_default_97, view_default_4);  expand_default_97 = view_default_4 = None
        sum_dim_int_list_99 = torch.ops.aten.sum.dim_IntList(mul_tensor_97, [3, 4], True);  mul_tensor_97 = None
        view_default_328 = torch.ops.aten.view.default(sum_dim_int_list_99, [128, 128, 1, 1]);  sum_dim_int_list_99 = None
        view_default_329 = torch.ops.aten.view.default(view_default_328, [128, 128]);  view_default_328 = None
        view_default_330 = torch.ops.aten.view.default(view_default_329, [128, 2, 1, 64]);  view_default_329 = None
        _softmax_backward_data_default_32 = torch.ops.aten._softmax_backward_data.default(view_default_330, _softmax_default, 1, torch.float32);  view_default_330 = _softmax_default = None
        transpose_int_65 = torch.ops.aten.transpose.int(_softmax_backward_data_default_32, 1, 2);  _softmax_backward_data_default_32 = None
        view_default_331 = torch.ops.aten.view.default(transpose_int_65, [128, 128, 1, 1]);  transpose_int_65 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(view_default_331, relu__default_5, primals_46, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_331 = primals_46 = None
        getitem_1313 = convolution_backward_default_165[0]
        getitem_1314 = convolution_backward_default_165[1]
        getitem_1315 = convolution_backward_default_165[2];  convolution_backward_default_165 = None
        to_dtype_387 = torch.ops.aten.to.dtype(getitem_1313, torch.float32);  getitem_1313 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_268, to_dtype_387);  le_scalar_129 = new_zeros_default_268 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_5, primals_41, primals_39, primals_40, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  to_dtype_389 = convolution_default_5 = primals_41 = primals_39 = primals_40 = getitem_18 = getitem_19 = None
        getitem_1316 = native_batch_norm_backward_default_133[0]
        getitem_1317 = native_batch_norm_backward_default_133[1]
        getitem_1318 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(getitem_1316, mean_dim, primals_44, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  getitem_1316 = mean_dim = primals_44 = None
        getitem_1319 = convolution_backward_default_166[0]
        getitem_1320 = convolution_backward_default_166[1]
        getitem_1321 = convolution_backward_default_166[2];  convolution_backward_default_166 = None
        expand_default_98 = torch.ops.aten.expand.default(getitem_1319, [128, 64, 64, 64]);  getitem_1319 = None
        div_scalar_33 = torch.ops.aten.div.Scalar(expand_default_98, 4096);  expand_default_98 = None
        unsqueeze_default_65 = torch.ops.aten.unsqueeze.default(div_scalar_33, 1);  div_scalar_33 = None
        expand_default_99 = torch.ops.aten.expand.default(unsqueeze_default_65, [128, 2, 64, 64, 64]);  unsqueeze_default_65 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(mul_tensor_98, expand_default_99);  mul_tensor_98 = expand_default_99 = None
        view_default_332 = torch.ops.aten.view.default(add_tensor_64, [128, 128, 64, 64]);  add_tensor_64 = None
        to_dtype_390 = torch.ops.aten.to.dtype(view_default_332, torch.float32);  view_default_332 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_269, to_dtype_390);  le_scalar_130 = new_zeros_default_269 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_392, convolution_default_4, primals_36, primals_34, primals_35, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  to_dtype_392 = convolution_default_4 = primals_36 = primals_34 = primals_35 = getitem_15 = getitem_16 = None
        getitem_1322 = native_batch_norm_backward_default_134[0]
        getitem_1323 = native_batch_norm_backward_default_134[1]
        getitem_1324 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(getitem_1322, relu__default_3, primals_42, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 2, [True, True, False]);  getitem_1322 = primals_42 = None
        getitem_1325 = convolution_backward_default_167[0]
        getitem_1326 = convolution_backward_default_167[1];  convolution_backward_default_167 = None
        to_dtype_393 = torch.ops.aten.to.dtype(getitem_1325, torch.float32);  getitem_1325 = None
        to_dtype_394 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_394, 0);  to_dtype_394 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(to_dtype_393, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_270, to_dtype_393);  le_scalar_131 = new_zeros_default_270 = to_dtype_393 = None
        to_dtype_395 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_395, convolution_default_3, primals_25, primals_23, primals_24, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  to_dtype_395 = convolution_default_3 = primals_25 = primals_23 = primals_24 = getitem_12 = getitem_13 = None
        getitem_1328 = native_batch_norm_backward_default_135[0]
        getitem_1329 = native_batch_norm_backward_default_135[1]
        getitem_1330 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1328, getitem_9, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1328 = getitem_9 = primals_31 = None
        getitem_1331 = convolution_backward_default_168[0]
        getitem_1332 = convolution_backward_default_168[1];  convolution_backward_default_168 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_1304, getitem_1331);  getitem_1304 = getitem_1331 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_65, relu__default_2, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_10);  add_tensor_65 = getitem_10 = None
        to_dtype_396 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_271, to_dtype_396);  le_scalar_132 = new_zeros_default_271 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        native_batch_norm_backward_default_136 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_398, convolution_default_2, primals_5, primals_3, primals_4, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_398 = convolution_default_2 = primals_5 = primals_3 = primals_4 = getitem_7 = getitem_8 = None
        getitem_1334 = native_batch_norm_backward_default_136[0]
        getitem_1335 = native_batch_norm_backward_default_136[1]
        getitem_1336 = native_batch_norm_backward_default_136[2];  native_batch_norm_backward_default_136 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1334, relu__default_1, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1334 = primals_18 = None
        getitem_1337 = convolution_backward_default_169[0]
        getitem_1338 = convolution_backward_default_169[1];  convolution_backward_default_169 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_1337, torch.float32);  getitem_1337 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_133 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_133 = torch.ops.aten.where.self(le_scalar_133, new_zeros_default_272, to_dtype_399);  le_scalar_133 = new_zeros_default_272 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_133, torch.float32);  where_self_133 = None
        native_batch_norm_backward_default_137 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_1, primals_17, primals_15, primals_16, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_401 = convolution_default_1 = primals_17 = primals_15 = primals_16 = getitem_4 = getitem_5 = None
        getitem_1340 = native_batch_norm_backward_default_137[0]
        getitem_1341 = native_batch_norm_backward_default_137[1]
        getitem_1342 = native_batch_norm_backward_default_137[2];  native_batch_norm_backward_default_137 = None
        convolution_backward_default_170 = torch.ops.aten.convolution_backward.default(getitem_1340, relu__default, primals_12, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1340 = primals_12 = None
        getitem_1343 = convolution_backward_default_170[0]
        getitem_1344 = convolution_backward_default_170[1];  convolution_backward_default_170 = None
        to_dtype_402 = torch.ops.aten.to.dtype(getitem_1343, torch.float32);  getitem_1343 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_134 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_134 = torch.ops.aten.where.self(le_scalar_134, new_zeros_default_273, to_dtype_402);  le_scalar_134 = new_zeros_default_273 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_134, torch.float32);  where_self_134 = None
        native_batch_norm_backward_default_138 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_404, convolution_default, primals_11, primals_9, primals_10, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_404 = convolution_default = primals_11 = primals_9 = primals_10 = getitem_1 = getitem_2 = None
        getitem_1346 = native_batch_norm_backward_default_138[0]
        getitem_1347 = native_batch_norm_backward_default_138[1]
        getitem_1348 = native_batch_norm_backward_default_138[2];  native_batch_norm_backward_default_138 = None
        convolution_backward_default_171 = torch.ops.aten.convolution_backward.default(getitem_1346, primals_936, primals_6, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1346 = primals_936 = primals_6 = None
        getitem_1350 = convolution_backward_default_171[1];  convolution_backward_default_171 = None
        return [getitem_1336, None, None, None, getitem_1335, getitem_1350, getitem_1348, None, None, None, getitem_1347, getitem_1344, getitem_1342, None, None, None, getitem_1341, getitem_1338, view_default_166, t_default_4, getitem_1330, None, None, None, getitem_1329, getitem_1309, None, None, None, getitem_1308, getitem_1332, getitem_1324, None, None, None, getitem_1323, getitem_1318, None, None, None, getitem_1317, getitem_1326, getitem_1321, getitem_1320, getitem_1315, getitem_1314, getitem_1311, getitem_1305, getitem_1303, None, None, None, getitem_1302, getitem_1297, None, None, None, getitem_1296, getitem_1276, None, None, None, getitem_1275, getitem_1299, getitem_1291, None, None, None, getitem_1290, getitem_1285, None, None, None, getitem_1284, getitem_1293, getitem_1288, getitem_1287, getitem_1282, getitem_1281, getitem_1278, getitem_1270, None, None, None, getitem_1269, getitem_1249, None, None, None, getitem_1248, getitem_1272, getitem_1264, None, None, None, getitem_1263, getitem_1258, None, None, None, getitem_1257, getitem_1266, getitem_1261, getitem_1260, getitem_1255, getitem_1254, getitem_1251, getitem_1243, None, None, None, getitem_1242, getitem_1222, None, None, None, getitem_1221, getitem_1245, getitem_1237, None, None, None, getitem_1236, getitem_1231, None, None, None, getitem_1230, getitem_1239, getitem_1234, getitem_1233, getitem_1228, getitem_1227, getitem_1224, getitem_1218, getitem_1216, None, None, None, getitem_1215, getitem_1210, None, None, None, getitem_1209, getitem_1189, None, None, None, getitem_1188, getitem_1212, getitem_1204, None, None, None, getitem_1203, getitem_1198, None, None, None, getitem_1197, getitem_1206, getitem_1201, getitem_1200, getitem_1195, getitem_1194, getitem_1191, getitem_1183, None, None, None, getitem_1182, getitem_1162, None, None, None, getitem_1161, getitem_1185, getitem_1177, None, None, None, getitem_1176, getitem_1171, None, None, None, getitem_1170, getitem_1179, getitem_1174, getitem_1173, getitem_1168, getitem_1167, getitem_1164, getitem_1156, None, None, None, getitem_1155, getitem_1135, None, None, None, getitem_1134, getitem_1158, getitem_1150, None, None, None, getitem_1149, getitem_1144, None, None, None, getitem_1143, getitem_1152, getitem_1147, getitem_1146, getitem_1141, getitem_1140, getitem_1137, getitem_1129, None, None, None, getitem_1128, getitem_1108, None, None, None, getitem_1107, getitem_1131, getitem_1123, None, None, None, getitem_1122, getitem_1117, None, None, None, getitem_1116, getitem_1125, getitem_1120, getitem_1119, getitem_1114, getitem_1113, getitem_1110, getitem_1104, getitem_1102, None, None, None, getitem_1101, getitem_853, None, None, None, getitem_852, getitem_832, None, None, None, getitem_831, getitem_855, getitem_847, None, None, None, getitem_846, getitem_841, None, None, None, getitem_840, getitem_849, getitem_844, getitem_843, getitem_838, getitem_837, getitem_834, getitem_826, None, None, None, getitem_825, getitem_805, None, None, None, getitem_804, getitem_828, getitem_820, None, None, None, getitem_819, getitem_814, None, None, None, getitem_813, getitem_822, getitem_817, getitem_816, getitem_811, getitem_810, getitem_807, getitem_799, None, None, None, getitem_798, getitem_778, None, None, None, getitem_777, getitem_801, getitem_793, None, None, None, getitem_792, getitem_787, None, None, None, getitem_786, getitem_795, getitem_790, getitem_789, getitem_784, getitem_783, getitem_780, getitem_772, None, None, None, getitem_771, getitem_751, None, None, None, getitem_750, getitem_774, getitem_766, None, None, None, getitem_765, getitem_760, None, None, None, getitem_759, getitem_768, getitem_763, getitem_762, getitem_757, getitem_756, getitem_753, getitem_745, None, None, None, getitem_744, getitem_724, None, None, None, getitem_723, getitem_747, getitem_739, None, None, None, getitem_738, getitem_733, None, None, None, getitem_732, getitem_741, getitem_736, getitem_735, getitem_730, getitem_729, getitem_726, getitem_718, None, None, None, getitem_717, getitem_697, None, None, None, getitem_696, getitem_720, getitem_712, None, None, None, getitem_711, getitem_706, None, None, None, getitem_705, getitem_714, getitem_709, getitem_708, getitem_703, getitem_702, getitem_699, getitem_691, None, None, None, getitem_690, getitem_670, None, None, None, getitem_669, getitem_693, getitem_685, None, None, None, getitem_684, getitem_679, None, None, None, getitem_678, getitem_687, getitem_682, getitem_681, getitem_676, getitem_675, getitem_672, getitem_664, None, None, None, getitem_663, getitem_643, None, None, None, getitem_642, getitem_666, getitem_658, None, None, None, getitem_657, getitem_652, None, None, None, getitem_651, getitem_660, getitem_655, getitem_654, getitem_649, getitem_648, getitem_645, getitem_637, None, None, None, getitem_636, getitem_616, None, None, None, getitem_615, getitem_639, getitem_631, None, None, None, getitem_630, getitem_625, None, None, None, getitem_624, getitem_633, getitem_628, getitem_627, getitem_622, getitem_621, getitem_618, getitem_610, None, None, None, getitem_609, getitem_589, None, None, None, getitem_588, getitem_612, getitem_604, None, None, None, getitem_603, getitem_598, None, None, None, getitem_597, getitem_606, getitem_601, getitem_600, getitem_595, getitem_594, getitem_591, getitem_1096, None, None, None, getitem_1095, getitem_1075, None, None, None, getitem_1074, getitem_1098, getitem_1090, None, None, None, getitem_1089, getitem_1084, None, None, None, getitem_1083, getitem_1092, getitem_1087, getitem_1086, getitem_1081, getitem_1080, getitem_1077, getitem_583, None, None, None, getitem_582, getitem_562, None, None, None, getitem_561, getitem_585, getitem_577, None, None, None, getitem_576, getitem_571, None, None, None, getitem_570, getitem_579, getitem_574, getitem_573, getitem_568, getitem_567, getitem_564, getitem_556, None, None, None, getitem_555, getitem_535, None, None, None, getitem_534, getitem_558, getitem_550, None, None, None, getitem_549, getitem_544, None, None, None, getitem_543, getitem_552, getitem_547, getitem_546, getitem_541, getitem_540, getitem_537, getitem_529, None, None, None, getitem_528, getitem_508, None, None, None, getitem_507, getitem_531, getitem_523, None, None, None, getitem_522, getitem_517, None, None, None, getitem_516, getitem_525, getitem_520, getitem_519, getitem_514, getitem_513, getitem_510, getitem_1069, None, None, None, getitem_1068, getitem_1048, None, None, None, getitem_1047, getitem_1071, getitem_1063, None, None, None, getitem_1062, getitem_1057, None, None, None, getitem_1056, getitem_1065, getitem_1060, getitem_1059, getitem_1054, getitem_1053, getitem_1050, getitem_1042, None, None, None, getitem_1041, getitem_1021, None, None, None, getitem_1020, getitem_1044, getitem_1036, None, None, None, getitem_1035, getitem_1030, None, None, None, getitem_1029, getitem_1038, getitem_1033, getitem_1032, getitem_1027, getitem_1026, getitem_1023, getitem_1015, None, None, None, getitem_1014, getitem_994, None, None, None, getitem_993, getitem_1017, getitem_1009, None, None, None, getitem_1008, getitem_1003, None, None, None, getitem_1002, getitem_1011, getitem_1006, getitem_1005, getitem_1000, getitem_999, getitem_996, getitem_988, None, None, None, getitem_987, getitem_967, None, None, None, getitem_966, getitem_990, getitem_982, None, None, None, getitem_981, getitem_976, None, None, None, getitem_975, getitem_984, getitem_979, getitem_978, getitem_973, getitem_972, getitem_969, getitem_961, None, None, None, getitem_960, getitem_940, None, None, None, getitem_939, getitem_963, getitem_955, None, None, None, getitem_954, getitem_949, None, None, None, getitem_948, getitem_957, getitem_952, getitem_951, getitem_946, getitem_945, getitem_942, getitem_934, None, None, None, getitem_933, getitem_913, None, None, None, getitem_912, getitem_936, getitem_928, None, None, None, getitem_927, getitem_922, None, None, None, getitem_921, getitem_930, getitem_925, getitem_924, getitem_919, getitem_918, getitem_915, getitem_907, None, None, None, getitem_906, getitem_886, None, None, None, getitem_885, getitem_909, getitem_901, None, None, None, getitem_900, getitem_895, None, None, None, getitem_894, getitem_903, getitem_898, getitem_897, getitem_892, getitem_891, getitem_888, getitem_880, None, None, None, getitem_879, getitem_859, None, None, None, getitem_858, getitem_882, getitem_874, None, None, None, getitem_873, getitem_868, None, None, None, getitem_867, getitem_876, getitem_871, getitem_870, getitem_865, getitem_864, getitem_861, getitem_502, None, None, None, getitem_501, getitem_481, None, None, None, getitem_480, getitem_504, getitem_496, None, None, None, getitem_495, getitem_490, None, None, None, getitem_489, getitem_498, getitem_493, getitem_492, getitem_487, getitem_486, getitem_483, getitem_477, getitem_475, None, None, None, getitem_474, getitem_469, None, None, None, getitem_468, getitem_448, None, None, None, getitem_447, getitem_471, getitem_463, None, None, None, getitem_462, getitem_457, None, None, None, getitem_456, getitem_465, getitem_460, getitem_459, getitem_454, getitem_453, getitem_450, getitem_442, None, None, None, getitem_441, getitem_421, None, None, None, getitem_420, getitem_444, getitem_436, None, None, None, getitem_435, getitem_430, None, None, None, getitem_429, getitem_438, getitem_433, getitem_432, getitem_427, getitem_426, getitem_423, None]
        
