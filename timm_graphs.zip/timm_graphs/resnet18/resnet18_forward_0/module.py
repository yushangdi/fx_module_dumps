
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/resnet18/resnet18_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123):
        convolution_default = torch.ops.aten.convolution.default(primals_123, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_19, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, True, 0.1, 1e-05);  primals_9 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_20, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_18, primals_14, primals_16, primals_17, True, 0.1, 1e-05);  primals_14 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_8, getitem_3);  getitem_8 = None
        relu__default_2 = torch.ops.aten.relu_.default(add__tensor_3);  add__tensor_3 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_31, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_25, primals_21, primals_23, primals_24, True, 0.1, 1e-05);  primals_21 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_32, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_30, primals_26, primals_28, primals_29, True, 0.1, 1e-05);  primals_26 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        add__tensor_6 = torch.ops.aten.add_.Tensor(getitem_14, relu__default_2);  getitem_14 = None
        relu__default_4 = torch.ops.aten.relu_.default(add__tensor_6);  add__tensor_6 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_43, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_37, primals_33, primals_35, primals_36, True, 0.1, 1e-05);  primals_33 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_5, primals_44, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_42, primals_38, primals_40, primals_41, True, 0.1, 1e-05);  primals_38 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_4, primals_45, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_50, primals_46, primals_48, primals_49, True, 0.1, 1e-05);  primals_46 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        add__tensor_10 = torch.ops.aten.add_.Tensor(getitem_20, getitem_23);  getitem_20 = getitem_23 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor_10);  add__tensor_10 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_6, primals_61, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_55, primals_51, primals_53, primals_54, True, 0.1, 1e-05);  primals_51 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_62, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_60, primals_56, primals_58, primals_59, True, 0.1, 1e-05);  primals_56 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_29, relu__default_6);  getitem_29 = None
        relu__default_8 = torch.ops.aten.relu_.default(add__tensor_13);  add__tensor_13 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_8, primals_73, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_67, primals_63, primals_65, primals_66, True, 0.1, 1e-05);  primals_63 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_9, primals_74, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_72, primals_68, primals_70, primals_71, True, 0.1, 1e-05);  primals_68 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_8, primals_75, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_80, primals_76, primals_78, primals_79, True, 0.1, 1e-05);  primals_76 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        add__tensor_17 = torch.ops.aten.add_.Tensor(getitem_35, getitem_38);  getitem_35 = getitem_38 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_17);  add__tensor_17 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_10, primals_91, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_11, primals_92, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_90, primals_86, primals_88, primals_89, True, 0.1, 1e-05);  primals_86 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add__tensor_20 = torch.ops.aten.add_.Tensor(getitem_44, relu__default_10);  getitem_44 = None
        relu__default_12 = torch.ops.aten.relu_.default(add__tensor_20);  add__tensor_20 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_12, primals_103, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_97, primals_93, primals_95, primals_96, True, 0.1, 1e-05);  primals_93 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_13, primals_104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_102, primals_98, primals_100, primals_101, True, 0.1, 1e-05);  primals_98 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_12, primals_105, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_110, primals_106, primals_108, primals_109, True, 0.1, 1e-05);  primals_106 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        add__tensor_24 = torch.ops.aten.add_.Tensor(getitem_50, getitem_53);  getitem_50 = getitem_53 = None
        relu__default_14 = torch.ops.aten.relu_.default(add__tensor_24);  add__tensor_24 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_14, primals_121, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_115, primals_111, primals_113, primals_114, True, 0.1, 1e-05);  primals_111 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_15, primals_122, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_120, primals_116, primals_118, primals_119, True, 0.1, 1e-05);  primals_116 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        add__tensor_27 = torch.ops.aten.add_.Tensor(getitem_59, relu__default_14);  getitem_59 = None
        relu__default_16 = torch.ops.aten.relu_.default(add__tensor_27);  add__tensor_27 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_16, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 512]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        return [addmm_default, primals_45, primals_11, primals_115, getitem_55, primals_74, primals_3, primals_60, primals_95, getitem_10, primals_5, primals_88, primals_114, convolution_default_3, primals_4, primals_49, primals_96, convolution_default_18, convolution_default_19, relu__default_2, primals_12, primals_97, primals_113, getitem_19, getitem_54, getitem_18, primals_123, primals_16, primals_48, getitem_58, primals_79, primals_100, getitem_57, primals_118, getitem_13, relu__default_5, primals_54, primals_119, getitem_12, primals_101, primals_40, primals_50, primals_18, primals_102, primals_19, primals_53, convolution_default_6, primals_37, relu__default_15, primals_61, primals_103, primals_32, primals_43, primals_55, primals_6, relu__default_3, primals_20, primals_108, relu__default_6, primals_83, primals_104, primals_120, primals_75, primals_58, primals_30, primals_121, primals_105, primals_29, getitem_22, primals_42, convolution_default_4, getitem_21, primals_31, primals_23, primals_80, primals_44, primals_73, primals_28, primals_72, primals_65, primals_59, primals_17, primals_70, primals_90, convolution_default_7, getitem_60, primals_71, primals_85, primals_110, primals_91, getitem_61, primals_109, primals_35, primals_66, primals_84, convolution_default, primals_24, primals_67, primals_92, primals_78, getitem_15, getitem_16, relu__default_16, primals_122, primals_25, primals_36, relu__default_4, primals_13, convolution_default_5, primals_41, primals_62, primals_89, getitem_2, getitem_40, view_default, convolution_default_8, relu__default, getitem_24, convolution_default_13, getitem_1, convolution_default_14, getitem_49, getitem_34, getitem_48, getitem_33, getitem_3, getitem_25, t_default, convolution_default_1, getitem_43, relu__default_13, getitem_28, relu__default_9, getitem_42, getitem_27, convolution_default_16, convolution_default_11, getitem_4, getitem_7, relu__default_11, relu__default_7, getitem_6, relu__default_10, getitem_52, getitem_39, getitem_37, getitem_51, getitem_36, convolution_default_9, relu__default_1, relu__default_14, convolution_default_17, convolution_default_12, getitem_45, convolution_default_2, getitem_46, getitem_30, relu__default_8, getitem_31, convolution_default_15, convolution_default_10, relu__default_12, getitem_9]
        
