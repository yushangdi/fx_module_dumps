
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/spnasnet_100/spnasnet_100_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387):
        convolution_default = torch.ops.aten.convolution.default(primals_67, primals_66, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_68, 1);  primals_68 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_71, primals_72, primals_69, primals_70, True, 0.1, 1e-05);  primals_72 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_73, 1);  primals_73 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_76, primals_77, primals_74, primals_75, True, 0.1, 1e-05);  primals_77 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_78, 1);  primals_78 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_81, primals_82, primals_79, primals_80, True, 0.1, 1e-05);  primals_82 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_6, primals_4, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_83, 1);  primals_83 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_86, primals_87, primals_84, primals_85, True, 0.1, 1e-05);  primals_87 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_2, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 48)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_88, 1);  primals_88 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_91, primals_92, primals_89, primals_90, True, 0.1, 1e-05);  primals_92 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_3, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_93, 1);  primals_93 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_96, primals_97, primals_94, primals_95, True, 0.1, 1e-05);  primals_97 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_98, 1);  primals_98 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_101, primals_102, primals_99, primals_100, True, 0.1, 1e-05);  primals_102 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_4, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 72)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_103, 1);  primals_103 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_106, primals_107, primals_104, primals_105, True, 0.1, 1e-05);  primals_107 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_108, 1);  primals_108 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_111, primals_112, primals_109, primals_110, True, 0.1, 1e-05);  primals_112 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_24, getitem_15);  getitem_24 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor_9, primals_10, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_113, 1);  primals_113 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_116, primals_117, primals_114, primals_115, True, 0.1, 1e-05);  primals_117 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_6, primals_9, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 72)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_118, 1);  primals_118 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_121, primals_122, primals_119, primals_120, True, 0.1, 1e-05);  primals_122 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_7, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_123, 1);  primals_123 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_126, primals_127, primals_124, primals_125, True, 0.1, 1e-05);  primals_127 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(getitem_33, add_tensor_9);  getitem_33 = None
        convolution_default_12 = torch.ops.aten.convolution.default(add_tensor_13, primals_13, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_128, 1);  primals_128 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_131, primals_132, primals_129, primals_130, True, 0.1, 1e-05);  primals_132 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_8, primals_12, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 144)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_133, 1);  primals_133 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_136, primals_137, primals_134, primals_135, True, 0.1, 1e-05);  primals_137 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_9, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_138, 1);  primals_138 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_141, primals_142, primals_139, primals_140, True, 0.1, 1e-05);  primals_142 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        convolution_default_15 = torch.ops.aten.convolution.default(getitem_42, primals_16, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_143, 1);  primals_143 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_146, primals_147, primals_144, primals_145, True, 0.1, 1e-05);  primals_147 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_10, primals_15, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_148, 1);  primals_148 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_151, primals_152, primals_149, primals_150, True, 0.1, 1e-05);  primals_152 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_11, primals_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_153, 1);  primals_153 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_156, primals_157, primals_154, primals_155, True, 0.1, 1e-05);  primals_157 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(getitem_51, getitem_42);  getitem_51 = None
        convolution_default_18 = torch.ops.aten.convolution.default(add_tensor_20, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_158, 1);  primals_158 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_161, primals_162, primals_159, primals_160, True, 0.1, 1e-05);  primals_162 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_12, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_163, 1);  primals_163 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_166, primals_167, primals_164, primals_165, True, 0.1, 1e-05);  primals_167 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_13, primals_20, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_168, 1);  primals_168 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_171, primals_172, primals_169, primals_170, True, 0.1, 1e-05);  primals_172 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_60, add_tensor_20);  getitem_60 = None
        convolution_default_21 = torch.ops.aten.convolution.default(add_tensor_24, primals_22, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_173, 1);  primals_173 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_176, primals_177, primals_174, primals_175, True, 0.1, 1e-05);  primals_177 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_63);  getitem_63 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_14, primals_21, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_178, 1);  primals_178 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_181, primals_182, primals_179, primals_180, True, 0.1, 1e-05);  primals_182 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_15, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_27 = torch.ops.aten.add.Tensor(primals_183, 1);  primals_183 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_186, primals_187, primals_184, primals_185, True, 0.1, 1e-05);  primals_187 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(getitem_69, add_tensor_24);  getitem_69 = None
        convolution_default_24 = torch.ops.aten.convolution.default(add_tensor_28, primals_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_188, 1);  primals_188 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_191, primals_192, primals_189, primals_190, True, 0.1, 1e-05);  primals_192 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_16, primals_24, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 240)
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_193, 1);  primals_193 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_196, primals_197, primals_194, primals_195, True, 0.1, 1e-05);  primals_197 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_17, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_198, 1);  primals_198 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_201, primals_202, primals_199, primals_200, True, 0.1, 1e-05);  primals_202 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        convolution_default_27 = torch.ops.aten.convolution.default(getitem_78, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_203, 1);  primals_203 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_206, primals_207, primals_204, primals_205, True, 0.1, 1e-05);  primals_207 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_81);  getitem_81 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_18, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 240)
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_208, 1);  primals_208 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_211, primals_212, primals_209, primals_210, True, 0.1, 1e-05);  primals_212 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_84);  getitem_84 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_19, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_34 = torch.ops.aten.add.Tensor(primals_213, 1);  primals_213 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_216, primals_217, primals_214, primals_215, True, 0.1, 1e-05);  primals_217 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_87, getitem_78);  getitem_87 = None
        convolution_default_30 = torch.ops.aten.convolution.default(add_tensor_35, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_218, 1);  primals_218 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_221, primals_222, primals_219, primals_220, True, 0.1, 1e-05);  primals_222 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_20, primals_30, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 240)
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_223, 1);  primals_223 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_226, primals_227, primals_224, primals_225, True, 0.1, 1e-05);  primals_227 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_21, primals_32, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_38 = torch.ops.aten.add.Tensor(primals_228, 1);  primals_228 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_231, primals_232, primals_229, primals_230, True, 0.1, 1e-05);  primals_232 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_96, add_tensor_35);  getitem_96 = None
        convolution_default_33 = torch.ops.aten.convolution.default(add_tensor_39, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_233, 1);  primals_233 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_236, primals_237, primals_234, primals_235, True, 0.1, 1e-05);  primals_237 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_99);  getitem_99 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_22, primals_33, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 240)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_238, 1);  primals_238 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_241, primals_242, primals_239, primals_240, True, 0.1, 1e-05);  primals_242 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_23, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_42 = torch.ops.aten.add.Tensor(primals_243, 1);  primals_243 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_246, primals_247, primals_244, primals_245, True, 0.1, 1e-05);  primals_247 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(getitem_105, add_tensor_39);  getitem_105 = None
        convolution_default_36 = torch.ops.aten.convolution.default(add_tensor_43, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_248, 1);  primals_248 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_251, primals_252, primals_249, primals_250, True, 0.1, 1e-05);  primals_252 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_24, primals_36, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 480)
        add_tensor_45 = torch.ops.aten.add.Tensor(primals_253, 1);  primals_253 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_256, primals_257, primals_254, primals_255, True, 0.1, 1e-05);  primals_257 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_25, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_258, 1);  primals_258 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_261, primals_262, primals_259, primals_260, True, 0.1, 1e-05);  primals_262 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        convolution_default_39 = torch.ops.aten.convolution.default(getitem_114, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_263, 1);  primals_263 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_266, primals_267, primals_264, primals_265, True, 0.1, 1e-05);  primals_267 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_117);  getitem_117 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_26, primals_39, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 288)
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_268, 1);  primals_268 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_271, primals_272, primals_269, primals_270, True, 0.1, 1e-05);  primals_272 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_27, primals_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_49 = torch.ops.aten.add.Tensor(primals_273, 1);  primals_273 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_276, primals_277, primals_274, primals_275, True, 0.1, 1e-05);  primals_277 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(getitem_123, getitem_114);  getitem_123 = None
        convolution_default_42 = torch.ops.aten.convolution.default(add_tensor_50, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_278, 1);  primals_278 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_281, primals_282, primals_279, primals_280, True, 0.1, 1e-05);  primals_282 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_28, primals_42, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 288)
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_283, 1);  primals_283 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_286, primals_287, primals_284, primals_285, True, 0.1, 1e-05);  primals_287 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_129);  getitem_129 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_29, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_53 = torch.ops.aten.add.Tensor(primals_288, 1);  primals_288 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_291, primals_292, primals_289, primals_290, True, 0.1, 1e-05);  primals_292 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(getitem_132, add_tensor_50);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(add_tensor_54, primals_46, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_55 = torch.ops.aten.add.Tensor(primals_293, 1);  primals_293 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_296, primals_297, primals_294, primals_295, True, 0.1, 1e-05);  primals_297 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_30, primals_45, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 288)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_298, 1);  primals_298 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_301, primals_302, primals_299, primals_300, True, 0.1, 1e-05);  primals_302 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_31, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_303, 1);  primals_303 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_306, primals_307, primals_304, primals_305, True, 0.1, 1e-05);  primals_307 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(getitem_141, add_tensor_54);  getitem_141 = None
        convolution_default_48 = torch.ops.aten.convolution.default(add_tensor_58, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_59 = torch.ops.aten.add.Tensor(primals_308, 1);  primals_308 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_311, primals_312, primals_309, primals_310, True, 0.1, 1e-05);  primals_312 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_32, primals_48, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 576)
        add_tensor_60 = torch.ops.aten.add.Tensor(primals_313, 1);  primals_313 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_316, primals_317, primals_314, primals_315, True, 0.1, 1e-05);  primals_317 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_147);  getitem_147 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_33, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_318, 1);  primals_318 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_321, primals_322, primals_319, primals_320, True, 0.1, 1e-05);  primals_322 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        convolution_default_51 = torch.ops.aten.convolution.default(getitem_150, primals_52, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_62 = torch.ops.aten.add.Tensor(primals_323, 1);  primals_323 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_326, primals_327, primals_324, primals_325, True, 0.1, 1e-05);  primals_327 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_153);  getitem_153 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_34, primals_51, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        add_tensor_63 = torch.ops.aten.add.Tensor(primals_328, 1);  primals_328 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_331, primals_332, primals_329, primals_330, True, 0.1, 1e-05);  primals_332 = None
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_35, primals_53, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_64 = torch.ops.aten.add.Tensor(primals_333, 1);  primals_333 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_336, primals_337, primals_334, primals_335, True, 0.1, 1e-05);  primals_337 = None
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_159, getitem_150);  getitem_159 = None
        convolution_default_54 = torch.ops.aten.convolution.default(add_tensor_65, primals_55, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_66 = torch.ops.aten.add.Tensor(primals_338, 1);  primals_338 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_341, primals_342, primals_339, primals_340, True, 0.1, 1e-05);  primals_342 = None
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_36, primals_54, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        add_tensor_67 = torch.ops.aten.add.Tensor(primals_343, 1);  primals_343 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_346, primals_347, primals_344, primals_345, True, 0.1, 1e-05);  primals_347 = None
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_165);  getitem_165 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_37, primals_56, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_68 = torch.ops.aten.add.Tensor(primals_348, 1);  primals_348 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_351, primals_352, primals_349, primals_350, True, 0.1, 1e-05);  primals_352 = None
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(getitem_168, add_tensor_65);  getitem_168 = None
        convolution_default_57 = torch.ops.aten.convolution.default(add_tensor_69, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_70 = torch.ops.aten.add.Tensor(primals_353, 1);  primals_353 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_356, primals_357, primals_354, primals_355, True, 0.1, 1e-05);  primals_357 = None
        getitem_171 = native_batch_norm_default_57[0]
        getitem_172 = native_batch_norm_default_57[1]
        getitem_173 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_171);  getitem_171 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_38, primals_57, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        add_tensor_71 = torch.ops.aten.add.Tensor(primals_358, 1);  primals_358 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_361, primals_362, primals_359, primals_360, True, 0.1, 1e-05);  primals_362 = None
        getitem_174 = native_batch_norm_default_58[0]
        getitem_175 = native_batch_norm_default_58[1]
        getitem_176 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_39, primals_59, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_72 = torch.ops.aten.add.Tensor(primals_363, 1);  primals_363 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_366, primals_367, primals_364, primals_365, True, 0.1, 1e-05);  primals_367 = None
        getitem_177 = native_batch_norm_default_59[0]
        getitem_178 = native_batch_norm_default_59[1]
        getitem_179 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(getitem_177, add_tensor_69);  getitem_177 = None
        convolution_default_60 = torch.ops.aten.convolution.default(add_tensor_73, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_74 = torch.ops.aten.add.Tensor(primals_368, 1);  primals_368 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_371, primals_372, primals_369, primals_370, True, 0.1, 1e-05);  primals_372 = None
        getitem_180 = native_batch_norm_default_60[0]
        getitem_181 = native_batch_norm_default_60[1]
        getitem_182 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_180);  getitem_180 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_40, primals_60, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1152)
        add_tensor_75 = torch.ops.aten.add.Tensor(primals_373, 1);  primals_373 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_376, primals_377, primals_374, primals_375, True, 0.1, 1e-05);  primals_377 = None
        getitem_183 = native_batch_norm_default_61[0]
        getitem_184 = native_batch_norm_default_61[1]
        getitem_185 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_183);  getitem_183 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_41, primals_62, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_76 = torch.ops.aten.add.Tensor(primals_378, 1);  primals_378 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_381, primals_382, primals_379, primals_380, True, 0.1, 1e-05);  primals_382 = None
        getitem_186 = native_batch_norm_default_62[0]
        getitem_187 = native_batch_norm_default_62[1]
        getitem_188 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        convolution_default_63 = torch.ops.aten.convolution.default(getitem_186, primals_65, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_77 = torch.ops.aten.add.Tensor(primals_383, 1);  primals_383 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_386, primals_387, primals_384, primals_385, True, 0.1, 1e-05);  primals_387 = None
        getitem_189 = native_batch_norm_default_63[0]
        getitem_190 = native_batch_norm_default_63[1]
        getitem_191 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_189);  getitem_189 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_42, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 1280]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_64);  primals_64 = None
        addmm_default = torch.ops.aten.addmm.default(primals_63, view_default, t_default);  primals_63 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_21, add_tensor_22, add_tensor_23, add_tensor_25, add_tensor_26, add_tensor_27, add_tensor_29, add_tensor_30, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_34, add_tensor_36, add_tensor_37, add_tensor_38, add_tensor_40, add_tensor_41, add_tensor_42, add_tensor_44, add_tensor_45, add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_49, add_tensor_51, add_tensor_52, add_tensor_53, add_tensor_55, add_tensor_56, add_tensor_57, add_tensor_59, add_tensor_60, add_tensor_61, add_tensor_62, add_tensor_63, add_tensor_64, add_tensor_66, add_tensor_67, add_tensor_68, add_tensor_70, add_tensor_71, add_tensor_72, add_tensor_74, add_tensor_75, add_tensor_76, add_tensor_77, primals_119, primals_114, add_tensor_24, getitem_44, primals_136, getitem_62, primals_94, convolution_default_30, primals_171, convolution_default_15, getitem_100, convolution_default_33, getitem_149, getitem_101, getitem_185, add_tensor_35, primals_170, convolution_default_22, getitem_89, getitem_98, relu__default_33, primals_96, getitem_47, getitem_67, getitem_46, convolution_default_21, add_tensor_39, getitem_64, relu__default_40, convolution_default_62, convolution_default_29, convolution_default_50, getitem_148, getitem_184, primals_111, getitem_88, relu__default_19, primals_116, primals_135, convolution_default_35, getitem_146, getitem_182, primals_169, getitem_97, primals_115, primals_134, getitem_85, relu__default_22, relu__default_32, convolution_default_34, getitem_86, getitem_103, primals_95, primals_90, getitem_61, primals_91, convolution_default_49, getitem_181, getitem_65, convolution_default_28, primals_110, getitem_68, convolution_default_61, relu__default_18, relu__default_14, getitem_104, getitem_145, getitem_167, primals_130, primals_184, relu__default_23, primals_159, primals_236, getitem_2, primals_235, primals_230, getitem_1, primals_161, primals_229, primals_129, primals_186, primals_231, primals_125, relu__default, getitem_4, convolution_default_1, primals_160, primals_191, primals_131, primals_225, primals_224, getitem_5, getitem_166, primals_234, primals_226, convolution_default_56, convolution_default_57, primals_126, relu__default_1, convolution_default_43, primals_221, convolution_default_2, primals_185, relu__default_37, primals_260, primals_261, primals_324, getitem_82, getitem_76, primals_325, primals_326, getitem_77, primals_264, primals_265, primals_329, primals_266, convolution_default_27, getitem_83, primals_330, getitem_78, primals_38, primals_166, primals_331, primals_165, primals_269, primals_40, primals_270, relu__default_17, primals_334, primals_271, primals_195, primals_335, primals_336, convolution_default_26, primals_41, primals_37, primals_274, primals_275, getitem_80, primals_276, primals_339, primals_39, primals_199, primals_164, primals_340, getitem_79, primals_341, primals_279, primals_36, primals_280, primals_42, primals_281, getitem_59, getitem_140, primals_144, primals_215, relu__default_6, primals_27, getitem_50, primals_214, relu__default_10, convolution_default_19, primals_120, primals_149, add_tensor_54, convolution_default_10, relu__default_30, primals_80, primals_284, primals_150, getitem_137, convolution_default_48, convolution_default_16, primals_60, primals_285, relu__default_12, primals_194, primals_286, primals_141, primals_211, relu__default_31, getitem_32, primals_65, primals_210, getitem_31, primals_209, primals_66, primals_121, primals_289, getitem_55, primals_290, getitem_56, primals_206, primals_291, primals_81, relu__default_7, primals_101, primals_205, primals_196, primals_204, getitem_34, convolution_default_11, primals_139, primals_61, primals_294, primals_79, primals_124, convolution_default_20, primals_295, primals_69, primals_201, primals_296, primals_62, primals_216, getitem_35, getitem_58, primals_67, convolution_default_46, primals_189, primals_190, primals_140, primals_299, add_tensor_13, primals_145, primals_300, relu__default_13, primals_219, convolution_default_12, getitem_136, getitem_139, primals_146, primals_301, primals_220, convolution_default_47, primals_181, getitem_191, relu__default_16, getitem_109, convolution_default_51, convolution_default, relu__default_34, getitem_155, primals_3, getitem_173, primals_4, getitem_110, getitem_170, primals_156, getitem_73, getitem_74, view_default, primals_154, getitem_172, getitem_107, t_default, add_tensor_28, getitem_106, relu__default_38, getitem_152, add_tensor_69, primals_151, primals_1, convolution_default_36, getitem_70, convolution_default_63, getitem_154, convolution_default_58, convolution_default_24, getitem_190, getitem_71, add_tensor_43, convolution_default_52, getitem_169, relu__default_15, primals_2, convolution_default_25, primals_155, getitem_151, convolution_default_23, getitem_150, relu__default_42, primals_239, primals_344, primals_99, primals_100, primals_240, primals_345, getitem_38, getitem_164, primals_241, primals_346, relu__default_3, getitem_37, convolution_default_5, primals_89, getitem_15, primals_44, relu__default_26, primals_244, primals_349, primals_245, primals_350, getitem_17, relu__default_8, getitem_143, getitem_16, primals_246, primals_351, primals_54, primals_43, convolution_default_13, add_tensor_58, getitem_121, primals_45, relu__default_27, primals_249, primals_354, convolution_default_40, getitem_41, convolution_default_6, primals_250, primals_355, getitem_40, getitem_122, primals_251, primals_356, primals_59, getitem_20, getitem_49, relu__default_36, primals_200, getitem_19, primals_86, primals_55, convolution_default_41, primals_359, relu__default_9, primals_58, primals_254, primals_360, getitem_142, primals_255, convolution_default_14, primals_361, primals_256, getitem_42, primals_57, relu__default_4, primals_56, getitem_119, primals_84, convolution_default_7, primals_364, primals_85, primals_259, getitem_118, convolution_default_55, getitem_43, convolution_default_39, primals_105, relu__default_29, convolution_default_18, primals_5, getitem_157, getitem_8, primals_304, getitem_158, getitem_7, primals_305, primals_34, primals_306, primals_32, primals_13, primals_174, convolution_default_17, getitem_186, convolution_default_3, getitem_134, primals_28, primals_106, primals_50, primals_309, getitem_133, primals_17, primals_18, primals_46, convolution_default_53, primals_76, primals_310, primals_75, getitem_11, relu__default_11, getitem_161, primals_14, primals_311, getitem_6, primals_53, getitem_10, add_tensor_20, primals_6, primals_12, relu__default_41, getitem_115, getitem_131, getitem_52, getitem_160, primals_176, primals_29, primals_31, primals_314, convolution_default_45, primals_16, primals_104, convolution_default_44, getitem_188, primals_9, primals_33, primals_51, primals_315, relu__default_2, primals_316, getitem_187, primals_48, getitem_114, add_tensor_65, primals_15, convolution_default_4, primals_49, convolution_default_54, primals_11, primals_52, primals_7, primals_47, primals_35, primals_74, primals_319, getitem_53, primals_320, primals_8, primals_321, getitem_116, relu__default_35, getitem_13, primals_10, primals_30, getitem_14, getitem_130, primals_109, getitem_163, primals_365, primals_386, convolution_default_37, primals_23, primals_366, convolution_default_38, getitem_179, getitem_23, relu__default_21, getitem_22, relu__default_28, primals_20, getitem_112, convolution_default_32, primals_369, convolution_default_60, primals_370, relu__default_24, relu__default_5, primals_70, primals_371, primals_25, getitem_94, convolution_default_8, convolution_default_59, primals_374, getitem_128, primals_375, getitem_113, getitem_178, getitem_26, primals_179, primals_180, primals_376, getitem_25, getitem_95, primals_21, add_tensor_73, getitem_175, primals_22, convolution_default_31, primals_379, primals_175, primals_24, convolution_default_9, primals_380, add_tensor_9, relu__default_20, primals_26, convolution_default_42, primals_381, primals_71, getitem_127, getitem_176, add_tensor_50, primals_19, primals_384, relu__default_25, getitem_124, getitem_28, relu__default_39, getitem_29, getitem_91, primals_385, getitem_125, getitem_92]
        
