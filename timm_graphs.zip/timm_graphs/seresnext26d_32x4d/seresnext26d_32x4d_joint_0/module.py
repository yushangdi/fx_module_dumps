
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/seresnext26d_32x4d/seresnext26d_32x4d_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_221, primals_6, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_8, 1);  primals_8 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_11, primals_7, primals_9, primals_10, True, 0.1, 1e-05);  primals_7 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_14, 1);  primals_14 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_17, primals_13, primals_15, primals_16, True, 0.1, 1e-05);  primals_13 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2], [1, 1])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_22, 1);  primals_22 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_25, primals_21, primals_23, primals_24, True, 0.1, 1e-05);  primals_21 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_27, 1);  primals_27 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_30, primals_26, primals_28, primals_29, True, 0.1, 1e-05);  primals_26 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_32, 1);  primals_32 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_35, primals_31, primals_33, primals_34, True, 0.1, 1e-05);  primals_31 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim = torch.ops.aten.mean.dim(getitem_17, [2, 3], True)
        convolution_default_6 = torch.ops.aten.convolution.default(mean_dim, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_6);  convolution_default_6 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_7);  convolution_default_7 = None
        mul_tensor = torch.ops.aten.mul.Tensor(getitem_17, sigmoid_default)
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_9, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_41, 1);  primals_41 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_7 = torch.ops.aten.add_.Tensor(mul_tensor, getitem_20);  mul_tensor = getitem_20 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_50, 1);  primals_50 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_53, primals_49, primals_51, primals_52, True, 0.1, 1e-05);  primals_49 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_7, primals_65, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_55, 1);  primals_55 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_58, primals_54, primals_56, primals_57, True, 0.1, 1e-05);  primals_54 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_8, primals_66, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_60, 1);  primals_60 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_63, primals_59, primals_61, primals_62, True, 0.1, 1e-05);  primals_59 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_1 = torch.ops.aten.mean.dim(getitem_29, [2, 3], True)
        convolution_default_12 = torch.ops.aten.convolution.default(mean_dim_1, primals_68, primals_67, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_67 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_12);  convolution_default_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_9, primals_70, primals_69, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_69 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_13);  convolution_default_13 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(getitem_29, sigmoid_default_1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(mul_tensor_1, relu__default_6);  mul_tensor_1 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_11);  add__tensor_11 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_10, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_72, 1);  primals_72 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_75, primals_71, primals_73, primals_74, True, 0.1, 1e-05);  primals_71 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_11, primals_87, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_77, 1);  primals_77 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_80, primals_76, primals_78, primals_79, True, 0.1, 1e-05);  primals_76 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_12, primals_88, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_14 = torch.ops.aten.add_.Tensor(primals_82, 1);  primals_82 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_2 = torch.ops.aten.mean.dim(getitem_38, [2, 3], True)
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_2, primals_96, primals_95, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_95 = None
        relu__default_13 = torch.ops.aten.relu_.default(convolution_default_17);  convolution_default_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_13, primals_98, primals_97, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_97 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_18);  convolution_default_18 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(getitem_38, sigmoid_default_2)
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(relu__default_10, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_19 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_89, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_91, 1);  primals_91 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_94, primals_90, primals_92, primals_93, True, 0.1, 1e-05);  primals_90 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_16 = torch.ops.aten.add_.Tensor(mul_tensor_2, getitem_41);  mul_tensor_2 = getitem_41 = None
        relu__default_14 = torch.ops.aten.relu_.default(add__tensor_16);  add__tensor_16 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_14, primals_114, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_100, 1);  primals_100 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_103, primals_99, primals_101, primals_102, True, 0.1, 1e-05);  primals_99 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_15, primals_115, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_105, 1);  primals_105 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_108, primals_104, primals_106, primals_107, True, 0.1, 1e-05);  primals_104 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_16, primals_116, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_19 = torch.ops.aten.add_.Tensor(primals_110, 1);  primals_110 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_113, primals_109, primals_111, primals_112, True, 0.1, 1e-05);  primals_109 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_3 = torch.ops.aten.mean.dim(getitem_50, [2, 3], True)
        convolution_default_23 = torch.ops.aten.convolution.default(mean_dim_3, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        relu__default_17 = torch.ops.aten.relu_.default(convolution_default_23);  convolution_default_23 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_17, primals_120, primals_119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_119 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_24);  convolution_default_24 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(getitem_50, sigmoid_default_3)
        add__tensor_20 = torch.ops.aten.add_.Tensor(mul_tensor_3, relu__default_14);  mul_tensor_3 = None
        relu__default_18 = torch.ops.aten.relu_.default(add__tensor_20);  add__tensor_20 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_18, primals_136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_122, 1);  primals_122 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_125, primals_121, primals_123, primals_124, True, 0.1, 1e-05);  primals_121 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_19, primals_137, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_127, 1);  primals_127 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_130, primals_126, primals_128, primals_129, True, 0.1, 1e-05);  primals_126 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_20, primals_138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_23 = torch.ops.aten.add_.Tensor(primals_132, 1);  primals_132 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_135, primals_131, primals_133, primals_134, True, 0.1, 1e-05);  primals_131 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_4 = torch.ops.aten.mean.dim(getitem_59, [2, 3], True)
        convolution_default_28 = torch.ops.aten.convolution.default(mean_dim_4, primals_146, primals_145, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_145 = None
        relu__default_21 = torch.ops.aten.relu_.default(convolution_default_28);  convolution_default_28 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_21, primals_148, primals_147, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_147 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_29);  convolution_default_29 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(getitem_59, sigmoid_default_4)
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(relu__default_18, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_30 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_139, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_24 = torch.ops.aten.add_.Tensor(primals_141, 1);  primals_141 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_144, primals_140, primals_142, primals_143, True, 0.1, 1e-05);  primals_140 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_25 = torch.ops.aten.add_.Tensor(mul_tensor_4, getitem_62);  mul_tensor_4 = getitem_62 = None
        relu__default_22 = torch.ops.aten.relu_.default(add__tensor_25);  add__tensor_25 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_22, primals_164, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_26 = torch.ops.aten.add_.Tensor(primals_150, 1);  primals_150 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_153, primals_149, primals_151, primals_152, True, 0.1, 1e-05);  primals_149 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_23, primals_165, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_155, 1);  primals_155 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_158, primals_154, primals_156, primals_157, True, 0.1, 1e-05);  primals_154 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_24, primals_166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_28 = torch.ops.aten.add_.Tensor(primals_160, 1);  primals_160 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_163, primals_159, primals_161, primals_162, True, 0.1, 1e-05);  primals_159 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_5 = torch.ops.aten.mean.dim(getitem_71, [2, 3], True)
        convolution_default_34 = torch.ops.aten.convolution.default(mean_dim_5, primals_168, primals_167, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_167 = None
        relu__default_25 = torch.ops.aten.relu_.default(convolution_default_34);  convolution_default_34 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_25, primals_170, primals_169, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_169 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_35);  convolution_default_35 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(getitem_71, sigmoid_default_5)
        add__tensor_29 = torch.ops.aten.add_.Tensor(mul_tensor_5, relu__default_22);  mul_tensor_5 = None
        relu__default_26 = torch.ops.aten.relu_.default(add__tensor_29);  add__tensor_29 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_26, primals_186, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_172, 1);  primals_172 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_175, primals_171, primals_173, primals_174, True, 0.1, 1e-05);  primals_171 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_27, primals_187, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_177, 1);  primals_177 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_180, primals_176, primals_178, primals_179, True, 0.1, 1e-05);  primals_176 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_28, primals_188, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_32 = torch.ops.aten.add_.Tensor(primals_182, 1);  primals_182 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_185, primals_181, primals_183, primals_184, True, 0.1, 1e-05);  primals_181 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_6 = torch.ops.aten.mean.dim(getitem_80, [2, 3], True)
        convolution_default_39 = torch.ops.aten.convolution.default(mean_dim_6, primals_196, primals_195, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_195 = None
        relu__default_29 = torch.ops.aten.relu_.default(convolution_default_39);  convolution_default_39 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_29, primals_198, primals_197, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_197 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_40);  convolution_default_40 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(getitem_80, sigmoid_default_6)
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(relu__default_26, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_41 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_189, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_191, 1);  primals_191 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_194, primals_190, primals_192, primals_193, True, 0.1, 1e-05);  primals_190 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_34 = torch.ops.aten.add_.Tensor(mul_tensor_6, getitem_83);  mul_tensor_6 = getitem_83 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_34);  add__tensor_34 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_30, primals_214, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_35 = torch.ops.aten.add_.Tensor(primals_200, 1);  primals_200 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_203, primals_199, primals_201, primals_202, True, 0.1, 1e-05);  primals_199 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_31, primals_215, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add__tensor_36 = torch.ops.aten.add_.Tensor(primals_205, 1);  primals_205 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_208, primals_204, primals_206, primals_207, True, 0.1, 1e-05);  primals_204 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_32, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_210, 1);  primals_210 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_213, primals_209, primals_211, primals_212, True, 0.1, 1e-05);  primals_209 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_7 = torch.ops.aten.mean.dim(getitem_92, [2, 3], True)
        convolution_default_45 = torch.ops.aten.convolution.default(mean_dim_7, primals_218, primals_217, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_217 = None
        relu__default_33 = torch.ops.aten.relu_.default(convolution_default_45);  convolution_default_45 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_33, primals_220, primals_219, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_219 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_46);  convolution_default_46 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(getitem_92, sigmoid_default_7)
        add__tensor_38 = torch.ops.aten.add_.Tensor(mul_tensor_7, relu__default_30);  mul_tensor_7 = None
        relu__default_34 = torch.ops.aten.relu_.default(add__tensor_38);  add__tensor_38 = None
        mean_dim_8 = torch.ops.aten.mean.dim(relu__default_34, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_8, [128, 2048]);  mean_dim_8 = None
        t_default = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default = torch.ops.aten.addmm.default(primals_19, view_default, t_default);  primals_19 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 2048, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_31, to_dtype);  le_scalar = new_zeros_default_31 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(to_dtype_2, getitem_92);  getitem_92 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_2, sigmoid_default_7)
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_8, [2, 3], True);  mul_tensor_8 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_10 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar);  to_dtype_4 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_10);  mul_tensor_10 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_11, torch.float32);  mul_tensor_11 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_5, relu__default_33, primals_220, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = primals_220 = None
        getitem_95 = convolution_backward_default[0]
        getitem_96 = convolution_backward_default[1]
        getitem_97 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_95, torch.float32);  getitem_95 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_32, to_dtype_6);  le_scalar_1 = new_zeros_default_32 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_7, primals_218, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_7 = primals_218 = None
        getitem_98 = convolution_backward_default_1[0]
        getitem_99 = convolution_backward_default_1[1]
        getitem_100 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_98, [128, 2048, 7, 7]);  getitem_98 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_9, div_scalar_1);  mul_tensor_9 = div_scalar_1 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(add_tensor, convolution_default_44, primals_213, primals_211, primals_212, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  add_tensor = convolution_default_44 = primals_213 = primals_211 = primals_212 = getitem_93 = getitem_94 = None
        getitem_101 = native_batch_norm_backward_default[0]
        getitem_102 = native_batch_norm_backward_default[1]
        getitem_103 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_101, relu__default_32, primals_216, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_101 = primals_216 = None
        getitem_104 = convolution_backward_default_2[0]
        getitem_105 = convolution_backward_default_2[1]
        getitem_106 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_104, torch.float32);  getitem_104 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_33, to_dtype_9);  le_scalar_2 = new_zeros_default_33 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_43, primals_208, primals_206, primals_207, getitem_90, getitem_91, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_43 = primals_208 = primals_206 = primals_207 = getitem_90 = getitem_91 = None
        getitem_107 = native_batch_norm_backward_default_1[0]
        getitem_108 = native_batch_norm_backward_default_1[1]
        getitem_109 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_107, relu__default_31, primals_215, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_107 = primals_215 = None
        getitem_110 = convolution_backward_default_3[0]
        getitem_111 = convolution_backward_default_3[1]
        getitem_112 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_110, torch.float32);  getitem_110 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_34, to_dtype_12);  le_scalar_3 = new_zeros_default_34 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_42, primals_203, primals_201, primals_202, getitem_87, getitem_88, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_42 = primals_203 = primals_201 = primals_202 = getitem_87 = getitem_88 = None
        getitem_113 = native_batch_norm_backward_default_2[0]
        getitem_114 = native_batch_norm_backward_default_2[1]
        getitem_115 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_113, relu__default_30, primals_214, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_113 = primals_214 = None
        getitem_116 = convolution_backward_default_4[0]
        getitem_117 = convolution_backward_default_4[1]
        getitem_118 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_116);  to_dtype_2 = getitem_116 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_35, to_dtype_15);  le_scalar_4 = new_zeros_default_35 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_41, primals_194, primals_192, primals_193, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  convolution_default_41 = primals_194 = primals_192 = primals_193 = getitem_84 = getitem_85 = None
        getitem_119 = native_batch_norm_backward_default_3[0]
        getitem_120 = native_batch_norm_backward_default_3[1]
        getitem_121 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_119, avg_pool2d_default_2, primals_189, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_119 = avg_pool2d_default_2 = primals_189 = None
        getitem_122 = convolution_backward_default_5[0]
        getitem_123 = convolution_backward_default_5[1]
        getitem_124 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_122, relu__default_26, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_122 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_17, getitem_80);  getitem_80 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_17, sigmoid_default_6);  to_dtype_17 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_12, [2, 3], True);  mul_tensor_12 = None
        to_dtype_18 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_19 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_19, 1)
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_1);  to_dtype_19 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_14);  mul_tensor_14 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(to_dtype_18, conj_physical_default_1);  to_dtype_18 = conj_physical_default_1 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_15, torch.float32);  mul_tensor_15 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(to_dtype_20, relu__default_29, primals_198, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = primals_198 = None
        getitem_125 = convolution_backward_default_6[0]
        getitem_126 = convolution_backward_default_6[1]
        getitem_127 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_125, torch.float32);  getitem_125 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_36, to_dtype_21);  le_scalar_5 = new_zeros_default_36 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_23, mean_dim_6, primals_196, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_23 = mean_dim_6 = primals_196 = None
        getitem_128 = convolution_backward_default_7[0]
        getitem_129 = convolution_backward_default_7[1]
        getitem_130 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_128, [128, 2048, 7, 7]);  getitem_128 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_13, div_scalar_2);  mul_tensor_13 = div_scalar_2 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_2, convolution_default_38, primals_185, primals_183, primals_184, getitem_81, getitem_82, True, 1e-05, [True, True, True]);  add_tensor_2 = convolution_default_38 = primals_185 = primals_183 = primals_184 = getitem_81 = getitem_82 = None
        getitem_131 = native_batch_norm_backward_default_4[0]
        getitem_132 = native_batch_norm_backward_default_4[1]
        getitem_133 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_131, relu__default_28, primals_188, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_131 = primals_188 = None
        getitem_134 = convolution_backward_default_8[0]
        getitem_135 = convolution_backward_default_8[1]
        getitem_136 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_134, torch.float32);  getitem_134 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_37, to_dtype_24);  le_scalar_6 = new_zeros_default_37 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_37, primals_180, primals_178, primals_179, getitem_78, getitem_79, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_37 = primals_180 = primals_178 = primals_179 = getitem_78 = getitem_79 = None
        getitem_137 = native_batch_norm_backward_default_5[0]
        getitem_138 = native_batch_norm_backward_default_5[1]
        getitem_139 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_137, relu__default_27, primals_187, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_137 = primals_187 = None
        getitem_140 = convolution_backward_default_9[0]
        getitem_141 = convolution_backward_default_9[1]
        getitem_142 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_140, torch.float32);  getitem_140 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_38, to_dtype_27);  le_scalar_7 = new_zeros_default_38 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_36, primals_175, primals_173, primals_174, getitem_75, getitem_76, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_36 = primals_175 = primals_173 = primals_174 = getitem_75 = getitem_76 = None
        getitem_143 = native_batch_norm_backward_default_6[0]
        getitem_144 = native_batch_norm_backward_default_6[1]
        getitem_145 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_143, relu__default_26, primals_186, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_143 = primals_186 = None
        getitem_146 = convolution_backward_default_10[0]
        getitem_147 = convolution_backward_default_10[1]
        getitem_148 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default, getitem_146);  avg_pool2d_backward_default = getitem_146 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_39, to_dtype_30);  le_scalar_8 = new_zeros_default_39 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(to_dtype_32, getitem_71);  getitem_71 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_32, sigmoid_default_5)
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_16, [2, 3], True);  mul_tensor_16 = None
        to_dtype_33 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_34 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(to_dtype_34, 1)
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_2);  to_dtype_34 = rsub_scalar_2 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_18);  mul_tensor_18 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_33, conj_physical_default_2);  to_dtype_33 = conj_physical_default_2 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_19, torch.float32);  mul_tensor_19 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(to_dtype_35, relu__default_25, primals_170, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = primals_170 = None
        getitem_149 = convolution_backward_default_11[0]
        getitem_150 = convolution_backward_default_11[1]
        getitem_151 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_149, torch.float32);  getitem_149 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_40, to_dtype_36);  le_scalar_9 = new_zeros_default_40 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_38, mean_dim_5, primals_168, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_38 = mean_dim_5 = primals_168 = None
        getitem_152 = convolution_backward_default_12[0]
        getitem_153 = convolution_backward_default_12[1]
        getitem_154 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_152, [128, 1024, 14, 14]);  getitem_152 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 196);  expand_default_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_17, div_scalar_3);  mul_tensor_17 = div_scalar_3 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_4, convolution_default_33, primals_163, primals_161, primals_162, getitem_72, getitem_73, True, 1e-05, [True, True, True]);  add_tensor_4 = convolution_default_33 = primals_163 = primals_161 = primals_162 = getitem_72 = getitem_73 = None
        getitem_155 = native_batch_norm_backward_default_7[0]
        getitem_156 = native_batch_norm_backward_default_7[1]
        getitem_157 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_155, relu__default_24, primals_166, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_155 = primals_166 = None
        getitem_158 = convolution_backward_default_13[0]
        getitem_159 = convolution_backward_default_13[1]
        getitem_160 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_158, torch.float32);  getitem_158 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_41, to_dtype_39);  le_scalar_10 = new_zeros_default_41 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_32, primals_158, primals_156, primals_157, getitem_69, getitem_70, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_32 = primals_158 = primals_156 = primals_157 = getitem_69 = getitem_70 = None
        getitem_161 = native_batch_norm_backward_default_8[0]
        getitem_162 = native_batch_norm_backward_default_8[1]
        getitem_163 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_161, relu__default_23, primals_165, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_161 = primals_165 = None
        getitem_164 = convolution_backward_default_14[0]
        getitem_165 = convolution_backward_default_14[1]
        getitem_166 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_164, torch.float32);  getitem_164 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_42, to_dtype_42);  le_scalar_11 = new_zeros_default_42 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_31, primals_153, primals_151, primals_152, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_31 = primals_153 = primals_151 = primals_152 = getitem_66 = getitem_67 = None
        getitem_167 = native_batch_norm_backward_default_9[0]
        getitem_168 = native_batch_norm_backward_default_9[1]
        getitem_169 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_167, relu__default_22, primals_164, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_167 = primals_164 = None
        getitem_170 = convolution_backward_default_15[0]
        getitem_171 = convolution_backward_default_15[1]
        getitem_172 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(to_dtype_32, getitem_170);  to_dtype_32 = getitem_170 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_43, to_dtype_45);  le_scalar_12 = new_zeros_default_43 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_30, primals_144, primals_142, primals_143, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  convolution_default_30 = primals_144 = primals_142 = primals_143 = getitem_63 = getitem_64 = None
        getitem_173 = native_batch_norm_backward_default_10[0]
        getitem_174 = native_batch_norm_backward_default_10[1]
        getitem_175 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_173, avg_pool2d_default_1, primals_139, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_173 = avg_pool2d_default_1 = primals_139 = None
        getitem_176 = convolution_backward_default_16[0]
        getitem_177 = convolution_backward_default_16[1]
        getitem_178 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_176, relu__default_18, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_176 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_47, getitem_59);  getitem_59 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_47, sigmoid_default_4);  to_dtype_47 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_20, [2, 3], True);  mul_tensor_20 = None
        to_dtype_48 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_49 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(to_dtype_49, 1)
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_3);  to_dtype_49 = rsub_scalar_3 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_22);  mul_tensor_22 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_48, conj_physical_default_3);  to_dtype_48 = conj_physical_default_3 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_23, torch.float32);  mul_tensor_23 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_50, relu__default_21, primals_148, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_50 = primals_148 = None
        getitem_179 = convolution_backward_default_17[0]
        getitem_180 = convolution_backward_default_17[1]
        getitem_181 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_179, torch.float32);  getitem_179 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_44, to_dtype_51);  le_scalar_13 = new_zeros_default_44 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_53, mean_dim_4, primals_146, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = mean_dim_4 = primals_146 = None
        getitem_182 = convolution_backward_default_18[0]
        getitem_183 = convolution_backward_default_18[1]
        getitem_184 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_182, [128, 1024, 14, 14]);  getitem_182 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 196);  expand_default_4 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_21, div_scalar_4);  mul_tensor_21 = div_scalar_4 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_6, convolution_default_27, primals_135, primals_133, primals_134, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  add_tensor_6 = convolution_default_27 = primals_135 = primals_133 = primals_134 = getitem_60 = getitem_61 = None
        getitem_185 = native_batch_norm_backward_default_11[0]
        getitem_186 = native_batch_norm_backward_default_11[1]
        getitem_187 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_185, relu__default_20, primals_138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_185 = primals_138 = None
        getitem_188 = convolution_backward_default_19[0]
        getitem_189 = convolution_backward_default_19[1]
        getitem_190 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_188, torch.float32);  getitem_188 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_45, to_dtype_54);  le_scalar_14 = new_zeros_default_45 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_26, primals_130, primals_128, primals_129, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_26 = primals_130 = primals_128 = primals_129 = getitem_57 = getitem_58 = None
        getitem_191 = native_batch_norm_backward_default_12[0]
        getitem_192 = native_batch_norm_backward_default_12[1]
        getitem_193 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_191, relu__default_19, primals_137, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_191 = primals_137 = None
        getitem_194 = convolution_backward_default_20[0]
        getitem_195 = convolution_backward_default_20[1]
        getitem_196 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_194, torch.float32);  getitem_194 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_46, to_dtype_57);  le_scalar_15 = new_zeros_default_46 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_25, primals_125, primals_123, primals_124, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_25 = primals_125 = primals_123 = primals_124 = getitem_54 = getitem_55 = None
        getitem_197 = native_batch_norm_backward_default_13[0]
        getitem_198 = native_batch_norm_backward_default_13[1]
        getitem_199 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_197, relu__default_18, primals_136, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_197 = primals_136 = None
        getitem_200 = convolution_backward_default_21[0]
        getitem_201 = convolution_backward_default_21[1]
        getitem_202 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_1, getitem_200);  avg_pool2d_backward_default_1 = getitem_200 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_47, to_dtype_60);  le_scalar_16 = new_zeros_default_47 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype_62, getitem_50);  getitem_50 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_62, sigmoid_default_3)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_24, [2, 3], True);  mul_tensor_24 = None
        to_dtype_63 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_4);  to_dtype_64 = rsub_scalar_4 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_26);  mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_4);  to_dtype_63 = conj_physical_default_4 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_27, torch.float32);  mul_tensor_27 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_65, relu__default_17, primals_120, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = primals_120 = None
        getitem_203 = convolution_backward_default_22[0]
        getitem_204 = convolution_backward_default_22[1]
        getitem_205 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_203, torch.float32);  getitem_203 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_48, to_dtype_66);  le_scalar_17 = new_zeros_default_48 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_68, mean_dim_3, primals_118, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = mean_dim_3 = primals_118 = None
        getitem_206 = convolution_backward_default_23[0]
        getitem_207 = convolution_backward_default_23[1]
        getitem_208 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_206, [128, 512, 28, 28]);  getitem_206 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 784);  expand_default_5 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_25, div_scalar_5);  mul_tensor_25 = div_scalar_5 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_8, convolution_default_22, primals_113, primals_111, primals_112, getitem_51, getitem_52, True, 1e-05, [True, True, True]);  add_tensor_8 = convolution_default_22 = primals_113 = primals_111 = primals_112 = getitem_51 = getitem_52 = None
        getitem_209 = native_batch_norm_backward_default_14[0]
        getitem_210 = native_batch_norm_backward_default_14[1]
        getitem_211 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_209, relu__default_16, primals_116, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_209 = primals_116 = None
        getitem_212 = convolution_backward_default_24[0]
        getitem_213 = convolution_backward_default_24[1]
        getitem_214 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_212, torch.float32);  getitem_212 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_49, to_dtype_69);  le_scalar_18 = new_zeros_default_49 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_21, primals_108, primals_106, primals_107, getitem_48, getitem_49, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_21 = primals_108 = primals_106 = primals_107 = getitem_48 = getitem_49 = None
        getitem_215 = native_batch_norm_backward_default_15[0]
        getitem_216 = native_batch_norm_backward_default_15[1]
        getitem_217 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_215, relu__default_15, primals_115, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_215 = primals_115 = None
        getitem_218 = convolution_backward_default_25[0]
        getitem_219 = convolution_backward_default_25[1]
        getitem_220 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_218, torch.float32);  getitem_218 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_50, to_dtype_72);  le_scalar_19 = new_zeros_default_50 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_20, primals_103, primals_101, primals_102, getitem_45, getitem_46, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_20 = primals_103 = primals_101 = primals_102 = getitem_45 = getitem_46 = None
        getitem_221 = native_batch_norm_backward_default_16[0]
        getitem_222 = native_batch_norm_backward_default_16[1]
        getitem_223 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_221, relu__default_14, primals_114, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_221 = primals_114 = None
        getitem_224 = convolution_backward_default_26[0]
        getitem_225 = convolution_backward_default_26[1]
        getitem_226 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_224);  to_dtype_62 = getitem_224 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_9, torch.float32);  add_tensor_9 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_51, to_dtype_75);  le_scalar_20 = new_zeros_default_51 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_19, primals_94, primals_92, primals_93, getitem_42, getitem_43, True, 1e-05, [True, True, True]);  convolution_default_19 = primals_94 = primals_92 = primals_93 = getitem_42 = getitem_43 = None
        getitem_227 = native_batch_norm_backward_default_17[0]
        getitem_228 = native_batch_norm_backward_default_17[1]
        getitem_229 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_227, avg_pool2d_default, primals_89, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_227 = avg_pool2d_default = primals_89 = None
        getitem_230 = convolution_backward_default_27[0]
        getitem_231 = convolution_backward_default_27[1]
        getitem_232 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_230, relu__default_10, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_230 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_77, getitem_38);  getitem_38 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_77, sigmoid_default_2);  to_dtype_77 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_28, [2, 3], True);  mul_tensor_28 = None
        to_dtype_78 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_79 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_79, 1)
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_5);  to_dtype_79 = rsub_scalar_5 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_30);  mul_tensor_30 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(to_dtype_78, conj_physical_default_5);  to_dtype_78 = conj_physical_default_5 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_31, torch.float32);  mul_tensor_31 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(to_dtype_80, relu__default_13, primals_98, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = primals_98 = None
        getitem_233 = convolution_backward_default_28[0]
        getitem_234 = convolution_backward_default_28[1]
        getitem_235 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_233, torch.float32);  getitem_233 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_52, to_dtype_81);  le_scalar_21 = new_zeros_default_52 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(to_dtype_83, mean_dim_2, primals_96, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_83 = mean_dim_2 = primals_96 = None
        getitem_236 = convolution_backward_default_29[0]
        getitem_237 = convolution_backward_default_29[1]
        getitem_238 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_236, [128, 512, 28, 28]);  getitem_236 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 784);  expand_default_6 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_29, div_scalar_6);  mul_tensor_29 = div_scalar_6 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_10, convolution_default_16, primals_85, primals_83, primals_84, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  add_tensor_10 = convolution_default_16 = primals_85 = primals_83 = primals_84 = getitem_39 = getitem_40 = None
        getitem_239 = native_batch_norm_backward_default_18[0]
        getitem_240 = native_batch_norm_backward_default_18[1]
        getitem_241 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_239, relu__default_12, primals_88, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_239 = primals_88 = None
        getitem_242 = convolution_backward_default_30[0]
        getitem_243 = convolution_backward_default_30[1]
        getitem_244 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_242, torch.float32);  getitem_242 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_53, to_dtype_84);  le_scalar_22 = new_zeros_default_53 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_15, primals_80, primals_78, primals_79, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_15 = primals_80 = primals_78 = primals_79 = getitem_36 = getitem_37 = None
        getitem_245 = native_batch_norm_backward_default_19[0]
        getitem_246 = native_batch_norm_backward_default_19[1]
        getitem_247 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_245, relu__default_11, primals_87, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_245 = primals_87 = None
        getitem_248 = convolution_backward_default_31[0]
        getitem_249 = convolution_backward_default_31[1]
        getitem_250 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_248, torch.float32);  getitem_248 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_54, to_dtype_87);  le_scalar_23 = new_zeros_default_54 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_14, primals_75, primals_73, primals_74, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_14 = primals_75 = primals_73 = primals_74 = getitem_33 = getitem_34 = None
        getitem_251 = native_batch_norm_backward_default_20[0]
        getitem_252 = native_batch_norm_backward_default_20[1]
        getitem_253 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_251, relu__default_10, primals_86, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_251 = primals_86 = None
        getitem_254 = convolution_backward_default_32[0]
        getitem_255 = convolution_backward_default_32[1]
        getitem_256 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_2, getitem_254);  avg_pool2d_backward_default_2 = getitem_254 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_11, torch.float32);  add_tensor_11 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_55, to_dtype_90);  le_scalar_24 = new_zeros_default_55 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(to_dtype_92, getitem_29);  getitem_29 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_92, sigmoid_default_1)
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_32, [2, 3], True);  mul_tensor_32 = None
        to_dtype_93 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_94 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(to_dtype_94, 1)
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_6);  to_dtype_94 = rsub_scalar_6 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_34);  mul_tensor_34 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_93, conj_physical_default_6);  to_dtype_93 = conj_physical_default_6 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_35, torch.float32);  mul_tensor_35 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(to_dtype_95, relu__default_9, primals_70, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_95 = primals_70 = None
        getitem_257 = convolution_backward_default_33[0]
        getitem_258 = convolution_backward_default_33[1]
        getitem_259 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_257, torch.float32);  getitem_257 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_56, to_dtype_96);  le_scalar_25 = new_zeros_default_56 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(to_dtype_98, mean_dim_1, primals_68, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_98 = mean_dim_1 = primals_68 = None
        getitem_260 = convolution_backward_default_34[0]
        getitem_261 = convolution_backward_default_34[1]
        getitem_262 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_260, [128, 256, 56, 56]);  getitem_260 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 3136);  expand_default_7 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_33, div_scalar_7);  mul_tensor_33 = div_scalar_7 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_12, convolution_default_11, primals_63, primals_61, primals_62, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  add_tensor_12 = convolution_default_11 = primals_63 = primals_61 = primals_62 = getitem_30 = getitem_31 = None
        getitem_263 = native_batch_norm_backward_default_21[0]
        getitem_264 = native_batch_norm_backward_default_21[1]
        getitem_265 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_263, relu__default_8, primals_66, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_263 = primals_66 = None
        getitem_266 = convolution_backward_default_35[0]
        getitem_267 = convolution_backward_default_35[1]
        getitem_268 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_266, torch.float32);  getitem_266 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_57, to_dtype_99);  le_scalar_26 = new_zeros_default_57 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_10, primals_58, primals_56, primals_57, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_10 = primals_58 = primals_56 = primals_57 = getitem_27 = getitem_28 = None
        getitem_269 = native_batch_norm_backward_default_22[0]
        getitem_270 = native_batch_norm_backward_default_22[1]
        getitem_271 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_269, relu__default_7, primals_65, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_269 = primals_65 = None
        getitem_272 = convolution_backward_default_36[0]
        getitem_273 = convolution_backward_default_36[1]
        getitem_274 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_272, torch.float32);  getitem_272 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_58, to_dtype_102);  le_scalar_27 = new_zeros_default_58 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_9, primals_53, primals_51, primals_52, getitem_24, getitem_25, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_9 = primals_53 = primals_51 = primals_52 = getitem_24 = getitem_25 = None
        getitem_275 = native_batch_norm_backward_default_23[0]
        getitem_276 = native_batch_norm_backward_default_23[1]
        getitem_277 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_275, relu__default_6, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_275 = primals_64 = None
        getitem_278 = convolution_backward_default_37[0]
        getitem_279 = convolution_backward_default_37[1]
        getitem_280 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(to_dtype_92, getitem_278);  to_dtype_92 = getitem_278 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_13, torch.float32);  add_tensor_13 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_59, to_dtype_105);  le_scalar_28 = new_zeros_default_59 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_8, primals_44, primals_42, primals_43, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  convolution_default_8 = primals_44 = primals_42 = primals_43 = getitem_21 = getitem_22 = None
        getitem_281 = native_batch_norm_backward_default_24[0]
        getitem_282 = native_batch_norm_backward_default_24[1]
        getitem_283 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_281, getitem_9, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_281 = primals_39 = None
        getitem_284 = convolution_backward_default_38[0]
        getitem_285 = convolution_backward_default_38[1]
        getitem_286 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_107, getitem_17);  getitem_17 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_107, sigmoid_default);  to_dtype_107 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_36, [2, 3], True);  mul_tensor_36 = None
        to_dtype_108 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_109 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(to_dtype_109, 1)
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_7);  to_dtype_109 = rsub_scalar_7 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_38);  mul_tensor_38 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_108, conj_physical_default_7);  to_dtype_108 = conj_physical_default_7 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_39, torch.float32);  mul_tensor_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(to_dtype_110, relu__default_5, primals_48, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_110 = primals_48 = None
        getitem_287 = convolution_backward_default_39[0]
        getitem_288 = convolution_backward_default_39[1]
        getitem_289 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_287, torch.float32);  getitem_287 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_60, to_dtype_111);  le_scalar_29 = new_zeros_default_60 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(to_dtype_113, mean_dim, primals_46, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = mean_dim = primals_46 = None
        getitem_290 = convolution_backward_default_40[0]
        getitem_291 = convolution_backward_default_40[1]
        getitem_292 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_290, [128, 256, 56, 56]);  getitem_290 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 3136);  expand_default_8 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_37, div_scalar_8);  mul_tensor_37 = div_scalar_8 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_14, convolution_default_5, primals_35, primals_33, primals_34, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  add_tensor_14 = convolution_default_5 = primals_35 = primals_33 = primals_34 = getitem_18 = getitem_19 = None
        getitem_293 = native_batch_norm_backward_default_25[0]
        getitem_294 = native_batch_norm_backward_default_25[1]
        getitem_295 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_293, relu__default_4, primals_38, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_293 = primals_38 = None
        getitem_296 = convolution_backward_default_41[0]
        getitem_297 = convolution_backward_default_41[1]
        getitem_298 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_296, torch.float32);  getitem_296 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_61, to_dtype_114);  le_scalar_30 = new_zeros_default_61 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_4, primals_30, primals_28, primals_29, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_4 = primals_30 = primals_28 = primals_29 = getitem_15 = getitem_16 = None
        getitem_299 = native_batch_norm_backward_default_26[0]
        getitem_300 = native_batch_norm_backward_default_26[1]
        getitem_301 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_299, relu__default_3, primals_37, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_299 = primals_37 = None
        getitem_302 = convolution_backward_default_42[0]
        getitem_303 = convolution_backward_default_42[1]
        getitem_304 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_302, torch.float32);  getitem_302 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_62, to_dtype_117);  le_scalar_31 = new_zeros_default_62 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_3, primals_25, primals_23, primals_24, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_3 = primals_25 = primals_23 = primals_24 = getitem_12 = getitem_13 = None
        getitem_305 = native_batch_norm_backward_default_27[0]
        getitem_306 = native_batch_norm_backward_default_27[1]
        getitem_307 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_305, getitem_9, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_305 = getitem_9 = primals_36 = None
        getitem_308 = convolution_backward_default_43[0]
        getitem_309 = convolution_backward_default_43[1]
        getitem_310 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_284, getitem_308);  getitem_284 = getitem_308 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_15, relu__default_2, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_10);  add_tensor_15 = getitem_10 = None
        to_dtype_120 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_63, to_dtype_120);  le_scalar_32 = new_zeros_default_63 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_2, primals_5, primals_3, primals_4, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_2 = primals_5 = primals_3 = primals_4 = getitem_7 = getitem_8 = None
        getitem_311 = native_batch_norm_backward_default_28[0]
        getitem_312 = native_batch_norm_backward_default_28[1]
        getitem_313 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_311, relu__default_1, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_311 = primals_18 = None
        getitem_314 = convolution_backward_default_44[0]
        getitem_315 = convolution_backward_default_44[1]
        getitem_316 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_314, torch.float32);  getitem_314 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_64, to_dtype_123);  le_scalar_33 = new_zeros_default_64 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_1, primals_17, primals_15, primals_16, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_1 = primals_17 = primals_15 = primals_16 = getitem_4 = getitem_5 = None
        getitem_317 = native_batch_norm_backward_default_29[0]
        getitem_318 = native_batch_norm_backward_default_29[1]
        getitem_319 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_317, relu__default, primals_12, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_317 = primals_12 = None
        getitem_320 = convolution_backward_default_45[0]
        getitem_321 = convolution_backward_default_45[1]
        getitem_322 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_320, torch.float32);  getitem_320 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_65, to_dtype_126);  le_scalar_34 = new_zeros_default_65 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default, primals_11, primals_9, primals_10, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default = primals_11 = primals_9 = primals_10 = getitem_1 = getitem_2 = None
        getitem_323 = native_batch_norm_backward_default_30[0]
        getitem_324 = native_batch_norm_backward_default_30[1]
        getitem_325 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_323, primals_221, primals_6, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_323 = primals_221 = primals_6 = None
        getitem_326 = convolution_backward_default_46[0]
        getitem_327 = convolution_backward_default_46[1]
        getitem_328 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        return [addmm_default, getitem_313, None, None, None, getitem_312, getitem_327, getitem_325, None, None, None, getitem_324, getitem_321, getitem_319, None, None, None, getitem_318, getitem_315, view_default_1, t_default_4, getitem_307, None, None, None, getitem_306, getitem_301, None, None, None, getitem_300, getitem_295, None, None, None, getitem_294, getitem_309, getitem_303, getitem_297, getitem_285, getitem_283, None, None, None, getitem_282, getitem_292, getitem_291, getitem_289, getitem_288, getitem_277, None, None, None, getitem_276, getitem_271, None, None, None, getitem_270, getitem_265, None, None, None, getitem_264, getitem_279, getitem_273, getitem_267, getitem_262, getitem_261, getitem_259, getitem_258, getitem_253, None, None, None, getitem_252, getitem_247, None, None, None, getitem_246, getitem_241, None, None, None, getitem_240, getitem_255, getitem_249, getitem_243, getitem_231, getitem_229, None, None, None, getitem_228, getitem_238, getitem_237, getitem_235, getitem_234, getitem_223, None, None, None, getitem_222, getitem_217, None, None, None, getitem_216, getitem_211, None, None, None, getitem_210, getitem_225, getitem_219, getitem_213, getitem_208, getitem_207, getitem_205, getitem_204, getitem_199, None, None, None, getitem_198, getitem_193, None, None, None, getitem_192, getitem_187, None, None, None, getitem_186, getitem_201, getitem_195, getitem_189, getitem_177, getitem_175, None, None, None, getitem_174, getitem_184, getitem_183, getitem_181, getitem_180, getitem_169, None, None, None, getitem_168, getitem_163, None, None, None, getitem_162, getitem_157, None, None, None, getitem_156, getitem_171, getitem_165, getitem_159, getitem_154, getitem_153, getitem_151, getitem_150, getitem_145, None, None, None, getitem_144, getitem_139, None, None, None, getitem_138, getitem_133, None, None, None, getitem_132, getitem_147, getitem_141, getitem_135, getitem_123, getitem_121, None, None, None, getitem_120, getitem_130, getitem_129, getitem_127, getitem_126, getitem_115, None, None, None, getitem_114, getitem_109, None, None, None, getitem_108, getitem_103, None, None, None, getitem_102, getitem_117, getitem_111, getitem_105, getitem_100, getitem_99, getitem_97, getitem_96, None]
        
