
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/seresnext26d_32x4d/seresnext26d_32x4d_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221):
        convolution_default = torch.ops.aten.convolution.default(primals_221, primals_6, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_11, primals_7, primals_9, primals_10, True, 0.1, 1e-05);  primals_7 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_17, primals_13, primals_15, primals_16, True, 0.1, 1e-05);  primals_13 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2], [1, 1])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_25, primals_21, primals_23, primals_24, True, 0.1, 1e-05);  primals_21 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_30, primals_26, primals_28, primals_29, True, 0.1, 1e-05);  primals_26 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_35, primals_31, primals_33, primals_34, True, 0.1, 1e-05);  primals_31 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        mean_dim = torch.ops.aten.mean.dim(getitem_17, [2, 3], True)
        convolution_default_6 = torch.ops.aten.convolution.default(mean_dim, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_6);  convolution_default_6 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_7);  convolution_default_7 = None
        mul_tensor = torch.ops.aten.mul.Tensor(getitem_17, sigmoid_default)
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_9, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(mul_tensor, getitem_20);  mul_tensor = getitem_20 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_53, primals_49, primals_51, primals_52, True, 0.1, 1e-05);  primals_49 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_7, primals_65, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_58, primals_54, primals_56, primals_57, True, 0.1, 1e-05);  primals_54 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_8, primals_66, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_63, primals_59, primals_61, primals_62, True, 0.1, 1e-05);  primals_59 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        mean_dim_1 = torch.ops.aten.mean.dim(getitem_29, [2, 3], True)
        convolution_default_12 = torch.ops.aten.convolution.default(mean_dim_1, primals_68, primals_67, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_67 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_12);  convolution_default_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_9, primals_70, primals_69, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_69 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_13);  convolution_default_13 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(getitem_29, sigmoid_default_1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(mul_tensor_1, relu__default_6);  mul_tensor_1 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_11);  add__tensor_11 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_10, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_75, primals_71, primals_73, primals_74, True, 0.1, 1e-05);  primals_71 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_11, primals_87, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_80, primals_76, primals_78, primals_79, True, 0.1, 1e-05);  primals_76 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_12, primals_88, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        mean_dim_2 = torch.ops.aten.mean.dim(getitem_38, [2, 3], True)
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_2, primals_96, primals_95, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_95 = None
        relu__default_13 = torch.ops.aten.relu_.default(convolution_default_17);  convolution_default_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_13, primals_98, primals_97, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_97 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_18);  convolution_default_18 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(getitem_38, sigmoid_default_2)
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(relu__default_10, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_19 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_89, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_94, primals_90, primals_92, primals_93, True, 0.1, 1e-05);  primals_90 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        add__tensor_16 = torch.ops.aten.add_.Tensor(mul_tensor_2, getitem_41);  mul_tensor_2 = getitem_41 = None
        relu__default_14 = torch.ops.aten.relu_.default(add__tensor_16);  add__tensor_16 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_14, primals_114, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_103, primals_99, primals_101, primals_102, True, 0.1, 1e-05);  primals_99 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_15, primals_115, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_108, primals_104, primals_106, primals_107, True, 0.1, 1e-05);  primals_104 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_16, primals_116, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_113, primals_109, primals_111, primals_112, True, 0.1, 1e-05);  primals_109 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        mean_dim_3 = torch.ops.aten.mean.dim(getitem_50, [2, 3], True)
        convolution_default_23 = torch.ops.aten.convolution.default(mean_dim_3, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        relu__default_17 = torch.ops.aten.relu_.default(convolution_default_23);  convolution_default_23 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_17, primals_120, primals_119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_119 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_24);  convolution_default_24 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(getitem_50, sigmoid_default_3)
        add__tensor_20 = torch.ops.aten.add_.Tensor(mul_tensor_3, relu__default_14);  mul_tensor_3 = None
        relu__default_18 = torch.ops.aten.relu_.default(add__tensor_20);  add__tensor_20 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_18, primals_136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_125, primals_121, primals_123, primals_124, True, 0.1, 1e-05);  primals_121 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_19, primals_137, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_130, primals_126, primals_128, primals_129, True, 0.1, 1e-05);  primals_126 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_20, primals_138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_135, primals_131, primals_133, primals_134, True, 0.1, 1e-05);  primals_131 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        mean_dim_4 = torch.ops.aten.mean.dim(getitem_59, [2, 3], True)
        convolution_default_28 = torch.ops.aten.convolution.default(mean_dim_4, primals_146, primals_145, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_145 = None
        relu__default_21 = torch.ops.aten.relu_.default(convolution_default_28);  convolution_default_28 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_21, primals_148, primals_147, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_147 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_29);  convolution_default_29 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(getitem_59, sigmoid_default_4)
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(relu__default_18, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_30 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_139, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_144, primals_140, primals_142, primals_143, True, 0.1, 1e-05);  primals_140 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        add__tensor_25 = torch.ops.aten.add_.Tensor(mul_tensor_4, getitem_62);  mul_tensor_4 = getitem_62 = None
        relu__default_22 = torch.ops.aten.relu_.default(add__tensor_25);  add__tensor_25 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_22, primals_164, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_153, primals_149, primals_151, primals_152, True, 0.1, 1e-05);  primals_149 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_23, primals_165, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_158, primals_154, primals_156, primals_157, True, 0.1, 1e-05);  primals_154 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_24, primals_166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_163, primals_159, primals_161, primals_162, True, 0.1, 1e-05);  primals_159 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        mean_dim_5 = torch.ops.aten.mean.dim(getitem_71, [2, 3], True)
        convolution_default_34 = torch.ops.aten.convolution.default(mean_dim_5, primals_168, primals_167, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_167 = None
        relu__default_25 = torch.ops.aten.relu_.default(convolution_default_34);  convolution_default_34 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_25, primals_170, primals_169, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_169 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_35);  convolution_default_35 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(getitem_71, sigmoid_default_5)
        add__tensor_29 = torch.ops.aten.add_.Tensor(mul_tensor_5, relu__default_22);  mul_tensor_5 = None
        relu__default_26 = torch.ops.aten.relu_.default(add__tensor_29);  add__tensor_29 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_26, primals_186, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_175, primals_171, primals_173, primals_174, True, 0.1, 1e-05);  primals_171 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_27, primals_187, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_180, primals_176, primals_178, primals_179, True, 0.1, 1e-05);  primals_176 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_28, primals_188, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_185, primals_181, primals_183, primals_184, True, 0.1, 1e-05);  primals_181 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        mean_dim_6 = torch.ops.aten.mean.dim(getitem_80, [2, 3], True)
        convolution_default_39 = torch.ops.aten.convolution.default(mean_dim_6, primals_196, primals_195, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_195 = None
        relu__default_29 = torch.ops.aten.relu_.default(convolution_default_39);  convolution_default_39 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_29, primals_198, primals_197, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_197 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_40);  convolution_default_40 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(getitem_80, sigmoid_default_6)
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(relu__default_26, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_41 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_189, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_194, primals_190, primals_192, primals_193, True, 0.1, 1e-05);  primals_190 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        add__tensor_34 = torch.ops.aten.add_.Tensor(mul_tensor_6, getitem_83);  mul_tensor_6 = getitem_83 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_34);  add__tensor_34 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_30, primals_214, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_203, primals_199, primals_201, primals_202, True, 0.1, 1e-05);  primals_199 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_31, primals_215, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_208, primals_204, primals_206, primals_207, True, 0.1, 1e-05);  primals_204 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_32, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_213, primals_209, primals_211, primals_212, True, 0.1, 1e-05);  primals_209 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        mean_dim_7 = torch.ops.aten.mean.dim(getitem_92, [2, 3], True)
        convolution_default_45 = torch.ops.aten.convolution.default(mean_dim_7, primals_218, primals_217, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_217 = None
        relu__default_33 = torch.ops.aten.relu_.default(convolution_default_45);  convolution_default_45 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_33, primals_220, primals_219, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_219 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_46);  convolution_default_46 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(getitem_92, sigmoid_default_7)
        add__tensor_38 = torch.ops.aten.add_.Tensor(mul_tensor_7, relu__default_30);  mul_tensor_7 = None
        relu__default_34 = torch.ops.aten.relu_.default(add__tensor_38);  add__tensor_38 = None
        mean_dim_8 = torch.ops.aten.mean.dim(relu__default_34, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_8, [128, 2048]);  mean_dim_8 = None
        t_default = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default = torch.ops.aten.addmm.default(primals_19, view_default, t_default);  primals_19 = None
        return [addmm_default, getitem_8, getitem_15, primals_115, getitem_9, getitem_7, getitem_43, primals_75, getitem_42, getitem_16, relu__default_2, primals_83, convolution_default_5, relu__default_4, primals_65, convolution_default_20, getitem_10, primals_73, primals_18, primals_24, relu__default_14, primals_68, getitem_19, getitem_18, getitem_46, getitem_17, getitem_45, primals_116, primals_28, primals_79, convolution_default_3, primals_12, getitem_13, getitem_12, relu__default_15, primals_25, primals_29, primals_78, primals_74, convolution_default_21, relu__default_3, mean_dim, mean_dim_3, primals_30, primals_64, relu__default_5, primals_66, primals_70, convolution_default_4, sigmoid_default, primals_16, primals_80, getitem_48, getitem_49, primals_15, primals_17, primals_23, primals_111, getitem_28, getitem_59, getitem_27, getitem_60, convolution_default_8, getitem_61, convolution_default_9, relu__default_8, primals_112, convolution_default_11, getitem_22, getitem_21, primals_107, relu__default_21, primals_114, primals_124, getitem_63, getitem_31, getitem_30, sigmoid_default_4, primals_108, getitem_29, relu__default_6, primals_106, getitem_25, getitem_24, avg_pool2d_default_1, relu__default_7, mean_dim_1, primals_113, convolution_default_30, relu__default_9, convolution_default_10, sigmoid_default_1, relu__default_22, primals_123, getitem_64, primals_5, convolution_default_37, primals_135, getitem_75, convolution_default_31, convolution_default_32, getitem_76, convolution_default_1, primals_86, relu__default_27, primals_120, getitem_2, primals_3, primals_46, getitem_1, getitem_67, primals_84, getitem_66, primals_4, primals_9, primals_43, relu__default, primals_48, primals_134, primals_44, getitem_79, relu__default_23, getitem_81, getitem_78, primals_42, primals_52, relu__default_28, getitem_5, primals_133, getitem_4, mean_dim_5, primals_11, convolution_default_38, primals_6, getitem_69, mean_dim_6, relu__default_1, getitem_70, primals_10, primals_130, primals_51, relu__default_24, getitem_80, convolution_default_2, getitem_82, primals_118, primals_129, primals_53, convolution_default_33, primals_85, relu__default_10, primals_187, convolution_default_14, primals_186, primals_218, primals_189, relu__default_29, primals_188, primals_101, sigmoid_default_6, getitem_34, getitem_33, convolution_default_41, relu__default_30, relu__default_11, primals_98, avg_pool2d_default_2, convolution_default_15, primals_94, getitem_84, getitem_85, primals_185, primals_220, mean_dim_2, primals_96, getitem_36, primals_221, getitem_37, convolution_default_16, relu__default_12, convolution_default_42, primals_211, primals_142, primals_57, primals_208, primals_63, primals_62, primals_139, primals_56, primals_61, primals_151, primals_58, primals_143, primals_203, primals_144, primals_137, primals_212, primals_136, primals_214, primals_215, primals_148, primals_201, primals_213, primals_216, primals_206, primals_138, primals_202, primals_207, primals_146, relu__default_16, convolution_default, convolution_default_22, getitem_88, primals_125, getitem_87, primals_38, relu__default_31, primals_36, getitem_52, getitem_51, getitem_50, primals_33, convolution_default_43, primals_34, getitem_91, getitem_90, relu__default_32, relu__default_17, sigmoid_default_3, convolution_default_44, primals_37, getitem_92, mean_dim_7, primals_39, primals_35, relu__default_18, convolution_default_25, primals_165, getitem_73, primals_152, getitem_71, primals_157, getitem_40, getitem_72, getitem_39, primals_153, getitem_38, primals_158, primals_164, primals_163, primals_166, primals_92, primals_170, relu__default_25, relu__default_13, sigmoid_default_5, sigmoid_default_2, relu__default_26, primals_168, primals_103, primals_162, primals_161, primals_156, primals_93, convolution_default_36, primals_102, avg_pool2d_default, convolution_default_19, primals_180, getitem_94, primals_173, primals_178, primals_193, getitem_55, getitem_93, getitem_54, relu__default_33, relu__default_19, sigmoid_default_7, convolution_default_26, primals_175, relu__default_34, primals_179, getitem_58, primals_89, primals_194, getitem_57, primals_184, primals_88, view_default, primals_87, primals_128, relu__default_20, primals_198, convolution_default_27, primals_174, primals_192, mean_dim_4, primals_196, t_default, primals_183]
        
