
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/tf_efficientnet_b0_ap/tf_efficientnet_b0_ap_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361):
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(primals_116, [0, 1, 0, 1], 0.0);  primals_116 = None
        convolution_default = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_115, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_117, 1);  primals_117 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_120, primals_121, primals_118, primals_119, True, 0.1, 0.001);  primals_121 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        silu__default = torch.ops.aten.silu_.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(silu__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_122, 1);  primals_122 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_125, primals_126, primals_123, primals_124, True, 0.1, 0.001);  primals_126 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        silu__default_1 = torch.ops.aten.silu_.default(getitem_3)
        mean_dim = torch.ops.aten.mean.dim(silu__default_1, [2, 3], True)
        convolution_default_2 = torch.ops.aten.convolution.default(mean_dim, primals_6, primals_5, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_5 = None
        silu__default_2 = torch.ops.aten.silu_.default(convolution_default_2)
        convolution_default_3 = torch.ops.aten.convolution.default(silu__default_2, primals_4, primals_3, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_3 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_3);  convolution_default_3 = None
        mul_tensor = torch.ops.aten.mul.Tensor(silu__default_1, sigmoid_default)
        convolution_default_4 = torch.ops.aten.convolution.default(mul_tensor, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_127, 1);  primals_127 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_130, primals_131, primals_128, primals_129, True, 0.1, 0.001);  primals_131 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_6, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_132, 1);  primals_132 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_135, primals_136, primals_133, primals_134, True, 0.1, 0.001);  primals_136 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        silu__default_3 = torch.ops.aten.silu_.default(getitem_9)
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(silu__default_3, [0, 1, 0, 1], 0.0);  silu__default_3 = None
        convolution_default_6 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, primals_7, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_137, 1);  primals_137 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_140, primals_141, primals_138, primals_139, True, 0.1, 0.001);  primals_141 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        silu__default_4 = torch.ops.aten.silu_.default(getitem_12)
        mean_dim_1 = torch.ops.aten.mean.dim(silu__default_4, [2, 3], True)
        convolution_default_7 = torch.ops.aten.convolution.default(mean_dim_1, primals_13, primals_12, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_12 = None
        silu__default_5 = torch.ops.aten.silu_.default(convolution_default_7)
        convolution_default_8 = torch.ops.aten.convolution.default(silu__default_5, primals_11, primals_10, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_10 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_8);  convolution_default_8 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(silu__default_4, sigmoid_default_1)
        convolution_default_9 = torch.ops.aten.convolution.default(mul_tensor_1, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_142, 1);  primals_142 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_145, primals_146, primals_143, primals_144, True, 0.1, 0.001);  primals_146 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_10 = torch.ops.aten.convolution.default(getitem_15, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_147, 1);  primals_147 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_150, primals_151, primals_148, primals_149, True, 0.1, 0.001);  primals_151 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        silu__default_6 = torch.ops.aten.silu_.default(getitem_18)
        convolution_default_11 = torch.ops.aten.convolution.default(silu__default_6, primals_14, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_152, 1);  primals_152 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_155, primals_156, primals_153, primals_154, True, 0.1, 0.001);  primals_156 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        silu__default_7 = torch.ops.aten.silu_.default(getitem_21)
        mean_dim_2 = torch.ops.aten.mean.dim(silu__default_7, [2, 3], True)
        convolution_default_12 = torch.ops.aten.convolution.default(mean_dim_2, primals_20, primals_19, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_19 = None
        silu__default_8 = torch.ops.aten.silu_.default(convolution_default_12)
        convolution_default_13 = torch.ops.aten.convolution.default(silu__default_8, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_13);  convolution_default_13 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(silu__default_7, sigmoid_default_2)
        convolution_default_14 = torch.ops.aten.convolution.default(mul_tensor_2, primals_16, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_157, 1);  primals_157 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_160, primals_161, primals_158, primals_159, True, 0.1, 0.001);  primals_161 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_24, getitem_15);  getitem_24 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_9, primals_22, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_162, 1);  primals_162 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_165, primals_166, primals_163, primals_164, True, 0.1, 0.001);  primals_166 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        silu__default_9 = torch.ops.aten.silu_.default(getitem_27)
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(silu__default_9, [1, 2, 1, 2], 0.0);  silu__default_9 = None
        convolution_default_16 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, primals_21, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 144)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_167, 1);  primals_167 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_170, primals_171, primals_168, primals_169, True, 0.1, 0.001);  primals_171 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        silu__default_10 = torch.ops.aten.silu_.default(getitem_30)
        mean_dim_3 = torch.ops.aten.mean.dim(silu__default_10, [2, 3], True)
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_3, primals_27, primals_26, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_26 = None
        silu__default_11 = torch.ops.aten.silu_.default(convolution_default_17)
        convolution_default_18 = torch.ops.aten.convolution.default(silu__default_11, primals_25, primals_24, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_24 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_18);  convolution_default_18 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(silu__default_10, sigmoid_default_3)
        convolution_default_19 = torch.ops.aten.convolution.default(mul_tensor_3, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_172, 1);  primals_172 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_175, primals_176, primals_173, primals_174, True, 0.1, 0.001);  primals_176 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_33, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_177, 1);  primals_177 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_180, primals_181, primals_178, primals_179, True, 0.1, 0.001);  primals_181 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        silu__default_12 = torch.ops.aten.silu_.default(getitem_36)
        convolution_default_21 = torch.ops.aten.convolution.default(silu__default_12, primals_28, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 240)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_182, 1);  primals_182 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_185, primals_186, primals_183, primals_184, True, 0.1, 0.001);  primals_186 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        silu__default_13 = torch.ops.aten.silu_.default(getitem_39)
        mean_dim_4 = torch.ops.aten.mean.dim(silu__default_13, [2, 3], True)
        convolution_default_22 = torch.ops.aten.convolution.default(mean_dim_4, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        silu__default_14 = torch.ops.aten.silu_.default(convolution_default_22)
        convolution_default_23 = torch.ops.aten.convolution.default(silu__default_14, primals_32, primals_31, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_31 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_23);  convolution_default_23 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(silu__default_13, sigmoid_default_4)
        convolution_default_24 = torch.ops.aten.convolution.default(mul_tensor_4, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_187, 1);  primals_187 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_190, primals_191, primals_188, primals_189, True, 0.1, 0.001);  primals_191 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_42, getitem_33);  getitem_42 = None
        convolution_default_25 = torch.ops.aten.convolution.default(add_tensor_16, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_192, 1);  primals_192 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_195, primals_196, primals_193, primals_194, True, 0.1, 0.001);  primals_196 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        silu__default_15 = torch.ops.aten.silu_.default(getitem_45)
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(silu__default_15, [0, 1, 0, 1], 0.0);  silu__default_15 = None
        convolution_default_26 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, primals_35, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 240)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_197, 1);  primals_197 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_200, primals_201, primals_198, primals_199, True, 0.1, 0.001);  primals_201 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        silu__default_16 = torch.ops.aten.silu_.default(getitem_48)
        mean_dim_5 = torch.ops.aten.mean.dim(silu__default_16, [2, 3], True)
        convolution_default_27 = torch.ops.aten.convolution.default(mean_dim_5, primals_41, primals_40, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_40 = None
        silu__default_17 = torch.ops.aten.silu_.default(convolution_default_27)
        convolution_default_28 = torch.ops.aten.convolution.default(silu__default_17, primals_39, primals_38, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_38 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_28);  convolution_default_28 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(silu__default_16, sigmoid_default_5)
        convolution_default_29 = torch.ops.aten.convolution.default(mul_tensor_5, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_202, 1);  primals_202 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_205, primals_206, primals_203, primals_204, True, 0.1, 0.001);  primals_206 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        convolution_default_30 = torch.ops.aten.convolution.default(getitem_51, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_207, 1);  primals_207 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_210, primals_211, primals_208, primals_209, True, 0.1, 0.001);  primals_211 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        silu__default_18 = torch.ops.aten.silu_.default(getitem_54)
        convolution_default_31 = torch.ops.aten.convolution.default(silu__default_18, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_212, 1);  primals_212 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_215, primals_216, primals_213, primals_214, True, 0.1, 0.001);  primals_216 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        silu__default_19 = torch.ops.aten.silu_.default(getitem_57)
        mean_dim_6 = torch.ops.aten.mean.dim(silu__default_19, [2, 3], True)
        convolution_default_32 = torch.ops.aten.convolution.default(mean_dim_6, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        silu__default_20 = torch.ops.aten.silu_.default(convolution_default_32)
        convolution_default_33 = torch.ops.aten.convolution.default(silu__default_20, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_33);  convolution_default_33 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(silu__default_19, sigmoid_default_6)
        convolution_default_34 = torch.ops.aten.convolution.default(mul_tensor_6, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_217, 1);  primals_217 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_220, primals_221, primals_218, primals_219, True, 0.1, 0.001);  primals_221 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(getitem_60, getitem_51);  getitem_60 = None
        convolution_default_35 = torch.ops.aten.convolution.default(add_tensor_23, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_222, 1);  primals_222 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_225, primals_226, primals_223, primals_224, True, 0.1, 0.001);  primals_226 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        silu__default_21 = torch.ops.aten.silu_.default(getitem_63)
        convolution_default_36 = torch.ops.aten.convolution.default(silu__default_21, primals_49, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_227, 1);  primals_227 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_230, primals_231, primals_228, primals_229, True, 0.1, 0.001);  primals_231 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        silu__default_22 = torch.ops.aten.silu_.default(getitem_66)
        mean_dim_7 = torch.ops.aten.mean.dim(silu__default_22, [2, 3], True)
        convolution_default_37 = torch.ops.aten.convolution.default(mean_dim_7, primals_55, primals_54, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_54 = None
        silu__default_23 = torch.ops.aten.silu_.default(convolution_default_37)
        convolution_default_38 = torch.ops.aten.convolution.default(silu__default_23, primals_53, primals_52, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_52 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_38);  convolution_default_38 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(silu__default_22, sigmoid_default_7)
        convolution_default_39 = torch.ops.aten.convolution.default(mul_tensor_7, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_232, 1);  primals_232 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_235, primals_236, primals_233, primals_234, True, 0.1, 0.001);  primals_236 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_69, add_tensor_23);  getitem_69 = None
        convolution_default_40 = torch.ops.aten.convolution.default(add_tensor_27, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_237, 1);  primals_237 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_240, primals_241, primals_238, primals_239, True, 0.1, 0.001);  primals_241 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        silu__default_24 = torch.ops.aten.silu_.default(getitem_72)
        convolution_default_41 = torch.ops.aten.convolution.default(silu__default_24, primals_56, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 480)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_242, 1);  primals_242 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_245, primals_246, primals_243, primals_244, True, 0.1, 0.001);  primals_246 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        silu__default_25 = torch.ops.aten.silu_.default(getitem_75)
        mean_dim_8 = torch.ops.aten.mean.dim(silu__default_25, [2, 3], True)
        convolution_default_42 = torch.ops.aten.convolution.default(mean_dim_8, primals_62, primals_61, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_61 = None
        silu__default_26 = torch.ops.aten.silu_.default(convolution_default_42)
        convolution_default_43 = torch.ops.aten.convolution.default(silu__default_26, primals_60, primals_59, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_59 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_43);  convolution_default_43 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(silu__default_25, sigmoid_default_8)
        convolution_default_44 = torch.ops.aten.convolution.default(mul_tensor_8, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_247, 1);  primals_247 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_250, primals_251, primals_248, primals_249, True, 0.1, 0.001);  primals_251 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        convolution_default_45 = torch.ops.aten.convolution.default(getitem_78, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_252, 1);  primals_252 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_255, primals_256, primals_253, primals_254, True, 0.1, 0.001);  primals_256 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        silu__default_27 = torch.ops.aten.silu_.default(getitem_81)
        convolution_default_46 = torch.ops.aten.convolution.default(silu__default_27, primals_63, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_257, 1);  primals_257 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_260, primals_261, primals_258, primals_259, True, 0.1, 0.001);  primals_261 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        silu__default_28 = torch.ops.aten.silu_.default(getitem_84)
        mean_dim_9 = torch.ops.aten.mean.dim(silu__default_28, [2, 3], True)
        convolution_default_47 = torch.ops.aten.convolution.default(mean_dim_9, primals_69, primals_68, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_68 = None
        silu__default_29 = torch.ops.aten.silu_.default(convolution_default_47)
        convolution_default_48 = torch.ops.aten.convolution.default(silu__default_29, primals_67, primals_66, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_66 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_48);  convolution_default_48 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(silu__default_28, sigmoid_default_9)
        convolution_default_49 = torch.ops.aten.convolution.default(mul_tensor_9, primals_65, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_262, 1);  primals_262 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_265, primals_266, primals_263, primals_264, True, 0.1, 0.001);  primals_266 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(getitem_87, getitem_78);  getitem_87 = None
        convolution_default_50 = torch.ops.aten.convolution.default(add_tensor_34, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_267, 1);  primals_267 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_270, primals_271, primals_268, primals_269, True, 0.1, 0.001);  primals_271 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        silu__default_30 = torch.ops.aten.silu_.default(getitem_90)
        convolution_default_51 = torch.ops.aten.convolution.default(silu__default_30, primals_70, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_272, 1);  primals_272 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_275, primals_276, primals_273, primals_274, True, 0.1, 0.001);  primals_276 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        silu__default_31 = torch.ops.aten.silu_.default(getitem_93)
        mean_dim_10 = torch.ops.aten.mean.dim(silu__default_31, [2, 3], True)
        convolution_default_52 = torch.ops.aten.convolution.default(mean_dim_10, primals_76, primals_75, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_75 = None
        silu__default_32 = torch.ops.aten.silu_.default(convolution_default_52)
        convolution_default_53 = torch.ops.aten.convolution.default(silu__default_32, primals_74, primals_73, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_73 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_53);  convolution_default_53 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(silu__default_31, sigmoid_default_10)
        convolution_default_54 = torch.ops.aten.convolution.default(mul_tensor_10, primals_72, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_277, 1);  primals_277 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_280, primals_281, primals_278, primals_279, True, 0.1, 0.001);  primals_281 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_96, add_tensor_34);  getitem_96 = None
        convolution_default_55 = torch.ops.aten.convolution.default(add_tensor_38, primals_78, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_282, 1);  primals_282 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_285, primals_286, primals_283, primals_284, True, 0.1, 0.001);  primals_286 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        silu__default_33 = torch.ops.aten.silu_.default(getitem_99)
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(silu__default_33, [1, 2, 1, 2], 0.0);  silu__default_33 = None
        convolution_default_56 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, primals_77, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 672)
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_287, 1);  primals_287 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_290, primals_291, primals_288, primals_289, True, 0.1, 0.001);  primals_291 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        silu__default_34 = torch.ops.aten.silu_.default(getitem_102)
        mean_dim_11 = torch.ops.aten.mean.dim(silu__default_34, [2, 3], True)
        convolution_default_57 = torch.ops.aten.convolution.default(mean_dim_11, primals_83, primals_82, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_82 = None
        silu__default_35 = torch.ops.aten.silu_.default(convolution_default_57)
        convolution_default_58 = torch.ops.aten.convolution.default(silu__default_35, primals_81, primals_80, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_80 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_58);  convolution_default_58 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(silu__default_34, sigmoid_default_11)
        convolution_default_59 = torch.ops.aten.convolution.default(mul_tensor_11, primals_79, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_292, 1);  primals_292 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_295, primals_296, primals_293, primals_294, True, 0.1, 0.001);  primals_296 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        convolution_default_60 = torch.ops.aten.convolution.default(getitem_105, primals_85, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_42 = torch.ops.aten.add.Tensor(primals_297, 1);  primals_297 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_300, primals_301, primals_298, primals_299, True, 0.1, 0.001);  primals_301 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        silu__default_36 = torch.ops.aten.silu_.default(getitem_108)
        convolution_default_61 = torch.ops.aten.convolution.default(silu__default_36, primals_84, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_302, 1);  primals_302 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_305, primals_306, primals_303, primals_304, True, 0.1, 0.001);  primals_306 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        silu__default_37 = torch.ops.aten.silu_.default(getitem_111)
        mean_dim_12 = torch.ops.aten.mean.dim(silu__default_37, [2, 3], True)
        convolution_default_62 = torch.ops.aten.convolution.default(mean_dim_12, primals_90, primals_89, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_89 = None
        silu__default_38 = torch.ops.aten.silu_.default(convolution_default_62)
        convolution_default_63 = torch.ops.aten.convolution.default(silu__default_38, primals_88, primals_87, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_87 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_63);  convolution_default_63 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(silu__default_37, sigmoid_default_12)
        convolution_default_64 = torch.ops.aten.convolution.default(mul_tensor_12, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_307, 1);  primals_307 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_310, primals_311, primals_308, primals_309, True, 0.1, 0.001);  primals_311 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_114, getitem_105);  getitem_114 = None
        convolution_default_65 = torch.ops.aten.convolution.default(add_tensor_45, primals_92, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_312, 1);  primals_312 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_315, primals_316, primals_313, primals_314, True, 0.1, 0.001);  primals_316 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        silu__default_39 = torch.ops.aten.silu_.default(getitem_117)
        convolution_default_66 = torch.ops.aten.convolution.default(silu__default_39, primals_91, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_317, 1);  primals_317 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_320, primals_321, primals_318, primals_319, True, 0.1, 0.001);  primals_321 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        silu__default_40 = torch.ops.aten.silu_.default(getitem_120)
        mean_dim_13 = torch.ops.aten.mean.dim(silu__default_40, [2, 3], True)
        convolution_default_67 = torch.ops.aten.convolution.default(mean_dim_13, primals_97, primals_96, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_96 = None
        silu__default_41 = torch.ops.aten.silu_.default(convolution_default_67)
        convolution_default_68 = torch.ops.aten.convolution.default(silu__default_41, primals_95, primals_94, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_94 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_68);  convolution_default_68 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(silu__default_40, sigmoid_default_13)
        convolution_default_69 = torch.ops.aten.convolution.default(mul_tensor_13, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_322, 1);  primals_322 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_325, primals_326, primals_323, primals_324, True, 0.1, 0.001);  primals_326 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(getitem_123, add_tensor_45);  getitem_123 = None
        convolution_default_70 = torch.ops.aten.convolution.default(add_tensor_49, primals_99, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_327, 1);  primals_327 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_330, primals_331, primals_328, primals_329, True, 0.1, 0.001);  primals_331 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        silu__default_42 = torch.ops.aten.silu_.default(getitem_126)
        convolution_default_71 = torch.ops.aten.convolution.default(silu__default_42, primals_98, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1152)
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_332, 1);  primals_332 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_335, primals_336, primals_333, primals_334, True, 0.1, 0.001);  primals_336 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        silu__default_43 = torch.ops.aten.silu_.default(getitem_129)
        mean_dim_14 = torch.ops.aten.mean.dim(silu__default_43, [2, 3], True)
        convolution_default_72 = torch.ops.aten.convolution.default(mean_dim_14, primals_104, primals_103, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_103 = None
        silu__default_44 = torch.ops.aten.silu_.default(convolution_default_72)
        convolution_default_73 = torch.ops.aten.convolution.default(silu__default_44, primals_102, primals_101, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_101 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_73);  convolution_default_73 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(silu__default_43, sigmoid_default_14)
        convolution_default_74 = torch.ops.aten.convolution.default(mul_tensor_14, primals_100, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_337, 1);  primals_337 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_340, primals_341, primals_338, primals_339, True, 0.1, 0.001);  primals_341 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_132, add_tensor_49);  getitem_132 = None
        convolution_default_75 = torch.ops.aten.convolution.default(add_tensor_53, primals_106, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_342, 1);  primals_342 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_345, primals_346, primals_343, primals_344, True, 0.1, 0.001);  primals_346 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        silu__default_45 = torch.ops.aten.silu_.default(getitem_135)
        convolution_default_76 = torch.ops.aten.convolution.default(silu__default_45, primals_105, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1152)
        add_tensor_55 = torch.ops.aten.add.Tensor(primals_347, 1);  primals_347 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_350, primals_351, primals_348, primals_349, True, 0.1, 0.001);  primals_351 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        silu__default_46 = torch.ops.aten.silu_.default(getitem_138)
        mean_dim_15 = torch.ops.aten.mean.dim(silu__default_46, [2, 3], True)
        convolution_default_77 = torch.ops.aten.convolution.default(mean_dim_15, primals_111, primals_110, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_110 = None
        silu__default_47 = torch.ops.aten.silu_.default(convolution_default_77)
        convolution_default_78 = torch.ops.aten.convolution.default(silu__default_47, primals_109, primals_108, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_108 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_78);  convolution_default_78 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(silu__default_46, sigmoid_default_15)
        convolution_default_79 = torch.ops.aten.convolution.default(mul_tensor_15, primals_107, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_352, 1);  primals_352 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_355, primals_356, primals_353, primals_354, True, 0.1, 0.001);  primals_356 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        convolution_default_80 = torch.ops.aten.convolution.default(getitem_141, primals_114, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_357, 1);  primals_357 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_360, primals_361, primals_358, primals_359, True, 0.1, 0.001);  primals_361 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        silu__default_48 = torch.ops.aten.silu_.default(getitem_144)
        mean_dim_16 = torch.ops.aten.mean.dim(silu__default_48, [-1, -2], True);  silu__default_48 = None
        view_default = torch.ops.aten.view.default(mean_dim_16, [128, 1280]);  mean_dim_16 = None
        t_default = torch.ops.aten.t.default(primals_113);  primals_113 = None
        addmm_default = torch.ops.aten.addmm.default(primals_112, view_default, t_default);  primals_112 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_24, add_tensor_25, add_tensor_26, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_35, add_tensor_36, add_tensor_37, add_tensor_39, add_tensor_40, add_tensor_41, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_50, add_tensor_51, add_tensor_52, add_tensor_54, add_tensor_55, add_tensor_56, add_tensor_57, primals_200, convolution_default_50, getitem_104, getitem_89, primals_100, convolution_default_80, getitem_88, getitem_144, convolution_default_1, silu__default, primals_185, primals_208, getitem_146, getitem_3, primals_205, getitem_145, primals_199, primals_180, view_default, silu__default_34, add_tensor_34, primals_178, primals_203, getitem_5, mean_dim, getitem_90, primals_130, getitem_4, primals_179, primals_190, getitem_92, convolution_default_57, getitem_93, getitem_91, primals_183, silu__default_35, primals_102, primals_204, silu__default_1, primals_99, convolution_default_2, sigmoid_default_11, silu__default_30, primals_188, convolution_default, t_default, getitem_1, getitem, mul_tensor_7, mul_tensor_11, convolution_default_51, getitem_2, convolution_default_59, primals_184, primals_189, silu__default_2, convolution_default_39, primals_333, primals_109, convolution_default_32, primals_254, getitem_59, primals_164, getitem_58, mean_dim_6, getitem_71, convolution_default_40, primals_20, getitem_70, getitem_72, primals_323, primals_14, primals_285, primals_325, primals_324, primals_169, primals_255, primals_15, getitem_57, primals_16, add_tensor_27, primals_253, primals_249, primals_328, silu__default_19, primals_248, primals_79, getitem_74, primals_289, getitem_73, primals_250, primals_329, primals_163, primals_114, primals_107, primals_111, primals_330, primals_170, primals_288, primals_81, primals_290, silu__default_20, primals_258, silu__default_24, primals_165, primals_245, primals_18, mul_tensor_6, convolution_default_41, primals_259, sigmoid_default_6, primals_168, primals_42, primals_43, primals_48, convolution_default_19, primals_51, primals_353, getitem_33, primals_355, silu__default_43, primals_50, primals_359, primals_2, primals_44, primals_39, getitem_35, getitem_36, getitem_34, primals_115, convolution_default_20, primals_119, getitem_38, getitem_37, primals_1, primals_41, primals_118, primals_124, primals_120, primals_354, primals_123, primals_358, convolution_default_21, primals_46, silu__default_12, primals_49, getitem_94, convolution_default_24, sigmoid_default_2, getitem_116, getitem_6, getitem_95, silu__default_6, convolution_default_14, mul_tensor, primals_238, getitem_13, getitem_115, convolution_default_65, sigmoid_default, getitem_41, mean_dim_10, convolution_default_4, mean_dim_4, add_tensor_45, getitem_117, getitem_40, mean_dim_1, getitem_43, getitem_23, getitem_44, getitem_12, mean_dim_2, convolution_default_25, getitem_22, getitem_25, silu__default_31, getitem_26, getitem_119, convolution_default_15, mul_tensor_3, mean_dim_13, getitem_14, getitem_45, convolution_default_52, getitem_118, getitem_7, getitem_8, getitem_27, primals_233, getitem_39, getitem_10, add_tensor_16, getitem_21, silu__default_13, getitem_28, add_tensor_9, silu__default_7, convolution_default_22, getitem_47, silu__default_32, constant_pad_nd_default_3, convolution_default_5, silu__default_4, mul_tensor_2, getitem_46, silu__default_39, convolution_default_12, convolution_default_16, constant_pad_nd_default_2, convolution_default_7, getitem_9, getitem_29, convolution_default_66, getitem_120, sigmoid_default_10, constant_pad_nd_default, convolution_default_6, constant_pad_nd_default_1, mul_tensor_10, primals_235, getitem_11, convolution_default_54, silu__default_14, getitem_121, sigmoid_default_4, getitem_122, convolution_default_26, mul_tensor_4, silu__default_5, silu__default_8, primals_234, convolution_default_34, getitem_15, getitem_78, getitem_98, getitem_99, primals_348, primals_67, getitem_80, mul_tensor_1, getitem_81, sigmoid_default_1, getitem_97, getitem_134, add_tensor_53, primals_104, convolution_default_9, getitem_79, primals_134, primals_76, primals_150, getitem_61, getitem_62, primals_148, convolution_default_35, primals_338, silu__default_37, primals_224, add_tensor_38, getitem_137, primals_343, primals_349, getitem_63, getitem_136, convolution_default_72, primals_139, primals_335, convolution_default_45, primals_344, primals_69, getitem_16, primals_240, getitem_17, getitem_101, convolution_default_62, convolution_default_55, primals_143, add_tensor_23, getitem_100, primals_334, getitem_18, getitem_83, silu__default_44, primals_239, primals_345, primals_144, getitem_82, getitem_135, getitem_65, silu__default_38, primals_339, getitem_64, primals_74, convolution_default_10, silu__default_45, getitem_19, primals_138, mul_tensor_14, primals_243, getitem_124, primals_350, convolution_default_76, primals_65, mul_tensor_12, sigmoid_default_14, getitem_139, primals_133, primals_135, sigmoid_default_12, getitem_138, getitem_20, convolution_default_74, silu__default_27, primals_105, getitem_102, mean_dim_15, convolution_default_31, convolution_default_64, primals_140, silu__default_21, convolution_default_46, getitem_140, constant_pad_nd_default_4, convolution_default_75, getitem_133, primals_78, primals_106, primals_149, primals_223, convolution_default_56, convolution_default_36, mean_dim_11, primals_77, primals_340, primals_70, primals_145, convolution_default_11, getitem_103, primals_160, primals_88, getitem_77, convolution_default_42, primals_153, getitem_76, primals_95, primals_128, primals_230, primals_225, primals_91, primals_125, primals_284, getitem_75, mean_dim_9, primals_86, primals_244, primals_154, primals_92, primals_84, silu__default_25, primals_278, mean_dim_8, primals_280, primals_159, primals_85, primals_98, primals_158, primals_198, primals_283, convolution_default_44, primals_195, silu__default_26, primals_83, primals_228, primals_129, primals_193, primals_97, primals_93, primals_155, primals_279, sigmoid_default_8, primals_194, primals_229, primals_90, mul_tensor_8, primals_173, getitem_125, primals_265, primals_260, mean_dim_5, getitem_49, primals_274, getitem_48, primals_72, add_tensor_49, convolution_default_27, primals_264, getitem_50, getitem_128, primals_275, getitem_127, primals_174, silu__default_16, getitem_126, primals_215, silu__default_42, primals_269, primals_220, convolution_default_71, mean_dim_14, primals_175, primals_214, getitem_130, primals_273, primals_270, primals_263, silu__default_17, getitem_129, primals_268, primals_218, primals_71, mul_tensor_5, primals_219, getitem_131, sigmoid_default_5, primals_298, getitem_51, primals_55, primals_300, getitem_85, mean_dim_7, primals_209, primals_360, getitem_107, getitem_31, getitem_68, getitem_86, primals_25, getitem_106, primals_294, primals_314, getitem_67, silu__default_46, primals_293, primals_303, mean_dim_3, convolution_default_47, primals_29, getitem_84, getitem_105, primals_37, getitem_54, getitem_52, convolution_default_60, silu__default_40, primals_57, getitem_30, getitem_53, getitem_108, primals_63, primals_28, convolution_default_29, primals_53, primals_299, getitem_32, convolution_default_77, primals_22, primals_308, primals_64, primals_310, convolution_default_67, convolution_default_37, silu__default_28, getitem_110, primals_7, mean_dim_12, primals_11, primals_27, getitem_109, primals_13, silu__default_22, getitem_66, silu__default_47, primals_30, convolution_default_30, primals_58, primals_305, silu__default_41, primals_4, primals_313, sigmoid_default_15, primals_62, getitem_56, silu__default_10, primals_23, primals_213, getitem_55, silu__default_29, getitem_113, convolution_default_17, primals_320, mul_tensor_13, primals_36, primals_309, primals_6, primals_32, primals_34, primals_295, silu__default_36, primals_318, getitem_141, silu__default_23, sigmoid_default_13, convolution_default_79, sigmoid_default_3, convolution_default_61, getitem_111, sigmoid_default_9, primals_21, primals_60, convolution_default_69, primals_56, primals_304, getitem_142, sigmoid_default_7, mul_tensor_9, primals_8, mul_tensor_15, primals_35, silu__default_18, convolution_default_49, convolution_default_70, primals_319, getitem_112, getitem_143, primals_315, silu__default_11, primals_210, primals_9]
        
