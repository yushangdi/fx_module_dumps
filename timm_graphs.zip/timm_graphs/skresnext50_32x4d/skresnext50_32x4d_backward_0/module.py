
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/skresnext50_32x4d/skresnext50_32x4d_backward_0/state_dict.pt'))

    
    
    def forward(self, convolution_default_32, primals_106, primals_276, convolution_default_23, getitem_253, getitem_183, primals_102, getitem_252, relu__default_56, relu__default_18, getitem_81, relu__default_57, primals_30, primals_268, relu__default_24, convolution_default_72, primals_24, primals_266, convolution_default_22, convolution_default_98, getitem_61, getitem_66, primals_107, primals_105, _softmax_default_4, primals_272, getitem_60, primals_16, primals_301, primals_26, getitem_232, primals_103, primals_297, primals_517, primals_104, _softmax_default_15, primals_296, getitem_184, primals_19, relu__default_17, getitem_64, sum_dim_int_list_31, convolution_default_71, sum_dim_int_list_7, primals_17, primals_31, primals_95, primals_108, getitem_234, primals_97, _softmax_default_3, getitem_63, mean_dim_15, mean_dim_3, stack_default_3, primals_101, relu__default_2, sum_dim_int_list_9, primals_15, primals_112, primals_96, primals_267, primals_278, getitem_115, primals_271, getitem_180, primals_109, primals_273, primals_29, primals_98, getitem_58, convolution_default_25, convolution_default_26, relu__default_19, primals_281, relu__default_41, relu__default_79, primals_25, getitem_181, mean_dim_4, primals_32, getitem_82, primals_23, primals_18, primals_277, convolution_default_100, primals_298, primals_20, getitem_67, primals_187, primals_502, primals_228, sum_dim_int_list_15, primals_82, getitem_45, primals_498, primals_84, primals_191, primals_481, sum_dim_int_list_23, primals_94, primals_501, primals_87, primals_162, primals_13, primals_233, primals_483, primals_317, stack_default_2, primals_192, primals_6, primals_201, primals_223, primals_478, convolution_default_50, getitem_46, getitem_129, getitem_192, getitem_127, primals_155, primals_231, primals_194, primals_472, primals_158, getitem_126, primals_12, primals_186, primals_326, primals_83, primals_221, primals_487, primals_85, primals_159, primals_321, getitem_90, primals_198, primals_316, getitem_91, relu__default_39, primals_488, convolution_default_16, primals_227, primals_477, getitem_93, primals_476, mean_dim_2, primals_157, primals_185, primals_232, primals_3, primals_492, primals_4, primals_86, primals_197, primals_471, relu__default_60, primals_93, primals_154, primals_482, primals_14, primals_328, relu__default_13, primals_9, primals_164, primals_190, primals_156, primals_497, convolution_default_35, primals_91, primals_153, primals_193, primals_327, primals_473, primals_322, primals_496, relu__default_27, convolution_default_75, primals_323, convolution_default_17, primals_196, convolution_default_19, primals_318, primals_491, primals_222, convolution_default_45, primals_226, primals_493, relu__default_12, primals_5, primals_81, primals_503, primals_92, primals_165, primals_486, primals_90, primals_163, primals_195, _softmax_default_7, primals_152, getitem_94, relu__default_14, primals_151, stack_default_6, primals_175, getitem_213, getitem_102, stack_default_11, sum_dim_int_list_13, primals_40, primals_178, mean_dim, primals_170, getitem_132, relu__default_32, primals_181, primals_33, convolution_default_51, getitem_133, getitem_109, stack_default_13, getitem_189, primals_184, getitem_214, relu__default_58, convolution_default_84, relu__default_72, primals_46, getitem_16, relu__default_30, primals_177, getitem_130, convolution_default_15, convolution_default_52, getitem_18, convolution_default_41, primals_179, getitem_39, relu__default_33, getitem_186, primals_35, convolution_default_85, primals_41, getitem_19, primals_34, stack_default, mean_dim_11, primals_37, primals_362, convolution_default_4, getitem_216, relu__default_3, getitem_135, getitem_190, relu__default_67, primals_363, convolution_default_40, getitem_100, primals_47, getitem_217, primals_366, primals_173, primals_43, getitem_42, primals_176, relu__default_31, primals_54, convolution_default_73, primals_45, relu__default_10, getitem_15, sum_dim_int_list_1, getitem_43, primals_367, convolution_default_14, getitem_105, relu__default_59, primals_53, getitem_12, primals_51, primals_180, primals_361, relu__default_4, primals_168, relu__default_40, primals_174, getitem_99, primals_169, primals_368, relu__default_11, primals_52, getitem_187, relu__default_73, primals_48, mean_dim_13, getitem_106, primals_166, _softmax_default_11, primals_44, _softmax_default, getitem_13, convolution_default_6, primals_36, relu__default_68, primals_167, convolution_default_7, primals_42, getitem_103, convolution_default_39, getitem_40, getitem_108, getitem_117, mean_dim_14, primals_73, primals_212, primals_238, primals_311, primals_252, primals_512, primals_242, primals_263, primals_522, getitem_52, primals_213, relu__default_34, convolution_default_44, primals_59, primals_262, primals_208, primals_308, primals_528, primals_446, primals_312, primals_506, primals_441, stack_default_14, convolution_default_94, primals_69, primals_206, primals_313, primals_507, primals_386, primals_527, primals_209, primals_383, relu__default_5, primals_63, convolution_default_46, getitem_199, getitem_202, primals_80, _softmax_default_6, relu__default_74, primals_207, primals_352, relu__default_42, stack_default_12, primals_71, primals_76, primals_236, primals_248, primals_302, primals_348, primals_518, primals_251, primals_342, primals_523, primals_72, primals_338, primals_65, primals_346, primals_307, primals_392, primals_448, convolution_default_3, relu__default_35, getitem_136, getitem_24, primals_443, convolution_default_9, _softmax_default_14, primals_70, primals_337, getitem_22, primals_203, getitem_237, primals_211, primals_436, primals_243, primals_205, primals_303, relu__default_6, primals_64, primals_351, getitem_10, convolution_default_42, primals_343, primals_437, primals_526, primals_511, primals_218, getitem_114, primals_393, convolution_default_8, primals_253, sum_dim_int_list_5, primals_247, sum_dim_int_list_29, primals_257, primals_341, relu__default_1, getitem_48, getitem_51, relu__default_36, getitem_6, getitem_49, getitem_139, primals_204, getitem_201, primals_256, getitem_25, mean_dim_12, primals_217, primals_442, convolution_default_79, getitem_231, primals_79, primals_237, primals_336, primals_74, primals_258, primals_306, primals_397, primals_68, primals_261, primals_388, convolution_default_2, primals_396, primals_438, primals_75, primals_347, primals_398, primals_241, primals_353, primals_513, primals_391, primals_516, getitem_7, primals_62, primals_387, primals_508, primals_216, getitem_21, primals_447, convolution_default_78, getitem_235, primals_246, primals_202, primals_125, convolution_default_21, primals_456, primals_123, primals_133, primals_145, primals_461, getitem_55, primals_462, convolution_default_63, primals_132, primals_466, getitem_3, stack_default_1, sum_dim_int_list_25, convolution_default_92, primals_451, relu__default_64, getitem_238, primals_56, convolution_default_11, primals_356, convolution_default_10, primals_131, convolution_default_33, primals_58, primals_130, getitem_88, primals_401, getitem_31, getitem_204, primals_458, getitem_57, convolution_default_81, primals_453, primals_115, primals_358, sum_dim_int_list_19, primals_406, primals_114, primals_142, primals_417, relu__default_62, primals_55, _softmax_default_12, primals_119, getitem_27, getitem_1, relu__default, getitem_28, primals_140, primals_403, convolution_default_54, getitem_85, getitem_162, convolution_default_1, getitem_87, primals_124, convolution_default_53, primals_148, primals_418, primals_143, primals_413, primals_144, relu__default_15, primals_118, primals_129, primals_134, primals_416, primals_135, primals_457, getitem_54, getitem_163, primals_147, relu__default_8, getitem_138, primals_408, primals_521, primals_137, relu__default_50, convolution_default_20, convolution_default_64, getitem_205, primals_126, primals_146, getitem_30, primals_121, primals_122, primals_136, primals_113, primals_463, mean_dim_1, primals_467, getitem_4, primals_141, getitem_2, primals_411, relu__default_26, getitem_160, primals_120, primals_407, relu__default_7, primals_357, relu__default_25, primals_402, primals_57, primals_412, primals_452, convolution_default_34, relu__default_49, relu__default_16, primals_468, getitem_84, getitem_208, relu__default_78, getitem_240, getitem_247, primals_332, getitem_159, getitem_211, getitem_249, relu__default_48, convolution_default_66, getitem_246, getitem_124, getitem_76, relu__default_37, getitem_156, convolution_default_82, primals_292, convolution_default_47, convolution_default_61, convolution_default_87, getitem_228, convolution_default_96, stack_default_9, primals_331, getitem_219, getitem_169, relu__default_52, relu__default_69, getitem_229, _softmax_default_13, relu__default_22, stack_default_4, primals_333, relu__default_23, getitem_250, primals_282, stack_default_7, relu__default_76, getitem_222, getitem_241, primals_287, getitem_121, primals_286, relu__default_51, relu__default_75, relu__default_66, convolution_default_88, primals_291, getitem_225, convolution_default_90, convolution_default_29, getitem_75, getitem_210, getitem_166, relu__default_70, getitem_123, getitem_223, getitem_168, getitem_79, _softmax_default_9, getitem_244, primals_288, getitem_207, getitem_220, convolution_default_65, getitem_165, getitem_226, getitem_120, relu__default_38, convolution_default_95, getitem_157, relu__default_71, mean_dim_7, getitem_243, relu__default_63, convolution_default_89, convolution_default, getitem_78, convolution_default_97, convolution_default_48, primals_283, convolution_default_83, sum_dim_int_list_27, relu__default_77, mean_dim_9, primals_293, relu__default_65, stack_default_15, mean_dim_8, relu__default_9, primals_427, getitem_145, primals_431, convolution_default_59, _softmax_default_1, sum_dim_int_list_17, convolution_default_55, relu__default_45, getitem_33, convolution_default_60, primals_422, getitem_153, _softmax_default_5, primals_423, relu__default_44, sum_dim_int_list_11, mean_dim_6, getitem_36, getitem_147, convolution_default_38, getitem_142, getitem_148, getitem_37, getitem_9, relu__default_47, getitem_112, getitem_97, getitem_96, getitem_151, primals_428, convolution_default_13, _softmax_default_2, relu__default_28, relu__default_29, getitem_34, convolution_default_36, relu__default_46, getitem_154, _softmax_default_8, getitem_141, getitem_150, mean_dim_5, primals_426, convolution_default_58, relu__default_43, primals_432, stack_default_8, primals_433, primals_421, stack_default_5, convolution_default_57, getitem_144, sum_dim_int_list_3, getitem_178, getitem_171, sum_dim_int_list_21, getitem_70, primals_376, primals_373, t_default, _softmax_default_10, getitem_177, convolution_default_69, relu__default_53, getitem_72, convolution_default_91, convolution_default_27, relu__default_55, convolution_default_30, convolution_default_67, convolution_default_70, convolution_default_77, convolution_default_28, convolution_default_76, getitem_255, getitem_196, primals_381, getitem_195, relu__default_21, getitem_172, relu__default_80, getitem_193, primals_377, primals_372, getitem_118, getitem_198, getitem_69, stack_default_10, mean_dim_10, getitem_174, primals_382, primals_371, relu__default_61, relu__default_20, getitem_111, primals_378, relu__default_54, getitem_73, getitem_175, getitem_256, view_default_16, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50, tangents_51, tangents_52, tangents_53, tangents_54, tangents_55, tangents_56, tangents_57, tangents_58, tangents_59, tangents_60, tangents_61, tangents_62, tangents_63, tangents_64, tangents_65):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default_16);  t_default_2 = view_default_16 = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_17 = torch.ops.aten.view.default(sum_dim_int_list_32, [1000]);  sum_dim_int_list_32 = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_18 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_18, [128, 2048, 7, 7]);  view_default_18 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_85, to_dtype);  le_scalar = new_zeros_default_85 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_100, primals_528, primals_526, primals_527, getitem_255, getitem_256, True, 1e-05, [True, True, True]);  convolution_default_100 = primals_528 = primals_526 = primals_527 = getitem_255 = getitem_256 = None
        getitem_257 = native_batch_norm_backward_default[0]
        getitem_258 = native_batch_norm_backward_default[1]
        getitem_259 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_257, sum_dim_int_list_31, primals_208, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_257 = sum_dim_int_list_31 = primals_208 = None
        getitem_260 = convolution_backward_default[0]
        getitem_261 = convolution_backward_default[1];  convolution_backward_default = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(getitem_260, 1);  getitem_260 = None
        expand_default_1 = torch.ops.aten.expand.default(unsqueeze_default, [128, 2, 1024, 7, 7]);  unsqueeze_default = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(expand_default_1, stack_default_15);  stack_default_15 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(expand_default_1, _softmax_default_15);  expand_default_1 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(mul_tensor_16, [3, 4], True);  mul_tensor_16 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_33, _softmax_default_15, 1, torch.float32);  sum_dim_int_list_33 = _softmax_default_15 = None
        view_default_19 = torch.ops.aten.view.default(_softmax_backward_data_default, [128, 2048, 1, 1]);  _softmax_backward_data_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(view_default_19, relu__default_79, primals_205, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_19 = primals_205 = None
        getitem_263 = convolution_backward_default_1[0]
        getitem_264 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_263, torch.float32);  getitem_263 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_86, to_dtype_3);  le_scalar_1 = new_zeros_default_86 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_98, primals_203, primals_201, primals_202, getitem_252, getitem_253, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_98 = primals_203 = primals_201 = primals_202 = getitem_252 = getitem_253 = None
        getitem_266 = native_batch_norm_backward_default_1[0]
        getitem_267 = native_batch_norm_backward_default_1[1]
        getitem_268 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_266, mean_dim_15, primals_204, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_266 = mean_dim_15 = primals_204 = None
        getitem_269 = convolution_backward_default_2[0]
        getitem_270 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_269, [128, 1024, 7, 7]);  getitem_269 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(div_scalar_1, 1);  div_scalar_1 = None
        expand_default_3 = torch.ops.aten.expand.default(unsqueeze_default_1, [128, 2, 1024, 7, 7]);  unsqueeze_default_1 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(mul_tensor_17, expand_default_3);  mul_tensor_17 = expand_default_3 = None
        unbind_int = torch.ops.aten.unbind.int(add_tensor_64, 1);  add_tensor_64 = None
        getitem_272 = unbind_int[0]
        getitem_273 = unbind_int[1];  unbind_int = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_273, torch.float32);  getitem_273 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_87, to_dtype_6);  le_scalar_2 = new_zeros_default_87 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_97, primals_523, primals_521, primals_522, getitem_249, getitem_250, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_97 = primals_523 = primals_521 = primals_522 = getitem_249 = getitem_250 = None
        getitem_274 = native_batch_norm_backward_default_2[0]
        getitem_275 = native_batch_norm_backward_default_2[1]
        getitem_276 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_274, relu__default_76, primals_207, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_274 = primals_207 = None
        getitem_277 = convolution_backward_default_3[0]
        getitem_278 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_272, torch.float32);  getitem_272 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_88, to_dtype_9);  le_scalar_3 = new_zeros_default_88 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_96, primals_518, primals_516, primals_517, getitem_246, getitem_247, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_96 = primals_518 = primals_516 = primals_517 = getitem_246 = getitem_247 = None
        getitem_280 = native_batch_norm_backward_default_3[0]
        getitem_281 = native_batch_norm_backward_default_3[1]
        getitem_282 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_280, relu__default_76, primals_206, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_280 = primals_206 = None
        getitem_283 = convolution_backward_default_4[0]
        getitem_284 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_277, getitem_283);  getitem_277 = getitem_283 = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_89, to_dtype_12);  le_scalar_4 = new_zeros_default_89 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_95, primals_513, primals_511, primals_512, getitem_243, getitem_244, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_95 = primals_513 = primals_511 = primals_512 = getitem_243 = getitem_244 = None
        getitem_286 = native_batch_norm_backward_default_4[0]
        getitem_287 = native_batch_norm_backward_default_4[1]
        getitem_288 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_286, relu__default_75, primals_198, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_286 = primals_198 = None
        getitem_289 = convolution_backward_default_5[0]
        getitem_290 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_289);  to_dtype_2 = getitem_289 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_90, to_dtype_15);  le_scalar_5 = new_zeros_default_90 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_94, primals_508, primals_506, primals_507, getitem_240, getitem_241, True, 1e-05, [True, True, True]);  convolution_default_94 = primals_508 = primals_506 = primals_507 = getitem_240 = getitem_241 = None
        getitem_292 = native_batch_norm_backward_default_5[0]
        getitem_293 = native_batch_norm_backward_default_5[1]
        getitem_294 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_292, sum_dim_int_list_29, primals_197, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_292 = sum_dim_int_list_29 = primals_197 = None
        getitem_295 = convolution_backward_default_6[0]
        getitem_296 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(getitem_295, 1);  getitem_295 = None
        expand_default_4 = torch.ops.aten.expand.default(unsqueeze_default_2, [128, 2, 1024, 7, 7]);  unsqueeze_default_2 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(expand_default_4, stack_default_14);  stack_default_14 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(expand_default_4, _softmax_default_14);  expand_default_4 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(mul_tensor_18, [3, 4], True);  mul_tensor_18 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_34, _softmax_default_14, 1, torch.float32);  sum_dim_int_list_34 = _softmax_default_14 = None
        view_default_20 = torch.ops.aten.view.default(_softmax_backward_data_default_1, [128, 2048, 1, 1]);  _softmax_backward_data_default_1 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(view_default_20, relu__default_74, primals_194, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_20 = primals_194 = None
        getitem_298 = convolution_backward_default_7[0]
        getitem_299 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_298, torch.float32);  getitem_298 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_91, to_dtype_18);  le_scalar_6 = new_zeros_default_91 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_92, primals_192, primals_190, primals_191, getitem_237, getitem_238, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_92 = primals_192 = primals_190 = primals_191 = getitem_237 = getitem_238 = None
        getitem_301 = native_batch_norm_backward_default_6[0]
        getitem_302 = native_batch_norm_backward_default_6[1]
        getitem_303 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_301, mean_dim_14, primals_193, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_301 = mean_dim_14 = primals_193 = None
        getitem_304 = convolution_backward_default_8[0]
        getitem_305 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_304, [128, 1024, 7, 7]);  getitem_304 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_5, 49);  expand_default_5 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(div_scalar_2, 1);  div_scalar_2 = None
        expand_default_6 = torch.ops.aten.expand.default(unsqueeze_default_3, [128, 2, 1024, 7, 7]);  unsqueeze_default_3 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(mul_tensor_19, expand_default_6);  mul_tensor_19 = expand_default_6 = None
        unbind_int_1 = torch.ops.aten.unbind.int(add_tensor_67, 1);  add_tensor_67 = None
        getitem_307 = unbind_int_1[0]
        getitem_308 = unbind_int_1[1];  unbind_int_1 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_308, torch.float32);  getitem_308 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_92, to_dtype_21);  le_scalar_7 = new_zeros_default_92 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_91, primals_503, primals_501, primals_502, getitem_234, getitem_235, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_91 = primals_503 = primals_501 = primals_502 = getitem_234 = getitem_235 = None
        getitem_309 = native_batch_norm_backward_default_7[0]
        getitem_310 = native_batch_norm_backward_default_7[1]
        getitem_311 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_309, relu__default_71, primals_196, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_309 = primals_196 = None
        getitem_312 = convolution_backward_default_9[0]
        getitem_313 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_307, torch.float32);  getitem_307 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_93, to_dtype_24);  le_scalar_8 = new_zeros_default_93 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_90, primals_498, primals_496, primals_497, getitem_231, getitem_232, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_90 = primals_498 = primals_496 = primals_497 = getitem_231 = getitem_232 = None
        getitem_315 = native_batch_norm_backward_default_8[0]
        getitem_316 = native_batch_norm_backward_default_8[1]
        getitem_317 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_315, relu__default_71, primals_195, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_315 = primals_195 = None
        getitem_318 = convolution_backward_default_10[0]
        getitem_319 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_312, getitem_318);  getitem_312 = getitem_318 = None
        to_dtype_27 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_94, to_dtype_27);  le_scalar_9 = new_zeros_default_94 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_89, primals_493, primals_491, primals_492, getitem_228, getitem_229, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_89 = primals_493 = primals_491 = primals_492 = getitem_228 = getitem_229 = None
        getitem_321 = native_batch_norm_backward_default_9[0]
        getitem_322 = native_batch_norm_backward_default_9[1]
        getitem_323 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_321, relu__default_70, primals_187, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_321 = primals_187 = None
        getitem_324 = convolution_backward_default_11[0]
        getitem_325 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(to_dtype_17, getitem_324);  to_dtype_17 = getitem_324 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_69, torch.float32);  add_tensor_69 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_95, to_dtype_30);  le_scalar_10 = new_zeros_default_95 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_88, primals_186, primals_184, primals_185, getitem_225, getitem_226, True, 1e-05, [True, True, True]);  convolution_default_88 = primals_186 = primals_184 = primals_185 = getitem_225 = getitem_226 = None
        getitem_327 = native_batch_norm_backward_default_10[0]
        getitem_328 = native_batch_norm_backward_default_10[1]
        getitem_329 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_327, relu__default_65, primals_181, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_327 = primals_181 = None
        getitem_330 = convolution_backward_default_12[0]
        getitem_331 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_87, primals_488, primals_486, primals_487, getitem_222, getitem_223, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_87 = primals_488 = primals_486 = primals_487 = getitem_222 = getitem_223 = None
        getitem_333 = native_batch_norm_backward_default_11[0]
        getitem_334 = native_batch_norm_backward_default_11[1]
        getitem_335 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_333, sum_dim_int_list_27, primals_180, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_333 = sum_dim_int_list_27 = primals_180 = None
        getitem_336 = convolution_backward_default_13[0]
        getitem_337 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(getitem_336, 1);  getitem_336 = None
        expand_default_7 = torch.ops.aten.expand.default(unsqueeze_default_4, [128, 2, 1024, 7, 7]);  unsqueeze_default_4 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(expand_default_7, stack_default_13);  stack_default_13 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(expand_default_7, _softmax_default_13);  expand_default_7 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(mul_tensor_20, [3, 4], True);  mul_tensor_20 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_35, _softmax_default_13, 1, torch.float32);  sum_dim_int_list_35 = _softmax_default_13 = None
        view_default_21 = torch.ops.aten.view.default(_softmax_backward_data_default_2, [128, 2048, 1, 1]);  _softmax_backward_data_default_2 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(view_default_21, relu__default_69, primals_177, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_21 = primals_177 = None
        getitem_339 = convolution_backward_default_14[0]
        getitem_340 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_339, torch.float32);  getitem_339 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_96, to_dtype_33);  le_scalar_11 = new_zeros_default_96 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_85, primals_175, primals_173, primals_174, getitem_219, getitem_220, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_85 = primals_175 = primals_173 = primals_174 = getitem_219 = getitem_220 = None
        getitem_342 = native_batch_norm_backward_default_12[0]
        getitem_343 = native_batch_norm_backward_default_12[1]
        getitem_344 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_342, mean_dim_13, primals_176, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_342 = mean_dim_13 = primals_176 = None
        getitem_345 = convolution_backward_default_15[0]
        getitem_346 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_345, [128, 1024, 7, 7]);  getitem_345 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_8, 49);  expand_default_8 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(div_scalar_3, 1);  div_scalar_3 = None
        expand_default_9 = torch.ops.aten.expand.default(unsqueeze_default_5, [128, 2, 1024, 7, 7]);  unsqueeze_default_5 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(mul_tensor_21, expand_default_9);  mul_tensor_21 = expand_default_9 = None
        unbind_int_2 = torch.ops.aten.unbind.int(add_tensor_70, 1);  add_tensor_70 = None
        getitem_348 = unbind_int_2[0]
        getitem_349 = unbind_int_2[1];  unbind_int_2 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_349, torch.float32);  getitem_349 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_97, to_dtype_36);  le_scalar_12 = new_zeros_default_97 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_84, primals_483, primals_481, primals_482, getitem_216, getitem_217, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_84 = primals_483 = primals_481 = primals_482 = getitem_216 = getitem_217 = None
        getitem_350 = native_batch_norm_backward_default_13[0]
        getitem_351 = native_batch_norm_backward_default_13[1]
        getitem_352 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_350, relu__default_66, primals_179, [0], [2, 2], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_350 = primals_179 = None
        getitem_353 = convolution_backward_default_16[0]
        getitem_354 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_348, torch.float32);  getitem_348 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_98, to_dtype_39);  le_scalar_13 = new_zeros_default_98 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_83, primals_478, primals_476, primals_477, getitem_213, getitem_214, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_83 = primals_478 = primals_476 = primals_477 = getitem_213 = getitem_214 = None
        getitem_356 = native_batch_norm_backward_default_14[0]
        getitem_357 = native_batch_norm_backward_default_14[1]
        getitem_358 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_356, relu__default_66, primals_178, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_356 = primals_178 = None
        getitem_359 = convolution_backward_default_17[0]
        getitem_360 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(getitem_353, getitem_359);  getitem_353 = getitem_359 = None
        to_dtype_42 = torch.ops.aten.to.dtype(add_tensor_71, torch.float32);  add_tensor_71 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_99, to_dtype_42);  le_scalar_14 = new_zeros_default_99 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_82, primals_473, primals_471, primals_472, getitem_210, getitem_211, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_82 = primals_473 = primals_471 = primals_472 = getitem_210 = getitem_211 = None
        getitem_362 = native_batch_norm_backward_default_15[0]
        getitem_363 = native_batch_norm_backward_default_15[1]
        getitem_364 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_362, relu__default_65, primals_170, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_362 = primals_170 = None
        getitem_365 = convolution_backward_default_18[0]
        getitem_366 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(getitem_330, getitem_365);  getitem_330 = getitem_365 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_72, torch.float32);  add_tensor_72 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_100, to_dtype_45);  le_scalar_15 = new_zeros_default_100 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_81, primals_468, primals_466, primals_467, getitem_207, getitem_208, True, 1e-05, [True, True, True]);  convolution_default_81 = primals_468 = primals_466 = primals_467 = getitem_207 = getitem_208 = None
        getitem_368 = native_batch_norm_backward_default_16[0]
        getitem_369 = native_batch_norm_backward_default_16[1]
        getitem_370 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_368, sum_dim_int_list_25, primals_169, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_368 = sum_dim_int_list_25 = primals_169 = None
        getitem_371 = convolution_backward_default_19[0]
        getitem_372 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(getitem_371, 1);  getitem_371 = None
        expand_default_10 = torch.ops.aten.expand.default(unsqueeze_default_6, [128, 2, 512, 14, 14]);  unsqueeze_default_6 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(expand_default_10, stack_default_12);  stack_default_12 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(expand_default_10, _softmax_default_12);  expand_default_10 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(mul_tensor_22, [3, 4], True);  mul_tensor_22 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_36, _softmax_default_12, 1, torch.float32);  sum_dim_int_list_36 = _softmax_default_12 = None
        view_default_22 = torch.ops.aten.view.default(_softmax_backward_data_default_3, [128, 1024, 1, 1]);  _softmax_backward_data_default_3 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(view_default_22, relu__default_64, primals_166, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_22 = primals_166 = None
        getitem_374 = convolution_backward_default_20[0]
        getitem_375 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_374, torch.float32);  getitem_374 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_101, to_dtype_48);  le_scalar_16 = new_zeros_default_101 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_79, primals_164, primals_162, primals_163, getitem_204, getitem_205, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_79 = primals_164 = primals_162 = primals_163 = getitem_204 = getitem_205 = None
        getitem_377 = native_batch_norm_backward_default_17[0]
        getitem_378 = native_batch_norm_backward_default_17[1]
        getitem_379 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_377, mean_dim_12, primals_165, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_377 = mean_dim_12 = primals_165 = None
        getitem_380 = convolution_backward_default_21[0]
        getitem_381 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_380, [128, 512, 14, 14]);  getitem_380 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_11, 196);  expand_default_11 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(div_scalar_4, 1);  div_scalar_4 = None
        expand_default_12 = torch.ops.aten.expand.default(unsqueeze_default_7, [128, 2, 512, 14, 14]);  unsqueeze_default_7 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_23, expand_default_12);  mul_tensor_23 = expand_default_12 = None
        unbind_int_3 = torch.ops.aten.unbind.int(add_tensor_73, 1);  add_tensor_73 = None
        getitem_383 = unbind_int_3[0]
        getitem_384 = unbind_int_3[1];  unbind_int_3 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_384, torch.float32);  getitem_384 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_102, to_dtype_51);  le_scalar_17 = new_zeros_default_102 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_78, primals_463, primals_461, primals_462, getitem_201, getitem_202, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_78 = primals_463 = primals_461 = primals_462 = getitem_201 = getitem_202 = None
        getitem_385 = native_batch_norm_backward_default_18[0]
        getitem_386 = native_batch_norm_backward_default_18[1]
        getitem_387 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_385, relu__default_61, primals_168, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_385 = primals_168 = None
        getitem_388 = convolution_backward_default_22[0]
        getitem_389 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_383, torch.float32);  getitem_383 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_103, to_dtype_54);  le_scalar_18 = new_zeros_default_103 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_77, primals_458, primals_456, primals_457, getitem_198, getitem_199, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_77 = primals_458 = primals_456 = primals_457 = getitem_198 = getitem_199 = None
        getitem_391 = native_batch_norm_backward_default_19[0]
        getitem_392 = native_batch_norm_backward_default_19[1]
        getitem_393 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_391, relu__default_61, primals_167, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_391 = primals_167 = None
        getitem_394 = convolution_backward_default_23[0]
        getitem_395 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(getitem_388, getitem_394);  getitem_388 = getitem_394 = None
        to_dtype_57 = torch.ops.aten.to.dtype(add_tensor_74, torch.float32);  add_tensor_74 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_104, to_dtype_57);  le_scalar_19 = new_zeros_default_104 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_76, primals_453, primals_451, primals_452, getitem_195, getitem_196, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_76 = primals_453 = primals_451 = primals_452 = getitem_195 = getitem_196 = None
        getitem_397 = native_batch_norm_backward_default_20[0]
        getitem_398 = native_batch_norm_backward_default_20[1]
        getitem_399 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_397, relu__default_60, primals_159, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_397 = primals_159 = None
        getitem_400 = convolution_backward_default_24[0]
        getitem_401 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(to_dtype_47, getitem_400);  to_dtype_47 = getitem_400 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_75, torch.float32);  add_tensor_75 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_105, to_dtype_60);  le_scalar_20 = new_zeros_default_105 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_75, primals_448, primals_446, primals_447, getitem_192, getitem_193, True, 1e-05, [True, True, True]);  convolution_default_75 = primals_448 = primals_446 = primals_447 = getitem_192 = getitem_193 = None
        getitem_403 = native_batch_norm_backward_default_21[0]
        getitem_404 = native_batch_norm_backward_default_21[1]
        getitem_405 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_403, sum_dim_int_list_23, primals_158, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_403 = sum_dim_int_list_23 = primals_158 = None
        getitem_406 = convolution_backward_default_25[0]
        getitem_407 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(getitem_406, 1);  getitem_406 = None
        expand_default_13 = torch.ops.aten.expand.default(unsqueeze_default_8, [128, 2, 512, 14, 14]);  unsqueeze_default_8 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(expand_default_13, stack_default_11);  stack_default_11 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(expand_default_13, _softmax_default_11);  expand_default_13 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(mul_tensor_24, [3, 4], True);  mul_tensor_24 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_37, _softmax_default_11, 1, torch.float32);  sum_dim_int_list_37 = _softmax_default_11 = None
        view_default_23 = torch.ops.aten.view.default(_softmax_backward_data_default_4, [128, 1024, 1, 1]);  _softmax_backward_data_default_4 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(view_default_23, relu__default_59, primals_155, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_23 = primals_155 = None
        getitem_409 = convolution_backward_default_26[0]
        getitem_410 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_409, torch.float32);  getitem_409 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_106, to_dtype_63);  le_scalar_21 = new_zeros_default_106 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_73, primals_153, primals_151, primals_152, getitem_189, getitem_190, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_73 = primals_153 = primals_151 = primals_152 = getitem_189 = getitem_190 = None
        getitem_412 = native_batch_norm_backward_default_22[0]
        getitem_413 = native_batch_norm_backward_default_22[1]
        getitem_414 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_412, mean_dim_11, primals_154, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_412 = mean_dim_11 = primals_154 = None
        getitem_415 = convolution_backward_default_27[0]
        getitem_416 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        expand_default_14 = torch.ops.aten.expand.default(getitem_415, [128, 512, 14, 14]);  getitem_415 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_14, 196);  expand_default_14 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(div_scalar_5, 1);  div_scalar_5 = None
        expand_default_15 = torch.ops.aten.expand.default(unsqueeze_default_9, [128, 2, 512, 14, 14]);  unsqueeze_default_9 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(mul_tensor_25, expand_default_15);  mul_tensor_25 = expand_default_15 = None
        unbind_int_4 = torch.ops.aten.unbind.int(add_tensor_76, 1);  add_tensor_76 = None
        getitem_418 = unbind_int_4[0]
        getitem_419 = unbind_int_4[1];  unbind_int_4 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_419, torch.float32);  getitem_419 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_107, to_dtype_66);  le_scalar_22 = new_zeros_default_107 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_72, primals_443, primals_441, primals_442, getitem_186, getitem_187, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_72 = primals_443 = primals_441 = primals_442 = getitem_186 = getitem_187 = None
        getitem_420 = native_batch_norm_backward_default_23[0]
        getitem_421 = native_batch_norm_backward_default_23[1]
        getitem_422 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_420, relu__default_56, primals_157, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_420 = primals_157 = None
        getitem_423 = convolution_backward_default_28[0]
        getitem_424 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_418, torch.float32);  getitem_418 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_108, to_dtype_69);  le_scalar_23 = new_zeros_default_108 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_71, primals_438, primals_436, primals_437, getitem_183, getitem_184, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_71 = primals_438 = primals_436 = primals_437 = getitem_183 = getitem_184 = None
        getitem_426 = native_batch_norm_backward_default_24[0]
        getitem_427 = native_batch_norm_backward_default_24[1]
        getitem_428 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_426, relu__default_56, primals_156, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_426 = primals_156 = None
        getitem_429 = convolution_backward_default_29[0]
        getitem_430 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(getitem_423, getitem_429);  getitem_423 = getitem_429 = None
        to_dtype_72 = torch.ops.aten.to.dtype(add_tensor_77, torch.float32);  add_tensor_77 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_109, to_dtype_72);  le_scalar_24 = new_zeros_default_109 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_70, primals_433, primals_431, primals_432, getitem_180, getitem_181, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_70 = primals_433 = primals_431 = primals_432 = getitem_180 = getitem_181 = None
        getitem_432 = native_batch_norm_backward_default_25[0]
        getitem_433 = native_batch_norm_backward_default_25[1]
        getitem_434 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_432, relu__default_55, primals_148, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_432 = primals_148 = None
        getitem_435 = convolution_backward_default_30[0]
        getitem_436 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_435);  to_dtype_62 = getitem_435 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_78, torch.float32);  add_tensor_78 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_110, to_dtype_75);  le_scalar_25 = new_zeros_default_110 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_69, primals_428, primals_426, primals_427, getitem_177, getitem_178, True, 1e-05, [True, True, True]);  convolution_default_69 = primals_428 = primals_426 = primals_427 = getitem_177 = getitem_178 = None
        getitem_438 = native_batch_norm_backward_default_26[0]
        getitem_439 = native_batch_norm_backward_default_26[1]
        getitem_440 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_438, sum_dim_int_list_21, primals_147, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_438 = sum_dim_int_list_21 = primals_147 = None
        getitem_441 = convolution_backward_default_31[0]
        getitem_442 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(getitem_441, 1);  getitem_441 = None
        expand_default_16 = torch.ops.aten.expand.default(unsqueeze_default_10, [128, 2, 512, 14, 14]);  unsqueeze_default_10 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(expand_default_16, stack_default_10);  stack_default_10 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(expand_default_16, _softmax_default_10);  expand_default_16 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(mul_tensor_26, [3, 4], True);  mul_tensor_26 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_38, _softmax_default_10, 1, torch.float32);  sum_dim_int_list_38 = _softmax_default_10 = None
        view_default_24 = torch.ops.aten.view.default(_softmax_backward_data_default_5, [128, 1024, 1, 1]);  _softmax_backward_data_default_5 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(view_default_24, relu__default_54, primals_144, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_24 = primals_144 = None
        getitem_444 = convolution_backward_default_32[0]
        getitem_445 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_444, torch.float32);  getitem_444 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_111, to_dtype_78);  le_scalar_26 = new_zeros_default_111 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_67, primals_142, primals_140, primals_141, getitem_174, getitem_175, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_67 = primals_142 = primals_140 = primals_141 = getitem_174 = getitem_175 = None
        getitem_447 = native_batch_norm_backward_default_27[0]
        getitem_448 = native_batch_norm_backward_default_27[1]
        getitem_449 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_447, mean_dim_10, primals_143, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_447 = mean_dim_10 = primals_143 = None
        getitem_450 = convolution_backward_default_33[0]
        getitem_451 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        expand_default_17 = torch.ops.aten.expand.default(getitem_450, [128, 512, 14, 14]);  getitem_450 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_17, 196);  expand_default_17 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(div_scalar_6, 1);  div_scalar_6 = None
        expand_default_18 = torch.ops.aten.expand.default(unsqueeze_default_11, [128, 2, 512, 14, 14]);  unsqueeze_default_11 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(mul_tensor_27, expand_default_18);  mul_tensor_27 = expand_default_18 = None
        unbind_int_5 = torch.ops.aten.unbind.int(add_tensor_79, 1);  add_tensor_79 = None
        getitem_453 = unbind_int_5[0]
        getitem_454 = unbind_int_5[1];  unbind_int_5 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_454, torch.float32);  getitem_454 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_112, to_dtype_81);  le_scalar_27 = new_zeros_default_112 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_66, primals_423, primals_421, primals_422, getitem_171, getitem_172, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_66 = primals_423 = primals_421 = primals_422 = getitem_171 = getitem_172 = None
        getitem_455 = native_batch_norm_backward_default_28[0]
        getitem_456 = native_batch_norm_backward_default_28[1]
        getitem_457 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_455, relu__default_51, primals_146, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_455 = primals_146 = None
        getitem_458 = convolution_backward_default_34[0]
        getitem_459 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_453, torch.float32);  getitem_453 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_113, to_dtype_84);  le_scalar_28 = new_zeros_default_113 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_65, primals_418, primals_416, primals_417, getitem_168, getitem_169, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_65 = primals_418 = primals_416 = primals_417 = getitem_168 = getitem_169 = None
        getitem_461 = native_batch_norm_backward_default_29[0]
        getitem_462 = native_batch_norm_backward_default_29[1]
        getitem_463 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_461, relu__default_51, primals_145, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_461 = primals_145 = None
        getitem_464 = convolution_backward_default_35[0]
        getitem_465 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_458, getitem_464);  getitem_458 = getitem_464 = None
        to_dtype_87 = torch.ops.aten.to.dtype(add_tensor_80, torch.float32);  add_tensor_80 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_114, to_dtype_87);  le_scalar_29 = new_zeros_default_114 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_64, primals_413, primals_411, primals_412, getitem_165, getitem_166, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_64 = primals_413 = primals_411 = primals_412 = getitem_165 = getitem_166 = None
        getitem_467 = native_batch_norm_backward_default_30[0]
        getitem_468 = native_batch_norm_backward_default_30[1]
        getitem_469 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_467, relu__default_50, primals_137, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_467 = primals_137 = None
        getitem_470 = convolution_backward_default_36[0]
        getitem_471 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(to_dtype_77, getitem_470);  to_dtype_77 = getitem_470 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_81, torch.float32);  add_tensor_81 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_115, to_dtype_90);  le_scalar_30 = new_zeros_default_115 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_63, primals_408, primals_406, primals_407, getitem_162, getitem_163, True, 1e-05, [True, True, True]);  convolution_default_63 = primals_408 = primals_406 = primals_407 = getitem_162 = getitem_163 = None
        getitem_473 = native_batch_norm_backward_default_31[0]
        getitem_474 = native_batch_norm_backward_default_31[1]
        getitem_475 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_473, sum_dim_int_list_19, primals_136, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_473 = sum_dim_int_list_19 = primals_136 = None
        getitem_476 = convolution_backward_default_37[0]
        getitem_477 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(getitem_476, 1);  getitem_476 = None
        expand_default_19 = torch.ops.aten.expand.default(unsqueeze_default_12, [128, 2, 512, 14, 14]);  unsqueeze_default_12 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(expand_default_19, stack_default_9);  stack_default_9 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(expand_default_19, _softmax_default_9);  expand_default_19 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(mul_tensor_28, [3, 4], True);  mul_tensor_28 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_39, _softmax_default_9, 1, torch.float32);  sum_dim_int_list_39 = _softmax_default_9 = None
        view_default_25 = torch.ops.aten.view.default(_softmax_backward_data_default_6, [128, 1024, 1, 1]);  _softmax_backward_data_default_6 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(view_default_25, relu__default_49, primals_133, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_25 = primals_133 = None
        getitem_479 = convolution_backward_default_38[0]
        getitem_480 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_479, torch.float32);  getitem_479 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_116, to_dtype_93);  le_scalar_31 = new_zeros_default_116 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_61, primals_131, primals_129, primals_130, getitem_159, getitem_160, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_61 = primals_131 = primals_129 = primals_130 = getitem_159 = getitem_160 = None
        getitem_482 = native_batch_norm_backward_default_32[0]
        getitem_483 = native_batch_norm_backward_default_32[1]
        getitem_484 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_482, mean_dim_9, primals_132, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_482 = mean_dim_9 = primals_132 = None
        getitem_485 = convolution_backward_default_39[0]
        getitem_486 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        expand_default_20 = torch.ops.aten.expand.default(getitem_485, [128, 512, 14, 14]);  getitem_485 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_20, 196);  expand_default_20 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(div_scalar_7, 1);  div_scalar_7 = None
        expand_default_21 = torch.ops.aten.expand.default(unsqueeze_default_13, [128, 2, 512, 14, 14]);  unsqueeze_default_13 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(mul_tensor_29, expand_default_21);  mul_tensor_29 = expand_default_21 = None
        unbind_int_6 = torch.ops.aten.unbind.int(add_tensor_82, 1);  add_tensor_82 = None
        getitem_488 = unbind_int_6[0]
        getitem_489 = unbind_int_6[1];  unbind_int_6 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_489, torch.float32);  getitem_489 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_117, to_dtype_96);  le_scalar_32 = new_zeros_default_117 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_60, primals_403, primals_401, primals_402, getitem_156, getitem_157, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_60 = primals_403 = primals_401 = primals_402 = getitem_156 = getitem_157 = None
        getitem_490 = native_batch_norm_backward_default_33[0]
        getitem_491 = native_batch_norm_backward_default_33[1]
        getitem_492 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_490, relu__default_46, primals_135, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_490 = primals_135 = None
        getitem_493 = convolution_backward_default_40[0]
        getitem_494 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_488, torch.float32);  getitem_488 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_118, to_dtype_99);  le_scalar_33 = new_zeros_default_118 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_59, primals_398, primals_396, primals_397, getitem_153, getitem_154, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_59 = primals_398 = primals_396 = primals_397 = getitem_153 = getitem_154 = None
        getitem_496 = native_batch_norm_backward_default_34[0]
        getitem_497 = native_batch_norm_backward_default_34[1]
        getitem_498 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_496, relu__default_46, primals_134, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_496 = primals_134 = None
        getitem_499 = convolution_backward_default_41[0]
        getitem_500 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(getitem_493, getitem_499);  getitem_493 = getitem_499 = None
        to_dtype_102 = torch.ops.aten.to.dtype(add_tensor_83, torch.float32);  add_tensor_83 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_119, to_dtype_102);  le_scalar_34 = new_zeros_default_119 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_58, primals_393, primals_391, primals_392, getitem_150, getitem_151, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_58 = primals_393 = primals_391 = primals_392 = getitem_150 = getitem_151 = None
        getitem_502 = native_batch_norm_backward_default_35[0]
        getitem_503 = native_batch_norm_backward_default_35[1]
        getitem_504 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_502, relu__default_45, primals_126, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_502 = primals_126 = None
        getitem_505 = convolution_backward_default_42[0]
        getitem_506 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(to_dtype_92, getitem_505);  to_dtype_92 = getitem_505 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_84, torch.float32);  add_tensor_84 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_120, to_dtype_105);  le_scalar_35 = new_zeros_default_120 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_57, primals_388, primals_386, primals_387, getitem_147, getitem_148, True, 1e-05, [True, True, True]);  convolution_default_57 = primals_388 = primals_386 = primals_387 = getitem_147 = getitem_148 = None
        getitem_508 = native_batch_norm_backward_default_36[0]
        getitem_509 = native_batch_norm_backward_default_36[1]
        getitem_510 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_508, sum_dim_int_list_17, primals_125, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_508 = sum_dim_int_list_17 = primals_125 = None
        getitem_511 = convolution_backward_default_43[0]
        getitem_512 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(getitem_511, 1);  getitem_511 = None
        expand_default_22 = torch.ops.aten.expand.default(unsqueeze_default_14, [128, 2, 512, 14, 14]);  unsqueeze_default_14 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(expand_default_22, stack_default_8);  stack_default_8 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(expand_default_22, _softmax_default_8);  expand_default_22 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(mul_tensor_30, [3, 4], True);  mul_tensor_30 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_40, _softmax_default_8, 1, torch.float32);  sum_dim_int_list_40 = _softmax_default_8 = None
        view_default_26 = torch.ops.aten.view.default(_softmax_backward_data_default_7, [128, 1024, 1, 1]);  _softmax_backward_data_default_7 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(view_default_26, relu__default_44, primals_122, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_26 = primals_122 = None
        getitem_514 = convolution_backward_default_44[0]
        getitem_515 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_514, torch.float32);  getitem_514 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_121, to_dtype_108);  le_scalar_36 = new_zeros_default_121 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_55, primals_120, primals_118, primals_119, getitem_144, getitem_145, True, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_55 = primals_120 = primals_118 = primals_119 = getitem_144 = getitem_145 = None
        getitem_517 = native_batch_norm_backward_default_37[0]
        getitem_518 = native_batch_norm_backward_default_37[1]
        getitem_519 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_517, mean_dim_8, primals_121, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_517 = mean_dim_8 = primals_121 = None
        getitem_520 = convolution_backward_default_45[0]
        getitem_521 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        expand_default_23 = torch.ops.aten.expand.default(getitem_520, [128, 512, 14, 14]);  getitem_520 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_23, 196);  expand_default_23 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(div_scalar_8, 1);  div_scalar_8 = None
        expand_default_24 = torch.ops.aten.expand.default(unsqueeze_default_15, [128, 2, 512, 14, 14]);  unsqueeze_default_15 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(mul_tensor_31, expand_default_24);  mul_tensor_31 = expand_default_24 = None
        unbind_int_7 = torch.ops.aten.unbind.int(add_tensor_85, 1);  add_tensor_85 = None
        getitem_523 = unbind_int_7[0]
        getitem_524 = unbind_int_7[1];  unbind_int_7 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_524, torch.float32);  getitem_524 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_122, to_dtype_111);  le_scalar_37 = new_zeros_default_122 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_54, primals_383, primals_381, primals_382, getitem_141, getitem_142, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_54 = primals_383 = primals_381 = primals_382 = getitem_141 = getitem_142 = None
        getitem_525 = native_batch_norm_backward_default_38[0]
        getitem_526 = native_batch_norm_backward_default_38[1]
        getitem_527 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_525, relu__default_41, primals_124, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_525 = primals_124 = None
        getitem_528 = convolution_backward_default_46[0]
        getitem_529 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_523, torch.float32);  getitem_523 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_123, to_dtype_114);  le_scalar_38 = new_zeros_default_123 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_53, primals_378, primals_376, primals_377, getitem_138, getitem_139, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_53 = primals_378 = primals_376 = primals_377 = getitem_138 = getitem_139 = None
        getitem_531 = native_batch_norm_backward_default_39[0]
        getitem_532 = native_batch_norm_backward_default_39[1]
        getitem_533 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_531, relu__default_41, primals_123, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_531 = primals_123 = None
        getitem_534 = convolution_backward_default_47[0]
        getitem_535 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(getitem_528, getitem_534);  getitem_528 = getitem_534 = None
        to_dtype_117 = torch.ops.aten.to.dtype(add_tensor_86, torch.float32);  add_tensor_86 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_124, to_dtype_117);  le_scalar_39 = new_zeros_default_124 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_52, primals_373, primals_371, primals_372, getitem_135, getitem_136, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_52 = primals_373 = primals_371 = primals_372 = getitem_135 = getitem_136 = None
        getitem_537 = native_batch_norm_backward_default_40[0]
        getitem_538 = native_batch_norm_backward_default_40[1]
        getitem_539 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_537, relu__default_40, primals_115, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_537 = primals_115 = None
        getitem_540 = convolution_backward_default_48[0]
        getitem_541 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(to_dtype_107, getitem_540);  to_dtype_107 = getitem_540 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_87, torch.float32);  add_tensor_87 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_125, to_dtype_120);  le_scalar_40 = new_zeros_default_125 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_51, primals_114, primals_112, primals_113, getitem_132, getitem_133, True, 1e-05, [True, True, True]);  convolution_default_51 = primals_114 = primals_112 = primals_113 = getitem_132 = getitem_133 = None
        getitem_543 = native_batch_norm_backward_default_41[0]
        getitem_544 = native_batch_norm_backward_default_41[1]
        getitem_545 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_543, relu__default_35, primals_109, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_543 = primals_109 = None
        getitem_546 = convolution_backward_default_49[0]
        getitem_547 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_50, primals_368, primals_366, primals_367, getitem_129, getitem_130, True, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_50 = primals_368 = primals_366 = primals_367 = getitem_129 = getitem_130 = None
        getitem_549 = native_batch_norm_backward_default_42[0]
        getitem_550 = native_batch_norm_backward_default_42[1]
        getitem_551 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_549, sum_dim_int_list_15, primals_108, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_549 = sum_dim_int_list_15 = primals_108 = None
        getitem_552 = convolution_backward_default_50[0]
        getitem_553 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(getitem_552, 1);  getitem_552 = None
        expand_default_25 = torch.ops.aten.expand.default(unsqueeze_default_16, [128, 2, 512, 14, 14]);  unsqueeze_default_16 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(expand_default_25, stack_default_7);  stack_default_7 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(expand_default_25, _softmax_default_7);  expand_default_25 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(mul_tensor_32, [3, 4], True);  mul_tensor_32 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_41, _softmax_default_7, 1, torch.float32);  sum_dim_int_list_41 = _softmax_default_7 = None
        view_default_27 = torch.ops.aten.view.default(_softmax_backward_data_default_8, [128, 1024, 1, 1]);  _softmax_backward_data_default_8 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(view_default_27, relu__default_39, primals_105, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_27 = primals_105 = None
        getitem_555 = convolution_backward_default_51[0]
        getitem_556 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_555, torch.float32);  getitem_555 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_126, to_dtype_123);  le_scalar_41 = new_zeros_default_126 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_48, primals_103, primals_101, primals_102, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_48 = primals_103 = primals_101 = primals_102 = getitem_126 = getitem_127 = None
        getitem_558 = native_batch_norm_backward_default_43[0]
        getitem_559 = native_batch_norm_backward_default_43[1]
        getitem_560 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_558, mean_dim_7, primals_104, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_558 = mean_dim_7 = primals_104 = None
        getitem_561 = convolution_backward_default_52[0]
        getitem_562 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        expand_default_26 = torch.ops.aten.expand.default(getitem_561, [128, 512, 14, 14]);  getitem_561 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_26, 196);  expand_default_26 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(div_scalar_9, 1);  div_scalar_9 = None
        expand_default_27 = torch.ops.aten.expand.default(unsqueeze_default_17, [128, 2, 512, 14, 14]);  unsqueeze_default_17 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(mul_tensor_33, expand_default_27);  mul_tensor_33 = expand_default_27 = None
        unbind_int_8 = torch.ops.aten.unbind.int(add_tensor_88, 1);  add_tensor_88 = None
        getitem_564 = unbind_int_8[0]
        getitem_565 = unbind_int_8[1];  unbind_int_8 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_565, torch.float32);  getitem_565 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_127, to_dtype_126);  le_scalar_42 = new_zeros_default_127 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_47, primals_363, primals_361, primals_362, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default_47 = primals_363 = primals_361 = primals_362 = getitem_123 = getitem_124 = None
        getitem_566 = native_batch_norm_backward_default_44[0]
        getitem_567 = native_batch_norm_backward_default_44[1]
        getitem_568 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_566, relu__default_36, primals_107, [0], [2, 2], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_566 = primals_107 = None
        getitem_569 = convolution_backward_default_53[0]
        getitem_570 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_564, torch.float32);  getitem_564 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_128, to_dtype_129);  le_scalar_43 = new_zeros_default_128 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_46, primals_358, primals_356, primals_357, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_46 = primals_358 = primals_356 = primals_357 = getitem_120 = getitem_121 = None
        getitem_572 = native_batch_norm_backward_default_45[0]
        getitem_573 = native_batch_norm_backward_default_45[1]
        getitem_574 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_572, relu__default_36, primals_106, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_572 = primals_106 = None
        getitem_575 = convolution_backward_default_54[0]
        getitem_576 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(getitem_569, getitem_575);  getitem_569 = getitem_575 = None
        to_dtype_132 = torch.ops.aten.to.dtype(add_tensor_89, torch.float32);  add_tensor_89 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_129, to_dtype_132);  le_scalar_44 = new_zeros_default_129 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_45, primals_353, primals_351, primals_352, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_45 = primals_353 = primals_351 = primals_352 = getitem_117 = getitem_118 = None
        getitem_578 = native_batch_norm_backward_default_46[0]
        getitem_579 = native_batch_norm_backward_default_46[1]
        getitem_580 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_578, relu__default_35, primals_98, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_578 = primals_98 = None
        getitem_581 = convolution_backward_default_55[0]
        getitem_582 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(getitem_546, getitem_581);  getitem_546 = getitem_581 = None
        to_dtype_135 = torch.ops.aten.to.dtype(add_tensor_90, torch.float32);  add_tensor_90 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_130, to_dtype_135);  le_scalar_45 = new_zeros_default_130 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_44, primals_348, primals_346, primals_347, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  convolution_default_44 = primals_348 = primals_346 = primals_347 = getitem_114 = getitem_115 = None
        getitem_584 = native_batch_norm_backward_default_47[0]
        getitem_585 = native_batch_norm_backward_default_47[1]
        getitem_586 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_584, sum_dim_int_list_13, primals_97, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_584 = sum_dim_int_list_13 = primals_97 = None
        getitem_587 = convolution_backward_default_56[0]
        getitem_588 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(getitem_587, 1);  getitem_587 = None
        expand_default_28 = torch.ops.aten.expand.default(unsqueeze_default_18, [128, 2, 256, 28, 28]);  unsqueeze_default_18 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(expand_default_28, stack_default_6);  stack_default_6 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(expand_default_28, _softmax_default_6);  expand_default_28 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(mul_tensor_34, [3, 4], True);  mul_tensor_34 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_42, _softmax_default_6, 1, torch.float32);  sum_dim_int_list_42 = _softmax_default_6 = None
        view_default_28 = torch.ops.aten.view.default(_softmax_backward_data_default_9, [128, 512, 1, 1]);  _softmax_backward_data_default_9 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(view_default_28, relu__default_34, primals_94, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_28 = primals_94 = None
        getitem_590 = convolution_backward_default_57[0]
        getitem_591 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_590, torch.float32);  getitem_590 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_131, to_dtype_138);  le_scalar_46 = new_zeros_default_131 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_42, primals_92, primals_90, primals_91, getitem_111, getitem_112, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_42 = primals_92 = primals_90 = primals_91 = getitem_111 = getitem_112 = None
        getitem_593 = native_batch_norm_backward_default_48[0]
        getitem_594 = native_batch_norm_backward_default_48[1]
        getitem_595 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_593, mean_dim_6, primals_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_593 = mean_dim_6 = primals_93 = None
        getitem_596 = convolution_backward_default_58[0]
        getitem_597 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        expand_default_29 = torch.ops.aten.expand.default(getitem_596, [128, 256, 28, 28]);  getitem_596 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_29, 784);  expand_default_29 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(div_scalar_10, 1);  div_scalar_10 = None
        expand_default_30 = torch.ops.aten.expand.default(unsqueeze_default_19, [128, 2, 256, 28, 28]);  unsqueeze_default_19 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(mul_tensor_35, expand_default_30);  mul_tensor_35 = expand_default_30 = None
        unbind_int_9 = torch.ops.aten.unbind.int(add_tensor_91, 1);  add_tensor_91 = None
        getitem_599 = unbind_int_9[0]
        getitem_600 = unbind_int_9[1];  unbind_int_9 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_600, torch.float32);  getitem_600 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_132, to_dtype_141);  le_scalar_47 = new_zeros_default_132 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_41, primals_343, primals_341, primals_342, getitem_108, getitem_109, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_41 = primals_343 = primals_341 = primals_342 = getitem_108 = getitem_109 = None
        getitem_601 = native_batch_norm_backward_default_49[0]
        getitem_602 = native_batch_norm_backward_default_49[1]
        getitem_603 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_601, relu__default_31, primals_96, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_601 = primals_96 = None
        getitem_604 = convolution_backward_default_59[0]
        getitem_605 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_599, torch.float32);  getitem_599 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_133, to_dtype_144);  le_scalar_48 = new_zeros_default_133 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_40, primals_338, primals_336, primals_337, getitem_105, getitem_106, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_40 = primals_338 = primals_336 = primals_337 = getitem_105 = getitem_106 = None
        getitem_607 = native_batch_norm_backward_default_50[0]
        getitem_608 = native_batch_norm_backward_default_50[1]
        getitem_609 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_607, relu__default_31, primals_95, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_607 = primals_95 = None
        getitem_610 = convolution_backward_default_60[0]
        getitem_611 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_604, getitem_610);  getitem_604 = getitem_610 = None
        to_dtype_147 = torch.ops.aten.to.dtype(add_tensor_92, torch.float32);  add_tensor_92 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_134, to_dtype_147);  le_scalar_49 = new_zeros_default_134 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_39, primals_333, primals_331, primals_332, getitem_102, getitem_103, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_39 = primals_333 = primals_331 = primals_332 = getitem_102 = getitem_103 = None
        getitem_613 = native_batch_norm_backward_default_51[0]
        getitem_614 = native_batch_norm_backward_default_51[1]
        getitem_615 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_613, relu__default_30, primals_87, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_613 = primals_87 = None
        getitem_616 = convolution_backward_default_61[0]
        getitem_617 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(to_dtype_137, getitem_616);  to_dtype_137 = getitem_616 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_93, torch.float32);  add_tensor_93 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_135, to_dtype_150);  le_scalar_50 = new_zeros_default_135 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_38, primals_328, primals_326, primals_327, getitem_99, getitem_100, True, 1e-05, [True, True, True]);  convolution_default_38 = primals_328 = primals_326 = primals_327 = getitem_99 = getitem_100 = None
        getitem_619 = native_batch_norm_backward_default_52[0]
        getitem_620 = native_batch_norm_backward_default_52[1]
        getitem_621 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_619, sum_dim_int_list_11, primals_86, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_619 = sum_dim_int_list_11 = primals_86 = None
        getitem_622 = convolution_backward_default_62[0]
        getitem_623 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(getitem_622, 1);  getitem_622 = None
        expand_default_31 = torch.ops.aten.expand.default(unsqueeze_default_20, [128, 2, 256, 28, 28]);  unsqueeze_default_20 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(expand_default_31, stack_default_5);  stack_default_5 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(expand_default_31, _softmax_default_5);  expand_default_31 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(mul_tensor_36, [3, 4], True);  mul_tensor_36 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_43, _softmax_default_5, 1, torch.float32);  sum_dim_int_list_43 = _softmax_default_5 = None
        view_default_29 = torch.ops.aten.view.default(_softmax_backward_data_default_10, [128, 512, 1, 1]);  _softmax_backward_data_default_10 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(view_default_29, relu__default_29, primals_83, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_29 = primals_83 = None
        getitem_625 = convolution_backward_default_63[0]
        getitem_626 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_625, torch.float32);  getitem_625 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_136, to_dtype_153);  le_scalar_51 = new_zeros_default_136 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_36, primals_81, primals_79, primals_80, getitem_96, getitem_97, True, 1e-05, [True, True, True]);  to_dtype_155 = convolution_default_36 = primals_81 = primals_79 = primals_80 = getitem_96 = getitem_97 = None
        getitem_628 = native_batch_norm_backward_default_53[0]
        getitem_629 = native_batch_norm_backward_default_53[1]
        getitem_630 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_628, mean_dim_5, primals_82, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_628 = mean_dim_5 = primals_82 = None
        getitem_631 = convolution_backward_default_64[0]
        getitem_632 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        expand_default_32 = torch.ops.aten.expand.default(getitem_631, [128, 256, 28, 28]);  getitem_631 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_32, 784);  expand_default_32 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(div_scalar_11, 1);  div_scalar_11 = None
        expand_default_33 = torch.ops.aten.expand.default(unsqueeze_default_21, [128, 2, 256, 28, 28]);  unsqueeze_default_21 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(mul_tensor_37, expand_default_33);  mul_tensor_37 = expand_default_33 = None
        unbind_int_10 = torch.ops.aten.unbind.int(add_tensor_94, 1);  add_tensor_94 = None
        getitem_634 = unbind_int_10[0]
        getitem_635 = unbind_int_10[1];  unbind_int_10 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_635, torch.float32);  getitem_635 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_137, to_dtype_156);  le_scalar_52 = new_zeros_default_137 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_35, primals_323, primals_321, primals_322, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  to_dtype_158 = convolution_default_35 = primals_323 = primals_321 = primals_322 = getitem_93 = getitem_94 = None
        getitem_636 = native_batch_norm_backward_default_54[0]
        getitem_637 = native_batch_norm_backward_default_54[1]
        getitem_638 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_636, relu__default_26, primals_85, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_636 = primals_85 = None
        getitem_639 = convolution_backward_default_65[0]
        getitem_640 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_634, torch.float32);  getitem_634 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_138, to_dtype_159);  le_scalar_53 = new_zeros_default_138 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_34, primals_318, primals_316, primals_317, getitem_90, getitem_91, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_34 = primals_318 = primals_316 = primals_317 = getitem_90 = getitem_91 = None
        getitem_642 = native_batch_norm_backward_default_55[0]
        getitem_643 = native_batch_norm_backward_default_55[1]
        getitem_644 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_642, relu__default_26, primals_84, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_642 = primals_84 = None
        getitem_645 = convolution_backward_default_66[0]
        getitem_646 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(getitem_639, getitem_645);  getitem_639 = getitem_645 = None
        to_dtype_162 = torch.ops.aten.to.dtype(add_tensor_95, torch.float32);  add_tensor_95 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_139, to_dtype_162);  le_scalar_54 = new_zeros_default_139 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_33, primals_313, primals_311, primals_312, getitem_87, getitem_88, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_33 = primals_313 = primals_311 = primals_312 = getitem_87 = getitem_88 = None
        getitem_648 = native_batch_norm_backward_default_56[0]
        getitem_649 = native_batch_norm_backward_default_56[1]
        getitem_650 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_648, relu__default_25, primals_76, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_648 = primals_76 = None
        getitem_651 = convolution_backward_default_67[0]
        getitem_652 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(to_dtype_152, getitem_651);  to_dtype_152 = getitem_651 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_96, torch.float32);  add_tensor_96 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_140, to_dtype_165);  le_scalar_55 = new_zeros_default_140 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_32, primals_308, primals_306, primals_307, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  convolution_default_32 = primals_308 = primals_306 = primals_307 = getitem_84 = getitem_85 = None
        getitem_654 = native_batch_norm_backward_default_57[0]
        getitem_655 = native_batch_norm_backward_default_57[1]
        getitem_656 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_654, sum_dim_int_list_9, primals_75, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_654 = sum_dim_int_list_9 = primals_75 = None
        getitem_657 = convolution_backward_default_68[0]
        getitem_658 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(getitem_657, 1);  getitem_657 = None
        expand_default_34 = torch.ops.aten.expand.default(unsqueeze_default_22, [128, 2, 256, 28, 28]);  unsqueeze_default_22 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(expand_default_34, stack_default_4);  stack_default_4 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(expand_default_34, _softmax_default_4);  expand_default_34 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(mul_tensor_38, [3, 4], True);  mul_tensor_38 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_44, _softmax_default_4, 1, torch.float32);  sum_dim_int_list_44 = _softmax_default_4 = None
        view_default_30 = torch.ops.aten.view.default(_softmax_backward_data_default_11, [128, 512, 1, 1]);  _softmax_backward_data_default_11 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(view_default_30, relu__default_24, primals_72, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_30 = primals_72 = None
        getitem_660 = convolution_backward_default_69[0]
        getitem_661 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_660, torch.float32);  getitem_660 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_141, to_dtype_168);  le_scalar_56 = new_zeros_default_141 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_30, primals_70, primals_68, primals_69, getitem_81, getitem_82, True, 1e-05, [True, True, True]);  to_dtype_170 = convolution_default_30 = primals_70 = primals_68 = primals_69 = getitem_81 = getitem_82 = None
        getitem_663 = native_batch_norm_backward_default_58[0]
        getitem_664 = native_batch_norm_backward_default_58[1]
        getitem_665 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_663, mean_dim_4, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_663 = mean_dim_4 = primals_71 = None
        getitem_666 = convolution_backward_default_70[0]
        getitem_667 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        expand_default_35 = torch.ops.aten.expand.default(getitem_666, [128, 256, 28, 28]);  getitem_666 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_35, 784);  expand_default_35 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(div_scalar_12, 1);  div_scalar_12 = None
        expand_default_36 = torch.ops.aten.expand.default(unsqueeze_default_23, [128, 2, 256, 28, 28]);  unsqueeze_default_23 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mul_tensor_39, expand_default_36);  mul_tensor_39 = expand_default_36 = None
        unbind_int_11 = torch.ops.aten.unbind.int(add_tensor_97, 1);  add_tensor_97 = None
        getitem_669 = unbind_int_11[0]
        getitem_670 = unbind_int_11[1];  unbind_int_11 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_670, torch.float32);  getitem_670 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_142, to_dtype_171);  le_scalar_57 = new_zeros_default_142 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_29, primals_303, primals_301, primals_302, getitem_78, getitem_79, True, 1e-05, [True, True, True]);  to_dtype_173 = convolution_default_29 = primals_303 = primals_301 = primals_302 = getitem_78 = getitem_79 = None
        getitem_671 = native_batch_norm_backward_default_59[0]
        getitem_672 = native_batch_norm_backward_default_59[1]
        getitem_673 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_671, relu__default_21, primals_74, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_671 = primals_74 = None
        getitem_674 = convolution_backward_default_71[0]
        getitem_675 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_669, torch.float32);  getitem_669 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_143, to_dtype_174);  le_scalar_58 = new_zeros_default_143 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_28, primals_298, primals_296, primals_297, getitem_75, getitem_76, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_28 = primals_298 = primals_296 = primals_297 = getitem_75 = getitem_76 = None
        getitem_677 = native_batch_norm_backward_default_60[0]
        getitem_678 = native_batch_norm_backward_default_60[1]
        getitem_679 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_677, relu__default_21, primals_73, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_677 = primals_73 = None
        getitem_680 = convolution_backward_default_72[0]
        getitem_681 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_674, getitem_680);  getitem_674 = getitem_680 = None
        to_dtype_177 = torch.ops.aten.to.dtype(add_tensor_98, torch.float32);  add_tensor_98 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_144, to_dtype_177);  le_scalar_59 = new_zeros_default_144 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_27, primals_293, primals_291, primals_292, getitem_72, getitem_73, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_27 = primals_293 = primals_291 = primals_292 = getitem_72 = getitem_73 = None
        getitem_683 = native_batch_norm_backward_default_61[0]
        getitem_684 = native_batch_norm_backward_default_61[1]
        getitem_685 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_683, relu__default_20, primals_65, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_683 = primals_65 = None
        getitem_686 = convolution_backward_default_73[0]
        getitem_687 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(to_dtype_167, getitem_686);  to_dtype_167 = getitem_686 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_99, torch.float32);  add_tensor_99 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_145, to_dtype_180);  le_scalar_60 = new_zeros_default_145 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_26, primals_64, primals_62, primals_63, getitem_69, getitem_70, True, 1e-05, [True, True, True]);  convolution_default_26 = primals_64 = primals_62 = primals_63 = getitem_69 = getitem_70 = None
        getitem_689 = native_batch_norm_backward_default_62[0]
        getitem_690 = native_batch_norm_backward_default_62[1]
        getitem_691 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_689, relu__default_15, primals_59, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_689 = primals_59 = None
        getitem_692 = convolution_backward_default_74[0]
        getitem_693 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_25, primals_288, primals_286, primals_287, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_182 = convolution_default_25 = primals_288 = primals_286 = primals_287 = getitem_66 = getitem_67 = None
        getitem_695 = native_batch_norm_backward_default_63[0]
        getitem_696 = native_batch_norm_backward_default_63[1]
        getitem_697 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_695, sum_dim_int_list_7, primals_58, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_695 = sum_dim_int_list_7 = primals_58 = None
        getitem_698 = convolution_backward_default_75[0]
        getitem_699 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(getitem_698, 1);  getitem_698 = None
        expand_default_37 = torch.ops.aten.expand.default(unsqueeze_default_24, [128, 2, 256, 28, 28]);  unsqueeze_default_24 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(expand_default_37, stack_default_3);  stack_default_3 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(expand_default_37, _softmax_default_3);  expand_default_37 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(mul_tensor_40, [3, 4], True);  mul_tensor_40 = None
        _softmax_backward_data_default_12 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_45, _softmax_default_3, 1, torch.float32);  sum_dim_int_list_45 = _softmax_default_3 = None
        view_default_31 = torch.ops.aten.view.default(_softmax_backward_data_default_12, [128, 512, 1, 1]);  _softmax_backward_data_default_12 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(view_default_31, relu__default_19, primals_55, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_31 = primals_55 = None
        getitem_701 = convolution_backward_default_76[0]
        getitem_702 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_701, torch.float32);  getitem_701 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_146, to_dtype_183);  le_scalar_61 = new_zeros_default_146 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_23, primals_53, primals_51, primals_52, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  to_dtype_185 = convolution_default_23 = primals_53 = primals_51 = primals_52 = getitem_63 = getitem_64 = None
        getitem_704 = native_batch_norm_backward_default_64[0]
        getitem_705 = native_batch_norm_backward_default_64[1]
        getitem_706 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_704, mean_dim_3, primals_54, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_704 = mean_dim_3 = primals_54 = None
        getitem_707 = convolution_backward_default_77[0]
        getitem_708 = convolution_backward_default_77[1];  convolution_backward_default_77 = None
        expand_default_38 = torch.ops.aten.expand.default(getitem_707, [128, 256, 28, 28]);  getitem_707 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_38, 784);  expand_default_38 = None
        unsqueeze_default_25 = torch.ops.aten.unsqueeze.default(div_scalar_13, 1);  div_scalar_13 = None
        expand_default_39 = torch.ops.aten.expand.default(unsqueeze_default_25, [128, 2, 256, 28, 28]);  unsqueeze_default_25 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(mul_tensor_41, expand_default_39);  mul_tensor_41 = expand_default_39 = None
        unbind_int_12 = torch.ops.aten.unbind.int(add_tensor_100, 1);  add_tensor_100 = None
        getitem_710 = unbind_int_12[0]
        getitem_711 = unbind_int_12[1];  unbind_int_12 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_711, torch.float32);  getitem_711 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_147, to_dtype_186);  le_scalar_62 = new_zeros_default_147 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_22, primals_283, primals_281, primals_282, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_22 = primals_283 = primals_281 = primals_282 = getitem_60 = getitem_61 = None
        getitem_712 = native_batch_norm_backward_default_65[0]
        getitem_713 = native_batch_norm_backward_default_65[1]
        getitem_714 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_712, relu__default_16, primals_57, [0], [2, 2], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_712 = primals_57 = None
        getitem_715 = convolution_backward_default_78[0]
        getitem_716 = convolution_backward_default_78[1];  convolution_backward_default_78 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_710, torch.float32);  getitem_710 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_148, to_dtype_189);  le_scalar_63 = new_zeros_default_148 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_21, primals_278, primals_276, primals_277, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_21 = primals_278 = primals_276 = primals_277 = getitem_57 = getitem_58 = None
        getitem_718 = native_batch_norm_backward_default_66[0]
        getitem_719 = native_batch_norm_backward_default_66[1]
        getitem_720 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_718, relu__default_16, primals_56, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_718 = primals_56 = None
        getitem_721 = convolution_backward_default_79[0]
        getitem_722 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(getitem_715, getitem_721);  getitem_715 = getitem_721 = None
        to_dtype_192 = torch.ops.aten.to.dtype(add_tensor_101, torch.float32);  add_tensor_101 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_149, to_dtype_192);  le_scalar_64 = new_zeros_default_149 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_20, primals_273, primals_271, primals_272, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default_20 = primals_273 = primals_271 = primals_272 = getitem_54 = getitem_55 = None
        getitem_724 = native_batch_norm_backward_default_67[0]
        getitem_725 = native_batch_norm_backward_default_67[1]
        getitem_726 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_724, relu__default_15, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_724 = primals_48 = None
        getitem_727 = convolution_backward_default_80[0]
        getitem_728 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(getitem_692, getitem_727);  getitem_692 = getitem_727 = None
        to_dtype_195 = torch.ops.aten.to.dtype(add_tensor_102, torch.float32);  add_tensor_102 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_150, to_dtype_195);  le_scalar_65 = new_zeros_default_150 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_19, primals_268, primals_266, primals_267, getitem_51, getitem_52, True, 1e-05, [True, True, True]);  convolution_default_19 = primals_268 = primals_266 = primals_267 = getitem_51 = getitem_52 = None
        getitem_730 = native_batch_norm_backward_default_68[0]
        getitem_731 = native_batch_norm_backward_default_68[1]
        getitem_732 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_730, sum_dim_int_list_5, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_730 = sum_dim_int_list_5 = primals_47 = None
        getitem_733 = convolution_backward_default_81[0]
        getitem_734 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        unsqueeze_default_26 = torch.ops.aten.unsqueeze.default(getitem_733, 1);  getitem_733 = None
        expand_default_40 = torch.ops.aten.expand.default(unsqueeze_default_26, [128, 2, 128, 56, 56]);  unsqueeze_default_26 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(expand_default_40, stack_default_2);  stack_default_2 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(expand_default_40, _softmax_default_2);  expand_default_40 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(mul_tensor_42, [3, 4], True);  mul_tensor_42 = None
        _softmax_backward_data_default_13 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_46, _softmax_default_2, 1, torch.float32);  sum_dim_int_list_46 = _softmax_default_2 = None
        view_default_32 = torch.ops.aten.view.default(_softmax_backward_data_default_13, [128, 256, 1, 1]);  _softmax_backward_data_default_13 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(view_default_32, relu__default_14, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_32 = primals_44 = None
        getitem_736 = convolution_backward_default_82[0]
        getitem_737 = convolution_backward_default_82[1];  convolution_backward_default_82 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_736, torch.float32);  getitem_736 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_151, to_dtype_198);  le_scalar_66 = new_zeros_default_151 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_17, primals_42, primals_40, primals_41, getitem_48, getitem_49, True, 1e-05, [True, True, True]);  to_dtype_200 = convolution_default_17 = primals_42 = primals_40 = primals_41 = getitem_48 = getitem_49 = None
        getitem_739 = native_batch_norm_backward_default_69[0]
        getitem_740 = native_batch_norm_backward_default_69[1]
        getitem_741 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_739, mean_dim_2, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_739 = mean_dim_2 = primals_43 = None
        getitem_742 = convolution_backward_default_83[0]
        getitem_743 = convolution_backward_default_83[1];  convolution_backward_default_83 = None
        expand_default_41 = torch.ops.aten.expand.default(getitem_742, [128, 128, 56, 56]);  getitem_742 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_41, 3136);  expand_default_41 = None
        unsqueeze_default_27 = torch.ops.aten.unsqueeze.default(div_scalar_14, 1);  div_scalar_14 = None
        expand_default_42 = torch.ops.aten.expand.default(unsqueeze_default_27, [128, 2, 128, 56, 56]);  unsqueeze_default_27 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(mul_tensor_43, expand_default_42);  mul_tensor_43 = expand_default_42 = None
        unbind_int_13 = torch.ops.aten.unbind.int(add_tensor_103, 1);  add_tensor_103 = None
        getitem_745 = unbind_int_13[0]
        getitem_746 = unbind_int_13[1];  unbind_int_13 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_746, torch.float32);  getitem_746 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_152, to_dtype_201);  le_scalar_67 = new_zeros_default_152 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_16, primals_263, primals_261, primals_262, getitem_45, getitem_46, True, 1e-05, [True, True, True]);  to_dtype_203 = convolution_default_16 = primals_263 = primals_261 = primals_262 = getitem_45 = getitem_46 = None
        getitem_747 = native_batch_norm_backward_default_70[0]
        getitem_748 = native_batch_norm_backward_default_70[1]
        getitem_749 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_747, relu__default_11, primals_46, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_747 = primals_46 = None
        getitem_750 = convolution_backward_default_84[0]
        getitem_751 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_745, torch.float32);  getitem_745 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_153, to_dtype_204);  le_scalar_68 = new_zeros_default_153 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_15, primals_258, primals_256, primals_257, getitem_42, getitem_43, True, 1e-05, [True, True, True]);  to_dtype_206 = convolution_default_15 = primals_258 = primals_256 = primals_257 = getitem_42 = getitem_43 = None
        getitem_753 = native_batch_norm_backward_default_71[0]
        getitem_754 = native_batch_norm_backward_default_71[1]
        getitem_755 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_753, relu__default_11, primals_45, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_753 = primals_45 = None
        getitem_756 = convolution_backward_default_85[0]
        getitem_757 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(getitem_750, getitem_756);  getitem_750 = getitem_756 = None
        to_dtype_207 = torch.ops.aten.to.dtype(add_tensor_104, torch.float32);  add_tensor_104 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_154, to_dtype_207);  le_scalar_69 = new_zeros_default_154 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_14, primals_253, primals_251, primals_252, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_14 = primals_253 = primals_251 = primals_252 = getitem_39 = getitem_40 = None
        getitem_759 = native_batch_norm_backward_default_72[0]
        getitem_760 = native_batch_norm_backward_default_72[1]
        getitem_761 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_759, relu__default_10, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_759 = primals_37 = None
        getitem_762 = convolution_backward_default_86[0]
        getitem_763 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(to_dtype_197, getitem_762);  to_dtype_197 = getitem_762 = None
        to_dtype_210 = torch.ops.aten.to.dtype(add_tensor_105, torch.float32);  add_tensor_105 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_155, to_dtype_210);  le_scalar_70 = new_zeros_default_155 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_13, primals_248, primals_246, primals_247, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  convolution_default_13 = primals_248 = primals_246 = primals_247 = getitem_36 = getitem_37 = None
        getitem_765 = native_batch_norm_backward_default_73[0]
        getitem_766 = native_batch_norm_backward_default_73[1]
        getitem_767 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_765, sum_dim_int_list_3, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_765 = sum_dim_int_list_3 = primals_36 = None
        getitem_768 = convolution_backward_default_87[0]
        getitem_769 = convolution_backward_default_87[1];  convolution_backward_default_87 = None
        unsqueeze_default_28 = torch.ops.aten.unsqueeze.default(getitem_768, 1);  getitem_768 = None
        expand_default_43 = torch.ops.aten.expand.default(unsqueeze_default_28, [128, 2, 128, 56, 56]);  unsqueeze_default_28 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(expand_default_43, stack_default_1);  stack_default_1 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(expand_default_43, _softmax_default_1);  expand_default_43 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(mul_tensor_44, [3, 4], True);  mul_tensor_44 = None
        _softmax_backward_data_default_14 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_47, _softmax_default_1, 1, torch.float32);  sum_dim_int_list_47 = _softmax_default_1 = None
        view_default_33 = torch.ops.aten.view.default(_softmax_backward_data_default_14, [128, 256, 1, 1]);  _softmax_backward_data_default_14 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(view_default_33, relu__default_9, primals_33, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_33 = primals_33 = None
        getitem_771 = convolution_backward_default_88[0]
        getitem_772 = convolution_backward_default_88[1];  convolution_backward_default_88 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_771, torch.float32);  getitem_771 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_156, to_dtype_213);  le_scalar_71 = new_zeros_default_156 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_11, primals_31, primals_29, primals_30, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  to_dtype_215 = convolution_default_11 = primals_31 = primals_29 = primals_30 = getitem_33 = getitem_34 = None
        getitem_774 = native_batch_norm_backward_default_74[0]
        getitem_775 = native_batch_norm_backward_default_74[1]
        getitem_776 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_774, mean_dim_1, primals_32, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_774 = mean_dim_1 = primals_32 = None
        getitem_777 = convolution_backward_default_89[0]
        getitem_778 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        expand_default_44 = torch.ops.aten.expand.default(getitem_777, [128, 128, 56, 56]);  getitem_777 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_44, 3136);  expand_default_44 = None
        unsqueeze_default_29 = torch.ops.aten.unsqueeze.default(div_scalar_15, 1);  div_scalar_15 = None
        expand_default_45 = torch.ops.aten.expand.default(unsqueeze_default_29, [128, 2, 128, 56, 56]);  unsqueeze_default_29 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(mul_tensor_45, expand_default_45);  mul_tensor_45 = expand_default_45 = None
        unbind_int_14 = torch.ops.aten.unbind.int(add_tensor_106, 1);  add_tensor_106 = None
        getitem_780 = unbind_int_14[0]
        getitem_781 = unbind_int_14[1];  unbind_int_14 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_781, torch.float32);  getitem_781 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_157, to_dtype_216);  le_scalar_72 = new_zeros_default_157 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_10, primals_243, primals_241, primals_242, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  to_dtype_218 = convolution_default_10 = primals_243 = primals_241 = primals_242 = getitem_30 = getitem_31 = None
        getitem_782 = native_batch_norm_backward_default_75[0]
        getitem_783 = native_batch_norm_backward_default_75[1]
        getitem_784 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_782, relu__default_6, primals_35, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_782 = primals_35 = None
        getitem_785 = convolution_backward_default_90[0]
        getitem_786 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_780, torch.float32);  getitem_780 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_158, to_dtype_219);  le_scalar_73 = new_zeros_default_158 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_9, primals_238, primals_236, primals_237, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_221 = convolution_default_9 = primals_238 = primals_236 = primals_237 = getitem_27 = getitem_28 = None
        getitem_788 = native_batch_norm_backward_default_76[0]
        getitem_789 = native_batch_norm_backward_default_76[1]
        getitem_790 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_788, relu__default_6, primals_34, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_788 = primals_34 = None
        getitem_791 = convolution_backward_default_91[0]
        getitem_792 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(getitem_785, getitem_791);  getitem_785 = getitem_791 = None
        to_dtype_222 = torch.ops.aten.to.dtype(add_tensor_107, torch.float32);  add_tensor_107 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_159, to_dtype_222);  le_scalar_74 = new_zeros_default_159 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_8, primals_233, primals_231, primals_232, getitem_24, getitem_25, True, 1e-05, [True, True, True]);  to_dtype_224 = convolution_default_8 = primals_233 = primals_231 = primals_232 = getitem_24 = getitem_25 = None
        getitem_794 = native_batch_norm_backward_default_77[0]
        getitem_795 = native_batch_norm_backward_default_77[1]
        getitem_796 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_794, relu__default_5, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_794 = primals_26 = None
        getitem_797 = convolution_backward_default_92[0]
        getitem_798 = convolution_backward_default_92[1];  convolution_backward_default_92 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(to_dtype_212, getitem_797);  to_dtype_212 = getitem_797 = None
        to_dtype_225 = torch.ops.aten.to.dtype(add_tensor_108, torch.float32);  add_tensor_108 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_160, to_dtype_225);  le_scalar_75 = new_zeros_default_160 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_7, primals_25, primals_23, primals_24, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  convolution_default_7 = primals_25 = primals_23 = primals_24 = getitem_21 = getitem_22 = None
        getitem_800 = native_batch_norm_backward_default_78[0]
        getitem_801 = native_batch_norm_backward_default_78[1]
        getitem_802 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_800, getitem_3, primals_20, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_800 = primals_20 = None
        getitem_803 = convolution_backward_default_93[0]
        getitem_804 = convolution_backward_default_93[1];  convolution_backward_default_93 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_6, primals_228, primals_226, primals_227, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  to_dtype_227 = convolution_default_6 = primals_228 = primals_226 = primals_227 = getitem_18 = getitem_19 = None
        getitem_806 = native_batch_norm_backward_default_79[0]
        getitem_807 = native_batch_norm_backward_default_79[1]
        getitem_808 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_806, sum_dim_int_list_1, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_806 = sum_dim_int_list_1 = primals_19 = None
        getitem_809 = convolution_backward_default_94[0]
        getitem_810 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        unsqueeze_default_30 = torch.ops.aten.unsqueeze.default(getitem_809, 1);  getitem_809 = None
        expand_default_46 = torch.ops.aten.expand.default(unsqueeze_default_30, [128, 2, 128, 56, 56]);  unsqueeze_default_30 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(expand_default_46, stack_default);  stack_default = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(expand_default_46, _softmax_default);  expand_default_46 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(mul_tensor_46, [3, 4], True);  mul_tensor_46 = None
        _softmax_backward_data_default_15 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_48, _softmax_default, 1, torch.float32);  sum_dim_int_list_48 = _softmax_default = None
        view_default_34 = torch.ops.aten.view.default(_softmax_backward_data_default_15, [128, 256, 1, 1]);  _softmax_backward_data_default_15 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(view_default_34, relu__default_4, primals_16, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_34 = primals_16 = None
        getitem_812 = convolution_backward_default_95[0]
        getitem_813 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        to_dtype_228 = torch.ops.aten.to.dtype(getitem_812, torch.float32);  getitem_812 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_161, to_dtype_228);  le_scalar_76 = new_zeros_default_161 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_4, primals_14, primals_12, primals_13, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  to_dtype_230 = convolution_default_4 = primals_14 = primals_12 = primals_13 = getitem_15 = getitem_16 = None
        getitem_815 = native_batch_norm_backward_default_80[0]
        getitem_816 = native_batch_norm_backward_default_80[1]
        getitem_817 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_815, mean_dim, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_815 = mean_dim = primals_15 = None
        getitem_818 = convolution_backward_default_96[0]
        getitem_819 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        expand_default_47 = torch.ops.aten.expand.default(getitem_818, [128, 128, 56, 56]);  getitem_818 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_47, 3136);  expand_default_47 = None
        unsqueeze_default_31 = torch.ops.aten.unsqueeze.default(div_scalar_16, 1);  div_scalar_16 = None
        expand_default_48 = torch.ops.aten.expand.default(unsqueeze_default_31, [128, 2, 128, 56, 56]);  unsqueeze_default_31 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(mul_tensor_47, expand_default_48);  mul_tensor_47 = expand_default_48 = None
        unbind_int_15 = torch.ops.aten.unbind.int(add_tensor_109, 1);  add_tensor_109 = None
        getitem_821 = unbind_int_15[0]
        getitem_822 = unbind_int_15[1];  unbind_int_15 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_822, torch.float32);  getitem_822 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_162, to_dtype_231);  le_scalar_77 = new_zeros_default_162 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_3, primals_223, primals_221, primals_222, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  to_dtype_233 = convolution_default_3 = primals_223 = primals_221 = primals_222 = getitem_12 = getitem_13 = None
        getitem_823 = native_batch_norm_backward_default_81[0]
        getitem_824 = native_batch_norm_backward_default_81[1]
        getitem_825 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_823, relu__default_1, primals_18, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 32, [True, True, False]);  getitem_823 = primals_18 = None
        getitem_826 = convolution_backward_default_97[0]
        getitem_827 = convolution_backward_default_97[1];  convolution_backward_default_97 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_821, torch.float32);  getitem_821 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_163, to_dtype_234);  le_scalar_78 = new_zeros_default_163 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_2, primals_218, primals_216, primals_217, getitem_9, getitem_10, True, 1e-05, [True, True, True]);  to_dtype_236 = convolution_default_2 = primals_218 = primals_216 = primals_217 = getitem_9 = getitem_10 = None
        getitem_829 = native_batch_norm_backward_default_82[0]
        getitem_830 = native_batch_norm_backward_default_82[1]
        getitem_831 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_829, relu__default_1, primals_17, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_829 = primals_17 = None
        getitem_832 = convolution_backward_default_98[0]
        getitem_833 = convolution_backward_default_98[1];  convolution_backward_default_98 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(getitem_826, getitem_832);  getitem_826 = getitem_832 = None
        to_dtype_237 = torch.ops.aten.to.dtype(add_tensor_110, torch.float32);  add_tensor_110 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_164, to_dtype_237);  le_scalar_79 = new_zeros_default_164 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_1, primals_213, primals_211, primals_212, getitem_6, getitem_7, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_1 = primals_213 = primals_211 = primals_212 = getitem_6 = getitem_7 = None
        getitem_835 = native_batch_norm_backward_default_83[0]
        getitem_836 = native_batch_norm_backward_default_83[1]
        getitem_837 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_835, getitem_3, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_835 = getitem_3 = primals_9 = None
        getitem_838 = convolution_backward_default_99[0]
        getitem_839 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(getitem_803, getitem_838);  getitem_803 = getitem_838 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_111, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  add_tensor_111 = getitem_4 = None
        to_dtype_240 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_165, to_dtype_240);  le_scalar_80 = new_zeros_default_165 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default, primals_5, primals_3, primals_4, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_242 = convolution_default = primals_5 = primals_3 = primals_4 = getitem_1 = getitem_2 = None
        getitem_841 = native_batch_norm_backward_default_84[0]
        getitem_842 = native_batch_norm_backward_default_84[1]
        getitem_843 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_841, primals_209, primals_6, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_841 = primals_209 = primals_6 = None
        getitem_845 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        return [getitem_843, None, None, None, getitem_842, getitem_845, view_default_17, t_default_4, getitem_839, getitem_817, None, None, None, getitem_816, getitem_819, getitem_813, getitem_833, getitem_827, getitem_810, getitem_804, getitem_802, None, None, None, getitem_801, getitem_798, getitem_776, None, None, None, getitem_775, getitem_778, getitem_772, getitem_792, getitem_786, getitem_769, getitem_763, getitem_741, None, None, None, getitem_740, getitem_743, getitem_737, getitem_757, getitem_751, getitem_734, getitem_728, getitem_706, None, None, None, getitem_705, getitem_708, getitem_702, getitem_722, getitem_716, getitem_699, getitem_693, getitem_691, None, None, None, getitem_690, getitem_687, getitem_665, None, None, None, getitem_664, getitem_667, getitem_661, getitem_681, getitem_675, getitem_658, getitem_652, getitem_630, None, None, None, getitem_629, getitem_632, getitem_626, getitem_646, getitem_640, getitem_623, getitem_617, getitem_595, None, None, None, getitem_594, getitem_597, getitem_591, getitem_611, getitem_605, getitem_588, getitem_582, getitem_560, None, None, None, getitem_559, getitem_562, getitem_556, getitem_576, getitem_570, getitem_553, getitem_547, getitem_545, None, None, None, getitem_544, getitem_541, getitem_519, None, None, None, getitem_518, getitem_521, getitem_515, getitem_535, getitem_529, getitem_512, getitem_506, getitem_484, None, None, None, getitem_483, getitem_486, getitem_480, getitem_500, getitem_494, getitem_477, getitem_471, getitem_449, None, None, None, getitem_448, getitem_451, getitem_445, getitem_465, getitem_459, getitem_442, getitem_436, getitem_414, None, None, None, getitem_413, getitem_416, getitem_410, getitem_430, getitem_424, getitem_407, getitem_401, getitem_379, None, None, None, getitem_378, getitem_381, getitem_375, getitem_395, getitem_389, getitem_372, getitem_366, getitem_344, None, None, None, getitem_343, getitem_346, getitem_340, getitem_360, getitem_354, getitem_337, getitem_331, getitem_329, None, None, None, getitem_328, getitem_325, getitem_303, None, None, None, getitem_302, getitem_305, getitem_299, getitem_319, getitem_313, getitem_296, getitem_290, getitem_268, None, None, None, getitem_267, getitem_270, getitem_264, getitem_284, getitem_278, getitem_261, None, None, None, None, getitem_836, getitem_837, None, None, None, getitem_830, getitem_831, None, None, None, getitem_824, getitem_825, None, None, None, getitem_807, getitem_808, None, None, None, getitem_795, getitem_796, None, None, None, getitem_789, getitem_790, None, None, None, getitem_783, getitem_784, None, None, None, getitem_766, getitem_767, None, None, None, getitem_760, getitem_761, None, None, None, getitem_754, getitem_755, None, None, None, getitem_748, getitem_749, None, None, None, getitem_731, getitem_732, None, None, None, getitem_725, getitem_726, None, None, None, getitem_719, getitem_720, None, None, None, getitem_713, getitem_714, None, None, None, getitem_696, getitem_697, None, None, None, getitem_684, getitem_685, None, None, None, getitem_678, getitem_679, None, None, None, getitem_672, getitem_673, None, None, None, getitem_655, getitem_656, None, None, None, getitem_649, getitem_650, None, None, None, getitem_643, getitem_644, None, None, None, getitem_637, getitem_638, None, None, None, getitem_620, getitem_621, None, None, None, getitem_614, getitem_615, None, None, None, getitem_608, getitem_609, None, None, None, getitem_602, getitem_603, None, None, None, getitem_585, getitem_586, None, None, None, getitem_579, getitem_580, None, None, None, getitem_573, getitem_574, None, None, None, getitem_567, getitem_568, None, None, None, getitem_550, getitem_551, None, None, None, getitem_538, getitem_539, None, None, None, getitem_532, getitem_533, None, None, None, getitem_526, getitem_527, None, None, None, getitem_509, getitem_510, None, None, None, getitem_503, getitem_504, None, None, None, getitem_497, getitem_498, None, None, None, getitem_491, getitem_492, None, None, None, getitem_474, getitem_475, None, None, None, getitem_468, getitem_469, None, None, None, getitem_462, getitem_463, None, None, None, getitem_456, getitem_457, None, None, None, getitem_439, getitem_440, None, None, None, getitem_433, getitem_434, None, None, None, getitem_427, getitem_428, None, None, None, getitem_421, getitem_422, None, None, None, getitem_404, getitem_405, None, None, None, getitem_398, getitem_399, None, None, None, getitem_392, getitem_393, None, None, None, getitem_386, getitem_387, None, None, None, getitem_369, getitem_370, None, None, None, getitem_363, getitem_364, None, None, None, getitem_357, getitem_358, None, None, None, getitem_351, getitem_352, None, None, None, getitem_334, getitem_335, None, None, None, getitem_322, getitem_323, None, None, None, getitem_316, getitem_317, None, None, None, getitem_310, getitem_311, None, None, None, getitem_293, getitem_294, None, None, None, getitem_287, getitem_288, None, None, None, getitem_281, getitem_282, None, None, None, getitem_275, getitem_276, None, None, None, getitem_258, getitem_259]
        
