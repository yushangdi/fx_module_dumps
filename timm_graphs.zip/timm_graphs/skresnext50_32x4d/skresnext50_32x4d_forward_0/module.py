
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/skresnext50_32x4d/skresnext50_32x4d_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529):
        convolution_default = torch.ops.aten.convolution.default(primals_209, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_210, 1);  primals_210 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_213, primals_214, primals_211, primals_212, True, 0.1, 1e-05);  primals_214 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_17, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_215, 1);  primals_215 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_218, primals_219, primals_216, primals_217, True, 0.1, 1e-05);  primals_219 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_1, primals_18, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_220, 1);  primals_220 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_223, primals_224, primals_221, primals_222, True, 0.1, 1e-05);  primals_224 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        stack_default = torch.ops.aten.stack.default([relu__default_2, relu__default_3], 1)
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(stack_default, [1])
        mean_dim = torch.ops.aten.mean.dim(sum_dim_int_list, [2, 3], True);  sum_dim_int_list = None
        convolution_default_4 = torch.ops.aten.convolution.default(mean_dim, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_14, primals_10, primals_12, primals_13, True, 0.1, 1e-05);  primals_10 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_16, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default = torch.ops.aten.view.default(convolution_default_5, [128, 2, 128, 1, 1]);  convolution_default_5 = None
        _softmax_default = torch.ops.aten._softmax.default(view_default, 1, False);  view_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(stack_default, _softmax_default)
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor, [1]);  mul_tensor = None
        convolution_default_6 = torch.ops.aten.convolution.default(sum_dim_int_list_1, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_225, 1);  primals_225 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_228, primals_229, primals_226, primals_227, True, 0.1, 1e-05);  primals_229 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_3, primals_20, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_25, primals_21, primals_23, primals_24, True, 0.1, 1e-05);  primals_21 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        add__tensor_3 = torch.ops.aten.add_.Tensor(getitem_17, getitem_20);  getitem_17 = getitem_20 = None
        relu__default_5 = torch.ops.aten.relu_.default(add__tensor_3);  add__tensor_3 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_230, 1);  primals_230 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_233, primals_234, primals_231, primals_232, True, 0.1, 1e-05);  primals_234 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_34, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_235, 1);  primals_235 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_238, primals_239, primals_236, primals_237, True, 0.1, 1e-05);  primals_239 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_6, primals_35, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_240, 1);  primals_240 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_243, primals_244, primals_241, primals_242, True, 0.1, 1e-05);  primals_244 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        stack_default_1 = torch.ops.aten.stack.default([relu__default_7, relu__default_8], 1)
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(stack_default_1, [1])
        mean_dim_1 = torch.ops.aten.mean.dim(sum_dim_int_list_2, [2, 3], True);  sum_dim_int_list_2 = None
        convolution_default_11 = torch.ops.aten.convolution.default(mean_dim_1, primals_32, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_31, primals_27, primals_29, primals_30, True, 0.1, 1e-05);  primals_27 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_9, primals_33, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_1 = torch.ops.aten.view.default(convolution_default_12, [128, 2, 128, 1, 1]);  convolution_default_12 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(view_default_1, 1, False);  view_default_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(stack_default_1, _softmax_default_1)
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_1, [1]);  mul_tensor_1 = None
        convolution_default_13 = torch.ops.aten.convolution.default(sum_dim_int_list_3, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_245, 1);  primals_245 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_248, primals_249, primals_246, primals_247, True, 0.1, 1e-05);  primals_249 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_35, relu__default_5);  getitem_35 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_5);  add__tensor_5 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_10, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_250, 1);  primals_250 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_253, primals_254, primals_251, primals_252, True, 0.1, 1e-05);  primals_254 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_11, primals_45, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_255, 1);  primals_255 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_258, primals_259, primals_256, primals_257, True, 0.1, 1e-05);  primals_259 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_11, primals_46, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_260, 1);  primals_260 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_263, primals_264, primals_261, primals_262, True, 0.1, 1e-05);  primals_264 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        stack_default_2 = torch.ops.aten.stack.default([relu__default_12, relu__default_13], 1)
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(stack_default_2, [1])
        mean_dim_2 = torch.ops.aten.mean.dim(sum_dim_int_list_4, [2, 3], True);  sum_dim_int_list_4 = None
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_2, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_42, primals_38, primals_40, primals_41, True, 0.1, 1e-05);  primals_38 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_14, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_2 = torch.ops.aten.view.default(convolution_default_18, [128, 2, 128, 1, 1]);  convolution_default_18 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(view_default_2, 1, False);  view_default_2 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(stack_default_2, _softmax_default_2)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_2, [1]);  mul_tensor_2 = None
        convolution_default_19 = torch.ops.aten.convolution.default(sum_dim_int_list_5, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_265, 1);  primals_265 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_268, primals_269, primals_266, primals_267, True, 0.1, 1e-05);  primals_269 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_50, relu__default_10);  getitem_50 = None
        relu__default_15 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_15, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_270, 1);  primals_270 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_273, primals_274, primals_271, primals_272, True, 0.1, 1e-05);  primals_274 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_16, primals_56, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_275, 1);  primals_275 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_278, primals_279, primals_276, primals_277, True, 0.1, 1e-05);  primals_279 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_16, primals_57, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_280, 1);  primals_280 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_283, primals_284, primals_281, primals_282, True, 0.1, 1e-05);  primals_284 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        stack_default_3 = torch.ops.aten.stack.default([relu__default_17, relu__default_18], 1)
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(stack_default_3, [1])
        mean_dim_3 = torch.ops.aten.mean.dim(sum_dim_int_list_6, [2, 3], True);  sum_dim_int_list_6 = None
        convolution_default_23 = torch.ops.aten.convolution.default(mean_dim_3, primals_54, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_53, primals_49, primals_51, primals_52, True, 0.1, 1e-05);  primals_49 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_62);  getitem_62 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_19, primals_55, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_3 = torch.ops.aten.view.default(convolution_default_24, [128, 2, 256, 1, 1]);  convolution_default_24 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(view_default_3, 1, False);  view_default_3 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(stack_default_3, _softmax_default_3)
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_3, [1]);  mul_tensor_3 = None
        convolution_default_25 = torch.ops.aten.convolution.default(sum_dim_int_list_7, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_285, 1);  primals_285 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_288, primals_289, primals_286, primals_287, True, 0.1, 1e-05);  primals_289 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_15, primals_59, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_64, primals_60, primals_62, primals_63, True, 0.1, 1e-05);  primals_60 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        add__tensor_10 = torch.ops.aten.add_.Tensor(getitem_65, getitem_68);  getitem_65 = getitem_68 = None
        relu__default_20 = torch.ops.aten.relu_.default(add__tensor_10);  add__tensor_10 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_20, primals_65, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_290, 1);  primals_290 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_293, primals_294, primals_291, primals_292, True, 0.1, 1e-05);  primals_294 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_71);  getitem_71 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_21, primals_73, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_295, 1);  primals_295 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_298, primals_299, primals_296, primals_297, True, 0.1, 1e-05);  primals_299 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_21, primals_74, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_300, 1);  primals_300 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_303, primals_304, primals_301, primals_302, True, 0.1, 1e-05);  primals_304 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        stack_default_4 = torch.ops.aten.stack.default([relu__default_22, relu__default_23], 1)
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(stack_default_4, [1])
        mean_dim_4 = torch.ops.aten.mean.dim(sum_dim_int_list_8, [2, 3], True);  sum_dim_int_list_8 = None
        convolution_default_30 = torch.ops.aten.convolution.default(mean_dim_4, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_70, primals_66, primals_68, primals_69, True, 0.1, 1e-05);  primals_66 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_80);  getitem_80 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_24, primals_72, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_4 = torch.ops.aten.view.default(convolution_default_31, [128, 2, 256, 1, 1]);  convolution_default_31 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(view_default_4, 1, False);  view_default_4 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(stack_default_4, _softmax_default_4)
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_4, [1]);  mul_tensor_4 = None
        convolution_default_32 = torch.ops.aten.convolution.default(sum_dim_int_list_9, primals_75, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_305, 1);  primals_305 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_308, primals_309, primals_306, primals_307, True, 0.1, 1e-05);  primals_309 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        add__tensor_12 = torch.ops.aten.add_.Tensor(getitem_83, relu__default_20);  getitem_83 = None
        relu__default_25 = torch.ops.aten.relu_.default(add__tensor_12);  add__tensor_12 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_25, primals_76, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_310, 1);  primals_310 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_313, primals_314, primals_311, primals_312, True, 0.1, 1e-05);  primals_314 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_26, primals_84, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_315, 1);  primals_315 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_318, primals_319, primals_316, primals_317, True, 0.1, 1e-05);  primals_319 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_26, primals_85, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_320, 1);  primals_320 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_323, primals_324, primals_321, primals_322, True, 0.1, 1e-05);  primals_324 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_92);  getitem_92 = None
        stack_default_5 = torch.ops.aten.stack.default([relu__default_27, relu__default_28], 1)
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(stack_default_5, [1])
        mean_dim_5 = torch.ops.aten.mean.dim(sum_dim_int_list_10, [2, 3], True);  sum_dim_int_list_10 = None
        convolution_default_36 = torch.ops.aten.convolution.default(mean_dim_5, primals_82, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_81, primals_77, primals_79, primals_80, True, 0.1, 1e-05);  primals_77 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_29, primals_83, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_5 = torch.ops.aten.view.default(convolution_default_37, [128, 2, 256, 1, 1]);  convolution_default_37 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(view_default_5, 1, False);  view_default_5 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(stack_default_5, _softmax_default_5)
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_5, [1]);  mul_tensor_5 = None
        convolution_default_38 = torch.ops.aten.convolution.default(sum_dim_int_list_11, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_325, 1);  primals_325 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_328, primals_329, primals_326, primals_327, True, 0.1, 1e-05);  primals_329 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        add__tensor_14 = torch.ops.aten.add_.Tensor(getitem_98, relu__default_25);  getitem_98 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_14);  add__tensor_14 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_30, primals_87, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_330, 1);  primals_330 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_333, primals_334, primals_331, primals_332, True, 0.1, 1e-05);  primals_334 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_101);  getitem_101 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_31, primals_95, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_335, 1);  primals_335 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_338, primals_339, primals_336, primals_337, True, 0.1, 1e-05);  primals_339 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_31, primals_96, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_340, 1);  primals_340 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_343, primals_344, primals_341, primals_342, True, 0.1, 1e-05);  primals_344 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        stack_default_6 = torch.ops.aten.stack.default([relu__default_32, relu__default_33], 1)
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(stack_default_6, [1])
        mean_dim_6 = torch.ops.aten.mean.dim(sum_dim_int_list_12, [2, 3], True);  sum_dim_int_list_12 = None
        convolution_default_42 = torch.ops.aten.convolution.default(mean_dim_6, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_92, primals_88, primals_90, primals_91, True, 0.1, 1e-05);  primals_88 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_110);  getitem_110 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_34, primals_94, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_6 = torch.ops.aten.view.default(convolution_default_43, [128, 2, 256, 1, 1]);  convolution_default_43 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(view_default_6, 1, False);  view_default_6 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(stack_default_6, _softmax_default_6)
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_6, [1]);  mul_tensor_6 = None
        convolution_default_44 = torch.ops.aten.convolution.default(sum_dim_int_list_13, primals_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_27 = torch.ops.aten.add.Tensor(primals_345, 1);  primals_345 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_348, primals_349, primals_346, primals_347, True, 0.1, 1e-05);  primals_349 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        add__tensor_16 = torch.ops.aten.add_.Tensor(getitem_113, relu__default_30);  getitem_113 = None
        relu__default_35 = torch.ops.aten.relu_.default(add__tensor_16);  add__tensor_16 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_35, primals_98, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_350, 1);  primals_350 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_353, primals_354, primals_351, primals_352, True, 0.1, 1e-05);  primals_354 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_36, primals_106, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_355, 1);  primals_355 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_358, primals_359, primals_356, primals_357, True, 0.1, 1e-05);  primals_359 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_36, primals_107, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_360, 1);  primals_360 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_363, primals_364, primals_361, primals_362, True, 0.1, 1e-05);  primals_364 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        stack_default_7 = torch.ops.aten.stack.default([relu__default_37, relu__default_38], 1)
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(stack_default_7, [1])
        mean_dim_7 = torch.ops.aten.mean.dim(sum_dim_int_list_14, [2, 3], True);  sum_dim_int_list_14 = None
        convolution_default_48 = torch.ops.aten.convolution.default(mean_dim_7, primals_104, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_103, primals_99, primals_101, primals_102, True, 0.1, 1e-05);  primals_99 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_39, primals_105, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_7 = torch.ops.aten.view.default(convolution_default_49, [128, 2, 512, 1, 1]);  convolution_default_49 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(view_default_7, 1, False);  view_default_7 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(stack_default_7, _softmax_default_7)
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_7, [1]);  mul_tensor_7 = None
        convolution_default_50 = torch.ops.aten.convolution.default(sum_dim_int_list_15, primals_108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_365, 1);  primals_365 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_368, primals_369, primals_366, primals_367, True, 0.1, 1e-05);  primals_369 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_35, primals_109, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_114, primals_110, primals_112, primals_113, True, 0.1, 1e-05);  primals_110 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        add__tensor_19 = torch.ops.aten.add_.Tensor(getitem_128, getitem_131);  getitem_128 = getitem_131 = None
        relu__default_40 = torch.ops.aten.relu_.default(add__tensor_19);  add__tensor_19 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_40, primals_115, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_370, 1);  primals_370 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_373, primals_374, primals_371, primals_372, True, 0.1, 1e-05);  primals_374 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_41, primals_123, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_375, 1);  primals_375 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_378, primals_379, primals_376, primals_377, True, 0.1, 1e-05);  primals_379 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_137);  getitem_137 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_41, primals_124, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_34 = torch.ops.aten.add.Tensor(primals_380, 1);  primals_380 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_383, primals_384, primals_381, primals_382, True, 0.1, 1e-05);  primals_384 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        stack_default_8 = torch.ops.aten.stack.default([relu__default_42, relu__default_43], 1)
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(stack_default_8, [1])
        mean_dim_8 = torch.ops.aten.mean.dim(sum_dim_int_list_16, [2, 3], True);  sum_dim_int_list_16 = None
        convolution_default_55 = torch.ops.aten.convolution.default(mean_dim_8, primals_121, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_120, primals_116, primals_118, primals_119, True, 0.1, 1e-05);  primals_116 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_143);  getitem_143 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_44, primals_122, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_8 = torch.ops.aten.view.default(convolution_default_56, [128, 2, 512, 1, 1]);  convolution_default_56 = None
        _softmax_default_8 = torch.ops.aten._softmax.default(view_default_8, 1, False);  view_default_8 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(stack_default_8, _softmax_default_8)
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_8, [1]);  mul_tensor_8 = None
        convolution_default_57 = torch.ops.aten.convolution.default(sum_dim_int_list_17, primals_125, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_385, 1);  primals_385 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_388, primals_389, primals_386, primals_387, True, 0.1, 1e-05);  primals_389 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        add__tensor_21 = torch.ops.aten.add_.Tensor(getitem_146, relu__default_40);  getitem_146 = None
        relu__default_45 = torch.ops.aten.relu_.default(add__tensor_21);  add__tensor_21 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_45, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_390, 1);  primals_390 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_393, primals_394, primals_391, primals_392, True, 0.1, 1e-05);  primals_394 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_149);  getitem_149 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_46, primals_134, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_395, 1);  primals_395 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_398, primals_399, primals_396, primals_397, True, 0.1, 1e-05);  primals_399 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_46, primals_135, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_38 = torch.ops.aten.add.Tensor(primals_400, 1);  primals_400 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_403, primals_404, primals_401, primals_402, True, 0.1, 1e-05);  primals_404 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_155);  getitem_155 = None
        stack_default_9 = torch.ops.aten.stack.default([relu__default_47, relu__default_48], 1)
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(stack_default_9, [1])
        mean_dim_9 = torch.ops.aten.mean.dim(sum_dim_int_list_18, [2, 3], True);  sum_dim_int_list_18 = None
        convolution_default_61 = torch.ops.aten.convolution.default(mean_dim_9, primals_132, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_131, primals_127, primals_129, primals_130, True, 0.1, 1e-05);  primals_127 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_49, primals_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_9 = torch.ops.aten.view.default(convolution_default_62, [128, 2, 512, 1, 1]);  convolution_default_62 = None
        _softmax_default_9 = torch.ops.aten._softmax.default(view_default_9, 1, False);  view_default_9 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(stack_default_9, _softmax_default_9)
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(mul_tensor_9, [1]);  mul_tensor_9 = None
        convolution_default_63 = torch.ops.aten.convolution.default(sum_dim_int_list_19, primals_136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_405, 1);  primals_405 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_408, primals_409, primals_406, primals_407, True, 0.1, 1e-05);  primals_409 = None
        getitem_161 = native_batch_norm_default_53[0]
        getitem_162 = native_batch_norm_default_53[1]
        getitem_163 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        add__tensor_23 = torch.ops.aten.add_.Tensor(getitem_161, relu__default_45);  getitem_161 = None
        relu__default_50 = torch.ops.aten.relu_.default(add__tensor_23);  add__tensor_23 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_50, primals_137, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_410, 1);  primals_410 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_413, primals_414, primals_411, primals_412, True, 0.1, 1e-05);  primals_414 = None
        getitem_164 = native_batch_norm_default_54[0]
        getitem_165 = native_batch_norm_default_54[1]
        getitem_166 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_51, primals_145, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_415, 1);  primals_415 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_418, primals_419, primals_416, primals_417, True, 0.1, 1e-05);  primals_419 = None
        getitem_167 = native_batch_norm_default_55[0]
        getitem_168 = native_batch_norm_default_55[1]
        getitem_169 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_51, primals_146, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_42 = torch.ops.aten.add.Tensor(primals_420, 1);  primals_420 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_423, primals_424, primals_421, primals_422, True, 0.1, 1e-05);  primals_424 = None
        getitem_170 = native_batch_norm_default_56[0]
        getitem_171 = native_batch_norm_default_56[1]
        getitem_172 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        stack_default_10 = torch.ops.aten.stack.default([relu__default_52, relu__default_53], 1)
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(stack_default_10, [1])
        mean_dim_10 = torch.ops.aten.mean.dim(sum_dim_int_list_20, [2, 3], True);  sum_dim_int_list_20 = None
        convolution_default_67 = torch.ops.aten.convolution.default(mean_dim_10, primals_143, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_142, primals_138, primals_140, primals_141, True, 0.1, 1e-05);  primals_138 = None
        getitem_173 = native_batch_norm_default_57[0]
        getitem_174 = native_batch_norm_default_57[1]
        getitem_175 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_173);  getitem_173 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_54, primals_144, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_10 = torch.ops.aten.view.default(convolution_default_68, [128, 2, 512, 1, 1]);  convolution_default_68 = None
        _softmax_default_10 = torch.ops.aten._softmax.default(view_default_10, 1, False);  view_default_10 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(stack_default_10, _softmax_default_10)
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(mul_tensor_10, [1]);  mul_tensor_10 = None
        convolution_default_69 = torch.ops.aten.convolution.default(sum_dim_int_list_21, primals_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_425, 1);  primals_425 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_428, primals_429, primals_426, primals_427, True, 0.1, 1e-05);  primals_429 = None
        getitem_176 = native_batch_norm_default_58[0]
        getitem_177 = native_batch_norm_default_58[1]
        getitem_178 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        add__tensor_25 = torch.ops.aten.add_.Tensor(getitem_176, relu__default_50);  getitem_176 = None
        relu__default_55 = torch.ops.aten.relu_.default(add__tensor_25);  add__tensor_25 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_55, primals_148, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_430, 1);  primals_430 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_433, primals_434, primals_431, primals_432, True, 0.1, 1e-05);  primals_434 = None
        getitem_179 = native_batch_norm_default_59[0]
        getitem_180 = native_batch_norm_default_59[1]
        getitem_181 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_56, primals_156, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_45 = torch.ops.aten.add.Tensor(primals_435, 1);  primals_435 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_438, primals_439, primals_436, primals_437, True, 0.1, 1e-05);  primals_439 = None
        getitem_182 = native_batch_norm_default_60[0]
        getitem_183 = native_batch_norm_default_60[1]
        getitem_184 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_56, primals_157, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_440, 1);  primals_440 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_443, primals_444, primals_441, primals_442, True, 0.1, 1e-05);  primals_444 = None
        getitem_185 = native_batch_norm_default_61[0]
        getitem_186 = native_batch_norm_default_61[1]
        getitem_187 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        stack_default_11 = torch.ops.aten.stack.default([relu__default_57, relu__default_58], 1)
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(stack_default_11, [1])
        mean_dim_11 = torch.ops.aten.mean.dim(sum_dim_int_list_22, [2, 3], True);  sum_dim_int_list_22 = None
        convolution_default_73 = torch.ops.aten.convolution.default(mean_dim_11, primals_154, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_153, primals_149, primals_151, primals_152, True, 0.1, 1e-05);  primals_149 = None
        getitem_188 = native_batch_norm_default_62[0]
        getitem_189 = native_batch_norm_default_62[1]
        getitem_190 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_59, primals_155, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_11 = torch.ops.aten.view.default(convolution_default_74, [128, 2, 512, 1, 1]);  convolution_default_74 = None
        _softmax_default_11 = torch.ops.aten._softmax.default(view_default_11, 1, False);  view_default_11 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(stack_default_11, _softmax_default_11)
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(mul_tensor_11, [1]);  mul_tensor_11 = None
        convolution_default_75 = torch.ops.aten.convolution.default(sum_dim_int_list_23, primals_158, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_445, 1);  primals_445 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_448, primals_449, primals_446, primals_447, True, 0.1, 1e-05);  primals_449 = None
        getitem_191 = native_batch_norm_default_63[0]
        getitem_192 = native_batch_norm_default_63[1]
        getitem_193 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        add__tensor_27 = torch.ops.aten.add_.Tensor(getitem_191, relu__default_55);  getitem_191 = None
        relu__default_60 = torch.ops.aten.relu_.default(add__tensor_27);  add__tensor_27 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_60, primals_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_450, 1);  primals_450 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_453, primals_454, primals_451, primals_452, True, 0.1, 1e-05);  primals_454 = None
        getitem_194 = native_batch_norm_default_64[0]
        getitem_195 = native_batch_norm_default_64[1]
        getitem_196 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_61, primals_167, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_49 = torch.ops.aten.add.Tensor(primals_455, 1);  primals_455 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_458, primals_459, primals_456, primals_457, True, 0.1, 1e-05);  primals_459 = None
        getitem_197 = native_batch_norm_default_65[0]
        getitem_198 = native_batch_norm_default_65[1]
        getitem_199 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_197);  getitem_197 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_61, primals_168, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_460, 1);  primals_460 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_463, primals_464, primals_461, primals_462, True, 0.1, 1e-05);  primals_464 = None
        getitem_200 = native_batch_norm_default_66[0]
        getitem_201 = native_batch_norm_default_66[1]
        getitem_202 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        stack_default_12 = torch.ops.aten.stack.default([relu__default_62, relu__default_63], 1)
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(stack_default_12, [1])
        mean_dim_12 = torch.ops.aten.mean.dim(sum_dim_int_list_24, [2, 3], True);  sum_dim_int_list_24 = None
        convolution_default_79 = torch.ops.aten.convolution.default(mean_dim_12, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_164, primals_160, primals_162, primals_163, True, 0.1, 1e-05);  primals_160 = None
        getitem_203 = native_batch_norm_default_67[0]
        getitem_204 = native_batch_norm_default_67[1]
        getitem_205 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_64, primals_166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_12 = torch.ops.aten.view.default(convolution_default_80, [128, 2, 512, 1, 1]);  convolution_default_80 = None
        _softmax_default_12 = torch.ops.aten._softmax.default(view_default_12, 1, False);  view_default_12 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(stack_default_12, _softmax_default_12)
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(mul_tensor_12, [1]);  mul_tensor_12 = None
        convolution_default_81 = torch.ops.aten.convolution.default(sum_dim_int_list_25, primals_169, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_465, 1);  primals_465 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_468, primals_469, primals_466, primals_467, True, 0.1, 1e-05);  primals_469 = None
        getitem_206 = native_batch_norm_default_68[0]
        getitem_207 = native_batch_norm_default_68[1]
        getitem_208 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        add__tensor_29 = torch.ops.aten.add_.Tensor(getitem_206, relu__default_60);  getitem_206 = None
        relu__default_65 = torch.ops.aten.relu_.default(add__tensor_29);  add__tensor_29 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_65, primals_170, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_470, 1);  primals_470 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_473, primals_474, primals_471, primals_472, True, 0.1, 1e-05);  primals_474 = None
        getitem_209 = native_batch_norm_default_69[0]
        getitem_210 = native_batch_norm_default_69[1]
        getitem_211 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_209);  getitem_209 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_66, primals_178, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_53 = torch.ops.aten.add.Tensor(primals_475, 1);  primals_475 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_478, primals_479, primals_476, primals_477, True, 0.1, 1e-05);  primals_479 = None
        getitem_212 = native_batch_norm_default_70[0]
        getitem_213 = native_batch_norm_default_70[1]
        getitem_214 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_66, primals_179, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_480, 1);  primals_480 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_483, primals_484, primals_481, primals_482, True, 0.1, 1e-05);  primals_484 = None
        getitem_215 = native_batch_norm_default_71[0]
        getitem_216 = native_batch_norm_default_71[1]
        getitem_217 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_215);  getitem_215 = None
        stack_default_13 = torch.ops.aten.stack.default([relu__default_67, relu__default_68], 1)
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(stack_default_13, [1])
        mean_dim_13 = torch.ops.aten.mean.dim(sum_dim_int_list_26, [2, 3], True);  sum_dim_int_list_26 = None
        convolution_default_85 = torch.ops.aten.convolution.default(mean_dim_13, primals_176, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_175, primals_171, primals_173, primals_174, True, 0.1, 1e-05);  primals_171 = None
        getitem_218 = native_batch_norm_default_72[0]
        getitem_219 = native_batch_norm_default_72[1]
        getitem_220 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_69, primals_177, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_13 = torch.ops.aten.view.default(convolution_default_86, [128, 2, 1024, 1, 1]);  convolution_default_86 = None
        _softmax_default_13 = torch.ops.aten._softmax.default(view_default_13, 1, False);  view_default_13 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(stack_default_13, _softmax_default_13)
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(mul_tensor_13, [1]);  mul_tensor_13 = None
        convolution_default_87 = torch.ops.aten.convolution.default(sum_dim_int_list_27, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_55 = torch.ops.aten.add.Tensor(primals_485, 1);  primals_485 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_488, primals_489, primals_486, primals_487, True, 0.1, 1e-05);  primals_489 = None
        getitem_221 = native_batch_norm_default_73[0]
        getitem_222 = native_batch_norm_default_73[1]
        getitem_223 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_65, primals_181, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_186, primals_182, primals_184, primals_185, True, 0.1, 1e-05);  primals_182 = None
        getitem_224 = native_batch_norm_default_74[0]
        getitem_225 = native_batch_norm_default_74[1]
        getitem_226 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        add__tensor_32 = torch.ops.aten.add_.Tensor(getitem_221, getitem_224);  getitem_221 = getitem_224 = None
        relu__default_70 = torch.ops.aten.relu_.default(add__tensor_32);  add__tensor_32 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_70, primals_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_490, 1);  primals_490 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_493, primals_494, primals_491, primals_492, True, 0.1, 1e-05);  primals_494 = None
        getitem_227 = native_batch_norm_default_75[0]
        getitem_228 = native_batch_norm_default_75[1]
        getitem_229 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_227);  getitem_227 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_71, primals_195, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_495, 1);  primals_495 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_498, primals_499, primals_496, primals_497, True, 0.1, 1e-05);  primals_499 = None
        getitem_230 = native_batch_norm_default_76[0]
        getitem_231 = native_batch_norm_default_76[1]
        getitem_232 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_71, primals_196, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_58 = torch.ops.aten.add.Tensor(primals_500, 1);  primals_500 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_503, primals_504, primals_501, primals_502, True, 0.1, 1e-05);  primals_504 = None
        getitem_233 = native_batch_norm_default_77[0]
        getitem_234 = native_batch_norm_default_77[1]
        getitem_235 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_233);  getitem_233 = None
        stack_default_14 = torch.ops.aten.stack.default([relu__default_72, relu__default_73], 1)
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(stack_default_14, [1])
        mean_dim_14 = torch.ops.aten.mean.dim(sum_dim_int_list_28, [2, 3], True);  sum_dim_int_list_28 = None
        convolution_default_92 = torch.ops.aten.convolution.default(mean_dim_14, primals_193, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_192, primals_188, primals_190, primals_191, True, 0.1, 1e-05);  primals_188 = None
        getitem_236 = native_batch_norm_default_78[0]
        getitem_237 = native_batch_norm_default_78[1]
        getitem_238 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_74, primals_194, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_14 = torch.ops.aten.view.default(convolution_default_93, [128, 2, 1024, 1, 1]);  convolution_default_93 = None
        _softmax_default_14 = torch.ops.aten._softmax.default(view_default_14, 1, False);  view_default_14 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(stack_default_14, _softmax_default_14)
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(mul_tensor_14, [1]);  mul_tensor_14 = None
        convolution_default_94 = torch.ops.aten.convolution.default(sum_dim_int_list_29, primals_197, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_59 = torch.ops.aten.add.Tensor(primals_505, 1);  primals_505 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_508, primals_509, primals_506, primals_507, True, 0.1, 1e-05);  primals_509 = None
        getitem_239 = native_batch_norm_default_79[0]
        getitem_240 = native_batch_norm_default_79[1]
        getitem_241 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        add__tensor_34 = torch.ops.aten.add_.Tensor(getitem_239, relu__default_70);  getitem_239 = None
        relu__default_75 = torch.ops.aten.relu_.default(add__tensor_34);  add__tensor_34 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_75, primals_198, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_60 = torch.ops.aten.add.Tensor(primals_510, 1);  primals_510 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_513, primals_514, primals_511, primals_512, True, 0.1, 1e-05);  primals_514 = None
        getitem_242 = native_batch_norm_default_80[0]
        getitem_243 = native_batch_norm_default_80[1]
        getitem_244 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_76, primals_206, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_515, 1);  primals_515 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_518, primals_519, primals_516, primals_517, True, 0.1, 1e-05);  primals_519 = None
        getitem_245 = native_batch_norm_default_81[0]
        getitem_246 = native_batch_norm_default_81[1]
        getitem_247 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_245);  getitem_245 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_76, primals_207, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 32)
        add_tensor_62 = torch.ops.aten.add.Tensor(primals_520, 1);  primals_520 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_523, primals_524, primals_521, primals_522, True, 0.1, 1e-05);  primals_524 = None
        getitem_248 = native_batch_norm_default_82[0]
        getitem_249 = native_batch_norm_default_82[1]
        getitem_250 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        stack_default_15 = torch.ops.aten.stack.default([relu__default_77, relu__default_78], 1)
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(stack_default_15, [1])
        mean_dim_15 = torch.ops.aten.mean.dim(sum_dim_int_list_30, [2, 3], True);  sum_dim_int_list_30 = None
        convolution_default_98 = torch.ops.aten.convolution.default(mean_dim_15, primals_204, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_203, primals_199, primals_201, primals_202, True, 0.1, 1e-05);  primals_199 = None
        getitem_251 = native_batch_norm_default_83[0]
        getitem_252 = native_batch_norm_default_83[1]
        getitem_253 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_79, primals_205, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_15 = torch.ops.aten.view.default(convolution_default_99, [128, 2, 1024, 1, 1]);  convolution_default_99 = None
        _softmax_default_15 = torch.ops.aten._softmax.default(view_default_15, 1, False);  view_default_15 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(stack_default_15, _softmax_default_15)
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(mul_tensor_15, [1]);  mul_tensor_15 = None
        convolution_default_100 = torch.ops.aten.convolution.default(sum_dim_int_list_31, primals_208, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_63 = torch.ops.aten.add.Tensor(primals_525, 1);  primals_525 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_528, primals_529, primals_526, primals_527, True, 0.1, 1e-05);  primals_529 = None
        getitem_254 = native_batch_norm_default_84[0]
        getitem_255 = native_batch_norm_default_84[1]
        getitem_256 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        add__tensor_36 = torch.ops.aten.add_.Tensor(getitem_254, relu__default_75);  getitem_254 = None
        relu__default_80 = torch.ops.aten.relu_.default(add__tensor_36);  add__tensor_36 = None
        mean_dim_16 = torch.ops.aten.mean.dim(relu__default_80, [-1, -2], True)
        view_default_16 = torch.ops.aten.view.default(mean_dim_16, [128, 2048]);  mean_dim_16 = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default_16, t_default);  primals_7 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_25, add_tensor_26, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_34, add_tensor_35, add_tensor_36, add_tensor_37, add_tensor_38, add_tensor_39, add_tensor_40, add_tensor_41, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_45, add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_49, add_tensor_50, add_tensor_51, add_tensor_52, add_tensor_53, add_tensor_54, add_tensor_55, add_tensor_56, add_tensor_57, add_tensor_58, add_tensor_59, add_tensor_60, add_tensor_61, add_tensor_62, add_tensor_63, convolution_default_32, primals_106, primals_276, convolution_default_23, getitem_253, getitem_183, primals_102, getitem_252, relu__default_56, relu__default_18, getitem_81, relu__default_57, primals_30, primals_268, relu__default_24, convolution_default_72, primals_24, primals_266, convolution_default_22, convolution_default_98, getitem_61, getitem_66, primals_107, primals_105, _softmax_default_4, primals_272, getitem_60, primals_16, primals_301, primals_26, getitem_232, primals_103, primals_297, primals_517, primals_104, _softmax_default_15, primals_296, getitem_184, primals_19, relu__default_17, getitem_64, sum_dim_int_list_31, convolution_default_71, sum_dim_int_list_7, primals_17, primals_31, primals_95, primals_108, getitem_234, primals_97, _softmax_default_3, getitem_63, mean_dim_15, mean_dim_3, stack_default_3, primals_101, relu__default_2, sum_dim_int_list_9, primals_15, primals_112, primals_96, primals_267, primals_278, getitem_115, primals_271, getitem_180, primals_109, primals_273, primals_29, primals_98, getitem_58, convolution_default_25, convolution_default_26, relu__default_19, primals_281, relu__default_41, relu__default_79, primals_25, getitem_181, mean_dim_4, primals_32, getitem_82, primals_23, primals_18, primals_277, convolution_default_100, primals_298, primals_20, getitem_67, primals_187, primals_502, primals_228, sum_dim_int_list_15, primals_82, getitem_45, primals_498, primals_84, primals_191, primals_481, sum_dim_int_list_23, primals_94, primals_501, primals_87, primals_162, primals_13, primals_233, primals_483, primals_317, stack_default_2, primals_192, primals_6, primals_201, primals_223, primals_478, convolution_default_50, getitem_46, getitem_129, getitem_192, getitem_127, primals_155, primals_231, primals_194, primals_472, primals_158, getitem_126, primals_12, primals_186, primals_326, primals_83, primals_221, primals_487, primals_85, primals_159, primals_321, getitem_90, primals_198, primals_316, getitem_91, relu__default_39, primals_488, convolution_default_16, primals_227, primals_477, getitem_93, primals_476, mean_dim_2, primals_157, primals_185, primals_232, primals_3, primals_492, primals_4, primals_86, primals_197, primals_471, relu__default_60, primals_93, primals_154, primals_482, primals_14, primals_328, relu__default_13, primals_9, primals_164, primals_190, primals_156, primals_497, convolution_default_35, primals_91, primals_153, primals_193, primals_327, primals_473, primals_322, primals_496, relu__default_27, convolution_default_75, primals_323, convolution_default_17, primals_196, convolution_default_19, primals_318, primals_491, primals_222, convolution_default_45, primals_226, primals_493, relu__default_12, primals_5, primals_81, primals_503, primals_92, primals_165, primals_486, primals_90, primals_163, primals_195, _softmax_default_7, primals_152, getitem_94, relu__default_14, primals_151, stack_default_6, primals_175, getitem_213, getitem_102, stack_default_11, sum_dim_int_list_13, primals_40, primals_178, mean_dim, primals_170, getitem_132, relu__default_32, primals_181, primals_33, convolution_default_51, getitem_133, getitem_109, stack_default_13, getitem_189, primals_184, getitem_214, relu__default_58, convolution_default_84, relu__default_72, primals_46, getitem_16, relu__default_30, primals_177, getitem_130, convolution_default_15, convolution_default_52, getitem_18, convolution_default_41, primals_179, getitem_39, relu__default_33, getitem_186, primals_35, convolution_default_85, primals_41, getitem_19, primals_34, stack_default, mean_dim_11, primals_37, primals_362, convolution_default_4, getitem_216, relu__default_3, getitem_135, getitem_190, relu__default_67, primals_363, convolution_default_40, getitem_100, primals_47, getitem_217, primals_366, primals_173, primals_43, getitem_42, primals_176, relu__default_31, primals_54, convolution_default_73, primals_45, relu__default_10, getitem_15, sum_dim_int_list_1, getitem_43, primals_367, convolution_default_14, getitem_105, relu__default_59, primals_53, getitem_12, primals_51, primals_180, primals_361, relu__default_4, primals_168, relu__default_40, primals_174, getitem_99, primals_169, primals_368, relu__default_11, primals_52, getitem_187, relu__default_73, primals_48, mean_dim_13, getitem_106, primals_166, _softmax_default_11, primals_44, _softmax_default, getitem_13, convolution_default_6, primals_36, relu__default_68, primals_167, convolution_default_7, primals_42, getitem_103, convolution_default_39, getitem_40, getitem_108, getitem_117, mean_dim_14, primals_73, primals_212, primals_238, primals_311, primals_252, primals_512, primals_242, primals_263, primals_522, getitem_52, primals_213, relu__default_34, convolution_default_44, primals_59, primals_262, primals_208, primals_308, primals_528, primals_446, primals_312, primals_506, primals_441, stack_default_14, convolution_default_94, primals_69, primals_206, primals_313, primals_507, primals_386, primals_527, primals_209, primals_383, relu__default_5, primals_63, convolution_default_46, getitem_199, getitem_202, primals_80, _softmax_default_6, relu__default_74, primals_207, primals_352, relu__default_42, stack_default_12, primals_71, primals_76, primals_236, primals_248, primals_302, primals_348, primals_518, primals_251, primals_342, primals_523, primals_72, primals_338, primals_65, primals_346, primals_307, primals_392, primals_448, convolution_default_3, relu__default_35, getitem_136, getitem_24, primals_443, convolution_default_9, _softmax_default_14, primals_70, primals_337, getitem_22, primals_203, getitem_237, primals_211, primals_436, primals_243, primals_205, primals_303, relu__default_6, primals_64, primals_351, getitem_10, convolution_default_42, primals_343, primals_437, primals_526, primals_511, primals_218, getitem_114, primals_393, convolution_default_8, primals_253, sum_dim_int_list_5, primals_247, sum_dim_int_list_29, primals_257, primals_341, relu__default_1, getitem_48, getitem_51, relu__default_36, getitem_6, getitem_49, getitem_139, primals_204, getitem_201, primals_256, getitem_25, mean_dim_12, primals_217, primals_442, convolution_default_79, getitem_231, primals_79, primals_237, primals_336, primals_74, primals_258, primals_306, primals_397, primals_68, primals_261, primals_388, convolution_default_2, primals_396, primals_438, primals_75, primals_347, primals_398, primals_241, primals_353, primals_513, primals_391, primals_516, getitem_7, primals_62, primals_387, primals_508, primals_216, getitem_21, primals_447, convolution_default_78, getitem_235, primals_246, primals_202, primals_125, convolution_default_21, primals_456, primals_123, primals_133, primals_145, primals_461, getitem_55, primals_462, convolution_default_63, primals_132, primals_466, getitem_3, stack_default_1, sum_dim_int_list_25, convolution_default_92, primals_451, relu__default_64, getitem_238, primals_56, convolution_default_11, primals_356, convolution_default_10, primals_131, convolution_default_33, primals_58, primals_130, getitem_88, primals_401, getitem_31, getitem_204, primals_458, getitem_57, convolution_default_81, primals_453, primals_115, primals_358, sum_dim_int_list_19, primals_406, primals_114, primals_142, primals_417, relu__default_62, primals_55, _softmax_default_12, primals_119, getitem_27, getitem_1, relu__default, getitem_28, primals_140, primals_403, convolution_default_54, getitem_85, getitem_162, convolution_default_1, getitem_87, primals_124, convolution_default_53, primals_148, primals_418, primals_143, primals_413, primals_144, relu__default_15, primals_118, primals_129, primals_134, primals_416, primals_135, primals_457, getitem_54, getitem_163, primals_147, relu__default_8, getitem_138, primals_408, primals_521, primals_137, relu__default_50, convolution_default_20, convolution_default_64, getitem_205, primals_126, primals_146, getitem_30, primals_121, primals_122, primals_136, primals_113, primals_463, mean_dim_1, primals_467, getitem_4, primals_141, getitem_2, primals_411, relu__default_26, getitem_160, primals_120, primals_407, relu__default_7, primals_357, relu__default_25, primals_402, primals_57, primals_412, primals_452, convolution_default_34, relu__default_49, relu__default_16, primals_468, getitem_84, getitem_208, relu__default_78, getitem_240, getitem_247, primals_332, getitem_159, getitem_211, getitem_249, relu__default_48, convolution_default_66, getitem_246, getitem_124, getitem_76, relu__default_37, getitem_156, convolution_default_82, primals_292, convolution_default_47, convolution_default_61, convolution_default_87, getitem_228, convolution_default_96, stack_default_9, primals_331, getitem_219, getitem_169, relu__default_52, relu__default_69, getitem_229, _softmax_default_13, relu__default_22, stack_default_4, primals_333, relu__default_23, getitem_250, primals_282, stack_default_7, relu__default_76, getitem_222, getitem_241, primals_287, getitem_121, primals_286, relu__default_51, relu__default_75, relu__default_66, convolution_default_88, primals_291, getitem_225, convolution_default_90, convolution_default_29, getitem_75, getitem_210, getitem_166, relu__default_70, getitem_123, getitem_223, getitem_168, getitem_79, _softmax_default_9, getitem_244, primals_288, getitem_207, getitem_220, convolution_default_65, getitem_165, getitem_226, getitem_120, relu__default_38, convolution_default_95, getitem_157, relu__default_71, mean_dim_7, getitem_243, relu__default_63, convolution_default_89, convolution_default, getitem_78, convolution_default_97, convolution_default_48, primals_283, convolution_default_83, sum_dim_int_list_27, relu__default_77, mean_dim_9, primals_293, relu__default_65, stack_default_15, mean_dim_8, relu__default_9, primals_427, getitem_145, primals_431, convolution_default_59, _softmax_default_1, sum_dim_int_list_17, convolution_default_55, relu__default_45, getitem_33, convolution_default_60, primals_422, getitem_153, _softmax_default_5, primals_423, relu__default_44, sum_dim_int_list_11, mean_dim_6, getitem_36, getitem_147, convolution_default_38, getitem_142, getitem_148, getitem_37, getitem_9, relu__default_47, getitem_112, getitem_97, getitem_96, getitem_151, primals_428, convolution_default_13, _softmax_default_2, relu__default_28, relu__default_29, getitem_34, convolution_default_36, relu__default_46, getitem_154, _softmax_default_8, getitem_141, getitem_150, mean_dim_5, primals_426, convolution_default_58, relu__default_43, primals_432, stack_default_8, primals_433, primals_421, stack_default_5, convolution_default_57, getitem_144, sum_dim_int_list_3, getitem_178, getitem_171, sum_dim_int_list_21, getitem_70, primals_376, primals_373, t_default, _softmax_default_10, getitem_177, convolution_default_69, relu__default_53, getitem_72, convolution_default_91, convolution_default_27, relu__default_55, convolution_default_30, convolution_default_67, convolution_default_70, convolution_default_77, convolution_default_28, convolution_default_76, getitem_255, getitem_196, primals_381, getitem_195, relu__default_21, getitem_172, relu__default_80, getitem_193, primals_377, primals_372, getitem_118, getitem_198, getitem_69, stack_default_10, mean_dim_10, getitem_174, primals_382, primals_371, relu__default_61, relu__default_20, getitem_111, primals_378, relu__default_54, getitem_73, getitem_175, getitem_256, view_default_16]
        
