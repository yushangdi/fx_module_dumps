
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/xception/xception_backward_0/state_dict.pt'))

    
    
    def forward(self, convolution_default_22, primals_261, primals_262, getitem_44, primals_263, getitem_43, primals_70, primals_64, primals_67, primals_266, relu__default_6, primals_267, primals_268, primals_269, convolution_default_21, primals_270, primals_68, primals_62, relu_default_6, primals_271, getitem_47, primals_272, primals_60, relu_default_3, primals_63, primals_273, getitem_46, primals_274, primals_277, primals_69, convolution_default_23, convolution_default_24, primals_61, primals_16, primals_21, primals_198, primals_19, relu__default_16, convolution_default_5, getitem_121, primals_199, getitem_7, getitem_22, primals_152, getitem_21, primals_200, relu__default_2, getitem_120, primals_151, getitem_20, primals_201, convolution_default_4, primals_150, getitem_8, primals_149, getitem_92, getitem_124, relu_default_1, primals_148, primals_204, convolution_default_11, getitem_91, primals_205, getitem_123, primals_145, primals_206, primals_144, relu__default_22, primals_207, getitem_11, primals_12, getitem_24, primals_9, primals_208, convolution_default_52, primals_143, getitem_27, convolution_default_71, getitem_26, primals_8, primals_142, getitem_10, getitem_9, primals_13, primals_141, convolution_default_72, primals_211, convolution_default_53, primals_20, primals_15, primals_212, primals_213, primals_138, primals_7, primals_214, convolution_default_54, convolution_default_73, primals_14, primals_137, primals_215, getitem_13, convolution_default_12, primals_136, convolution_default_6, convolution_default_13, primals_23, getitem_94, getitem_126, primals_135, add__tensor_5, primals_218, primals_22, primals_155, getitem_95, getitem_127, convolution_default_14, getitem_50, convolution_default_1, getitem_107, relu__default_17, getitem_30, getitem_29, convolution_default_55, getitem_2, convolution_default_56, relu__default_20, getitem_49, getitem_1, convolution_default_63, convolution_default_64, relu__default_7, relu__default_4, getitem_98, relu__default, getitem_110, getitem_97, convolution_default_26, convolution_default_15, getitem_109, relu__default_18, getitem_33, convolution_default_25, getitem_5, getitem_53, getitem_4, getitem_32, getitem_31, convolution_default_28, getitem_52, convolution_default_57, relu__default_1, relu__default_8, convolution_default_65, convolution_default_2, convolution_default_16, convolution_default_58, relu_default_9, getitem_35, convolution_default_66, convolution_default_27, getitem_100, convolution_default_3, primals_240, primals_162, primals_241, primals_158, primals_242, primals_243, getitem_80, primals_163, primals_164, primals_91, relu_default_7, primals_176, getitem_79, primals_246, primals_159, primals_165, primals_247, relu__default_14, primals_166, primals_248, convolution_default_44, primals_156, convolution_default_45, primals_251, primals_252, primals_169, primals_253, primals_170, primals_171, getitem_82, primals_172, convolution_default_46, primals_256, primals_257, primals_173, relu_default_4, primals_258, getitem_83, convolution_default, primals_157, primals_177, primals_178, relu__default_23, primals_94, primals_179, primals_127, primals_180, view_default, primals_122, primals_123, primals_134, primals_183, primals_131, primals_184, t_default, primals_185, primals_186, primals_100, primals_97, primals_187, primals_190, primals_191, primals_124, primals_192, primals_193, primals_128, primals_194, primals_130, primals_120, primals_121, primals_129, primals_96, primals_95, primals_197, relu_default_2, getitem_101, primals_84, getitem_112, primals_89, getitem_56, convolution_default_36, getitem_38, getitem_113, getitem_37, relu_default_10, primals_51, getitem_55, getitem_68, relu__default_21, primals_43, convolution_default_38, convolution_default_60, convolution_default_59, convolution_default_68, primals_54, convolution_default_67, primals_75, primals_74, getitem_67, getitem_118, getitem_104, convolution_default_18, convolution_default_17, primals_83, relu__default_11, getitem_116, convolution_default_30, getitem_103, primals_76, convolution_default_29, getitem_41, convolution_default_37, getitem_115, getitem_114, relu__default_19, primals_90, primals_40, convolution_default_70, getitem_40, convolution_default_32, primals_47, primals_80, primals_49, relu__default_5, getitem_59, primals_82, getitem_58, convolution_default_61, primals_41, getitem_71, primals_50, getitem_70, primals_88, relu__default_9, primals_44, convolution_default_62, primals_71, convolution_default_19, primals_81, add__tensor_49, primals_42, primals_87, convolution_default_69, primals_56, convolution_default_39, relu__default_12, add__tensor_45, convolution_default_31, primals_55, convolution_default_20, primals_48, primals_77, getitem_106, primals_57, primals_116, primals_219, primals_117, primals_220, primals_221, primals_222, primals_5, primals_102, primals_103, primals_225, primals_104, primals_226, primals_227, primals_228, primals_107, primals_108, primals_6, primals_229, primals_109, primals_110, primals_115, primals_232, primals_101, primals_233, primals_2, primals_234, primals_1, primals_235, primals_111, primals_114, primals_236, primals_239, getitem_16, convolution_default_34, getitem_15, convolution_default_48, convolution_default_47, getitem_62, getitem_74, getitem_86, getitem_88, getitem_61, getitem_73, primals_29, convolution_default_8, convolution_default_7, relu__default_10, getitem_85, primals_28, relu_default, convolution_default_40, relu__default_15, convolution_default_33, getitem_19, add__tensor_9, convolution_default_41, primals_27, getitem_18, primals_37, convolution_default_49, relu__default_3, primals_36, relu_default_8, primals_34, getitem_65, relu_default_5, getitem_64, convolution_default_42, convolution_default_51, convolution_default_50, primals_26, convolution_default_9, convolution_default_43, primals_33, getitem_77, convolution_default_10, primals_35, getitem_76, getitem_89, primals_30, relu__default_13, convolution_default_35, tangents_1):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 2048, 10, 10]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 100);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_40, to_dtype);  le_scalar = new_zeros_default_40 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_73, primals_268, primals_266, primals_267, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_73 = primals_268 = primals_266 = primals_267 = getitem_126 = getitem_127 = None
        getitem_128 = native_batch_norm_backward_default[0]
        getitem_129 = native_batch_norm_backward_default[1]
        getitem_130 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_128, convolution_default_72, primals_274, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_128 = convolution_default_72 = primals_274 = None
        getitem_131 = convolution_backward_default[0]
        getitem_132 = convolution_backward_default[1];  convolution_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_131, relu__default_22, primals_273, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1536, [True, True, False]);  getitem_131 = primals_273 = None
        getitem_134 = convolution_backward_default_1[0]
        getitem_135 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_134, torch.float32);  getitem_134 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_41, to_dtype_3);  le_scalar_1 = new_zeros_default_41 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_71, primals_263, primals_261, primals_262, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_71 = primals_263 = primals_261 = primals_262 = getitem_123 = getitem_124 = None
        getitem_137 = native_batch_norm_backward_default_1[0]
        getitem_138 = native_batch_norm_backward_default_1[1]
        getitem_139 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_137, convolution_default_70, primals_272, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_137 = convolution_default_70 = primals_272 = None
        getitem_140 = convolution_backward_default_2[0]
        getitem_141 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_140, add__tensor_49, primals_271, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1024, [True, True, False]);  getitem_140 = add__tensor_49 = primals_271 = None
        getitem_143 = convolution_backward_default_3[0]
        getitem_144 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(getitem_143, convolution_default_69, primals_62, primals_60, primals_61, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  convolution_default_69 = primals_62 = primals_60 = primals_61 = getitem_120 = getitem_121 = None
        getitem_146 = native_batch_norm_backward_default_2[0]
        getitem_147 = native_batch_norm_backward_default_2[1]
        getitem_148 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_146, add__tensor_45, primals_57, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_146 = add__tensor_45 = primals_57 = None
        getitem_149 = convolution_backward_default_4[0]
        getitem_150 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_143, getitem_114, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_118);  getitem_143 = getitem_114 = getitem_118 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(max_pool2d_with_indices_backward_default, convolution_default_68, primals_56, primals_54, primals_55, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  max_pool2d_with_indices_backward_default = convolution_default_68 = primals_56 = primals_54 = primals_55 = getitem_115 = getitem_116 = None
        getitem_152 = native_batch_norm_backward_default_3[0]
        getitem_153 = native_batch_norm_backward_default_3[1]
        getitem_154 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_152, convolution_default_67, primals_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_152 = convolution_default_67 = primals_51 = None
        getitem_155 = convolution_backward_default_5[0]
        getitem_156 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_155, relu__default_21, primals_50, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_155 = primals_50 = None
        getitem_158 = convolution_backward_default_6[0]
        getitem_159 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_158, torch.float32);  getitem_158 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_42, to_dtype_6);  le_scalar_2 = new_zeros_default_42 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_66, primals_49, primals_47, primals_48, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_66 = primals_49 = primals_47 = primals_48 = getitem_112 = getitem_113 = None
        getitem_161 = native_batch_norm_backward_default_4[0]
        getitem_162 = native_batch_norm_backward_default_4[1]
        getitem_163 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_161, convolution_default_65, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_161 = convolution_default_65 = primals_44 = None
        getitem_164 = convolution_backward_default_7[0]
        getitem_165 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_164, relu_default_10, primals_43, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_164 = primals_43 = None
        getitem_167 = convolution_backward_default_8[0]
        getitem_168 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_167, torch.float32);  getitem_167 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_43, to_dtype_9);  le_scalar_3 = new_zeros_default_43 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        add_tensor = torch.ops.aten.add.Tensor(getitem_149, to_dtype_11);  getitem_149 = to_dtype_11 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(add_tensor, convolution_default_64, primals_42, primals_40, primals_41, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  convolution_default_64 = primals_42 = primals_40 = primals_41 = getitem_109 = getitem_110 = None
        getitem_170 = native_batch_norm_backward_default_5[0]
        getitem_171 = native_batch_norm_backward_default_5[1]
        getitem_172 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_170, convolution_default_63, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_170 = convolution_default_63 = primals_37 = None
        getitem_173 = convolution_backward_default_9[0]
        getitem_174 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_173, relu__default_20, primals_36, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_173 = primals_36 = None
        getitem_176 = convolution_backward_default_10[0]
        getitem_177 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_176, torch.float32);  getitem_176 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_44, to_dtype_12);  le_scalar_4 = new_zeros_default_44 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_62, primals_35, primals_33, primals_34, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_62 = primals_35 = primals_33 = primals_34 = getitem_106 = getitem_107 = None
        getitem_179 = native_batch_norm_backward_default_6[0]
        getitem_180 = native_batch_norm_backward_default_6[1]
        getitem_181 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_179, convolution_default_61, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_179 = convolution_default_61 = primals_30 = None
        getitem_182 = convolution_backward_default_11[0]
        getitem_183 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_182, relu__default_19, primals_29, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_182 = primals_29 = None
        getitem_185 = convolution_backward_default_12[0]
        getitem_186 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_185, torch.float32);  getitem_185 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_45, to_dtype_15);  le_scalar_5 = new_zeros_default_45 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_60, primals_28, primals_26, primals_27, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_60 = primals_28 = primals_26 = primals_27 = getitem_103 = getitem_104 = None
        getitem_188 = native_batch_norm_backward_default_7[0]
        getitem_189 = native_batch_norm_backward_default_7[1]
        getitem_190 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_188, convolution_default_59, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_188 = convolution_default_59 = primals_23 = None
        getitem_191 = convolution_backward_default_13[0]
        getitem_192 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_191, relu_default_9, primals_22, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_191 = primals_22 = None
        getitem_194 = convolution_backward_default_14[0]
        getitem_195 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_194, torch.float32);  getitem_194 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_46, to_dtype_18);  le_scalar_6 = new_zeros_default_46 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(add_tensor, to_dtype_20);  add_tensor = to_dtype_20 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_1, convolution_default_58, primals_21, primals_19, primals_20, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  convolution_default_58 = primals_21 = primals_19 = primals_20 = getitem_100 = getitem_101 = None
        getitem_197 = native_batch_norm_backward_default_8[0]
        getitem_198 = native_batch_norm_backward_default_8[1]
        getitem_199 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_197, convolution_default_57, primals_16, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_197 = convolution_default_57 = primals_16 = None
        getitem_200 = convolution_backward_default_15[0]
        getitem_201 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_200, relu__default_18, primals_15, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_200 = primals_15 = None
        getitem_203 = convolution_backward_default_16[0]
        getitem_204 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_203, torch.float32);  getitem_203 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_47, to_dtype_21);  le_scalar_7 = new_zeros_default_47 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_56, primals_14, primals_12, primals_13, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_56 = primals_14 = primals_12 = primals_13 = getitem_97 = getitem_98 = None
        getitem_206 = native_batch_norm_backward_default_9[0]
        getitem_207 = native_batch_norm_backward_default_9[1]
        getitem_208 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_206, convolution_default_55, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_206 = convolution_default_55 = primals_9 = None
        getitem_209 = convolution_backward_default_17[0]
        getitem_210 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_209, relu__default_17, primals_8, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_209 = primals_8 = None
        getitem_212 = convolution_backward_default_18[0]
        getitem_213 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_212, torch.float32);  getitem_212 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_48, to_dtype_24);  le_scalar_8 = new_zeros_default_48 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_54, primals_7, primals_5, primals_6, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_54 = primals_7 = primals_5 = primals_6 = getitem_94 = getitem_95 = None
        getitem_215 = native_batch_norm_backward_default_10[0]
        getitem_216 = native_batch_norm_backward_default_10[1]
        getitem_217 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_215, convolution_default_53, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_215 = convolution_default_53 = primals_2 = None
        getitem_218 = convolution_backward_default_19[0]
        getitem_219 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_218, relu_default_8, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_218 = primals_1 = None
        getitem_221 = convolution_backward_default_20[0]
        getitem_222 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_221, torch.float32);  getitem_221 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_49, to_dtype_27);  le_scalar_9 = new_zeros_default_49 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, to_dtype_29);  add_tensor_1 = to_dtype_29 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_2, convolution_default_52, primals_248, primals_246, primals_247, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  convolution_default_52 = primals_248 = primals_246 = primals_247 = getitem_91 = getitem_92 = None
        getitem_224 = native_batch_norm_backward_default_11[0]
        getitem_225 = native_batch_norm_backward_default_11[1]
        getitem_226 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_224, convolution_default_51, primals_243, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_224 = convolution_default_51 = primals_243 = None
        getitem_227 = convolution_backward_default_21[0]
        getitem_228 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_227, relu__default_16, primals_242, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_227 = primals_242 = None
        getitem_230 = convolution_backward_default_22[0]
        getitem_231 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_230, torch.float32);  getitem_230 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_50, to_dtype_30);  le_scalar_10 = new_zeros_default_50 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_50, primals_241, primals_239, primals_240, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_50 = primals_241 = primals_239 = primals_240 = getitem_88 = getitem_89 = None
        getitem_233 = native_batch_norm_backward_default_12[0]
        getitem_234 = native_batch_norm_backward_default_12[1]
        getitem_235 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_233, convolution_default_49, primals_236, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_233 = convolution_default_49 = primals_236 = None
        getitem_236 = convolution_backward_default_23[0]
        getitem_237 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_236, relu__default_15, primals_235, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_236 = primals_235 = None
        getitem_239 = convolution_backward_default_24[0]
        getitem_240 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_239, torch.float32);  getitem_239 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_51, to_dtype_33);  le_scalar_11 = new_zeros_default_51 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_48, primals_234, primals_232, primals_233, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_48 = primals_234 = primals_232 = primals_233 = getitem_85 = getitem_86 = None
        getitem_242 = native_batch_norm_backward_default_13[0]
        getitem_243 = native_batch_norm_backward_default_13[1]
        getitem_244 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_242, convolution_default_47, primals_229, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_242 = convolution_default_47 = primals_229 = None
        getitem_245 = convolution_backward_default_25[0]
        getitem_246 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_245, relu_default_7, primals_228, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_245 = primals_228 = None
        getitem_248 = convolution_backward_default_26[0]
        getitem_249 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_248, torch.float32);  getitem_248 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_52, to_dtype_36);  le_scalar_12 = new_zeros_default_52 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_2, to_dtype_38);  add_tensor_2 = to_dtype_38 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_3, convolution_default_46, primals_227, primals_225, primals_226, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  convolution_default_46 = primals_227 = primals_225 = primals_226 = getitem_82 = getitem_83 = None
        getitem_251 = native_batch_norm_backward_default_14[0]
        getitem_252 = native_batch_norm_backward_default_14[1]
        getitem_253 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_251, convolution_default_45, primals_222, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_251 = convolution_default_45 = primals_222 = None
        getitem_254 = convolution_backward_default_27[0]
        getitem_255 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_254, relu__default_14, primals_221, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_254 = primals_221 = None
        getitem_257 = convolution_backward_default_28[0]
        getitem_258 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_257, torch.float32);  getitem_257 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_53, to_dtype_39);  le_scalar_13 = new_zeros_default_53 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_44, primals_220, primals_218, primals_219, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_44 = primals_220 = primals_218 = primals_219 = getitem_79 = getitem_80 = None
        getitem_260 = native_batch_norm_backward_default_15[0]
        getitem_261 = native_batch_norm_backward_default_15[1]
        getitem_262 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_260, convolution_default_43, primals_215, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_260 = convolution_default_43 = primals_215 = None
        getitem_263 = convolution_backward_default_29[0]
        getitem_264 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_263, relu__default_13, primals_214, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_263 = primals_214 = None
        getitem_266 = convolution_backward_default_30[0]
        getitem_267 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_266, torch.float32);  getitem_266 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_54, to_dtype_42);  le_scalar_14 = new_zeros_default_54 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_42, primals_213, primals_211, primals_212, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_42 = primals_213 = primals_211 = primals_212 = getitem_76 = getitem_77 = None
        getitem_269 = native_batch_norm_backward_default_16[0]
        getitem_270 = native_batch_norm_backward_default_16[1]
        getitem_271 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_269, convolution_default_41, primals_208, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_269 = convolution_default_41 = primals_208 = None
        getitem_272 = convolution_backward_default_31[0]
        getitem_273 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_272, relu_default_6, primals_207, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_272 = primals_207 = None
        getitem_275 = convolution_backward_default_32[0]
        getitem_276 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_275, torch.float32);  getitem_275 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_55, to_dtype_45);  le_scalar_15 = new_zeros_default_55 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, to_dtype_47);  add_tensor_3 = to_dtype_47 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_4, convolution_default_40, primals_206, primals_204, primals_205, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  convolution_default_40 = primals_206 = primals_204 = primals_205 = getitem_73 = getitem_74 = None
        getitem_278 = native_batch_norm_backward_default_17[0]
        getitem_279 = native_batch_norm_backward_default_17[1]
        getitem_280 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_278, convolution_default_39, primals_201, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_278 = convolution_default_39 = primals_201 = None
        getitem_281 = convolution_backward_default_33[0]
        getitem_282 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_281, relu__default_12, primals_200, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_281 = primals_200 = None
        getitem_284 = convolution_backward_default_34[0]
        getitem_285 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_284, torch.float32);  getitem_284 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_56, to_dtype_48);  le_scalar_16 = new_zeros_default_56 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_38, primals_199, primals_197, primals_198, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_38 = primals_199 = primals_197 = primals_198 = getitem_70 = getitem_71 = None
        getitem_287 = native_batch_norm_backward_default_18[0]
        getitem_288 = native_batch_norm_backward_default_18[1]
        getitem_289 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_287, convolution_default_37, primals_194, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_287 = convolution_default_37 = primals_194 = None
        getitem_290 = convolution_backward_default_35[0]
        getitem_291 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_290, relu__default_11, primals_193, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_290 = primals_193 = None
        getitem_293 = convolution_backward_default_36[0]
        getitem_294 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_293, torch.float32);  getitem_293 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_57, to_dtype_51);  le_scalar_17 = new_zeros_default_57 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_36, primals_192, primals_190, primals_191, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_36 = primals_192 = primals_190 = primals_191 = getitem_67 = getitem_68 = None
        getitem_296 = native_batch_norm_backward_default_19[0]
        getitem_297 = native_batch_norm_backward_default_19[1]
        getitem_298 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_296, convolution_default_35, primals_187, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_296 = convolution_default_35 = primals_187 = None
        getitem_299 = convolution_backward_default_37[0]
        getitem_300 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_299, relu_default_5, primals_186, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_299 = primals_186 = None
        getitem_302 = convolution_backward_default_38[0]
        getitem_303 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_302, torch.float32);  getitem_302 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_58, to_dtype_54);  le_scalar_18 = new_zeros_default_58 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(add_tensor_4, to_dtype_56);  add_tensor_4 = to_dtype_56 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_5, convolution_default_34, primals_185, primals_183, primals_184, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  convolution_default_34 = primals_185 = primals_183 = primals_184 = getitem_64 = getitem_65 = None
        getitem_305 = native_batch_norm_backward_default_20[0]
        getitem_306 = native_batch_norm_backward_default_20[1]
        getitem_307 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_305, convolution_default_33, primals_180, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_305 = convolution_default_33 = primals_180 = None
        getitem_308 = convolution_backward_default_39[0]
        getitem_309 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_308, relu__default_10, primals_179, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_308 = primals_179 = None
        getitem_311 = convolution_backward_default_40[0]
        getitem_312 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_311, torch.float32);  getitem_311 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_59, to_dtype_57);  le_scalar_19 = new_zeros_default_59 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_32, primals_178, primals_176, primals_177, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_32 = primals_178 = primals_176 = primals_177 = getitem_61 = getitem_62 = None
        getitem_314 = native_batch_norm_backward_default_21[0]
        getitem_315 = native_batch_norm_backward_default_21[1]
        getitem_316 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_314, convolution_default_31, primals_173, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_314 = convolution_default_31 = primals_173 = None
        getitem_317 = convolution_backward_default_41[0]
        getitem_318 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_317, relu__default_9, primals_172, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_317 = primals_172 = None
        getitem_320 = convolution_backward_default_42[0]
        getitem_321 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_320, torch.float32);  getitem_320 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_60, to_dtype_60);  le_scalar_20 = new_zeros_default_60 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_30, primals_171, primals_169, primals_170, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_30 = primals_171 = primals_169 = primals_170 = getitem_58 = getitem_59 = None
        getitem_323 = native_batch_norm_backward_default_22[0]
        getitem_324 = native_batch_norm_backward_default_22[1]
        getitem_325 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_323, convolution_default_29, primals_166, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_323 = convolution_default_29 = primals_166 = None
        getitem_326 = convolution_backward_default_43[0]
        getitem_327 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_326, relu_default_4, primals_165, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_326 = primals_165 = None
        getitem_329 = convolution_backward_default_44[0]
        getitem_330 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_329, torch.float32);  getitem_329 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_61, to_dtype_63);  le_scalar_21 = new_zeros_default_61 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(add_tensor_5, to_dtype_65);  add_tensor_5 = to_dtype_65 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_6, convolution_default_28, primals_164, primals_162, primals_163, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  convolution_default_28 = primals_164 = primals_162 = primals_163 = getitem_55 = getitem_56 = None
        getitem_332 = native_batch_norm_backward_default_23[0]
        getitem_333 = native_batch_norm_backward_default_23[1]
        getitem_334 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_332, convolution_default_27, primals_159, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_332 = convolution_default_27 = primals_159 = None
        getitem_335 = convolution_backward_default_45[0]
        getitem_336 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_335, relu__default_8, primals_158, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_335 = primals_158 = None
        getitem_338 = convolution_backward_default_46[0]
        getitem_339 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_338, torch.float32);  getitem_338 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_62, to_dtype_66);  le_scalar_22 = new_zeros_default_62 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_26, primals_157, primals_155, primals_156, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_26 = primals_157 = primals_155 = primals_156 = getitem_52 = getitem_53 = None
        getitem_341 = native_batch_norm_backward_default_24[0]
        getitem_342 = native_batch_norm_backward_default_24[1]
        getitem_343 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_341, convolution_default_25, primals_152, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_341 = convolution_default_25 = primals_152 = None
        getitem_344 = convolution_backward_default_47[0]
        getitem_345 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_344, relu__default_7, primals_151, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_344 = primals_151 = None
        getitem_347 = convolution_backward_default_48[0]
        getitem_348 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_347, torch.float32);  getitem_347 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_63, to_dtype_69);  le_scalar_23 = new_zeros_default_63 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_24, primals_150, primals_148, primals_149, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_24 = primals_150 = primals_148 = primals_149 = getitem_49 = getitem_50 = None
        getitem_350 = native_batch_norm_backward_default_25[0]
        getitem_351 = native_batch_norm_backward_default_25[1]
        getitem_352 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_350, convolution_default_23, primals_145, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_350 = convolution_default_23 = primals_145 = None
        getitem_353 = convolution_backward_default_49[0]
        getitem_354 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_353, relu_default_3, primals_144, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_353 = primals_144 = None
        getitem_356 = convolution_backward_default_50[0]
        getitem_357 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_356, torch.float32);  getitem_356 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_64, to_dtype_72);  le_scalar_24 = new_zeros_default_64 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, to_dtype_74);  add_tensor_6 = to_dtype_74 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_7, convolution_default_22, primals_143, primals_141, primals_142, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  convolution_default_22 = primals_143 = primals_141 = primals_142 = getitem_46 = getitem_47 = None
        getitem_359 = native_batch_norm_backward_default_26[0]
        getitem_360 = native_batch_norm_backward_default_26[1]
        getitem_361 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_359, convolution_default_21, primals_138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_359 = convolution_default_21 = primals_138 = None
        getitem_362 = convolution_backward_default_51[0]
        getitem_363 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_362, relu__default_6, primals_137, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_362 = primals_137 = None
        getitem_365 = convolution_backward_default_52[0]
        getitem_366 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_365, torch.float32);  getitem_365 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_65, to_dtype_75);  le_scalar_25 = new_zeros_default_65 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_20, primals_136, primals_134, primals_135, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_20 = primals_136 = primals_134 = primals_135 = getitem_43 = getitem_44 = None
        getitem_368 = native_batch_norm_backward_default_27[0]
        getitem_369 = native_batch_norm_backward_default_27[1]
        getitem_370 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_368, convolution_default_19, primals_131, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_368 = convolution_default_19 = primals_131 = None
        getitem_371 = convolution_backward_default_53[0]
        getitem_372 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_371, relu__default_5, primals_130, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_371 = primals_130 = None
        getitem_374 = convolution_backward_default_54[0]
        getitem_375 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_374, torch.float32);  getitem_374 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_66, to_dtype_78);  le_scalar_26 = new_zeros_default_66 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_18, primals_129, primals_127, primals_128, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_18 = primals_129 = primals_127 = primals_128 = getitem_40 = getitem_41 = None
        getitem_377 = native_batch_norm_backward_default_28[0]
        getitem_378 = native_batch_norm_backward_default_28[1]
        getitem_379 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_377, convolution_default_17, primals_124, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_377 = convolution_default_17 = primals_124 = None
        getitem_380 = convolution_backward_default_55[0]
        getitem_381 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_380, relu_default_2, primals_123, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_380 = primals_123 = None
        getitem_383 = convolution_backward_default_56[0]
        getitem_384 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_383, torch.float32);  getitem_383 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_67, to_dtype_81);  le_scalar_27 = new_zeros_default_67 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_7, to_dtype_83);  add_tensor_7 = to_dtype_83 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_8, convolution_default_16, primals_122, primals_120, primals_121, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  convolution_default_16 = primals_122 = primals_120 = primals_121 = getitem_37 = getitem_38 = None
        getitem_386 = native_batch_norm_backward_default_29[0]
        getitem_387 = native_batch_norm_backward_default_29[1]
        getitem_388 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_386, add__tensor_9, primals_117, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_386 = add__tensor_9 = primals_117 = None
        getitem_389 = convolution_backward_default_57[0]
        getitem_390 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_8, getitem_31, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_35);  add_tensor_8 = getitem_31 = getitem_35 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(max_pool2d_with_indices_backward_default_1, convolution_default_15, primals_116, primals_114, primals_115, getitem_32, getitem_33, True, 1e-05, [True, True, True]);  max_pool2d_with_indices_backward_default_1 = convolution_default_15 = primals_116 = primals_114 = primals_115 = getitem_32 = getitem_33 = None
        getitem_392 = native_batch_norm_backward_default_30[0]
        getitem_393 = native_batch_norm_backward_default_30[1]
        getitem_394 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_392, convolution_default_14, primals_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_392 = convolution_default_14 = primals_111 = None
        getitem_395 = convolution_backward_default_58[0]
        getitem_396 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_395, relu__default_4, primals_110, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_395 = primals_110 = None
        getitem_398 = convolution_backward_default_59[0]
        getitem_399 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_398, torch.float32);  getitem_398 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_68, to_dtype_84);  le_scalar_28 = new_zeros_default_68 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_13, primals_109, primals_107, primals_108, getitem_29, getitem_30, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_13 = primals_109 = primals_107 = primals_108 = getitem_29 = getitem_30 = None
        getitem_401 = native_batch_norm_backward_default_31[0]
        getitem_402 = native_batch_norm_backward_default_31[1]
        getitem_403 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_401, convolution_default_12, primals_104, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_401 = convolution_default_12 = primals_104 = None
        getitem_404 = convolution_backward_default_60[0]
        getitem_405 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_404, relu_default_1, primals_103, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 256, [True, True, False]);  getitem_404 = primals_103 = None
        getitem_407 = convolution_backward_default_61[0]
        getitem_408 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_407, torch.float32);  getitem_407 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_69, to_dtype_87);  le_scalar_29 = new_zeros_default_69 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_389, to_dtype_89);  getitem_389 = to_dtype_89 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_9, convolution_default_11, primals_102, primals_100, primals_101, getitem_26, getitem_27, True, 1e-05, [True, True, True]);  convolution_default_11 = primals_102 = primals_100 = primals_101 = getitem_26 = getitem_27 = None
        getitem_410 = native_batch_norm_backward_default_32[0]
        getitem_411 = native_batch_norm_backward_default_32[1]
        getitem_412 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_410, add__tensor_5, primals_97, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_410 = add__tensor_5 = primals_97 = None
        getitem_413 = convolution_backward_default_62[0]
        getitem_414 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_9, getitem_20, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_24);  add_tensor_9 = getitem_20 = getitem_24 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(max_pool2d_with_indices_backward_default_2, convolution_default_10, primals_96, primals_94, primals_95, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  max_pool2d_with_indices_backward_default_2 = convolution_default_10 = primals_96 = primals_94 = primals_95 = getitem_21 = getitem_22 = None
        getitem_416 = native_batch_norm_backward_default_33[0]
        getitem_417 = native_batch_norm_backward_default_33[1]
        getitem_418 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_416, convolution_default_9, primals_91, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_416 = convolution_default_9 = primals_91 = None
        getitem_419 = convolution_backward_default_63[0]
        getitem_420 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_419, relu__default_3, primals_90, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 256, [True, True, False]);  getitem_419 = primals_90 = None
        getitem_422 = convolution_backward_default_64[0]
        getitem_423 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_422, torch.float32);  getitem_422 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_70, to_dtype_90);  le_scalar_30 = new_zeros_default_70 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_8, primals_89, primals_87, primals_88, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_8 = primals_89 = primals_87 = primals_88 = getitem_18 = getitem_19 = None
        getitem_425 = native_batch_norm_backward_default_34[0]
        getitem_426 = native_batch_norm_backward_default_34[1]
        getitem_427 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_425, convolution_default_7, primals_84, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_425 = convolution_default_7 = primals_84 = None
        getitem_428 = convolution_backward_default_65[0]
        getitem_429 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_428, relu_default, primals_83, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_428 = primals_83 = None
        getitem_431 = convolution_backward_default_66[0]
        getitem_432 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_431, torch.float32);  getitem_431 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_71, to_dtype_93);  le_scalar_31 = new_zeros_default_71 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_413, to_dtype_95);  getitem_413 = to_dtype_95 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_10, convolution_default_6, primals_82, primals_80, primals_81, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  convolution_default_6 = primals_82 = primals_80 = primals_81 = getitem_15 = getitem_16 = None
        getitem_434 = native_batch_norm_backward_default_35[0]
        getitem_435 = native_batch_norm_backward_default_35[1]
        getitem_436 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_434, relu__default_1, primals_77, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_434 = primals_77 = None
        getitem_437 = convolution_backward_default_67[0]
        getitem_438 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_10, getitem_9, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_13);  add_tensor_10 = getitem_9 = getitem_13 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(max_pool2d_with_indices_backward_default_3, convolution_default_5, primals_76, primals_74, primals_75, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  max_pool2d_with_indices_backward_default_3 = convolution_default_5 = primals_76 = primals_74 = primals_75 = getitem_10 = getitem_11 = None
        getitem_440 = native_batch_norm_backward_default_36[0]
        getitem_441 = native_batch_norm_backward_default_36[1]
        getitem_442 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_440, convolution_default_4, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_440 = convolution_default_4 = primals_71 = None
        getitem_443 = convolution_backward_default_68[0]
        getitem_444 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_443, relu__default_2, primals_70, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_443 = primals_70 = None
        getitem_446 = convolution_backward_default_69[0]
        getitem_447 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_446, torch.float32);  getitem_446 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_72, to_dtype_96);  le_scalar_32 = new_zeros_default_72 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_3, primals_69, primals_67, primals_68, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_3 = primals_69 = primals_67 = primals_68 = getitem_7 = getitem_8 = None
        getitem_449 = native_batch_norm_backward_default_37[0]
        getitem_450 = native_batch_norm_backward_default_37[1]
        getitem_451 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_449, convolution_default_2, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_449 = convolution_default_2 = primals_64 = None
        getitem_452 = convolution_backward_default_70[0]
        getitem_453 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_452, relu__default_1, primals_63, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 64, [True, True, False]);  getitem_452 = primals_63 = None
        getitem_455 = convolution_backward_default_71[0]
        getitem_456 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_437, getitem_455);  getitem_437 = getitem_455 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_11, torch.float32);  add_tensor_11 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_73, to_dtype_99);  le_scalar_33 = new_zeros_default_73 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_1, primals_258, primals_256, primals_257, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_1 = primals_258 = primals_256 = primals_257 = getitem_4 = getitem_5 = None
        getitem_458 = native_batch_norm_backward_default_38[0]
        getitem_459 = native_batch_norm_backward_default_38[1]
        getitem_460 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_458, relu__default, primals_270, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_458 = primals_270 = None
        getitem_461 = convolution_backward_default_72[0]
        getitem_462 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_461, torch.float32);  getitem_461 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_74, to_dtype_102);  le_scalar_34 = new_zeros_default_74 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default, primals_253, primals_251, primals_252, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default = primals_253 = primals_251 = primals_252 = getitem_1 = getitem_2 = None
        getitem_464 = native_batch_norm_backward_default_39[0]
        getitem_465 = native_batch_norm_backward_default_39[1]
        getitem_466 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_464, primals_277, primals_269, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_464 = primals_277 = primals_269 = None
        getitem_468 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        return [getitem_222, getitem_219, getitem_217, None, None, None, getitem_216, getitem_213, getitem_210, getitem_208, None, None, None, getitem_207, getitem_204, getitem_201, getitem_199, None, None, None, getitem_198, getitem_195, getitem_192, getitem_190, None, None, None, getitem_189, getitem_186, getitem_183, getitem_181, None, None, None, getitem_180, getitem_177, getitem_174, getitem_172, None, None, None, getitem_171, getitem_168, getitem_165, getitem_163, None, None, None, getitem_162, getitem_159, getitem_156, getitem_154, None, None, None, getitem_153, getitem_150, getitem_148, None, None, None, getitem_147, getitem_456, getitem_453, getitem_451, None, None, None, getitem_450, getitem_447, getitem_444, getitem_442, None, None, None, getitem_441, getitem_438, getitem_436, None, None, None, getitem_435, getitem_432, getitem_429, getitem_427, None, None, None, getitem_426, getitem_423, getitem_420, getitem_418, None, None, None, getitem_417, getitem_414, getitem_412, None, None, None, getitem_411, getitem_408, getitem_405, getitem_403, None, None, None, getitem_402, getitem_399, getitem_396, getitem_394, None, None, None, getitem_393, getitem_390, getitem_388, None, None, None, getitem_387, getitem_384, getitem_381, getitem_379, None, None, None, getitem_378, getitem_375, getitem_372, getitem_370, None, None, None, getitem_369, getitem_366, getitem_363, getitem_361, None, None, None, getitem_360, getitem_357, getitem_354, getitem_352, None, None, None, getitem_351, getitem_348, getitem_345, getitem_343, None, None, None, getitem_342, getitem_339, getitem_336, getitem_334, None, None, None, getitem_333, getitem_330, getitem_327, getitem_325, None, None, None, getitem_324, getitem_321, getitem_318, getitem_316, None, None, None, getitem_315, getitem_312, getitem_309, getitem_307, None, None, None, getitem_306, getitem_303, getitem_300, getitem_298, None, None, None, getitem_297, getitem_294, getitem_291, getitem_289, None, None, None, getitem_288, getitem_285, getitem_282, getitem_280, None, None, None, getitem_279, getitem_276, getitem_273, getitem_271, None, None, None, getitem_270, getitem_267, getitem_264, getitem_262, None, None, None, getitem_261, getitem_258, getitem_255, getitem_253, None, None, None, getitem_252, getitem_249, getitem_246, getitem_244, None, None, None, getitem_243, getitem_240, getitem_237, getitem_235, None, None, None, getitem_234, getitem_231, getitem_228, getitem_226, None, None, None, getitem_225, getitem_466, None, None, None, getitem_465, getitem_460, None, None, None, getitem_459, getitem_139, None, None, None, getitem_138, getitem_130, None, None, None, getitem_129, getitem_468, getitem_462, getitem_144, getitem_141, getitem_135, getitem_132, view_default_1, t_default_4, None]
        
