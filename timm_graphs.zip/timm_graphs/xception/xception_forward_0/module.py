
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/xception/xception_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277):
        convolution_default = torch.ops.aten.convolution.default(primals_277, primals_269, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_253, primals_249, primals_251, primals_252, True, 0.1, 1e-05);  primals_249 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_270, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_258, primals_254, primals_256, primals_257, True, 0.1, 1e-05);  primals_254 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_63, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        convolution_default_3 = torch.ops.aten.convolution.default(convolution_default_2, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_69, primals_65, primals_67, primals_68, True, 0.1, 1e-05);  primals_65 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_2, primals_70, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        convolution_default_5 = torch.ops.aten.convolution.default(convolution_default_4, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_76, primals_72, primals_74, primals_75, True, 0.1, 1e-05);  primals_72 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(getitem_9, [3, 3], [2, 2], [1, 1])
        getitem_12 = max_pool2d_with_indices_default[0]
        getitem_13 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_1, primals_77, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_82, primals_78, primals_80, primals_81, True, 0.1, 1e-05);  primals_78 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        add__tensor_5 = torch.ops.aten.add_.Tensor(getitem_12, getitem_14);  getitem_12 = getitem_14 = None
        relu_default = torch.ops.aten.relu.default(add__tensor_5)
        convolution_default_7 = torch.ops.aten.convolution.default(relu_default, primals_83, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        convolution_default_8 = torch.ops.aten.convolution.default(convolution_default_7, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_89, primals_85, primals_87, primals_88, True, 0.1, 1e-05);  primals_85 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_3, primals_90, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 256)
        convolution_default_10 = torch.ops.aten.convolution.default(convolution_default_9, primals_91, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_96, primals_92, primals_94, primals_95, True, 0.1, 1e-05);  primals_92 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(getitem_20, [3, 3], [2, 2], [1, 1])
        getitem_23 = max_pool2d_with_indices_default_1[0]
        getitem_24 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_11 = torch.ops.aten.convolution.default(add__tensor_5, primals_97, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_102, primals_98, primals_100, primals_101, True, 0.1, 1e-05);  primals_98 = None
        getitem_25 = native_batch_norm_default_7[0]
        getitem_26 = native_batch_norm_default_7[1]
        getitem_27 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        add__tensor_9 = torch.ops.aten.add_.Tensor(getitem_23, getitem_25);  getitem_23 = getitem_25 = None
        relu_default_1 = torch.ops.aten.relu.default(add__tensor_9)
        convolution_default_12 = torch.ops.aten.convolution.default(relu_default_1, primals_103, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 256)
        convolution_default_13 = torch.ops.aten.convolution.default(convolution_default_12, primals_104, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_109, primals_105, primals_107, primals_108, True, 0.1, 1e-05);  primals_105 = None
        getitem_28 = native_batch_norm_default_8[0]
        getitem_29 = native_batch_norm_default_8[1]
        getitem_30 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_28);  getitem_28 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_4, primals_110, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_15 = torch.ops.aten.convolution.default(convolution_default_14, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_116, primals_112, primals_114, primals_115, True, 0.1, 1e-05);  primals_112 = None
        getitem_31 = native_batch_norm_default_9[0]
        getitem_32 = native_batch_norm_default_9[1]
        getitem_33 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(getitem_31, [3, 3], [2, 2], [1, 1])
        getitem_34 = max_pool2d_with_indices_default_2[0]
        getitem_35 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        convolution_default_16 = torch.ops.aten.convolution.default(add__tensor_9, primals_117, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_122, primals_118, primals_120, primals_121, True, 0.1, 1e-05);  primals_118 = None
        getitem_36 = native_batch_norm_default_10[0]
        getitem_37 = native_batch_norm_default_10[1]
        getitem_38 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_34, getitem_36);  getitem_34 = getitem_36 = None
        relu_default_2 = torch.ops.aten.relu.default(add__tensor_13)
        convolution_default_17 = torch.ops.aten.convolution.default(relu_default_2, primals_123, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_18 = torch.ops.aten.convolution.default(convolution_default_17, primals_124, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_129, primals_125, primals_127, primals_128, True, 0.1, 1e-05);  primals_125 = None
        getitem_39 = native_batch_norm_default_11[0]
        getitem_40 = native_batch_norm_default_11[1]
        getitem_41 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_5, primals_130, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_20 = torch.ops.aten.convolution.default(convolution_default_19, primals_131, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_136, primals_132, primals_134, primals_135, True, 0.1, 1e-05);  primals_132 = None
        getitem_42 = native_batch_norm_default_12[0]
        getitem_43 = native_batch_norm_default_12[1]
        getitem_44 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_42);  getitem_42 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_6, primals_137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_22 = torch.ops.aten.convolution.default(convolution_default_21, primals_138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_143, primals_139, primals_141, primals_142, True, 0.1, 1e-05);  primals_139 = None
        getitem_45 = native_batch_norm_default_13[0]
        getitem_46 = native_batch_norm_default_13[1]
        getitem_47 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        add__tensor_17 = torch.ops.aten.add_.Tensor(getitem_45, add__tensor_13);  getitem_45 = add__tensor_13 = None
        relu_default_3 = torch.ops.aten.relu.default(add__tensor_17)
        convolution_default_23 = torch.ops.aten.convolution.default(relu_default_3, primals_144, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_24 = torch.ops.aten.convolution.default(convolution_default_23, primals_145, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_150, primals_146, primals_148, primals_149, True, 0.1, 1e-05);  primals_146 = None
        getitem_48 = native_batch_norm_default_14[0]
        getitem_49 = native_batch_norm_default_14[1]
        getitem_50 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_7, primals_151, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_26 = torch.ops.aten.convolution.default(convolution_default_25, primals_152, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_157, primals_153, primals_155, primals_156, True, 0.1, 1e-05);  primals_153 = None
        getitem_51 = native_batch_norm_default_15[0]
        getitem_52 = native_batch_norm_default_15[1]
        getitem_53 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_51);  getitem_51 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_8, primals_158, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_28 = torch.ops.aten.convolution.default(convolution_default_27, primals_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_164, primals_160, primals_162, primals_163, True, 0.1, 1e-05);  primals_160 = None
        getitem_54 = native_batch_norm_default_16[0]
        getitem_55 = native_batch_norm_default_16[1]
        getitem_56 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        add__tensor_21 = torch.ops.aten.add_.Tensor(getitem_54, add__tensor_17);  getitem_54 = add__tensor_17 = None
        relu_default_4 = torch.ops.aten.relu.default(add__tensor_21)
        convolution_default_29 = torch.ops.aten.convolution.default(relu_default_4, primals_165, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_30 = torch.ops.aten.convolution.default(convolution_default_29, primals_166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_171, primals_167, primals_169, primals_170, True, 0.1, 1e-05);  primals_167 = None
        getitem_57 = native_batch_norm_default_17[0]
        getitem_58 = native_batch_norm_default_17[1]
        getitem_59 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_9, primals_172, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_32 = torch.ops.aten.convolution.default(convolution_default_31, primals_173, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_178, primals_174, primals_176, primals_177, True, 0.1, 1e-05);  primals_174 = None
        getitem_60 = native_batch_norm_default_18[0]
        getitem_61 = native_batch_norm_default_18[1]
        getitem_62 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_10, primals_179, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_34 = torch.ops.aten.convolution.default(convolution_default_33, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_185, primals_181, primals_183, primals_184, True, 0.1, 1e-05);  primals_181 = None
        getitem_63 = native_batch_norm_default_19[0]
        getitem_64 = native_batch_norm_default_19[1]
        getitem_65 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        add__tensor_25 = torch.ops.aten.add_.Tensor(getitem_63, add__tensor_21);  getitem_63 = add__tensor_21 = None
        relu_default_5 = torch.ops.aten.relu.default(add__tensor_25)
        convolution_default_35 = torch.ops.aten.convolution.default(relu_default_5, primals_186, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_36 = torch.ops.aten.convolution.default(convolution_default_35, primals_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_192, primals_188, primals_190, primals_191, True, 0.1, 1e-05);  primals_188 = None
        getitem_66 = native_batch_norm_default_20[0]
        getitem_67 = native_batch_norm_default_20[1]
        getitem_68 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_11, primals_193, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_38 = torch.ops.aten.convolution.default(convolution_default_37, primals_194, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_199, primals_195, primals_197, primals_198, True, 0.1, 1e-05);  primals_195 = None
        getitem_69 = native_batch_norm_default_21[0]
        getitem_70 = native_batch_norm_default_21[1]
        getitem_71 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_12, primals_200, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_40 = torch.ops.aten.convolution.default(convolution_default_39, primals_201, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_206, primals_202, primals_204, primals_205, True, 0.1, 1e-05);  primals_202 = None
        getitem_72 = native_batch_norm_default_22[0]
        getitem_73 = native_batch_norm_default_22[1]
        getitem_74 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        add__tensor_29 = torch.ops.aten.add_.Tensor(getitem_72, add__tensor_25);  getitem_72 = add__tensor_25 = None
        relu_default_6 = torch.ops.aten.relu.default(add__tensor_29)
        convolution_default_41 = torch.ops.aten.convolution.default(relu_default_6, primals_207, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_42 = torch.ops.aten.convolution.default(convolution_default_41, primals_208, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_213, primals_209, primals_211, primals_212, True, 0.1, 1e-05);  primals_209 = None
        getitem_75 = native_batch_norm_default_23[0]
        getitem_76 = native_batch_norm_default_23[1]
        getitem_77 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_13, primals_214, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_44 = torch.ops.aten.convolution.default(convolution_default_43, primals_215, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_220, primals_216, primals_218, primals_219, True, 0.1, 1e-05);  primals_216 = None
        getitem_78 = native_batch_norm_default_24[0]
        getitem_79 = native_batch_norm_default_24[1]
        getitem_80 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_14, primals_221, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_46 = torch.ops.aten.convolution.default(convolution_default_45, primals_222, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_227, primals_223, primals_225, primals_226, True, 0.1, 1e-05);  primals_223 = None
        getitem_81 = native_batch_norm_default_25[0]
        getitem_82 = native_batch_norm_default_25[1]
        getitem_83 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        add__tensor_33 = torch.ops.aten.add_.Tensor(getitem_81, add__tensor_29);  getitem_81 = add__tensor_29 = None
        relu_default_7 = torch.ops.aten.relu.default(add__tensor_33)
        convolution_default_47 = torch.ops.aten.convolution.default(relu_default_7, primals_228, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_48 = torch.ops.aten.convolution.default(convolution_default_47, primals_229, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_234, primals_230, primals_232, primals_233, True, 0.1, 1e-05);  primals_230 = None
        getitem_84 = native_batch_norm_default_26[0]
        getitem_85 = native_batch_norm_default_26[1]
        getitem_86 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_84);  getitem_84 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_15, primals_235, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_50 = torch.ops.aten.convolution.default(convolution_default_49, primals_236, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_241, primals_237, primals_239, primals_240, True, 0.1, 1e-05);  primals_237 = None
        getitem_87 = native_batch_norm_default_27[0]
        getitem_88 = native_batch_norm_default_27[1]
        getitem_89 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_16, primals_242, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_52 = torch.ops.aten.convolution.default(convolution_default_51, primals_243, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_248, primals_244, primals_246, primals_247, True, 0.1, 1e-05);  primals_244 = None
        getitem_90 = native_batch_norm_default_28[0]
        getitem_91 = native_batch_norm_default_28[1]
        getitem_92 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        add__tensor_37 = torch.ops.aten.add_.Tensor(getitem_90, add__tensor_33);  getitem_90 = add__tensor_33 = None
        relu_default_8 = torch.ops.aten.relu.default(add__tensor_37)
        convolution_default_53 = torch.ops.aten.convolution.default(relu_default_8, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_54 = torch.ops.aten.convolution.default(convolution_default_53, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_7, primals_3, primals_5, primals_6, True, 0.1, 1e-05);  primals_3 = None
        getitem_93 = native_batch_norm_default_29[0]
        getitem_94 = native_batch_norm_default_29[1]
        getitem_95 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_17, primals_8, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_56 = torch.ops.aten.convolution.default(convolution_default_55, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_14, primals_10, primals_12, primals_13, True, 0.1, 1e-05);  primals_10 = None
        getitem_96 = native_batch_norm_default_30[0]
        getitem_97 = native_batch_norm_default_30[1]
        getitem_98 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_18, primals_15, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_58 = torch.ops.aten.convolution.default(convolution_default_57, primals_16, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_21, primals_17, primals_19, primals_20, True, 0.1, 1e-05);  primals_17 = None
        getitem_99 = native_batch_norm_default_31[0]
        getitem_100 = native_batch_norm_default_31[1]
        getitem_101 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        add__tensor_41 = torch.ops.aten.add_.Tensor(getitem_99, add__tensor_37);  getitem_99 = add__tensor_37 = None
        relu_default_9 = torch.ops.aten.relu.default(add__tensor_41)
        convolution_default_59 = torch.ops.aten.convolution.default(relu_default_9, primals_22, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_60 = torch.ops.aten.convolution.default(convolution_default_59, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_28, primals_24, primals_26, primals_27, True, 0.1, 1e-05);  primals_24 = None
        getitem_102 = native_batch_norm_default_32[0]
        getitem_103 = native_batch_norm_default_32[1]
        getitem_104 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_19, primals_29, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_62 = torch.ops.aten.convolution.default(convolution_default_61, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_35, primals_31, primals_33, primals_34, True, 0.1, 1e-05);  primals_31 = None
        getitem_105 = native_batch_norm_default_33[0]
        getitem_106 = native_batch_norm_default_33[1]
        getitem_107 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_20, primals_36, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_64 = torch.ops.aten.convolution.default(convolution_default_63, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_42, primals_38, primals_40, primals_41, True, 0.1, 1e-05);  primals_38 = None
        getitem_108 = native_batch_norm_default_34[0]
        getitem_109 = native_batch_norm_default_34[1]
        getitem_110 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        add__tensor_45 = torch.ops.aten.add_.Tensor(getitem_108, add__tensor_41);  getitem_108 = add__tensor_41 = None
        relu_default_10 = torch.ops.aten.relu.default(add__tensor_45)
        convolution_default_65 = torch.ops.aten.convolution.default(relu_default_10, primals_43, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_66 = torch.ops.aten.convolution.default(convolution_default_65, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_49, primals_45, primals_47, primals_48, True, 0.1, 1e-05);  primals_45 = None
        getitem_111 = native_batch_norm_default_35[0]
        getitem_112 = native_batch_norm_default_35[1]
        getitem_113 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_21, primals_50, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        convolution_default_68 = torch.ops.aten.convolution.default(convolution_default_67, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_56, primals_52, primals_54, primals_55, True, 0.1, 1e-05);  primals_52 = None
        getitem_114 = native_batch_norm_default_36[0]
        getitem_115 = native_batch_norm_default_36[1]
        getitem_116 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(getitem_114, [3, 3], [2, 2], [1, 1])
        getitem_117 = max_pool2d_with_indices_default_3[0]
        getitem_118 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        convolution_default_69 = torch.ops.aten.convolution.default(add__tensor_45, primals_57, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_62, primals_58, primals_60, primals_61, True, 0.1, 1e-05);  primals_58 = None
        getitem_119 = native_batch_norm_default_37[0]
        getitem_120 = native_batch_norm_default_37[1]
        getitem_121 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        add__tensor_49 = torch.ops.aten.add_.Tensor(getitem_117, getitem_119);  getitem_117 = getitem_119 = None
        convolution_default_70 = torch.ops.aten.convolution.default(add__tensor_49, primals_271, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1024)
        convolution_default_71 = torch.ops.aten.convolution.default(convolution_default_70, primals_272, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_263, primals_259, primals_261, primals_262, True, 0.1, 1e-05);  primals_259 = None
        getitem_122 = native_batch_norm_default_38[0]
        getitem_123 = native_batch_norm_default_38[1]
        getitem_124 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_22, primals_273, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1536)
        convolution_default_73 = torch.ops.aten.convolution.default(convolution_default_72, primals_274, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_268, primals_264, primals_266, primals_267, True, 0.1, 1e-05);  primals_264 = None
        getitem_125 = native_batch_norm_default_39[0]
        getitem_126 = native_batch_norm_default_39[1]
        getitem_127 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_23, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_276);  primals_276 = None
        addmm_default = torch.ops.aten.addmm.default(primals_275, view_default, t_default);  primals_275 = None
        return [addmm_default, convolution_default_22, primals_261, primals_262, getitem_44, primals_263, getitem_43, primals_70, primals_64, primals_67, primals_266, relu__default_6, primals_267, primals_268, primals_269, convolution_default_21, primals_270, primals_68, primals_62, relu_default_6, primals_271, getitem_47, primals_272, primals_60, relu_default_3, primals_63, primals_273, getitem_46, primals_274, primals_277, primals_69, convolution_default_23, convolution_default_24, primals_61, primals_16, primals_21, primals_198, primals_19, relu__default_16, convolution_default_5, getitem_121, primals_199, getitem_7, getitem_22, primals_152, getitem_21, primals_200, relu__default_2, getitem_120, primals_151, getitem_20, primals_201, convolution_default_4, primals_150, getitem_8, primals_149, getitem_92, getitem_124, relu_default_1, primals_148, primals_204, convolution_default_11, getitem_91, primals_205, getitem_123, primals_145, primals_206, primals_144, relu__default_22, primals_207, getitem_11, primals_12, getitem_24, primals_9, primals_208, convolution_default_52, primals_143, getitem_27, convolution_default_71, getitem_26, primals_8, primals_142, getitem_10, getitem_9, primals_13, primals_141, convolution_default_72, primals_211, convolution_default_53, primals_20, primals_15, primals_212, primals_213, primals_138, primals_7, primals_214, convolution_default_54, convolution_default_73, primals_14, primals_137, primals_215, getitem_13, convolution_default_12, primals_136, convolution_default_6, convolution_default_13, primals_23, getitem_94, getitem_126, primals_135, add__tensor_5, primals_218, primals_22, primals_155, getitem_95, getitem_127, convolution_default_14, getitem_50, convolution_default_1, getitem_107, relu__default_17, getitem_30, getitem_29, convolution_default_55, getitem_2, convolution_default_56, relu__default_20, getitem_49, getitem_1, convolution_default_63, convolution_default_64, relu__default_7, relu__default_4, getitem_98, relu__default, getitem_110, getitem_97, convolution_default_26, convolution_default_15, getitem_109, relu__default_18, getitem_33, convolution_default_25, getitem_5, getitem_53, getitem_4, getitem_32, getitem_31, convolution_default_28, getitem_52, convolution_default_57, relu__default_1, relu__default_8, convolution_default_65, convolution_default_2, convolution_default_16, convolution_default_58, relu_default_9, getitem_35, convolution_default_66, convolution_default_27, getitem_100, convolution_default_3, primals_240, primals_162, primals_241, primals_158, primals_242, primals_243, getitem_80, primals_163, primals_164, primals_91, relu_default_7, primals_176, getitem_79, primals_246, primals_159, primals_165, primals_247, relu__default_14, primals_166, primals_248, convolution_default_44, primals_156, convolution_default_45, primals_251, primals_252, primals_169, primals_253, primals_170, primals_171, getitem_82, primals_172, convolution_default_46, primals_256, primals_257, primals_173, relu_default_4, primals_258, getitem_83, convolution_default, primals_157, primals_177, primals_178, relu__default_23, primals_94, primals_179, primals_127, primals_180, view_default, primals_122, primals_123, primals_134, primals_183, primals_131, primals_184, t_default, primals_185, primals_186, primals_100, primals_97, primals_187, primals_190, primals_191, primals_124, primals_192, primals_193, primals_128, primals_194, primals_130, primals_120, primals_121, primals_129, primals_96, primals_95, primals_197, relu_default_2, getitem_101, primals_84, getitem_112, primals_89, getitem_56, convolution_default_36, getitem_38, getitem_113, getitem_37, relu_default_10, primals_51, getitem_55, getitem_68, relu__default_21, primals_43, convolution_default_38, convolution_default_60, convolution_default_59, convolution_default_68, primals_54, convolution_default_67, primals_75, primals_74, getitem_67, getitem_118, getitem_104, convolution_default_18, convolution_default_17, primals_83, relu__default_11, getitem_116, convolution_default_30, getitem_103, primals_76, convolution_default_29, getitem_41, convolution_default_37, getitem_115, getitem_114, relu__default_19, primals_90, primals_40, convolution_default_70, getitem_40, convolution_default_32, primals_47, primals_80, primals_49, relu__default_5, getitem_59, primals_82, getitem_58, convolution_default_61, primals_41, getitem_71, primals_50, getitem_70, primals_88, relu__default_9, primals_44, convolution_default_62, primals_71, convolution_default_19, primals_81, add__tensor_49, primals_42, primals_87, convolution_default_69, primals_56, convolution_default_39, relu__default_12, add__tensor_45, convolution_default_31, primals_55, convolution_default_20, primals_48, primals_77, getitem_106, primals_57, primals_116, primals_219, primals_117, primals_220, primals_221, primals_222, primals_5, primals_102, primals_103, primals_225, primals_104, primals_226, primals_227, primals_228, primals_107, primals_108, primals_6, primals_229, primals_109, primals_110, primals_115, primals_232, primals_101, primals_233, primals_2, primals_234, primals_1, primals_235, primals_111, primals_114, primals_236, primals_239, getitem_16, convolution_default_34, getitem_15, convolution_default_48, convolution_default_47, getitem_62, getitem_74, getitem_86, getitem_88, getitem_61, getitem_73, primals_29, convolution_default_8, convolution_default_7, relu__default_10, getitem_85, primals_28, relu_default, convolution_default_40, relu__default_15, convolution_default_33, getitem_19, add__tensor_9, convolution_default_41, primals_27, getitem_18, primals_37, convolution_default_49, relu__default_3, primals_36, relu_default_8, primals_34, getitem_65, relu_default_5, getitem_64, convolution_default_42, convolution_default_51, convolution_default_50, primals_26, convolution_default_9, convolution_default_43, primals_33, getitem_77, convolution_default_10, primals_35, getitem_76, getitem_89, primals_30, relu__default_13, convolution_default_35]
        
