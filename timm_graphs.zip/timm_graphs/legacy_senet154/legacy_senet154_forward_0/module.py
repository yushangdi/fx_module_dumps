
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/legacy_senet154/legacy_senet154_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, primals_1024, primals_1025, primals_1026, primals_1027, primals_1028, primals_1029, primals_1030, primals_1031, primals_1032, primals_1033, primals_1034, primals_1035, primals_1036, primals_1037, primals_1038, primals_1039, primals_1040, primals_1041, primals_1042, primals_1043, primals_1044, primals_1045, primals_1046, primals_1047, primals_1048, primals_1049, primals_1050, primals_1051, primals_1052, primals_1053, primals_1054, primals_1055, primals_1056, primals_1057, primals_1058, primals_1059, primals_1060, primals_1061, primals_1062, primals_1063, primals_1064, primals_1065, primals_1066, primals_1067, primals_1068, primals_1069, primals_1070, primals_1071, primals_1072, primals_1073, primals_1074, primals_1075, primals_1076, primals_1077, primals_1078, primals_1079, primals_1080, primals_1081, primals_1082, primals_1083, primals_1084, primals_1085, primals_1086, primals_1087, primals_1088, primals_1089, primals_1090, primals_1091, primals_1092, primals_1093, primals_1094, primals_1095, primals_1096, primals_1097, primals_1098, primals_1099, primals_1100, primals_1101, primals_1102, primals_1103, primals_1104, primals_1105, primals_1106, primals_1107, primals_1108, primals_1109, primals_1110, primals_1111, primals_1112, primals_1113, primals_1114, primals_1115, primals_1116, primals_1117, primals_1118, primals_1119, primals_1120, primals_1121, primals_1122, primals_1123, primals_1124, primals_1125, primals_1126, primals_1127, primals_1128, primals_1129, primals_1130, primals_1131, primals_1132, primals_1133, primals_1134, primals_1135, primals_1136, primals_1137, primals_1138, primals_1139, primals_1140, primals_1141, primals_1142, primals_1143, primals_1144, primals_1145):
        convolution_default = torch.ops.aten.convolution.default(primals_1145, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_8, primals_4, primals_6, primals_7, True, 0.1, 1e-05);  primals_4 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_9, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_14, primals_10, primals_12, primals_13, True, 0.1, 1e-05);  primals_10 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_15, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_20, primals_16, primals_18, primals_19, True, 0.1, 1e-05);  primals_16 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_25, primals_21, primals_23, primals_24, True, 0.1, 1e-05);  primals_21 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_30, primals_26, primals_28, primals_29, True, 0.1, 1e-05);  primals_26 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_35, primals_31, primals_33, primals_34, True, 0.1, 1e-05);  primals_31 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_9, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        mean_dim = torch.ops.aten.mean.dim(getitem_17, [2, 3], True)
        convolution_default_7 = torch.ops.aten.convolution.default(mean_dim, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_7);  convolution_default_7 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_8);  convolution_default_8 = None
        mul_tensor = torch.ops.aten.mul.Tensor(getitem_17, sigmoid_default)
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor, getitem_20);  mul_tensor = getitem_20 = None
        relu__default_6 = torch.ops.aten.relu_.default(add_tensor);  add_tensor = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_53, primals_49, primals_51, primals_52, True, 0.1, 1e-05);  primals_49 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_7, primals_65, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_58, primals_54, primals_56, primals_57, True, 0.1, 1e-05);  primals_54 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_8, primals_66, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_63, primals_59, primals_61, primals_62, True, 0.1, 1e-05);  primals_59 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        mean_dim_1 = torch.ops.aten.mean.dim(getitem_29, [2, 3], True)
        convolution_default_12 = torch.ops.aten.convolution.default(mean_dim_1, primals_68, primals_67, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_67 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_12);  convolution_default_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_9, primals_70, primals_69, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_69 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_13);  convolution_default_13 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(getitem_29, sigmoid_default_1)
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_1, relu__default_6);  mul_tensor_1 = None
        relu__default_10 = torch.ops.aten.relu_.default(add_tensor_1);  add_tensor_1 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_10, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_75, primals_71, primals_73, primals_74, True, 0.1, 1e-05);  primals_71 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_11, primals_87, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_80, primals_76, primals_78, primals_79, True, 0.1, 1e-05);  primals_76 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_12, primals_88, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        mean_dim_2 = torch.ops.aten.mean.dim(getitem_38, [2, 3], True)
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_2, primals_90, primals_89, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_89 = None
        relu__default_13 = torch.ops.aten.relu_.default(convolution_default_17);  convolution_default_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_13, primals_92, primals_91, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_91 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_18);  convolution_default_18 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(getitem_38, sigmoid_default_2)
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_2, relu__default_10);  mul_tensor_2 = None
        relu__default_14 = torch.ops.aten.relu_.default(add_tensor_2);  add_tensor_2 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_14, primals_108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_97, primals_93, primals_95, primals_96, True, 0.1, 1e-05);  primals_93 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_15, primals_109, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_102, primals_98, primals_100, primals_101, True, 0.1, 1e-05);  primals_98 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_16, primals_110, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_107, primals_103, primals_105, primals_106, True, 0.1, 1e-05);  primals_103 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_14, primals_111, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_116, primals_112, primals_114, primals_115, True, 0.1, 1e-05);  primals_112 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        mean_dim_3 = torch.ops.aten.mean.dim(getitem_47, [2, 3], True)
        convolution_default_23 = torch.ops.aten.convolution.default(mean_dim_3, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        relu__default_17 = torch.ops.aten.relu_.default(convolution_default_23);  convolution_default_23 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_17, primals_120, primals_119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_119 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_24);  convolution_default_24 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(getitem_47, sigmoid_default_3)
        add_tensor_3 = torch.ops.aten.add.Tensor(mul_tensor_3, getitem_50);  mul_tensor_3 = getitem_50 = None
        relu__default_18 = torch.ops.aten.relu_.default(add_tensor_3);  add_tensor_3 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_18, primals_136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_125, primals_121, primals_123, primals_124, True, 0.1, 1e-05);  primals_121 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_19, primals_137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_130, primals_126, primals_128, primals_129, True, 0.1, 1e-05);  primals_126 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_20, primals_138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_135, primals_131, primals_133, primals_134, True, 0.1, 1e-05);  primals_131 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        mean_dim_4 = torch.ops.aten.mean.dim(getitem_59, [2, 3], True)
        convolution_default_28 = torch.ops.aten.convolution.default(mean_dim_4, primals_140, primals_139, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_139 = None
        relu__default_21 = torch.ops.aten.relu_.default(convolution_default_28);  convolution_default_28 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_21, primals_142, primals_141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_141 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_29);  convolution_default_29 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(getitem_59, sigmoid_default_4)
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_4, relu__default_18);  mul_tensor_4 = None
        relu__default_22 = torch.ops.aten.relu_.default(add_tensor_4);  add_tensor_4 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_22, primals_158, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_147, primals_143, primals_145, primals_146, True, 0.1, 1e-05);  primals_143 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_62);  getitem_62 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_23, primals_159, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_152, primals_148, primals_150, primals_151, True, 0.1, 1e-05);  primals_148 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_24, primals_160, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_157, primals_153, primals_155, primals_156, True, 0.1, 1e-05);  primals_153 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        mean_dim_5 = torch.ops.aten.mean.dim(getitem_68, [2, 3], True)
        convolution_default_33 = torch.ops.aten.convolution.default(mean_dim_5, primals_162, primals_161, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_161 = None
        relu__default_25 = torch.ops.aten.relu_.default(convolution_default_33);  convolution_default_33 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_25, primals_164, primals_163, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_163 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_34);  convolution_default_34 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(getitem_68, sigmoid_default_5)
        add_tensor_5 = torch.ops.aten.add.Tensor(mul_tensor_5, relu__default_22);  mul_tensor_5 = None
        relu__default_26 = torch.ops.aten.relu_.default(add_tensor_5);  add_tensor_5 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_26, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_169, primals_165, primals_167, primals_168, True, 0.1, 1e-05);  primals_165 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_71);  getitem_71 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_27, primals_181, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_174, primals_170, primals_172, primals_173, True, 0.1, 1e-05);  primals_170 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_28, primals_182, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_179, primals_175, primals_177, primals_178, True, 0.1, 1e-05);  primals_175 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        mean_dim_6 = torch.ops.aten.mean.dim(getitem_77, [2, 3], True)
        convolution_default_38 = torch.ops.aten.convolution.default(mean_dim_6, primals_184, primals_183, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_183 = None
        relu__default_29 = torch.ops.aten.relu_.default(convolution_default_38);  convolution_default_38 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_29, primals_186, primals_185, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_185 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_39);  convolution_default_39 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(getitem_77, sigmoid_default_6)
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_6, relu__default_26);  mul_tensor_6 = None
        relu__default_30 = torch.ops.aten.relu_.default(add_tensor_6);  add_tensor_6 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_30, primals_202, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_191, primals_187, primals_189, primals_190, True, 0.1, 1e-05);  primals_187 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_80);  getitem_80 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_31, primals_203, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_196, primals_192, primals_194, primals_195, True, 0.1, 1e-05);  primals_192 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_32, primals_204, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_201, primals_197, primals_199, primals_200, True, 0.1, 1e-05);  primals_197 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        mean_dim_7 = torch.ops.aten.mean.dim(getitem_86, [2, 3], True)
        convolution_default_43 = torch.ops.aten.convolution.default(mean_dim_7, primals_206, primals_205, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_205 = None
        relu__default_33 = torch.ops.aten.relu_.default(convolution_default_43);  convolution_default_43 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_33, primals_208, primals_207, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_207 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_44);  convolution_default_44 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(getitem_86, sigmoid_default_7)
        add_tensor_7 = torch.ops.aten.add.Tensor(mul_tensor_7, relu__default_30);  mul_tensor_7 = None
        relu__default_34 = torch.ops.aten.relu_.default(add_tensor_7);  add_tensor_7 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_34, primals_224, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_213, primals_209, primals_211, primals_212, True, 0.1, 1e-05);  primals_209 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_35, primals_225, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_218, primals_214, primals_216, primals_217, True, 0.1, 1e-05);  primals_214 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_92);  getitem_92 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_36, primals_226, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_223, primals_219, primals_221, primals_222, True, 0.1, 1e-05);  primals_219 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        mean_dim_8 = torch.ops.aten.mean.dim(getitem_95, [2, 3], True)
        convolution_default_48 = torch.ops.aten.convolution.default(mean_dim_8, primals_228, primals_227, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_227 = None
        relu__default_37 = torch.ops.aten.relu_.default(convolution_default_48);  convolution_default_48 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_37, primals_230, primals_229, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_229 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_49);  convolution_default_49 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(getitem_95, sigmoid_default_8)
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_8, relu__default_34);  mul_tensor_8 = None
        relu__default_38 = torch.ops.aten.relu_.default(add_tensor_8);  add_tensor_8 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_38, primals_246, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_235, primals_231, primals_233, primals_234, True, 0.1, 1e-05);  primals_231 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_39, primals_247, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_240, primals_236, primals_238, primals_239, True, 0.1, 1e-05);  primals_236 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_101);  getitem_101 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_40, primals_248, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_245, primals_241, primals_243, primals_244, True, 0.1, 1e-05);  primals_241 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        mean_dim_9 = torch.ops.aten.mean.dim(getitem_104, [2, 3], True)
        convolution_default_53 = torch.ops.aten.convolution.default(mean_dim_9, primals_250, primals_249, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_249 = None
        relu__default_41 = torch.ops.aten.relu_.default(convolution_default_53);  convolution_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_41, primals_252, primals_251, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_251 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_54);  convolution_default_54 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(getitem_104, sigmoid_default_9)
        add_tensor_9 = torch.ops.aten.add.Tensor(mul_tensor_9, relu__default_38);  mul_tensor_9 = None
        relu__default_42 = torch.ops.aten.relu_.default(add_tensor_9);  add_tensor_9 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_42, primals_268, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_257, primals_253, primals_255, primals_256, True, 0.1, 1e-05);  primals_253 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_43, primals_269, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_262, primals_258, primals_260, primals_261, True, 0.1, 1e-05);  primals_258 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_110);  getitem_110 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_44, primals_270, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_267, primals_263, primals_265, primals_266, True, 0.1, 1e-05);  primals_263 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        mean_dim_10 = torch.ops.aten.mean.dim(getitem_113, [2, 3], True)
        convolution_default_58 = torch.ops.aten.convolution.default(mean_dim_10, primals_272, primals_271, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_271 = None
        relu__default_45 = torch.ops.aten.relu_.default(convolution_default_58);  convolution_default_58 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_45, primals_274, primals_273, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_273 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_59);  convolution_default_59 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(getitem_113, sigmoid_default_10)
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_10, relu__default_42);  mul_tensor_10 = None
        relu__default_46 = torch.ops.aten.relu_.default(add_tensor_10);  add_tensor_10 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_46, primals_290, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_279, primals_275, primals_277, primals_278, True, 0.1, 1e-05);  primals_275 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_47, primals_291, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_284, primals_280, primals_282, primals_283, True, 0.1, 1e-05);  primals_280 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_48, primals_292, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_289, primals_285, primals_287, primals_288, True, 0.1, 1e-05);  primals_285 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_46, primals_293, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_298, primals_294, primals_296, primals_297, True, 0.1, 1e-05);  primals_294 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        mean_dim_11 = torch.ops.aten.mean.dim(getitem_122, [2, 3], True)
        convolution_default_64 = torch.ops.aten.convolution.default(mean_dim_11, primals_300, primals_299, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_299 = None
        relu__default_49 = torch.ops.aten.relu_.default(convolution_default_64);  convolution_default_64 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_49, primals_302, primals_301, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_301 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_65);  convolution_default_65 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(getitem_122, sigmoid_default_11)
        add_tensor_11 = torch.ops.aten.add.Tensor(mul_tensor_11, getitem_125);  mul_tensor_11 = getitem_125 = None
        relu__default_50 = torch.ops.aten.relu_.default(add_tensor_11);  add_tensor_11 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_50, primals_538, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_527, primals_523, primals_525, primals_526, True, 0.1, 1e-05);  primals_523 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_128);  getitem_128 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_51, primals_539, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_532, primals_528, primals_530, primals_531, True, 0.1, 1e-05);  primals_528 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_52, primals_540, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_537, primals_533, primals_535, primals_536, True, 0.1, 1e-05);  primals_533 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        mean_dim_12 = torch.ops.aten.mean.dim(getitem_134, [2, 3], True)
        convolution_default_69 = torch.ops.aten.convolution.default(mean_dim_12, primals_542, primals_541, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_541 = None
        relu__default_53 = torch.ops.aten.relu_.default(convolution_default_69);  convolution_default_69 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_53, primals_544, primals_543, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_543 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_70);  convolution_default_70 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(getitem_134, sigmoid_default_12)
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_12, relu__default_50);  mul_tensor_12 = None
        relu__default_54 = torch.ops.aten.relu_.default(add_tensor_12);  add_tensor_12 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_54, primals_780, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_769, primals_765, primals_767, primals_768, True, 0.1, 1e-05);  primals_765 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_137);  getitem_137 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_55, primals_781, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_774, primals_770, primals_772, primals_773, True, 0.1, 1e-05);  primals_770 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_56, primals_782, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_779, primals_775, primals_777, primals_778, True, 0.1, 1e-05);  primals_775 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        mean_dim_13 = torch.ops.aten.mean.dim(getitem_143, [2, 3], True)
        convolution_default_74 = torch.ops.aten.convolution.default(mean_dim_13, primals_784, primals_783, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_783 = None
        relu__default_57 = torch.ops.aten.relu_.default(convolution_default_74);  convolution_default_74 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_57, primals_786, primals_785, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_785 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_75);  convolution_default_75 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(getitem_143, sigmoid_default_13)
        add_tensor_13 = torch.ops.aten.add.Tensor(mul_tensor_13, relu__default_54);  mul_tensor_13 = None
        relu__default_58 = torch.ops.aten.relu_.default(add_tensor_13);  add_tensor_13 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_58, primals_934, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_923, primals_919, primals_921, primals_922, True, 0.1, 1e-05);  primals_919 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_59, primals_935, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_928, primals_924, primals_926, primals_927, True, 0.1, 1e-05);  primals_924 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_149);  getitem_149 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_60, primals_936, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_933, primals_929, primals_931, primals_932, True, 0.1, 1e-05);  primals_929 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        mean_dim_14 = torch.ops.aten.mean.dim(getitem_152, [2, 3], True)
        convolution_default_79 = torch.ops.aten.convolution.default(mean_dim_14, primals_938, primals_937, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_937 = None
        relu__default_61 = torch.ops.aten.relu_.default(convolution_default_79);  convolution_default_79 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_61, primals_940, primals_939, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_939 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_80);  convolution_default_80 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(getitem_152, sigmoid_default_14)
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_14, relu__default_58);  mul_tensor_14 = None
        relu__default_62 = torch.ops.aten.relu_.default(add_tensor_14);  add_tensor_14 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_62, primals_956, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_945, primals_941, primals_943, primals_944, True, 0.1, 1e-05);  primals_941 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_155);  getitem_155 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_63, primals_957, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_950, primals_946, primals_948, primals_949, True, 0.1, 1e-05);  primals_946 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_64, primals_958, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_955, primals_951, primals_953, primals_954, True, 0.1, 1e-05);  primals_951 = None
        getitem_161 = native_batch_norm_default_53[0]
        getitem_162 = native_batch_norm_default_53[1]
        getitem_163 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        mean_dim_15 = torch.ops.aten.mean.dim(getitem_161, [2, 3], True)
        convolution_default_84 = torch.ops.aten.convolution.default(mean_dim_15, primals_960, primals_959, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_959 = None
        relu__default_65 = torch.ops.aten.relu_.default(convolution_default_84);  convolution_default_84 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_65, primals_962, primals_961, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_961 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_85);  convolution_default_85 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(getitem_161, sigmoid_default_15)
        add_tensor_15 = torch.ops.aten.add.Tensor(mul_tensor_15, relu__default_62);  mul_tensor_15 = None
        relu__default_66 = torch.ops.aten.relu_.default(add_tensor_15);  add_tensor_15 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_66, primals_978, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_967, primals_963, primals_965, primals_966, True, 0.1, 1e-05);  primals_963 = None
        getitem_164 = native_batch_norm_default_54[0]
        getitem_165 = native_batch_norm_default_54[1]
        getitem_166 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_67, primals_979, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_972, primals_968, primals_970, primals_971, True, 0.1, 1e-05);  primals_968 = None
        getitem_167 = native_batch_norm_default_55[0]
        getitem_168 = native_batch_norm_default_55[1]
        getitem_169 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_68, primals_980, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_977, primals_973, primals_975, primals_976, True, 0.1, 1e-05);  primals_973 = None
        getitem_170 = native_batch_norm_default_56[0]
        getitem_171 = native_batch_norm_default_56[1]
        getitem_172 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        mean_dim_16 = torch.ops.aten.mean.dim(getitem_170, [2, 3], True)
        convolution_default_89 = torch.ops.aten.convolution.default(mean_dim_16, primals_982, primals_981, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_981 = None
        relu__default_69 = torch.ops.aten.relu_.default(convolution_default_89);  convolution_default_89 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_69, primals_984, primals_983, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_983 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(convolution_default_90);  convolution_default_90 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(getitem_170, sigmoid_default_16)
        add_tensor_16 = torch.ops.aten.add.Tensor(mul_tensor_16, relu__default_66);  mul_tensor_16 = None
        relu__default_70 = torch.ops.aten.relu_.default(add_tensor_16);  add_tensor_16 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_70, primals_1000, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_989, primals_985, primals_987, primals_988, True, 0.1, 1e-05);  primals_985 = None
        getitem_173 = native_batch_norm_default_57[0]
        getitem_174 = native_batch_norm_default_57[1]
        getitem_175 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_173);  getitem_173 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_71, primals_1001, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_994, primals_990, primals_992, primals_993, True, 0.1, 1e-05);  primals_990 = None
        getitem_176 = native_batch_norm_default_58[0]
        getitem_177 = native_batch_norm_default_58[1]
        getitem_178 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_72, primals_1002, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_999, primals_995, primals_997, primals_998, True, 0.1, 1e-05);  primals_995 = None
        getitem_179 = native_batch_norm_default_59[0]
        getitem_180 = native_batch_norm_default_59[1]
        getitem_181 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        mean_dim_17 = torch.ops.aten.mean.dim(getitem_179, [2, 3], True)
        convolution_default_94 = torch.ops.aten.convolution.default(mean_dim_17, primals_1004, primals_1003, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1003 = None
        relu__default_73 = torch.ops.aten.relu_.default(convolution_default_94);  convolution_default_94 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_73, primals_1006, primals_1005, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1005 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_95);  convolution_default_95 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(getitem_179, sigmoid_default_17)
        add_tensor_17 = torch.ops.aten.add.Tensor(mul_tensor_17, relu__default_70);  mul_tensor_17 = None
        relu__default_74 = torch.ops.aten.relu_.default(add_tensor_17);  add_tensor_17 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_74, primals_1022, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_1011, primals_1007, primals_1009, primals_1010, True, 0.1, 1e-05);  primals_1007 = None
        getitem_182 = native_batch_norm_default_60[0]
        getitem_183 = native_batch_norm_default_60[1]
        getitem_184 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_75, primals_1023, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_1016, primals_1012, primals_1014, primals_1015, True, 0.1, 1e-05);  primals_1012 = None
        getitem_185 = native_batch_norm_default_61[0]
        getitem_186 = native_batch_norm_default_61[1]
        getitem_187 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_76, primals_1024, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_1021, primals_1017, primals_1019, primals_1020, True, 0.1, 1e-05);  primals_1017 = None
        getitem_188 = native_batch_norm_default_62[0]
        getitem_189 = native_batch_norm_default_62[1]
        getitem_190 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        mean_dim_18 = torch.ops.aten.mean.dim(getitem_188, [2, 3], True)
        convolution_default_99 = torch.ops.aten.convolution.default(mean_dim_18, primals_1026, primals_1025, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1025 = None
        relu__default_77 = torch.ops.aten.relu_.default(convolution_default_99);  convolution_default_99 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_77, primals_1028, primals_1027, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1027 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(convolution_default_100);  convolution_default_100 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(getitem_188, sigmoid_default_18)
        add_tensor_18 = torch.ops.aten.add.Tensor(mul_tensor_18, relu__default_74);  mul_tensor_18 = None
        relu__default_78 = torch.ops.aten.relu_.default(add_tensor_18);  add_tensor_18 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_78, primals_1044, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_1033, primals_1029, primals_1031, primals_1032, True, 0.1, 1e-05);  primals_1029 = None
        getitem_191 = native_batch_norm_default_63[0]
        getitem_192 = native_batch_norm_default_63[1]
        getitem_193 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_191);  getitem_191 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_79, primals_1045, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_1038, primals_1034, primals_1036, primals_1037, True, 0.1, 1e-05);  primals_1034 = None
        getitem_194 = native_batch_norm_default_64[0]
        getitem_195 = native_batch_norm_default_64[1]
        getitem_196 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_80, primals_1046, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_1043, primals_1039, primals_1041, primals_1042, True, 0.1, 1e-05);  primals_1039 = None
        getitem_197 = native_batch_norm_default_65[0]
        getitem_198 = native_batch_norm_default_65[1]
        getitem_199 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        mean_dim_19 = torch.ops.aten.mean.dim(getitem_197, [2, 3], True)
        convolution_default_104 = torch.ops.aten.convolution.default(mean_dim_19, primals_1048, primals_1047, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1047 = None
        relu__default_81 = torch.ops.aten.relu_.default(convolution_default_104);  convolution_default_104 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_81, primals_1050, primals_1049, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1049 = None
        sigmoid_default_19 = torch.ops.aten.sigmoid.default(convolution_default_105);  convolution_default_105 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(getitem_197, sigmoid_default_19)
        add_tensor_19 = torch.ops.aten.add.Tensor(mul_tensor_19, relu__default_78);  mul_tensor_19 = None
        relu__default_82 = torch.ops.aten.relu_.default(add_tensor_19);  add_tensor_19 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_82, primals_1066, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_1055, primals_1051, primals_1053, primals_1054, True, 0.1, 1e-05);  primals_1051 = None
        getitem_200 = native_batch_norm_default_66[0]
        getitem_201 = native_batch_norm_default_66[1]
        getitem_202 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu__default_83, primals_1067, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_1060, primals_1056, primals_1058, primals_1059, True, 0.1, 1e-05);  primals_1056 = None
        getitem_203 = native_batch_norm_default_67[0]
        getitem_204 = native_batch_norm_default_67[1]
        getitem_205 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_84, primals_1068, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_1065, primals_1061, primals_1063, primals_1064, True, 0.1, 1e-05);  primals_1061 = None
        getitem_206 = native_batch_norm_default_68[0]
        getitem_207 = native_batch_norm_default_68[1]
        getitem_208 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        mean_dim_20 = torch.ops.aten.mean.dim(getitem_206, [2, 3], True)
        convolution_default_109 = torch.ops.aten.convolution.default(mean_dim_20, primals_1070, primals_1069, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1069 = None
        relu__default_85 = torch.ops.aten.relu_.default(convolution_default_109);  convolution_default_109 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_85, primals_1072, primals_1071, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1071 = None
        sigmoid_default_20 = torch.ops.aten.sigmoid.default(convolution_default_110);  convolution_default_110 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(getitem_206, sigmoid_default_20)
        add_tensor_20 = torch.ops.aten.add.Tensor(mul_tensor_20, relu__default_82);  mul_tensor_20 = None
        relu__default_86 = torch.ops.aten.relu_.default(add_tensor_20);  add_tensor_20 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_86, primals_318, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_307, primals_303, primals_305, primals_306, True, 0.1, 1e-05);  primals_303 = None
        getitem_209 = native_batch_norm_default_69[0]
        getitem_210 = native_batch_norm_default_69[1]
        getitem_211 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_209);  getitem_209 = None
        convolution_default_112 = torch.ops.aten.convolution.default(relu__default_87, primals_319, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_312, primals_308, primals_310, primals_311, True, 0.1, 1e-05);  primals_308 = None
        getitem_212 = native_batch_norm_default_70[0]
        getitem_213 = native_batch_norm_default_70[1]
        getitem_214 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu__default_88, primals_320, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_317, primals_313, primals_315, primals_316, True, 0.1, 1e-05);  primals_313 = None
        getitem_215 = native_batch_norm_default_71[0]
        getitem_216 = native_batch_norm_default_71[1]
        getitem_217 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        mean_dim_21 = torch.ops.aten.mean.dim(getitem_215, [2, 3], True)
        convolution_default_114 = torch.ops.aten.convolution.default(mean_dim_21, primals_322, primals_321, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_321 = None
        relu__default_89 = torch.ops.aten.relu_.default(convolution_default_114);  convolution_default_114 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_89, primals_324, primals_323, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_323 = None
        sigmoid_default_21 = torch.ops.aten.sigmoid.default(convolution_default_115);  convolution_default_115 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(getitem_215, sigmoid_default_21)
        add_tensor_21 = torch.ops.aten.add.Tensor(mul_tensor_21, relu__default_86);  mul_tensor_21 = None
        relu__default_90 = torch.ops.aten.relu_.default(add_tensor_21);  add_tensor_21 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_90, primals_340, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_329, primals_325, primals_327, primals_328, True, 0.1, 1e-05);  primals_325 = None
        getitem_218 = native_batch_norm_default_72[0]
        getitem_219 = native_batch_norm_default_72[1]
        getitem_220 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_91, primals_341, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_334, primals_330, primals_332, primals_333, True, 0.1, 1e-05);  primals_330 = None
        getitem_221 = native_batch_norm_default_73[0]
        getitem_222 = native_batch_norm_default_73[1]
        getitem_223 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_221);  getitem_221 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_92, primals_342, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_339, primals_335, primals_337, primals_338, True, 0.1, 1e-05);  primals_335 = None
        getitem_224 = native_batch_norm_default_74[0]
        getitem_225 = native_batch_norm_default_74[1]
        getitem_226 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        mean_dim_22 = torch.ops.aten.mean.dim(getitem_224, [2, 3], True)
        convolution_default_119 = torch.ops.aten.convolution.default(mean_dim_22, primals_344, primals_343, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_343 = None
        relu__default_93 = torch.ops.aten.relu_.default(convolution_default_119);  convolution_default_119 = None
        convolution_default_120 = torch.ops.aten.convolution.default(relu__default_93, primals_346, primals_345, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_345 = None
        sigmoid_default_22 = torch.ops.aten.sigmoid.default(convolution_default_120);  convolution_default_120 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(getitem_224, sigmoid_default_22)
        add_tensor_22 = torch.ops.aten.add.Tensor(mul_tensor_22, relu__default_90);  mul_tensor_22 = None
        relu__default_94 = torch.ops.aten.relu_.default(add_tensor_22);  add_tensor_22 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_94, primals_362, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_351, primals_347, primals_349, primals_350, True, 0.1, 1e-05);  primals_347 = None
        getitem_227 = native_batch_norm_default_75[0]
        getitem_228 = native_batch_norm_default_75[1]
        getitem_229 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_227);  getitem_227 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_95, primals_363, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_356, primals_352, primals_354, primals_355, True, 0.1, 1e-05);  primals_352 = None
        getitem_230 = native_batch_norm_default_76[0]
        getitem_231 = native_batch_norm_default_76[1]
        getitem_232 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_123 = torch.ops.aten.convolution.default(relu__default_96, primals_364, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_361, primals_357, primals_359, primals_360, True, 0.1, 1e-05);  primals_357 = None
        getitem_233 = native_batch_norm_default_77[0]
        getitem_234 = native_batch_norm_default_77[1]
        getitem_235 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        mean_dim_23 = torch.ops.aten.mean.dim(getitem_233, [2, 3], True)
        convolution_default_124 = torch.ops.aten.convolution.default(mean_dim_23, primals_366, primals_365, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_365 = None
        relu__default_97 = torch.ops.aten.relu_.default(convolution_default_124);  convolution_default_124 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu__default_97, primals_368, primals_367, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_367 = None
        sigmoid_default_23 = torch.ops.aten.sigmoid.default(convolution_default_125);  convolution_default_125 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(getitem_233, sigmoid_default_23)
        add_tensor_23 = torch.ops.aten.add.Tensor(mul_tensor_23, relu__default_94);  mul_tensor_23 = None
        relu__default_98 = torch.ops.aten.relu_.default(add_tensor_23);  add_tensor_23 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_98, primals_384, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_373, primals_369, primals_371, primals_372, True, 0.1, 1e-05);  primals_369 = None
        getitem_236 = native_batch_norm_default_78[0]
        getitem_237 = native_batch_norm_default_78[1]
        getitem_238 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_127 = torch.ops.aten.convolution.default(relu__default_99, primals_385, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_378, primals_374, primals_376, primals_377, True, 0.1, 1e-05);  primals_374 = None
        getitem_239 = native_batch_norm_default_79[0]
        getitem_240 = native_batch_norm_default_79[1]
        getitem_241 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_100 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_100, primals_386, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_383, primals_379, primals_381, primals_382, True, 0.1, 1e-05);  primals_379 = None
        getitem_242 = native_batch_norm_default_80[0]
        getitem_243 = native_batch_norm_default_80[1]
        getitem_244 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        mean_dim_24 = torch.ops.aten.mean.dim(getitem_242, [2, 3], True)
        convolution_default_129 = torch.ops.aten.convolution.default(mean_dim_24, primals_388, primals_387, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_387 = None
        relu__default_101 = torch.ops.aten.relu_.default(convolution_default_129);  convolution_default_129 = None
        convolution_default_130 = torch.ops.aten.convolution.default(relu__default_101, primals_390, primals_389, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_389 = None
        sigmoid_default_24 = torch.ops.aten.sigmoid.default(convolution_default_130);  convolution_default_130 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(getitem_242, sigmoid_default_24)
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_24, relu__default_98);  mul_tensor_24 = None
        relu__default_102 = torch.ops.aten.relu_.default(add_tensor_24);  add_tensor_24 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_102, primals_406, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_395, primals_391, primals_393, primals_394, True, 0.1, 1e-05);  primals_391 = None
        getitem_245 = native_batch_norm_default_81[0]
        getitem_246 = native_batch_norm_default_81[1]
        getitem_247 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu__default_103 = torch.ops.aten.relu_.default(getitem_245);  getitem_245 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu__default_103, primals_407, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_400, primals_396, primals_398, primals_399, True, 0.1, 1e-05);  primals_396 = None
        getitem_248 = native_batch_norm_default_82[0]
        getitem_249 = native_batch_norm_default_82[1]
        getitem_250 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_104 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu__default_104, primals_408, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_405, primals_401, primals_403, primals_404, True, 0.1, 1e-05);  primals_401 = None
        getitem_251 = native_batch_norm_default_83[0]
        getitem_252 = native_batch_norm_default_83[1]
        getitem_253 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        mean_dim_25 = torch.ops.aten.mean.dim(getitem_251, [2, 3], True)
        convolution_default_134 = torch.ops.aten.convolution.default(mean_dim_25, primals_410, primals_409, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_409 = None
        relu__default_105 = torch.ops.aten.relu_.default(convolution_default_134);  convolution_default_134 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu__default_105, primals_412, primals_411, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_411 = None
        sigmoid_default_25 = torch.ops.aten.sigmoid.default(convolution_default_135);  convolution_default_135 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(getitem_251, sigmoid_default_25)
        add_tensor_25 = torch.ops.aten.add.Tensor(mul_tensor_25, relu__default_102);  mul_tensor_25 = None
        relu__default_106 = torch.ops.aten.relu_.default(add_tensor_25);  add_tensor_25 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_106, primals_428, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_417, primals_413, primals_415, primals_416, True, 0.1, 1e-05);  primals_413 = None
        getitem_254 = native_batch_norm_default_84[0]
        getitem_255 = native_batch_norm_default_84[1]
        getitem_256 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu__default_107 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        convolution_default_137 = torch.ops.aten.convolution.default(relu__default_107, primals_429, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_422, primals_418, primals_420, primals_421, True, 0.1, 1e-05);  primals_418 = None
        getitem_257 = native_batch_norm_default_85[0]
        getitem_258 = native_batch_norm_default_85[1]
        getitem_259 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu__default_108 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        convolution_default_138 = torch.ops.aten.convolution.default(relu__default_108, primals_430, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_427, primals_423, primals_425, primals_426, True, 0.1, 1e-05);  primals_423 = None
        getitem_260 = native_batch_norm_default_86[0]
        getitem_261 = native_batch_norm_default_86[1]
        getitem_262 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        mean_dim_26 = torch.ops.aten.mean.dim(getitem_260, [2, 3], True)
        convolution_default_139 = torch.ops.aten.convolution.default(mean_dim_26, primals_432, primals_431, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_431 = None
        relu__default_109 = torch.ops.aten.relu_.default(convolution_default_139);  convolution_default_139 = None
        convolution_default_140 = torch.ops.aten.convolution.default(relu__default_109, primals_434, primals_433, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_433 = None
        sigmoid_default_26 = torch.ops.aten.sigmoid.default(convolution_default_140);  convolution_default_140 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(getitem_260, sigmoid_default_26)
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_26, relu__default_106);  mul_tensor_26 = None
        relu__default_110 = torch.ops.aten.relu_.default(add_tensor_26);  add_tensor_26 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_110, primals_450, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_439, primals_435, primals_437, primals_438, True, 0.1, 1e-05);  primals_435 = None
        getitem_263 = native_batch_norm_default_87[0]
        getitem_264 = native_batch_norm_default_87[1]
        getitem_265 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu__default_111 = torch.ops.aten.relu_.default(getitem_263);  getitem_263 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu__default_111, primals_451, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_444, primals_440, primals_442, primals_443, True, 0.1, 1e-05);  primals_440 = None
        getitem_266 = native_batch_norm_default_88[0]
        getitem_267 = native_batch_norm_default_88[1]
        getitem_268 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu__default_112 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu__default_112, primals_452, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_449, primals_445, primals_447, primals_448, True, 0.1, 1e-05);  primals_445 = None
        getitem_269 = native_batch_norm_default_89[0]
        getitem_270 = native_batch_norm_default_89[1]
        getitem_271 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        mean_dim_27 = torch.ops.aten.mean.dim(getitem_269, [2, 3], True)
        convolution_default_144 = torch.ops.aten.convolution.default(mean_dim_27, primals_454, primals_453, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_453 = None
        relu__default_113 = torch.ops.aten.relu_.default(convolution_default_144);  convolution_default_144 = None
        convolution_default_145 = torch.ops.aten.convolution.default(relu__default_113, primals_456, primals_455, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_455 = None
        sigmoid_default_27 = torch.ops.aten.sigmoid.default(convolution_default_145);  convolution_default_145 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(getitem_269, sigmoid_default_27)
        add_tensor_27 = torch.ops.aten.add.Tensor(mul_tensor_27, relu__default_110);  mul_tensor_27 = None
        relu__default_114 = torch.ops.aten.relu_.default(add_tensor_27);  add_tensor_27 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_114, primals_472, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_461, primals_457, primals_459, primals_460, True, 0.1, 1e-05);  primals_457 = None
        getitem_272 = native_batch_norm_default_90[0]
        getitem_273 = native_batch_norm_default_90[1]
        getitem_274 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu__default_115 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu__default_115, primals_473, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_466, primals_462, primals_464, primals_465, True, 0.1, 1e-05);  primals_462 = None
        getitem_275 = native_batch_norm_default_91[0]
        getitem_276 = native_batch_norm_default_91[1]
        getitem_277 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu__default_116 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_148 = torch.ops.aten.convolution.default(relu__default_116, primals_474, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_471, primals_467, primals_469, primals_470, True, 0.1, 1e-05);  primals_467 = None
        getitem_278 = native_batch_norm_default_92[0]
        getitem_279 = native_batch_norm_default_92[1]
        getitem_280 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        mean_dim_28 = torch.ops.aten.mean.dim(getitem_278, [2, 3], True)
        convolution_default_149 = torch.ops.aten.convolution.default(mean_dim_28, primals_476, primals_475, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_475 = None
        relu__default_117 = torch.ops.aten.relu_.default(convolution_default_149);  convolution_default_149 = None
        convolution_default_150 = torch.ops.aten.convolution.default(relu__default_117, primals_478, primals_477, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_477 = None
        sigmoid_default_28 = torch.ops.aten.sigmoid.default(convolution_default_150);  convolution_default_150 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(getitem_278, sigmoid_default_28)
        add_tensor_28 = torch.ops.aten.add.Tensor(mul_tensor_28, relu__default_114);  mul_tensor_28 = None
        relu__default_118 = torch.ops.aten.relu_.default(add_tensor_28);  add_tensor_28 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu__default_118, primals_494, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_483, primals_479, primals_481, primals_482, True, 0.1, 1e-05);  primals_479 = None
        getitem_281 = native_batch_norm_default_93[0]
        getitem_282 = native_batch_norm_default_93[1]
        getitem_283 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        relu__default_119 = torch.ops.aten.relu_.default(getitem_281);  getitem_281 = None
        convolution_default_152 = torch.ops.aten.convolution.default(relu__default_119, primals_495, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_488, primals_484, primals_486, primals_487, True, 0.1, 1e-05);  primals_484 = None
        getitem_284 = native_batch_norm_default_94[0]
        getitem_285 = native_batch_norm_default_94[1]
        getitem_286 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu__default_120 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_153 = torch.ops.aten.convolution.default(relu__default_120, primals_496, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_493, primals_489, primals_491, primals_492, True, 0.1, 1e-05);  primals_489 = None
        getitem_287 = native_batch_norm_default_95[0]
        getitem_288 = native_batch_norm_default_95[1]
        getitem_289 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        mean_dim_29 = torch.ops.aten.mean.dim(getitem_287, [2, 3], True)
        convolution_default_154 = torch.ops.aten.convolution.default(mean_dim_29, primals_498, primals_497, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_497 = None
        relu__default_121 = torch.ops.aten.relu_.default(convolution_default_154);  convolution_default_154 = None
        convolution_default_155 = torch.ops.aten.convolution.default(relu__default_121, primals_500, primals_499, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_499 = None
        sigmoid_default_29 = torch.ops.aten.sigmoid.default(convolution_default_155);  convolution_default_155 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(getitem_287, sigmoid_default_29)
        add_tensor_29 = torch.ops.aten.add.Tensor(mul_tensor_29, relu__default_118);  mul_tensor_29 = None
        relu__default_122 = torch.ops.aten.relu_.default(add_tensor_29);  add_tensor_29 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu__default_122, primals_516, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_505, primals_501, primals_503, primals_504, True, 0.1, 1e-05);  primals_501 = None
        getitem_290 = native_batch_norm_default_96[0]
        getitem_291 = native_batch_norm_default_96[1]
        getitem_292 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        relu__default_123 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        convolution_default_157 = torch.ops.aten.convolution.default(relu__default_123, primals_517, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_510, primals_506, primals_508, primals_509, True, 0.1, 1e-05);  primals_506 = None
        getitem_293 = native_batch_norm_default_97[0]
        getitem_294 = native_batch_norm_default_97[1]
        getitem_295 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        relu__default_124 = torch.ops.aten.relu_.default(getitem_293);  getitem_293 = None
        convolution_default_158 = torch.ops.aten.convolution.default(relu__default_124, primals_518, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_515, primals_511, primals_513, primals_514, True, 0.1, 1e-05);  primals_511 = None
        getitem_296 = native_batch_norm_default_98[0]
        getitem_297 = native_batch_norm_default_98[1]
        getitem_298 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        mean_dim_30 = torch.ops.aten.mean.dim(getitem_296, [2, 3], True)
        convolution_default_159 = torch.ops.aten.convolution.default(mean_dim_30, primals_520, primals_519, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_519 = None
        relu__default_125 = torch.ops.aten.relu_.default(convolution_default_159);  convolution_default_159 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu__default_125, primals_522, primals_521, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_521 = None
        sigmoid_default_30 = torch.ops.aten.sigmoid.default(convolution_default_160);  convolution_default_160 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(getitem_296, sigmoid_default_30)
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_30, relu__default_122);  mul_tensor_30 = None
        relu__default_126 = torch.ops.aten.relu_.default(add_tensor_30);  add_tensor_30 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu__default_126, primals_560, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_549, primals_545, primals_547, primals_548, True, 0.1, 1e-05);  primals_545 = None
        getitem_299 = native_batch_norm_default_99[0]
        getitem_300 = native_batch_norm_default_99[1]
        getitem_301 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu__default_127 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        convolution_default_162 = torch.ops.aten.convolution.default(relu__default_127, primals_561, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_554, primals_550, primals_552, primals_553, True, 0.1, 1e-05);  primals_550 = None
        getitem_302 = native_batch_norm_default_100[0]
        getitem_303 = native_batch_norm_default_100[1]
        getitem_304 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu__default_128 = torch.ops.aten.relu_.default(getitem_302);  getitem_302 = None
        convolution_default_163 = torch.ops.aten.convolution.default(relu__default_128, primals_562, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_559, primals_555, primals_557, primals_558, True, 0.1, 1e-05);  primals_555 = None
        getitem_305 = native_batch_norm_default_101[0]
        getitem_306 = native_batch_norm_default_101[1]
        getitem_307 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        mean_dim_31 = torch.ops.aten.mean.dim(getitem_305, [2, 3], True)
        convolution_default_164 = torch.ops.aten.convolution.default(mean_dim_31, primals_564, primals_563, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_563 = None
        relu__default_129 = torch.ops.aten.relu_.default(convolution_default_164);  convolution_default_164 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_129, primals_566, primals_565, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_565 = None
        sigmoid_default_31 = torch.ops.aten.sigmoid.default(convolution_default_165);  convolution_default_165 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(getitem_305, sigmoid_default_31)
        add_tensor_31 = torch.ops.aten.add.Tensor(mul_tensor_31, relu__default_126);  mul_tensor_31 = None
        relu__default_130 = torch.ops.aten.relu_.default(add_tensor_31);  add_tensor_31 = None
        convolution_default_166 = torch.ops.aten.convolution.default(relu__default_130, primals_582, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_571, primals_567, primals_569, primals_570, True, 0.1, 1e-05);  primals_567 = None
        getitem_308 = native_batch_norm_default_102[0]
        getitem_309 = native_batch_norm_default_102[1]
        getitem_310 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_131 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_167 = torch.ops.aten.convolution.default(relu__default_131, primals_583, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_576, primals_572, primals_574, primals_575, True, 0.1, 1e-05);  primals_572 = None
        getitem_311 = native_batch_norm_default_103[0]
        getitem_312 = native_batch_norm_default_103[1]
        getitem_313 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        relu__default_132 = torch.ops.aten.relu_.default(getitem_311);  getitem_311 = None
        convolution_default_168 = torch.ops.aten.convolution.default(relu__default_132, primals_584, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_314 = native_batch_norm_default_104[0]
        getitem_315 = native_batch_norm_default_104[1]
        getitem_316 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        mean_dim_32 = torch.ops.aten.mean.dim(getitem_314, [2, 3], True)
        convolution_default_169 = torch.ops.aten.convolution.default(mean_dim_32, primals_586, primals_585, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_585 = None
        relu__default_133 = torch.ops.aten.relu_.default(convolution_default_169);  convolution_default_169 = None
        convolution_default_170 = torch.ops.aten.convolution.default(relu__default_133, primals_588, primals_587, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_587 = None
        sigmoid_default_32 = torch.ops.aten.sigmoid.default(convolution_default_170);  convolution_default_170 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(getitem_314, sigmoid_default_32)
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_32, relu__default_130);  mul_tensor_32 = None
        relu__default_134 = torch.ops.aten.relu_.default(add_tensor_32);  add_tensor_32 = None
        convolution_default_171 = torch.ops.aten.convolution.default(relu__default_134, primals_604, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_171, primals_593, primals_589, primals_591, primals_592, True, 0.1, 1e-05);  primals_589 = None
        getitem_317 = native_batch_norm_default_105[0]
        getitem_318 = native_batch_norm_default_105[1]
        getitem_319 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        relu__default_135 = torch.ops.aten.relu_.default(getitem_317);  getitem_317 = None
        convolution_default_172 = torch.ops.aten.convolution.default(relu__default_135, primals_605, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_172, primals_598, primals_594, primals_596, primals_597, True, 0.1, 1e-05);  primals_594 = None
        getitem_320 = native_batch_norm_default_106[0]
        getitem_321 = native_batch_norm_default_106[1]
        getitem_322 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu__default_136 = torch.ops.aten.relu_.default(getitem_320);  getitem_320 = None
        convolution_default_173 = torch.ops.aten.convolution.default(relu__default_136, primals_606, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_173, primals_603, primals_599, primals_601, primals_602, True, 0.1, 1e-05);  primals_599 = None
        getitem_323 = native_batch_norm_default_107[0]
        getitem_324 = native_batch_norm_default_107[1]
        getitem_325 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        mean_dim_33 = torch.ops.aten.mean.dim(getitem_323, [2, 3], True)
        convolution_default_174 = torch.ops.aten.convolution.default(mean_dim_33, primals_608, primals_607, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_607 = None
        relu__default_137 = torch.ops.aten.relu_.default(convolution_default_174);  convolution_default_174 = None
        convolution_default_175 = torch.ops.aten.convolution.default(relu__default_137, primals_610, primals_609, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_609 = None
        sigmoid_default_33 = torch.ops.aten.sigmoid.default(convolution_default_175);  convolution_default_175 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(getitem_323, sigmoid_default_33)
        add_tensor_33 = torch.ops.aten.add.Tensor(mul_tensor_33, relu__default_134);  mul_tensor_33 = None
        relu__default_138 = torch.ops.aten.relu_.default(add_tensor_33);  add_tensor_33 = None
        convolution_default_176 = torch.ops.aten.convolution.default(relu__default_138, primals_626, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_176, primals_615, primals_611, primals_613, primals_614, True, 0.1, 1e-05);  primals_611 = None
        getitem_326 = native_batch_norm_default_108[0]
        getitem_327 = native_batch_norm_default_108[1]
        getitem_328 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu__default_139 = torch.ops.aten.relu_.default(getitem_326);  getitem_326 = None
        convolution_default_177 = torch.ops.aten.convolution.default(relu__default_139, primals_627, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_177, primals_620, primals_616, primals_618, primals_619, True, 0.1, 1e-05);  primals_616 = None
        getitem_329 = native_batch_norm_default_109[0]
        getitem_330 = native_batch_norm_default_109[1]
        getitem_331 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        relu__default_140 = torch.ops.aten.relu_.default(getitem_329);  getitem_329 = None
        convolution_default_178 = torch.ops.aten.convolution.default(relu__default_140, primals_628, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_178, primals_625, primals_621, primals_623, primals_624, True, 0.1, 1e-05);  primals_621 = None
        getitem_332 = native_batch_norm_default_110[0]
        getitem_333 = native_batch_norm_default_110[1]
        getitem_334 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        mean_dim_34 = torch.ops.aten.mean.dim(getitem_332, [2, 3], True)
        convolution_default_179 = torch.ops.aten.convolution.default(mean_dim_34, primals_630, primals_629, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_629 = None
        relu__default_141 = torch.ops.aten.relu_.default(convolution_default_179);  convolution_default_179 = None
        convolution_default_180 = torch.ops.aten.convolution.default(relu__default_141, primals_632, primals_631, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_631 = None
        sigmoid_default_34 = torch.ops.aten.sigmoid.default(convolution_default_180);  convolution_default_180 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(getitem_332, sigmoid_default_34)
        add_tensor_34 = torch.ops.aten.add.Tensor(mul_tensor_34, relu__default_138);  mul_tensor_34 = None
        relu__default_142 = torch.ops.aten.relu_.default(add_tensor_34);  add_tensor_34 = None
        convolution_default_181 = torch.ops.aten.convolution.default(relu__default_142, primals_648, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_181, primals_637, primals_633, primals_635, primals_636, True, 0.1, 1e-05);  primals_633 = None
        getitem_335 = native_batch_norm_default_111[0]
        getitem_336 = native_batch_norm_default_111[1]
        getitem_337 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        relu__default_143 = torch.ops.aten.relu_.default(getitem_335);  getitem_335 = None
        convolution_default_182 = torch.ops.aten.convolution.default(relu__default_143, primals_649, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_182, primals_642, primals_638, primals_640, primals_641, True, 0.1, 1e-05);  primals_638 = None
        getitem_338 = native_batch_norm_default_112[0]
        getitem_339 = native_batch_norm_default_112[1]
        getitem_340 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        relu__default_144 = torch.ops.aten.relu_.default(getitem_338);  getitem_338 = None
        convolution_default_183 = torch.ops.aten.convolution.default(relu__default_144, primals_650, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_183, primals_647, primals_643, primals_645, primals_646, True, 0.1, 1e-05);  primals_643 = None
        getitem_341 = native_batch_norm_default_113[0]
        getitem_342 = native_batch_norm_default_113[1]
        getitem_343 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        mean_dim_35 = torch.ops.aten.mean.dim(getitem_341, [2, 3], True)
        convolution_default_184 = torch.ops.aten.convolution.default(mean_dim_35, primals_652, primals_651, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_651 = None
        relu__default_145 = torch.ops.aten.relu_.default(convolution_default_184);  convolution_default_184 = None
        convolution_default_185 = torch.ops.aten.convolution.default(relu__default_145, primals_654, primals_653, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_653 = None
        sigmoid_default_35 = torch.ops.aten.sigmoid.default(convolution_default_185);  convolution_default_185 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(getitem_341, sigmoid_default_35)
        add_tensor_35 = torch.ops.aten.add.Tensor(mul_tensor_35, relu__default_142);  mul_tensor_35 = None
        relu__default_146 = torch.ops.aten.relu_.default(add_tensor_35);  add_tensor_35 = None
        convolution_default_186 = torch.ops.aten.convolution.default(relu__default_146, primals_670, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_186, primals_659, primals_655, primals_657, primals_658, True, 0.1, 1e-05);  primals_655 = None
        getitem_344 = native_batch_norm_default_114[0]
        getitem_345 = native_batch_norm_default_114[1]
        getitem_346 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu__default_147 = torch.ops.aten.relu_.default(getitem_344);  getitem_344 = None
        convolution_default_187 = torch.ops.aten.convolution.default(relu__default_147, primals_671, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_664, primals_660, primals_662, primals_663, True, 0.1, 1e-05);  primals_660 = None
        getitem_347 = native_batch_norm_default_115[0]
        getitem_348 = native_batch_norm_default_115[1]
        getitem_349 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        relu__default_148 = torch.ops.aten.relu_.default(getitem_347);  getitem_347 = None
        convolution_default_188 = torch.ops.aten.convolution.default(relu__default_148, primals_672, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_188, primals_669, primals_665, primals_667, primals_668, True, 0.1, 1e-05);  primals_665 = None
        getitem_350 = native_batch_norm_default_116[0]
        getitem_351 = native_batch_norm_default_116[1]
        getitem_352 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        mean_dim_36 = torch.ops.aten.mean.dim(getitem_350, [2, 3], True)
        convolution_default_189 = torch.ops.aten.convolution.default(mean_dim_36, primals_674, primals_673, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_673 = None
        relu__default_149 = torch.ops.aten.relu_.default(convolution_default_189);  convolution_default_189 = None
        convolution_default_190 = torch.ops.aten.convolution.default(relu__default_149, primals_676, primals_675, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_675 = None
        sigmoid_default_36 = torch.ops.aten.sigmoid.default(convolution_default_190);  convolution_default_190 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(getitem_350, sigmoid_default_36)
        add_tensor_36 = torch.ops.aten.add.Tensor(mul_tensor_36, relu__default_146);  mul_tensor_36 = None
        relu__default_150 = torch.ops.aten.relu_.default(add_tensor_36);  add_tensor_36 = None
        convolution_default_191 = torch.ops.aten.convolution.default(relu__default_150, primals_692, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_191, primals_681, primals_677, primals_679, primals_680, True, 0.1, 1e-05);  primals_677 = None
        getitem_353 = native_batch_norm_default_117[0]
        getitem_354 = native_batch_norm_default_117[1]
        getitem_355 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        relu__default_151 = torch.ops.aten.relu_.default(getitem_353);  getitem_353 = None
        convolution_default_192 = torch.ops.aten.convolution.default(relu__default_151, primals_693, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_192, primals_686, primals_682, primals_684, primals_685, True, 0.1, 1e-05);  primals_682 = None
        getitem_356 = native_batch_norm_default_118[0]
        getitem_357 = native_batch_norm_default_118[1]
        getitem_358 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        relu__default_152 = torch.ops.aten.relu_.default(getitem_356);  getitem_356 = None
        convolution_default_193 = torch.ops.aten.convolution.default(relu__default_152, primals_694, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_193, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_359 = native_batch_norm_default_119[0]
        getitem_360 = native_batch_norm_default_119[1]
        getitem_361 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        mean_dim_37 = torch.ops.aten.mean.dim(getitem_359, [2, 3], True)
        convolution_default_194 = torch.ops.aten.convolution.default(mean_dim_37, primals_696, primals_695, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_695 = None
        relu__default_153 = torch.ops.aten.relu_.default(convolution_default_194);  convolution_default_194 = None
        convolution_default_195 = torch.ops.aten.convolution.default(relu__default_153, primals_698, primals_697, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_697 = None
        sigmoid_default_37 = torch.ops.aten.sigmoid.default(convolution_default_195);  convolution_default_195 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(getitem_359, sigmoid_default_37)
        add_tensor_37 = torch.ops.aten.add.Tensor(mul_tensor_37, relu__default_150);  mul_tensor_37 = None
        relu__default_154 = torch.ops.aten.relu_.default(add_tensor_37);  add_tensor_37 = None
        convolution_default_196 = torch.ops.aten.convolution.default(relu__default_154, primals_714, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_196, primals_703, primals_699, primals_701, primals_702, True, 0.1, 1e-05);  primals_699 = None
        getitem_362 = native_batch_norm_default_120[0]
        getitem_363 = native_batch_norm_default_120[1]
        getitem_364 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        relu__default_155 = torch.ops.aten.relu_.default(getitem_362);  getitem_362 = None
        convolution_default_197 = torch.ops.aten.convolution.default(relu__default_155, primals_715, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_197, primals_708, primals_704, primals_706, primals_707, True, 0.1, 1e-05);  primals_704 = None
        getitem_365 = native_batch_norm_default_121[0]
        getitem_366 = native_batch_norm_default_121[1]
        getitem_367 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        relu__default_156 = torch.ops.aten.relu_.default(getitem_365);  getitem_365 = None
        convolution_default_198 = torch.ops.aten.convolution.default(relu__default_156, primals_716, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_198, primals_713, primals_709, primals_711, primals_712, True, 0.1, 1e-05);  primals_709 = None
        getitem_368 = native_batch_norm_default_122[0]
        getitem_369 = native_batch_norm_default_122[1]
        getitem_370 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        mean_dim_38 = torch.ops.aten.mean.dim(getitem_368, [2, 3], True)
        convolution_default_199 = torch.ops.aten.convolution.default(mean_dim_38, primals_718, primals_717, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_717 = None
        relu__default_157 = torch.ops.aten.relu_.default(convolution_default_199);  convolution_default_199 = None
        convolution_default_200 = torch.ops.aten.convolution.default(relu__default_157, primals_720, primals_719, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_719 = None
        sigmoid_default_38 = torch.ops.aten.sigmoid.default(convolution_default_200);  convolution_default_200 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(getitem_368, sigmoid_default_38)
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_38, relu__default_154);  mul_tensor_38 = None
        relu__default_158 = torch.ops.aten.relu_.default(add_tensor_38);  add_tensor_38 = None
        convolution_default_201 = torch.ops.aten.convolution.default(relu__default_158, primals_736, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_201, primals_725, primals_721, primals_723, primals_724, True, 0.1, 1e-05);  primals_721 = None
        getitem_371 = native_batch_norm_default_123[0]
        getitem_372 = native_batch_norm_default_123[1]
        getitem_373 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        relu__default_159 = torch.ops.aten.relu_.default(getitem_371);  getitem_371 = None
        convolution_default_202 = torch.ops.aten.convolution.default(relu__default_159, primals_737, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_202, primals_730, primals_726, primals_728, primals_729, True, 0.1, 1e-05);  primals_726 = None
        getitem_374 = native_batch_norm_default_124[0]
        getitem_375 = native_batch_norm_default_124[1]
        getitem_376 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        relu__default_160 = torch.ops.aten.relu_.default(getitem_374);  getitem_374 = None
        convolution_default_203 = torch.ops.aten.convolution.default(relu__default_160, primals_738, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_203, primals_735, primals_731, primals_733, primals_734, True, 0.1, 1e-05);  primals_731 = None
        getitem_377 = native_batch_norm_default_125[0]
        getitem_378 = native_batch_norm_default_125[1]
        getitem_379 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        mean_dim_39 = torch.ops.aten.mean.dim(getitem_377, [2, 3], True)
        convolution_default_204 = torch.ops.aten.convolution.default(mean_dim_39, primals_740, primals_739, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_739 = None
        relu__default_161 = torch.ops.aten.relu_.default(convolution_default_204);  convolution_default_204 = None
        convolution_default_205 = torch.ops.aten.convolution.default(relu__default_161, primals_742, primals_741, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_741 = None
        sigmoid_default_39 = torch.ops.aten.sigmoid.default(convolution_default_205);  convolution_default_205 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(getitem_377, sigmoid_default_39)
        add_tensor_39 = torch.ops.aten.add.Tensor(mul_tensor_39, relu__default_158);  mul_tensor_39 = None
        relu__default_162 = torch.ops.aten.relu_.default(add_tensor_39);  add_tensor_39 = None
        convolution_default_206 = torch.ops.aten.convolution.default(relu__default_162, primals_758, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_206, primals_747, primals_743, primals_745, primals_746, True, 0.1, 1e-05);  primals_743 = None
        getitem_380 = native_batch_norm_default_126[0]
        getitem_381 = native_batch_norm_default_126[1]
        getitem_382 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        relu__default_163 = torch.ops.aten.relu_.default(getitem_380);  getitem_380 = None
        convolution_default_207 = torch.ops.aten.convolution.default(relu__default_163, primals_759, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_207, primals_752, primals_748, primals_750, primals_751, True, 0.1, 1e-05);  primals_748 = None
        getitem_383 = native_batch_norm_default_127[0]
        getitem_384 = native_batch_norm_default_127[1]
        getitem_385 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        relu__default_164 = torch.ops.aten.relu_.default(getitem_383);  getitem_383 = None
        convolution_default_208 = torch.ops.aten.convolution.default(relu__default_164, primals_760, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_208, primals_757, primals_753, primals_755, primals_756, True, 0.1, 1e-05);  primals_753 = None
        getitem_386 = native_batch_norm_default_128[0]
        getitem_387 = native_batch_norm_default_128[1]
        getitem_388 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        mean_dim_40 = torch.ops.aten.mean.dim(getitem_386, [2, 3], True)
        convolution_default_209 = torch.ops.aten.convolution.default(mean_dim_40, primals_762, primals_761, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_761 = None
        relu__default_165 = torch.ops.aten.relu_.default(convolution_default_209);  convolution_default_209 = None
        convolution_default_210 = torch.ops.aten.convolution.default(relu__default_165, primals_764, primals_763, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_763 = None
        sigmoid_default_40 = torch.ops.aten.sigmoid.default(convolution_default_210);  convolution_default_210 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(getitem_386, sigmoid_default_40)
        add_tensor_40 = torch.ops.aten.add.Tensor(mul_tensor_40, relu__default_162);  mul_tensor_40 = None
        relu__default_166 = torch.ops.aten.relu_.default(add_tensor_40);  add_tensor_40 = None
        convolution_default_211 = torch.ops.aten.convolution.default(relu__default_166, primals_802, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_211, primals_791, primals_787, primals_789, primals_790, True, 0.1, 1e-05);  primals_787 = None
        getitem_389 = native_batch_norm_default_129[0]
        getitem_390 = native_batch_norm_default_129[1]
        getitem_391 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        relu__default_167 = torch.ops.aten.relu_.default(getitem_389);  getitem_389 = None
        convolution_default_212 = torch.ops.aten.convolution.default(relu__default_167, primals_803, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_212, primals_796, primals_792, primals_794, primals_795, True, 0.1, 1e-05);  primals_792 = None
        getitem_392 = native_batch_norm_default_130[0]
        getitem_393 = native_batch_norm_default_130[1]
        getitem_394 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        relu__default_168 = torch.ops.aten.relu_.default(getitem_392);  getitem_392 = None
        convolution_default_213 = torch.ops.aten.convolution.default(relu__default_168, primals_804, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_213, primals_801, primals_797, primals_799, primals_800, True, 0.1, 1e-05);  primals_797 = None
        getitem_395 = native_batch_norm_default_131[0]
        getitem_396 = native_batch_norm_default_131[1]
        getitem_397 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        mean_dim_41 = torch.ops.aten.mean.dim(getitem_395, [2, 3], True)
        convolution_default_214 = torch.ops.aten.convolution.default(mean_dim_41, primals_806, primals_805, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_805 = None
        relu__default_169 = torch.ops.aten.relu_.default(convolution_default_214);  convolution_default_214 = None
        convolution_default_215 = torch.ops.aten.convolution.default(relu__default_169, primals_808, primals_807, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_807 = None
        sigmoid_default_41 = torch.ops.aten.sigmoid.default(convolution_default_215);  convolution_default_215 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(getitem_395, sigmoid_default_41)
        add_tensor_41 = torch.ops.aten.add.Tensor(mul_tensor_41, relu__default_166);  mul_tensor_41 = None
        relu__default_170 = torch.ops.aten.relu_.default(add_tensor_41);  add_tensor_41 = None
        convolution_default_216 = torch.ops.aten.convolution.default(relu__default_170, primals_824, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_216, primals_813, primals_809, primals_811, primals_812, True, 0.1, 1e-05);  primals_809 = None
        getitem_398 = native_batch_norm_default_132[0]
        getitem_399 = native_batch_norm_default_132[1]
        getitem_400 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        relu__default_171 = torch.ops.aten.relu_.default(getitem_398);  getitem_398 = None
        convolution_default_217 = torch.ops.aten.convolution.default(relu__default_171, primals_825, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_217, primals_818, primals_814, primals_816, primals_817, True, 0.1, 1e-05);  primals_814 = None
        getitem_401 = native_batch_norm_default_133[0]
        getitem_402 = native_batch_norm_default_133[1]
        getitem_403 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        relu__default_172 = torch.ops.aten.relu_.default(getitem_401);  getitem_401 = None
        convolution_default_218 = torch.ops.aten.convolution.default(relu__default_172, primals_826, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_218, primals_823, primals_819, primals_821, primals_822, True, 0.1, 1e-05);  primals_819 = None
        getitem_404 = native_batch_norm_default_134[0]
        getitem_405 = native_batch_norm_default_134[1]
        getitem_406 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        mean_dim_42 = torch.ops.aten.mean.dim(getitem_404, [2, 3], True)
        convolution_default_219 = torch.ops.aten.convolution.default(mean_dim_42, primals_828, primals_827, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_827 = None
        relu__default_173 = torch.ops.aten.relu_.default(convolution_default_219);  convolution_default_219 = None
        convolution_default_220 = torch.ops.aten.convolution.default(relu__default_173, primals_830, primals_829, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_829 = None
        sigmoid_default_42 = torch.ops.aten.sigmoid.default(convolution_default_220);  convolution_default_220 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(getitem_404, sigmoid_default_42)
        add_tensor_42 = torch.ops.aten.add.Tensor(mul_tensor_42, relu__default_170);  mul_tensor_42 = None
        relu__default_174 = torch.ops.aten.relu_.default(add_tensor_42);  add_tensor_42 = None
        convolution_default_221 = torch.ops.aten.convolution.default(relu__default_174, primals_846, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_221, primals_835, primals_831, primals_833, primals_834, True, 0.1, 1e-05);  primals_831 = None
        getitem_407 = native_batch_norm_default_135[0]
        getitem_408 = native_batch_norm_default_135[1]
        getitem_409 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        relu__default_175 = torch.ops.aten.relu_.default(getitem_407);  getitem_407 = None
        convolution_default_222 = torch.ops.aten.convolution.default(relu__default_175, primals_847, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_222, primals_840, primals_836, primals_838, primals_839, True, 0.1, 1e-05);  primals_836 = None
        getitem_410 = native_batch_norm_default_136[0]
        getitem_411 = native_batch_norm_default_136[1]
        getitem_412 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        relu__default_176 = torch.ops.aten.relu_.default(getitem_410);  getitem_410 = None
        convolution_default_223 = torch.ops.aten.convolution.default(relu__default_176, primals_848, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_223, primals_845, primals_841, primals_843, primals_844, True, 0.1, 1e-05);  primals_841 = None
        getitem_413 = native_batch_norm_default_137[0]
        getitem_414 = native_batch_norm_default_137[1]
        getitem_415 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        mean_dim_43 = torch.ops.aten.mean.dim(getitem_413, [2, 3], True)
        convolution_default_224 = torch.ops.aten.convolution.default(mean_dim_43, primals_850, primals_849, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_849 = None
        relu__default_177 = torch.ops.aten.relu_.default(convolution_default_224);  convolution_default_224 = None
        convolution_default_225 = torch.ops.aten.convolution.default(relu__default_177, primals_852, primals_851, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_851 = None
        sigmoid_default_43 = torch.ops.aten.sigmoid.default(convolution_default_225);  convolution_default_225 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(getitem_413, sigmoid_default_43)
        add_tensor_43 = torch.ops.aten.add.Tensor(mul_tensor_43, relu__default_174);  mul_tensor_43 = None
        relu__default_178 = torch.ops.aten.relu_.default(add_tensor_43);  add_tensor_43 = None
        convolution_default_226 = torch.ops.aten.convolution.default(relu__default_178, primals_868, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_226, primals_857, primals_853, primals_855, primals_856, True, 0.1, 1e-05);  primals_853 = None
        getitem_416 = native_batch_norm_default_138[0]
        getitem_417 = native_batch_norm_default_138[1]
        getitem_418 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        relu__default_179 = torch.ops.aten.relu_.default(getitem_416);  getitem_416 = None
        convolution_default_227 = torch.ops.aten.convolution.default(relu__default_179, primals_869, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_227, primals_862, primals_858, primals_860, primals_861, True, 0.1, 1e-05);  primals_858 = None
        getitem_419 = native_batch_norm_default_139[0]
        getitem_420 = native_batch_norm_default_139[1]
        getitem_421 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        relu__default_180 = torch.ops.aten.relu_.default(getitem_419);  getitem_419 = None
        convolution_default_228 = torch.ops.aten.convolution.default(relu__default_180, primals_870, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_228, primals_867, primals_863, primals_865, primals_866, True, 0.1, 1e-05);  primals_863 = None
        getitem_422 = native_batch_norm_default_140[0]
        getitem_423 = native_batch_norm_default_140[1]
        getitem_424 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        mean_dim_44 = torch.ops.aten.mean.dim(getitem_422, [2, 3], True)
        convolution_default_229 = torch.ops.aten.convolution.default(mean_dim_44, primals_872, primals_871, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_871 = None
        relu__default_181 = torch.ops.aten.relu_.default(convolution_default_229);  convolution_default_229 = None
        convolution_default_230 = torch.ops.aten.convolution.default(relu__default_181, primals_874, primals_873, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_873 = None
        sigmoid_default_44 = torch.ops.aten.sigmoid.default(convolution_default_230);  convolution_default_230 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(getitem_422, sigmoid_default_44)
        add_tensor_44 = torch.ops.aten.add.Tensor(mul_tensor_44, relu__default_178);  mul_tensor_44 = None
        relu__default_182 = torch.ops.aten.relu_.default(add_tensor_44);  add_tensor_44 = None
        convolution_default_231 = torch.ops.aten.convolution.default(relu__default_182, primals_890, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_231, primals_879, primals_875, primals_877, primals_878, True, 0.1, 1e-05);  primals_875 = None
        getitem_425 = native_batch_norm_default_141[0]
        getitem_426 = native_batch_norm_default_141[1]
        getitem_427 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        relu__default_183 = torch.ops.aten.relu_.default(getitem_425);  getitem_425 = None
        convolution_default_232 = torch.ops.aten.convolution.default(relu__default_183, primals_891, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_232, primals_884, primals_880, primals_882, primals_883, True, 0.1, 1e-05);  primals_880 = None
        getitem_428 = native_batch_norm_default_142[0]
        getitem_429 = native_batch_norm_default_142[1]
        getitem_430 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        relu__default_184 = torch.ops.aten.relu_.default(getitem_428);  getitem_428 = None
        convolution_default_233 = torch.ops.aten.convolution.default(relu__default_184, primals_892, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_233, primals_889, primals_885, primals_887, primals_888, True, 0.1, 1e-05);  primals_885 = None
        getitem_431 = native_batch_norm_default_143[0]
        getitem_432 = native_batch_norm_default_143[1]
        getitem_433 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        mean_dim_45 = torch.ops.aten.mean.dim(getitem_431, [2, 3], True)
        convolution_default_234 = torch.ops.aten.convolution.default(mean_dim_45, primals_894, primals_893, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_893 = None
        relu__default_185 = torch.ops.aten.relu_.default(convolution_default_234);  convolution_default_234 = None
        convolution_default_235 = torch.ops.aten.convolution.default(relu__default_185, primals_896, primals_895, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_895 = None
        sigmoid_default_45 = torch.ops.aten.sigmoid.default(convolution_default_235);  convolution_default_235 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(getitem_431, sigmoid_default_45)
        add_tensor_45 = torch.ops.aten.add.Tensor(mul_tensor_45, relu__default_182);  mul_tensor_45 = None
        relu__default_186 = torch.ops.aten.relu_.default(add_tensor_45);  add_tensor_45 = None
        convolution_default_236 = torch.ops.aten.convolution.default(relu__default_186, primals_912, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_236, primals_901, primals_897, primals_899, primals_900, True, 0.1, 1e-05);  primals_897 = None
        getitem_434 = native_batch_norm_default_144[0]
        getitem_435 = native_batch_norm_default_144[1]
        getitem_436 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        relu__default_187 = torch.ops.aten.relu_.default(getitem_434);  getitem_434 = None
        convolution_default_237 = torch.ops.aten.convolution.default(relu__default_187, primals_913, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_237, primals_906, primals_902, primals_904, primals_905, True, 0.1, 1e-05);  primals_902 = None
        getitem_437 = native_batch_norm_default_145[0]
        getitem_438 = native_batch_norm_default_145[1]
        getitem_439 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        relu__default_188 = torch.ops.aten.relu_.default(getitem_437);  getitem_437 = None
        convolution_default_238 = torch.ops.aten.convolution.default(relu__default_188, primals_914, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_238, primals_911, primals_907, primals_909, primals_910, True, 0.1, 1e-05);  primals_907 = None
        getitem_440 = native_batch_norm_default_146[0]
        getitem_441 = native_batch_norm_default_146[1]
        getitem_442 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        mean_dim_46 = torch.ops.aten.mean.dim(getitem_440, [2, 3], True)
        convolution_default_239 = torch.ops.aten.convolution.default(mean_dim_46, primals_916, primals_915, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_915 = None
        relu__default_189 = torch.ops.aten.relu_.default(convolution_default_239);  convolution_default_239 = None
        convolution_default_240 = torch.ops.aten.convolution.default(relu__default_189, primals_918, primals_917, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_917 = None
        sigmoid_default_46 = torch.ops.aten.sigmoid.default(convolution_default_240);  convolution_default_240 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(getitem_440, sigmoid_default_46)
        add_tensor_46 = torch.ops.aten.add.Tensor(mul_tensor_46, relu__default_186);  mul_tensor_46 = None
        relu__default_190 = torch.ops.aten.relu_.default(add_tensor_46);  add_tensor_46 = None
        convolution_default_241 = torch.ops.aten.convolution.default(relu__default_190, primals_1088, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_241, primals_1077, primals_1073, primals_1075, primals_1076, True, 0.1, 1e-05);  primals_1073 = None
        getitem_443 = native_batch_norm_default_147[0]
        getitem_444 = native_batch_norm_default_147[1]
        getitem_445 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        relu__default_191 = torch.ops.aten.relu_.default(getitem_443);  getitem_443 = None
        convolution_default_242 = torch.ops.aten.convolution.default(relu__default_191, primals_1089, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_242, primals_1082, primals_1078, primals_1080, primals_1081, True, 0.1, 1e-05);  primals_1078 = None
        getitem_446 = native_batch_norm_default_148[0]
        getitem_447 = native_batch_norm_default_148[1]
        getitem_448 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        relu__default_192 = torch.ops.aten.relu_.default(getitem_446);  getitem_446 = None
        convolution_default_243 = torch.ops.aten.convolution.default(relu__default_192, primals_1090, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_243, primals_1087, primals_1083, primals_1085, primals_1086, True, 0.1, 1e-05);  primals_1083 = None
        getitem_449 = native_batch_norm_default_149[0]
        getitem_450 = native_batch_norm_default_149[1]
        getitem_451 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        convolution_default_244 = torch.ops.aten.convolution.default(relu__default_190, primals_1091, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_244, primals_1096, primals_1092, primals_1094, primals_1095, True, 0.1, 1e-05);  primals_1092 = None
        getitem_452 = native_batch_norm_default_150[0]
        getitem_453 = native_batch_norm_default_150[1]
        getitem_454 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        mean_dim_47 = torch.ops.aten.mean.dim(getitem_449, [2, 3], True)
        convolution_default_245 = torch.ops.aten.convolution.default(mean_dim_47, primals_1098, primals_1097, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1097 = None
        relu__default_193 = torch.ops.aten.relu_.default(convolution_default_245);  convolution_default_245 = None
        convolution_default_246 = torch.ops.aten.convolution.default(relu__default_193, primals_1100, primals_1099, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1099 = None
        sigmoid_default_47 = torch.ops.aten.sigmoid.default(convolution_default_246);  convolution_default_246 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(getitem_449, sigmoid_default_47)
        add_tensor_47 = torch.ops.aten.add.Tensor(mul_tensor_47, getitem_452);  mul_tensor_47 = getitem_452 = None
        relu__default_194 = torch.ops.aten.relu_.default(add_tensor_47);  add_tensor_47 = None
        convolution_default_247 = torch.ops.aten.convolution.default(relu__default_194, primals_1116, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_247, primals_1105, primals_1101, primals_1103, primals_1104, True, 0.1, 1e-05);  primals_1101 = None
        getitem_455 = native_batch_norm_default_151[0]
        getitem_456 = native_batch_norm_default_151[1]
        getitem_457 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        relu__default_195 = torch.ops.aten.relu_.default(getitem_455);  getitem_455 = None
        convolution_default_248 = torch.ops.aten.convolution.default(relu__default_195, primals_1117, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_248, primals_1110, primals_1106, primals_1108, primals_1109, True, 0.1, 1e-05);  primals_1106 = None
        getitem_458 = native_batch_norm_default_152[0]
        getitem_459 = native_batch_norm_default_152[1]
        getitem_460 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        relu__default_196 = torch.ops.aten.relu_.default(getitem_458);  getitem_458 = None
        convolution_default_249 = torch.ops.aten.convolution.default(relu__default_196, primals_1118, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_249, primals_1115, primals_1111, primals_1113, primals_1114, True, 0.1, 1e-05);  primals_1111 = None
        getitem_461 = native_batch_norm_default_153[0]
        getitem_462 = native_batch_norm_default_153[1]
        getitem_463 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        mean_dim_48 = torch.ops.aten.mean.dim(getitem_461, [2, 3], True)
        convolution_default_250 = torch.ops.aten.convolution.default(mean_dim_48, primals_1120, primals_1119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1119 = None
        relu__default_197 = torch.ops.aten.relu_.default(convolution_default_250);  convolution_default_250 = None
        convolution_default_251 = torch.ops.aten.convolution.default(relu__default_197, primals_1122, primals_1121, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1121 = None
        sigmoid_default_48 = torch.ops.aten.sigmoid.default(convolution_default_251);  convolution_default_251 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(getitem_461, sigmoid_default_48)
        add_tensor_48 = torch.ops.aten.add.Tensor(mul_tensor_48, relu__default_194);  mul_tensor_48 = None
        relu__default_198 = torch.ops.aten.relu_.default(add_tensor_48);  add_tensor_48 = None
        convolution_default_252 = torch.ops.aten.convolution.default(relu__default_198, primals_1138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_252, primals_1127, primals_1123, primals_1125, primals_1126, True, 0.1, 1e-05);  primals_1123 = None
        getitem_464 = native_batch_norm_default_154[0]
        getitem_465 = native_batch_norm_default_154[1]
        getitem_466 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        relu__default_199 = torch.ops.aten.relu_.default(getitem_464);  getitem_464 = None
        convolution_default_253 = torch.ops.aten.convolution.default(relu__default_199, primals_1139, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_253, primals_1132, primals_1128, primals_1130, primals_1131, True, 0.1, 1e-05);  primals_1128 = None
        getitem_467 = native_batch_norm_default_155[0]
        getitem_468 = native_batch_norm_default_155[1]
        getitem_469 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        relu__default_200 = torch.ops.aten.relu_.default(getitem_467);  getitem_467 = None
        convolution_default_254 = torch.ops.aten.convolution.default(relu__default_200, primals_1140, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_254, primals_1137, primals_1133, primals_1135, primals_1136, True, 0.1, 1e-05);  primals_1133 = None
        getitem_470 = native_batch_norm_default_156[0]
        getitem_471 = native_batch_norm_default_156[1]
        getitem_472 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        mean_dim_49 = torch.ops.aten.mean.dim(getitem_470, [2, 3], True)
        convolution_default_255 = torch.ops.aten.convolution.default(mean_dim_49, primals_1142, primals_1141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1141 = None
        relu__default_201 = torch.ops.aten.relu_.default(convolution_default_255);  convolution_default_255 = None
        convolution_default_256 = torch.ops.aten.convolution.default(relu__default_201, primals_1144, primals_1143, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1143 = None
        sigmoid_default_49 = torch.ops.aten.sigmoid.default(convolution_default_256);  convolution_default_256 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(getitem_470, sigmoid_default_49)
        add_tensor_49 = torch.ops.aten.add.Tensor(mul_tensor_49, relu__default_198);  mul_tensor_49 = None
        relu__default_202 = torch.ops.aten.relu_.default(add_tensor_49);  add_tensor_49 = None
        mean_dim_50 = torch.ops.aten.mean.dim(relu__default_202, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_50, [64, 2048]);  mean_dim_50 = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        return [addmm_default, primals_111, primals_1096, primals_346, convolution_default_66, getitem_436, convolution_default_67, getitem_399, primals_109, primals_349, relu__default_106, primals_1098, sigmoid_default_21, relu__default_187, primals_107, relu__default_90, relu__default_171, convolution_default_237, convolution_default_217, primals_1100, getitem_129, convolution_default_136, primals_100, getitem_130, getitem_400, primals_105, primals_101, primals_106, getitem_439, primals_1103, getitem_438, getitem_256, relu__default_51, primals_1104, getitem_255, getitem_403, convolution_default_116, primals_1105, getitem_402, getitem_220, relu__default_188, getitem_219, primals_350, relu__default_107, relu__default_172, primals_1108, convolution_default_238, primals_110, primals_1109, getitem_133, mean_dim_12, relu__default_91, getitem_440, getitem_132, convolution_default_137, primals_1110, convolution_default_218, convolution_default_117, mean_dim_42, relu__default_52, getitem_258, primals_108, getitem_441, primals_1113, mean_dim_22, convolution_default_138, getitem_442, primals_1114, primals_114, getitem_405, primals_1115, convolution_default_68, mean_dim_26, getitem_406, mean_dim_46, primals_102, getitem_259, primals_1116, getitem_222, getitem_404, primals_970, getitem_202, primals_395, getitem_75, primals_971, getitem_201, getitem_76, getitem_364, primals_972, getitem_166, getitem_165, getitem_363, getitem_328, relu__default_28, relu__default_83, convolution_default_37, convolution_default_107, getitem_327, primals_975, relu__default_155, relu__default_67, primals_976, primals_977, relu__default_139, convolution_default_197, primals_978, getitem_79, convolution_default_87, getitem_78, getitem_77, primals_979, getitem_205, convolution_default_177, getitem_204, primals_980, primals_393, getitem_367, getitem_169, getitem_366, getitem_170, getitem_168, primals_982, relu__default_84, getitem_331, getitem_330, relu__default_156, primals_984, relu__default_68, mean_dim_6, convolution_default_108, relu__default_140, mean_dim_20, convolution_default_198, relu__default_29, primals_987, convolution_default_88, getitem_368, mean_dim_38, primals_988, mean_dim_16, convolution_default_178, primals_989, getitem_207, sigmoid_default_6, getitem_208, primals_394, getitem_206, mean_dim_34, primals_844, primals_482, primals_845, primals_846, primals_847, primals_848, primals_359, primals_483, primals_850, primals_852, primals_360, primals_855, primals_856, primals_361, primals_486, primals_857, primals_860, primals_861, primals_862, primals_362, primals_481, primals_211, primals_718, relu__default_122, relu__default_44, getitem_151, convolution_default_156, primals_720, getitem_112, convolution_default_57, getitem_150, convolution_default_157, primals_213, primals_204, getitem_40, getitem_39, getitem_38, relu__default_60, primals_723, getitem_292, primals_724, getitem_115, primals_216, getitem_291, getitem_114, getitem_113, primals_725, primals_212, convolution_default_78, relu__default_123, primals_728, getitem_154, getitem_153, primals_729, getitem_152, relu__default_13, primals_730, primals_733, mean_dim_30, sigmoid_default_2, getitem_294, relu__default_45, relu__default_46, primals_734, getitem_295, primals_206, primals_735, mean_dim_14, sigmoid_default_10, primals_736, relu__default_124, relu__default_14, convolution_default_158, primals_208, primals_218, primals_737, relu__default_61, convolution_default_19, convolution_default_60, primals_217, primals_738, sigmoid_default_14, primals_592, primals_1117, primals_593, primals_1118, relu__default_180, convolution_default_228, primals_1120, primals_596, relu__default_202, primals_597, primals_1122, getitem_424, primals_35, primals_598, getitem_423, getitem_422, primals_33, primals_1125, primals_601, primals_1126, primals_602, primals_1127, primals_30, primals_29, primals_603, primals_34, primals_28, primals_604, primals_605, primals_1130, primals_37, primals_606, primals_1131, primals_1132, relu__default_181, primals_608, primals_38, primals_36, sigmoid_default_44, primals_610, primals_1135, primals_42, primals_1136, convolution_default_231, primals_1137, relu__default_182, primals_39, primals_364, primals_992, getitem_349, getitem_460, primals_993, getitem_348, getitem_459, primals_994, relu__default_148, relu__default_196, primals_371, primals_997, convolution_default_188, primals_998, convolution_default_249, primals_999, primals_1000, getitem_352, primals_1001, getitem_463, getitem_351, getitem_350, getitem_462, getitem_461, primals_1002, primals_1004, primals_1006, primals_363, mean_dim_36, mean_dim_48, sigmoid_default_48, primals_1009, sigmoid_default_36, relu__default_149, relu__default_197, primals_1010, primals_366, primals_1011, primals_368, primals_865, getitem_238, getitem_384, relu__default_115, primals_866, convolution_default_147, getitem_385, primals_867, convolution_default_148, relu__default_99, primals_868, getitem_237, getitem_313, relu__default_164, convolution_default_127, getitem_312, primals_869, primals_410, convolution_default_208, primals_870, getitem_277, getitem_276, relu__default_132, primals_872, getitem_241, getitem_240, getitem_388, relu__default_116, getitem_387, convolution_default_168, getitem_386, primals_874, relu__default_100, getitem_278, getitem_316, primals_877, getitem_315, getitem_314, primals_878, convolution_default_128, primals_412, relu__default_133, primals_879, getitem_242, getitem_279, mean_dim_40, getitem_280, relu__default_165, primals_882, primals_883, getitem_243, mean_dim_32, getitem_244, primals_884, mean_dim_28, mean_dim_24, relu__default_117, sigmoid_default_40, primals_189, getitem_60, primals_740, getitem_61, primals_169, primals_167, relu__default_5, primals_742, primals_159, primals_190, sigmoid_default, primals_745, relu__default_21, primals_746, primals_747, sigmoid_default_4, relu__default_6, primals_164, relu__default_22, convolution_default_9, primals_750, primals_751, primals_752, getitem_24, primals_160, getitem_25, convolution_default_30, primals_172, primals_162, primals_191, primals_168, primals_755, relu__default_7, primals_756, primals_757, getitem_63, convolution_default_10, primals_758, getitem_64, primals_173, primals_759, primals_613, convolution_default_98, getitem_223, primals_278, primals_614, getitem_186, relu__default_92, primals_615, getitem_187, primals_180, convolution_default_118, relu__default_76, primals_267, primals_618, primals_619, primals_182, getitem_226, primals_270, getitem_225, primals_177, primals_620, getitem_224, primals_269, getitem_190, getitem_189, getitem_188, primals_623, primals_174, primals_277, primals_624, primals_268, primals_274, primals_625, primals_272, primals_626, primals_266, primals_627, primals_181, primals_628, mean_dim_18, primals_186, primals_179, relu__default_93, relu__default_94, primals_279, primals_630, relu__default_77, sigmoid_default_22, primals_632, primals_265, sigmoid_default_18, primals_178, primals_184, convolution_default_121, primals_1138, getitem_369, primals_496, primals_1139, getitem_370, getitem_136, primals_495, getitem_135, relu__default_189, primals_1140, primals_494, getitem_134, primals_329, primals_327, primals_493, primals_1142, relu__default_37, convolution_default_241, primals_492, primals_328, sigmoid_default_46, primals_491, primals_1144, relu__default_157, relu__default_190, sigmoid_default_8, primals_1145, relu__default_38, primals_504, sigmoid_default_38, relu__default_53, primals_332, relu__default_158, sigmoid_default_12, primals_500, relu__default_54, getitem_445, primals_488, convolution_default_50, getitem_372, getitem_444, convolution_default_201, primals_498, primals_487, convolution_default_202, convolution_default_71, primals_503, relu__default_191, getitem_99, getitem_100, getitem_373, convolution_default_51, convolution_default_242, primals_505, relu__default_39, primals_333, getitem_172, primals_155, getitem_334, relu__default_30, getitem_333, primals_466, primals_158, getitem_43, convolution_default_40, primals_1014, primals_145, getitem_171, getitem_42, primals_1015, convolution_default_41, convolution_default_221, getitem_332, primals_1016, relu__default_173, relu__default_15, getitem_82, getitem_81, sigmoid_default_42, primals_146, relu__default_69, primals_1019, relu__default_174, primals_465, primals_452, primals_1020, relu__default_141, sigmoid_default_16, primals_1021, convolution_default_20, relu__default_31, primals_1022, relu__default_70, primals_150, getitem_46, sigmoid_default_34, primals_464, getitem_45, primals_1023, primals_147, relu__default_142, primals_461, primals_1024, primals_460, relu__default_16, primals_459, primals_1026, convolution_default_91, primals_157, mean_dim_7, getitem_84, convolution_default_181, getitem_408, primals_1028, getitem_85, convolution_default_21, primals_151, getitem_409, primals_456, mean_dim_3, primals_156, relu__default_32, convolution_default_42, primals_1031, getitem_174, relu__default_175, primals_454, getitem_175, convolution_default_222, primals_1032, getitem_48, getitem_336, primals_152, getitem_47, primals_887, primals_888, getitem_298, primals_889, getitem_297, primals_890, getitem_296, primals_891, primals_892, primals_894, primals_896, relu__default_125, primals_899, primals_900, relu__default_126, primals_901, sigmoid_default_30, primals_904, convolution_default_161, primals_905, primals_906, primals_255, primals_432, primals_760, primals_257, relu__default_108, primals_256, primals_762, primals_320, primals_261, getitem_118, convolution_default_216, primals_764, primals_319, getitem_117, getitem_262, getitem_261, getitem_260, primals_767, relu__default_47, primals_768, primals_260, primals_318, primals_262, primals_252, primals_317, primals_769, convolution_default_61, primals_250, primals_772, relu__default_109, getitem_121, primals_773, getitem_120, primals_322, primals_774, relu__default_48, sigmoid_default_26, primals_437, primals_324, convolution_default_141, primals_777, primals_434, primals_778, convolution_default_62, relu__default_110, primals_779, primals_780, mean_dim_11, primals_196, primals_635, relu__default_198, convolution_default, primals_636, primals_637, primals_203, getitem_427, getitem_426, primals_200, relu__default_85, view_default, convolution_default_252, primals_199, primals_640, sigmoid_default_20, relu__default_183, primals_641, primals_201, getitem_466, primals_642, relu__default_86, getitem_465, convolution_default_232, primals_195, primals_645, t_default, relu__default_199, primals_646, convolution_default_111, getitem_430, getitem_429, primals_647, primals_202, primals_648, convolution_default_253, primals_194, primals_649, relu__default_184, primals_650, getitem_468, convolution_default_254, relu__default_87, primals_652, getitem_210, convolution_default_233, getitem_211, mean_dim_49, primals_654, mean_dim_45, getitem_469, convolution_default_112, primals_508, primals_354, primals_509, relu__default_62, sigmoid_default_32, primals_510, relu__default_134, convolution_default_81, primals_513, primals_514, primals_515, getitem_157, primals_516, getitem_156, convolution_default_171, primals_517, getitem_319, sigmoid_default_49, getitem_318, primals_518, relu__default_63, primals_520, primals_351, relu__default_135, primals_522, convolution_default_82, primals_355, convolution_default_172, primals_356, getitem_159, mean_dim_33, primals_525, convolution_default_83, primals_526, primals_527, mean_dim_15, getitem_321, getitem_160, relu__default_166, primals_381, getitem_28, relu__default_150, convolution_default_211, getitem_27, primals_378, relu__default_101, convolution_default_191, convolution_default_212, convolution_default_11, convolution_default_131, sigmoid_default_28, primals_390, relu__default_8, relu__default_118, sigmoid_default_24, getitem_391, getitem_390, relu__default_102, getitem_355, primals_382, primals_383, getitem_354, relu__default_167, primals_377, primals_384, getitem_31, getitem_30, getitem_29, convolution_default_151, relu__default_151, getitem_283, getitem_282, primals_385, convolution_default_192, mean_dim_41, getitem_246, relu__default_119, convolution_default_213, primals_386, getitem_247, getitem_393, getitem_394, getitem_357, mean_dim_1, relu__default_103, convolution_default_152, relu__default_168, relu__default_9, mean_dim_37, primals_388, getitem_358, sigmoid_default_1, convolution_default_132, convolution_default_193, relu__default_152, primals_1033, relu__default_23, convolution_default_31, convolution_default_32, convolution_default_1, primals_74, primals_1036, getitem_103, primals_83, getitem_102, primals_1037, getitem_229, primals_61, getitem_2, getitem_228, primals_70, primals_62, primals_80, primals_1038, getitem_67, getitem_1, getitem_66, primals_85, relu__default_40, primals_63, primals_68, relu__default_95, relu__default, primals_1041, primals_73, relu__default_24, convolution_default_52, primals_84, primals_1042, convolution_default_122, primals_1043, primals_58, primals_1044, getitem_68, getitem_106, primals_1045, getitem_105, primals_75, getitem_104, getitem_5, getitem_232, primals_1046, getitem_4, getitem_231, relu__default_41, getitem_69, primals_64, primals_1048, getitem_70, relu__default_1, relu__default_96, primals_57, primals_1050, primals_79, primals_66, primals_65, mean_dim_9, convolution_default_2, convolution_default_123, mean_dim_5, primals_1053, relu__default_25, primals_78, mean_dim_23, primals_305, getitem_301, relu__default_78, getitem_448, getitem_300, getitem_447, primals_909, relu__default_55, convolution_default_101, getitem_88, getitem_138, primals_910, convolution_default_72, relu__default_127, getitem_87, convolution_default_162, convolution_default_243, primals_911, getitem_86, convolution_default_102, getitem_139, relu__default_192, primals_912, primals_302, getitem_193, primals_913, getitem_192, primals_914, getitem_142, getitem_141, getitem_304, primals_916, relu__default_79, getitem_303, getitem_451, primals_300, relu__default_33, getitem_450, getitem_449, relu__default_56, primals_918, relu__default_128, convolution_default_244, convolution_default_73, primals_921, primals_298, getitem_143, relu__default_34, convolution_default_163, primals_922, sigmoid_default_7, mean_dim_19, getitem_195, getitem_453, primals_923, mean_dim_31, primals_297, getitem_196, mean_dim_47, relu__default_80, convolution_default_103, convolution_default_45, getitem_144, primals_306, primals_926, getitem_145, getitem_306, mean_dim_13, getitem_307, getitem_454, primals_296, primals_927, getitem_305, primals_781, primals_782, primals_784, primals_786, primals_246, primals_789, primals_239, primals_790, primals_238, primals_791, primals_234, primals_248, primals_245, primals_247, primals_794, primals_795, primals_796, primals_235, primals_799, primals_240, primals_244, primals_800, primals_801, primals_243, convolution_default_142, relu__default_71, relu__default_159, convolution_default_92, primals_657, getitem_265, convolution_default_93, getitem_264, getitem_412, primals_658, convolution_default_22, getitem_411, primals_659, getitem_52, getitem_376, getitem_51, getitem_178, relu__default_111, getitem_49, getitem_375, getitem_177, relu__default_176, primals_662, primals_663, relu__default_160, convolution_default_223, relu__default_72, primals_664, convolution_default_203, getitem_268, getitem_377, getitem_179, getitem_267, getitem_415, primals_667, getitem_414, getitem_413, relu__default_17, primals_668, relu__default_18, primals_669, relu__default_112, getitem_378, getitem_180, relu__default_161, primals_670, getitem_379, getitem_181, primals_671, sigmoid_default_3, convolution_default_143, primals_672, convolution_default_25, relu__default_73, mean_dim_27, mean_dim_43, mean_dim_39, primals_674, mean_dim_17, getitem_269, relu__default_177, primals_125, primals_530, primals_116, primals_403, primals_531, primals_123, primals_96, primals_90, primals_532, primals_404, primals_407, primals_118, primals_535, primals_408, primals_536, primals_537, primals_92, primals_405, primals_538, primals_97, primals_539, primals_88, primals_540, primals_406, primals_399, primals_86, primals_542, primals_120, primals_95, primals_400, primals_87, primals_544, primals_398, primals_124, primals_115, primals_547, primals_548, primals_128, primals_549, primals_478, primals_1054, primals_372, getitem_124, getitem_337, primals_439, primals_1055, getitem_123, primals_472, relu__default_143, primals_473, getitem_122, convolution_default_182, primals_1058, convolution_default_63, primals_337, primals_373, primals_442, primals_1059, primals_130, primals_129, primals_284, primals_135, primals_1060, primals_283, primals_287, getitem_127, getitem_340, primals_448, primals_470, getitem_339, getitem_126, primals_339, primals_138, primals_291, primals_1063, primals_134, primals_282, primals_451, primals_1064, relu__default_144, primals_288, primals_449, primals_1065, primals_142, primals_334, primals_471, primals_1066, primals_438, primals_140, primals_474, convolution_default_183, primals_1067, getitem_341, primals_290, primals_1068, primals_443, primals_292, primals_1070, relu__default_49, primals_133, primals_450, primals_136, primals_444, primals_476, primals_1072, primals_289, getitem_342, getitem_343, relu__default_50, primals_293, primals_338, primals_447, mean_dim_35, primals_137, primals_376, primals_469, sigmoid_default_11, primals_928, getitem_433, getitem_432, primals_931, getitem_431, primals_932, primals_933, primals_934, primals_935, relu__default_185, primals_936, primals_938, sigmoid_default_45, relu__default_186, primals_940, primals_943, convolution_default_236, primals_944, primals_945, primals_948, getitem_435, primals_802, convolution_default_133, primals_52, relu__default_64, getitem_8, relu__default_200, primals_803, primals_43, convolution_default_3, getitem_7, getitem_250, primals_804, getitem_249, getitem_397, getitem_396, primals_342, getitem_395, primals_48, primals_44, getitem_214, relu__default_2, getitem_213, primals_806, primals_307, getitem_163, getitem_472, getitem_162, getitem_161, relu__default_104, getitem_470, getitem_471, primals_808, relu__default_88, getitem_9, getitem_10, primals_23, primals_312, primals_19, primals_51, convolution_default_113, primals_811, relu__default_169, primals_310, primals_341, primals_812, getitem_253, getitem_252, getitem_251, primals_53, primals_813, getitem_13, primals_311, getitem_217, getitem_12, relu__default_65, relu__default_201, primals_46, getitem_216, getitem_215, primals_20, primals_340, primals_816, relu__default_170, primals_25, primals_15, primals_817, sigmoid_default_41, relu__default_3, primals_818, sigmoid_default_15, mean_dim_25, sigmoid_default_25, primals_56, primals_18, primals_315, primals_344, convolution_default_4, mean_dim_21, relu__default_105, primals_14, primals_821, relu__default_66, convolution_default_86, primals_316, primals_822, relu__default_89, primals_24, primals_676, getitem_322, relu__default_136, getitem_199, convolution_default_173, primals_679, getitem_198, getitem_197, primals_680, primals_681, getitem_325, getitem_324, getitem_323, primals_684, primals_685, primals_686, relu__default_81, primals_689, primals_690, relu__default_82, primals_691, sigmoid_default_19, relu__default_137, relu__default_138, primals_692, primals_693, sigmoid_default_33, primals_694, convolution_default_106, convolution_default_176, primals_696, relu__default_10, primals_552, primals_553, convolution_default_14, sigmoid_default_5, primals_554, getitem_361, relu__default_26, getitem_360, getitem_359, getitem_34, primals_557, getitem_33, primals_558, primals_559, primals_560, relu__default_11, convolution_default_35, primals_561, getitem_73, getitem_72, relu__default_153, primals_562, convolution_default_15, primals_564, relu__default_27, sigmoid_default_37, primals_566, mean_dim_2, convolution_default_36, convolution_default_16, relu__default_154, getitem_36, primals_569, getitem_37, primals_570, convolution_default_196, relu__default_12, primals_1075, primals_420, primals_1076, primals_425, primals_1077, primals_1080, primals_1081, primals_422, primals_1082, primals_421, primals_1085, primals_430, primals_1086, primals_1087, primals_429, primals_1088, primals_1089, primals_1090, primals_428, primals_1091, primals_427, primals_1094, primals_426, primals_1095, primals_949, primals_950, getitem_285, sigmoid_default_43, primals_415, getitem_286, sigmoid_default_9, relu__default_178, relu__default_42, sigmoid_default_17, convolution_default_226, sigmoid_default_39, relu__default_120, primals_953, convolution_default_153, relu__default_74, relu__default_162, primals_954, primals_955, primals_956, primals_416, primals_957, getitem_289, convolution_default_55, getitem_288, getitem_287, getitem_418, primals_958, getitem_109, getitem_417, getitem_108, convolution_default_206, convolution_default_96, getitem_382, primals_960, getitem_184, getitem_381, primals_417, getitem_183, relu__default_179, relu__default_43, primals_962, relu__default_163, mean_dim_29, relu__default_75, convolution_default_227, convolution_default_56, primals_965, mean_dim_44, mean_dim_10, relu__default_121, primals_966, convolution_default_207, convolution_default_97, primals_967, sigmoid_default_29, getitem_420, getitem_111, getitem_421, primals_823, primals_824, getitem_235, getitem_234, primals_825, primals_826, getitem_233, primals_828, primals_830, relu__default_97, primals_833, sigmoid_default_23, primals_834, relu__default_98, primals_835, primals_838, convolution_default_126, primals_839, primals_840, primals_843, getitem_16, getitem_91, convolution_default_26, getitem_90, primals_698, getitem_15, primals_6, getitem_55, primals_9, relu__default_57, getitem_54, relu__default_193, relu__default_4, relu__default_35, convolution_default_5, primals_701, convolution_default_76, relu__default_129, primals_12, convolution_default_46, primals_7, primals_702, sigmoid_default_13, primals_13, sigmoid_default_47, relu__default_19, primals_703, relu__default_58, sigmoid_default_31, relu__default_130, getitem_94, primals_706, getitem_19, getitem_93, getitem_18, relu__default_194, primals_8, getitem_17, primals_707, convolution_default_247, getitem_58, primals_708, getitem_57, relu__default_36, convolution_default_6, convolution_default_166, getitem_456, primals_711, relu__default_20, getitem_147, convolution_default_47, getitem_457, primals_712, getitem_148, primals_713, mean_dim_8, convolution_default_27, getitem_309, primals_714, relu__default_195, relu__default_59, primals_3, getitem_310, primals_715, mean_dim_4, getitem_21, primals_716, getitem_22, getitem_96, getitem_59, convolution_default_167, mean_dim, getitem_97, relu__default_131, convolution_default_248, convolution_default_77, getitem_95, primals_571, getitem_270, primals_225, getitem_271, primals_223, relu__default_145, primals_574, convolution_default_186, primals_575, primals_228, sigmoid_default_35, primals_576, relu__default_146, relu__default_113, primals_226, primals_579, sigmoid_default_27, primals_580, relu__default_114, primals_581, primals_222, primals_582, primals_583, getitem_346, primals_584, getitem_345, convolution_default_146, primals_586, primals_221, relu__default_147, primals_588, primals_224, primals_233, getitem_273, getitem_274, convolution_default_187, primals_591, primals_230]
        
