
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_joint_12/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, tangents_1):
        mean_dim = torch.ops.aten.mean.dim(primals_3, [-1, -2], True);  primals_3 = None
        view_default = torch.ops.aten.view.default(mean_dim, [128, 1024]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1024, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1024, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        return [addmm_default, view_default_1, t_default_4, div_scalar]
        
