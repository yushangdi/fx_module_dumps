
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_forward_9/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6):
        add_tensor = torch.ops.aten.add.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(primals_1, primals_5, primals_6, primals_3, primals_4, True, 0.1, 1e-05);  primals_6 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        return [relu__default, add_tensor, primals_1, primals_5, getitem_2, primals_3, getitem_1, primals_4, relu__default]
        
