
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_backward_2/state_dict.pt'))

    
    
    def forward(self, primals_8, getitem_15, primals_10, primals_27, getitem_16, relu__default_8, primals_13, primals_55, getitem_9, primals_11, convolution_default_8, primals_32, primals_21, getitem_37, getitem_10, primals_5, getitem_36, relu__default_4, primals_30, primals_52, getitem_31, primals_41, convolution_default_4, primals_4, getitem_30, relu__default_2, primals_66, primals_7, convolution_default_2, relu__default_11, primals_2, primals_65, primals_31, getitem_19, primals_17, getitem_18, primals_1, primals_51, relu__default_9, getitem_13, primals_16, primals_25, getitem_12, getitem_34, primals_12, primals_3, primals_9, relu__default_5, primals_67, primals_26, primals_20, relu__default_3, getitem_33, relu__default_10, cat_default_5, convolution_default_10, cat_default_2, primals_22, primals_6, primals_15, cat_default_3, getitem_1, getitem_21, primals_70, getitem_22, primals_47, primals_61, relu__default_6, primals_56, getitem_3, convolution_default_6, getitem_4, getitem_25, primals_50, primals_72, primals_36, getitem_24, primals_71, primals_57, relu__default, convolution_default, cat_default, relu__default_7, primals_60, getitem_7, primals_40, getitem_6, primals_35, primals_62, cat_default_1, getitem_27, primals_45, relu__default_1, primals_42, cat_default_4, getitem_28, primals_37, primals_46, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13):
        slice_tensor = torch.ops.aten.slice.Tensor(tangents_1, 1, 0, 64)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(tangents_1, 1, 64, 96)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(tangents_1, 1, 96, 128)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(tangents_1, 1, 128, 160)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(tangents_1, 1, 160, 192)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(tangents_1, 1, 192, 224)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(tangents_1, 1, 224, 256);  tangents_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(slice_tensor_6, relu__default_11, primals_12, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_6 = primals_12 = None
        getitem_38 = convolution_backward_default[0]
        getitem_39 = convolution_backward_default[1];  convolution_backward_default = None
        to_dtype = torch.ops.aten.to.dtype(getitem_38, torch.float32);  getitem_38 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_12, to_dtype);  le_scalar = new_zeros_default_12 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_10, primals_72, primals_70, primals_71, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_10 = primals_72 = primals_70 = primals_71 = getitem_36 = getitem_37 = None
        getitem_41 = native_batch_norm_backward_default[0]
        getitem_42 = native_batch_norm_backward_default[1]
        getitem_43 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_41, relu__default_10, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_41 = primals_11 = None
        getitem_44 = convolution_backward_default_1[0]
        getitem_45 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_44, torch.float32);  getitem_44 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_13, to_dtype_3);  le_scalar_1 = new_zeros_default_13 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, cat_default_5, primals_67, primals_65, primals_66, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  to_dtype_5 = cat_default_5 = primals_67 = primals_65 = primals_66 = getitem_33 = getitem_34 = None
        getitem_47 = native_batch_norm_backward_default_1[0]
        getitem_48 = native_batch_norm_backward_default_1[1]
        getitem_49 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_47, 1, 0, 64)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(getitem_47, 1, 64, 96)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(getitem_47, 1, 96, 128)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_47, 1, 128, 160)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_47, 1, 160, 192)
        slice_tensor_12 = torch.ops.aten.slice.Tensor(getitem_47, 1, 192, 224);  getitem_47 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(slice_tensor, slice_tensor_7);  slice_tensor = slice_tensor_7 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(slice_tensor_1, slice_tensor_8);  slice_tensor_1 = slice_tensor_8 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(slice_tensor_2, slice_tensor_9);  slice_tensor_2 = slice_tensor_9 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(slice_tensor_3, slice_tensor_10);  slice_tensor_3 = slice_tensor_10 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(slice_tensor_4, slice_tensor_11);  slice_tensor_4 = slice_tensor_11 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(slice_tensor_5, slice_tensor_12);  slice_tensor_5 = slice_tensor_12 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(add_tensor_17, relu__default_9, primals_10, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_17 = primals_10 = None
        getitem_50 = convolution_backward_default_2[0]
        getitem_51 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_50, torch.float32);  getitem_50 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_14, to_dtype_6);  le_scalar_2 = new_zeros_default_14 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_8, primals_62, primals_60, primals_61, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_8 = primals_62 = primals_60 = primals_61 = getitem_30 = getitem_31 = None
        getitem_53 = native_batch_norm_backward_default_2[0]
        getitem_54 = native_batch_norm_backward_default_2[1]
        getitem_55 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_53, relu__default_8, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_53 = primals_9 = None
        getitem_56 = convolution_backward_default_3[0]
        getitem_57 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_56, torch.float32);  getitem_56 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_15, to_dtype_9);  le_scalar_3 = new_zeros_default_15 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, cat_default_4, primals_57, primals_55, primals_56, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_11 = cat_default_4 = primals_57 = primals_55 = primals_56 = getitem_27 = getitem_28 = None
        getitem_59 = native_batch_norm_backward_default_3[0]
        getitem_60 = native_batch_norm_backward_default_3[1]
        getitem_61 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        slice_tensor_13 = torch.ops.aten.slice.Tensor(getitem_59, 1, 0, 64)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(getitem_59, 1, 64, 96)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_59, 1, 96, 128)
        slice_tensor_16 = torch.ops.aten.slice.Tensor(getitem_59, 1, 128, 160)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(getitem_59, 1, 160, 192);  getitem_59 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(add_tensor_12, slice_tensor_13);  add_tensor_12 = slice_tensor_13 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_13, slice_tensor_14);  add_tensor_13 = slice_tensor_14 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(add_tensor_14, slice_tensor_15);  add_tensor_14 = slice_tensor_15 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_15, slice_tensor_16);  add_tensor_15 = slice_tensor_16 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_16, slice_tensor_17);  add_tensor_16 = slice_tensor_17 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(add_tensor_22, relu__default_7, primals_8, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_22 = primals_8 = None
        getitem_62 = convolution_backward_default_4[0]
        getitem_63 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_62, torch.float32);  getitem_62 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_16, to_dtype_12);  le_scalar_4 = new_zeros_default_16 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_6, primals_52, primals_50, primals_51, getitem_24, getitem_25, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_6 = primals_52 = primals_50 = primals_51 = getitem_24 = getitem_25 = None
        getitem_65 = native_batch_norm_backward_default_4[0]
        getitem_66 = native_batch_norm_backward_default_4[1]
        getitem_67 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_65, relu__default_6, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_65 = primals_7 = None
        getitem_68 = convolution_backward_default_5[0]
        getitem_69 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_68, torch.float32);  getitem_68 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_17, to_dtype_15);  le_scalar_5 = new_zeros_default_17 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, cat_default_3, primals_47, primals_45, primals_46, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  to_dtype_17 = cat_default_3 = primals_47 = primals_45 = primals_46 = getitem_21 = getitem_22 = None
        getitem_71 = native_batch_norm_backward_default_5[0]
        getitem_72 = native_batch_norm_backward_default_5[1]
        getitem_73 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        slice_tensor_18 = torch.ops.aten.slice.Tensor(getitem_71, 1, 0, 64)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(getitem_71, 1, 64, 96)
        slice_tensor_20 = torch.ops.aten.slice.Tensor(getitem_71, 1, 96, 128)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(getitem_71, 1, 128, 160);  getitem_71 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_18, slice_tensor_18);  add_tensor_18 = slice_tensor_18 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_19, slice_tensor_19);  add_tensor_19 = slice_tensor_19 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_20, slice_tensor_20);  add_tensor_20 = slice_tensor_20 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(add_tensor_21, slice_tensor_21);  add_tensor_21 = slice_tensor_21 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(add_tensor_26, relu__default_5, primals_6, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_26 = primals_6 = None
        getitem_74 = convolution_backward_default_6[0]
        getitem_75 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_74, torch.float32);  getitem_74 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_18, to_dtype_18);  le_scalar_6 = new_zeros_default_18 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_4, primals_42, primals_40, primals_41, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_4 = primals_42 = primals_40 = primals_41 = getitem_18 = getitem_19 = None
        getitem_77 = native_batch_norm_backward_default_6[0]
        getitem_78 = native_batch_norm_backward_default_6[1]
        getitem_79 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_77, relu__default_4, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_77 = primals_5 = None
        getitem_80 = convolution_backward_default_7[0]
        getitem_81 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_80, torch.float32);  getitem_80 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_19, to_dtype_21);  le_scalar_7 = new_zeros_default_19 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, cat_default_2, primals_37, primals_35, primals_36, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  to_dtype_23 = cat_default_2 = primals_37 = primals_35 = primals_36 = getitem_15 = getitem_16 = None
        getitem_83 = native_batch_norm_backward_default_7[0]
        getitem_84 = native_batch_norm_backward_default_7[1]
        getitem_85 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(getitem_83, 1, 0, 64)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(getitem_83, 1, 64, 96)
        slice_tensor_24 = torch.ops.aten.slice.Tensor(getitem_83, 1, 96, 128);  getitem_83 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_23, slice_tensor_22);  add_tensor_23 = slice_tensor_22 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_24, slice_tensor_23);  add_tensor_24 = slice_tensor_23 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(add_tensor_25, slice_tensor_24);  add_tensor_25 = slice_tensor_24 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(add_tensor_29, relu__default_3, primals_4, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_29 = primals_4 = None
        getitem_86 = convolution_backward_default_8[0]
        getitem_87 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_86, torch.float32);  getitem_86 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_20, to_dtype_24);  le_scalar_8 = new_zeros_default_20 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_2, primals_32, primals_30, primals_31, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_2 = primals_32 = primals_30 = primals_31 = getitem_12 = getitem_13 = None
        getitem_89 = native_batch_norm_backward_default_8[0]
        getitem_90 = native_batch_norm_backward_default_8[1]
        getitem_91 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_89, relu__default_2, primals_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_89 = primals_3 = None
        getitem_92 = convolution_backward_default_9[0]
        getitem_93 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_92, torch.float32);  getitem_92 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_21, to_dtype_27);  le_scalar_9 = new_zeros_default_21 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, cat_default_1, primals_27, primals_25, primals_26, getitem_9, getitem_10, True, 1e-05, [True, True, True]);  to_dtype_29 = cat_default_1 = primals_27 = primals_25 = primals_26 = getitem_9 = getitem_10 = None
        getitem_95 = native_batch_norm_backward_default_9[0]
        getitem_96 = native_batch_norm_backward_default_9[1]
        getitem_97 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        slice_tensor_25 = torch.ops.aten.slice.Tensor(getitem_95, 1, 0, 64)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(getitem_95, 1, 64, 96);  getitem_95 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_27, slice_tensor_25);  add_tensor_27 = slice_tensor_25 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_28, slice_tensor_26);  add_tensor_28 = slice_tensor_26 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(add_tensor_31, relu__default_1, primals_2, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_31 = primals_2 = None
        getitem_98 = convolution_backward_default_10[0]
        getitem_99 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_98, torch.float32);  getitem_98 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_22, to_dtype_30);  le_scalar_10 = new_zeros_default_22 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default, primals_22, primals_20, primals_21, getitem_6, getitem_7, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default = primals_22 = primals_20 = primals_21 = getitem_6 = getitem_7 = None
        getitem_101 = native_batch_norm_backward_default_10[0]
        getitem_102 = native_batch_norm_backward_default_10[1]
        getitem_103 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_101, relu__default, primals_1, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_101 = primals_1 = None
        getitem_104 = convolution_backward_default_11[0]
        getitem_105 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_104, torch.float32);  getitem_104 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_23, to_dtype_33);  le_scalar_11 = new_zeros_default_23 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, cat_default, primals_17, primals_15, primals_16, getitem_3, getitem_4, True, 1e-05, [True, True, True]);  to_dtype_35 = cat_default = primals_17 = primals_15 = primals_16 = getitem_3 = getitem_4 = None
        getitem_107 = native_batch_norm_backward_default_11[0]
        getitem_108 = native_batch_norm_backward_default_11[1]
        getitem_109 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(getitem_107, 1, 0, 64);  getitem_107 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(add_tensor_30, slice_tensor_27);  add_tensor_30 = slice_tensor_27 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_32, primals_13, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_1);  add_tensor_32 = primals_13 = getitem_1 = None
        return [getitem_105, getitem_99, getitem_93, getitem_87, getitem_81, getitem_75, getitem_69, getitem_63, getitem_57, getitem_51, getitem_45, getitem_39, max_pool2d_with_indices_backward_default, None, None, None, getitem_108, getitem_109, None, None, None, getitem_102, getitem_103, None, None, None, getitem_96, getitem_97, None, None, None, getitem_90, getitem_91, None, None, None, getitem_84, getitem_85, None, None, None, getitem_78, getitem_79, None, None, None, getitem_72, getitem_73, None, None, None, getitem_66, getitem_67, None, None, None, getitem_60, getitem_61, None, None, None, getitem_54, getitem_55, None, None, None, getitem_48, getitem_49, None, None, None, getitem_42, getitem_43]
        
