
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, tangents_1):
        convolution_backward_default = torch.ops.aten.convolution_backward.default(tangents_1, primals_2, primals_1, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  tangents_1 = primals_2 = primals_1 = None
        getitem_1 = convolution_backward_default[1];  convolution_backward_default = None
        return [getitem_1, None]
        
