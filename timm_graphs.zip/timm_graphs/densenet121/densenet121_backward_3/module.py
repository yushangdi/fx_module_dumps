
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_backward_3/state_dict.pt'))

    
    
    def forward(self, primals_5, primals_1, relu__default, primals_3, getitem_2, primals_4, getitem_1, tangents_1, tangents_2):
        to_dtype = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_1, to_dtype);  le_scalar = new_zeros_default_1 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, primals_1, primals_5, primals_3, primals_4, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_2 = primals_1 = primals_5 = primals_3 = primals_4 = getitem_1 = getitem_2 = None
        getitem_3 = native_batch_norm_backward_default[0]
        getitem_4 = native_batch_norm_backward_default[1]
        getitem_5 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        return [getitem_3, None, None, None, getitem_4, getitem_5]
        
