
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_forward_11/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198):
        cat_default = torch.ops.aten.cat.default([primals_33], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_34, 1);  primals_34 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(cat_default, primals_37, primals_38, primals_35, primals_36, True, 0.1, 1e-05);  primals_38 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default = torch.ops.aten.convolution.default(relu__default, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_39, 1);  primals_39 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default, primals_42, primals_43, primals_40, primals_41, True, 0.1, 1e-05);  primals_43 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default_1, primals_16, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_1 = torch.ops.aten.cat.default([primals_33, convolution_default_1], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_44, 1);  primals_44 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_47, primals_48, primals_45, primals_46, True, 0.1, 1e-05);  primals_48 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_2, primals_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_49, 1);  primals_49 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_52, primals_53, primals_50, primals_51, True, 0.1, 1e-05);  primals_53 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_3, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_2 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_54, 1);  primals_54 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(cat_default_2, primals_57, primals_58, primals_55, primals_56, True, 0.1, 1e-05);  primals_58 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_4, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_59, 1);  primals_59 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_62, primals_63, primals_60, primals_61, True, 0.1, 1e-05);  primals_63 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_5, primals_20, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_64, 1);  primals_64 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_67, primals_68, primals_65, primals_66, True, 0.1, 1e-05);  primals_68 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_6, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_69, 1);  primals_69 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_72, primals_73, primals_70, primals_71, True, 0.1, 1e-05);  primals_73 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_7, primals_22, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_4 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_74, 1);  primals_74 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(cat_default_4, primals_77, primals_78, primals_75, primals_76, True, 0.1, 1e-05);  primals_78 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_8, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_79, 1);  primals_79 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_82, primals_83, primals_80, primals_81, True, 0.1, 1e-05);  primals_83 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_9, primals_24, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_5 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_84, 1);  primals_84 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(cat_default_5, primals_87, primals_88, primals_85, primals_86, True, 0.1, 1e-05);  primals_88 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_10, primals_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_89, 1);  primals_89 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_92, primals_93, primals_90, primals_91, True, 0.1, 1e-05);  primals_93 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_33);  getitem_33 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_11, primals_26, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_6 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_94, 1);  primals_94 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(cat_default_6, primals_97, primals_98, primals_95, primals_96, True, 0.1, 1e-05);  primals_98 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_12, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_99, 1);  primals_99 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_102, primals_103, primals_100, primals_101, True, 0.1, 1e-05);  primals_103 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_13, primals_28, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_7 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_104, 1);  primals_104 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(cat_default_7, primals_107, primals_108, primals_105, primals_106, True, 0.1, 1e-05);  primals_108 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_42);  getitem_42 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_14, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_109, 1);  primals_109 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_112, primals_113, primals_110, primals_111, True, 0.1, 1e-05);  primals_113 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_15, primals_30, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_8 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_114, 1);  primals_114 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(cat_default_8, primals_117, primals_118, primals_115, primals_116, True, 0.1, 1e-05);  primals_118 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_16, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_119, 1);  primals_119 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_122, primals_123, primals_120, primals_121, True, 0.1, 1e-05);  primals_123 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_51);  getitem_51 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_17, primals_32, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_9 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_124, 1);  primals_124 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(cat_default_9, primals_127, primals_128, primals_125, primals_126, True, 0.1, 1e-05);  primals_128 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_18, primals_1, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_129, 1);  primals_129 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_132, primals_133, primals_130, primals_131, True, 0.1, 1e-05);  primals_133 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_19, primals_2, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_10 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_134, 1);  primals_134 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(cat_default_10, primals_137, primals_138, primals_135, primals_136, True, 0.1, 1e-05);  primals_138 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_20, primals_3, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_139, 1);  primals_139 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_142, primals_143, primals_140, primals_141, True, 0.1, 1e-05);  primals_143 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_63);  getitem_63 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_21, primals_4, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_11 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_144, 1);  primals_144 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(cat_default_11, primals_147, primals_148, primals_145, primals_146, True, 0.1, 1e-05);  primals_148 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_22, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_149, 1);  primals_149 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_152, primals_153, primals_150, primals_151, True, 0.1, 1e-05);  primals_153 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_23, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_12 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_154, 1);  primals_154 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(cat_default_12, primals_157, primals_158, primals_155, primals_156, True, 0.1, 1e-05);  primals_158 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_24, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_159, 1);  primals_159 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_162, primals_163, primals_160, primals_161, True, 0.1, 1e-05);  primals_163 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_25, primals_8, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_13 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_164, 1);  primals_164 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(cat_default_13, primals_167, primals_168, primals_165, primals_166, True, 0.1, 1e-05);  primals_168 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_26, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_27 = torch.ops.aten.add.Tensor(primals_169, 1);  primals_169 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_172, primals_173, primals_170, primals_171, True, 0.1, 1e-05);  primals_173 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_81);  getitem_81 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_27, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_14 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_174, 1);  primals_174 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(cat_default_14, primals_177, primals_178, primals_175, primals_176, True, 0.1, 1e-05);  primals_178 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_84);  getitem_84 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_28, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_179, 1);  primals_179 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_182, primals_183, primals_180, primals_181, True, 0.1, 1e-05);  primals_183 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_29, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_15 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27, convolution_default_29], 1)
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_184, 1);  primals_184 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(cat_default_15, primals_187, primals_188, primals_185, primals_186, True, 0.1, 1e-05);  primals_188 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_30, primals_13, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_189, 1);  primals_189 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_192, primals_193, primals_190, primals_191, True, 0.1, 1e-05);  primals_193 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_31, primals_14, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_16 = torch.ops.aten.cat.default([primals_33, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23, convolution_default_25, convolution_default_27, convolution_default_29, convolution_default_31], 1);  primals_33 = convolution_default_1 = convolution_default_3 = convolution_default_5 = convolution_default_7 = convolution_default_9 = convolution_default_11 = convolution_default_13 = convolution_default_15 = convolution_default_17 = convolution_default_19 = convolution_default_21 = convolution_default_23 = convolution_default_25 = convolution_default_27 = convolution_default_29 = convolution_default_31 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_194, 1);  primals_194 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(cat_default_16, primals_197, primals_198, primals_195, primals_196, True, 0.1, 1e-05);  primals_198 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        return [relu__default_32, add_tensor_32, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_25, add_tensor_26, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_31, relu__default_18, primals_146, getitem_23, getitem_89, relu__default_23, getitem_35, getitem_34, primals_150, primals_77, getitem_8, getitem_7, primals_155, relu__default_11, primals_76, cat_default_6, relu__default_1, relu__default_7, primals_72, primals_147, primals_156, cat_default_4, getitem_5, getitem_95, getitem_22, primals_152, relu__default_31, cat_default, primals_151, getitem_4, primals_75, primals_71, cat_default_1, primals_145, getitem_88, getitem_37, convolution_default_24, getitem_1, getitem_74, relu__default_25, getitem_11, getitem_10, getitem_77, relu__default_3, getitem_2, getitem_79, relu__default, convolution_default, cat_default_2, convolution_default_26, getitem_80, relu__default_24, getitem_73, getitem_76, cat_default_13, relu__default_26, relu__default_8, cat_default_11, getitem_62, primals_101, getitem_38, primals_175, cat_default_7, primals_170, relu__default_12, primals_172, primals_102, primals_100, primals_165, getitem_40, primals_167, relu__default_13, convolution_default_12, primals_166, primals_177, primals_176, primals_171, getitem_41, primals_106, primals_116, relu__default_21, relu__default_27, cat_default_12, getitem_65, getitem_86, getitem_91, primals_110, primals_112, relu__default_28, getitem_83, primals_115, getitem_25, relu__default_30, getitem_26, getitem_85, primals_117, convolution_default_8, cat_default_5, convolution_default_30, cat_default_14, primals_107, primals_111, convolution_default_28, getitem_71, getitem_92, cat_default_16, getitem_70, primals_105, getitem_82, primals_22, primals_36, primals_12, primals_20, getitem_50, cat_default_8, convolution_default_16, primals_9, primals_24, primals_29, primals_17, relu__default_15, primals_8, primals_6, primals_27, getitem_46, getitem_61, getitem_31, primals_18, getitem_32, primals_15, getitem_47, primals_23, primals_26, primals_19, primals_30, primals_21, primals_14, relu__default_16, primals_7, primals_11, getitem_94, primals_13, primals_28, primals_16, primals_37, primals_32, primals_10, primals_35, primals_25, relu__default_19, primals_31, relu__default_17, getitem_98, primals_127, primals_161, getitem_29, getitem_64, primals_120, primals_122, primals_126, primals_121, primals_160, relu__default_10, primals_132, primals_131, getitem_67, primals_130, cat_default_9, convolution_default_2, primals_125, primals_157, primals_162, convolution_default_22, getitem_53, getitem_68, relu__default_2, convolution_default_10, relu__default_9, cat_default_10, getitem_28, relu__default_5, cat_default_15, primals_66, getitem_13, primals_51, primals_45, relu__default_4, primals_192, getitem_19, primals_41, primals_191, primals_62, primals_186, primals_61, convolution_default_20, primals_50, primals_185, primals_190, relu__default_6, primals_42, primals_182, getitem_14, getitem_58, primals_67, primals_70, getitem_20, getitem_17, convolution_default_4, primals_56, primals_187, primals_180, getitem_49, relu__default_29, getitem_16, primals_55, primals_40, primals_181, relu__default_20, primals_46, primals_47, primals_65, convolution_default_6, cat_default_3, primals_57, primals_60, primals_52, primals_87, primals_135, getitem_56, primals_96, primals_81, getitem_59, primals_82, getitem_44, primals_1, primals_136, getitem_43, getitem_97, primals_86, primals_2, relu__default_22, primals_140, primals_3, primals_95, primals_196, primals_141, primals_5, primals_137, relu__default_32, primals_91, convolution_default_18, primals_4, primals_142, convolution_default_14, getitem_55, primals_90, primals_85, primals_97, primals_80, relu__default_14, primals_92, primals_195, getitem_52, primals_197]
        
