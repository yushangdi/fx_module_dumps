
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_forward_10/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2):
        convolution_default = torch.ops.aten.convolution.default(primals_2, primals_1, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(convolution_default, [2, 2], [2, 2])
        return [avg_pool2d_default, primals_1, convolution_default, primals_2]
        
