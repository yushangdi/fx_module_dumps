
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_forward_2/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73):
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(primals_13, [3, 3], [2, 2], [1, 1])
        getitem = max_pool2d_with_indices_default[0]
        getitem_1 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        cat_default = torch.ops.aten.cat.default([getitem], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_14, 1);  primals_14 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(cat_default, primals_17, primals_18, primals_15, primals_16, True, 0.1, 1e-05);  primals_18 = None
        getitem_2 = native_batch_norm_default[0]
        getitem_3 = native_batch_norm_default[1]
        getitem_4 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem_2);  getitem_2 = None
        convolution_default = torch.ops.aten.convolution.default(relu__default, primals_1, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_19, 1);  primals_19 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default, primals_22, primals_23, primals_20, primals_21, True, 0.1, 1e-05);  primals_23 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default_1, primals_2, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_1 = torch.ops.aten.cat.default([getitem, convolution_default_1], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_24, 1);  primals_24 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_27, primals_28, primals_25, primals_26, True, 0.1, 1e-05);  primals_28 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_2, primals_3, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_29, 1);  primals_29 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_32, primals_33, primals_30, primals_31, True, 0.1, 1e-05);  primals_33 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_3, primals_4, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_2 = torch.ops.aten.cat.default([getitem, convolution_default_1, convolution_default_3], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_34, 1);  primals_34 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(cat_default_2, primals_37, primals_38, primals_35, primals_36, True, 0.1, 1e-05);  primals_38 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_4, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_39, 1);  primals_39 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_42, primals_43, primals_40, primals_41, True, 0.1, 1e-05);  primals_43 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_5, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([getitem, convolution_default_1, convolution_default_3, convolution_default_5], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_44, 1);  primals_44 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_47, primals_48, primals_45, primals_46, True, 0.1, 1e-05);  primals_48 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_6, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_49, 1);  primals_49 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_52, primals_53, primals_50, primals_51, True, 0.1, 1e-05);  primals_53 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_7, primals_8, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_4 = torch.ops.aten.cat.default([getitem, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_54, 1);  primals_54 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(cat_default_4, primals_57, primals_58, primals_55, primals_56, True, 0.1, 1e-05);  primals_58 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_8, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_59, 1);  primals_59 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_62, primals_63, primals_60, primals_61, True, 0.1, 1e-05);  primals_63 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_9, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_5 = torch.ops.aten.cat.default([getitem, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_64, 1);  primals_64 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(cat_default_5, primals_67, primals_68, primals_65, primals_66, True, 0.1, 1e-05);  primals_68 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_10, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_69, 1);  primals_69 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_72, primals_73, primals_70, primals_71, True, 0.1, 1e-05);  primals_73 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_11, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_6 = torch.ops.aten.cat.default([getitem, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11], 1);  getitem = convolution_default_1 = convolution_default_3 = convolution_default_5 = convolution_default_7 = convolution_default_9 = convolution_default_11 = None
        return [cat_default_6, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, add_tensor_11, primals_8, getitem_15, primals_10, primals_27, getitem_16, relu__default_8, primals_13, primals_55, getitem_9, primals_11, convolution_default_8, primals_32, primals_21, getitem_37, getitem_10, primals_5, getitem_36, relu__default_4, primals_30, primals_52, getitem_31, primals_41, convolution_default_4, primals_4, getitem_30, relu__default_2, primals_66, primals_7, convolution_default_2, relu__default_11, primals_2, primals_65, primals_31, getitem_19, primals_17, getitem_18, primals_1, primals_51, relu__default_9, getitem_13, primals_16, primals_25, getitem_12, getitem_34, primals_12, primals_3, primals_9, relu__default_5, primals_67, primals_26, primals_20, relu__default_3, getitem_33, relu__default_10, cat_default_5, convolution_default_10, cat_default_2, primals_22, primals_6, primals_15, cat_default_3, getitem_1, getitem_21, primals_70, getitem_22, primals_47, primals_61, relu__default_6, primals_56, getitem_3, convolution_default_6, getitem_4, getitem_25, primals_50, primals_72, primals_36, getitem_24, primals_71, primals_57, relu__default, convolution_default, cat_default, relu__default_7, primals_60, getitem_7, primals_40, getitem_6, primals_35, primals_62, cat_default_1, getitem_27, primals_45, relu__default_1, primals_42, cat_default_4, getitem_28, primals_37, primals_46]
        
