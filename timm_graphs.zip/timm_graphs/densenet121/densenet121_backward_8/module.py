
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_backward_8/state_dict.pt'))

    
    
    def forward(self, convolution_default_44, getitem_80, getitem_133, relu__default_11, getitem_134, getitem_37, relu__default_3, getitem_14, relu__default_44, getitem_137, relu__default_4, getitem_101, cat_default_23, convolution_default_12, relu__default_12, relu__default_33, primals_192, primals_52, relu__default_26, primals_197, primals_193, cat_default_2, getitem_79, primals_51, getitem_40, primals_53, getitem_100, getitem_13, primals_196, primals_56, primals_198, relu__default_45, getitem_103, getitem_11, getitem_136, convolution_default_26, cat_default_17, getitem_10, convolution_default_4, getitem_38, getitem_41, relu__default_24, primals_102, primals_141, primals_136, getitem_76, convolution_default_24, primals_121, primals_106, cat_default_13, primals_123, primals_138, primals_137, getitem_74, primals_103, primals_118, relu__default_25, primals_122, getitem_77, getitem_44, relu__default_15, getitem_49, relu__default_16, getitem_82, primals_263, cat_default_7, primals_166, relu__default_35, primals_266, getitem_50, relu__default_28, relu__default_14, cat_default_15, convolution_default_36, getitem_110, primals_267, primals_153, primals_71, primals_261, cat_default_14, convolution_default_28, getitem_109, primals_66, cat_default_19, getitem_61, getitem_112, primals_158, primals_262, relu__default_13, cat_default_8, getitem_47, getitem_88, relu__default_37, relu__default_27, getitem_86, cat_default_10, primals_156, getitem_62, relu__default_36, getitem_113, primals_68, primals_152, getitem_59, getitem_89, primals_157, convolution_default_14, relu__default_19, relu__default_29, primals_167, getitem_46, primals_67, getitem_43, convolution_default_16, getitem_85, primals_271, getitem_83, primals_268, primals_177, getitem_31, cat_default_9, primals_171, primals_168, primals_172, cat_default_6, relu__default_6, primals_182, convolution_default, getitem_104, convolution_default_18, primals_186, relu__default_10, cat_default_18, getitem_53, getitem_107, relu__default_17, getitem_20, getitem_23, getitem_25, getitem_1, convolution_default_34, cat_default_4, getitem_52, getitem_4, relu__default_7, primals_176, getitem_106, getitem_22, relu__default_18, getitem_35, getitem_32, getitem_2, convolution_default_6, cat_default, getitem_5, primals_183, relu__default, primals_181, primals_188, getitem_56, primals_178, primals_187, getitem_34, convolution_default_10, primals_191, relu__default_34, primals_173, getitem_55, getitem_125, getitem_17, primals_107, getitem_140, primals_86, primals_43, primals_41, relu__default_9, getitem_98, primals_87, getitem_121, primals_117, getitem_68, primals_111, relu__default_32, primals_46, primals_45, relu__default_8, getitem_124, getitem_143, getitem_19, getitem_58, primals_40, relu__default_43, primals_112, relu__default_22, cat_default_21, getitem_131, cat_default_16, primals_217, cat_default_11, getitem_94, getitem_64, relu__default_47, primals_42, relu__default_20, convolution_default_32, primals_48, cat_default_3, getitem_29, primals_81, getitem_142, convolution_default_46, primals_216, getitem_95, relu__default_40, primals_116, getitem_97, getitem_130, primals_258, relu__default_21, primals_108, primals_218, primals_83, getitem_65, convolution_default_20, primals_44, primals_47, cat_default_5, convolution_default_8, getitem_67, cat_default_22, primals_113, getitem_139, primals_82, relu__default_5, relu__default_41, convolution_default_40, getitem_28, convolution_default_22, getitem_122, relu__default_31, getitem_26, relu__default_46, primals_221, getitem_16, relu__default_38, primals_93, getitem_119, primals_14, primals_32, primals_126, getitem_116, primals_18, primals_19, getitem_70, primals_96, primals_63, primals_73, primals_16, primals_33, primals_58, primals_132, getitem_71, primals_39, primals_31, primals_28, primals_72, primals_76, primals_92, getitem_73, primals_78, getitem_115, relu__default_23, primals_36, primals_30, cat_default_12, convolution_default_30, primals_29, relu__default_30, primals_26, getitem_91, primals_27, primals_127, primals_34, relu__default_39, primals_62, primals_37, primals_25, primals_21, primals_131, primals_17, primals_38, primals_97, primals_101, primals_22, primals_57, primals_133, primals_61, primals_98, primals_15, convolution_default_38, primals_23, primals_20, primals_77, getitem_118, primals_24, getitem_92, primals_35, primals_128, cat_default_20, primals_10, primals_257, primals_6, primals_248, primals_272, primals_3, primals_13, primals_88, primals_163, primals_253, primals_12, primals_151, primals_162, primals_252, primals_1, primals_251, primals_91, primals_256, primals_148, primals_143, primals_146, primals_161, primals_9, primals_247, primals_273, primals_5, primals_147, primals_4, primals_7, primals_11, primals_8, primals_2, primals_142, getitem_127, primals_241, primals_242, primals_243, relu__default_2, primals_201, primals_208, primals_283, primals_212, primals_222, primals_277, primals_206, primals_246, relu__default_42, primals_282, primals_203, primals_207, primals_202, primals_238, primals_281, primals_278, getitem_128, primals_213, convolution_default_42, getitem_8, getitem_7, primals_211, primals_237, relu__default_1, primals_236, convolution_default_2, primals_286, primals_276, cat_default_1, primals_233, primals_232, primals_288, primals_226, primals_223, primals_231, primals_228, primals_287, primals_227, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49):
        slice_tensor = torch.ops.aten.slice.Tensor(tangents_1, 1, 0, 256)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(tangents_1, 1, 256, 288)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(tangents_1, 1, 288, 320)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(tangents_1, 1, 320, 352)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(tangents_1, 1, 352, 384)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(tangents_1, 1, 384, 416)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(tangents_1, 1, 416, 448)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(tangents_1, 1, 448, 480)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(tangents_1, 1, 480, 512)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(tangents_1, 1, 512, 544)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(tangents_1, 1, 544, 576)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(tangents_1, 1, 576, 608)
        slice_tensor_12 = torch.ops.aten.slice.Tensor(tangents_1, 1, 608, 640)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(tangents_1, 1, 640, 672)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(tangents_1, 1, 672, 704)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(tangents_1, 1, 704, 736)
        slice_tensor_16 = torch.ops.aten.slice.Tensor(tangents_1, 1, 736, 768)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(tangents_1, 1, 768, 800)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(tangents_1, 1, 800, 832)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(tangents_1, 1, 832, 864)
        slice_tensor_20 = torch.ops.aten.slice.Tensor(tangents_1, 1, 864, 896)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(tangents_1, 1, 896, 928)
        slice_tensor_22 = torch.ops.aten.slice.Tensor(tangents_1, 1, 928, 960)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(tangents_1, 1, 960, 992)
        slice_tensor_24 = torch.ops.aten.slice.Tensor(tangents_1, 1, 992, 1024);  tangents_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(slice_tensor_24, relu__default_47, primals_32, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_24 = primals_32 = None
        getitem_144 = convolution_backward_default[0]
        getitem_145 = convolution_backward_default[1];  convolution_backward_default = None
        to_dtype = torch.ops.aten.to.dtype(getitem_144, torch.float32);  getitem_144 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_48, to_dtype);  le_scalar = new_zeros_default_48 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_46, primals_288, primals_286, primals_287, getitem_142, getitem_143, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_46 = primals_288 = primals_286 = primals_287 = getitem_142 = getitem_143 = None
        getitem_147 = native_batch_norm_backward_default[0]
        getitem_148 = native_batch_norm_backward_default[1]
        getitem_149 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_147, relu__default_46, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_147 = primals_31 = None
        getitem_150 = convolution_backward_default_1[0]
        getitem_151 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_150, torch.float32);  getitem_150 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_49, to_dtype_3);  le_scalar_1 = new_zeros_default_49 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, cat_default_23, primals_283, primals_281, primals_282, getitem_139, getitem_140, True, 1e-05, [True, True, True]);  to_dtype_5 = cat_default_23 = primals_283 = primals_281 = primals_282 = getitem_139 = getitem_140 = None
        getitem_153 = native_batch_norm_backward_default_1[0]
        getitem_154 = native_batch_norm_backward_default_1[1]
        getitem_155 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        slice_tensor_25 = torch.ops.aten.slice.Tensor(getitem_153, 1, 0, 256)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(getitem_153, 1, 256, 288)
        slice_tensor_27 = torch.ops.aten.slice.Tensor(getitem_153, 1, 288, 320)
        slice_tensor_28 = torch.ops.aten.slice.Tensor(getitem_153, 1, 320, 352)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(getitem_153, 1, 352, 384)
        slice_tensor_30 = torch.ops.aten.slice.Tensor(getitem_153, 1, 384, 416)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(getitem_153, 1, 416, 448)
        slice_tensor_32 = torch.ops.aten.slice.Tensor(getitem_153, 1, 448, 480)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(getitem_153, 1, 480, 512)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(getitem_153, 1, 512, 544)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(getitem_153, 1, 544, 576)
        slice_tensor_36 = torch.ops.aten.slice.Tensor(getitem_153, 1, 576, 608)
        slice_tensor_37 = torch.ops.aten.slice.Tensor(getitem_153, 1, 608, 640)
        slice_tensor_38 = torch.ops.aten.slice.Tensor(getitem_153, 1, 640, 672)
        slice_tensor_39 = torch.ops.aten.slice.Tensor(getitem_153, 1, 672, 704)
        slice_tensor_40 = torch.ops.aten.slice.Tensor(getitem_153, 1, 704, 736)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(getitem_153, 1, 736, 768)
        slice_tensor_42 = torch.ops.aten.slice.Tensor(getitem_153, 1, 768, 800)
        slice_tensor_43 = torch.ops.aten.slice.Tensor(getitem_153, 1, 800, 832)
        slice_tensor_44 = torch.ops.aten.slice.Tensor(getitem_153, 1, 832, 864)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(getitem_153, 1, 864, 896)
        slice_tensor_46 = torch.ops.aten.slice.Tensor(getitem_153, 1, 896, 928)
        slice_tensor_47 = torch.ops.aten.slice.Tensor(getitem_153, 1, 928, 960)
        slice_tensor_48 = torch.ops.aten.slice.Tensor(getitem_153, 1, 960, 992);  getitem_153 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(slice_tensor, slice_tensor_25);  slice_tensor = slice_tensor_25 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(slice_tensor_1, slice_tensor_26);  slice_tensor_1 = slice_tensor_26 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(slice_tensor_2, slice_tensor_27);  slice_tensor_2 = slice_tensor_27 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(slice_tensor_3, slice_tensor_28);  slice_tensor_3 = slice_tensor_28 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(slice_tensor_4, slice_tensor_29);  slice_tensor_4 = slice_tensor_29 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(slice_tensor_5, slice_tensor_30);  slice_tensor_5 = slice_tensor_30 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(slice_tensor_6, slice_tensor_31);  slice_tensor_6 = slice_tensor_31 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(slice_tensor_7, slice_tensor_32);  slice_tensor_7 = slice_tensor_32 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(slice_tensor_8, slice_tensor_33);  slice_tensor_8 = slice_tensor_33 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(slice_tensor_9, slice_tensor_34);  slice_tensor_9 = slice_tensor_34 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(slice_tensor_10, slice_tensor_35);  slice_tensor_10 = slice_tensor_35 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(slice_tensor_11, slice_tensor_36);  slice_tensor_11 = slice_tensor_36 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(slice_tensor_12, slice_tensor_37);  slice_tensor_12 = slice_tensor_37 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(slice_tensor_13, slice_tensor_38);  slice_tensor_13 = slice_tensor_38 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(slice_tensor_14, slice_tensor_39);  slice_tensor_14 = slice_tensor_39 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(slice_tensor_15, slice_tensor_40);  slice_tensor_15 = slice_tensor_40 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(slice_tensor_16, slice_tensor_41);  slice_tensor_16 = slice_tensor_41 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(slice_tensor_17, slice_tensor_42);  slice_tensor_17 = slice_tensor_42 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(slice_tensor_18, slice_tensor_43);  slice_tensor_18 = slice_tensor_43 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(slice_tensor_19, slice_tensor_44);  slice_tensor_19 = slice_tensor_44 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(slice_tensor_20, slice_tensor_45);  slice_tensor_20 = slice_tensor_45 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(slice_tensor_21, slice_tensor_46);  slice_tensor_21 = slice_tensor_46 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(slice_tensor_22, slice_tensor_47);  slice_tensor_22 = slice_tensor_47 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(slice_tensor_23, slice_tensor_48);  slice_tensor_23 = slice_tensor_48 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(add_tensor_71, relu__default_45, primals_30, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_71 = primals_30 = None
        getitem_156 = convolution_backward_default_2[0]
        getitem_157 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_156, torch.float32);  getitem_156 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_50, to_dtype_6);  le_scalar_2 = new_zeros_default_50 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_44, primals_278, primals_276, primals_277, getitem_136, getitem_137, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_44 = primals_278 = primals_276 = primals_277 = getitem_136 = getitem_137 = None
        getitem_159 = native_batch_norm_backward_default_2[0]
        getitem_160 = native_batch_norm_backward_default_2[1]
        getitem_161 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_159, relu__default_44, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_159 = primals_29 = None
        getitem_162 = convolution_backward_default_3[0]
        getitem_163 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_162, torch.float32);  getitem_162 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_51, to_dtype_9);  le_scalar_3 = new_zeros_default_51 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, cat_default_22, primals_273, primals_271, primals_272, getitem_133, getitem_134, True, 1e-05, [True, True, True]);  to_dtype_11 = cat_default_22 = primals_273 = primals_271 = primals_272 = getitem_133 = getitem_134 = None
        getitem_165 = native_batch_norm_backward_default_3[0]
        getitem_166 = native_batch_norm_backward_default_3[1]
        getitem_167 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        slice_tensor_49 = torch.ops.aten.slice.Tensor(getitem_165, 1, 0, 256)
        slice_tensor_50 = torch.ops.aten.slice.Tensor(getitem_165, 1, 256, 288)
        slice_tensor_51 = torch.ops.aten.slice.Tensor(getitem_165, 1, 288, 320)
        slice_tensor_52 = torch.ops.aten.slice.Tensor(getitem_165, 1, 320, 352)
        slice_tensor_53 = torch.ops.aten.slice.Tensor(getitem_165, 1, 352, 384)
        slice_tensor_54 = torch.ops.aten.slice.Tensor(getitem_165, 1, 384, 416)
        slice_tensor_55 = torch.ops.aten.slice.Tensor(getitem_165, 1, 416, 448)
        slice_tensor_56 = torch.ops.aten.slice.Tensor(getitem_165, 1, 448, 480)
        slice_tensor_57 = torch.ops.aten.slice.Tensor(getitem_165, 1, 480, 512)
        slice_tensor_58 = torch.ops.aten.slice.Tensor(getitem_165, 1, 512, 544)
        slice_tensor_59 = torch.ops.aten.slice.Tensor(getitem_165, 1, 544, 576)
        slice_tensor_60 = torch.ops.aten.slice.Tensor(getitem_165, 1, 576, 608)
        slice_tensor_61 = torch.ops.aten.slice.Tensor(getitem_165, 1, 608, 640)
        slice_tensor_62 = torch.ops.aten.slice.Tensor(getitem_165, 1, 640, 672)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(getitem_165, 1, 672, 704)
        slice_tensor_64 = torch.ops.aten.slice.Tensor(getitem_165, 1, 704, 736)
        slice_tensor_65 = torch.ops.aten.slice.Tensor(getitem_165, 1, 736, 768)
        slice_tensor_66 = torch.ops.aten.slice.Tensor(getitem_165, 1, 768, 800)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(getitem_165, 1, 800, 832)
        slice_tensor_68 = torch.ops.aten.slice.Tensor(getitem_165, 1, 832, 864)
        slice_tensor_69 = torch.ops.aten.slice.Tensor(getitem_165, 1, 864, 896)
        slice_tensor_70 = torch.ops.aten.slice.Tensor(getitem_165, 1, 896, 928)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(getitem_165, 1, 928, 960);  getitem_165 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(add_tensor_48, slice_tensor_49);  add_tensor_48 = slice_tensor_49 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(add_tensor_49, slice_tensor_50);  add_tensor_49 = slice_tensor_50 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(add_tensor_50, slice_tensor_51);  add_tensor_50 = slice_tensor_51 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(add_tensor_51, slice_tensor_52);  add_tensor_51 = slice_tensor_52 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(add_tensor_52, slice_tensor_53);  add_tensor_52 = slice_tensor_53 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(add_tensor_53, slice_tensor_54);  add_tensor_53 = slice_tensor_54 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(add_tensor_54, slice_tensor_55);  add_tensor_54 = slice_tensor_55 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(add_tensor_55, slice_tensor_56);  add_tensor_55 = slice_tensor_56 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(add_tensor_56, slice_tensor_57);  add_tensor_56 = slice_tensor_57 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(add_tensor_57, slice_tensor_58);  add_tensor_57 = slice_tensor_58 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(add_tensor_58, slice_tensor_59);  add_tensor_58 = slice_tensor_59 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(add_tensor_59, slice_tensor_60);  add_tensor_59 = slice_tensor_60 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(add_tensor_60, slice_tensor_61);  add_tensor_60 = slice_tensor_61 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(add_tensor_61, slice_tensor_62);  add_tensor_61 = slice_tensor_62 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(add_tensor_62, slice_tensor_63);  add_tensor_62 = slice_tensor_63 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(add_tensor_63, slice_tensor_64);  add_tensor_63 = slice_tensor_64 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(add_tensor_64, slice_tensor_65);  add_tensor_64 = slice_tensor_65 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(add_tensor_65, slice_tensor_66);  add_tensor_65 = slice_tensor_66 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(add_tensor_66, slice_tensor_67);  add_tensor_66 = slice_tensor_67 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(add_tensor_67, slice_tensor_68);  add_tensor_67 = slice_tensor_68 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(add_tensor_68, slice_tensor_69);  add_tensor_68 = slice_tensor_69 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(add_tensor_69, slice_tensor_70);  add_tensor_69 = slice_tensor_70 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(add_tensor_70, slice_tensor_71);  add_tensor_70 = slice_tensor_71 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(add_tensor_94, relu__default_43, primals_28, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_94 = primals_28 = None
        getitem_168 = convolution_backward_default_4[0]
        getitem_169 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_168, torch.float32);  getitem_168 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_52, to_dtype_12);  le_scalar_4 = new_zeros_default_52 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_42, primals_268, primals_266, primals_267, getitem_130, getitem_131, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_42 = primals_268 = primals_266 = primals_267 = getitem_130 = getitem_131 = None
        getitem_171 = native_batch_norm_backward_default_4[0]
        getitem_172 = native_batch_norm_backward_default_4[1]
        getitem_173 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_171, relu__default_42, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_171 = primals_27 = None
        getitem_174 = convolution_backward_default_5[0]
        getitem_175 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_174, torch.float32);  getitem_174 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_53, to_dtype_15);  le_scalar_5 = new_zeros_default_53 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, cat_default_21, primals_263, primals_261, primals_262, getitem_127, getitem_128, True, 1e-05, [True, True, True]);  to_dtype_17 = cat_default_21 = primals_263 = primals_261 = primals_262 = getitem_127 = getitem_128 = None
        getitem_177 = native_batch_norm_backward_default_5[0]
        getitem_178 = native_batch_norm_backward_default_5[1]
        getitem_179 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        slice_tensor_72 = torch.ops.aten.slice.Tensor(getitem_177, 1, 0, 256)
        slice_tensor_73 = torch.ops.aten.slice.Tensor(getitem_177, 1, 256, 288)
        slice_tensor_74 = torch.ops.aten.slice.Tensor(getitem_177, 1, 288, 320)
        slice_tensor_75 = torch.ops.aten.slice.Tensor(getitem_177, 1, 320, 352)
        slice_tensor_76 = torch.ops.aten.slice.Tensor(getitem_177, 1, 352, 384)
        slice_tensor_77 = torch.ops.aten.slice.Tensor(getitem_177, 1, 384, 416)
        slice_tensor_78 = torch.ops.aten.slice.Tensor(getitem_177, 1, 416, 448)
        slice_tensor_79 = torch.ops.aten.slice.Tensor(getitem_177, 1, 448, 480)
        slice_tensor_80 = torch.ops.aten.slice.Tensor(getitem_177, 1, 480, 512)
        slice_tensor_81 = torch.ops.aten.slice.Tensor(getitem_177, 1, 512, 544)
        slice_tensor_82 = torch.ops.aten.slice.Tensor(getitem_177, 1, 544, 576)
        slice_tensor_83 = torch.ops.aten.slice.Tensor(getitem_177, 1, 576, 608)
        slice_tensor_84 = torch.ops.aten.slice.Tensor(getitem_177, 1, 608, 640)
        slice_tensor_85 = torch.ops.aten.slice.Tensor(getitem_177, 1, 640, 672)
        slice_tensor_86 = torch.ops.aten.slice.Tensor(getitem_177, 1, 672, 704)
        slice_tensor_87 = torch.ops.aten.slice.Tensor(getitem_177, 1, 704, 736)
        slice_tensor_88 = torch.ops.aten.slice.Tensor(getitem_177, 1, 736, 768)
        slice_tensor_89 = torch.ops.aten.slice.Tensor(getitem_177, 1, 768, 800)
        slice_tensor_90 = torch.ops.aten.slice.Tensor(getitem_177, 1, 800, 832)
        slice_tensor_91 = torch.ops.aten.slice.Tensor(getitem_177, 1, 832, 864)
        slice_tensor_92 = torch.ops.aten.slice.Tensor(getitem_177, 1, 864, 896)
        slice_tensor_93 = torch.ops.aten.slice.Tensor(getitem_177, 1, 896, 928);  getitem_177 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_72, slice_tensor_72);  add_tensor_72 = slice_tensor_72 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(add_tensor_73, slice_tensor_73);  add_tensor_73 = slice_tensor_73 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(add_tensor_74, slice_tensor_74);  add_tensor_74 = slice_tensor_74 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(add_tensor_75, slice_tensor_75);  add_tensor_75 = slice_tensor_75 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(add_tensor_76, slice_tensor_76);  add_tensor_76 = slice_tensor_76 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(add_tensor_77, slice_tensor_77);  add_tensor_77 = slice_tensor_77 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(add_tensor_78, slice_tensor_78);  add_tensor_78 = slice_tensor_78 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(add_tensor_79, slice_tensor_79);  add_tensor_79 = slice_tensor_79 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(add_tensor_80, slice_tensor_80);  add_tensor_80 = slice_tensor_80 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(add_tensor_81, slice_tensor_81);  add_tensor_81 = slice_tensor_81 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(add_tensor_82, slice_tensor_82);  add_tensor_82 = slice_tensor_82 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(add_tensor_83, slice_tensor_83);  add_tensor_83 = slice_tensor_83 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(add_tensor_84, slice_tensor_84);  add_tensor_84 = slice_tensor_84 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(add_tensor_85, slice_tensor_85);  add_tensor_85 = slice_tensor_85 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(add_tensor_86, slice_tensor_86);  add_tensor_86 = slice_tensor_86 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(add_tensor_87, slice_tensor_87);  add_tensor_87 = slice_tensor_87 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(add_tensor_88, slice_tensor_88);  add_tensor_88 = slice_tensor_88 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(add_tensor_89, slice_tensor_89);  add_tensor_89 = slice_tensor_89 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(add_tensor_90, slice_tensor_90);  add_tensor_90 = slice_tensor_90 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(add_tensor_91, slice_tensor_91);  add_tensor_91 = slice_tensor_91 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(add_tensor_92, slice_tensor_92);  add_tensor_92 = slice_tensor_92 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(add_tensor_93, slice_tensor_93);  add_tensor_93 = slice_tensor_93 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(add_tensor_116, relu__default_41, primals_26, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_116 = primals_26 = None
        getitem_180 = convolution_backward_default_6[0]
        getitem_181 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_180, torch.float32);  getitem_180 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_54, to_dtype_18);  le_scalar_6 = new_zeros_default_54 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_40, primals_258, primals_256, primals_257, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_40 = primals_258 = primals_256 = primals_257 = getitem_124 = getitem_125 = None
        getitem_183 = native_batch_norm_backward_default_6[0]
        getitem_184 = native_batch_norm_backward_default_6[1]
        getitem_185 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_183, relu__default_40, primals_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_183 = primals_25 = None
        getitem_186 = convolution_backward_default_7[0]
        getitem_187 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_186, torch.float32);  getitem_186 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_55, to_dtype_21);  le_scalar_7 = new_zeros_default_55 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, cat_default_20, primals_253, primals_251, primals_252, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  to_dtype_23 = cat_default_20 = primals_253 = primals_251 = primals_252 = getitem_121 = getitem_122 = None
        getitem_189 = native_batch_norm_backward_default_7[0]
        getitem_190 = native_batch_norm_backward_default_7[1]
        getitem_191 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        slice_tensor_94 = torch.ops.aten.slice.Tensor(getitem_189, 1, 0, 256)
        slice_tensor_95 = torch.ops.aten.slice.Tensor(getitem_189, 1, 256, 288)
        slice_tensor_96 = torch.ops.aten.slice.Tensor(getitem_189, 1, 288, 320)
        slice_tensor_97 = torch.ops.aten.slice.Tensor(getitem_189, 1, 320, 352)
        slice_tensor_98 = torch.ops.aten.slice.Tensor(getitem_189, 1, 352, 384)
        slice_tensor_99 = torch.ops.aten.slice.Tensor(getitem_189, 1, 384, 416)
        slice_tensor_100 = torch.ops.aten.slice.Tensor(getitem_189, 1, 416, 448)
        slice_tensor_101 = torch.ops.aten.slice.Tensor(getitem_189, 1, 448, 480)
        slice_tensor_102 = torch.ops.aten.slice.Tensor(getitem_189, 1, 480, 512)
        slice_tensor_103 = torch.ops.aten.slice.Tensor(getitem_189, 1, 512, 544)
        slice_tensor_104 = torch.ops.aten.slice.Tensor(getitem_189, 1, 544, 576)
        slice_tensor_105 = torch.ops.aten.slice.Tensor(getitem_189, 1, 576, 608)
        slice_tensor_106 = torch.ops.aten.slice.Tensor(getitem_189, 1, 608, 640)
        slice_tensor_107 = torch.ops.aten.slice.Tensor(getitem_189, 1, 640, 672)
        slice_tensor_108 = torch.ops.aten.slice.Tensor(getitem_189, 1, 672, 704)
        slice_tensor_109 = torch.ops.aten.slice.Tensor(getitem_189, 1, 704, 736)
        slice_tensor_110 = torch.ops.aten.slice.Tensor(getitem_189, 1, 736, 768)
        slice_tensor_111 = torch.ops.aten.slice.Tensor(getitem_189, 1, 768, 800)
        slice_tensor_112 = torch.ops.aten.slice.Tensor(getitem_189, 1, 800, 832)
        slice_tensor_113 = torch.ops.aten.slice.Tensor(getitem_189, 1, 832, 864)
        slice_tensor_114 = torch.ops.aten.slice.Tensor(getitem_189, 1, 864, 896);  getitem_189 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(add_tensor_95, slice_tensor_94);  add_tensor_95 = slice_tensor_94 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(add_tensor_96, slice_tensor_95);  add_tensor_96 = slice_tensor_95 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(add_tensor_97, slice_tensor_96);  add_tensor_97 = slice_tensor_96 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(add_tensor_98, slice_tensor_97);  add_tensor_98 = slice_tensor_97 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(add_tensor_99, slice_tensor_98);  add_tensor_99 = slice_tensor_98 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(add_tensor_100, slice_tensor_99);  add_tensor_100 = slice_tensor_99 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(add_tensor_101, slice_tensor_100);  add_tensor_101 = slice_tensor_100 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(add_tensor_102, slice_tensor_101);  add_tensor_102 = slice_tensor_101 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(add_tensor_103, slice_tensor_102);  add_tensor_103 = slice_tensor_102 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(add_tensor_104, slice_tensor_103);  add_tensor_104 = slice_tensor_103 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(add_tensor_105, slice_tensor_104);  add_tensor_105 = slice_tensor_104 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(add_tensor_106, slice_tensor_105);  add_tensor_106 = slice_tensor_105 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(add_tensor_107, slice_tensor_106);  add_tensor_107 = slice_tensor_106 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(add_tensor_108, slice_tensor_107);  add_tensor_108 = slice_tensor_107 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(add_tensor_109, slice_tensor_108);  add_tensor_109 = slice_tensor_108 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(add_tensor_110, slice_tensor_109);  add_tensor_110 = slice_tensor_109 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_111, slice_tensor_110);  add_tensor_111 = slice_tensor_110 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(add_tensor_112, slice_tensor_111);  add_tensor_112 = slice_tensor_111 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(add_tensor_113, slice_tensor_112);  add_tensor_113 = slice_tensor_112 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(add_tensor_114, slice_tensor_113);  add_tensor_114 = slice_tensor_113 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(add_tensor_115, slice_tensor_114);  add_tensor_115 = slice_tensor_114 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(add_tensor_137, relu__default_39, primals_24, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_137 = primals_24 = None
        getitem_192 = convolution_backward_default_8[0]
        getitem_193 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_192, torch.float32);  getitem_192 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_56, to_dtype_24);  le_scalar_8 = new_zeros_default_56 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_38, primals_248, primals_246, primals_247, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_38 = primals_248 = primals_246 = primals_247 = getitem_118 = getitem_119 = None
        getitem_195 = native_batch_norm_backward_default_8[0]
        getitem_196 = native_batch_norm_backward_default_8[1]
        getitem_197 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_195, relu__default_38, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_195 = primals_23 = None
        getitem_198 = convolution_backward_default_9[0]
        getitem_199 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_198, torch.float32);  getitem_198 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_57, to_dtype_27);  le_scalar_9 = new_zeros_default_57 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, cat_default_19, primals_243, primals_241, primals_242, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  to_dtype_29 = cat_default_19 = primals_243 = primals_241 = primals_242 = getitem_115 = getitem_116 = None
        getitem_201 = native_batch_norm_backward_default_9[0]
        getitem_202 = native_batch_norm_backward_default_9[1]
        getitem_203 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        slice_tensor_115 = torch.ops.aten.slice.Tensor(getitem_201, 1, 0, 256)
        slice_tensor_116 = torch.ops.aten.slice.Tensor(getitem_201, 1, 256, 288)
        slice_tensor_117 = torch.ops.aten.slice.Tensor(getitem_201, 1, 288, 320)
        slice_tensor_118 = torch.ops.aten.slice.Tensor(getitem_201, 1, 320, 352)
        slice_tensor_119 = torch.ops.aten.slice.Tensor(getitem_201, 1, 352, 384)
        slice_tensor_120 = torch.ops.aten.slice.Tensor(getitem_201, 1, 384, 416)
        slice_tensor_121 = torch.ops.aten.slice.Tensor(getitem_201, 1, 416, 448)
        slice_tensor_122 = torch.ops.aten.slice.Tensor(getitem_201, 1, 448, 480)
        slice_tensor_123 = torch.ops.aten.slice.Tensor(getitem_201, 1, 480, 512)
        slice_tensor_124 = torch.ops.aten.slice.Tensor(getitem_201, 1, 512, 544)
        slice_tensor_125 = torch.ops.aten.slice.Tensor(getitem_201, 1, 544, 576)
        slice_tensor_126 = torch.ops.aten.slice.Tensor(getitem_201, 1, 576, 608)
        slice_tensor_127 = torch.ops.aten.slice.Tensor(getitem_201, 1, 608, 640)
        slice_tensor_128 = torch.ops.aten.slice.Tensor(getitem_201, 1, 640, 672)
        slice_tensor_129 = torch.ops.aten.slice.Tensor(getitem_201, 1, 672, 704)
        slice_tensor_130 = torch.ops.aten.slice.Tensor(getitem_201, 1, 704, 736)
        slice_tensor_131 = torch.ops.aten.slice.Tensor(getitem_201, 1, 736, 768)
        slice_tensor_132 = torch.ops.aten.slice.Tensor(getitem_201, 1, 768, 800)
        slice_tensor_133 = torch.ops.aten.slice.Tensor(getitem_201, 1, 800, 832)
        slice_tensor_134 = torch.ops.aten.slice.Tensor(getitem_201, 1, 832, 864);  getitem_201 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(add_tensor_117, slice_tensor_115);  add_tensor_117 = slice_tensor_115 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(add_tensor_118, slice_tensor_116);  add_tensor_118 = slice_tensor_116 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(add_tensor_119, slice_tensor_117);  add_tensor_119 = slice_tensor_117 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(add_tensor_120, slice_tensor_118);  add_tensor_120 = slice_tensor_118 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(add_tensor_121, slice_tensor_119);  add_tensor_121 = slice_tensor_119 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(add_tensor_122, slice_tensor_120);  add_tensor_122 = slice_tensor_120 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(add_tensor_123, slice_tensor_121);  add_tensor_123 = slice_tensor_121 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(add_tensor_124, slice_tensor_122);  add_tensor_124 = slice_tensor_122 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(add_tensor_125, slice_tensor_123);  add_tensor_125 = slice_tensor_123 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(add_tensor_126, slice_tensor_124);  add_tensor_126 = slice_tensor_124 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(add_tensor_127, slice_tensor_125);  add_tensor_127 = slice_tensor_125 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(add_tensor_128, slice_tensor_126);  add_tensor_128 = slice_tensor_126 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(add_tensor_129, slice_tensor_127);  add_tensor_129 = slice_tensor_127 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(add_tensor_130, slice_tensor_128);  add_tensor_130 = slice_tensor_128 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(add_tensor_131, slice_tensor_129);  add_tensor_131 = slice_tensor_129 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(add_tensor_132, slice_tensor_130);  add_tensor_132 = slice_tensor_130 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(add_tensor_133, slice_tensor_131);  add_tensor_133 = slice_tensor_131 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(add_tensor_134, slice_tensor_132);  add_tensor_134 = slice_tensor_132 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(add_tensor_135, slice_tensor_133);  add_tensor_135 = slice_tensor_133 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(add_tensor_136, slice_tensor_134);  add_tensor_136 = slice_tensor_134 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(add_tensor_157, relu__default_37, primals_20, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_157 = primals_20 = None
        getitem_204 = convolution_backward_default_10[0]
        getitem_205 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_204, torch.float32);  getitem_204 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_58, to_dtype_30);  le_scalar_10 = new_zeros_default_58 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_36, primals_238, primals_236, primals_237, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_36 = primals_238 = primals_236 = primals_237 = getitem_112 = getitem_113 = None
        getitem_207 = native_batch_norm_backward_default_10[0]
        getitem_208 = native_batch_norm_backward_default_10[1]
        getitem_209 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_207, relu__default_36, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_207 = primals_19 = None
        getitem_210 = convolution_backward_default_11[0]
        getitem_211 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_210, torch.float32);  getitem_210 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_59, to_dtype_33);  le_scalar_11 = new_zeros_default_59 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, cat_default_18, primals_233, primals_231, primals_232, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  to_dtype_35 = cat_default_18 = primals_233 = primals_231 = primals_232 = getitem_109 = getitem_110 = None
        getitem_213 = native_batch_norm_backward_default_11[0]
        getitem_214 = native_batch_norm_backward_default_11[1]
        getitem_215 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        slice_tensor_135 = torch.ops.aten.slice.Tensor(getitem_213, 1, 0, 256)
        slice_tensor_136 = torch.ops.aten.slice.Tensor(getitem_213, 1, 256, 288)
        slice_tensor_137 = torch.ops.aten.slice.Tensor(getitem_213, 1, 288, 320)
        slice_tensor_138 = torch.ops.aten.slice.Tensor(getitem_213, 1, 320, 352)
        slice_tensor_139 = torch.ops.aten.slice.Tensor(getitem_213, 1, 352, 384)
        slice_tensor_140 = torch.ops.aten.slice.Tensor(getitem_213, 1, 384, 416)
        slice_tensor_141 = torch.ops.aten.slice.Tensor(getitem_213, 1, 416, 448)
        slice_tensor_142 = torch.ops.aten.slice.Tensor(getitem_213, 1, 448, 480)
        slice_tensor_143 = torch.ops.aten.slice.Tensor(getitem_213, 1, 480, 512)
        slice_tensor_144 = torch.ops.aten.slice.Tensor(getitem_213, 1, 512, 544)
        slice_tensor_145 = torch.ops.aten.slice.Tensor(getitem_213, 1, 544, 576)
        slice_tensor_146 = torch.ops.aten.slice.Tensor(getitem_213, 1, 576, 608)
        slice_tensor_147 = torch.ops.aten.slice.Tensor(getitem_213, 1, 608, 640)
        slice_tensor_148 = torch.ops.aten.slice.Tensor(getitem_213, 1, 640, 672)
        slice_tensor_149 = torch.ops.aten.slice.Tensor(getitem_213, 1, 672, 704)
        slice_tensor_150 = torch.ops.aten.slice.Tensor(getitem_213, 1, 704, 736)
        slice_tensor_151 = torch.ops.aten.slice.Tensor(getitem_213, 1, 736, 768)
        slice_tensor_152 = torch.ops.aten.slice.Tensor(getitem_213, 1, 768, 800)
        slice_tensor_153 = torch.ops.aten.slice.Tensor(getitem_213, 1, 800, 832);  getitem_213 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(add_tensor_138, slice_tensor_135);  add_tensor_138 = slice_tensor_135 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(add_tensor_139, slice_tensor_136);  add_tensor_139 = slice_tensor_136 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(add_tensor_140, slice_tensor_137);  add_tensor_140 = slice_tensor_137 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(add_tensor_141, slice_tensor_138);  add_tensor_141 = slice_tensor_138 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(add_tensor_142, slice_tensor_139);  add_tensor_142 = slice_tensor_139 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(add_tensor_143, slice_tensor_140);  add_tensor_143 = slice_tensor_140 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(add_tensor_144, slice_tensor_141);  add_tensor_144 = slice_tensor_141 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(add_tensor_145, slice_tensor_142);  add_tensor_145 = slice_tensor_142 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(add_tensor_146, slice_tensor_143);  add_tensor_146 = slice_tensor_143 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(add_tensor_147, slice_tensor_144);  add_tensor_147 = slice_tensor_144 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(add_tensor_148, slice_tensor_145);  add_tensor_148 = slice_tensor_145 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(add_tensor_149, slice_tensor_146);  add_tensor_149 = slice_tensor_146 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(add_tensor_150, slice_tensor_147);  add_tensor_150 = slice_tensor_147 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(add_tensor_151, slice_tensor_148);  add_tensor_151 = slice_tensor_148 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(add_tensor_152, slice_tensor_149);  add_tensor_152 = slice_tensor_149 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(add_tensor_153, slice_tensor_150);  add_tensor_153 = slice_tensor_150 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(add_tensor_154, slice_tensor_151);  add_tensor_154 = slice_tensor_151 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(add_tensor_155, slice_tensor_152);  add_tensor_155 = slice_tensor_152 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(add_tensor_156, slice_tensor_153);  add_tensor_156 = slice_tensor_153 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(add_tensor_176, relu__default_35, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_176 = primals_18 = None
        getitem_216 = convolution_backward_default_12[0]
        getitem_217 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_216, torch.float32);  getitem_216 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_60, to_dtype_36);  le_scalar_12 = new_zeros_default_60 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_34, primals_228, primals_226, primals_227, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_34 = primals_228 = primals_226 = primals_227 = getitem_106 = getitem_107 = None
        getitem_219 = native_batch_norm_backward_default_12[0]
        getitem_220 = native_batch_norm_backward_default_12[1]
        getitem_221 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_219, relu__default_34, primals_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_219 = primals_17 = None
        getitem_222 = convolution_backward_default_13[0]
        getitem_223 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_222, torch.float32);  getitem_222 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_61, to_dtype_39);  le_scalar_13 = new_zeros_default_61 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, cat_default_17, primals_223, primals_221, primals_222, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  to_dtype_41 = cat_default_17 = primals_223 = primals_221 = primals_222 = getitem_103 = getitem_104 = None
        getitem_225 = native_batch_norm_backward_default_13[0]
        getitem_226 = native_batch_norm_backward_default_13[1]
        getitem_227 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        slice_tensor_154 = torch.ops.aten.slice.Tensor(getitem_225, 1, 0, 256)
        slice_tensor_155 = torch.ops.aten.slice.Tensor(getitem_225, 1, 256, 288)
        slice_tensor_156 = torch.ops.aten.slice.Tensor(getitem_225, 1, 288, 320)
        slice_tensor_157 = torch.ops.aten.slice.Tensor(getitem_225, 1, 320, 352)
        slice_tensor_158 = torch.ops.aten.slice.Tensor(getitem_225, 1, 352, 384)
        slice_tensor_159 = torch.ops.aten.slice.Tensor(getitem_225, 1, 384, 416)
        slice_tensor_160 = torch.ops.aten.slice.Tensor(getitem_225, 1, 416, 448)
        slice_tensor_161 = torch.ops.aten.slice.Tensor(getitem_225, 1, 448, 480)
        slice_tensor_162 = torch.ops.aten.slice.Tensor(getitem_225, 1, 480, 512)
        slice_tensor_163 = torch.ops.aten.slice.Tensor(getitem_225, 1, 512, 544)
        slice_tensor_164 = torch.ops.aten.slice.Tensor(getitem_225, 1, 544, 576)
        slice_tensor_165 = torch.ops.aten.slice.Tensor(getitem_225, 1, 576, 608)
        slice_tensor_166 = torch.ops.aten.slice.Tensor(getitem_225, 1, 608, 640)
        slice_tensor_167 = torch.ops.aten.slice.Tensor(getitem_225, 1, 640, 672)
        slice_tensor_168 = torch.ops.aten.slice.Tensor(getitem_225, 1, 672, 704)
        slice_tensor_169 = torch.ops.aten.slice.Tensor(getitem_225, 1, 704, 736)
        slice_tensor_170 = torch.ops.aten.slice.Tensor(getitem_225, 1, 736, 768)
        slice_tensor_171 = torch.ops.aten.slice.Tensor(getitem_225, 1, 768, 800);  getitem_225 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(add_tensor_158, slice_tensor_154);  add_tensor_158 = slice_tensor_154 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(add_tensor_159, slice_tensor_155);  add_tensor_159 = slice_tensor_155 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(add_tensor_160, slice_tensor_156);  add_tensor_160 = slice_tensor_156 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(add_tensor_161, slice_tensor_157);  add_tensor_161 = slice_tensor_157 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(add_tensor_162, slice_tensor_158);  add_tensor_162 = slice_tensor_158 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(add_tensor_163, slice_tensor_159);  add_tensor_163 = slice_tensor_159 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(add_tensor_164, slice_tensor_160);  add_tensor_164 = slice_tensor_160 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(add_tensor_165, slice_tensor_161);  add_tensor_165 = slice_tensor_161 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(add_tensor_166, slice_tensor_162);  add_tensor_166 = slice_tensor_162 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(add_tensor_167, slice_tensor_163);  add_tensor_167 = slice_tensor_163 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(add_tensor_168, slice_tensor_164);  add_tensor_168 = slice_tensor_164 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(add_tensor_169, slice_tensor_165);  add_tensor_169 = slice_tensor_165 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(add_tensor_170, slice_tensor_166);  add_tensor_170 = slice_tensor_166 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(add_tensor_171, slice_tensor_167);  add_tensor_171 = slice_tensor_167 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(add_tensor_172, slice_tensor_168);  add_tensor_172 = slice_tensor_168 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(add_tensor_173, slice_tensor_169);  add_tensor_173 = slice_tensor_169 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(add_tensor_174, slice_tensor_170);  add_tensor_174 = slice_tensor_170 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(add_tensor_175, slice_tensor_171);  add_tensor_175 = slice_tensor_171 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(add_tensor_194, relu__default_33, primals_16, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_194 = primals_16 = None
        getitem_228 = convolution_backward_default_14[0]
        getitem_229 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_228, torch.float32);  getitem_228 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_62, to_dtype_42);  le_scalar_14 = new_zeros_default_62 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_32, primals_218, primals_216, primals_217, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_32 = primals_218 = primals_216 = primals_217 = getitem_100 = getitem_101 = None
        getitem_231 = native_batch_norm_backward_default_14[0]
        getitem_232 = native_batch_norm_backward_default_14[1]
        getitem_233 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_231, relu__default_32, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_231 = primals_15 = None
        getitem_234 = convolution_backward_default_15[0]
        getitem_235 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_234, torch.float32);  getitem_234 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_63, to_dtype_45);  le_scalar_15 = new_zeros_default_63 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, cat_default_16, primals_213, primals_211, primals_212, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  to_dtype_47 = cat_default_16 = primals_213 = primals_211 = primals_212 = getitem_97 = getitem_98 = None
        getitem_237 = native_batch_norm_backward_default_15[0]
        getitem_238 = native_batch_norm_backward_default_15[1]
        getitem_239 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        slice_tensor_172 = torch.ops.aten.slice.Tensor(getitem_237, 1, 0, 256)
        slice_tensor_173 = torch.ops.aten.slice.Tensor(getitem_237, 1, 256, 288)
        slice_tensor_174 = torch.ops.aten.slice.Tensor(getitem_237, 1, 288, 320)
        slice_tensor_175 = torch.ops.aten.slice.Tensor(getitem_237, 1, 320, 352)
        slice_tensor_176 = torch.ops.aten.slice.Tensor(getitem_237, 1, 352, 384)
        slice_tensor_177 = torch.ops.aten.slice.Tensor(getitem_237, 1, 384, 416)
        slice_tensor_178 = torch.ops.aten.slice.Tensor(getitem_237, 1, 416, 448)
        slice_tensor_179 = torch.ops.aten.slice.Tensor(getitem_237, 1, 448, 480)
        slice_tensor_180 = torch.ops.aten.slice.Tensor(getitem_237, 1, 480, 512)
        slice_tensor_181 = torch.ops.aten.slice.Tensor(getitem_237, 1, 512, 544)
        slice_tensor_182 = torch.ops.aten.slice.Tensor(getitem_237, 1, 544, 576)
        slice_tensor_183 = torch.ops.aten.slice.Tensor(getitem_237, 1, 576, 608)
        slice_tensor_184 = torch.ops.aten.slice.Tensor(getitem_237, 1, 608, 640)
        slice_tensor_185 = torch.ops.aten.slice.Tensor(getitem_237, 1, 640, 672)
        slice_tensor_186 = torch.ops.aten.slice.Tensor(getitem_237, 1, 672, 704)
        slice_tensor_187 = torch.ops.aten.slice.Tensor(getitem_237, 1, 704, 736)
        slice_tensor_188 = torch.ops.aten.slice.Tensor(getitem_237, 1, 736, 768);  getitem_237 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(add_tensor_177, slice_tensor_172);  add_tensor_177 = slice_tensor_172 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(add_tensor_178, slice_tensor_173);  add_tensor_178 = slice_tensor_173 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(add_tensor_179, slice_tensor_174);  add_tensor_179 = slice_tensor_174 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(add_tensor_180, slice_tensor_175);  add_tensor_180 = slice_tensor_175 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(add_tensor_181, slice_tensor_176);  add_tensor_181 = slice_tensor_176 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(add_tensor_182, slice_tensor_177);  add_tensor_182 = slice_tensor_177 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(add_tensor_183, slice_tensor_178);  add_tensor_183 = slice_tensor_178 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(add_tensor_184, slice_tensor_179);  add_tensor_184 = slice_tensor_179 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(add_tensor_185, slice_tensor_180);  add_tensor_185 = slice_tensor_180 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(add_tensor_186, slice_tensor_181);  add_tensor_186 = slice_tensor_181 = None
        add_tensor_205 = torch.ops.aten.add.Tensor(add_tensor_187, slice_tensor_182);  add_tensor_187 = slice_tensor_182 = None
        add_tensor_206 = torch.ops.aten.add.Tensor(add_tensor_188, slice_tensor_183);  add_tensor_188 = slice_tensor_183 = None
        add_tensor_207 = torch.ops.aten.add.Tensor(add_tensor_189, slice_tensor_184);  add_tensor_189 = slice_tensor_184 = None
        add_tensor_208 = torch.ops.aten.add.Tensor(add_tensor_190, slice_tensor_185);  add_tensor_190 = slice_tensor_185 = None
        add_tensor_209 = torch.ops.aten.add.Tensor(add_tensor_191, slice_tensor_186);  add_tensor_191 = slice_tensor_186 = None
        add_tensor_210 = torch.ops.aten.add.Tensor(add_tensor_192, slice_tensor_187);  add_tensor_192 = slice_tensor_187 = None
        add_tensor_211 = torch.ops.aten.add.Tensor(add_tensor_193, slice_tensor_188);  add_tensor_193 = slice_tensor_188 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(add_tensor_211, relu__default_31, primals_14, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_211 = primals_14 = None
        getitem_240 = convolution_backward_default_16[0]
        getitem_241 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_240, torch.float32);  getitem_240 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_64, to_dtype_48);  le_scalar_16 = new_zeros_default_64 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_30, primals_208, primals_206, primals_207, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_30 = primals_208 = primals_206 = primals_207 = getitem_94 = getitem_95 = None
        getitem_243 = native_batch_norm_backward_default_16[0]
        getitem_244 = native_batch_norm_backward_default_16[1]
        getitem_245 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_243, relu__default_30, primals_13, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_243 = primals_13 = None
        getitem_246 = convolution_backward_default_17[0]
        getitem_247 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_246, torch.float32);  getitem_246 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_65, to_dtype_51);  le_scalar_17 = new_zeros_default_65 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, cat_default_15, primals_203, primals_201, primals_202, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  to_dtype_53 = cat_default_15 = primals_203 = primals_201 = primals_202 = getitem_91 = getitem_92 = None
        getitem_249 = native_batch_norm_backward_default_17[0]
        getitem_250 = native_batch_norm_backward_default_17[1]
        getitem_251 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        slice_tensor_189 = torch.ops.aten.slice.Tensor(getitem_249, 1, 0, 256)
        slice_tensor_190 = torch.ops.aten.slice.Tensor(getitem_249, 1, 256, 288)
        slice_tensor_191 = torch.ops.aten.slice.Tensor(getitem_249, 1, 288, 320)
        slice_tensor_192 = torch.ops.aten.slice.Tensor(getitem_249, 1, 320, 352)
        slice_tensor_193 = torch.ops.aten.slice.Tensor(getitem_249, 1, 352, 384)
        slice_tensor_194 = torch.ops.aten.slice.Tensor(getitem_249, 1, 384, 416)
        slice_tensor_195 = torch.ops.aten.slice.Tensor(getitem_249, 1, 416, 448)
        slice_tensor_196 = torch.ops.aten.slice.Tensor(getitem_249, 1, 448, 480)
        slice_tensor_197 = torch.ops.aten.slice.Tensor(getitem_249, 1, 480, 512)
        slice_tensor_198 = torch.ops.aten.slice.Tensor(getitem_249, 1, 512, 544)
        slice_tensor_199 = torch.ops.aten.slice.Tensor(getitem_249, 1, 544, 576)
        slice_tensor_200 = torch.ops.aten.slice.Tensor(getitem_249, 1, 576, 608)
        slice_tensor_201 = torch.ops.aten.slice.Tensor(getitem_249, 1, 608, 640)
        slice_tensor_202 = torch.ops.aten.slice.Tensor(getitem_249, 1, 640, 672)
        slice_tensor_203 = torch.ops.aten.slice.Tensor(getitem_249, 1, 672, 704)
        slice_tensor_204 = torch.ops.aten.slice.Tensor(getitem_249, 1, 704, 736);  getitem_249 = None
        add_tensor_212 = torch.ops.aten.add.Tensor(add_tensor_195, slice_tensor_189);  add_tensor_195 = slice_tensor_189 = None
        add_tensor_213 = torch.ops.aten.add.Tensor(add_tensor_196, slice_tensor_190);  add_tensor_196 = slice_tensor_190 = None
        add_tensor_214 = torch.ops.aten.add.Tensor(add_tensor_197, slice_tensor_191);  add_tensor_197 = slice_tensor_191 = None
        add_tensor_215 = torch.ops.aten.add.Tensor(add_tensor_198, slice_tensor_192);  add_tensor_198 = slice_tensor_192 = None
        add_tensor_216 = torch.ops.aten.add.Tensor(add_tensor_199, slice_tensor_193);  add_tensor_199 = slice_tensor_193 = None
        add_tensor_217 = torch.ops.aten.add.Tensor(add_tensor_200, slice_tensor_194);  add_tensor_200 = slice_tensor_194 = None
        add_tensor_218 = torch.ops.aten.add.Tensor(add_tensor_201, slice_tensor_195);  add_tensor_201 = slice_tensor_195 = None
        add_tensor_219 = torch.ops.aten.add.Tensor(add_tensor_202, slice_tensor_196);  add_tensor_202 = slice_tensor_196 = None
        add_tensor_220 = torch.ops.aten.add.Tensor(add_tensor_203, slice_tensor_197);  add_tensor_203 = slice_tensor_197 = None
        add_tensor_221 = torch.ops.aten.add.Tensor(add_tensor_204, slice_tensor_198);  add_tensor_204 = slice_tensor_198 = None
        add_tensor_222 = torch.ops.aten.add.Tensor(add_tensor_205, slice_tensor_199);  add_tensor_205 = slice_tensor_199 = None
        add_tensor_223 = torch.ops.aten.add.Tensor(add_tensor_206, slice_tensor_200);  add_tensor_206 = slice_tensor_200 = None
        add_tensor_224 = torch.ops.aten.add.Tensor(add_tensor_207, slice_tensor_201);  add_tensor_207 = slice_tensor_201 = None
        add_tensor_225 = torch.ops.aten.add.Tensor(add_tensor_208, slice_tensor_202);  add_tensor_208 = slice_tensor_202 = None
        add_tensor_226 = torch.ops.aten.add.Tensor(add_tensor_209, slice_tensor_203);  add_tensor_209 = slice_tensor_203 = None
        add_tensor_227 = torch.ops.aten.add.Tensor(add_tensor_210, slice_tensor_204);  add_tensor_210 = slice_tensor_204 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(add_tensor_227, relu__default_29, primals_12, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_227 = primals_12 = None
        getitem_252 = convolution_backward_default_18[0]
        getitem_253 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_252, torch.float32);  getitem_252 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_66, to_dtype_54);  le_scalar_18 = new_zeros_default_66 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_28, primals_198, primals_196, primals_197, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_28 = primals_198 = primals_196 = primals_197 = getitem_88 = getitem_89 = None
        getitem_255 = native_batch_norm_backward_default_18[0]
        getitem_256 = native_batch_norm_backward_default_18[1]
        getitem_257 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_255, relu__default_28, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_255 = primals_11 = None
        getitem_258 = convolution_backward_default_19[0]
        getitem_259 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_258, torch.float32);  getitem_258 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_67, to_dtype_57);  le_scalar_19 = new_zeros_default_67 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, cat_default_14, primals_193, primals_191, primals_192, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  to_dtype_59 = cat_default_14 = primals_193 = primals_191 = primals_192 = getitem_85 = getitem_86 = None
        getitem_261 = native_batch_norm_backward_default_19[0]
        getitem_262 = native_batch_norm_backward_default_19[1]
        getitem_263 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        slice_tensor_205 = torch.ops.aten.slice.Tensor(getitem_261, 1, 0, 256)
        slice_tensor_206 = torch.ops.aten.slice.Tensor(getitem_261, 1, 256, 288)
        slice_tensor_207 = torch.ops.aten.slice.Tensor(getitem_261, 1, 288, 320)
        slice_tensor_208 = torch.ops.aten.slice.Tensor(getitem_261, 1, 320, 352)
        slice_tensor_209 = torch.ops.aten.slice.Tensor(getitem_261, 1, 352, 384)
        slice_tensor_210 = torch.ops.aten.slice.Tensor(getitem_261, 1, 384, 416)
        slice_tensor_211 = torch.ops.aten.slice.Tensor(getitem_261, 1, 416, 448)
        slice_tensor_212 = torch.ops.aten.slice.Tensor(getitem_261, 1, 448, 480)
        slice_tensor_213 = torch.ops.aten.slice.Tensor(getitem_261, 1, 480, 512)
        slice_tensor_214 = torch.ops.aten.slice.Tensor(getitem_261, 1, 512, 544)
        slice_tensor_215 = torch.ops.aten.slice.Tensor(getitem_261, 1, 544, 576)
        slice_tensor_216 = torch.ops.aten.slice.Tensor(getitem_261, 1, 576, 608)
        slice_tensor_217 = torch.ops.aten.slice.Tensor(getitem_261, 1, 608, 640)
        slice_tensor_218 = torch.ops.aten.slice.Tensor(getitem_261, 1, 640, 672)
        slice_tensor_219 = torch.ops.aten.slice.Tensor(getitem_261, 1, 672, 704);  getitem_261 = None
        add_tensor_228 = torch.ops.aten.add.Tensor(add_tensor_212, slice_tensor_205);  add_tensor_212 = slice_tensor_205 = None
        add_tensor_229 = torch.ops.aten.add.Tensor(add_tensor_213, slice_tensor_206);  add_tensor_213 = slice_tensor_206 = None
        add_tensor_230 = torch.ops.aten.add.Tensor(add_tensor_214, slice_tensor_207);  add_tensor_214 = slice_tensor_207 = None
        add_tensor_231 = torch.ops.aten.add.Tensor(add_tensor_215, slice_tensor_208);  add_tensor_215 = slice_tensor_208 = None
        add_tensor_232 = torch.ops.aten.add.Tensor(add_tensor_216, slice_tensor_209);  add_tensor_216 = slice_tensor_209 = None
        add_tensor_233 = torch.ops.aten.add.Tensor(add_tensor_217, slice_tensor_210);  add_tensor_217 = slice_tensor_210 = None
        add_tensor_234 = torch.ops.aten.add.Tensor(add_tensor_218, slice_tensor_211);  add_tensor_218 = slice_tensor_211 = None
        add_tensor_235 = torch.ops.aten.add.Tensor(add_tensor_219, slice_tensor_212);  add_tensor_219 = slice_tensor_212 = None
        add_tensor_236 = torch.ops.aten.add.Tensor(add_tensor_220, slice_tensor_213);  add_tensor_220 = slice_tensor_213 = None
        add_tensor_237 = torch.ops.aten.add.Tensor(add_tensor_221, slice_tensor_214);  add_tensor_221 = slice_tensor_214 = None
        add_tensor_238 = torch.ops.aten.add.Tensor(add_tensor_222, slice_tensor_215);  add_tensor_222 = slice_tensor_215 = None
        add_tensor_239 = torch.ops.aten.add.Tensor(add_tensor_223, slice_tensor_216);  add_tensor_223 = slice_tensor_216 = None
        add_tensor_240 = torch.ops.aten.add.Tensor(add_tensor_224, slice_tensor_217);  add_tensor_224 = slice_tensor_217 = None
        add_tensor_241 = torch.ops.aten.add.Tensor(add_tensor_225, slice_tensor_218);  add_tensor_225 = slice_tensor_218 = None
        add_tensor_242 = torch.ops.aten.add.Tensor(add_tensor_226, slice_tensor_219);  add_tensor_226 = slice_tensor_219 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(add_tensor_242, relu__default_27, primals_10, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_242 = primals_10 = None
        getitem_264 = convolution_backward_default_20[0]
        getitem_265 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_264, torch.float32);  getitem_264 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_68, to_dtype_60);  le_scalar_20 = new_zeros_default_68 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_26, primals_188, primals_186, primals_187, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_26 = primals_188 = primals_186 = primals_187 = getitem_82 = getitem_83 = None
        getitem_267 = native_batch_norm_backward_default_20[0]
        getitem_268 = native_batch_norm_backward_default_20[1]
        getitem_269 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_267, relu__default_26, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_267 = primals_9 = None
        getitem_270 = convolution_backward_default_21[0]
        getitem_271 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_270, torch.float32);  getitem_270 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_69, to_dtype_63);  le_scalar_21 = new_zeros_default_69 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, cat_default_13, primals_183, primals_181, primals_182, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_65 = cat_default_13 = primals_183 = primals_181 = primals_182 = getitem_79 = getitem_80 = None
        getitem_273 = native_batch_norm_backward_default_21[0]
        getitem_274 = native_batch_norm_backward_default_21[1]
        getitem_275 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        slice_tensor_220 = torch.ops.aten.slice.Tensor(getitem_273, 1, 0, 256)
        slice_tensor_221 = torch.ops.aten.slice.Tensor(getitem_273, 1, 256, 288)
        slice_tensor_222 = torch.ops.aten.slice.Tensor(getitem_273, 1, 288, 320)
        slice_tensor_223 = torch.ops.aten.slice.Tensor(getitem_273, 1, 320, 352)
        slice_tensor_224 = torch.ops.aten.slice.Tensor(getitem_273, 1, 352, 384)
        slice_tensor_225 = torch.ops.aten.slice.Tensor(getitem_273, 1, 384, 416)
        slice_tensor_226 = torch.ops.aten.slice.Tensor(getitem_273, 1, 416, 448)
        slice_tensor_227 = torch.ops.aten.slice.Tensor(getitem_273, 1, 448, 480)
        slice_tensor_228 = torch.ops.aten.slice.Tensor(getitem_273, 1, 480, 512)
        slice_tensor_229 = torch.ops.aten.slice.Tensor(getitem_273, 1, 512, 544)
        slice_tensor_230 = torch.ops.aten.slice.Tensor(getitem_273, 1, 544, 576)
        slice_tensor_231 = torch.ops.aten.slice.Tensor(getitem_273, 1, 576, 608)
        slice_tensor_232 = torch.ops.aten.slice.Tensor(getitem_273, 1, 608, 640)
        slice_tensor_233 = torch.ops.aten.slice.Tensor(getitem_273, 1, 640, 672);  getitem_273 = None
        add_tensor_243 = torch.ops.aten.add.Tensor(add_tensor_228, slice_tensor_220);  add_tensor_228 = slice_tensor_220 = None
        add_tensor_244 = torch.ops.aten.add.Tensor(add_tensor_229, slice_tensor_221);  add_tensor_229 = slice_tensor_221 = None
        add_tensor_245 = torch.ops.aten.add.Tensor(add_tensor_230, slice_tensor_222);  add_tensor_230 = slice_tensor_222 = None
        add_tensor_246 = torch.ops.aten.add.Tensor(add_tensor_231, slice_tensor_223);  add_tensor_231 = slice_tensor_223 = None
        add_tensor_247 = torch.ops.aten.add.Tensor(add_tensor_232, slice_tensor_224);  add_tensor_232 = slice_tensor_224 = None
        add_tensor_248 = torch.ops.aten.add.Tensor(add_tensor_233, slice_tensor_225);  add_tensor_233 = slice_tensor_225 = None
        add_tensor_249 = torch.ops.aten.add.Tensor(add_tensor_234, slice_tensor_226);  add_tensor_234 = slice_tensor_226 = None
        add_tensor_250 = torch.ops.aten.add.Tensor(add_tensor_235, slice_tensor_227);  add_tensor_235 = slice_tensor_227 = None
        add_tensor_251 = torch.ops.aten.add.Tensor(add_tensor_236, slice_tensor_228);  add_tensor_236 = slice_tensor_228 = None
        add_tensor_252 = torch.ops.aten.add.Tensor(add_tensor_237, slice_tensor_229);  add_tensor_237 = slice_tensor_229 = None
        add_tensor_253 = torch.ops.aten.add.Tensor(add_tensor_238, slice_tensor_230);  add_tensor_238 = slice_tensor_230 = None
        add_tensor_254 = torch.ops.aten.add.Tensor(add_tensor_239, slice_tensor_231);  add_tensor_239 = slice_tensor_231 = None
        add_tensor_255 = torch.ops.aten.add.Tensor(add_tensor_240, slice_tensor_232);  add_tensor_240 = slice_tensor_232 = None
        add_tensor_256 = torch.ops.aten.add.Tensor(add_tensor_241, slice_tensor_233);  add_tensor_241 = slice_tensor_233 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(add_tensor_256, relu__default_25, primals_8, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_256 = primals_8 = None
        getitem_276 = convolution_backward_default_22[0]
        getitem_277 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_276, torch.float32);  getitem_276 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_70, to_dtype_66);  le_scalar_22 = new_zeros_default_70 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_24, primals_178, primals_176, primals_177, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_24 = primals_178 = primals_176 = primals_177 = getitem_76 = getitem_77 = None
        getitem_279 = native_batch_norm_backward_default_22[0]
        getitem_280 = native_batch_norm_backward_default_22[1]
        getitem_281 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_279, relu__default_24, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_279 = primals_7 = None
        getitem_282 = convolution_backward_default_23[0]
        getitem_283 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_282, torch.float32);  getitem_282 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_71, to_dtype_69);  le_scalar_23 = new_zeros_default_71 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, cat_default_12, primals_173, primals_171, primals_172, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_71 = cat_default_12 = primals_173 = primals_171 = primals_172 = getitem_73 = getitem_74 = None
        getitem_285 = native_batch_norm_backward_default_23[0]
        getitem_286 = native_batch_norm_backward_default_23[1]
        getitem_287 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        slice_tensor_234 = torch.ops.aten.slice.Tensor(getitem_285, 1, 0, 256)
        slice_tensor_235 = torch.ops.aten.slice.Tensor(getitem_285, 1, 256, 288)
        slice_tensor_236 = torch.ops.aten.slice.Tensor(getitem_285, 1, 288, 320)
        slice_tensor_237 = torch.ops.aten.slice.Tensor(getitem_285, 1, 320, 352)
        slice_tensor_238 = torch.ops.aten.slice.Tensor(getitem_285, 1, 352, 384)
        slice_tensor_239 = torch.ops.aten.slice.Tensor(getitem_285, 1, 384, 416)
        slice_tensor_240 = torch.ops.aten.slice.Tensor(getitem_285, 1, 416, 448)
        slice_tensor_241 = torch.ops.aten.slice.Tensor(getitem_285, 1, 448, 480)
        slice_tensor_242 = torch.ops.aten.slice.Tensor(getitem_285, 1, 480, 512)
        slice_tensor_243 = torch.ops.aten.slice.Tensor(getitem_285, 1, 512, 544)
        slice_tensor_244 = torch.ops.aten.slice.Tensor(getitem_285, 1, 544, 576)
        slice_tensor_245 = torch.ops.aten.slice.Tensor(getitem_285, 1, 576, 608)
        slice_tensor_246 = torch.ops.aten.slice.Tensor(getitem_285, 1, 608, 640);  getitem_285 = None
        add_tensor_257 = torch.ops.aten.add.Tensor(add_tensor_243, slice_tensor_234);  add_tensor_243 = slice_tensor_234 = None
        add_tensor_258 = torch.ops.aten.add.Tensor(add_tensor_244, slice_tensor_235);  add_tensor_244 = slice_tensor_235 = None
        add_tensor_259 = torch.ops.aten.add.Tensor(add_tensor_245, slice_tensor_236);  add_tensor_245 = slice_tensor_236 = None
        add_tensor_260 = torch.ops.aten.add.Tensor(add_tensor_246, slice_tensor_237);  add_tensor_246 = slice_tensor_237 = None
        add_tensor_261 = torch.ops.aten.add.Tensor(add_tensor_247, slice_tensor_238);  add_tensor_247 = slice_tensor_238 = None
        add_tensor_262 = torch.ops.aten.add.Tensor(add_tensor_248, slice_tensor_239);  add_tensor_248 = slice_tensor_239 = None
        add_tensor_263 = torch.ops.aten.add.Tensor(add_tensor_249, slice_tensor_240);  add_tensor_249 = slice_tensor_240 = None
        add_tensor_264 = torch.ops.aten.add.Tensor(add_tensor_250, slice_tensor_241);  add_tensor_250 = slice_tensor_241 = None
        add_tensor_265 = torch.ops.aten.add.Tensor(add_tensor_251, slice_tensor_242);  add_tensor_251 = slice_tensor_242 = None
        add_tensor_266 = torch.ops.aten.add.Tensor(add_tensor_252, slice_tensor_243);  add_tensor_252 = slice_tensor_243 = None
        add_tensor_267 = torch.ops.aten.add.Tensor(add_tensor_253, slice_tensor_244);  add_tensor_253 = slice_tensor_244 = None
        add_tensor_268 = torch.ops.aten.add.Tensor(add_tensor_254, slice_tensor_245);  add_tensor_254 = slice_tensor_245 = None
        add_tensor_269 = torch.ops.aten.add.Tensor(add_tensor_255, slice_tensor_246);  add_tensor_255 = slice_tensor_246 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(add_tensor_269, relu__default_23, primals_6, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_269 = primals_6 = None
        getitem_288 = convolution_backward_default_24[0]
        getitem_289 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_288, torch.float32);  getitem_288 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_72, to_dtype_72);  le_scalar_24 = new_zeros_default_72 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_22, primals_168, primals_166, primals_167, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_22 = primals_168 = primals_166 = primals_167 = getitem_70 = getitem_71 = None
        getitem_291 = native_batch_norm_backward_default_24[0]
        getitem_292 = native_batch_norm_backward_default_24[1]
        getitem_293 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_291, relu__default_22, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_291 = primals_5 = None
        getitem_294 = convolution_backward_default_25[0]
        getitem_295 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_294, torch.float32);  getitem_294 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_73, to_dtype_75);  le_scalar_25 = new_zeros_default_73 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, cat_default_11, primals_163, primals_161, primals_162, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  to_dtype_77 = cat_default_11 = primals_163 = primals_161 = primals_162 = getitem_67 = getitem_68 = None
        getitem_297 = native_batch_norm_backward_default_25[0]
        getitem_298 = native_batch_norm_backward_default_25[1]
        getitem_299 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        slice_tensor_247 = torch.ops.aten.slice.Tensor(getitem_297, 1, 0, 256)
        slice_tensor_248 = torch.ops.aten.slice.Tensor(getitem_297, 1, 256, 288)
        slice_tensor_249 = torch.ops.aten.slice.Tensor(getitem_297, 1, 288, 320)
        slice_tensor_250 = torch.ops.aten.slice.Tensor(getitem_297, 1, 320, 352)
        slice_tensor_251 = torch.ops.aten.slice.Tensor(getitem_297, 1, 352, 384)
        slice_tensor_252 = torch.ops.aten.slice.Tensor(getitem_297, 1, 384, 416)
        slice_tensor_253 = torch.ops.aten.slice.Tensor(getitem_297, 1, 416, 448)
        slice_tensor_254 = torch.ops.aten.slice.Tensor(getitem_297, 1, 448, 480)
        slice_tensor_255 = torch.ops.aten.slice.Tensor(getitem_297, 1, 480, 512)
        slice_tensor_256 = torch.ops.aten.slice.Tensor(getitem_297, 1, 512, 544)
        slice_tensor_257 = torch.ops.aten.slice.Tensor(getitem_297, 1, 544, 576)
        slice_tensor_258 = torch.ops.aten.slice.Tensor(getitem_297, 1, 576, 608);  getitem_297 = None
        add_tensor_270 = torch.ops.aten.add.Tensor(add_tensor_257, slice_tensor_247);  add_tensor_257 = slice_tensor_247 = None
        add_tensor_271 = torch.ops.aten.add.Tensor(add_tensor_258, slice_tensor_248);  add_tensor_258 = slice_tensor_248 = None
        add_tensor_272 = torch.ops.aten.add.Tensor(add_tensor_259, slice_tensor_249);  add_tensor_259 = slice_tensor_249 = None
        add_tensor_273 = torch.ops.aten.add.Tensor(add_tensor_260, slice_tensor_250);  add_tensor_260 = slice_tensor_250 = None
        add_tensor_274 = torch.ops.aten.add.Tensor(add_tensor_261, slice_tensor_251);  add_tensor_261 = slice_tensor_251 = None
        add_tensor_275 = torch.ops.aten.add.Tensor(add_tensor_262, slice_tensor_252);  add_tensor_262 = slice_tensor_252 = None
        add_tensor_276 = torch.ops.aten.add.Tensor(add_tensor_263, slice_tensor_253);  add_tensor_263 = slice_tensor_253 = None
        add_tensor_277 = torch.ops.aten.add.Tensor(add_tensor_264, slice_tensor_254);  add_tensor_264 = slice_tensor_254 = None
        add_tensor_278 = torch.ops.aten.add.Tensor(add_tensor_265, slice_tensor_255);  add_tensor_265 = slice_tensor_255 = None
        add_tensor_279 = torch.ops.aten.add.Tensor(add_tensor_266, slice_tensor_256);  add_tensor_266 = slice_tensor_256 = None
        add_tensor_280 = torch.ops.aten.add.Tensor(add_tensor_267, slice_tensor_257);  add_tensor_267 = slice_tensor_257 = None
        add_tensor_281 = torch.ops.aten.add.Tensor(add_tensor_268, slice_tensor_258);  add_tensor_268 = slice_tensor_258 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(add_tensor_281, relu__default_21, primals_4, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_281 = primals_4 = None
        getitem_300 = convolution_backward_default_26[0]
        getitem_301 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_300, torch.float32);  getitem_300 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_74, to_dtype_78);  le_scalar_26 = new_zeros_default_74 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_20, primals_158, primals_156, primals_157, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_20 = primals_158 = primals_156 = primals_157 = getitem_64 = getitem_65 = None
        getitem_303 = native_batch_norm_backward_default_26[0]
        getitem_304 = native_batch_norm_backward_default_26[1]
        getitem_305 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_303, relu__default_20, primals_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_303 = primals_3 = None
        getitem_306 = convolution_backward_default_27[0]
        getitem_307 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_306, torch.float32);  getitem_306 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_75, to_dtype_81);  le_scalar_27 = new_zeros_default_75 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, cat_default_10, primals_153, primals_151, primals_152, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_83 = cat_default_10 = primals_153 = primals_151 = primals_152 = getitem_61 = getitem_62 = None
        getitem_309 = native_batch_norm_backward_default_27[0]
        getitem_310 = native_batch_norm_backward_default_27[1]
        getitem_311 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        slice_tensor_259 = torch.ops.aten.slice.Tensor(getitem_309, 1, 0, 256)
        slice_tensor_260 = torch.ops.aten.slice.Tensor(getitem_309, 1, 256, 288)
        slice_tensor_261 = torch.ops.aten.slice.Tensor(getitem_309, 1, 288, 320)
        slice_tensor_262 = torch.ops.aten.slice.Tensor(getitem_309, 1, 320, 352)
        slice_tensor_263 = torch.ops.aten.slice.Tensor(getitem_309, 1, 352, 384)
        slice_tensor_264 = torch.ops.aten.slice.Tensor(getitem_309, 1, 384, 416)
        slice_tensor_265 = torch.ops.aten.slice.Tensor(getitem_309, 1, 416, 448)
        slice_tensor_266 = torch.ops.aten.slice.Tensor(getitem_309, 1, 448, 480)
        slice_tensor_267 = torch.ops.aten.slice.Tensor(getitem_309, 1, 480, 512)
        slice_tensor_268 = torch.ops.aten.slice.Tensor(getitem_309, 1, 512, 544)
        slice_tensor_269 = torch.ops.aten.slice.Tensor(getitem_309, 1, 544, 576);  getitem_309 = None
        add_tensor_282 = torch.ops.aten.add.Tensor(add_tensor_270, slice_tensor_259);  add_tensor_270 = slice_tensor_259 = None
        add_tensor_283 = torch.ops.aten.add.Tensor(add_tensor_271, slice_tensor_260);  add_tensor_271 = slice_tensor_260 = None
        add_tensor_284 = torch.ops.aten.add.Tensor(add_tensor_272, slice_tensor_261);  add_tensor_272 = slice_tensor_261 = None
        add_tensor_285 = torch.ops.aten.add.Tensor(add_tensor_273, slice_tensor_262);  add_tensor_273 = slice_tensor_262 = None
        add_tensor_286 = torch.ops.aten.add.Tensor(add_tensor_274, slice_tensor_263);  add_tensor_274 = slice_tensor_263 = None
        add_tensor_287 = torch.ops.aten.add.Tensor(add_tensor_275, slice_tensor_264);  add_tensor_275 = slice_tensor_264 = None
        add_tensor_288 = torch.ops.aten.add.Tensor(add_tensor_276, slice_tensor_265);  add_tensor_276 = slice_tensor_265 = None
        add_tensor_289 = torch.ops.aten.add.Tensor(add_tensor_277, slice_tensor_266);  add_tensor_277 = slice_tensor_266 = None
        add_tensor_290 = torch.ops.aten.add.Tensor(add_tensor_278, slice_tensor_267);  add_tensor_278 = slice_tensor_267 = None
        add_tensor_291 = torch.ops.aten.add.Tensor(add_tensor_279, slice_tensor_268);  add_tensor_279 = slice_tensor_268 = None
        add_tensor_292 = torch.ops.aten.add.Tensor(add_tensor_280, slice_tensor_269);  add_tensor_280 = slice_tensor_269 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(add_tensor_292, relu__default_19, primals_2, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_292 = primals_2 = None
        getitem_312 = convolution_backward_default_28[0]
        getitem_313 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_312, torch.float32);  getitem_312 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_76, to_dtype_84);  le_scalar_28 = new_zeros_default_76 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_18, primals_148, primals_146, primals_147, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_18 = primals_148 = primals_146 = primals_147 = getitem_58 = getitem_59 = None
        getitem_315 = native_batch_norm_backward_default_28[0]
        getitem_316 = native_batch_norm_backward_default_28[1]
        getitem_317 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_315, relu__default_18, primals_1, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_315 = primals_1 = None
        getitem_318 = convolution_backward_default_29[0]
        getitem_319 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_318, torch.float32);  getitem_318 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_77, to_dtype_87);  le_scalar_29 = new_zeros_default_77 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, cat_default_9, primals_143, primals_141, primals_142, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  to_dtype_89 = cat_default_9 = primals_143 = primals_141 = primals_142 = getitem_55 = getitem_56 = None
        getitem_321 = native_batch_norm_backward_default_29[0]
        getitem_322 = native_batch_norm_backward_default_29[1]
        getitem_323 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        slice_tensor_270 = torch.ops.aten.slice.Tensor(getitem_321, 1, 0, 256)
        slice_tensor_271 = torch.ops.aten.slice.Tensor(getitem_321, 1, 256, 288)
        slice_tensor_272 = torch.ops.aten.slice.Tensor(getitem_321, 1, 288, 320)
        slice_tensor_273 = torch.ops.aten.slice.Tensor(getitem_321, 1, 320, 352)
        slice_tensor_274 = torch.ops.aten.slice.Tensor(getitem_321, 1, 352, 384)
        slice_tensor_275 = torch.ops.aten.slice.Tensor(getitem_321, 1, 384, 416)
        slice_tensor_276 = torch.ops.aten.slice.Tensor(getitem_321, 1, 416, 448)
        slice_tensor_277 = torch.ops.aten.slice.Tensor(getitem_321, 1, 448, 480)
        slice_tensor_278 = torch.ops.aten.slice.Tensor(getitem_321, 1, 480, 512)
        slice_tensor_279 = torch.ops.aten.slice.Tensor(getitem_321, 1, 512, 544);  getitem_321 = None
        add_tensor_293 = torch.ops.aten.add.Tensor(add_tensor_282, slice_tensor_270);  add_tensor_282 = slice_tensor_270 = None
        add_tensor_294 = torch.ops.aten.add.Tensor(add_tensor_283, slice_tensor_271);  add_tensor_283 = slice_tensor_271 = None
        add_tensor_295 = torch.ops.aten.add.Tensor(add_tensor_284, slice_tensor_272);  add_tensor_284 = slice_tensor_272 = None
        add_tensor_296 = torch.ops.aten.add.Tensor(add_tensor_285, slice_tensor_273);  add_tensor_285 = slice_tensor_273 = None
        add_tensor_297 = torch.ops.aten.add.Tensor(add_tensor_286, slice_tensor_274);  add_tensor_286 = slice_tensor_274 = None
        add_tensor_298 = torch.ops.aten.add.Tensor(add_tensor_287, slice_tensor_275);  add_tensor_287 = slice_tensor_275 = None
        add_tensor_299 = torch.ops.aten.add.Tensor(add_tensor_288, slice_tensor_276);  add_tensor_288 = slice_tensor_276 = None
        add_tensor_300 = torch.ops.aten.add.Tensor(add_tensor_289, slice_tensor_277);  add_tensor_289 = slice_tensor_277 = None
        add_tensor_301 = torch.ops.aten.add.Tensor(add_tensor_290, slice_tensor_278);  add_tensor_290 = slice_tensor_278 = None
        add_tensor_302 = torch.ops.aten.add.Tensor(add_tensor_291, slice_tensor_279);  add_tensor_291 = slice_tensor_279 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(add_tensor_302, relu__default_17, primals_48, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_302 = primals_48 = None
        getitem_324 = convolution_backward_default_30[0]
        getitem_325 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_324, torch.float32);  getitem_324 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_78, to_dtype_90);  le_scalar_30 = new_zeros_default_78 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_16, primals_138, primals_136, primals_137, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_16 = primals_138 = primals_136 = primals_137 = getitem_52 = getitem_53 = None
        getitem_327 = native_batch_norm_backward_default_30[0]
        getitem_328 = native_batch_norm_backward_default_30[1]
        getitem_329 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_327, relu__default_16, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_327 = primals_47 = None
        getitem_330 = convolution_backward_default_31[0]
        getitem_331 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_330, torch.float32);  getitem_330 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_79, to_dtype_93);  le_scalar_31 = new_zeros_default_79 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, cat_default_8, primals_133, primals_131, primals_132, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  to_dtype_95 = cat_default_8 = primals_133 = primals_131 = primals_132 = getitem_49 = getitem_50 = None
        getitem_333 = native_batch_norm_backward_default_31[0]
        getitem_334 = native_batch_norm_backward_default_31[1]
        getitem_335 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        slice_tensor_280 = torch.ops.aten.slice.Tensor(getitem_333, 1, 0, 256)
        slice_tensor_281 = torch.ops.aten.slice.Tensor(getitem_333, 1, 256, 288)
        slice_tensor_282 = torch.ops.aten.slice.Tensor(getitem_333, 1, 288, 320)
        slice_tensor_283 = torch.ops.aten.slice.Tensor(getitem_333, 1, 320, 352)
        slice_tensor_284 = torch.ops.aten.slice.Tensor(getitem_333, 1, 352, 384)
        slice_tensor_285 = torch.ops.aten.slice.Tensor(getitem_333, 1, 384, 416)
        slice_tensor_286 = torch.ops.aten.slice.Tensor(getitem_333, 1, 416, 448)
        slice_tensor_287 = torch.ops.aten.slice.Tensor(getitem_333, 1, 448, 480)
        slice_tensor_288 = torch.ops.aten.slice.Tensor(getitem_333, 1, 480, 512);  getitem_333 = None
        add_tensor_303 = torch.ops.aten.add.Tensor(add_tensor_293, slice_tensor_280);  add_tensor_293 = slice_tensor_280 = None
        add_tensor_304 = torch.ops.aten.add.Tensor(add_tensor_294, slice_tensor_281);  add_tensor_294 = slice_tensor_281 = None
        add_tensor_305 = torch.ops.aten.add.Tensor(add_tensor_295, slice_tensor_282);  add_tensor_295 = slice_tensor_282 = None
        add_tensor_306 = torch.ops.aten.add.Tensor(add_tensor_296, slice_tensor_283);  add_tensor_296 = slice_tensor_283 = None
        add_tensor_307 = torch.ops.aten.add.Tensor(add_tensor_297, slice_tensor_284);  add_tensor_297 = slice_tensor_284 = None
        add_tensor_308 = torch.ops.aten.add.Tensor(add_tensor_298, slice_tensor_285);  add_tensor_298 = slice_tensor_285 = None
        add_tensor_309 = torch.ops.aten.add.Tensor(add_tensor_299, slice_tensor_286);  add_tensor_299 = slice_tensor_286 = None
        add_tensor_310 = torch.ops.aten.add.Tensor(add_tensor_300, slice_tensor_287);  add_tensor_300 = slice_tensor_287 = None
        add_tensor_311 = torch.ops.aten.add.Tensor(add_tensor_301, slice_tensor_288);  add_tensor_301 = slice_tensor_288 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(add_tensor_311, relu__default_15, primals_46, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_311 = primals_46 = None
        getitem_336 = convolution_backward_default_32[0]
        getitem_337 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_336, torch.float32);  getitem_336 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_80, to_dtype_96);  le_scalar_32 = new_zeros_default_80 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_14, primals_128, primals_126, primals_127, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_14 = primals_128 = primals_126 = primals_127 = getitem_46 = getitem_47 = None
        getitem_339 = native_batch_norm_backward_default_32[0]
        getitem_340 = native_batch_norm_backward_default_32[1]
        getitem_341 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_339, relu__default_14, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_339 = primals_45 = None
        getitem_342 = convolution_backward_default_33[0]
        getitem_343 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_342, torch.float32);  getitem_342 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_81, to_dtype_99);  le_scalar_33 = new_zeros_default_81 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, cat_default_7, primals_123, primals_121, primals_122, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  to_dtype_101 = cat_default_7 = primals_123 = primals_121 = primals_122 = getitem_43 = getitem_44 = None
        getitem_345 = native_batch_norm_backward_default_33[0]
        getitem_346 = native_batch_norm_backward_default_33[1]
        getitem_347 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        slice_tensor_289 = torch.ops.aten.slice.Tensor(getitem_345, 1, 0, 256)
        slice_tensor_290 = torch.ops.aten.slice.Tensor(getitem_345, 1, 256, 288)
        slice_tensor_291 = torch.ops.aten.slice.Tensor(getitem_345, 1, 288, 320)
        slice_tensor_292 = torch.ops.aten.slice.Tensor(getitem_345, 1, 320, 352)
        slice_tensor_293 = torch.ops.aten.slice.Tensor(getitem_345, 1, 352, 384)
        slice_tensor_294 = torch.ops.aten.slice.Tensor(getitem_345, 1, 384, 416)
        slice_tensor_295 = torch.ops.aten.slice.Tensor(getitem_345, 1, 416, 448)
        slice_tensor_296 = torch.ops.aten.slice.Tensor(getitem_345, 1, 448, 480);  getitem_345 = None
        add_tensor_312 = torch.ops.aten.add.Tensor(add_tensor_303, slice_tensor_289);  add_tensor_303 = slice_tensor_289 = None
        add_tensor_313 = torch.ops.aten.add.Tensor(add_tensor_304, slice_tensor_290);  add_tensor_304 = slice_tensor_290 = None
        add_tensor_314 = torch.ops.aten.add.Tensor(add_tensor_305, slice_tensor_291);  add_tensor_305 = slice_tensor_291 = None
        add_tensor_315 = torch.ops.aten.add.Tensor(add_tensor_306, slice_tensor_292);  add_tensor_306 = slice_tensor_292 = None
        add_tensor_316 = torch.ops.aten.add.Tensor(add_tensor_307, slice_tensor_293);  add_tensor_307 = slice_tensor_293 = None
        add_tensor_317 = torch.ops.aten.add.Tensor(add_tensor_308, slice_tensor_294);  add_tensor_308 = slice_tensor_294 = None
        add_tensor_318 = torch.ops.aten.add.Tensor(add_tensor_309, slice_tensor_295);  add_tensor_309 = slice_tensor_295 = None
        add_tensor_319 = torch.ops.aten.add.Tensor(add_tensor_310, slice_tensor_296);  add_tensor_310 = slice_tensor_296 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(add_tensor_319, relu__default_13, primals_44, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_319 = primals_44 = None
        getitem_348 = convolution_backward_default_34[0]
        getitem_349 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_348, torch.float32);  getitem_348 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_82, to_dtype_102);  le_scalar_34 = new_zeros_default_82 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_12, primals_118, primals_116, primals_117, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_12 = primals_118 = primals_116 = primals_117 = getitem_40 = getitem_41 = None
        getitem_351 = native_batch_norm_backward_default_34[0]
        getitem_352 = native_batch_norm_backward_default_34[1]
        getitem_353 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_351, relu__default_12, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_351 = primals_43 = None
        getitem_354 = convolution_backward_default_35[0]
        getitem_355 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_354, torch.float32);  getitem_354 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_83, to_dtype_105);  le_scalar_35 = new_zeros_default_83 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, cat_default_6, primals_113, primals_111, primals_112, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  to_dtype_107 = cat_default_6 = primals_113 = primals_111 = primals_112 = getitem_37 = getitem_38 = None
        getitem_357 = native_batch_norm_backward_default_35[0]
        getitem_358 = native_batch_norm_backward_default_35[1]
        getitem_359 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        slice_tensor_297 = torch.ops.aten.slice.Tensor(getitem_357, 1, 0, 256)
        slice_tensor_298 = torch.ops.aten.slice.Tensor(getitem_357, 1, 256, 288)
        slice_tensor_299 = torch.ops.aten.slice.Tensor(getitem_357, 1, 288, 320)
        slice_tensor_300 = torch.ops.aten.slice.Tensor(getitem_357, 1, 320, 352)
        slice_tensor_301 = torch.ops.aten.slice.Tensor(getitem_357, 1, 352, 384)
        slice_tensor_302 = torch.ops.aten.slice.Tensor(getitem_357, 1, 384, 416)
        slice_tensor_303 = torch.ops.aten.slice.Tensor(getitem_357, 1, 416, 448);  getitem_357 = None
        add_tensor_320 = torch.ops.aten.add.Tensor(add_tensor_312, slice_tensor_297);  add_tensor_312 = slice_tensor_297 = None
        add_tensor_321 = torch.ops.aten.add.Tensor(add_tensor_313, slice_tensor_298);  add_tensor_313 = slice_tensor_298 = None
        add_tensor_322 = torch.ops.aten.add.Tensor(add_tensor_314, slice_tensor_299);  add_tensor_314 = slice_tensor_299 = None
        add_tensor_323 = torch.ops.aten.add.Tensor(add_tensor_315, slice_tensor_300);  add_tensor_315 = slice_tensor_300 = None
        add_tensor_324 = torch.ops.aten.add.Tensor(add_tensor_316, slice_tensor_301);  add_tensor_316 = slice_tensor_301 = None
        add_tensor_325 = torch.ops.aten.add.Tensor(add_tensor_317, slice_tensor_302);  add_tensor_317 = slice_tensor_302 = None
        add_tensor_326 = torch.ops.aten.add.Tensor(add_tensor_318, slice_tensor_303);  add_tensor_318 = slice_tensor_303 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(add_tensor_326, relu__default_11, primals_42, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_326 = primals_42 = None
        getitem_360 = convolution_backward_default_36[0]
        getitem_361 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_360, torch.float32);  getitem_360 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_84, to_dtype_108);  le_scalar_36 = new_zeros_default_84 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_10, primals_108, primals_106, primals_107, getitem_34, getitem_35, True, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_10 = primals_108 = primals_106 = primals_107 = getitem_34 = getitem_35 = None
        getitem_363 = native_batch_norm_backward_default_36[0]
        getitem_364 = native_batch_norm_backward_default_36[1]
        getitem_365 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_363, relu__default_10, primals_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_363 = primals_41 = None
        getitem_366 = convolution_backward_default_37[0]
        getitem_367 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_366, torch.float32);  getitem_366 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_85, to_dtype_111);  le_scalar_37 = new_zeros_default_85 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, cat_default_5, primals_103, primals_101, primals_102, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  to_dtype_113 = cat_default_5 = primals_103 = primals_101 = primals_102 = getitem_31 = getitem_32 = None
        getitem_369 = native_batch_norm_backward_default_37[0]
        getitem_370 = native_batch_norm_backward_default_37[1]
        getitem_371 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        slice_tensor_304 = torch.ops.aten.slice.Tensor(getitem_369, 1, 0, 256)
        slice_tensor_305 = torch.ops.aten.slice.Tensor(getitem_369, 1, 256, 288)
        slice_tensor_306 = torch.ops.aten.slice.Tensor(getitem_369, 1, 288, 320)
        slice_tensor_307 = torch.ops.aten.slice.Tensor(getitem_369, 1, 320, 352)
        slice_tensor_308 = torch.ops.aten.slice.Tensor(getitem_369, 1, 352, 384)
        slice_tensor_309 = torch.ops.aten.slice.Tensor(getitem_369, 1, 384, 416);  getitem_369 = None
        add_tensor_327 = torch.ops.aten.add.Tensor(add_tensor_320, slice_tensor_304);  add_tensor_320 = slice_tensor_304 = None
        add_tensor_328 = torch.ops.aten.add.Tensor(add_tensor_321, slice_tensor_305);  add_tensor_321 = slice_tensor_305 = None
        add_tensor_329 = torch.ops.aten.add.Tensor(add_tensor_322, slice_tensor_306);  add_tensor_322 = slice_tensor_306 = None
        add_tensor_330 = torch.ops.aten.add.Tensor(add_tensor_323, slice_tensor_307);  add_tensor_323 = slice_tensor_307 = None
        add_tensor_331 = torch.ops.aten.add.Tensor(add_tensor_324, slice_tensor_308);  add_tensor_324 = slice_tensor_308 = None
        add_tensor_332 = torch.ops.aten.add.Tensor(add_tensor_325, slice_tensor_309);  add_tensor_325 = slice_tensor_309 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(add_tensor_332, relu__default_9, primals_40, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_332 = primals_40 = None
        getitem_372 = convolution_backward_default_38[0]
        getitem_373 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_372, torch.float32);  getitem_372 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_86, to_dtype_114);  le_scalar_38 = new_zeros_default_86 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_8, primals_98, primals_96, primals_97, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_8 = primals_98 = primals_96 = primals_97 = getitem_28 = getitem_29 = None
        getitem_375 = native_batch_norm_backward_default_38[0]
        getitem_376 = native_batch_norm_backward_default_38[1]
        getitem_377 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_375, relu__default_8, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_375 = primals_39 = None
        getitem_378 = convolution_backward_default_39[0]
        getitem_379 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_378, torch.float32);  getitem_378 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_87, to_dtype_117);  le_scalar_39 = new_zeros_default_87 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, cat_default_4, primals_93, primals_91, primals_92, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  to_dtype_119 = cat_default_4 = primals_93 = primals_91 = primals_92 = getitem_25 = getitem_26 = None
        getitem_381 = native_batch_norm_backward_default_39[0]
        getitem_382 = native_batch_norm_backward_default_39[1]
        getitem_383 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        slice_tensor_310 = torch.ops.aten.slice.Tensor(getitem_381, 1, 0, 256)
        slice_tensor_311 = torch.ops.aten.slice.Tensor(getitem_381, 1, 256, 288)
        slice_tensor_312 = torch.ops.aten.slice.Tensor(getitem_381, 1, 288, 320)
        slice_tensor_313 = torch.ops.aten.slice.Tensor(getitem_381, 1, 320, 352)
        slice_tensor_314 = torch.ops.aten.slice.Tensor(getitem_381, 1, 352, 384);  getitem_381 = None
        add_tensor_333 = torch.ops.aten.add.Tensor(add_tensor_327, slice_tensor_310);  add_tensor_327 = slice_tensor_310 = None
        add_tensor_334 = torch.ops.aten.add.Tensor(add_tensor_328, slice_tensor_311);  add_tensor_328 = slice_tensor_311 = None
        add_tensor_335 = torch.ops.aten.add.Tensor(add_tensor_329, slice_tensor_312);  add_tensor_329 = slice_tensor_312 = None
        add_tensor_336 = torch.ops.aten.add.Tensor(add_tensor_330, slice_tensor_313);  add_tensor_330 = slice_tensor_313 = None
        add_tensor_337 = torch.ops.aten.add.Tensor(add_tensor_331, slice_tensor_314);  add_tensor_331 = slice_tensor_314 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(add_tensor_337, relu__default_7, primals_38, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_337 = primals_38 = None
        getitem_384 = convolution_backward_default_40[0]
        getitem_385 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_384, torch.float32);  getitem_384 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_88, to_dtype_120);  le_scalar_40 = new_zeros_default_88 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_6, primals_88, primals_86, primals_87, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_6 = primals_88 = primals_86 = primals_87 = getitem_22 = getitem_23 = None
        getitem_387 = native_batch_norm_backward_default_40[0]
        getitem_388 = native_batch_norm_backward_default_40[1]
        getitem_389 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_387, relu__default_6, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_387 = primals_37 = None
        getitem_390 = convolution_backward_default_41[0]
        getitem_391 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_390, torch.float32);  getitem_390 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_89, to_dtype_123);  le_scalar_41 = new_zeros_default_89 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, cat_default_3, primals_83, primals_81, primals_82, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_125 = cat_default_3 = primals_83 = primals_81 = primals_82 = getitem_19 = getitem_20 = None
        getitem_393 = native_batch_norm_backward_default_41[0]
        getitem_394 = native_batch_norm_backward_default_41[1]
        getitem_395 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        slice_tensor_315 = torch.ops.aten.slice.Tensor(getitem_393, 1, 0, 256)
        slice_tensor_316 = torch.ops.aten.slice.Tensor(getitem_393, 1, 256, 288)
        slice_tensor_317 = torch.ops.aten.slice.Tensor(getitem_393, 1, 288, 320)
        slice_tensor_318 = torch.ops.aten.slice.Tensor(getitem_393, 1, 320, 352);  getitem_393 = None
        add_tensor_338 = torch.ops.aten.add.Tensor(add_tensor_333, slice_tensor_315);  add_tensor_333 = slice_tensor_315 = None
        add_tensor_339 = torch.ops.aten.add.Tensor(add_tensor_334, slice_tensor_316);  add_tensor_334 = slice_tensor_316 = None
        add_tensor_340 = torch.ops.aten.add.Tensor(add_tensor_335, slice_tensor_317);  add_tensor_335 = slice_tensor_317 = None
        add_tensor_341 = torch.ops.aten.add.Tensor(add_tensor_336, slice_tensor_318);  add_tensor_336 = slice_tensor_318 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(add_tensor_341, relu__default_5, primals_36, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_341 = primals_36 = None
        getitem_396 = convolution_backward_default_42[0]
        getitem_397 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_396, torch.float32);  getitem_396 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_90, to_dtype_126);  le_scalar_42 = new_zeros_default_90 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_4, primals_78, primals_76, primals_77, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default_4 = primals_78 = primals_76 = primals_77 = getitem_16 = getitem_17 = None
        getitem_399 = native_batch_norm_backward_default_42[0]
        getitem_400 = native_batch_norm_backward_default_42[1]
        getitem_401 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_399, relu__default_4, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_399 = primals_35 = None
        getitem_402 = convolution_backward_default_43[0]
        getitem_403 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_402, torch.float32);  getitem_402 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_91, to_dtype_129);  le_scalar_43 = new_zeros_default_91 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, cat_default_2, primals_73, primals_71, primals_72, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_131 = cat_default_2 = primals_73 = primals_71 = primals_72 = getitem_13 = getitem_14 = None
        getitem_405 = native_batch_norm_backward_default_43[0]
        getitem_406 = native_batch_norm_backward_default_43[1]
        getitem_407 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        slice_tensor_319 = torch.ops.aten.slice.Tensor(getitem_405, 1, 0, 256)
        slice_tensor_320 = torch.ops.aten.slice.Tensor(getitem_405, 1, 256, 288)
        slice_tensor_321 = torch.ops.aten.slice.Tensor(getitem_405, 1, 288, 320);  getitem_405 = None
        add_tensor_342 = torch.ops.aten.add.Tensor(add_tensor_338, slice_tensor_319);  add_tensor_338 = slice_tensor_319 = None
        add_tensor_343 = torch.ops.aten.add.Tensor(add_tensor_339, slice_tensor_320);  add_tensor_339 = slice_tensor_320 = None
        add_tensor_344 = torch.ops.aten.add.Tensor(add_tensor_340, slice_tensor_321);  add_tensor_340 = slice_tensor_321 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(add_tensor_344, relu__default_3, primals_34, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_344 = primals_34 = None
        getitem_408 = convolution_backward_default_44[0]
        getitem_409 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_408, torch.float32);  getitem_408 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_92, to_dtype_132);  le_scalar_44 = new_zeros_default_92 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_2, primals_68, primals_66, primals_67, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_2 = primals_68 = primals_66 = primals_67 = getitem_10 = getitem_11 = None
        getitem_411 = native_batch_norm_backward_default_44[0]
        getitem_412 = native_batch_norm_backward_default_44[1]
        getitem_413 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_411, relu__default_2, primals_33, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_411 = primals_33 = None
        getitem_414 = convolution_backward_default_45[0]
        getitem_415 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_414, torch.float32);  getitem_414 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_93, to_dtype_135);  le_scalar_45 = new_zeros_default_93 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, cat_default_1, primals_63, primals_61, primals_62, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_137 = cat_default_1 = primals_63 = primals_61 = primals_62 = getitem_7 = getitem_8 = None
        getitem_417 = native_batch_norm_backward_default_45[0]
        getitem_418 = native_batch_norm_backward_default_45[1]
        getitem_419 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        slice_tensor_322 = torch.ops.aten.slice.Tensor(getitem_417, 1, 0, 256)
        slice_tensor_323 = torch.ops.aten.slice.Tensor(getitem_417, 1, 256, 288);  getitem_417 = None
        add_tensor_345 = torch.ops.aten.add.Tensor(add_tensor_342, slice_tensor_322);  add_tensor_342 = slice_tensor_322 = None
        add_tensor_346 = torch.ops.aten.add.Tensor(add_tensor_343, slice_tensor_323);  add_tensor_343 = slice_tensor_323 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(add_tensor_346, relu__default_1, primals_22, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_346 = primals_22 = None
        getitem_420 = convolution_backward_default_46[0]
        getitem_421 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_420, torch.float32);  getitem_420 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_94, to_dtype_138);  le_scalar_46 = new_zeros_default_94 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default, primals_58, primals_56, primals_57, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default = primals_58 = primals_56 = primals_57 = getitem_4 = getitem_5 = None
        getitem_423 = native_batch_norm_backward_default_46[0]
        getitem_424 = native_batch_norm_backward_default_46[1]
        getitem_425 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_423, relu__default, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_423 = primals_21 = None
        getitem_426 = convolution_backward_default_47[0]
        getitem_427 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_426, torch.float32);  getitem_426 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_95, to_dtype_141);  le_scalar_47 = new_zeros_default_95 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, cat_default, primals_53, primals_51, primals_52, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_143 = cat_default = primals_53 = primals_51 = primals_52 = getitem_1 = getitem_2 = None
        getitem_429 = native_batch_norm_backward_default_47[0]
        getitem_430 = native_batch_norm_backward_default_47[1]
        getitem_431 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        slice_tensor_324 = torch.ops.aten.slice.Tensor(getitem_429, 1, 0, 256);  getitem_429 = None
        add_tensor_347 = torch.ops.aten.add.Tensor(add_tensor_345, slice_tensor_324);  add_tensor_345 = slice_tensor_324 = None
        return [getitem_319, getitem_313, getitem_307, getitem_301, getitem_295, getitem_289, getitem_283, getitem_277, getitem_271, getitem_265, getitem_259, getitem_253, getitem_247, getitem_241, getitem_235, getitem_229, getitem_223, getitem_217, getitem_211, getitem_205, getitem_427, getitem_421, getitem_199, getitem_193, getitem_187, getitem_181, getitem_175, getitem_169, getitem_163, getitem_157, getitem_151, getitem_145, getitem_415, getitem_409, getitem_403, getitem_397, getitem_391, getitem_385, getitem_379, getitem_373, getitem_367, getitem_361, getitem_355, getitem_349, getitem_343, getitem_337, getitem_331, getitem_325, add_tensor_347, None, None, None, getitem_430, getitem_431, None, None, None, getitem_424, getitem_425, None, None, None, getitem_418, getitem_419, None, None, None, getitem_412, getitem_413, None, None, None, getitem_406, getitem_407, None, None, None, getitem_400, getitem_401, None, None, None, getitem_394, getitem_395, None, None, None, getitem_388, getitem_389, None, None, None, getitem_382, getitem_383, None, None, None, getitem_376, getitem_377, None, None, None, getitem_370, getitem_371, None, None, None, getitem_364, getitem_365, None, None, None, getitem_358, getitem_359, None, None, None, getitem_352, getitem_353, None, None, None, getitem_346, getitem_347, None, None, None, getitem_340, getitem_341, None, None, None, getitem_334, getitem_335, None, None, None, getitem_328, getitem_329, None, None, None, getitem_322, getitem_323, None, None, None, getitem_316, getitem_317, None, None, None, getitem_310, getitem_311, None, None, None, getitem_304, getitem_305, None, None, None, getitem_298, getitem_299, None, None, None, getitem_292, getitem_293, None, None, None, getitem_286, getitem_287, None, None, None, getitem_280, getitem_281, None, None, None, getitem_274, getitem_275, None, None, None, getitem_268, getitem_269, None, None, None, getitem_262, getitem_263, None, None, None, getitem_256, getitem_257, None, None, None, getitem_250, getitem_251, None, None, None, getitem_244, getitem_245, None, None, None, getitem_238, getitem_239, None, None, None, getitem_232, getitem_233, None, None, None, getitem_226, getitem_227, None, None, None, getitem_220, getitem_221, None, None, None, getitem_214, getitem_215, None, None, None, getitem_208, getitem_209, None, None, None, getitem_202, getitem_203, None, None, None, getitem_196, getitem_197, None, None, None, getitem_190, getitem_191, None, None, None, getitem_184, getitem_185, None, None, None, getitem_178, getitem_179, None, None, None, getitem_172, getitem_173, None, None, None, getitem_166, getitem_167, None, None, None, getitem_160, getitem_161, None, None, None, getitem_154, getitem_155, None, None, None, getitem_148, getitem_149]
        
