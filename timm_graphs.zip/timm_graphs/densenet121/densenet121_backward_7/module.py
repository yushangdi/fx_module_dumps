
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_backward_7/state_dict.pt'))

    
    
    def forward(self, convolution_default, primals_2, primals_1, tangents_1):
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(tangents_1, convolution_default, [2, 2], [2, 2], [0, 0], False, True, None);  tangents_1 = convolution_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(avg_pool2d_backward_default, primals_2, primals_1, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  avg_pool2d_backward_default = primals_2 = primals_1 = None
        getitem = convolution_backward_default[0]
        getitem_1 = convolution_backward_default[1];  convolution_backward_default = None
        return [getitem_1, getitem]
        
