
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/densenet121/densenet121_forward_5/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145):
        cat_default = torch.ops.aten.cat.default([primals_25], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_26, 1);  primals_26 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(cat_default, primals_29, primals_30, primals_27, primals_28, True, 0.1, 1e-05);  primals_30 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default = torch.ops.aten.convolution.default(relu__default, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_31, 1);  primals_31 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default, primals_34, primals_35, primals_32, primals_33, True, 0.1, 1e-05);  primals_35 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default_1, primals_8, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_1 = torch.ops.aten.cat.default([primals_25, convolution_default_1], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_36, 1);  primals_36 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_39, primals_40, primals_37, primals_38, True, 0.1, 1e-05);  primals_40 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_2, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_41, 1);  primals_41 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_44, primals_45, primals_42, primals_43, True, 0.1, 1e-05);  primals_45 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_3, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_2 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_46, 1);  primals_46 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(cat_default_2, primals_49, primals_50, primals_47, primals_48, True, 0.1, 1e-05);  primals_50 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_4, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_51, 1);  primals_51 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_54, primals_55, primals_52, primals_53, True, 0.1, 1e-05);  primals_55 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_5, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_56, 1);  primals_56 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_59, primals_60, primals_57, primals_58, True, 0.1, 1e-05);  primals_60 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_6, primals_13, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_61, 1);  primals_61 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_64, primals_65, primals_62, primals_63, True, 0.1, 1e-05);  primals_65 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_7, primals_14, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_4 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_66, 1);  primals_66 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(cat_default_4, primals_69, primals_70, primals_67, primals_68, True, 0.1, 1e-05);  primals_70 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_8, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_71, 1);  primals_71 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_74, primals_75, primals_72, primals_73, True, 0.1, 1e-05);  primals_75 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_9, primals_16, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_5 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_76, 1);  primals_76 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(cat_default_5, primals_79, primals_80, primals_77, primals_78, True, 0.1, 1e-05);  primals_80 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_10, primals_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_81, 1);  primals_81 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_84, primals_85, primals_82, primals_83, True, 0.1, 1e-05);  primals_85 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_33);  getitem_33 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_11, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_6 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_86, 1);  primals_86 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(cat_default_6, primals_89, primals_90, primals_87, primals_88, True, 0.1, 1e-05);  primals_90 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_12, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_91, 1);  primals_91 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_94, primals_95, primals_92, primals_93, True, 0.1, 1e-05);  primals_95 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_13, primals_20, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_7 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_96, 1);  primals_96 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(cat_default_7, primals_99, primals_100, primals_97, primals_98, True, 0.1, 1e-05);  primals_100 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_42);  getitem_42 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_14, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_101, 1);  primals_101 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_104, primals_105, primals_102, primals_103, True, 0.1, 1e-05);  primals_105 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_15, primals_22, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_8 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_106, 1);  primals_106 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(cat_default_8, primals_109, primals_110, primals_107, primals_108, True, 0.1, 1e-05);  primals_110 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_16, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_111, 1);  primals_111 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_114, primals_115, primals_112, primals_113, True, 0.1, 1e-05);  primals_115 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_51);  getitem_51 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_17, primals_24, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_9 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_116, 1);  primals_116 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(cat_default_9, primals_119, primals_120, primals_117, primals_118, True, 0.1, 1e-05);  primals_120 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_18, primals_1, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_121, 1);  primals_121 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_124, primals_125, primals_122, primals_123, True, 0.1, 1e-05);  primals_125 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_19, primals_2, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_10 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_126, 1);  primals_126 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(cat_default_10, primals_129, primals_130, primals_127, primals_128, True, 0.1, 1e-05);  primals_130 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_20, primals_3, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_131, 1);  primals_131 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_134, primals_135, primals_132, primals_133, True, 0.1, 1e-05);  primals_135 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_63);  getitem_63 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_21, primals_4, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_11 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_136, 1);  primals_136 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(cat_default_11, primals_139, primals_140, primals_137, primals_138, True, 0.1, 1e-05);  primals_140 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_22, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_141, 1);  primals_141 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_144, primals_145, primals_142, primals_143, True, 0.1, 1e-05);  primals_145 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_23, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        cat_default_12 = torch.ops.aten.cat.default([primals_25, convolution_default_1, convolution_default_3, convolution_default_5, convolution_default_7, convolution_default_9, convolution_default_11, convolution_default_13, convolution_default_15, convolution_default_17, convolution_default_19, convolution_default_21, convolution_default_23], 1);  primals_25 = convolution_default_1 = convolution_default_3 = convolution_default_5 = convolution_default_7 = convolution_default_9 = convolution_default_11 = convolution_default_13 = convolution_default_15 = convolution_default_17 = convolution_default_19 = convolution_default_21 = convolution_default_23 = None
        return [cat_default_12, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_23, primals_20, primals_28, relu__default_5, primals_14, getitem_1, cat_default_5, convolution_default_20, getitem_65, getitem_8, relu__default_7, getitem_68, primals_143, convolution_default_2, getitem_19, primals_79, relu__default_21, relu__default_16, primals_59, getitem_49, primals_78, getitem_58, getitem_5, relu__default_17, getitem_17, getitem_50, primals_39, getitem_2, getitem_61, primals_27, cat_default_6, cat_default, relu__default_23, getitem_13, primals_33, relu__default_6, primals_63, primals_22, primals_68, primals_72, convolution_default_16, primals_37, primals_144, primals_15, primals_64, relu__default_20, relu__default_22, primals_21, primals_138, relu__default_1, primals_16, primals_69, getitem_67, cat_default_9, primals_62, getitem_20, primals_17, relu__default_9, getitem_7, getitem_62, primals_142, getitem_10, getitem_35, getitem_22, convolution_default, getitem_4, primals_67, primals_139, cat_default_3, primals_73, getitem_43, getitem_52, primals_19, relu__default, primals_18, getitem_28, relu__default_2, primals_74, cat_default_4, getitem_56, cat_default_1, convolution_default_6, getitem_64, primals_23, primals_32, getitem_23, getitem_55, cat_default_11, primals_24, primals_34, getitem_70, getitem_53, primals_38, relu__default_11, primals_77, getitem_29, getitem_44, primals_29, getitem_34, primals_12, primals_114, primals_129, convolution_default_4, primals_103, primals_123, primals_127, primals_89, getitem_26, primals_82, getitem_32, getitem_37, getitem_46, primals_54, primals_112, primals_3, primals_8, relu__default_10, primals_94, primals_128, getitem_11, primals_97, primals_132, getitem_25, primals_119, cat_default_10, primals_11, primals_122, relu__default_3, primals_13, primals_4, convolution_default_10, cat_default_8, primals_57, primals_118, primals_2, primals_99, convolution_default_14, primals_134, relu__default_12, relu__default_19, cat_default_2, primals_117, primals_5, cat_default_7, primals_113, primals_108, convolution_default_22, primals_84, relu__default_14, primals_44, getitem_16, primals_52, getitem_31, relu__default_18, getitem_71, primals_9, getitem_38, primals_48, relu__default_4, primals_53, primals_1, primals_42, getitem_47, primals_43, primals_93, relu__default_13, convolution_default_18, primals_58, primals_107, primals_10, primals_87, primals_6, primals_49, getitem_41, primals_133, primals_92, primals_88, primals_124, convolution_default_8, relu__default_8, getitem_59, primals_7, relu__default_15, primals_137, primals_98, primals_104, convolution_default_12, primals_102, getitem_14, getitem_40, primals_47, primals_83, primals_109]
        
