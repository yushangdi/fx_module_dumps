
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/res2net101_26w_4s/res2net101_26w_4s_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_1023, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_10, 1);  primals_10 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, True, 0.1, 1e-05);  primals_9 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        split_tensor = torch.ops.aten.split.Tensor(relu__default_1, 26, 1)
        getitem_8 = split_tensor[0]
        getitem_9 = split_tensor[1]
        getitem_10 = split_tensor[2]
        getitem_11 = split_tensor[3];  split_tensor = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_8, primals_36, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_20, 1);  primals_20 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_23, primals_19, primals_21, primals_22, True, 0.1, 1e-05);  primals_19 = None
        getitem_12 = native_batch_norm_default_2[0]
        getitem_13 = native_batch_norm_default_2[1]
        getitem_14 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_25, 1);  primals_25 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_28, primals_24, primals_26, primals_27, True, 0.1, 1e-05);  primals_24 = None
        getitem_15 = native_batch_norm_default_3[0]
        getitem_16 = native_batch_norm_default_3[1]
        getitem_17 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_10, primals_38, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_30, 1);  primals_30 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_33, primals_29, primals_31, primals_32, True, 0.1, 1e-05);  primals_29 = None
        getitem_18 = native_batch_norm_default_4[0]
        getitem_19 = native_batch_norm_default_4[1]
        getitem_20 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(getitem_11, [3, 3], [1, 1], [1, 1])
        cat_default = torch.ops.aten.cat.default([relu__default_2, relu__default_3, relu__default_4, avg_pool2d_default], 1);  avg_pool2d_default = None
        convolution_default_5 = torch.ops.aten.convolution.default(cat_default, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_15, 1);  primals_15 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_18, primals_14, primals_16, primals_17, True, 0.1, 1e-05);  primals_14 = None
        getitem_21 = native_batch_norm_default_5[0]
        getitem_22 = native_batch_norm_default_5[1]
        getitem_23 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_3, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_41, 1);  primals_41 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_24 = native_batch_norm_default_6[0]
        getitem_25 = native_batch_norm_default_6[1]
        getitem_26 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_21, getitem_24);  getitem_21 = getitem_24 = None
        relu__default_5 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_46, 1);  primals_46 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_49, primals_45, primals_47, primals_48, True, 0.1, 1e-05);  primals_45 = None
        getitem_27 = native_batch_norm_default_7[0]
        getitem_28 = native_batch_norm_default_7[1]
        getitem_29 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        split_tensor_1 = torch.ops.aten.split.Tensor(relu__default_6, 26, 1)
        getitem_30 = split_tensor_1[0]
        getitem_31 = split_tensor_1[1]
        getitem_32 = split_tensor_1[2]
        getitem_33 = split_tensor_1[3];  split_tensor_1 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_30, primals_72, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_56, 1);  primals_56 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_59, primals_55, primals_57, primals_58, True, 0.1, 1e-05);  primals_55 = None
        getitem_34 = native_batch_norm_default_8[0]
        getitem_35 = native_batch_norm_default_8[1]
        getitem_36 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_34);  getitem_34 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_7, getitem_31);  getitem_31 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor, primals_73, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_61, 1);  primals_61 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_64, primals_60, primals_62, primals_63, True, 0.1, 1e-05);  primals_60 = None
        getitem_37 = native_batch_norm_default_9[0]
        getitem_38 = native_batch_norm_default_9[1]
        getitem_39 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_37);  getitem_37 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(relu__default_8, getitem_32);  getitem_32 = None
        convolution_default_10 = torch.ops.aten.convolution.default(add_tensor_1, primals_74, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(primals_66, 1);  primals_66 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_69, primals_65, primals_67, primals_68, True, 0.1, 1e-05);  primals_65 = None
        getitem_40 = native_batch_norm_default_10[0]
        getitem_41 = native_batch_norm_default_10[1]
        getitem_42 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_40);  getitem_40 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_7, relu__default_8, relu__default_9, getitem_33], 1);  getitem_33 = None
        convolution_default_11 = torch.ops.aten.convolution.default(cat_default_1, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_51, 1);  primals_51 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_54, primals_50, primals_52, primals_53, True, 0.1, 1e-05);  primals_50 = None
        getitem_43 = native_batch_norm_default_11[0]
        getitem_44 = native_batch_norm_default_11[1]
        getitem_45 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_43, relu__default_5);  getitem_43 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_13);  add__tensor_13 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_10, primals_100, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_14 = torch.ops.aten.add_.Tensor(primals_76, 1);  primals_76 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_79, primals_75, primals_77, primals_78, True, 0.1, 1e-05);  primals_75 = None
        getitem_46 = native_batch_norm_default_12[0]
        getitem_47 = native_batch_norm_default_12[1]
        getitem_48 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_46);  getitem_46 = None
        split_tensor_2 = torch.ops.aten.split.Tensor(relu__default_11, 26, 1)
        getitem_49 = split_tensor_2[0]
        getitem_50 = split_tensor_2[1]
        getitem_51 = split_tensor_2[2]
        getitem_52 = split_tensor_2[3];  split_tensor_2 = None
        convolution_default_13 = torch.ops.aten.convolution.default(getitem_49, primals_102, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_86, 1);  primals_86 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_89, primals_85, primals_87, primals_88, True, 0.1, 1e-05);  primals_85 = None
        getitem_53 = native_batch_norm_default_13[0]
        getitem_54 = native_batch_norm_default_13[1]
        getitem_55 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(relu__default_12, getitem_50);  getitem_50 = None
        convolution_default_14 = torch.ops.aten.convolution.default(add_tensor_2, primals_103, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_91, 1);  primals_91 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_94, primals_90, primals_92, primals_93, True, 0.1, 1e-05);  primals_90 = None
        getitem_56 = native_batch_norm_default_14[0]
        getitem_57 = native_batch_norm_default_14[1]
        getitem_58 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(relu__default_13, getitem_51);  getitem_51 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_3, primals_104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_96, 1);  primals_96 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_99, primals_95, primals_97, primals_98, True, 0.1, 1e-05);  primals_95 = None
        getitem_59 = native_batch_norm_default_15[0]
        getitem_60 = native_batch_norm_default_15[1]
        getitem_61 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_12, relu__default_13, relu__default_14, getitem_52], 1);  getitem_52 = None
        convolution_default_16 = torch.ops.aten.convolution.default(cat_default_2, primals_101, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_81, 1);  primals_81 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_84, primals_80, primals_82, primals_83, True, 0.1, 1e-05);  primals_80 = None
        getitem_62 = native_batch_norm_default_16[0]
        getitem_63 = native_batch_norm_default_16[1]
        getitem_64 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_19 = torch.ops.aten.add_.Tensor(getitem_62, relu__default_10);  getitem_62 = None
        relu__default_15 = torch.ops.aten.relu_.default(add__tensor_19);  add__tensor_19 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_15, primals_130, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_20 = torch.ops.aten.add_.Tensor(primals_106, 1);  primals_106 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_109, primals_105, primals_107, primals_108, True, 0.1, 1e-05);  primals_105 = None
        getitem_65 = native_batch_norm_default_17[0]
        getitem_66 = native_batch_norm_default_17[1]
        getitem_67 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        split_tensor_3 = torch.ops.aten.split.Tensor(relu__default_16, 52, 1)
        getitem_68 = split_tensor_3[0]
        getitem_69 = split_tensor_3[1]
        getitem_70 = split_tensor_3[2]
        getitem_71 = split_tensor_3[3];  split_tensor_3 = None
        convolution_default_18 = torch.ops.aten.convolution.default(getitem_68, primals_132, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_116, 1);  primals_116 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_119, primals_115, primals_117, primals_118, True, 0.1, 1e-05);  primals_115 = None
        getitem_72 = native_batch_norm_default_18[0]
        getitem_73 = native_batch_norm_default_18[1]
        getitem_74 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_19 = torch.ops.aten.convolution.default(getitem_69, primals_133, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_121, 1);  primals_121 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_124, primals_120, primals_122, primals_123, True, 0.1, 1e-05);  primals_120 = None
        getitem_75 = native_batch_norm_default_19[0]
        getitem_76 = native_batch_norm_default_19[1]
        getitem_77 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_70, primals_134, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_23 = torch.ops.aten.add_.Tensor(primals_126, 1);  primals_126 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_129, primals_125, primals_127, primals_128, True, 0.1, 1e-05);  primals_125 = None
        getitem_78 = native_batch_norm_default_20[0]
        getitem_79 = native_batch_norm_default_20[1]
        getitem_80 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(getitem_71, [3, 3], [2, 2], [1, 1])
        cat_default_3 = torch.ops.aten.cat.default([relu__default_17, relu__default_18, relu__default_19, avg_pool2d_default_1], 1);  avg_pool2d_default_1 = None
        convolution_default_21 = torch.ops.aten.convolution.default(cat_default_3, primals_131, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_24 = torch.ops.aten.add_.Tensor(primals_111, 1);  primals_111 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_114, primals_110, primals_112, primals_113, True, 0.1, 1e-05);  primals_110 = None
        getitem_81 = native_batch_norm_default_21[0]
        getitem_82 = native_batch_norm_default_21[1]
        getitem_83 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_15, primals_135, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_25 = torch.ops.aten.add_.Tensor(primals_137, 1);  primals_137 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_140, primals_136, primals_138, primals_139, True, 0.1, 1e-05);  primals_136 = None
        getitem_84 = native_batch_norm_default_22[0]
        getitem_85 = native_batch_norm_default_22[1]
        getitem_86 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_26 = torch.ops.aten.add_.Tensor(getitem_81, getitem_84);  getitem_81 = getitem_84 = None
        relu__default_20 = torch.ops.aten.relu_.default(add__tensor_26);  add__tensor_26 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_20, primals_166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_142, 1);  primals_142 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_145, primals_141, primals_143, primals_144, True, 0.1, 1e-05);  primals_141 = None
        getitem_87 = native_batch_norm_default_23[0]
        getitem_88 = native_batch_norm_default_23[1]
        getitem_89 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        split_tensor_4 = torch.ops.aten.split.Tensor(relu__default_21, 52, 1)
        getitem_90 = split_tensor_4[0]
        getitem_91 = split_tensor_4[1]
        getitem_92 = split_tensor_4[2]
        getitem_93 = split_tensor_4[3];  split_tensor_4 = None
        convolution_default_24 = torch.ops.aten.convolution.default(getitem_90, primals_168, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_28 = torch.ops.aten.add_.Tensor(primals_152, 1);  primals_152 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_155, primals_151, primals_153, primals_154, True, 0.1, 1e-05);  primals_151 = None
        getitem_94 = native_batch_norm_default_24[0]
        getitem_95 = native_batch_norm_default_24[1]
        getitem_96 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_94);  getitem_94 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(relu__default_22, getitem_91);  getitem_91 = None
        convolution_default_25 = torch.ops.aten.convolution.default(add_tensor_4, primals_169, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_29 = torch.ops.aten.add_.Tensor(primals_157, 1);  primals_157 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_160, primals_156, primals_158, primals_159, True, 0.1, 1e-05);  primals_156 = None
        getitem_97 = native_batch_norm_default_25[0]
        getitem_98 = native_batch_norm_default_25[1]
        getitem_99 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_97);  getitem_97 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(relu__default_23, getitem_92);  getitem_92 = None
        convolution_default_26 = torch.ops.aten.convolution.default(add_tensor_5, primals_170, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_162, 1);  primals_162 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_165, primals_161, primals_163, primals_164, True, 0.1, 1e-05);  primals_161 = None
        getitem_100 = native_batch_norm_default_26[0]
        getitem_101 = native_batch_norm_default_26[1]
        getitem_102 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_100);  getitem_100 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_22, relu__default_23, relu__default_24, getitem_93], 1);  getitem_93 = None
        convolution_default_27 = torch.ops.aten.convolution.default(cat_default_4, primals_167, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_147, 1);  primals_147 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_150, primals_146, primals_148, primals_149, True, 0.1, 1e-05);  primals_146 = None
        getitem_103 = native_batch_norm_default_27[0]
        getitem_104 = native_batch_norm_default_27[1]
        getitem_105 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_32 = torch.ops.aten.add_.Tensor(getitem_103, relu__default_20);  getitem_103 = None
        relu__default_25 = torch.ops.aten.relu_.default(add__tensor_32);  add__tensor_32 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_25, primals_196, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_172, 1);  primals_172 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_175, primals_171, primals_173, primals_174, True, 0.1, 1e-05);  primals_171 = None
        getitem_106 = native_batch_norm_default_28[0]
        getitem_107 = native_batch_norm_default_28[1]
        getitem_108 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_106);  getitem_106 = None
        split_tensor_5 = torch.ops.aten.split.Tensor(relu__default_26, 52, 1)
        getitem_109 = split_tensor_5[0]
        getitem_110 = split_tensor_5[1]
        getitem_111 = split_tensor_5[2]
        getitem_112 = split_tensor_5[3];  split_tensor_5 = None
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_109, primals_198, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_34 = torch.ops.aten.add_.Tensor(primals_182, 1);  primals_182 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_185, primals_181, primals_183, primals_184, True, 0.1, 1e-05);  primals_181 = None
        getitem_113 = native_batch_norm_default_29[0]
        getitem_114 = native_batch_norm_default_29[1]
        getitem_115 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(relu__default_27, getitem_110);  getitem_110 = None
        convolution_default_30 = torch.ops.aten.convolution.default(add_tensor_6, primals_199, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_35 = torch.ops.aten.add_.Tensor(primals_187, 1);  primals_187 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_190, primals_186, primals_188, primals_189, True, 0.1, 1e-05);  primals_186 = None
        getitem_116 = native_batch_norm_default_30[0]
        getitem_117 = native_batch_norm_default_30[1]
        getitem_118 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(relu__default_28, getitem_111);  getitem_111 = None
        convolution_default_31 = torch.ops.aten.convolution.default(add_tensor_7, primals_200, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_36 = torch.ops.aten.add_.Tensor(primals_192, 1);  primals_192 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_195, primals_191, primals_193, primals_194, True, 0.1, 1e-05);  primals_191 = None
        getitem_119 = native_batch_norm_default_31[0]
        getitem_120 = native_batch_norm_default_31[1]
        getitem_121 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_27, relu__default_28, relu__default_29, getitem_112], 1);  getitem_112 = None
        convolution_default_32 = torch.ops.aten.convolution.default(cat_default_5, primals_197, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_177, 1);  primals_177 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_180, primals_176, primals_178, primals_179, True, 0.1, 1e-05);  primals_176 = None
        getitem_122 = native_batch_norm_default_32[0]
        getitem_123 = native_batch_norm_default_32[1]
        getitem_124 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_38 = torch.ops.aten.add_.Tensor(getitem_122, relu__default_25);  getitem_122 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_38);  add__tensor_38 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_30, primals_226, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_39 = torch.ops.aten.add_.Tensor(primals_202, 1);  primals_202 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_205, primals_201, primals_203, primals_204, True, 0.1, 1e-05);  primals_201 = None
        getitem_125 = native_batch_norm_default_33[0]
        getitem_126 = native_batch_norm_default_33[1]
        getitem_127 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        split_tensor_6 = torch.ops.aten.split.Tensor(relu__default_31, 52, 1)
        getitem_128 = split_tensor_6[0]
        getitem_129 = split_tensor_6[1]
        getitem_130 = split_tensor_6[2]
        getitem_131 = split_tensor_6[3];  split_tensor_6 = None
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_128, primals_228, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_40 = torch.ops.aten.add_.Tensor(primals_212, 1);  primals_212 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_215, primals_211, primals_213, primals_214, True, 0.1, 1e-05);  primals_211 = None
        getitem_132 = native_batch_norm_default_34[0]
        getitem_133 = native_batch_norm_default_34[1]
        getitem_134 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(relu__default_32, getitem_129);  getitem_129 = None
        convolution_default_35 = torch.ops.aten.convolution.default(add_tensor_8, primals_229, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_41 = torch.ops.aten.add_.Tensor(primals_217, 1);  primals_217 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_220, primals_216, primals_218, primals_219, True, 0.1, 1e-05);  primals_216 = None
        getitem_135 = native_batch_norm_default_35[0]
        getitem_136 = native_batch_norm_default_35[1]
        getitem_137 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_33 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(relu__default_33, getitem_130);  getitem_130 = None
        convolution_default_36 = torch.ops.aten.convolution.default(add_tensor_9, primals_230, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_42 = torch.ops.aten.add_.Tensor(primals_222, 1);  primals_222 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_225, primals_221, primals_223, primals_224, True, 0.1, 1e-05);  primals_221 = None
        getitem_138 = native_batch_norm_default_36[0]
        getitem_139 = native_batch_norm_default_36[1]
        getitem_140 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_34 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        cat_default_6 = torch.ops.aten.cat.default([relu__default_32, relu__default_33, relu__default_34, getitem_131], 1);  getitem_131 = None
        convolution_default_37 = torch.ops.aten.convolution.default(cat_default_6, primals_227, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_43 = torch.ops.aten.add_.Tensor(primals_207, 1);  primals_207 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_210, primals_206, primals_208, primals_209, True, 0.1, 1e-05);  primals_206 = None
        getitem_141 = native_batch_norm_default_37[0]
        getitem_142 = native_batch_norm_default_37[1]
        getitem_143 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_44 = torch.ops.aten.add_.Tensor(getitem_141, relu__default_30);  getitem_141 = None
        relu__default_35 = torch.ops.aten.relu_.default(add__tensor_44);  add__tensor_44 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_35, primals_256, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_45 = torch.ops.aten.add_.Tensor(primals_232, 1);  primals_232 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_235, primals_231, primals_233, primals_234, True, 0.1, 1e-05);  primals_231 = None
        getitem_144 = native_batch_norm_default_38[0]
        getitem_145 = native_batch_norm_default_38[1]
        getitem_146 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_36 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        split_tensor_7 = torch.ops.aten.split.Tensor(relu__default_36, 104, 1)
        getitem_147 = split_tensor_7[0]
        getitem_148 = split_tensor_7[1]
        getitem_149 = split_tensor_7[2]
        getitem_150 = split_tensor_7[3];  split_tensor_7 = None
        convolution_default_39 = torch.ops.aten.convolution.default(getitem_147, primals_258, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_46 = torch.ops.aten.add_.Tensor(primals_242, 1);  primals_242 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_245, primals_241, primals_243, primals_244, True, 0.1, 1e-05);  primals_241 = None
        getitem_151 = native_batch_norm_default_39[0]
        getitem_152 = native_batch_norm_default_39[1]
        getitem_153 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_151);  getitem_151 = None
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_148, primals_259, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_47 = torch.ops.aten.add_.Tensor(primals_247, 1);  primals_247 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_250, primals_246, primals_248, primals_249, True, 0.1, 1e-05);  primals_246 = None
        getitem_154 = native_batch_norm_default_40[0]
        getitem_155 = native_batch_norm_default_40[1]
        getitem_156 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_38 = torch.ops.aten.relu_.default(getitem_154);  getitem_154 = None
        convolution_default_41 = torch.ops.aten.convolution.default(getitem_149, primals_260, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_48 = torch.ops.aten.add_.Tensor(primals_252, 1);  primals_252 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_255, primals_251, primals_253, primals_254, True, 0.1, 1e-05);  primals_251 = None
        getitem_157 = native_batch_norm_default_41[0]
        getitem_158 = native_batch_norm_default_41[1]
        getitem_159 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_39 = torch.ops.aten.relu_.default(getitem_157);  getitem_157 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(getitem_150, [3, 3], [2, 2], [1, 1])
        cat_default_7 = torch.ops.aten.cat.default([relu__default_37, relu__default_38, relu__default_39, avg_pool2d_default_2], 1);  avg_pool2d_default_2 = None
        convolution_default_42 = torch.ops.aten.convolution.default(cat_default_7, primals_257, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_49 = torch.ops.aten.add_.Tensor(primals_237, 1);  primals_237 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_240, primals_236, primals_238, primals_239, True, 0.1, 1e-05);  primals_236 = None
        getitem_160 = native_batch_norm_default_42[0]
        getitem_161 = native_batch_norm_default_42[1]
        getitem_162 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_35, primals_261, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_50 = torch.ops.aten.add_.Tensor(primals_263, 1);  primals_263 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_266, primals_262, primals_264, primals_265, True, 0.1, 1e-05);  primals_262 = None
        getitem_163 = native_batch_norm_default_43[0]
        getitem_164 = native_batch_norm_default_43[1]
        getitem_165 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_51 = torch.ops.aten.add_.Tensor(getitem_160, getitem_163);  getitem_160 = getitem_163 = None
        relu__default_40 = torch.ops.aten.relu_.default(add__tensor_51);  add__tensor_51 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_40, primals_592, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_52 = torch.ops.aten.add_.Tensor(primals_568, 1);  primals_568 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_571, primals_567, primals_569, primals_570, True, 0.1, 1e-05);  primals_567 = None
        getitem_166 = native_batch_norm_default_44[0]
        getitem_167 = native_batch_norm_default_44[1]
        getitem_168 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_41 = torch.ops.aten.relu_.default(getitem_166);  getitem_166 = None
        split_tensor_8 = torch.ops.aten.split.Tensor(relu__default_41, 104, 1)
        getitem_169 = split_tensor_8[0]
        getitem_170 = split_tensor_8[1]
        getitem_171 = split_tensor_8[2]
        getitem_172 = split_tensor_8[3];  split_tensor_8 = None
        convolution_default_45 = torch.ops.aten.convolution.default(getitem_169, primals_594, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_53 = torch.ops.aten.add_.Tensor(primals_578, 1);  primals_578 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_173 = native_batch_norm_default_45[0]
        getitem_174 = native_batch_norm_default_45[1]
        getitem_175 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_42 = torch.ops.aten.relu_.default(getitem_173);  getitem_173 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(relu__default_42, getitem_170);  getitem_170 = None
        convolution_default_46 = torch.ops.aten.convolution.default(add_tensor_10, primals_595, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_54 = torch.ops.aten.add_.Tensor(primals_583, 1);  primals_583 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_586, primals_582, primals_584, primals_585, True, 0.1, 1e-05);  primals_582 = None
        getitem_176 = native_batch_norm_default_46[0]
        getitem_177 = native_batch_norm_default_46[1]
        getitem_178 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_43 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(relu__default_43, getitem_171);  getitem_171 = None
        convolution_default_47 = torch.ops.aten.convolution.default(add_tensor_11, primals_596, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_55 = torch.ops.aten.add_.Tensor(primals_588, 1);  primals_588 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_591, primals_587, primals_589, primals_590, True, 0.1, 1e-05);  primals_587 = None
        getitem_179 = native_batch_norm_default_47[0]
        getitem_180 = native_batch_norm_default_47[1]
        getitem_181 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_44 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        cat_default_8 = torch.ops.aten.cat.default([relu__default_42, relu__default_43, relu__default_44, getitem_172], 1);  getitem_172 = None
        convolution_default_48 = torch.ops.aten.convolution.default(cat_default_8, primals_593, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_56 = torch.ops.aten.add_.Tensor(primals_573, 1);  primals_573 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_576, primals_572, primals_574, primals_575, True, 0.1, 1e-05);  primals_572 = None
        getitem_182 = native_batch_norm_default_48[0]
        getitem_183 = native_batch_norm_default_48[1]
        getitem_184 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_57 = torch.ops.aten.add_.Tensor(getitem_182, relu__default_40);  getitem_182 = None
        relu__default_45 = torch.ops.aten.relu_.default(add__tensor_57);  add__tensor_57 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_45, primals_712, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_58 = torch.ops.aten.add_.Tensor(primals_688, 1);  primals_688 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_185 = native_batch_norm_default_49[0]
        getitem_186 = native_batch_norm_default_49[1]
        getitem_187 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_46 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        split_tensor_9 = torch.ops.aten.split.Tensor(relu__default_46, 104, 1)
        getitem_188 = split_tensor_9[0]
        getitem_189 = split_tensor_9[1]
        getitem_190 = split_tensor_9[2]
        getitem_191 = split_tensor_9[3];  split_tensor_9 = None
        convolution_default_50 = torch.ops.aten.convolution.default(getitem_188, primals_714, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_59 = torch.ops.aten.add_.Tensor(primals_698, 1);  primals_698 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_701, primals_697, primals_699, primals_700, True, 0.1, 1e-05);  primals_697 = None
        getitem_192 = native_batch_norm_default_50[0]
        getitem_193 = native_batch_norm_default_50[1]
        getitem_194 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_47 = torch.ops.aten.relu_.default(getitem_192);  getitem_192 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(relu__default_47, getitem_189);  getitem_189 = None
        convolution_default_51 = torch.ops.aten.convolution.default(add_tensor_12, primals_715, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_60 = torch.ops.aten.add_.Tensor(primals_703, 1);  primals_703 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_706, primals_702, primals_704, primals_705, True, 0.1, 1e-05);  primals_702 = None
        getitem_195 = native_batch_norm_default_51[0]
        getitem_196 = native_batch_norm_default_51[1]
        getitem_197 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_48 = torch.ops.aten.relu_.default(getitem_195);  getitem_195 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(relu__default_48, getitem_190);  getitem_190 = None
        convolution_default_52 = torch.ops.aten.convolution.default(add_tensor_13, primals_716, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_61 = torch.ops.aten.add_.Tensor(primals_708, 1);  primals_708 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_711, primals_707, primals_709, primals_710, True, 0.1, 1e-05);  primals_707 = None
        getitem_198 = native_batch_norm_default_52[0]
        getitem_199 = native_batch_norm_default_52[1]
        getitem_200 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_49 = torch.ops.aten.relu_.default(getitem_198);  getitem_198 = None
        cat_default_9 = torch.ops.aten.cat.default([relu__default_47, relu__default_48, relu__default_49, getitem_191], 1);  getitem_191 = None
        convolution_default_53 = torch.ops.aten.convolution.default(cat_default_9, primals_713, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_62 = torch.ops.aten.add_.Tensor(primals_693, 1);  primals_693 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_696, primals_692, primals_694, primals_695, True, 0.1, 1e-05);  primals_692 = None
        getitem_201 = native_batch_norm_default_53[0]
        getitem_202 = native_batch_norm_default_53[1]
        getitem_203 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_63 = torch.ops.aten.add_.Tensor(getitem_201, relu__default_45);  getitem_201 = None
        relu__default_50 = torch.ops.aten.relu_.default(add__tensor_63);  add__tensor_63 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_50, primals_742, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_64 = torch.ops.aten.add_.Tensor(primals_718, 1);  primals_718 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_721, primals_717, primals_719, primals_720, True, 0.1, 1e-05);  primals_717 = None
        getitem_204 = native_batch_norm_default_54[0]
        getitem_205 = native_batch_norm_default_54[1]
        getitem_206 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_51 = torch.ops.aten.relu_.default(getitem_204);  getitem_204 = None
        split_tensor_10 = torch.ops.aten.split.Tensor(relu__default_51, 104, 1)
        getitem_207 = split_tensor_10[0]
        getitem_208 = split_tensor_10[1]
        getitem_209 = split_tensor_10[2]
        getitem_210 = split_tensor_10[3];  split_tensor_10 = None
        convolution_default_55 = torch.ops.aten.convolution.default(getitem_207, primals_744, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_65 = torch.ops.aten.add_.Tensor(primals_728, 1);  primals_728 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_731, primals_727, primals_729, primals_730, True, 0.1, 1e-05);  primals_727 = None
        getitem_211 = native_batch_norm_default_55[0]
        getitem_212 = native_batch_norm_default_55[1]
        getitem_213 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_52 = torch.ops.aten.relu_.default(getitem_211);  getitem_211 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(relu__default_52, getitem_208);  getitem_208 = None
        convolution_default_56 = torch.ops.aten.convolution.default(add_tensor_14, primals_745, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_66 = torch.ops.aten.add_.Tensor(primals_733, 1);  primals_733 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_736, primals_732, primals_734, primals_735, True, 0.1, 1e-05);  primals_732 = None
        getitem_214 = native_batch_norm_default_56[0]
        getitem_215 = native_batch_norm_default_56[1]
        getitem_216 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_53 = torch.ops.aten.relu_.default(getitem_214);  getitem_214 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(relu__default_53, getitem_209);  getitem_209 = None
        convolution_default_57 = torch.ops.aten.convolution.default(add_tensor_15, primals_746, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_67 = torch.ops.aten.add_.Tensor(primals_738, 1);  primals_738 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_741, primals_737, primals_739, primals_740, True, 0.1, 1e-05);  primals_737 = None
        getitem_217 = native_batch_norm_default_57[0]
        getitem_218 = native_batch_norm_default_57[1]
        getitem_219 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_54 = torch.ops.aten.relu_.default(getitem_217);  getitem_217 = None
        cat_default_10 = torch.ops.aten.cat.default([relu__default_52, relu__default_53, relu__default_54, getitem_210], 1);  getitem_210 = None
        convolution_default_58 = torch.ops.aten.convolution.default(cat_default_10, primals_743, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_68 = torch.ops.aten.add_.Tensor(primals_723, 1);  primals_723 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_726, primals_722, primals_724, primals_725, True, 0.1, 1e-05);  primals_722 = None
        getitem_220 = native_batch_norm_default_58[0]
        getitem_221 = native_batch_norm_default_58[1]
        getitem_222 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_69 = torch.ops.aten.add_.Tensor(getitem_220, relu__default_50);  getitem_220 = None
        relu__default_55 = torch.ops.aten.relu_.default(add__tensor_69);  add__tensor_69 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_55, primals_772, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_70 = torch.ops.aten.add_.Tensor(primals_748, 1);  primals_748 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_751, primals_747, primals_749, primals_750, True, 0.1, 1e-05);  primals_747 = None
        getitem_223 = native_batch_norm_default_59[0]
        getitem_224 = native_batch_norm_default_59[1]
        getitem_225 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_56 = torch.ops.aten.relu_.default(getitem_223);  getitem_223 = None
        split_tensor_11 = torch.ops.aten.split.Tensor(relu__default_56, 104, 1)
        getitem_226 = split_tensor_11[0]
        getitem_227 = split_tensor_11[1]
        getitem_228 = split_tensor_11[2]
        getitem_229 = split_tensor_11[3];  split_tensor_11 = None
        convolution_default_60 = torch.ops.aten.convolution.default(getitem_226, primals_774, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_71 = torch.ops.aten.add_.Tensor(primals_758, 1);  primals_758 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_761, primals_757, primals_759, primals_760, True, 0.1, 1e-05);  primals_757 = None
        getitem_230 = native_batch_norm_default_60[0]
        getitem_231 = native_batch_norm_default_60[1]
        getitem_232 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_57 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(relu__default_57, getitem_227);  getitem_227 = None
        convolution_default_61 = torch.ops.aten.convolution.default(add_tensor_16, primals_775, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_72 = torch.ops.aten.add_.Tensor(primals_763, 1);  primals_763 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_766, primals_762, primals_764, primals_765, True, 0.1, 1e-05);  primals_762 = None
        getitem_233 = native_batch_norm_default_61[0]
        getitem_234 = native_batch_norm_default_61[1]
        getitem_235 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_58 = torch.ops.aten.relu_.default(getitem_233);  getitem_233 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(relu__default_58, getitem_228);  getitem_228 = None
        convolution_default_62 = torch.ops.aten.convolution.default(add_tensor_17, primals_776, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_73 = torch.ops.aten.add_.Tensor(primals_768, 1);  primals_768 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_771, primals_767, primals_769, primals_770, True, 0.1, 1e-05);  primals_767 = None
        getitem_236 = native_batch_norm_default_62[0]
        getitem_237 = native_batch_norm_default_62[1]
        getitem_238 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_62, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_59 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        cat_default_11 = torch.ops.aten.cat.default([relu__default_57, relu__default_58, relu__default_59, getitem_229], 1);  getitem_229 = None
        convolution_default_63 = torch.ops.aten.convolution.default(cat_default_11, primals_773, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_74 = torch.ops.aten.add_.Tensor(primals_753, 1);  primals_753 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_756, primals_752, primals_754, primals_755, True, 0.1, 1e-05);  primals_752 = None
        getitem_239 = native_batch_norm_default_63[0]
        getitem_240 = native_batch_norm_default_63[1]
        getitem_241 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_75 = torch.ops.aten.add_.Tensor(getitem_239, relu__default_55);  getitem_239 = None
        relu__default_60 = torch.ops.aten.relu_.default(add__tensor_75);  add__tensor_75 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_60, primals_802, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_76 = torch.ops.aten.add_.Tensor(primals_778, 1);  primals_778 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_781, primals_777, primals_779, primals_780, True, 0.1, 1e-05);  primals_777 = None
        getitem_242 = native_batch_norm_default_64[0]
        getitem_243 = native_batch_norm_default_64[1]
        getitem_244 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_61 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        split_tensor_12 = torch.ops.aten.split.Tensor(relu__default_61, 104, 1)
        getitem_245 = split_tensor_12[0]
        getitem_246 = split_tensor_12[1]
        getitem_247 = split_tensor_12[2]
        getitem_248 = split_tensor_12[3];  split_tensor_12 = None
        convolution_default_65 = torch.ops.aten.convolution.default(getitem_245, primals_804, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_77 = torch.ops.aten.add_.Tensor(primals_788, 1);  primals_788 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_791, primals_787, primals_789, primals_790, True, 0.1, 1e-05);  primals_787 = None
        getitem_249 = native_batch_norm_default_65[0]
        getitem_250 = native_batch_norm_default_65[1]
        getitem_251 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_62 = torch.ops.aten.relu_.default(getitem_249);  getitem_249 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(relu__default_62, getitem_246);  getitem_246 = None
        convolution_default_66 = torch.ops.aten.convolution.default(add_tensor_18, primals_805, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_78 = torch.ops.aten.add_.Tensor(primals_793, 1);  primals_793 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_796, primals_792, primals_794, primals_795, True, 0.1, 1e-05);  primals_792 = None
        getitem_252 = native_batch_norm_default_66[0]
        getitem_253 = native_batch_norm_default_66[1]
        getitem_254 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_63 = torch.ops.aten.relu_.default(getitem_252);  getitem_252 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(relu__default_63, getitem_247);  getitem_247 = None
        convolution_default_67 = torch.ops.aten.convolution.default(add_tensor_19, primals_806, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_79 = torch.ops.aten.add_.Tensor(primals_798, 1);  primals_798 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_801, primals_797, primals_799, primals_800, True, 0.1, 1e-05);  primals_797 = None
        getitem_255 = native_batch_norm_default_67[0]
        getitem_256 = native_batch_norm_default_67[1]
        getitem_257 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_67, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_64 = torch.ops.aten.relu_.default(getitem_255);  getitem_255 = None
        cat_default_12 = torch.ops.aten.cat.default([relu__default_62, relu__default_63, relu__default_64, getitem_248], 1);  getitem_248 = None
        convolution_default_68 = torch.ops.aten.convolution.default(cat_default_12, primals_803, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_80 = torch.ops.aten.add_.Tensor(primals_783, 1);  primals_783 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_786, primals_782, primals_784, primals_785, True, 0.1, 1e-05);  primals_782 = None
        getitem_258 = native_batch_norm_default_68[0]
        getitem_259 = native_batch_norm_default_68[1]
        getitem_260 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_81 = torch.ops.aten.add_.Tensor(getitem_258, relu__default_60);  getitem_258 = None
        relu__default_65 = torch.ops.aten.relu_.default(add__tensor_81);  add__tensor_81 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_65, primals_832, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_82 = torch.ops.aten.add_.Tensor(primals_808, 1);  primals_808 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_811, primals_807, primals_809, primals_810, True, 0.1, 1e-05);  primals_807 = None
        getitem_261 = native_batch_norm_default_69[0]
        getitem_262 = native_batch_norm_default_69[1]
        getitem_263 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_66 = torch.ops.aten.relu_.default(getitem_261);  getitem_261 = None
        split_tensor_13 = torch.ops.aten.split.Tensor(relu__default_66, 104, 1)
        getitem_264 = split_tensor_13[0]
        getitem_265 = split_tensor_13[1]
        getitem_266 = split_tensor_13[2]
        getitem_267 = split_tensor_13[3];  split_tensor_13 = None
        convolution_default_70 = torch.ops.aten.convolution.default(getitem_264, primals_834, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_83 = torch.ops.aten.add_.Tensor(primals_818, 1);  primals_818 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_821, primals_817, primals_819, primals_820, True, 0.1, 1e-05);  primals_817 = None
        getitem_268 = native_batch_norm_default_70[0]
        getitem_269 = native_batch_norm_default_70[1]
        getitem_270 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_67 = torch.ops.aten.relu_.default(getitem_268);  getitem_268 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(relu__default_67, getitem_265);  getitem_265 = None
        convolution_default_71 = torch.ops.aten.convolution.default(add_tensor_20, primals_835, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_84 = torch.ops.aten.add_.Tensor(primals_823, 1);  primals_823 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_826, primals_822, primals_824, primals_825, True, 0.1, 1e-05);  primals_822 = None
        getitem_271 = native_batch_norm_default_71[0]
        getitem_272 = native_batch_norm_default_71[1]
        getitem_273 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_71, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_68 = torch.ops.aten.relu_.default(getitem_271);  getitem_271 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(relu__default_68, getitem_266);  getitem_266 = None
        convolution_default_72 = torch.ops.aten.convolution.default(add_tensor_21, primals_836, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_85 = torch.ops.aten.add_.Tensor(primals_828, 1);  primals_828 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_831, primals_827, primals_829, primals_830, True, 0.1, 1e-05);  primals_827 = None
        getitem_274 = native_batch_norm_default_72[0]
        getitem_275 = native_batch_norm_default_72[1]
        getitem_276 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_72, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_69 = torch.ops.aten.relu_.default(getitem_274);  getitem_274 = None
        cat_default_13 = torch.ops.aten.cat.default([relu__default_67, relu__default_68, relu__default_69, getitem_267], 1);  getitem_267 = None
        convolution_default_73 = torch.ops.aten.convolution.default(cat_default_13, primals_833, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_86 = torch.ops.aten.add_.Tensor(primals_813, 1);  primals_813 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_816, primals_812, primals_814, primals_815, True, 0.1, 1e-05);  primals_812 = None
        getitem_277 = native_batch_norm_default_73[0]
        getitem_278 = native_batch_norm_default_73[1]
        getitem_279 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_87 = torch.ops.aten.add_.Tensor(getitem_277, relu__default_65);  getitem_277 = None
        relu__default_70 = torch.ops.aten.relu_.default(add__tensor_87);  add__tensor_87 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_70, primals_862, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_88 = torch.ops.aten.add_.Tensor(primals_838, 1);  primals_838 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_841, primals_837, primals_839, primals_840, True, 0.1, 1e-05);  primals_837 = None
        getitem_280 = native_batch_norm_default_74[0]
        getitem_281 = native_batch_norm_default_74[1]
        getitem_282 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_71 = torch.ops.aten.relu_.default(getitem_280);  getitem_280 = None
        split_tensor_14 = torch.ops.aten.split.Tensor(relu__default_71, 104, 1)
        getitem_283 = split_tensor_14[0]
        getitem_284 = split_tensor_14[1]
        getitem_285 = split_tensor_14[2]
        getitem_286 = split_tensor_14[3];  split_tensor_14 = None
        convolution_default_75 = torch.ops.aten.convolution.default(getitem_283, primals_864, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_89 = torch.ops.aten.add_.Tensor(primals_848, 1);  primals_848 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_851, primals_847, primals_849, primals_850, True, 0.1, 1e-05);  primals_847 = None
        getitem_287 = native_batch_norm_default_75[0]
        getitem_288 = native_batch_norm_default_75[1]
        getitem_289 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_72 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(relu__default_72, getitem_284);  getitem_284 = None
        convolution_default_76 = torch.ops.aten.convolution.default(add_tensor_22, primals_865, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_90 = torch.ops.aten.add_.Tensor(primals_853, 1);  primals_853 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_856, primals_852, primals_854, primals_855, True, 0.1, 1e-05);  primals_852 = None
        getitem_290 = native_batch_norm_default_76[0]
        getitem_291 = native_batch_norm_default_76[1]
        getitem_292 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_73 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(relu__default_73, getitem_285);  getitem_285 = None
        convolution_default_77 = torch.ops.aten.convolution.default(add_tensor_23, primals_866, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_91 = torch.ops.aten.add_.Tensor(primals_858, 1);  primals_858 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_861, primals_857, primals_859, primals_860, True, 0.1, 1e-05);  primals_857 = None
        getitem_293 = native_batch_norm_default_77[0]
        getitem_294 = native_batch_norm_default_77[1]
        getitem_295 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_77, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_74 = torch.ops.aten.relu_.default(getitem_293);  getitem_293 = None
        cat_default_14 = torch.ops.aten.cat.default([relu__default_72, relu__default_73, relu__default_74, getitem_286], 1);  getitem_286 = None
        convolution_default_78 = torch.ops.aten.convolution.default(cat_default_14, primals_863, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_92 = torch.ops.aten.add_.Tensor(primals_843, 1);  primals_843 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_846, primals_842, primals_844, primals_845, True, 0.1, 1e-05);  primals_842 = None
        getitem_296 = native_batch_norm_default_78[0]
        getitem_297 = native_batch_norm_default_78[1]
        getitem_298 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_93 = torch.ops.aten.add_.Tensor(getitem_296, relu__default_70);  getitem_296 = None
        relu__default_75 = torch.ops.aten.relu_.default(add__tensor_93);  add__tensor_93 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_75, primals_892, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_94 = torch.ops.aten.add_.Tensor(primals_868, 1);  primals_868 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_871, primals_867, primals_869, primals_870, True, 0.1, 1e-05);  primals_867 = None
        getitem_299 = native_batch_norm_default_79[0]
        getitem_300 = native_batch_norm_default_79[1]
        getitem_301 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_76 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        split_tensor_15 = torch.ops.aten.split.Tensor(relu__default_76, 104, 1)
        getitem_302 = split_tensor_15[0]
        getitem_303 = split_tensor_15[1]
        getitem_304 = split_tensor_15[2]
        getitem_305 = split_tensor_15[3];  split_tensor_15 = None
        convolution_default_80 = torch.ops.aten.convolution.default(getitem_302, primals_894, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_95 = torch.ops.aten.add_.Tensor(primals_878, 1);  primals_878 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_881, primals_877, primals_879, primals_880, True, 0.1, 1e-05);  primals_877 = None
        getitem_306 = native_batch_norm_default_80[0]
        getitem_307 = native_batch_norm_default_80[1]
        getitem_308 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_77 = torch.ops.aten.relu_.default(getitem_306);  getitem_306 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(relu__default_77, getitem_303);  getitem_303 = None
        convolution_default_81 = torch.ops.aten.convolution.default(add_tensor_24, primals_895, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_96 = torch.ops.aten.add_.Tensor(primals_883, 1);  primals_883 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_886, primals_882, primals_884, primals_885, True, 0.1, 1e-05);  primals_882 = None
        getitem_309 = native_batch_norm_default_81[0]
        getitem_310 = native_batch_norm_default_81[1]
        getitem_311 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_81, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_78 = torch.ops.aten.relu_.default(getitem_309);  getitem_309 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(relu__default_78, getitem_304);  getitem_304 = None
        convolution_default_82 = torch.ops.aten.convolution.default(add_tensor_25, primals_896, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_97 = torch.ops.aten.add_.Tensor(primals_888, 1);  primals_888 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_891, primals_887, primals_889, primals_890, True, 0.1, 1e-05);  primals_887 = None
        getitem_312 = native_batch_norm_default_82[0]
        getitem_313 = native_batch_norm_default_82[1]
        getitem_314 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_82, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_79 = torch.ops.aten.relu_.default(getitem_312);  getitem_312 = None
        cat_default_15 = torch.ops.aten.cat.default([relu__default_77, relu__default_78, relu__default_79, getitem_305], 1);  getitem_305 = None
        convolution_default_83 = torch.ops.aten.convolution.default(cat_default_15, primals_893, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_98 = torch.ops.aten.add_.Tensor(primals_873, 1);  primals_873 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_876, primals_872, primals_874, primals_875, True, 0.1, 1e-05);  primals_872 = None
        getitem_315 = native_batch_norm_default_83[0]
        getitem_316 = native_batch_norm_default_83[1]
        getitem_317 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_99 = torch.ops.aten.add_.Tensor(getitem_315, relu__default_75);  getitem_315 = None
        relu__default_80 = torch.ops.aten.relu_.default(add__tensor_99);  add__tensor_99 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_80, primals_922, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_100 = torch.ops.aten.add_.Tensor(primals_898, 1);  primals_898 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_901, primals_897, primals_899, primals_900, True, 0.1, 1e-05);  primals_897 = None
        getitem_318 = native_batch_norm_default_84[0]
        getitem_319 = native_batch_norm_default_84[1]
        getitem_320 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_81 = torch.ops.aten.relu_.default(getitem_318);  getitem_318 = None
        split_tensor_16 = torch.ops.aten.split.Tensor(relu__default_81, 104, 1)
        getitem_321 = split_tensor_16[0]
        getitem_322 = split_tensor_16[1]
        getitem_323 = split_tensor_16[2]
        getitem_324 = split_tensor_16[3];  split_tensor_16 = None
        convolution_default_85 = torch.ops.aten.convolution.default(getitem_321, primals_924, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_101 = torch.ops.aten.add_.Tensor(primals_908, 1);  primals_908 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_911, primals_907, primals_909, primals_910, True, 0.1, 1e-05);  primals_907 = None
        getitem_325 = native_batch_norm_default_85[0]
        getitem_326 = native_batch_norm_default_85[1]
        getitem_327 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_82 = torch.ops.aten.relu_.default(getitem_325);  getitem_325 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(relu__default_82, getitem_322);  getitem_322 = None
        convolution_default_86 = torch.ops.aten.convolution.default(add_tensor_26, primals_925, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_102 = torch.ops.aten.add_.Tensor(primals_913, 1);  primals_913 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_916, primals_912, primals_914, primals_915, True, 0.1, 1e-05);  primals_912 = None
        getitem_328 = native_batch_norm_default_86[0]
        getitem_329 = native_batch_norm_default_86[1]
        getitem_330 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_86, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_83 = torch.ops.aten.relu_.default(getitem_328);  getitem_328 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(relu__default_83, getitem_323);  getitem_323 = None
        convolution_default_87 = torch.ops.aten.convolution.default(add_tensor_27, primals_926, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_103 = torch.ops.aten.add_.Tensor(primals_918, 1);  primals_918 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_921, primals_917, primals_919, primals_920, True, 0.1, 1e-05);  primals_917 = None
        getitem_331 = native_batch_norm_default_87[0]
        getitem_332 = native_batch_norm_default_87[1]
        getitem_333 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_87, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_84 = torch.ops.aten.relu_.default(getitem_331);  getitem_331 = None
        cat_default_16 = torch.ops.aten.cat.default([relu__default_82, relu__default_83, relu__default_84, getitem_324], 1);  getitem_324 = None
        convolution_default_88 = torch.ops.aten.convolution.default(cat_default_16, primals_923, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_104 = torch.ops.aten.add_.Tensor(primals_903, 1);  primals_903 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_906, primals_902, primals_904, primals_905, True, 0.1, 1e-05);  primals_902 = None
        getitem_334 = native_batch_norm_default_88[0]
        getitem_335 = native_batch_norm_default_88[1]
        getitem_336 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_105 = torch.ops.aten.add_.Tensor(getitem_334, relu__default_80);  getitem_334 = None
        relu__default_85 = torch.ops.aten.relu_.default(add__tensor_105);  add__tensor_105 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_85, primals_292, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_106 = torch.ops.aten.add_.Tensor(primals_268, 1);  primals_268 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_271, primals_267, primals_269, primals_270, True, 0.1, 1e-05);  primals_267 = None
        getitem_337 = native_batch_norm_default_89[0]
        getitem_338 = native_batch_norm_default_89[1]
        getitem_339 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_86 = torch.ops.aten.relu_.default(getitem_337);  getitem_337 = None
        split_tensor_17 = torch.ops.aten.split.Tensor(relu__default_86, 104, 1)
        getitem_340 = split_tensor_17[0]
        getitem_341 = split_tensor_17[1]
        getitem_342 = split_tensor_17[2]
        getitem_343 = split_tensor_17[3];  split_tensor_17 = None
        convolution_default_90 = torch.ops.aten.convolution.default(getitem_340, primals_294, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_107 = torch.ops.aten.add_.Tensor(primals_278, 1);  primals_278 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_281, primals_277, primals_279, primals_280, True, 0.1, 1e-05);  primals_277 = None
        getitem_344 = native_batch_norm_default_90[0]
        getitem_345 = native_batch_norm_default_90[1]
        getitem_346 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_87 = torch.ops.aten.relu_.default(getitem_344);  getitem_344 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(relu__default_87, getitem_341);  getitem_341 = None
        convolution_default_91 = torch.ops.aten.convolution.default(add_tensor_28, primals_295, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_108 = torch.ops.aten.add_.Tensor(primals_283, 1);  primals_283 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_286, primals_282, primals_284, primals_285, True, 0.1, 1e-05);  primals_282 = None
        getitem_347 = native_batch_norm_default_91[0]
        getitem_348 = native_batch_norm_default_91[1]
        getitem_349 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_91, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_88 = torch.ops.aten.relu_.default(getitem_347);  getitem_347 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(relu__default_88, getitem_342);  getitem_342 = None
        convolution_default_92 = torch.ops.aten.convolution.default(add_tensor_29, primals_296, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_109 = torch.ops.aten.add_.Tensor(primals_288, 1);  primals_288 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_291, primals_287, primals_289, primals_290, True, 0.1, 1e-05);  primals_287 = None
        getitem_350 = native_batch_norm_default_92[0]
        getitem_351 = native_batch_norm_default_92[1]
        getitem_352 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_92, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_89 = torch.ops.aten.relu_.default(getitem_350);  getitem_350 = None
        cat_default_17 = torch.ops.aten.cat.default([relu__default_87, relu__default_88, relu__default_89, getitem_343], 1);  getitem_343 = None
        convolution_default_93 = torch.ops.aten.convolution.default(cat_default_17, primals_293, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_110 = torch.ops.aten.add_.Tensor(primals_273, 1);  primals_273 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_276, primals_272, primals_274, primals_275, True, 0.1, 1e-05);  primals_272 = None
        getitem_353 = native_batch_norm_default_93[0]
        getitem_354 = native_batch_norm_default_93[1]
        getitem_355 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_111 = torch.ops.aten.add_.Tensor(getitem_353, relu__default_85);  getitem_353 = None
        relu__default_90 = torch.ops.aten.relu_.default(add__tensor_111);  add__tensor_111 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_90, primals_322, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_112 = torch.ops.aten.add_.Tensor(primals_298, 1);  primals_298 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_301, primals_297, primals_299, primals_300, True, 0.1, 1e-05);  primals_297 = None
        getitem_356 = native_batch_norm_default_94[0]
        getitem_357 = native_batch_norm_default_94[1]
        getitem_358 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_91 = torch.ops.aten.relu_.default(getitem_356);  getitem_356 = None
        split_tensor_18 = torch.ops.aten.split.Tensor(relu__default_91, 104, 1)
        getitem_359 = split_tensor_18[0]
        getitem_360 = split_tensor_18[1]
        getitem_361 = split_tensor_18[2]
        getitem_362 = split_tensor_18[3];  split_tensor_18 = None
        convolution_default_95 = torch.ops.aten.convolution.default(getitem_359, primals_324, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_113 = torch.ops.aten.add_.Tensor(primals_308, 1);  primals_308 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_311, primals_307, primals_309, primals_310, True, 0.1, 1e-05);  primals_307 = None
        getitem_363 = native_batch_norm_default_95[0]
        getitem_364 = native_batch_norm_default_95[1]
        getitem_365 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_95, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_92 = torch.ops.aten.relu_.default(getitem_363);  getitem_363 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(relu__default_92, getitem_360);  getitem_360 = None
        convolution_default_96 = torch.ops.aten.convolution.default(add_tensor_30, primals_325, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_114 = torch.ops.aten.add_.Tensor(primals_313, 1);  primals_313 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_316, primals_312, primals_314, primals_315, True, 0.1, 1e-05);  primals_312 = None
        getitem_366 = native_batch_norm_default_96[0]
        getitem_367 = native_batch_norm_default_96[1]
        getitem_368 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_96, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_93 = torch.ops.aten.relu_.default(getitem_366);  getitem_366 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(relu__default_93, getitem_361);  getitem_361 = None
        convolution_default_97 = torch.ops.aten.convolution.default(add_tensor_31, primals_326, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_115 = torch.ops.aten.add_.Tensor(primals_318, 1);  primals_318 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_321, primals_317, primals_319, primals_320, True, 0.1, 1e-05);  primals_317 = None
        getitem_369 = native_batch_norm_default_97[0]
        getitem_370 = native_batch_norm_default_97[1]
        getitem_371 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_97, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_94 = torch.ops.aten.relu_.default(getitem_369);  getitem_369 = None
        cat_default_18 = torch.ops.aten.cat.default([relu__default_92, relu__default_93, relu__default_94, getitem_362], 1);  getitem_362 = None
        convolution_default_98 = torch.ops.aten.convolution.default(cat_default_18, primals_323, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_116 = torch.ops.aten.add_.Tensor(primals_303, 1);  primals_303 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_306, primals_302, primals_304, primals_305, True, 0.1, 1e-05);  primals_302 = None
        getitem_372 = native_batch_norm_default_98[0]
        getitem_373 = native_batch_norm_default_98[1]
        getitem_374 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_117 = torch.ops.aten.add_.Tensor(getitem_372, relu__default_90);  getitem_372 = None
        relu__default_95 = torch.ops.aten.relu_.default(add__tensor_117);  add__tensor_117 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_95, primals_352, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_118 = torch.ops.aten.add_.Tensor(primals_328, 1);  primals_328 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_331, primals_327, primals_329, primals_330, True, 0.1, 1e-05);  primals_327 = None
        getitem_375 = native_batch_norm_default_99[0]
        getitem_376 = native_batch_norm_default_99[1]
        getitem_377 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_99, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_96 = torch.ops.aten.relu_.default(getitem_375);  getitem_375 = None
        split_tensor_19 = torch.ops.aten.split.Tensor(relu__default_96, 104, 1)
        getitem_378 = split_tensor_19[0]
        getitem_379 = split_tensor_19[1]
        getitem_380 = split_tensor_19[2]
        getitem_381 = split_tensor_19[3];  split_tensor_19 = None
        convolution_default_100 = torch.ops.aten.convolution.default(getitem_378, primals_354, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_119 = torch.ops.aten.add_.Tensor(primals_338, 1);  primals_338 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_341, primals_337, primals_339, primals_340, True, 0.1, 1e-05);  primals_337 = None
        getitem_382 = native_batch_norm_default_100[0]
        getitem_383 = native_batch_norm_default_100[1]
        getitem_384 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_97 = torch.ops.aten.relu_.default(getitem_382);  getitem_382 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(relu__default_97, getitem_379);  getitem_379 = None
        convolution_default_101 = torch.ops.aten.convolution.default(add_tensor_32, primals_355, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_120 = torch.ops.aten.add_.Tensor(primals_343, 1);  primals_343 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_346, primals_342, primals_344, primals_345, True, 0.1, 1e-05);  primals_342 = None
        getitem_385 = native_batch_norm_default_101[0]
        getitem_386 = native_batch_norm_default_101[1]
        getitem_387 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_101, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_98 = torch.ops.aten.relu_.default(getitem_385);  getitem_385 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(relu__default_98, getitem_380);  getitem_380 = None
        convolution_default_102 = torch.ops.aten.convolution.default(add_tensor_33, primals_356, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_121 = torch.ops.aten.add_.Tensor(primals_348, 1);  primals_348 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_351, primals_347, primals_349, primals_350, True, 0.1, 1e-05);  primals_347 = None
        getitem_388 = native_batch_norm_default_102[0]
        getitem_389 = native_batch_norm_default_102[1]
        getitem_390 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_102, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_99 = torch.ops.aten.relu_.default(getitem_388);  getitem_388 = None
        cat_default_19 = torch.ops.aten.cat.default([relu__default_97, relu__default_98, relu__default_99, getitem_381], 1);  getitem_381 = None
        convolution_default_103 = torch.ops.aten.convolution.default(cat_default_19, primals_353, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_122 = torch.ops.aten.add_.Tensor(primals_333, 1);  primals_333 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_336, primals_332, primals_334, primals_335, True, 0.1, 1e-05);  primals_332 = None
        getitem_391 = native_batch_norm_default_103[0]
        getitem_392 = native_batch_norm_default_103[1]
        getitem_393 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_103, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_123 = torch.ops.aten.add_.Tensor(getitem_391, relu__default_95);  getitem_391 = None
        relu__default_100 = torch.ops.aten.relu_.default(add__tensor_123);  add__tensor_123 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_100, primals_382, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_124 = torch.ops.aten.add_.Tensor(primals_358, 1);  primals_358 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_361, primals_357, primals_359, primals_360, True, 0.1, 1e-05);  primals_357 = None
        getitem_394 = native_batch_norm_default_104[0]
        getitem_395 = native_batch_norm_default_104[1]
        getitem_396 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_101 = torch.ops.aten.relu_.default(getitem_394);  getitem_394 = None
        split_tensor_20 = torch.ops.aten.split.Tensor(relu__default_101, 104, 1)
        getitem_397 = split_tensor_20[0]
        getitem_398 = split_tensor_20[1]
        getitem_399 = split_tensor_20[2]
        getitem_400 = split_tensor_20[3];  split_tensor_20 = None
        convolution_default_105 = torch.ops.aten.convolution.default(getitem_397, primals_384, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_125 = torch.ops.aten.add_.Tensor(primals_368, 1);  primals_368 = None
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_371, primals_367, primals_369, primals_370, True, 0.1, 1e-05);  primals_367 = None
        getitem_401 = native_batch_norm_default_105[0]
        getitem_402 = native_batch_norm_default_105[1]
        getitem_403 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_105, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_102 = torch.ops.aten.relu_.default(getitem_401);  getitem_401 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(relu__default_102, getitem_398);  getitem_398 = None
        convolution_default_106 = torch.ops.aten.convolution.default(add_tensor_34, primals_385, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_126 = torch.ops.aten.add_.Tensor(primals_373, 1);  primals_373 = None
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_376, primals_372, primals_374, primals_375, True, 0.1, 1e-05);  primals_372 = None
        getitem_404 = native_batch_norm_default_106[0]
        getitem_405 = native_batch_norm_default_106[1]
        getitem_406 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_106, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_103 = torch.ops.aten.relu_.default(getitem_404);  getitem_404 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(relu__default_103, getitem_399);  getitem_399 = None
        convolution_default_107 = torch.ops.aten.convolution.default(add_tensor_35, primals_386, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_127 = torch.ops.aten.add_.Tensor(primals_378, 1);  primals_378 = None
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_381, primals_377, primals_379, primals_380, True, 0.1, 1e-05);  primals_377 = None
        getitem_407 = native_batch_norm_default_107[0]
        getitem_408 = native_batch_norm_default_107[1]
        getitem_409 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_107, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_104 = torch.ops.aten.relu_.default(getitem_407);  getitem_407 = None
        cat_default_20 = torch.ops.aten.cat.default([relu__default_102, relu__default_103, relu__default_104, getitem_400], 1);  getitem_400 = None
        convolution_default_108 = torch.ops.aten.convolution.default(cat_default_20, primals_383, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_128 = torch.ops.aten.add_.Tensor(primals_363, 1);  primals_363 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_366, primals_362, primals_364, primals_365, True, 0.1, 1e-05);  primals_362 = None
        getitem_410 = native_batch_norm_default_108[0]
        getitem_411 = native_batch_norm_default_108[1]
        getitem_412 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_129 = torch.ops.aten.add_.Tensor(getitem_410, relu__default_100);  getitem_410 = None
        relu__default_105 = torch.ops.aten.relu_.default(add__tensor_129);  add__tensor_129 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_105, primals_412, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_130 = torch.ops.aten.add_.Tensor(primals_388, 1);  primals_388 = None
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_391, primals_387, primals_389, primals_390, True, 0.1, 1e-05);  primals_387 = None
        getitem_413 = native_batch_norm_default_109[0]
        getitem_414 = native_batch_norm_default_109[1]
        getitem_415 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_106 = torch.ops.aten.relu_.default(getitem_413);  getitem_413 = None
        split_tensor_21 = torch.ops.aten.split.Tensor(relu__default_106, 104, 1)
        getitem_416 = split_tensor_21[0]
        getitem_417 = split_tensor_21[1]
        getitem_418 = split_tensor_21[2]
        getitem_419 = split_tensor_21[3];  split_tensor_21 = None
        convolution_default_110 = torch.ops.aten.convolution.default(getitem_416, primals_414, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_131 = torch.ops.aten.add_.Tensor(primals_398, 1);  primals_398 = None
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_401, primals_397, primals_399, primals_400, True, 0.1, 1e-05);  primals_397 = None
        getitem_420 = native_batch_norm_default_110[0]
        getitem_421 = native_batch_norm_default_110[1]
        getitem_422 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_107 = torch.ops.aten.relu_.default(getitem_420);  getitem_420 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(relu__default_107, getitem_417);  getitem_417 = None
        convolution_default_111 = torch.ops.aten.convolution.default(add_tensor_36, primals_415, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_132 = torch.ops.aten.add_.Tensor(primals_403, 1);  primals_403 = None
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_406, primals_402, primals_404, primals_405, True, 0.1, 1e-05);  primals_402 = None
        getitem_423 = native_batch_norm_default_111[0]
        getitem_424 = native_batch_norm_default_111[1]
        getitem_425 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_111, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_108 = torch.ops.aten.relu_.default(getitem_423);  getitem_423 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(relu__default_108, getitem_418);  getitem_418 = None
        convolution_default_112 = torch.ops.aten.convolution.default(add_tensor_37, primals_416, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_133 = torch.ops.aten.add_.Tensor(primals_408, 1);  primals_408 = None
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_411, primals_407, primals_409, primals_410, True, 0.1, 1e-05);  primals_407 = None
        getitem_426 = native_batch_norm_default_112[0]
        getitem_427 = native_batch_norm_default_112[1]
        getitem_428 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_112, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_109 = torch.ops.aten.relu_.default(getitem_426);  getitem_426 = None
        cat_default_21 = torch.ops.aten.cat.default([relu__default_107, relu__default_108, relu__default_109, getitem_419], 1);  getitem_419 = None
        convolution_default_113 = torch.ops.aten.convolution.default(cat_default_21, primals_413, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_134 = torch.ops.aten.add_.Tensor(primals_393, 1);  primals_393 = None
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_396, primals_392, primals_394, primals_395, True, 0.1, 1e-05);  primals_392 = None
        getitem_429 = native_batch_norm_default_113[0]
        getitem_430 = native_batch_norm_default_113[1]
        getitem_431 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_113, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_135 = torch.ops.aten.add_.Tensor(getitem_429, relu__default_105);  getitem_429 = None
        relu__default_110 = torch.ops.aten.relu_.default(add__tensor_135);  add__tensor_135 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu__default_110, primals_442, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_136 = torch.ops.aten.add_.Tensor(primals_418, 1);  primals_418 = None
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_421, primals_417, primals_419, primals_420, True, 0.1, 1e-05);  primals_417 = None
        getitem_432 = native_batch_norm_default_114[0]
        getitem_433 = native_batch_norm_default_114[1]
        getitem_434 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_111 = torch.ops.aten.relu_.default(getitem_432);  getitem_432 = None
        split_tensor_22 = torch.ops.aten.split.Tensor(relu__default_111, 104, 1)
        getitem_435 = split_tensor_22[0]
        getitem_436 = split_tensor_22[1]
        getitem_437 = split_tensor_22[2]
        getitem_438 = split_tensor_22[3];  split_tensor_22 = None
        convolution_default_115 = torch.ops.aten.convolution.default(getitem_435, primals_444, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_137 = torch.ops.aten.add_.Tensor(primals_428, 1);  primals_428 = None
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_431, primals_427, primals_429, primals_430, True, 0.1, 1e-05);  primals_427 = None
        getitem_439 = native_batch_norm_default_115[0]
        getitem_440 = native_batch_norm_default_115[1]
        getitem_441 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_115, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_112 = torch.ops.aten.relu_.default(getitem_439);  getitem_439 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(relu__default_112, getitem_436);  getitem_436 = None
        convolution_default_116 = torch.ops.aten.convolution.default(add_tensor_38, primals_445, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_138 = torch.ops.aten.add_.Tensor(primals_433, 1);  primals_433 = None
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_436, primals_432, primals_434, primals_435, True, 0.1, 1e-05);  primals_432 = None
        getitem_442 = native_batch_norm_default_116[0]
        getitem_443 = native_batch_norm_default_116[1]
        getitem_444 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_113 = torch.ops.aten.relu_.default(getitem_442);  getitem_442 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(relu__default_113, getitem_437);  getitem_437 = None
        convolution_default_117 = torch.ops.aten.convolution.default(add_tensor_39, primals_446, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_139 = torch.ops.aten.add_.Tensor(primals_438, 1);  primals_438 = None
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_441, primals_437, primals_439, primals_440, True, 0.1, 1e-05);  primals_437 = None
        getitem_445 = native_batch_norm_default_117[0]
        getitem_446 = native_batch_norm_default_117[1]
        getitem_447 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_117, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_114 = torch.ops.aten.relu_.default(getitem_445);  getitem_445 = None
        cat_default_22 = torch.ops.aten.cat.default([relu__default_112, relu__default_113, relu__default_114, getitem_438], 1);  getitem_438 = None
        convolution_default_118 = torch.ops.aten.convolution.default(cat_default_22, primals_443, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_140 = torch.ops.aten.add_.Tensor(primals_423, 1);  primals_423 = None
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_426, primals_422, primals_424, primals_425, True, 0.1, 1e-05);  primals_422 = None
        getitem_448 = native_batch_norm_default_118[0]
        getitem_449 = native_batch_norm_default_118[1]
        getitem_450 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_118, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_141 = torch.ops.aten.add_.Tensor(getitem_448, relu__default_110);  getitem_448 = None
        relu__default_115 = torch.ops.aten.relu_.default(add__tensor_141);  add__tensor_141 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu__default_115, primals_472, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_142 = torch.ops.aten.add_.Tensor(primals_448, 1);  primals_448 = None
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_451, primals_447, primals_449, primals_450, True, 0.1, 1e-05);  primals_447 = None
        getitem_451 = native_batch_norm_default_119[0]
        getitem_452 = native_batch_norm_default_119[1]
        getitem_453 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_116 = torch.ops.aten.relu_.default(getitem_451);  getitem_451 = None
        split_tensor_23 = torch.ops.aten.split.Tensor(relu__default_116, 104, 1)
        getitem_454 = split_tensor_23[0]
        getitem_455 = split_tensor_23[1]
        getitem_456 = split_tensor_23[2]
        getitem_457 = split_tensor_23[3];  split_tensor_23 = None
        convolution_default_120 = torch.ops.aten.convolution.default(getitem_454, primals_474, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_143 = torch.ops.aten.add_.Tensor(primals_458, 1);  primals_458 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_461, primals_457, primals_459, primals_460, True, 0.1, 1e-05);  primals_457 = None
        getitem_458 = native_batch_norm_default_120[0]
        getitem_459 = native_batch_norm_default_120[1]
        getitem_460 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_117 = torch.ops.aten.relu_.default(getitem_458);  getitem_458 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(relu__default_117, getitem_455);  getitem_455 = None
        convolution_default_121 = torch.ops.aten.convolution.default(add_tensor_40, primals_475, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_144 = torch.ops.aten.add_.Tensor(primals_463, 1);  primals_463 = None
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_466, primals_462, primals_464, primals_465, True, 0.1, 1e-05);  primals_462 = None
        getitem_461 = native_batch_norm_default_121[0]
        getitem_462 = native_batch_norm_default_121[1]
        getitem_463 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_121, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_118 = torch.ops.aten.relu_.default(getitem_461);  getitem_461 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(relu__default_118, getitem_456);  getitem_456 = None
        convolution_default_122 = torch.ops.aten.convolution.default(add_tensor_41, primals_476, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_145 = torch.ops.aten.add_.Tensor(primals_468, 1);  primals_468 = None
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_471, primals_467, primals_469, primals_470, True, 0.1, 1e-05);  primals_467 = None
        getitem_464 = native_batch_norm_default_122[0]
        getitem_465 = native_batch_norm_default_122[1]
        getitem_466 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_119 = torch.ops.aten.relu_.default(getitem_464);  getitem_464 = None
        cat_default_23 = torch.ops.aten.cat.default([relu__default_117, relu__default_118, relu__default_119, getitem_457], 1);  getitem_457 = None
        convolution_default_123 = torch.ops.aten.convolution.default(cat_default_23, primals_473, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_146 = torch.ops.aten.add_.Tensor(primals_453, 1);  primals_453 = None
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_456, primals_452, primals_454, primals_455, True, 0.1, 1e-05);  primals_452 = None
        getitem_467 = native_batch_norm_default_123[0]
        getitem_468 = native_batch_norm_default_123[1]
        getitem_469 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_123, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_147 = torch.ops.aten.add_.Tensor(getitem_467, relu__default_115);  getitem_467 = None
        relu__default_120 = torch.ops.aten.relu_.default(add__tensor_147);  add__tensor_147 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_120, primals_502, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_148 = torch.ops.aten.add_.Tensor(primals_478, 1);  primals_478 = None
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_481, primals_477, primals_479, primals_480, True, 0.1, 1e-05);  primals_477 = None
        getitem_470 = native_batch_norm_default_124[0]
        getitem_471 = native_batch_norm_default_124[1]
        getitem_472 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_124, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_121 = torch.ops.aten.relu_.default(getitem_470);  getitem_470 = None
        split_tensor_24 = torch.ops.aten.split.Tensor(relu__default_121, 104, 1)
        getitem_473 = split_tensor_24[0]
        getitem_474 = split_tensor_24[1]
        getitem_475 = split_tensor_24[2]
        getitem_476 = split_tensor_24[3];  split_tensor_24 = None
        convolution_default_125 = torch.ops.aten.convolution.default(getitem_473, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_149 = torch.ops.aten.add_.Tensor(primals_488, 1);  primals_488 = None
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_491, primals_487, primals_489, primals_490, True, 0.1, 1e-05);  primals_487 = None
        getitem_477 = native_batch_norm_default_125[0]
        getitem_478 = native_batch_norm_default_125[1]
        getitem_479 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_125, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_122 = torch.ops.aten.relu_.default(getitem_477);  getitem_477 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(relu__default_122, getitem_474);  getitem_474 = None
        convolution_default_126 = torch.ops.aten.convolution.default(add_tensor_42, primals_505, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_150 = torch.ops.aten.add_.Tensor(primals_493, 1);  primals_493 = None
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_496, primals_492, primals_494, primals_495, True, 0.1, 1e-05);  primals_492 = None
        getitem_480 = native_batch_norm_default_126[0]
        getitem_481 = native_batch_norm_default_126[1]
        getitem_482 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_123 = torch.ops.aten.relu_.default(getitem_480);  getitem_480 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(relu__default_123, getitem_475);  getitem_475 = None
        convolution_default_127 = torch.ops.aten.convolution.default(add_tensor_43, primals_506, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_151 = torch.ops.aten.add_.Tensor(primals_498, 1);  primals_498 = None
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_501, primals_497, primals_499, primals_500, True, 0.1, 1e-05);  primals_497 = None
        getitem_483 = native_batch_norm_default_127[0]
        getitem_484 = native_batch_norm_default_127[1]
        getitem_485 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_127, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_124 = torch.ops.aten.relu_.default(getitem_483);  getitem_483 = None
        cat_default_24 = torch.ops.aten.cat.default([relu__default_122, relu__default_123, relu__default_124, getitem_476], 1);  getitem_476 = None
        convolution_default_128 = torch.ops.aten.convolution.default(cat_default_24, primals_503, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_152 = torch.ops.aten.add_.Tensor(primals_483, 1);  primals_483 = None
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_486, primals_482, primals_484, primals_485, True, 0.1, 1e-05);  primals_482 = None
        getitem_486 = native_batch_norm_default_128[0]
        getitem_487 = native_batch_norm_default_128[1]
        getitem_488 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_153 = torch.ops.aten.add_.Tensor(getitem_486, relu__default_120);  getitem_486 = None
        relu__default_125 = torch.ops.aten.relu_.default(add__tensor_153);  add__tensor_153 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu__default_125, primals_532, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_154 = torch.ops.aten.add_.Tensor(primals_508, 1);  primals_508 = None
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_511, primals_507, primals_509, primals_510, True, 0.1, 1e-05);  primals_507 = None
        getitem_489 = native_batch_norm_default_129[0]
        getitem_490 = native_batch_norm_default_129[1]
        getitem_491 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_129, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_126 = torch.ops.aten.relu_.default(getitem_489);  getitem_489 = None
        split_tensor_25 = torch.ops.aten.split.Tensor(relu__default_126, 104, 1)
        getitem_492 = split_tensor_25[0]
        getitem_493 = split_tensor_25[1]
        getitem_494 = split_tensor_25[2]
        getitem_495 = split_tensor_25[3];  split_tensor_25 = None
        convolution_default_130 = torch.ops.aten.convolution.default(getitem_492, primals_534, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_155 = torch.ops.aten.add_.Tensor(primals_518, 1);  primals_518 = None
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_521, primals_517, primals_519, primals_520, True, 0.1, 1e-05);  primals_517 = None
        getitem_496 = native_batch_norm_default_130[0]
        getitem_497 = native_batch_norm_default_130[1]
        getitem_498 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_130, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_127 = torch.ops.aten.relu_.default(getitem_496);  getitem_496 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(relu__default_127, getitem_493);  getitem_493 = None
        convolution_default_131 = torch.ops.aten.convolution.default(add_tensor_44, primals_535, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_156 = torch.ops.aten.add_.Tensor(primals_523, 1);  primals_523 = None
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_526, primals_522, primals_524, primals_525, True, 0.1, 1e-05);  primals_522 = None
        getitem_499 = native_batch_norm_default_131[0]
        getitem_500 = native_batch_norm_default_131[1]
        getitem_501 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_128 = torch.ops.aten.relu_.default(getitem_499);  getitem_499 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(relu__default_128, getitem_494);  getitem_494 = None
        convolution_default_132 = torch.ops.aten.convolution.default(add_tensor_45, primals_536, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_157 = torch.ops.aten.add_.Tensor(primals_528, 1);  primals_528 = None
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_531, primals_527, primals_529, primals_530, True, 0.1, 1e-05);  primals_527 = None
        getitem_502 = native_batch_norm_default_132[0]
        getitem_503 = native_batch_norm_default_132[1]
        getitem_504 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_132, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_129 = torch.ops.aten.relu_.default(getitem_502);  getitem_502 = None
        cat_default_25 = torch.ops.aten.cat.default([relu__default_127, relu__default_128, relu__default_129, getitem_495], 1);  getitem_495 = None
        convolution_default_133 = torch.ops.aten.convolution.default(cat_default_25, primals_533, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_158 = torch.ops.aten.add_.Tensor(primals_513, 1);  primals_513 = None
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_516, primals_512, primals_514, primals_515, True, 0.1, 1e-05);  primals_512 = None
        getitem_505 = native_batch_norm_default_133[0]
        getitem_506 = native_batch_norm_default_133[1]
        getitem_507 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_133, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_159 = torch.ops.aten.add_.Tensor(getitem_505, relu__default_125);  getitem_505 = None
        relu__default_130 = torch.ops.aten.relu_.default(add__tensor_159);  add__tensor_159 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_130, primals_562, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_160 = torch.ops.aten.add_.Tensor(primals_538, 1);  primals_538 = None
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_541, primals_537, primals_539, primals_540, True, 0.1, 1e-05);  primals_537 = None
        getitem_508 = native_batch_norm_default_134[0]
        getitem_509 = native_batch_norm_default_134[1]
        getitem_510 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_134, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_131 = torch.ops.aten.relu_.default(getitem_508);  getitem_508 = None
        split_tensor_26 = torch.ops.aten.split.Tensor(relu__default_131, 104, 1)
        getitem_511 = split_tensor_26[0]
        getitem_512 = split_tensor_26[1]
        getitem_513 = split_tensor_26[2]
        getitem_514 = split_tensor_26[3];  split_tensor_26 = None
        convolution_default_135 = torch.ops.aten.convolution.default(getitem_511, primals_564, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_161 = torch.ops.aten.add_.Tensor(primals_548, 1);  primals_548 = None
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_551, primals_547, primals_549, primals_550, True, 0.1, 1e-05);  primals_547 = None
        getitem_515 = native_batch_norm_default_135[0]
        getitem_516 = native_batch_norm_default_135[1]
        getitem_517 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_135, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_132 = torch.ops.aten.relu_.default(getitem_515);  getitem_515 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(relu__default_132, getitem_512);  getitem_512 = None
        convolution_default_136 = torch.ops.aten.convolution.default(add_tensor_46, primals_565, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_162 = torch.ops.aten.add_.Tensor(primals_553, 1);  primals_553 = None
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_556, primals_552, primals_554, primals_555, True, 0.1, 1e-05);  primals_552 = None
        getitem_518 = native_batch_norm_default_136[0]
        getitem_519 = native_batch_norm_default_136[1]
        getitem_520 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_136, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_133 = torch.ops.aten.relu_.default(getitem_518);  getitem_518 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(relu__default_133, getitem_513);  getitem_513 = None
        convolution_default_137 = torch.ops.aten.convolution.default(add_tensor_47, primals_566, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_163 = torch.ops.aten.add_.Tensor(primals_558, 1);  primals_558 = None
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_561, primals_557, primals_559, primals_560, True, 0.1, 1e-05);  primals_557 = None
        getitem_521 = native_batch_norm_default_137[0]
        getitem_522 = native_batch_norm_default_137[1]
        getitem_523 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_137, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_134 = torch.ops.aten.relu_.default(getitem_521);  getitem_521 = None
        cat_default_26 = torch.ops.aten.cat.default([relu__default_132, relu__default_133, relu__default_134, getitem_514], 1);  getitem_514 = None
        convolution_default_138 = torch.ops.aten.convolution.default(cat_default_26, primals_563, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_164 = torch.ops.aten.add_.Tensor(primals_543, 1);  primals_543 = None
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_546, primals_542, primals_544, primals_545, True, 0.1, 1e-05);  primals_542 = None
        getitem_524 = native_batch_norm_default_138[0]
        getitem_525 = native_batch_norm_default_138[1]
        getitem_526 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_138, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_165 = torch.ops.aten.add_.Tensor(getitem_524, relu__default_130);  getitem_524 = None
        relu__default_135 = torch.ops.aten.relu_.default(add__tensor_165);  add__tensor_165 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu__default_135, primals_622, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_166 = torch.ops.aten.add_.Tensor(primals_598, 1);  primals_598 = None
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_601, primals_597, primals_599, primals_600, True, 0.1, 1e-05);  primals_597 = None
        getitem_527 = native_batch_norm_default_139[0]
        getitem_528 = native_batch_norm_default_139[1]
        getitem_529 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_139, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_136 = torch.ops.aten.relu_.default(getitem_527);  getitem_527 = None
        split_tensor_27 = torch.ops.aten.split.Tensor(relu__default_136, 104, 1)
        getitem_530 = split_tensor_27[0]
        getitem_531 = split_tensor_27[1]
        getitem_532 = split_tensor_27[2]
        getitem_533 = split_tensor_27[3];  split_tensor_27 = None
        convolution_default_140 = torch.ops.aten.convolution.default(getitem_530, primals_624, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_167 = torch.ops.aten.add_.Tensor(primals_608, 1);  primals_608 = None
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_611, primals_607, primals_609, primals_610, True, 0.1, 1e-05);  primals_607 = None
        getitem_534 = native_batch_norm_default_140[0]
        getitem_535 = native_batch_norm_default_140[1]
        getitem_536 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(convolution_default_140, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_137 = torch.ops.aten.relu_.default(getitem_534);  getitem_534 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(relu__default_137, getitem_531);  getitem_531 = None
        convolution_default_141 = torch.ops.aten.convolution.default(add_tensor_48, primals_625, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_168 = torch.ops.aten.add_.Tensor(primals_613, 1);  primals_613 = None
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_616, primals_612, primals_614, primals_615, True, 0.1, 1e-05);  primals_612 = None
        getitem_537 = native_batch_norm_default_141[0]
        getitem_538 = native_batch_norm_default_141[1]
        getitem_539 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_141, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_138 = torch.ops.aten.relu_.default(getitem_537);  getitem_537 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(relu__default_138, getitem_532);  getitem_532 = None
        convolution_default_142 = torch.ops.aten.convolution.default(add_tensor_49, primals_626, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_169 = torch.ops.aten.add_.Tensor(primals_618, 1);  primals_618 = None
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_621, primals_617, primals_619, primals_620, True, 0.1, 1e-05);  primals_617 = None
        getitem_540 = native_batch_norm_default_142[0]
        getitem_541 = native_batch_norm_default_142[1]
        getitem_542 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_142, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_139 = torch.ops.aten.relu_.default(getitem_540);  getitem_540 = None
        cat_default_27 = torch.ops.aten.cat.default([relu__default_137, relu__default_138, relu__default_139, getitem_533], 1);  getitem_533 = None
        convolution_default_143 = torch.ops.aten.convolution.default(cat_default_27, primals_623, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_170 = torch.ops.aten.add_.Tensor(primals_603, 1);  primals_603 = None
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_606, primals_602, primals_604, primals_605, True, 0.1, 1e-05);  primals_602 = None
        getitem_543 = native_batch_norm_default_143[0]
        getitem_544 = native_batch_norm_default_143[1]
        getitem_545 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(convolution_default_143, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_171 = torch.ops.aten.add_.Tensor(getitem_543, relu__default_135);  getitem_543 = None
        relu__default_140 = torch.ops.aten.relu_.default(add__tensor_171);  add__tensor_171 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_140, primals_652, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_172 = torch.ops.aten.add_.Tensor(primals_628, 1);  primals_628 = None
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_631, primals_627, primals_629, primals_630, True, 0.1, 1e-05);  primals_627 = None
        getitem_546 = native_batch_norm_default_144[0]
        getitem_547 = native_batch_norm_default_144[1]
        getitem_548 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_144, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_141 = torch.ops.aten.relu_.default(getitem_546);  getitem_546 = None
        split_tensor_28 = torch.ops.aten.split.Tensor(relu__default_141, 104, 1)
        getitem_549 = split_tensor_28[0]
        getitem_550 = split_tensor_28[1]
        getitem_551 = split_tensor_28[2]
        getitem_552 = split_tensor_28[3];  split_tensor_28 = None
        convolution_default_145 = torch.ops.aten.convolution.default(getitem_549, primals_654, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_173 = torch.ops.aten.add_.Tensor(primals_638, 1);  primals_638 = None
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_641, primals_637, primals_639, primals_640, True, 0.1, 1e-05);  primals_637 = None
        getitem_553 = native_batch_norm_default_145[0]
        getitem_554 = native_batch_norm_default_145[1]
        getitem_555 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_145, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_142 = torch.ops.aten.relu_.default(getitem_553);  getitem_553 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(relu__default_142, getitem_550);  getitem_550 = None
        convolution_default_146 = torch.ops.aten.convolution.default(add_tensor_50, primals_655, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_174 = torch.ops.aten.add_.Tensor(primals_643, 1);  primals_643 = None
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_646, primals_642, primals_644, primals_645, True, 0.1, 1e-05);  primals_642 = None
        getitem_556 = native_batch_norm_default_146[0]
        getitem_557 = native_batch_norm_default_146[1]
        getitem_558 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(convolution_default_146, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_143 = torch.ops.aten.relu_.default(getitem_556);  getitem_556 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(relu__default_143, getitem_551);  getitem_551 = None
        convolution_default_147 = torch.ops.aten.convolution.default(add_tensor_51, primals_656, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_175 = torch.ops.aten.add_.Tensor(primals_648, 1);  primals_648 = None
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_651, primals_647, primals_649, primals_650, True, 0.1, 1e-05);  primals_647 = None
        getitem_559 = native_batch_norm_default_147[0]
        getitem_560 = native_batch_norm_default_147[1]
        getitem_561 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_147, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_144 = torch.ops.aten.relu_.default(getitem_559);  getitem_559 = None
        cat_default_28 = torch.ops.aten.cat.default([relu__default_142, relu__default_143, relu__default_144, getitem_552], 1);  getitem_552 = None
        convolution_default_148 = torch.ops.aten.convolution.default(cat_default_28, primals_653, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_176 = torch.ops.aten.add_.Tensor(primals_633, 1);  primals_633 = None
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_636, primals_632, primals_634, primals_635, True, 0.1, 1e-05);  primals_632 = None
        getitem_562 = native_batch_norm_default_148[0]
        getitem_563 = native_batch_norm_default_148[1]
        getitem_564 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_148, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_177 = torch.ops.aten.add_.Tensor(getitem_562, relu__default_140);  getitem_562 = None
        relu__default_145 = torch.ops.aten.relu_.default(add__tensor_177);  add__tensor_177 = None
        convolution_default_149 = torch.ops.aten.convolution.default(relu__default_145, primals_682, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_178 = torch.ops.aten.add_.Tensor(primals_658, 1);  primals_658 = None
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_661, primals_657, primals_659, primals_660, True, 0.1, 1e-05);  primals_657 = None
        getitem_565 = native_batch_norm_default_149[0]
        getitem_566 = native_batch_norm_default_149[1]
        getitem_567 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(convolution_default_149, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_146 = torch.ops.aten.relu_.default(getitem_565);  getitem_565 = None
        split_tensor_29 = torch.ops.aten.split.Tensor(relu__default_146, 104, 1)
        getitem_568 = split_tensor_29[0]
        getitem_569 = split_tensor_29[1]
        getitem_570 = split_tensor_29[2]
        getitem_571 = split_tensor_29[3];  split_tensor_29 = None
        convolution_default_150 = torch.ops.aten.convolution.default(getitem_568, primals_684, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_179 = torch.ops.aten.add_.Tensor(primals_668, 1);  primals_668 = None
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_671, primals_667, primals_669, primals_670, True, 0.1, 1e-05);  primals_667 = None
        getitem_572 = native_batch_norm_default_150[0]
        getitem_573 = native_batch_norm_default_150[1]
        getitem_574 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(convolution_default_150, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_147 = torch.ops.aten.relu_.default(getitem_572);  getitem_572 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(relu__default_147, getitem_569);  getitem_569 = None
        convolution_default_151 = torch.ops.aten.convolution.default(add_tensor_52, primals_685, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_180 = torch.ops.aten.add_.Tensor(primals_673, 1);  primals_673 = None
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_676, primals_672, primals_674, primals_675, True, 0.1, 1e-05);  primals_672 = None
        getitem_575 = native_batch_norm_default_151[0]
        getitem_576 = native_batch_norm_default_151[1]
        getitem_577 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(convolution_default_151, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_148 = torch.ops.aten.relu_.default(getitem_575);  getitem_575 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(relu__default_148, getitem_570);  getitem_570 = None
        convolution_default_152 = torch.ops.aten.convolution.default(add_tensor_53, primals_686, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_181 = torch.ops.aten.add_.Tensor(primals_678, 1);  primals_678 = None
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_681, primals_677, primals_679, primals_680, True, 0.1, 1e-05);  primals_677 = None
        getitem_578 = native_batch_norm_default_152[0]
        getitem_579 = native_batch_norm_default_152[1]
        getitem_580 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(convolution_default_152, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_149 = torch.ops.aten.relu_.default(getitem_578);  getitem_578 = None
        cat_default_29 = torch.ops.aten.cat.default([relu__default_147, relu__default_148, relu__default_149, getitem_571], 1);  getitem_571 = None
        convolution_default_153 = torch.ops.aten.convolution.default(cat_default_29, primals_683, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_182 = torch.ops.aten.add_.Tensor(primals_663, 1);  primals_663 = None
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_666, primals_662, primals_664, primals_665, True, 0.1, 1e-05);  primals_662 = None
        getitem_581 = native_batch_norm_default_153[0]
        getitem_582 = native_batch_norm_default_153[1]
        getitem_583 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(convolution_default_153, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_183 = torch.ops.aten.add_.Tensor(getitem_581, relu__default_145);  getitem_581 = None
        relu__default_150 = torch.ops.aten.relu_.default(add__tensor_183);  add__tensor_183 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu__default_150, primals_952, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_184 = torch.ops.aten.add_.Tensor(primals_928, 1);  primals_928 = None
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_931, primals_927, primals_929, primals_930, True, 0.1, 1e-05);  primals_927 = None
        getitem_584 = native_batch_norm_default_154[0]
        getitem_585 = native_batch_norm_default_154[1]
        getitem_586 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(convolution_default_154, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_151 = torch.ops.aten.relu_.default(getitem_584);  getitem_584 = None
        split_tensor_30 = torch.ops.aten.split.Tensor(relu__default_151, 208, 1)
        getitem_587 = split_tensor_30[0]
        getitem_588 = split_tensor_30[1]
        getitem_589 = split_tensor_30[2]
        getitem_590 = split_tensor_30[3];  split_tensor_30 = None
        convolution_default_155 = torch.ops.aten.convolution.default(getitem_587, primals_954, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_185 = torch.ops.aten.add_.Tensor(primals_938, 1);  primals_938 = None
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_941, primals_937, primals_939, primals_940, True, 0.1, 1e-05);  primals_937 = None
        getitem_591 = native_batch_norm_default_155[0]
        getitem_592 = native_batch_norm_default_155[1]
        getitem_593 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(convolution_default_155, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_152 = torch.ops.aten.relu_.default(getitem_591);  getitem_591 = None
        convolution_default_156 = torch.ops.aten.convolution.default(getitem_588, primals_955, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_186 = torch.ops.aten.add_.Tensor(primals_943, 1);  primals_943 = None
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_946, primals_942, primals_944, primals_945, True, 0.1, 1e-05);  primals_942 = None
        getitem_594 = native_batch_norm_default_156[0]
        getitem_595 = native_batch_norm_default_156[1]
        getitem_596 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(convolution_default_156, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_153 = torch.ops.aten.relu_.default(getitem_594);  getitem_594 = None
        convolution_default_157 = torch.ops.aten.convolution.default(getitem_589, primals_956, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_187 = torch.ops.aten.add_.Tensor(primals_948, 1);  primals_948 = None
        native_batch_norm_default_157 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_951, primals_947, primals_949, primals_950, True, 0.1, 1e-05);  primals_947 = None
        getitem_597 = native_batch_norm_default_157[0]
        getitem_598 = native_batch_norm_default_157[1]
        getitem_599 = native_batch_norm_default_157[2];  native_batch_norm_default_157 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(convolution_default_157, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_154 = torch.ops.aten.relu_.default(getitem_597);  getitem_597 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(getitem_590, [3, 3], [2, 2], [1, 1])
        cat_default_30 = torch.ops.aten.cat.default([relu__default_152, relu__default_153, relu__default_154, avg_pool2d_default_3], 1);  avg_pool2d_default_3 = None
        convolution_default_158 = torch.ops.aten.convolution.default(cat_default_30, primals_953, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_188 = torch.ops.aten.add_.Tensor(primals_933, 1);  primals_933 = None
        native_batch_norm_default_158 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_936, primals_932, primals_934, primals_935, True, 0.1, 1e-05);  primals_932 = None
        getitem_600 = native_batch_norm_default_158[0]
        getitem_601 = native_batch_norm_default_158[1]
        getitem_602 = native_batch_norm_default_158[2];  native_batch_norm_default_158 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(convolution_default_158, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_159 = torch.ops.aten.convolution.default(relu__default_150, primals_957, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_189 = torch.ops.aten.add_.Tensor(primals_959, 1);  primals_959 = None
        native_batch_norm_default_159 = torch.ops.aten.native_batch_norm.default(convolution_default_159, primals_962, primals_958, primals_960, primals_961, True, 0.1, 1e-05);  primals_958 = None
        getitem_603 = native_batch_norm_default_159[0]
        getitem_604 = native_batch_norm_default_159[1]
        getitem_605 = native_batch_norm_default_159[2];  native_batch_norm_default_159 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(convolution_default_159, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_190 = torch.ops.aten.add_.Tensor(getitem_600, getitem_603);  getitem_600 = getitem_603 = None
        relu__default_155 = torch.ops.aten.relu_.default(add__tensor_190);  add__tensor_190 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu__default_155, primals_988, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_191 = torch.ops.aten.add_.Tensor(primals_964, 1);  primals_964 = None
        native_batch_norm_default_160 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_967, primals_963, primals_965, primals_966, True, 0.1, 1e-05);  primals_963 = None
        getitem_606 = native_batch_norm_default_160[0]
        getitem_607 = native_batch_norm_default_160[1]
        getitem_608 = native_batch_norm_default_160[2];  native_batch_norm_default_160 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(convolution_default_160, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_156 = torch.ops.aten.relu_.default(getitem_606);  getitem_606 = None
        split_tensor_31 = torch.ops.aten.split.Tensor(relu__default_156, 208, 1)
        getitem_609 = split_tensor_31[0]
        getitem_610 = split_tensor_31[1]
        getitem_611 = split_tensor_31[2]
        getitem_612 = split_tensor_31[3];  split_tensor_31 = None
        convolution_default_161 = torch.ops.aten.convolution.default(getitem_609, primals_990, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_192 = torch.ops.aten.add_.Tensor(primals_974, 1);  primals_974 = None
        native_batch_norm_default_161 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_977, primals_973, primals_975, primals_976, True, 0.1, 1e-05);  primals_973 = None
        getitem_613 = native_batch_norm_default_161[0]
        getitem_614 = native_batch_norm_default_161[1]
        getitem_615 = native_batch_norm_default_161[2];  native_batch_norm_default_161 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(convolution_default_161, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_157 = torch.ops.aten.relu_.default(getitem_613);  getitem_613 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(relu__default_157, getitem_610);  getitem_610 = None
        convolution_default_162 = torch.ops.aten.convolution.default(add_tensor_54, primals_991, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_193 = torch.ops.aten.add_.Tensor(primals_979, 1);  primals_979 = None
        native_batch_norm_default_162 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_982, primals_978, primals_980, primals_981, True, 0.1, 1e-05);  primals_978 = None
        getitem_616 = native_batch_norm_default_162[0]
        getitem_617 = native_batch_norm_default_162[1]
        getitem_618 = native_batch_norm_default_162[2];  native_batch_norm_default_162 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(convolution_default_162, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_158 = torch.ops.aten.relu_.default(getitem_616);  getitem_616 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(relu__default_158, getitem_611);  getitem_611 = None
        convolution_default_163 = torch.ops.aten.convolution.default(add_tensor_55, primals_992, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_194 = torch.ops.aten.add_.Tensor(primals_984, 1);  primals_984 = None
        native_batch_norm_default_163 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_987, primals_983, primals_985, primals_986, True, 0.1, 1e-05);  primals_983 = None
        getitem_619 = native_batch_norm_default_163[0]
        getitem_620 = native_batch_norm_default_163[1]
        getitem_621 = native_batch_norm_default_163[2];  native_batch_norm_default_163 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(convolution_default_163, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_159 = torch.ops.aten.relu_.default(getitem_619);  getitem_619 = None
        cat_default_31 = torch.ops.aten.cat.default([relu__default_157, relu__default_158, relu__default_159, getitem_612], 1);  getitem_612 = None
        convolution_default_164 = torch.ops.aten.convolution.default(cat_default_31, primals_989, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_195 = torch.ops.aten.add_.Tensor(primals_969, 1);  primals_969 = None
        native_batch_norm_default_164 = torch.ops.aten.native_batch_norm.default(convolution_default_164, primals_972, primals_968, primals_970, primals_971, True, 0.1, 1e-05);  primals_968 = None
        getitem_622 = native_batch_norm_default_164[0]
        getitem_623 = native_batch_norm_default_164[1]
        getitem_624 = native_batch_norm_default_164[2];  native_batch_norm_default_164 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(convolution_default_164, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_196 = torch.ops.aten.add_.Tensor(getitem_622, relu__default_155);  getitem_622 = None
        relu__default_160 = torch.ops.aten.relu_.default(add__tensor_196);  add__tensor_196 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_160, primals_1018, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_197 = torch.ops.aten.add_.Tensor(primals_994, 1);  primals_994 = None
        native_batch_norm_default_165 = torch.ops.aten.native_batch_norm.default(convolution_default_165, primals_997, primals_993, primals_995, primals_996, True, 0.1, 1e-05);  primals_993 = None
        getitem_625 = native_batch_norm_default_165[0]
        getitem_626 = native_batch_norm_default_165[1]
        getitem_627 = native_batch_norm_default_165[2];  native_batch_norm_default_165 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(convolution_default_165, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_161 = torch.ops.aten.relu_.default(getitem_625);  getitem_625 = None
        split_tensor_32 = torch.ops.aten.split.Tensor(relu__default_161, 208, 1)
        getitem_628 = split_tensor_32[0]
        getitem_629 = split_tensor_32[1]
        getitem_630 = split_tensor_32[2]
        getitem_631 = split_tensor_32[3];  split_tensor_32 = None
        convolution_default_166 = torch.ops.aten.convolution.default(getitem_628, primals_1020, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_198 = torch.ops.aten.add_.Tensor(primals_1004, 1);  primals_1004 = None
        native_batch_norm_default_166 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_1007, primals_1003, primals_1005, primals_1006, True, 0.1, 1e-05);  primals_1003 = None
        getitem_632 = native_batch_norm_default_166[0]
        getitem_633 = native_batch_norm_default_166[1]
        getitem_634 = native_batch_norm_default_166[2];  native_batch_norm_default_166 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(convolution_default_166, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_162 = torch.ops.aten.relu_.default(getitem_632);  getitem_632 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(relu__default_162, getitem_629);  getitem_629 = None
        convolution_default_167 = torch.ops.aten.convolution.default(add_tensor_56, primals_1021, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_199 = torch.ops.aten.add_.Tensor(primals_1009, 1);  primals_1009 = None
        native_batch_norm_default_167 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_1012, primals_1008, primals_1010, primals_1011, True, 0.1, 1e-05);  primals_1008 = None
        getitem_635 = native_batch_norm_default_167[0]
        getitem_636 = native_batch_norm_default_167[1]
        getitem_637 = native_batch_norm_default_167[2];  native_batch_norm_default_167 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(convolution_default_167, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_163 = torch.ops.aten.relu_.default(getitem_635);  getitem_635 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(relu__default_163, getitem_630);  getitem_630 = None
        convolution_default_168 = torch.ops.aten.convolution.default(add_tensor_57, primals_1022, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_200 = torch.ops.aten.add_.Tensor(primals_1014, 1);  primals_1014 = None
        native_batch_norm_default_168 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_1017, primals_1013, primals_1015, primals_1016, True, 0.1, 1e-05);  primals_1013 = None
        getitem_638 = native_batch_norm_default_168[0]
        getitem_639 = native_batch_norm_default_168[1]
        getitem_640 = native_batch_norm_default_168[2];  native_batch_norm_default_168 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(convolution_default_168, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_164 = torch.ops.aten.relu_.default(getitem_638);  getitem_638 = None
        cat_default_32 = torch.ops.aten.cat.default([relu__default_162, relu__default_163, relu__default_164, getitem_631], 1);  getitem_631 = None
        convolution_default_169 = torch.ops.aten.convolution.default(cat_default_32, primals_1019, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_201 = torch.ops.aten.add_.Tensor(primals_999, 1);  primals_999 = None
        native_batch_norm_default_169 = torch.ops.aten.native_batch_norm.default(convolution_default_169, primals_1002, primals_998, primals_1000, primals_1001, True, 0.1, 1e-05);  primals_998 = None
        getitem_641 = native_batch_norm_default_169[0]
        getitem_642 = native_batch_norm_default_169[1]
        getitem_643 = native_batch_norm_default_169[2];  native_batch_norm_default_169 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(convolution_default_169, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_202 = torch.ops.aten.add_.Tensor(getitem_641, relu__default_160);  getitem_641 = None
        relu__default_165 = torch.ops.aten.relu_.default(add__tensor_202);  add__tensor_202 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_165, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 2048, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_165, torch.float32);  relu__default_165 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_170, to_dtype);  le_scalar = new_zeros_default_170 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_169, primals_1002, primals_1000, primals_1001, getitem_642, getitem_643, True, 1e-05, [True, True, True]);  convolution_default_169 = primals_1002 = primals_1000 = primals_1001 = getitem_642 = getitem_643 = None
        getitem_644 = native_batch_norm_backward_default[0]
        getitem_645 = native_batch_norm_backward_default[1]
        getitem_646 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_644, cat_default_32, primals_1019, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_644 = cat_default_32 = primals_1019 = None
        getitem_647 = convolution_backward_default[0]
        getitem_648 = convolution_backward_default[1]
        getitem_649 = convolution_backward_default[2];  convolution_backward_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_647, 1, 0, 208)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_647, 1, 208, 416)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_647, 1, 416, 624)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_647, 1, 624, 832);  getitem_647 = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor_2, torch.float32);  slice_tensor_2 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_164, torch.float32);  relu__default_164 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_171, to_dtype_3);  le_scalar_1 = new_zeros_default_171 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_168, primals_1017, primals_1015, primals_1016, getitem_639, getitem_640, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_168 = primals_1017 = primals_1015 = primals_1016 = getitem_639 = getitem_640 = None
        getitem_650 = native_batch_norm_backward_default_1[0]
        getitem_651 = native_batch_norm_backward_default_1[1]
        getitem_652 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_650, add_tensor_57, primals_1022, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_650 = add_tensor_57 = primals_1022 = None
        getitem_653 = convolution_backward_default_1[0]
        getitem_654 = convolution_backward_default_1[1]
        getitem_655 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(slice_tensor_1, getitem_653);  slice_tensor_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(add_tensor_58, torch.float32);  add_tensor_58 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_163, torch.float32);  relu__default_163 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_172, to_dtype_6);  le_scalar_2 = new_zeros_default_172 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_167, primals_1012, primals_1010, primals_1011, getitem_636, getitem_637, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_167 = primals_1012 = primals_1010 = primals_1011 = getitem_636 = getitem_637 = None
        getitem_656 = native_batch_norm_backward_default_2[0]
        getitem_657 = native_batch_norm_backward_default_2[1]
        getitem_658 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_656, add_tensor_56, primals_1021, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_656 = add_tensor_56 = primals_1021 = None
        getitem_659 = convolution_backward_default_2[0]
        getitem_660 = convolution_backward_default_2[1]
        getitem_661 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(slice_tensor, getitem_659);  slice_tensor = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_59, torch.float32);  add_tensor_59 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_162, torch.float32);  relu__default_162 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_173, to_dtype_9);  le_scalar_3 = new_zeros_default_173 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_166, primals_1007, primals_1005, primals_1006, getitem_633, getitem_634, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_166 = primals_1007 = primals_1005 = primals_1006 = getitem_633 = getitem_634 = None
        getitem_662 = native_batch_norm_backward_default_3[0]
        getitem_663 = native_batch_norm_backward_default_3[1]
        getitem_664 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_662, getitem_628, primals_1020, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_662 = getitem_628 = primals_1020 = None
        getitem_665 = convolution_backward_default_3[0]
        getitem_666 = convolution_backward_default_3[1]
        getitem_667 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        cat_default_33 = torch.ops.aten.cat.default([getitem_665, getitem_659, getitem_653, slice_tensor_3], 1);  getitem_665 = getitem_659 = getitem_653 = slice_tensor_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(cat_default_33, torch.float32);  cat_default_33 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_161, torch.float32);  relu__default_161 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_174, to_dtype_12);  le_scalar_4 = new_zeros_default_174 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_165, primals_997, primals_995, primals_996, getitem_626, getitem_627, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_165 = primals_997 = primals_995 = primals_996 = getitem_626 = getitem_627 = None
        getitem_668 = native_batch_norm_backward_default_4[0]
        getitem_669 = native_batch_norm_backward_default_4[1]
        getitem_670 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_668, relu__default_160, primals_1018, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_668 = primals_1018 = None
        getitem_671 = convolution_backward_default_4[0]
        getitem_672 = convolution_backward_default_4[1]
        getitem_673 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_671);  to_dtype_2 = getitem_671 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_60, torch.float32);  add_tensor_60 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_160, torch.float32);  relu__default_160 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_175, to_dtype_15);  le_scalar_5 = new_zeros_default_175 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_164, primals_972, primals_970, primals_971, getitem_623, getitem_624, True, 1e-05, [True, True, True]);  convolution_default_164 = primals_972 = primals_970 = primals_971 = getitem_623 = getitem_624 = None
        getitem_674 = native_batch_norm_backward_default_5[0]
        getitem_675 = native_batch_norm_backward_default_5[1]
        getitem_676 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_674, cat_default_31, primals_989, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_674 = cat_default_31 = primals_989 = None
        getitem_677 = convolution_backward_default_5[0]
        getitem_678 = convolution_backward_default_5[1]
        getitem_679 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_677, 1, 0, 208)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_677, 1, 208, 416)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_677, 1, 416, 624)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_677, 1, 624, 832);  getitem_677 = None
        to_dtype_18 = torch.ops.aten.to.dtype(slice_tensor_6, torch.float32);  slice_tensor_6 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_159, torch.float32);  relu__default_159 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_176, to_dtype_18);  le_scalar_6 = new_zeros_default_176 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_163, primals_987, primals_985, primals_986, getitem_620, getitem_621, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_163 = primals_987 = primals_985 = primals_986 = getitem_620 = getitem_621 = None
        getitem_680 = native_batch_norm_backward_default_6[0]
        getitem_681 = native_batch_norm_backward_default_6[1]
        getitem_682 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_680, add_tensor_55, primals_992, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_680 = add_tensor_55 = primals_992 = None
        getitem_683 = convolution_backward_default_6[0]
        getitem_684 = convolution_backward_default_6[1]
        getitem_685 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(slice_tensor_5, getitem_683);  slice_tensor_5 = None
        to_dtype_21 = torch.ops.aten.to.dtype(add_tensor_61, torch.float32);  add_tensor_61 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_158, torch.float32);  relu__default_158 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_177, to_dtype_21);  le_scalar_7 = new_zeros_default_177 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_162, primals_982, primals_980, primals_981, getitem_617, getitem_618, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_162 = primals_982 = primals_980 = primals_981 = getitem_617 = getitem_618 = None
        getitem_686 = native_batch_norm_backward_default_7[0]
        getitem_687 = native_batch_norm_backward_default_7[1]
        getitem_688 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_686, add_tensor_54, primals_991, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_686 = add_tensor_54 = primals_991 = None
        getitem_689 = convolution_backward_default_7[0]
        getitem_690 = convolution_backward_default_7[1]
        getitem_691 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(slice_tensor_4, getitem_689);  slice_tensor_4 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_157, torch.float32);  relu__default_157 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_178, to_dtype_24);  le_scalar_8 = new_zeros_default_178 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_161, primals_977, primals_975, primals_976, getitem_614, getitem_615, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_161 = primals_977 = primals_975 = primals_976 = getitem_614 = getitem_615 = None
        getitem_692 = native_batch_norm_backward_default_8[0]
        getitem_693 = native_batch_norm_backward_default_8[1]
        getitem_694 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_692, getitem_609, primals_990, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_692 = getitem_609 = primals_990 = None
        getitem_695 = convolution_backward_default_8[0]
        getitem_696 = convolution_backward_default_8[1]
        getitem_697 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        cat_default_34 = torch.ops.aten.cat.default([getitem_695, getitem_689, getitem_683, slice_tensor_7], 1);  getitem_695 = getitem_689 = getitem_683 = slice_tensor_7 = None
        to_dtype_27 = torch.ops.aten.to.dtype(cat_default_34, torch.float32);  cat_default_34 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_156, torch.float32);  relu__default_156 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_179, to_dtype_27);  le_scalar_9 = new_zeros_default_179 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_160, primals_967, primals_965, primals_966, getitem_607, getitem_608, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_160 = primals_967 = primals_965 = primals_966 = getitem_607 = getitem_608 = None
        getitem_698 = native_batch_norm_backward_default_9[0]
        getitem_699 = native_batch_norm_backward_default_9[1]
        getitem_700 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_698, relu__default_155, primals_988, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_698 = primals_988 = None
        getitem_701 = convolution_backward_default_9[0]
        getitem_702 = convolution_backward_default_9[1]
        getitem_703 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(to_dtype_17, getitem_701);  to_dtype_17 = getitem_701 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_63, torch.float32);  add_tensor_63 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_155, torch.float32);  relu__default_155 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_180, to_dtype_30);  le_scalar_10 = new_zeros_default_180 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_159, primals_962, primals_960, primals_961, getitem_604, getitem_605, True, 1e-05, [True, True, True]);  convolution_default_159 = primals_962 = primals_960 = primals_961 = getitem_604 = getitem_605 = None
        getitem_704 = native_batch_norm_backward_default_10[0]
        getitem_705 = native_batch_norm_backward_default_10[1]
        getitem_706 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_704, relu__default_150, primals_957, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_704 = primals_957 = None
        getitem_707 = convolution_backward_default_10[0]
        getitem_708 = convolution_backward_default_10[1]
        getitem_709 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_158, primals_936, primals_934, primals_935, getitem_601, getitem_602, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_158 = primals_936 = primals_934 = primals_935 = getitem_601 = getitem_602 = None
        getitem_710 = native_batch_norm_backward_default_11[0]
        getitem_711 = native_batch_norm_backward_default_11[1]
        getitem_712 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_710, cat_default_30, primals_953, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_710 = cat_default_30 = primals_953 = None
        getitem_713 = convolution_backward_default_11[0]
        getitem_714 = convolution_backward_default_11[1]
        getitem_715 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(getitem_713, 1, 0, 208)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(getitem_713, 1, 208, 416)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_713, 1, 416, 624)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_713, 1, 624, 832);  getitem_713 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_11, getitem_590, [3, 3], [2, 2], [1, 1], False, True, None);  slice_tensor_11 = getitem_590 = None
        to_dtype_33 = torch.ops.aten.to.dtype(slice_tensor_10, torch.float32);  slice_tensor_10 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_154, torch.float32);  relu__default_154 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_181, to_dtype_33);  le_scalar_11 = new_zeros_default_181 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_157, primals_951, primals_949, primals_950, getitem_598, getitem_599, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_157 = primals_951 = primals_949 = primals_950 = getitem_598 = getitem_599 = None
        getitem_716 = native_batch_norm_backward_default_12[0]
        getitem_717 = native_batch_norm_backward_default_12[1]
        getitem_718 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_716, getitem_589, primals_956, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_716 = getitem_589 = primals_956 = None
        getitem_719 = convolution_backward_default_12[0]
        getitem_720 = convolution_backward_default_12[1]
        getitem_721 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_36 = torch.ops.aten.to.dtype(slice_tensor_9, torch.float32);  slice_tensor_9 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_153, torch.float32);  relu__default_153 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_182, to_dtype_36);  le_scalar_12 = new_zeros_default_182 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_156, primals_946, primals_944, primals_945, getitem_595, getitem_596, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_156 = primals_946 = primals_944 = primals_945 = getitem_595 = getitem_596 = None
        getitem_722 = native_batch_norm_backward_default_13[0]
        getitem_723 = native_batch_norm_backward_default_13[1]
        getitem_724 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_722, getitem_588, primals_955, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_722 = getitem_588 = primals_955 = None
        getitem_725 = convolution_backward_default_13[0]
        getitem_726 = convolution_backward_default_13[1]
        getitem_727 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(slice_tensor_8, torch.float32);  slice_tensor_8 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_152, torch.float32);  relu__default_152 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_183, to_dtype_39);  le_scalar_13 = new_zeros_default_183 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_155, primals_941, primals_939, primals_940, getitem_592, getitem_593, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_155 = primals_941 = primals_939 = primals_940 = getitem_592 = getitem_593 = None
        getitem_728 = native_batch_norm_backward_default_14[0]
        getitem_729 = native_batch_norm_backward_default_14[1]
        getitem_730 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_728, getitem_587, primals_954, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_728 = getitem_587 = primals_954 = None
        getitem_731 = convolution_backward_default_14[0]
        getitem_732 = convolution_backward_default_14[1]
        getitem_733 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        cat_default_35 = torch.ops.aten.cat.default([getitem_731, getitem_725, getitem_719, avg_pool2d_backward_default], 1);  getitem_731 = getitem_725 = getitem_719 = avg_pool2d_backward_default = None
        to_dtype_42 = torch.ops.aten.to.dtype(cat_default_35, torch.float32);  cat_default_35 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_151, torch.float32);  relu__default_151 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_184, to_dtype_42);  le_scalar_14 = new_zeros_default_184 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_154, primals_931, primals_929, primals_930, getitem_585, getitem_586, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_154 = primals_931 = primals_929 = primals_930 = getitem_585 = getitem_586 = None
        getitem_734 = native_batch_norm_backward_default_15[0]
        getitem_735 = native_batch_norm_backward_default_15[1]
        getitem_736 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_734, relu__default_150, primals_952, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_734 = primals_952 = None
        getitem_737 = convolution_backward_default_15[0]
        getitem_738 = convolution_backward_default_15[1]
        getitem_739 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(getitem_707, getitem_737);  getitem_707 = getitem_737 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_64, torch.float32);  add_tensor_64 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_150, torch.float32);  relu__default_150 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_185, to_dtype_45);  le_scalar_15 = new_zeros_default_185 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_153, primals_666, primals_664, primals_665, getitem_582, getitem_583, True, 1e-05, [True, True, True]);  convolution_default_153 = primals_666 = primals_664 = primals_665 = getitem_582 = getitem_583 = None
        getitem_740 = native_batch_norm_backward_default_16[0]
        getitem_741 = native_batch_norm_backward_default_16[1]
        getitem_742 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_740, cat_default_29, primals_683, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_740 = cat_default_29 = primals_683 = None
        getitem_743 = convolution_backward_default_16[0]
        getitem_744 = convolution_backward_default_16[1]
        getitem_745 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(getitem_743, 1, 0, 104)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(getitem_743, 1, 104, 208)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(getitem_743, 1, 208, 312)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_743, 1, 312, 416);  getitem_743 = None
        to_dtype_48 = torch.ops.aten.to.dtype(slice_tensor_14, torch.float32);  slice_tensor_14 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_149, torch.float32);  relu__default_149 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_186, to_dtype_48);  le_scalar_16 = new_zeros_default_186 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_152, primals_681, primals_679, primals_680, getitem_579, getitem_580, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_152 = primals_681 = primals_679 = primals_680 = getitem_579 = getitem_580 = None
        getitem_746 = native_batch_norm_backward_default_17[0]
        getitem_747 = native_batch_norm_backward_default_17[1]
        getitem_748 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_746, add_tensor_53, primals_686, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_746 = add_tensor_53 = primals_686 = None
        getitem_749 = convolution_backward_default_17[0]
        getitem_750 = convolution_backward_default_17[1]
        getitem_751 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(slice_tensor_13, getitem_749);  slice_tensor_13 = None
        to_dtype_51 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_148, torch.float32);  relu__default_148 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_187, to_dtype_51);  le_scalar_17 = new_zeros_default_187 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_151, primals_676, primals_674, primals_675, getitem_576, getitem_577, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_151 = primals_676 = primals_674 = primals_675 = getitem_576 = getitem_577 = None
        getitem_752 = native_batch_norm_backward_default_18[0]
        getitem_753 = native_batch_norm_backward_default_18[1]
        getitem_754 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_752, add_tensor_52, primals_685, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_752 = add_tensor_52 = primals_685 = None
        getitem_755 = convolution_backward_default_18[0]
        getitem_756 = convolution_backward_default_18[1]
        getitem_757 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(slice_tensor_12, getitem_755);  slice_tensor_12 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_147, torch.float32);  relu__default_147 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_188, to_dtype_54);  le_scalar_18 = new_zeros_default_188 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_150, primals_671, primals_669, primals_670, getitem_573, getitem_574, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_150 = primals_671 = primals_669 = primals_670 = getitem_573 = getitem_574 = None
        getitem_758 = native_batch_norm_backward_default_19[0]
        getitem_759 = native_batch_norm_backward_default_19[1]
        getitem_760 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_758, getitem_568, primals_684, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_758 = getitem_568 = primals_684 = None
        getitem_761 = convolution_backward_default_19[0]
        getitem_762 = convolution_backward_default_19[1]
        getitem_763 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        cat_default_36 = torch.ops.aten.cat.default([getitem_761, getitem_755, getitem_749, slice_tensor_15], 1);  getitem_761 = getitem_755 = getitem_749 = slice_tensor_15 = None
        to_dtype_57 = torch.ops.aten.to.dtype(cat_default_36, torch.float32);  cat_default_36 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_146, torch.float32);  relu__default_146 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_189, to_dtype_57);  le_scalar_19 = new_zeros_default_189 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_149, primals_661, primals_659, primals_660, getitem_566, getitem_567, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_149 = primals_661 = primals_659 = primals_660 = getitem_566 = getitem_567 = None
        getitem_764 = native_batch_norm_backward_default_20[0]
        getitem_765 = native_batch_norm_backward_default_20[1]
        getitem_766 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_764, relu__default_145, primals_682, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_764 = primals_682 = None
        getitem_767 = convolution_backward_default_20[0]
        getitem_768 = convolution_backward_default_20[1]
        getitem_769 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(to_dtype_47, getitem_767);  to_dtype_47 = getitem_767 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_67, torch.float32);  add_tensor_67 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_145, torch.float32);  relu__default_145 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_190, to_dtype_60);  le_scalar_20 = new_zeros_default_190 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_148, primals_636, primals_634, primals_635, getitem_563, getitem_564, True, 1e-05, [True, True, True]);  convolution_default_148 = primals_636 = primals_634 = primals_635 = getitem_563 = getitem_564 = None
        getitem_770 = native_batch_norm_backward_default_21[0]
        getitem_771 = native_batch_norm_backward_default_21[1]
        getitem_772 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_770, cat_default_28, primals_653, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_770 = cat_default_28 = primals_653 = None
        getitem_773 = convolution_backward_default_21[0]
        getitem_774 = convolution_backward_default_21[1]
        getitem_775 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(getitem_773, 1, 0, 104)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(getitem_773, 1, 104, 208)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(getitem_773, 1, 208, 312)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(getitem_773, 1, 312, 416);  getitem_773 = None
        to_dtype_63 = torch.ops.aten.to.dtype(slice_tensor_18, torch.float32);  slice_tensor_18 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_144, torch.float32);  relu__default_144 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_191, to_dtype_63);  le_scalar_21 = new_zeros_default_191 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_147, primals_651, primals_649, primals_650, getitem_560, getitem_561, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_147 = primals_651 = primals_649 = primals_650 = getitem_560 = getitem_561 = None
        getitem_776 = native_batch_norm_backward_default_22[0]
        getitem_777 = native_batch_norm_backward_default_22[1]
        getitem_778 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_776, add_tensor_51, primals_656, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_776 = add_tensor_51 = primals_656 = None
        getitem_779 = convolution_backward_default_22[0]
        getitem_780 = convolution_backward_default_22[1]
        getitem_781 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(slice_tensor_17, getitem_779);  slice_tensor_17 = None
        to_dtype_66 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_143, torch.float32);  relu__default_143 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_192, to_dtype_66);  le_scalar_22 = new_zeros_default_192 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_146, primals_646, primals_644, primals_645, getitem_557, getitem_558, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_146 = primals_646 = primals_644 = primals_645 = getitem_557 = getitem_558 = None
        getitem_782 = native_batch_norm_backward_default_23[0]
        getitem_783 = native_batch_norm_backward_default_23[1]
        getitem_784 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_782, add_tensor_50, primals_655, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_782 = add_tensor_50 = primals_655 = None
        getitem_785 = convolution_backward_default_23[0]
        getitem_786 = convolution_backward_default_23[1]
        getitem_787 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(slice_tensor_16, getitem_785);  slice_tensor_16 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_69, torch.float32);  add_tensor_69 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_142, torch.float32);  relu__default_142 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_193, to_dtype_69);  le_scalar_23 = new_zeros_default_193 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_145, primals_641, primals_639, primals_640, getitem_554, getitem_555, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_145 = primals_641 = primals_639 = primals_640 = getitem_554 = getitem_555 = None
        getitem_788 = native_batch_norm_backward_default_24[0]
        getitem_789 = native_batch_norm_backward_default_24[1]
        getitem_790 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_788, getitem_549, primals_654, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_788 = getitem_549 = primals_654 = None
        getitem_791 = convolution_backward_default_24[0]
        getitem_792 = convolution_backward_default_24[1]
        getitem_793 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        cat_default_37 = torch.ops.aten.cat.default([getitem_791, getitem_785, getitem_779, slice_tensor_19], 1);  getitem_791 = getitem_785 = getitem_779 = slice_tensor_19 = None
        to_dtype_72 = torch.ops.aten.to.dtype(cat_default_37, torch.float32);  cat_default_37 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_141, torch.float32);  relu__default_141 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_194, to_dtype_72);  le_scalar_24 = new_zeros_default_194 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_144, primals_631, primals_629, primals_630, getitem_547, getitem_548, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_144 = primals_631 = primals_629 = primals_630 = getitem_547 = getitem_548 = None
        getitem_794 = native_batch_norm_backward_default_25[0]
        getitem_795 = native_batch_norm_backward_default_25[1]
        getitem_796 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_794, relu__default_140, primals_652, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_794 = primals_652 = None
        getitem_797 = convolution_backward_default_25[0]
        getitem_798 = convolution_backward_default_25[1]
        getitem_799 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_797);  to_dtype_62 = getitem_797 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_70, torch.float32);  add_tensor_70 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_140, torch.float32);  relu__default_140 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_195, to_dtype_75);  le_scalar_25 = new_zeros_default_195 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_143, primals_606, primals_604, primals_605, getitem_544, getitem_545, True, 1e-05, [True, True, True]);  convolution_default_143 = primals_606 = primals_604 = primals_605 = getitem_544 = getitem_545 = None
        getitem_800 = native_batch_norm_backward_default_26[0]
        getitem_801 = native_batch_norm_backward_default_26[1]
        getitem_802 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_800, cat_default_27, primals_623, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_800 = cat_default_27 = primals_623 = None
        getitem_803 = convolution_backward_default_26[0]
        getitem_804 = convolution_backward_default_26[1]
        getitem_805 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(getitem_803, 1, 0, 104)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(getitem_803, 1, 104, 208)
        slice_tensor_22 = torch.ops.aten.slice.Tensor(getitem_803, 1, 208, 312)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(getitem_803, 1, 312, 416);  getitem_803 = None
        to_dtype_78 = torch.ops.aten.to.dtype(slice_tensor_22, torch.float32);  slice_tensor_22 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_139, torch.float32);  relu__default_139 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_196, to_dtype_78);  le_scalar_26 = new_zeros_default_196 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_142, primals_621, primals_619, primals_620, getitem_541, getitem_542, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_142 = primals_621 = primals_619 = primals_620 = getitem_541 = getitem_542 = None
        getitem_806 = native_batch_norm_backward_default_27[0]
        getitem_807 = native_batch_norm_backward_default_27[1]
        getitem_808 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_806, add_tensor_49, primals_626, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_806 = add_tensor_49 = primals_626 = None
        getitem_809 = convolution_backward_default_27[0]
        getitem_810 = convolution_backward_default_27[1]
        getitem_811 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(slice_tensor_21, getitem_809);  slice_tensor_21 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_71, torch.float32);  add_tensor_71 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_138, torch.float32);  relu__default_138 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_197, to_dtype_81);  le_scalar_27 = new_zeros_default_197 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_141, primals_616, primals_614, primals_615, getitem_538, getitem_539, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_141 = primals_616 = primals_614 = primals_615 = getitem_538 = getitem_539 = None
        getitem_812 = native_batch_norm_backward_default_28[0]
        getitem_813 = native_batch_norm_backward_default_28[1]
        getitem_814 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_812, add_tensor_48, primals_625, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_812 = add_tensor_48 = primals_625 = None
        getitem_815 = convolution_backward_default_28[0]
        getitem_816 = convolution_backward_default_28[1]
        getitem_817 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(slice_tensor_20, getitem_815);  slice_tensor_20 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_72, torch.float32);  add_tensor_72 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_137, torch.float32);  relu__default_137 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_198, to_dtype_84);  le_scalar_28 = new_zeros_default_198 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_140, primals_611, primals_609, primals_610, getitem_535, getitem_536, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_140 = primals_611 = primals_609 = primals_610 = getitem_535 = getitem_536 = None
        getitem_818 = native_batch_norm_backward_default_29[0]
        getitem_819 = native_batch_norm_backward_default_29[1]
        getitem_820 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_818, getitem_530, primals_624, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_818 = getitem_530 = primals_624 = None
        getitem_821 = convolution_backward_default_29[0]
        getitem_822 = convolution_backward_default_29[1]
        getitem_823 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        cat_default_38 = torch.ops.aten.cat.default([getitem_821, getitem_815, getitem_809, slice_tensor_23], 1);  getitem_821 = getitem_815 = getitem_809 = slice_tensor_23 = None
        to_dtype_87 = torch.ops.aten.to.dtype(cat_default_38, torch.float32);  cat_default_38 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_136, torch.float32);  relu__default_136 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_199, to_dtype_87);  le_scalar_29 = new_zeros_default_199 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_139, primals_601, primals_599, primals_600, getitem_528, getitem_529, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_139 = primals_601 = primals_599 = primals_600 = getitem_528 = getitem_529 = None
        getitem_824 = native_batch_norm_backward_default_30[0]
        getitem_825 = native_batch_norm_backward_default_30[1]
        getitem_826 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_824, relu__default_135, primals_622, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_824 = primals_622 = None
        getitem_827 = convolution_backward_default_30[0]
        getitem_828 = convolution_backward_default_30[1]
        getitem_829 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(to_dtype_77, getitem_827);  to_dtype_77 = getitem_827 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_73, torch.float32);  add_tensor_73 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_135, torch.float32);  relu__default_135 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_200, to_dtype_90);  le_scalar_30 = new_zeros_default_200 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_138, primals_546, primals_544, primals_545, getitem_525, getitem_526, True, 1e-05, [True, True, True]);  convolution_default_138 = primals_546 = primals_544 = primals_545 = getitem_525 = getitem_526 = None
        getitem_830 = native_batch_norm_backward_default_31[0]
        getitem_831 = native_batch_norm_backward_default_31[1]
        getitem_832 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_830, cat_default_26, primals_563, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_830 = cat_default_26 = primals_563 = None
        getitem_833 = convolution_backward_default_31[0]
        getitem_834 = convolution_backward_default_31[1]
        getitem_835 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(getitem_833, 1, 0, 104)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(getitem_833, 1, 104, 208)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(getitem_833, 1, 208, 312)
        slice_tensor_27 = torch.ops.aten.slice.Tensor(getitem_833, 1, 312, 416);  getitem_833 = None
        to_dtype_93 = torch.ops.aten.to.dtype(slice_tensor_26, torch.float32);  slice_tensor_26 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_134, torch.float32);  relu__default_134 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_201, to_dtype_93);  le_scalar_31 = new_zeros_default_201 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_137, primals_561, primals_559, primals_560, getitem_522, getitem_523, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_137 = primals_561 = primals_559 = primals_560 = getitem_522 = getitem_523 = None
        getitem_836 = native_batch_norm_backward_default_32[0]
        getitem_837 = native_batch_norm_backward_default_32[1]
        getitem_838 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_836, add_tensor_47, primals_566, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_836 = add_tensor_47 = primals_566 = None
        getitem_839 = convolution_backward_default_32[0]
        getitem_840 = convolution_backward_default_32[1]
        getitem_841 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(slice_tensor_25, getitem_839);  slice_tensor_25 = None
        to_dtype_96 = torch.ops.aten.to.dtype(add_tensor_74, torch.float32);  add_tensor_74 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_133, torch.float32);  relu__default_133 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_202, to_dtype_96);  le_scalar_32 = new_zeros_default_202 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_136, primals_556, primals_554, primals_555, getitem_519, getitem_520, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_136 = primals_556 = primals_554 = primals_555 = getitem_519 = getitem_520 = None
        getitem_842 = native_batch_norm_backward_default_33[0]
        getitem_843 = native_batch_norm_backward_default_33[1]
        getitem_844 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_842, add_tensor_46, primals_565, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_842 = add_tensor_46 = primals_565 = None
        getitem_845 = convolution_backward_default_33[0]
        getitem_846 = convolution_backward_default_33[1]
        getitem_847 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(slice_tensor_24, getitem_845);  slice_tensor_24 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_75, torch.float32);  add_tensor_75 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_132, torch.float32);  relu__default_132 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_203, to_dtype_99);  le_scalar_33 = new_zeros_default_203 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_135, primals_551, primals_549, primals_550, getitem_516, getitem_517, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_135 = primals_551 = primals_549 = primals_550 = getitem_516 = getitem_517 = None
        getitem_848 = native_batch_norm_backward_default_34[0]
        getitem_849 = native_batch_norm_backward_default_34[1]
        getitem_850 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_848, getitem_511, primals_564, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_848 = getitem_511 = primals_564 = None
        getitem_851 = convolution_backward_default_34[0]
        getitem_852 = convolution_backward_default_34[1]
        getitem_853 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        cat_default_39 = torch.ops.aten.cat.default([getitem_851, getitem_845, getitem_839, slice_tensor_27], 1);  getitem_851 = getitem_845 = getitem_839 = slice_tensor_27 = None
        to_dtype_102 = torch.ops.aten.to.dtype(cat_default_39, torch.float32);  cat_default_39 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_131, torch.float32);  relu__default_131 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_204, to_dtype_102);  le_scalar_34 = new_zeros_default_204 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_134, primals_541, primals_539, primals_540, getitem_509, getitem_510, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_134 = primals_541 = primals_539 = primals_540 = getitem_509 = getitem_510 = None
        getitem_854 = native_batch_norm_backward_default_35[0]
        getitem_855 = native_batch_norm_backward_default_35[1]
        getitem_856 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_854, relu__default_130, primals_562, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_854 = primals_562 = None
        getitem_857 = convolution_backward_default_35[0]
        getitem_858 = convolution_backward_default_35[1]
        getitem_859 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(to_dtype_92, getitem_857);  to_dtype_92 = getitem_857 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_76, torch.float32);  add_tensor_76 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_130, torch.float32);  relu__default_130 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_205, to_dtype_105);  le_scalar_35 = new_zeros_default_205 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_133, primals_516, primals_514, primals_515, getitem_506, getitem_507, True, 1e-05, [True, True, True]);  convolution_default_133 = primals_516 = primals_514 = primals_515 = getitem_506 = getitem_507 = None
        getitem_860 = native_batch_norm_backward_default_36[0]
        getitem_861 = native_batch_norm_backward_default_36[1]
        getitem_862 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_860, cat_default_25, primals_533, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_860 = cat_default_25 = primals_533 = None
        getitem_863 = convolution_backward_default_36[0]
        getitem_864 = convolution_backward_default_36[1]
        getitem_865 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        slice_tensor_28 = torch.ops.aten.slice.Tensor(getitem_863, 1, 0, 104)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(getitem_863, 1, 104, 208)
        slice_tensor_30 = torch.ops.aten.slice.Tensor(getitem_863, 1, 208, 312)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(getitem_863, 1, 312, 416);  getitem_863 = None
        to_dtype_108 = torch.ops.aten.to.dtype(slice_tensor_30, torch.float32);  slice_tensor_30 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_129, torch.float32);  relu__default_129 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_206, to_dtype_108);  le_scalar_36 = new_zeros_default_206 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_132, primals_531, primals_529, primals_530, getitem_503, getitem_504, True, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_132 = primals_531 = primals_529 = primals_530 = getitem_503 = getitem_504 = None
        getitem_866 = native_batch_norm_backward_default_37[0]
        getitem_867 = native_batch_norm_backward_default_37[1]
        getitem_868 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_866, add_tensor_45, primals_536, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_866 = add_tensor_45 = primals_536 = None
        getitem_869 = convolution_backward_default_37[0]
        getitem_870 = convolution_backward_default_37[1]
        getitem_871 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(slice_tensor_29, getitem_869);  slice_tensor_29 = None
        to_dtype_111 = torch.ops.aten.to.dtype(add_tensor_77, torch.float32);  add_tensor_77 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_128, torch.float32);  relu__default_128 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_207, to_dtype_111);  le_scalar_37 = new_zeros_default_207 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_131, primals_526, primals_524, primals_525, getitem_500, getitem_501, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_131 = primals_526 = primals_524 = primals_525 = getitem_500 = getitem_501 = None
        getitem_872 = native_batch_norm_backward_default_38[0]
        getitem_873 = native_batch_norm_backward_default_38[1]
        getitem_874 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_872, add_tensor_44, primals_535, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_872 = add_tensor_44 = primals_535 = None
        getitem_875 = convolution_backward_default_38[0]
        getitem_876 = convolution_backward_default_38[1]
        getitem_877 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(slice_tensor_28, getitem_875);  slice_tensor_28 = None
        to_dtype_114 = torch.ops.aten.to.dtype(add_tensor_78, torch.float32);  add_tensor_78 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_127, torch.float32);  relu__default_127 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_208, to_dtype_114);  le_scalar_38 = new_zeros_default_208 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_130, primals_521, primals_519, primals_520, getitem_497, getitem_498, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_130 = primals_521 = primals_519 = primals_520 = getitem_497 = getitem_498 = None
        getitem_878 = native_batch_norm_backward_default_39[0]
        getitem_879 = native_batch_norm_backward_default_39[1]
        getitem_880 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_878, getitem_492, primals_534, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_878 = getitem_492 = primals_534 = None
        getitem_881 = convolution_backward_default_39[0]
        getitem_882 = convolution_backward_default_39[1]
        getitem_883 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        cat_default_40 = torch.ops.aten.cat.default([getitem_881, getitem_875, getitem_869, slice_tensor_31], 1);  getitem_881 = getitem_875 = getitem_869 = slice_tensor_31 = None
        to_dtype_117 = torch.ops.aten.to.dtype(cat_default_40, torch.float32);  cat_default_40 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_126, torch.float32);  relu__default_126 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_209, to_dtype_117);  le_scalar_39 = new_zeros_default_209 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_129, primals_511, primals_509, primals_510, getitem_490, getitem_491, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_129 = primals_511 = primals_509 = primals_510 = getitem_490 = getitem_491 = None
        getitem_884 = native_batch_norm_backward_default_40[0]
        getitem_885 = native_batch_norm_backward_default_40[1]
        getitem_886 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_884, relu__default_125, primals_532, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_884 = primals_532 = None
        getitem_887 = convolution_backward_default_40[0]
        getitem_888 = convolution_backward_default_40[1]
        getitem_889 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(to_dtype_107, getitem_887);  to_dtype_107 = getitem_887 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_79, torch.float32);  add_tensor_79 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_125, torch.float32);  relu__default_125 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_210, to_dtype_120);  le_scalar_40 = new_zeros_default_210 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_128, primals_486, primals_484, primals_485, getitem_487, getitem_488, True, 1e-05, [True, True, True]);  convolution_default_128 = primals_486 = primals_484 = primals_485 = getitem_487 = getitem_488 = None
        getitem_890 = native_batch_norm_backward_default_41[0]
        getitem_891 = native_batch_norm_backward_default_41[1]
        getitem_892 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_890, cat_default_24, primals_503, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_890 = cat_default_24 = primals_503 = None
        getitem_893 = convolution_backward_default_41[0]
        getitem_894 = convolution_backward_default_41[1]
        getitem_895 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        slice_tensor_32 = torch.ops.aten.slice.Tensor(getitem_893, 1, 0, 104)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(getitem_893, 1, 104, 208)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(getitem_893, 1, 208, 312)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(getitem_893, 1, 312, 416);  getitem_893 = None
        to_dtype_123 = torch.ops.aten.to.dtype(slice_tensor_34, torch.float32);  slice_tensor_34 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_124, torch.float32);  relu__default_124 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_211, to_dtype_123);  le_scalar_41 = new_zeros_default_211 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_127, primals_501, primals_499, primals_500, getitem_484, getitem_485, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_127 = primals_501 = primals_499 = primals_500 = getitem_484 = getitem_485 = None
        getitem_896 = native_batch_norm_backward_default_42[0]
        getitem_897 = native_batch_norm_backward_default_42[1]
        getitem_898 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_896, add_tensor_43, primals_506, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_896 = add_tensor_43 = primals_506 = None
        getitem_899 = convolution_backward_default_42[0]
        getitem_900 = convolution_backward_default_42[1]
        getitem_901 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(slice_tensor_33, getitem_899);  slice_tensor_33 = None
        to_dtype_126 = torch.ops.aten.to.dtype(add_tensor_80, torch.float32);  add_tensor_80 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_123, torch.float32);  relu__default_123 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_212, to_dtype_126);  le_scalar_42 = new_zeros_default_212 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_126, primals_496, primals_494, primals_495, getitem_481, getitem_482, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default_126 = primals_496 = primals_494 = primals_495 = getitem_481 = getitem_482 = None
        getitem_902 = native_batch_norm_backward_default_43[0]
        getitem_903 = native_batch_norm_backward_default_43[1]
        getitem_904 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_902, add_tensor_42, primals_505, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_902 = add_tensor_42 = primals_505 = None
        getitem_905 = convolution_backward_default_43[0]
        getitem_906 = convolution_backward_default_43[1]
        getitem_907 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(slice_tensor_32, getitem_905);  slice_tensor_32 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_81, torch.float32);  add_tensor_81 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_122, torch.float32);  relu__default_122 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_213, to_dtype_129);  le_scalar_43 = new_zeros_default_213 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_125, primals_491, primals_489, primals_490, getitem_478, getitem_479, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_125 = primals_491 = primals_489 = primals_490 = getitem_478 = getitem_479 = None
        getitem_908 = native_batch_norm_backward_default_44[0]
        getitem_909 = native_batch_norm_backward_default_44[1]
        getitem_910 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_908, getitem_473, primals_504, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_908 = getitem_473 = primals_504 = None
        getitem_911 = convolution_backward_default_44[0]
        getitem_912 = convolution_backward_default_44[1]
        getitem_913 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        cat_default_41 = torch.ops.aten.cat.default([getitem_911, getitem_905, getitem_899, slice_tensor_35], 1);  getitem_911 = getitem_905 = getitem_899 = slice_tensor_35 = None
        to_dtype_132 = torch.ops.aten.to.dtype(cat_default_41, torch.float32);  cat_default_41 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_121, torch.float32);  relu__default_121 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_214, to_dtype_132);  le_scalar_44 = new_zeros_default_214 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_124, primals_481, primals_479, primals_480, getitem_471, getitem_472, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_124 = primals_481 = primals_479 = primals_480 = getitem_471 = getitem_472 = None
        getitem_914 = native_batch_norm_backward_default_45[0]
        getitem_915 = native_batch_norm_backward_default_45[1]
        getitem_916 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_914, relu__default_120, primals_502, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_914 = primals_502 = None
        getitem_917 = convolution_backward_default_45[0]
        getitem_918 = convolution_backward_default_45[1]
        getitem_919 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(to_dtype_122, getitem_917);  to_dtype_122 = getitem_917 = None
        to_dtype_135 = torch.ops.aten.to.dtype(add_tensor_82, torch.float32);  add_tensor_82 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_120, torch.float32);  relu__default_120 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_215, to_dtype_135);  le_scalar_45 = new_zeros_default_215 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_123, primals_456, primals_454, primals_455, getitem_468, getitem_469, True, 1e-05, [True, True, True]);  convolution_default_123 = primals_456 = primals_454 = primals_455 = getitem_468 = getitem_469 = None
        getitem_920 = native_batch_norm_backward_default_46[0]
        getitem_921 = native_batch_norm_backward_default_46[1]
        getitem_922 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_920, cat_default_23, primals_473, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_920 = cat_default_23 = primals_473 = None
        getitem_923 = convolution_backward_default_46[0]
        getitem_924 = convolution_backward_default_46[1]
        getitem_925 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        slice_tensor_36 = torch.ops.aten.slice.Tensor(getitem_923, 1, 0, 104)
        slice_tensor_37 = torch.ops.aten.slice.Tensor(getitem_923, 1, 104, 208)
        slice_tensor_38 = torch.ops.aten.slice.Tensor(getitem_923, 1, 208, 312)
        slice_tensor_39 = torch.ops.aten.slice.Tensor(getitem_923, 1, 312, 416);  getitem_923 = None
        to_dtype_138 = torch.ops.aten.to.dtype(slice_tensor_38, torch.float32);  slice_tensor_38 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_119, torch.float32);  relu__default_119 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_216, to_dtype_138);  le_scalar_46 = new_zeros_default_216 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_122, primals_471, primals_469, primals_470, getitem_465, getitem_466, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_122 = primals_471 = primals_469 = primals_470 = getitem_465 = getitem_466 = None
        getitem_926 = native_batch_norm_backward_default_47[0]
        getitem_927 = native_batch_norm_backward_default_47[1]
        getitem_928 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_926, add_tensor_41, primals_476, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_926 = add_tensor_41 = primals_476 = None
        getitem_929 = convolution_backward_default_47[0]
        getitem_930 = convolution_backward_default_47[1]
        getitem_931 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(slice_tensor_37, getitem_929);  slice_tensor_37 = None
        to_dtype_141 = torch.ops.aten.to.dtype(add_tensor_83, torch.float32);  add_tensor_83 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_118, torch.float32);  relu__default_118 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_217, to_dtype_141);  le_scalar_47 = new_zeros_default_217 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_121, primals_466, primals_464, primals_465, getitem_462, getitem_463, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_121 = primals_466 = primals_464 = primals_465 = getitem_462 = getitem_463 = None
        getitem_932 = native_batch_norm_backward_default_48[0]
        getitem_933 = native_batch_norm_backward_default_48[1]
        getitem_934 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_932, add_tensor_40, primals_475, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_932 = add_tensor_40 = primals_475 = None
        getitem_935 = convolution_backward_default_48[0]
        getitem_936 = convolution_backward_default_48[1]
        getitem_937 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(slice_tensor_36, getitem_935);  slice_tensor_36 = None
        to_dtype_144 = torch.ops.aten.to.dtype(add_tensor_84, torch.float32);  add_tensor_84 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_117, torch.float32);  relu__default_117 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_218, to_dtype_144);  le_scalar_48 = new_zeros_default_218 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_120, primals_461, primals_459, primals_460, getitem_459, getitem_460, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_120 = primals_461 = primals_459 = primals_460 = getitem_459 = getitem_460 = None
        getitem_938 = native_batch_norm_backward_default_49[0]
        getitem_939 = native_batch_norm_backward_default_49[1]
        getitem_940 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_938, getitem_454, primals_474, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_938 = getitem_454 = primals_474 = None
        getitem_941 = convolution_backward_default_49[0]
        getitem_942 = convolution_backward_default_49[1]
        getitem_943 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        cat_default_42 = torch.ops.aten.cat.default([getitem_941, getitem_935, getitem_929, slice_tensor_39], 1);  getitem_941 = getitem_935 = getitem_929 = slice_tensor_39 = None
        to_dtype_147 = torch.ops.aten.to.dtype(cat_default_42, torch.float32);  cat_default_42 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_116, torch.float32);  relu__default_116 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_219, to_dtype_147);  le_scalar_49 = new_zeros_default_219 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_119, primals_451, primals_449, primals_450, getitem_452, getitem_453, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_119 = primals_451 = primals_449 = primals_450 = getitem_452 = getitem_453 = None
        getitem_944 = native_batch_norm_backward_default_50[0]
        getitem_945 = native_batch_norm_backward_default_50[1]
        getitem_946 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_944, relu__default_115, primals_472, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_944 = primals_472 = None
        getitem_947 = convolution_backward_default_50[0]
        getitem_948 = convolution_backward_default_50[1]
        getitem_949 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(to_dtype_137, getitem_947);  to_dtype_137 = getitem_947 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_85, torch.float32);  add_tensor_85 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_115, torch.float32);  relu__default_115 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_220, to_dtype_150);  le_scalar_50 = new_zeros_default_220 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_118, primals_426, primals_424, primals_425, getitem_449, getitem_450, True, 1e-05, [True, True, True]);  convolution_default_118 = primals_426 = primals_424 = primals_425 = getitem_449 = getitem_450 = None
        getitem_950 = native_batch_norm_backward_default_51[0]
        getitem_951 = native_batch_norm_backward_default_51[1]
        getitem_952 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_950, cat_default_22, primals_443, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_950 = cat_default_22 = primals_443 = None
        getitem_953 = convolution_backward_default_51[0]
        getitem_954 = convolution_backward_default_51[1]
        getitem_955 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        slice_tensor_40 = torch.ops.aten.slice.Tensor(getitem_953, 1, 0, 104)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(getitem_953, 1, 104, 208)
        slice_tensor_42 = torch.ops.aten.slice.Tensor(getitem_953, 1, 208, 312)
        slice_tensor_43 = torch.ops.aten.slice.Tensor(getitem_953, 1, 312, 416);  getitem_953 = None
        to_dtype_153 = torch.ops.aten.to.dtype(slice_tensor_42, torch.float32);  slice_tensor_42 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_114, torch.float32);  relu__default_114 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_221, to_dtype_153);  le_scalar_51 = new_zeros_default_221 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_117, primals_441, primals_439, primals_440, getitem_446, getitem_447, True, 1e-05, [True, True, True]);  to_dtype_155 = convolution_default_117 = primals_441 = primals_439 = primals_440 = getitem_446 = getitem_447 = None
        getitem_956 = native_batch_norm_backward_default_52[0]
        getitem_957 = native_batch_norm_backward_default_52[1]
        getitem_958 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_956, add_tensor_39, primals_446, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_956 = add_tensor_39 = primals_446 = None
        getitem_959 = convolution_backward_default_52[0]
        getitem_960 = convolution_backward_default_52[1]
        getitem_961 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(slice_tensor_41, getitem_959);  slice_tensor_41 = None
        to_dtype_156 = torch.ops.aten.to.dtype(add_tensor_86, torch.float32);  add_tensor_86 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_113, torch.float32);  relu__default_113 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_222, to_dtype_156);  le_scalar_52 = new_zeros_default_222 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_116, primals_436, primals_434, primals_435, getitem_443, getitem_444, True, 1e-05, [True, True, True]);  to_dtype_158 = convolution_default_116 = primals_436 = primals_434 = primals_435 = getitem_443 = getitem_444 = None
        getitem_962 = native_batch_norm_backward_default_53[0]
        getitem_963 = native_batch_norm_backward_default_53[1]
        getitem_964 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_962, add_tensor_38, primals_445, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_962 = add_tensor_38 = primals_445 = None
        getitem_965 = convolution_backward_default_53[0]
        getitem_966 = convolution_backward_default_53[1]
        getitem_967 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(slice_tensor_40, getitem_965);  slice_tensor_40 = None
        to_dtype_159 = torch.ops.aten.to.dtype(add_tensor_87, torch.float32);  add_tensor_87 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_112, torch.float32);  relu__default_112 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_223, to_dtype_159);  le_scalar_53 = new_zeros_default_223 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_115, primals_431, primals_429, primals_430, getitem_440, getitem_441, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_115 = primals_431 = primals_429 = primals_430 = getitem_440 = getitem_441 = None
        getitem_968 = native_batch_norm_backward_default_54[0]
        getitem_969 = native_batch_norm_backward_default_54[1]
        getitem_970 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_968, getitem_435, primals_444, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_968 = getitem_435 = primals_444 = None
        getitem_971 = convolution_backward_default_54[0]
        getitem_972 = convolution_backward_default_54[1]
        getitem_973 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        cat_default_43 = torch.ops.aten.cat.default([getitem_971, getitem_965, getitem_959, slice_tensor_43], 1);  getitem_971 = getitem_965 = getitem_959 = slice_tensor_43 = None
        to_dtype_162 = torch.ops.aten.to.dtype(cat_default_43, torch.float32);  cat_default_43 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_111, torch.float32);  relu__default_111 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_224, to_dtype_162);  le_scalar_54 = new_zeros_default_224 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_114, primals_421, primals_419, primals_420, getitem_433, getitem_434, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_114 = primals_421 = primals_419 = primals_420 = getitem_433 = getitem_434 = None
        getitem_974 = native_batch_norm_backward_default_55[0]
        getitem_975 = native_batch_norm_backward_default_55[1]
        getitem_976 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_974, relu__default_110, primals_442, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_974 = primals_442 = None
        getitem_977 = convolution_backward_default_55[0]
        getitem_978 = convolution_backward_default_55[1]
        getitem_979 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(to_dtype_152, getitem_977);  to_dtype_152 = getitem_977 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_88, torch.float32);  add_tensor_88 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_110, torch.float32);  relu__default_110 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_225, to_dtype_165);  le_scalar_55 = new_zeros_default_225 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_113, primals_396, primals_394, primals_395, getitem_430, getitem_431, True, 1e-05, [True, True, True]);  convolution_default_113 = primals_396 = primals_394 = primals_395 = getitem_430 = getitem_431 = None
        getitem_980 = native_batch_norm_backward_default_56[0]
        getitem_981 = native_batch_norm_backward_default_56[1]
        getitem_982 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_980, cat_default_21, primals_413, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_980 = cat_default_21 = primals_413 = None
        getitem_983 = convolution_backward_default_56[0]
        getitem_984 = convolution_backward_default_56[1]
        getitem_985 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        slice_tensor_44 = torch.ops.aten.slice.Tensor(getitem_983, 1, 0, 104)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(getitem_983, 1, 104, 208)
        slice_tensor_46 = torch.ops.aten.slice.Tensor(getitem_983, 1, 208, 312)
        slice_tensor_47 = torch.ops.aten.slice.Tensor(getitem_983, 1, 312, 416);  getitem_983 = None
        to_dtype_168 = torch.ops.aten.to.dtype(slice_tensor_46, torch.float32);  slice_tensor_46 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_226, to_dtype_168);  le_scalar_56 = new_zeros_default_226 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_112, primals_411, primals_409, primals_410, getitem_427, getitem_428, True, 1e-05, [True, True, True]);  to_dtype_170 = convolution_default_112 = primals_411 = primals_409 = primals_410 = getitem_427 = getitem_428 = None
        getitem_986 = native_batch_norm_backward_default_57[0]
        getitem_987 = native_batch_norm_backward_default_57[1]
        getitem_988 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_986, add_tensor_37, primals_416, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_986 = add_tensor_37 = primals_416 = None
        getitem_989 = convolution_backward_default_57[0]
        getitem_990 = convolution_backward_default_57[1]
        getitem_991 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(slice_tensor_45, getitem_989);  slice_tensor_45 = None
        to_dtype_171 = torch.ops.aten.to.dtype(add_tensor_89, torch.float32);  add_tensor_89 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_227, to_dtype_171);  le_scalar_57 = new_zeros_default_227 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_111, primals_406, primals_404, primals_405, getitem_424, getitem_425, True, 1e-05, [True, True, True]);  to_dtype_173 = convolution_default_111 = primals_406 = primals_404 = primals_405 = getitem_424 = getitem_425 = None
        getitem_992 = native_batch_norm_backward_default_58[0]
        getitem_993 = native_batch_norm_backward_default_58[1]
        getitem_994 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_992, add_tensor_36, primals_415, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_992 = add_tensor_36 = primals_415 = None
        getitem_995 = convolution_backward_default_58[0]
        getitem_996 = convolution_backward_default_58[1]
        getitem_997 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(slice_tensor_44, getitem_995);  slice_tensor_44 = None
        to_dtype_174 = torch.ops.aten.to.dtype(add_tensor_90, torch.float32);  add_tensor_90 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_228, to_dtype_174);  le_scalar_58 = new_zeros_default_228 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_110, primals_401, primals_399, primals_400, getitem_421, getitem_422, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_110 = primals_401 = primals_399 = primals_400 = getitem_421 = getitem_422 = None
        getitem_998 = native_batch_norm_backward_default_59[0]
        getitem_999 = native_batch_norm_backward_default_59[1]
        getitem_1000 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_998, getitem_416, primals_414, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_998 = getitem_416 = primals_414 = None
        getitem_1001 = convolution_backward_default_59[0]
        getitem_1002 = convolution_backward_default_59[1]
        getitem_1003 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        cat_default_44 = torch.ops.aten.cat.default([getitem_1001, getitem_995, getitem_989, slice_tensor_47], 1);  getitem_1001 = getitem_995 = getitem_989 = slice_tensor_47 = None
        to_dtype_177 = torch.ops.aten.to.dtype(cat_default_44, torch.float32);  cat_default_44 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_229, to_dtype_177);  le_scalar_59 = new_zeros_default_229 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_109, primals_391, primals_389, primals_390, getitem_414, getitem_415, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_109 = primals_391 = primals_389 = primals_390 = getitem_414 = getitem_415 = None
        getitem_1004 = native_batch_norm_backward_default_60[0]
        getitem_1005 = native_batch_norm_backward_default_60[1]
        getitem_1006 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_1004, relu__default_105, primals_412, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1004 = primals_412 = None
        getitem_1007 = convolution_backward_default_60[0]
        getitem_1008 = convolution_backward_default_60[1]
        getitem_1009 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(to_dtype_167, getitem_1007);  to_dtype_167 = getitem_1007 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_91, torch.float32);  add_tensor_91 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_230, to_dtype_180);  le_scalar_60 = new_zeros_default_230 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_108, primals_366, primals_364, primals_365, getitem_411, getitem_412, True, 1e-05, [True, True, True]);  convolution_default_108 = primals_366 = primals_364 = primals_365 = getitem_411 = getitem_412 = None
        getitem_1010 = native_batch_norm_backward_default_61[0]
        getitem_1011 = native_batch_norm_backward_default_61[1]
        getitem_1012 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_1010, cat_default_20, primals_383, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1010 = cat_default_20 = primals_383 = None
        getitem_1013 = convolution_backward_default_61[0]
        getitem_1014 = convolution_backward_default_61[1]
        getitem_1015 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        slice_tensor_48 = torch.ops.aten.slice.Tensor(getitem_1013, 1, 0, 104)
        slice_tensor_49 = torch.ops.aten.slice.Tensor(getitem_1013, 1, 104, 208)
        slice_tensor_50 = torch.ops.aten.slice.Tensor(getitem_1013, 1, 208, 312)
        slice_tensor_51 = torch.ops.aten.slice.Tensor(getitem_1013, 1, 312, 416);  getitem_1013 = None
        to_dtype_183 = torch.ops.aten.to.dtype(slice_tensor_50, torch.float32);  slice_tensor_50 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_231, to_dtype_183);  le_scalar_61 = new_zeros_default_231 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_107, primals_381, primals_379, primals_380, getitem_408, getitem_409, True, 1e-05, [True, True, True]);  to_dtype_185 = convolution_default_107 = primals_381 = primals_379 = primals_380 = getitem_408 = getitem_409 = None
        getitem_1016 = native_batch_norm_backward_default_62[0]
        getitem_1017 = native_batch_norm_backward_default_62[1]
        getitem_1018 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_1016, add_tensor_35, primals_386, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1016 = add_tensor_35 = primals_386 = None
        getitem_1019 = convolution_backward_default_62[0]
        getitem_1020 = convolution_backward_default_62[1]
        getitem_1021 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(slice_tensor_49, getitem_1019);  slice_tensor_49 = None
        to_dtype_186 = torch.ops.aten.to.dtype(add_tensor_92, torch.float32);  add_tensor_92 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_232, to_dtype_186);  le_scalar_62 = new_zeros_default_232 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_106, primals_376, primals_374, primals_375, getitem_405, getitem_406, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_106 = primals_376 = primals_374 = primals_375 = getitem_405 = getitem_406 = None
        getitem_1022 = native_batch_norm_backward_default_63[0]
        getitem_1023 = native_batch_norm_backward_default_63[1]
        getitem_1024 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_1022, add_tensor_34, primals_385, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1022 = add_tensor_34 = primals_385 = None
        getitem_1025 = convolution_backward_default_63[0]
        getitem_1026 = convolution_backward_default_63[1]
        getitem_1027 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(slice_tensor_48, getitem_1025);  slice_tensor_48 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_93, torch.float32);  add_tensor_93 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_233, to_dtype_189);  le_scalar_63 = new_zeros_default_233 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_105, primals_371, primals_369, primals_370, getitem_402, getitem_403, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_105 = primals_371 = primals_369 = primals_370 = getitem_402 = getitem_403 = None
        getitem_1028 = native_batch_norm_backward_default_64[0]
        getitem_1029 = native_batch_norm_backward_default_64[1]
        getitem_1030 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_1028, getitem_397, primals_384, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1028 = getitem_397 = primals_384 = None
        getitem_1031 = convolution_backward_default_64[0]
        getitem_1032 = convolution_backward_default_64[1]
        getitem_1033 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        cat_default_45 = torch.ops.aten.cat.default([getitem_1031, getitem_1025, getitem_1019, slice_tensor_51], 1);  getitem_1031 = getitem_1025 = getitem_1019 = slice_tensor_51 = None
        to_dtype_192 = torch.ops.aten.to.dtype(cat_default_45, torch.float32);  cat_default_45 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_234, to_dtype_192);  le_scalar_64 = new_zeros_default_234 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_104, primals_361, primals_359, primals_360, getitem_395, getitem_396, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default_104 = primals_361 = primals_359 = primals_360 = getitem_395 = getitem_396 = None
        getitem_1034 = native_batch_norm_backward_default_65[0]
        getitem_1035 = native_batch_norm_backward_default_65[1]
        getitem_1036 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_1034, relu__default_100, primals_382, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1034 = primals_382 = None
        getitem_1037 = convolution_backward_default_65[0]
        getitem_1038 = convolution_backward_default_65[1]
        getitem_1039 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(to_dtype_182, getitem_1037);  to_dtype_182 = getitem_1037 = None
        to_dtype_195 = torch.ops.aten.to.dtype(add_tensor_94, torch.float32);  add_tensor_94 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_235, to_dtype_195);  le_scalar_65 = new_zeros_default_235 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_103, primals_336, primals_334, primals_335, getitem_392, getitem_393, True, 1e-05, [True, True, True]);  convolution_default_103 = primals_336 = primals_334 = primals_335 = getitem_392 = getitem_393 = None
        getitem_1040 = native_batch_norm_backward_default_66[0]
        getitem_1041 = native_batch_norm_backward_default_66[1]
        getitem_1042 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_1040, cat_default_19, primals_353, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1040 = cat_default_19 = primals_353 = None
        getitem_1043 = convolution_backward_default_66[0]
        getitem_1044 = convolution_backward_default_66[1]
        getitem_1045 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        slice_tensor_52 = torch.ops.aten.slice.Tensor(getitem_1043, 1, 0, 104)
        slice_tensor_53 = torch.ops.aten.slice.Tensor(getitem_1043, 1, 104, 208)
        slice_tensor_54 = torch.ops.aten.slice.Tensor(getitem_1043, 1, 208, 312)
        slice_tensor_55 = torch.ops.aten.slice.Tensor(getitem_1043, 1, 312, 416);  getitem_1043 = None
        to_dtype_198 = torch.ops.aten.to.dtype(slice_tensor_54, torch.float32);  slice_tensor_54 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_236, to_dtype_198);  le_scalar_66 = new_zeros_default_236 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_102, primals_351, primals_349, primals_350, getitem_389, getitem_390, True, 1e-05, [True, True, True]);  to_dtype_200 = convolution_default_102 = primals_351 = primals_349 = primals_350 = getitem_389 = getitem_390 = None
        getitem_1046 = native_batch_norm_backward_default_67[0]
        getitem_1047 = native_batch_norm_backward_default_67[1]
        getitem_1048 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_1046, add_tensor_33, primals_356, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1046 = add_tensor_33 = primals_356 = None
        getitem_1049 = convolution_backward_default_67[0]
        getitem_1050 = convolution_backward_default_67[1]
        getitem_1051 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(slice_tensor_53, getitem_1049);  slice_tensor_53 = None
        to_dtype_201 = torch.ops.aten.to.dtype(add_tensor_95, torch.float32);  add_tensor_95 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_237 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_237, to_dtype_201);  le_scalar_67 = new_zeros_default_237 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_101, primals_346, primals_344, primals_345, getitem_386, getitem_387, True, 1e-05, [True, True, True]);  to_dtype_203 = convolution_default_101 = primals_346 = primals_344 = primals_345 = getitem_386 = getitem_387 = None
        getitem_1052 = native_batch_norm_backward_default_68[0]
        getitem_1053 = native_batch_norm_backward_default_68[1]
        getitem_1054 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_1052, add_tensor_32, primals_355, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1052 = add_tensor_32 = primals_355 = None
        getitem_1055 = convolution_backward_default_68[0]
        getitem_1056 = convolution_backward_default_68[1]
        getitem_1057 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(slice_tensor_52, getitem_1055);  slice_tensor_52 = None
        to_dtype_204 = torch.ops.aten.to.dtype(add_tensor_96, torch.float32);  add_tensor_96 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_238 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_238, to_dtype_204);  le_scalar_68 = new_zeros_default_238 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_100, primals_341, primals_339, primals_340, getitem_383, getitem_384, True, 1e-05, [True, True, True]);  to_dtype_206 = convolution_default_100 = primals_341 = primals_339 = primals_340 = getitem_383 = getitem_384 = None
        getitem_1058 = native_batch_norm_backward_default_69[0]
        getitem_1059 = native_batch_norm_backward_default_69[1]
        getitem_1060 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_1058, getitem_378, primals_354, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1058 = getitem_378 = primals_354 = None
        getitem_1061 = convolution_backward_default_69[0]
        getitem_1062 = convolution_backward_default_69[1]
        getitem_1063 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        cat_default_46 = torch.ops.aten.cat.default([getitem_1061, getitem_1055, getitem_1049, slice_tensor_55], 1);  getitem_1061 = getitem_1055 = getitem_1049 = slice_tensor_55 = None
        to_dtype_207 = torch.ops.aten.to.dtype(cat_default_46, torch.float32);  cat_default_46 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_239 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_239, to_dtype_207);  le_scalar_69 = new_zeros_default_239 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_99, primals_331, primals_329, primals_330, getitem_376, getitem_377, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_99 = primals_331 = primals_329 = primals_330 = getitem_376 = getitem_377 = None
        getitem_1064 = native_batch_norm_backward_default_70[0]
        getitem_1065 = native_batch_norm_backward_default_70[1]
        getitem_1066 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_1064, relu__default_95, primals_352, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1064 = primals_352 = None
        getitem_1067 = convolution_backward_default_70[0]
        getitem_1068 = convolution_backward_default_70[1]
        getitem_1069 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(to_dtype_197, getitem_1067);  to_dtype_197 = getitem_1067 = None
        to_dtype_210 = torch.ops.aten.to.dtype(add_tensor_97, torch.float32);  add_tensor_97 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_240 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_240, to_dtype_210);  le_scalar_70 = new_zeros_default_240 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_98, primals_306, primals_304, primals_305, getitem_373, getitem_374, True, 1e-05, [True, True, True]);  convolution_default_98 = primals_306 = primals_304 = primals_305 = getitem_373 = getitem_374 = None
        getitem_1070 = native_batch_norm_backward_default_71[0]
        getitem_1071 = native_batch_norm_backward_default_71[1]
        getitem_1072 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_1070, cat_default_18, primals_323, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1070 = cat_default_18 = primals_323 = None
        getitem_1073 = convolution_backward_default_71[0]
        getitem_1074 = convolution_backward_default_71[1]
        getitem_1075 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        slice_tensor_56 = torch.ops.aten.slice.Tensor(getitem_1073, 1, 0, 104)
        slice_tensor_57 = torch.ops.aten.slice.Tensor(getitem_1073, 1, 104, 208)
        slice_tensor_58 = torch.ops.aten.slice.Tensor(getitem_1073, 1, 208, 312)
        slice_tensor_59 = torch.ops.aten.slice.Tensor(getitem_1073, 1, 312, 416);  getitem_1073 = None
        to_dtype_213 = torch.ops.aten.to.dtype(slice_tensor_58, torch.float32);  slice_tensor_58 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_241 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_241, to_dtype_213);  le_scalar_71 = new_zeros_default_241 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_97, primals_321, primals_319, primals_320, getitem_370, getitem_371, True, 1e-05, [True, True, True]);  to_dtype_215 = convolution_default_97 = primals_321 = primals_319 = primals_320 = getitem_370 = getitem_371 = None
        getitem_1076 = native_batch_norm_backward_default_72[0]
        getitem_1077 = native_batch_norm_backward_default_72[1]
        getitem_1078 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_1076, add_tensor_31, primals_326, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1076 = add_tensor_31 = primals_326 = None
        getitem_1079 = convolution_backward_default_72[0]
        getitem_1080 = convolution_backward_default_72[1]
        getitem_1081 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(slice_tensor_57, getitem_1079);  slice_tensor_57 = None
        to_dtype_216 = torch.ops.aten.to.dtype(add_tensor_98, torch.float32);  add_tensor_98 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_242 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_242, to_dtype_216);  le_scalar_72 = new_zeros_default_242 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_96, primals_316, primals_314, primals_315, getitem_367, getitem_368, True, 1e-05, [True, True, True]);  to_dtype_218 = convolution_default_96 = primals_316 = primals_314 = primals_315 = getitem_367 = getitem_368 = None
        getitem_1082 = native_batch_norm_backward_default_73[0]
        getitem_1083 = native_batch_norm_backward_default_73[1]
        getitem_1084 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_1082, add_tensor_30, primals_325, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1082 = add_tensor_30 = primals_325 = None
        getitem_1085 = convolution_backward_default_73[0]
        getitem_1086 = convolution_backward_default_73[1]
        getitem_1087 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(slice_tensor_56, getitem_1085);  slice_tensor_56 = None
        to_dtype_219 = torch.ops.aten.to.dtype(add_tensor_99, torch.float32);  add_tensor_99 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_243 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_243, to_dtype_219);  le_scalar_73 = new_zeros_default_243 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_95, primals_311, primals_309, primals_310, getitem_364, getitem_365, True, 1e-05, [True, True, True]);  to_dtype_221 = convolution_default_95 = primals_311 = primals_309 = primals_310 = getitem_364 = getitem_365 = None
        getitem_1088 = native_batch_norm_backward_default_74[0]
        getitem_1089 = native_batch_norm_backward_default_74[1]
        getitem_1090 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_1088, getitem_359, primals_324, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1088 = getitem_359 = primals_324 = None
        getitem_1091 = convolution_backward_default_74[0]
        getitem_1092 = convolution_backward_default_74[1]
        getitem_1093 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        cat_default_47 = torch.ops.aten.cat.default([getitem_1091, getitem_1085, getitem_1079, slice_tensor_59], 1);  getitem_1091 = getitem_1085 = getitem_1079 = slice_tensor_59 = None
        to_dtype_222 = torch.ops.aten.to.dtype(cat_default_47, torch.float32);  cat_default_47 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_244 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_244, to_dtype_222);  le_scalar_74 = new_zeros_default_244 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_94, primals_301, primals_299, primals_300, getitem_357, getitem_358, True, 1e-05, [True, True, True]);  to_dtype_224 = convolution_default_94 = primals_301 = primals_299 = primals_300 = getitem_357 = getitem_358 = None
        getitem_1094 = native_batch_norm_backward_default_75[0]
        getitem_1095 = native_batch_norm_backward_default_75[1]
        getitem_1096 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_1094, relu__default_90, primals_322, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1094 = primals_322 = None
        getitem_1097 = convolution_backward_default_75[0]
        getitem_1098 = convolution_backward_default_75[1]
        getitem_1099 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(to_dtype_212, getitem_1097);  to_dtype_212 = getitem_1097 = None
        to_dtype_225 = torch.ops.aten.to.dtype(add_tensor_100, torch.float32);  add_tensor_100 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_245 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_245, to_dtype_225);  le_scalar_75 = new_zeros_default_245 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_93, primals_276, primals_274, primals_275, getitem_354, getitem_355, True, 1e-05, [True, True, True]);  convolution_default_93 = primals_276 = primals_274 = primals_275 = getitem_354 = getitem_355 = None
        getitem_1100 = native_batch_norm_backward_default_76[0]
        getitem_1101 = native_batch_norm_backward_default_76[1]
        getitem_1102 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_1100, cat_default_17, primals_293, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1100 = cat_default_17 = primals_293 = None
        getitem_1103 = convolution_backward_default_76[0]
        getitem_1104 = convolution_backward_default_76[1]
        getitem_1105 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        slice_tensor_60 = torch.ops.aten.slice.Tensor(getitem_1103, 1, 0, 104)
        slice_tensor_61 = torch.ops.aten.slice.Tensor(getitem_1103, 1, 104, 208)
        slice_tensor_62 = torch.ops.aten.slice.Tensor(getitem_1103, 1, 208, 312)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(getitem_1103, 1, 312, 416);  getitem_1103 = None
        to_dtype_228 = torch.ops.aten.to.dtype(slice_tensor_62, torch.float32);  slice_tensor_62 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_246 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_246, to_dtype_228);  le_scalar_76 = new_zeros_default_246 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_92, primals_291, primals_289, primals_290, getitem_351, getitem_352, True, 1e-05, [True, True, True]);  to_dtype_230 = convolution_default_92 = primals_291 = primals_289 = primals_290 = getitem_351 = getitem_352 = None
        getitem_1106 = native_batch_norm_backward_default_77[0]
        getitem_1107 = native_batch_norm_backward_default_77[1]
        getitem_1108 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_1106, add_tensor_29, primals_296, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1106 = add_tensor_29 = primals_296 = None
        getitem_1109 = convolution_backward_default_77[0]
        getitem_1110 = convolution_backward_default_77[1]
        getitem_1111 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(slice_tensor_61, getitem_1109);  slice_tensor_61 = None
        to_dtype_231 = torch.ops.aten.to.dtype(add_tensor_101, torch.float32);  add_tensor_101 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_247 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_247, to_dtype_231);  le_scalar_77 = new_zeros_default_247 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_91, primals_286, primals_284, primals_285, getitem_348, getitem_349, True, 1e-05, [True, True, True]);  to_dtype_233 = convolution_default_91 = primals_286 = primals_284 = primals_285 = getitem_348 = getitem_349 = None
        getitem_1112 = native_batch_norm_backward_default_78[0]
        getitem_1113 = native_batch_norm_backward_default_78[1]
        getitem_1114 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_1112, add_tensor_28, primals_295, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1112 = add_tensor_28 = primals_295 = None
        getitem_1115 = convolution_backward_default_78[0]
        getitem_1116 = convolution_backward_default_78[1]
        getitem_1117 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(slice_tensor_60, getitem_1115);  slice_tensor_60 = None
        to_dtype_234 = torch.ops.aten.to.dtype(add_tensor_102, torch.float32);  add_tensor_102 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_248 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_248, to_dtype_234);  le_scalar_78 = new_zeros_default_248 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_90, primals_281, primals_279, primals_280, getitem_345, getitem_346, True, 1e-05, [True, True, True]);  to_dtype_236 = convolution_default_90 = primals_281 = primals_279 = primals_280 = getitem_345 = getitem_346 = None
        getitem_1118 = native_batch_norm_backward_default_79[0]
        getitem_1119 = native_batch_norm_backward_default_79[1]
        getitem_1120 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_1118, getitem_340, primals_294, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1118 = getitem_340 = primals_294 = None
        getitem_1121 = convolution_backward_default_79[0]
        getitem_1122 = convolution_backward_default_79[1]
        getitem_1123 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        cat_default_48 = torch.ops.aten.cat.default([getitem_1121, getitem_1115, getitem_1109, slice_tensor_63], 1);  getitem_1121 = getitem_1115 = getitem_1109 = slice_tensor_63 = None
        to_dtype_237 = torch.ops.aten.to.dtype(cat_default_48, torch.float32);  cat_default_48 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_249 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_249, to_dtype_237);  le_scalar_79 = new_zeros_default_249 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_89, primals_271, primals_269, primals_270, getitem_338, getitem_339, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_89 = primals_271 = primals_269 = primals_270 = getitem_338 = getitem_339 = None
        getitem_1124 = native_batch_norm_backward_default_80[0]
        getitem_1125 = native_batch_norm_backward_default_80[1]
        getitem_1126 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_1124, relu__default_85, primals_292, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1124 = primals_292 = None
        getitem_1127 = convolution_backward_default_80[0]
        getitem_1128 = convolution_backward_default_80[1]
        getitem_1129 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(to_dtype_227, getitem_1127);  to_dtype_227 = getitem_1127 = None
        to_dtype_240 = torch.ops.aten.to.dtype(add_tensor_103, torch.float32);  add_tensor_103 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_250 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_250, to_dtype_240);  le_scalar_80 = new_zeros_default_250 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_88, primals_906, primals_904, primals_905, getitem_335, getitem_336, True, 1e-05, [True, True, True]);  convolution_default_88 = primals_906 = primals_904 = primals_905 = getitem_335 = getitem_336 = None
        getitem_1130 = native_batch_norm_backward_default_81[0]
        getitem_1131 = native_batch_norm_backward_default_81[1]
        getitem_1132 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_1130, cat_default_16, primals_923, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1130 = cat_default_16 = primals_923 = None
        getitem_1133 = convolution_backward_default_81[0]
        getitem_1134 = convolution_backward_default_81[1]
        getitem_1135 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        slice_tensor_64 = torch.ops.aten.slice.Tensor(getitem_1133, 1, 0, 104)
        slice_tensor_65 = torch.ops.aten.slice.Tensor(getitem_1133, 1, 104, 208)
        slice_tensor_66 = torch.ops.aten.slice.Tensor(getitem_1133, 1, 208, 312)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(getitem_1133, 1, 312, 416);  getitem_1133 = None
        to_dtype_243 = torch.ops.aten.to.dtype(slice_tensor_66, torch.float32);  slice_tensor_66 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_251 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_251, to_dtype_243);  le_scalar_81 = new_zeros_default_251 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_245, convolution_default_87, primals_921, primals_919, primals_920, getitem_332, getitem_333, True, 1e-05, [True, True, True]);  to_dtype_245 = convolution_default_87 = primals_921 = primals_919 = primals_920 = getitem_332 = getitem_333 = None
        getitem_1136 = native_batch_norm_backward_default_82[0]
        getitem_1137 = native_batch_norm_backward_default_82[1]
        getitem_1138 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_1136, add_tensor_27, primals_926, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1136 = add_tensor_27 = primals_926 = None
        getitem_1139 = convolution_backward_default_82[0]
        getitem_1140 = convolution_backward_default_82[1]
        getitem_1141 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(slice_tensor_65, getitem_1139);  slice_tensor_65 = None
        to_dtype_246 = torch.ops.aten.to.dtype(add_tensor_104, torch.float32);  add_tensor_104 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_252 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_252, to_dtype_246);  le_scalar_82 = new_zeros_default_252 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_86, primals_916, primals_914, primals_915, getitem_329, getitem_330, True, 1e-05, [True, True, True]);  to_dtype_248 = convolution_default_86 = primals_916 = primals_914 = primals_915 = getitem_329 = getitem_330 = None
        getitem_1142 = native_batch_norm_backward_default_83[0]
        getitem_1143 = native_batch_norm_backward_default_83[1]
        getitem_1144 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_1142, add_tensor_26, primals_925, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1142 = add_tensor_26 = primals_925 = None
        getitem_1145 = convolution_backward_default_83[0]
        getitem_1146 = convolution_backward_default_83[1]
        getitem_1147 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(slice_tensor_64, getitem_1145);  slice_tensor_64 = None
        to_dtype_249 = torch.ops.aten.to.dtype(add_tensor_105, torch.float32);  add_tensor_105 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_253 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_253, to_dtype_249);  le_scalar_83 = new_zeros_default_253 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_85, primals_911, primals_909, primals_910, getitem_326, getitem_327, True, 1e-05, [True, True, True]);  to_dtype_251 = convolution_default_85 = primals_911 = primals_909 = primals_910 = getitem_326 = getitem_327 = None
        getitem_1148 = native_batch_norm_backward_default_84[0]
        getitem_1149 = native_batch_norm_backward_default_84[1]
        getitem_1150 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_1148, getitem_321, primals_924, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1148 = getitem_321 = primals_924 = None
        getitem_1151 = convolution_backward_default_84[0]
        getitem_1152 = convolution_backward_default_84[1]
        getitem_1153 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        cat_default_49 = torch.ops.aten.cat.default([getitem_1151, getitem_1145, getitem_1139, slice_tensor_67], 1);  getitem_1151 = getitem_1145 = getitem_1139 = slice_tensor_67 = None
        to_dtype_252 = torch.ops.aten.to.dtype(cat_default_49, torch.float32);  cat_default_49 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_254 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_254, to_dtype_252);  le_scalar_84 = new_zeros_default_254 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_84, primals_901, primals_899, primals_900, getitem_319, getitem_320, True, 1e-05, [True, True, True]);  to_dtype_254 = convolution_default_84 = primals_901 = primals_899 = primals_900 = getitem_319 = getitem_320 = None
        getitem_1154 = native_batch_norm_backward_default_85[0]
        getitem_1155 = native_batch_norm_backward_default_85[1]
        getitem_1156 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_1154, relu__default_80, primals_922, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1154 = primals_922 = None
        getitem_1157 = convolution_backward_default_85[0]
        getitem_1158 = convolution_backward_default_85[1]
        getitem_1159 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(to_dtype_242, getitem_1157);  to_dtype_242 = getitem_1157 = None
        to_dtype_255 = torch.ops.aten.to.dtype(add_tensor_106, torch.float32);  add_tensor_106 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_255 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_255, to_dtype_255);  le_scalar_85 = new_zeros_default_255 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_257, convolution_default_83, primals_876, primals_874, primals_875, getitem_316, getitem_317, True, 1e-05, [True, True, True]);  convolution_default_83 = primals_876 = primals_874 = primals_875 = getitem_316 = getitem_317 = None
        getitem_1160 = native_batch_norm_backward_default_86[0]
        getitem_1161 = native_batch_norm_backward_default_86[1]
        getitem_1162 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_1160, cat_default_15, primals_893, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1160 = cat_default_15 = primals_893 = None
        getitem_1163 = convolution_backward_default_86[0]
        getitem_1164 = convolution_backward_default_86[1]
        getitem_1165 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        slice_tensor_68 = torch.ops.aten.slice.Tensor(getitem_1163, 1, 0, 104)
        slice_tensor_69 = torch.ops.aten.slice.Tensor(getitem_1163, 1, 104, 208)
        slice_tensor_70 = torch.ops.aten.slice.Tensor(getitem_1163, 1, 208, 312)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(getitem_1163, 1, 312, 416);  getitem_1163 = None
        to_dtype_258 = torch.ops.aten.to.dtype(slice_tensor_70, torch.float32);  slice_tensor_70 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_256 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_256, to_dtype_258);  le_scalar_86 = new_zeros_default_256 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_82, primals_891, primals_889, primals_890, getitem_313, getitem_314, True, 1e-05, [True, True, True]);  to_dtype_260 = convolution_default_82 = primals_891 = primals_889 = primals_890 = getitem_313 = getitem_314 = None
        getitem_1166 = native_batch_norm_backward_default_87[0]
        getitem_1167 = native_batch_norm_backward_default_87[1]
        getitem_1168 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_1166, add_tensor_25, primals_896, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1166 = add_tensor_25 = primals_896 = None
        getitem_1169 = convolution_backward_default_87[0]
        getitem_1170 = convolution_backward_default_87[1]
        getitem_1171 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(slice_tensor_69, getitem_1169);  slice_tensor_69 = None
        to_dtype_261 = torch.ops.aten.to.dtype(add_tensor_107, torch.float32);  add_tensor_107 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_257 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_257, to_dtype_261);  le_scalar_87 = new_zeros_default_257 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_81, primals_886, primals_884, primals_885, getitem_310, getitem_311, True, 1e-05, [True, True, True]);  to_dtype_263 = convolution_default_81 = primals_886 = primals_884 = primals_885 = getitem_310 = getitem_311 = None
        getitem_1172 = native_batch_norm_backward_default_88[0]
        getitem_1173 = native_batch_norm_backward_default_88[1]
        getitem_1174 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_1172, add_tensor_24, primals_895, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1172 = add_tensor_24 = primals_895 = None
        getitem_1175 = convolution_backward_default_88[0]
        getitem_1176 = convolution_backward_default_88[1]
        getitem_1177 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(slice_tensor_68, getitem_1175);  slice_tensor_68 = None
        to_dtype_264 = torch.ops.aten.to.dtype(add_tensor_108, torch.float32);  add_tensor_108 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_258 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_258, to_dtype_264);  le_scalar_88 = new_zeros_default_258 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_80, primals_881, primals_879, primals_880, getitem_307, getitem_308, True, 1e-05, [True, True, True]);  to_dtype_266 = convolution_default_80 = primals_881 = primals_879 = primals_880 = getitem_307 = getitem_308 = None
        getitem_1178 = native_batch_norm_backward_default_89[0]
        getitem_1179 = native_batch_norm_backward_default_89[1]
        getitem_1180 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_1178, getitem_302, primals_894, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1178 = getitem_302 = primals_894 = None
        getitem_1181 = convolution_backward_default_89[0]
        getitem_1182 = convolution_backward_default_89[1]
        getitem_1183 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        cat_default_50 = torch.ops.aten.cat.default([getitem_1181, getitem_1175, getitem_1169, slice_tensor_71], 1);  getitem_1181 = getitem_1175 = getitem_1169 = slice_tensor_71 = None
        to_dtype_267 = torch.ops.aten.to.dtype(cat_default_50, torch.float32);  cat_default_50 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_259 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_259, to_dtype_267);  le_scalar_89 = new_zeros_default_259 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_79, primals_871, primals_869, primals_870, getitem_300, getitem_301, True, 1e-05, [True, True, True]);  to_dtype_269 = convolution_default_79 = primals_871 = primals_869 = primals_870 = getitem_300 = getitem_301 = None
        getitem_1184 = native_batch_norm_backward_default_90[0]
        getitem_1185 = native_batch_norm_backward_default_90[1]
        getitem_1186 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_1184, relu__default_75, primals_892, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1184 = primals_892 = None
        getitem_1187 = convolution_backward_default_90[0]
        getitem_1188 = convolution_backward_default_90[1]
        getitem_1189 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(to_dtype_257, getitem_1187);  to_dtype_257 = getitem_1187 = None
        to_dtype_270 = torch.ops.aten.to.dtype(add_tensor_109, torch.float32);  add_tensor_109 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_260 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_260, to_dtype_270);  le_scalar_90 = new_zeros_default_260 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_78, primals_846, primals_844, primals_845, getitem_297, getitem_298, True, 1e-05, [True, True, True]);  convolution_default_78 = primals_846 = primals_844 = primals_845 = getitem_297 = getitem_298 = None
        getitem_1190 = native_batch_norm_backward_default_91[0]
        getitem_1191 = native_batch_norm_backward_default_91[1]
        getitem_1192 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_1190, cat_default_14, primals_863, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1190 = cat_default_14 = primals_863 = None
        getitem_1193 = convolution_backward_default_91[0]
        getitem_1194 = convolution_backward_default_91[1]
        getitem_1195 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        slice_tensor_72 = torch.ops.aten.slice.Tensor(getitem_1193, 1, 0, 104)
        slice_tensor_73 = torch.ops.aten.slice.Tensor(getitem_1193, 1, 104, 208)
        slice_tensor_74 = torch.ops.aten.slice.Tensor(getitem_1193, 1, 208, 312)
        slice_tensor_75 = torch.ops.aten.slice.Tensor(getitem_1193, 1, 312, 416);  getitem_1193 = None
        to_dtype_273 = torch.ops.aten.to.dtype(slice_tensor_74, torch.float32);  slice_tensor_74 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_261 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_261, to_dtype_273);  le_scalar_91 = new_zeros_default_261 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_77, primals_861, primals_859, primals_860, getitem_294, getitem_295, True, 1e-05, [True, True, True]);  to_dtype_275 = convolution_default_77 = primals_861 = primals_859 = primals_860 = getitem_294 = getitem_295 = None
        getitem_1196 = native_batch_norm_backward_default_92[0]
        getitem_1197 = native_batch_norm_backward_default_92[1]
        getitem_1198 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_1196, add_tensor_23, primals_866, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1196 = add_tensor_23 = primals_866 = None
        getitem_1199 = convolution_backward_default_92[0]
        getitem_1200 = convolution_backward_default_92[1]
        getitem_1201 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(slice_tensor_73, getitem_1199);  slice_tensor_73 = None
        to_dtype_276 = torch.ops.aten.to.dtype(add_tensor_110, torch.float32);  add_tensor_110 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_262 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_262, to_dtype_276);  le_scalar_92 = new_zeros_default_262 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_278, convolution_default_76, primals_856, primals_854, primals_855, getitem_291, getitem_292, True, 1e-05, [True, True, True]);  to_dtype_278 = convolution_default_76 = primals_856 = primals_854 = primals_855 = getitem_291 = getitem_292 = None
        getitem_1202 = native_batch_norm_backward_default_93[0]
        getitem_1203 = native_batch_norm_backward_default_93[1]
        getitem_1204 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_1202, add_tensor_22, primals_865, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1202 = add_tensor_22 = primals_865 = None
        getitem_1205 = convolution_backward_default_93[0]
        getitem_1206 = convolution_backward_default_93[1]
        getitem_1207 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(slice_tensor_72, getitem_1205);  slice_tensor_72 = None
        to_dtype_279 = torch.ops.aten.to.dtype(add_tensor_111, torch.float32);  add_tensor_111 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_263 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_263, to_dtype_279);  le_scalar_93 = new_zeros_default_263 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_75, primals_851, primals_849, primals_850, getitem_288, getitem_289, True, 1e-05, [True, True, True]);  to_dtype_281 = convolution_default_75 = primals_851 = primals_849 = primals_850 = getitem_288 = getitem_289 = None
        getitem_1208 = native_batch_norm_backward_default_94[0]
        getitem_1209 = native_batch_norm_backward_default_94[1]
        getitem_1210 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_1208, getitem_283, primals_864, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1208 = getitem_283 = primals_864 = None
        getitem_1211 = convolution_backward_default_94[0]
        getitem_1212 = convolution_backward_default_94[1]
        getitem_1213 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        cat_default_51 = torch.ops.aten.cat.default([getitem_1211, getitem_1205, getitem_1199, slice_tensor_75], 1);  getitem_1211 = getitem_1205 = getitem_1199 = slice_tensor_75 = None
        to_dtype_282 = torch.ops.aten.to.dtype(cat_default_51, torch.float32);  cat_default_51 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_264, to_dtype_282);  le_scalar_94 = new_zeros_default_264 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_74, primals_841, primals_839, primals_840, getitem_281, getitem_282, True, 1e-05, [True, True, True]);  to_dtype_284 = convolution_default_74 = primals_841 = primals_839 = primals_840 = getitem_281 = getitem_282 = None
        getitem_1214 = native_batch_norm_backward_default_95[0]
        getitem_1215 = native_batch_norm_backward_default_95[1]
        getitem_1216 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_1214, relu__default_70, primals_862, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1214 = primals_862 = None
        getitem_1217 = convolution_backward_default_95[0]
        getitem_1218 = convolution_backward_default_95[1]
        getitem_1219 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(to_dtype_272, getitem_1217);  to_dtype_272 = getitem_1217 = None
        to_dtype_285 = torch.ops.aten.to.dtype(add_tensor_112, torch.float32);  add_tensor_112 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_265, to_dtype_285);  le_scalar_95 = new_zeros_default_265 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_287, convolution_default_73, primals_816, primals_814, primals_815, getitem_278, getitem_279, True, 1e-05, [True, True, True]);  convolution_default_73 = primals_816 = primals_814 = primals_815 = getitem_278 = getitem_279 = None
        getitem_1220 = native_batch_norm_backward_default_96[0]
        getitem_1221 = native_batch_norm_backward_default_96[1]
        getitem_1222 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_1220, cat_default_13, primals_833, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1220 = cat_default_13 = primals_833 = None
        getitem_1223 = convolution_backward_default_96[0]
        getitem_1224 = convolution_backward_default_96[1]
        getitem_1225 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        slice_tensor_76 = torch.ops.aten.slice.Tensor(getitem_1223, 1, 0, 104)
        slice_tensor_77 = torch.ops.aten.slice.Tensor(getitem_1223, 1, 104, 208)
        slice_tensor_78 = torch.ops.aten.slice.Tensor(getitem_1223, 1, 208, 312)
        slice_tensor_79 = torch.ops.aten.slice.Tensor(getitem_1223, 1, 312, 416);  getitem_1223 = None
        to_dtype_288 = torch.ops.aten.to.dtype(slice_tensor_78, torch.float32);  slice_tensor_78 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_266, to_dtype_288);  le_scalar_96 = new_zeros_default_266 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_72, primals_831, primals_829, primals_830, getitem_275, getitem_276, True, 1e-05, [True, True, True]);  to_dtype_290 = convolution_default_72 = primals_831 = primals_829 = primals_830 = getitem_275 = getitem_276 = None
        getitem_1226 = native_batch_norm_backward_default_97[0]
        getitem_1227 = native_batch_norm_backward_default_97[1]
        getitem_1228 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_1226, add_tensor_21, primals_836, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1226 = add_tensor_21 = primals_836 = None
        getitem_1229 = convolution_backward_default_97[0]
        getitem_1230 = convolution_backward_default_97[1]
        getitem_1231 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(slice_tensor_77, getitem_1229);  slice_tensor_77 = None
        to_dtype_291 = torch.ops.aten.to.dtype(add_tensor_113, torch.float32);  add_tensor_113 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_267, to_dtype_291);  le_scalar_97 = new_zeros_default_267 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_293, convolution_default_71, primals_826, primals_824, primals_825, getitem_272, getitem_273, True, 1e-05, [True, True, True]);  to_dtype_293 = convolution_default_71 = primals_826 = primals_824 = primals_825 = getitem_272 = getitem_273 = None
        getitem_1232 = native_batch_norm_backward_default_98[0]
        getitem_1233 = native_batch_norm_backward_default_98[1]
        getitem_1234 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_1232, add_tensor_20, primals_835, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1232 = add_tensor_20 = primals_835 = None
        getitem_1235 = convolution_backward_default_98[0]
        getitem_1236 = convolution_backward_default_98[1]
        getitem_1237 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(slice_tensor_76, getitem_1235);  slice_tensor_76 = None
        to_dtype_294 = torch.ops.aten.to.dtype(add_tensor_114, torch.float32);  add_tensor_114 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_268, to_dtype_294);  le_scalar_98 = new_zeros_default_268 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_70, primals_821, primals_819, primals_820, getitem_269, getitem_270, True, 1e-05, [True, True, True]);  to_dtype_296 = convolution_default_70 = primals_821 = primals_819 = primals_820 = getitem_269 = getitem_270 = None
        getitem_1238 = native_batch_norm_backward_default_99[0]
        getitem_1239 = native_batch_norm_backward_default_99[1]
        getitem_1240 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_1238, getitem_264, primals_834, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1238 = getitem_264 = primals_834 = None
        getitem_1241 = convolution_backward_default_99[0]
        getitem_1242 = convolution_backward_default_99[1]
        getitem_1243 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        cat_default_52 = torch.ops.aten.cat.default([getitem_1241, getitem_1235, getitem_1229, slice_tensor_79], 1);  getitem_1241 = getitem_1235 = getitem_1229 = slice_tensor_79 = None
        to_dtype_297 = torch.ops.aten.to.dtype(cat_default_52, torch.float32);  cat_default_52 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_269, to_dtype_297);  le_scalar_99 = new_zeros_default_269 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_69, primals_811, primals_809, primals_810, getitem_262, getitem_263, True, 1e-05, [True, True, True]);  to_dtype_299 = convolution_default_69 = primals_811 = primals_809 = primals_810 = getitem_262 = getitem_263 = None
        getitem_1244 = native_batch_norm_backward_default_100[0]
        getitem_1245 = native_batch_norm_backward_default_100[1]
        getitem_1246 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_1244, relu__default_65, primals_832, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1244 = primals_832 = None
        getitem_1247 = convolution_backward_default_100[0]
        getitem_1248 = convolution_backward_default_100[1]
        getitem_1249 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(to_dtype_287, getitem_1247);  to_dtype_287 = getitem_1247 = None
        to_dtype_300 = torch.ops.aten.to.dtype(add_tensor_115, torch.float32);  add_tensor_115 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_270, to_dtype_300);  le_scalar_100 = new_zeros_default_270 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_68, primals_786, primals_784, primals_785, getitem_259, getitem_260, True, 1e-05, [True, True, True]);  convolution_default_68 = primals_786 = primals_784 = primals_785 = getitem_259 = getitem_260 = None
        getitem_1250 = native_batch_norm_backward_default_101[0]
        getitem_1251 = native_batch_norm_backward_default_101[1]
        getitem_1252 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1250, cat_default_12, primals_803, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1250 = cat_default_12 = primals_803 = None
        getitem_1253 = convolution_backward_default_101[0]
        getitem_1254 = convolution_backward_default_101[1]
        getitem_1255 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        slice_tensor_80 = torch.ops.aten.slice.Tensor(getitem_1253, 1, 0, 104)
        slice_tensor_81 = torch.ops.aten.slice.Tensor(getitem_1253, 1, 104, 208)
        slice_tensor_82 = torch.ops.aten.slice.Tensor(getitem_1253, 1, 208, 312)
        slice_tensor_83 = torch.ops.aten.slice.Tensor(getitem_1253, 1, 312, 416);  getitem_1253 = None
        to_dtype_303 = torch.ops.aten.to.dtype(slice_tensor_82, torch.float32);  slice_tensor_82 = None
        to_dtype_304 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_304, 0);  to_dtype_304 = None
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(to_dtype_303, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_271, to_dtype_303);  le_scalar_101 = new_zeros_default_271 = to_dtype_303 = None
        to_dtype_305 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_305, convolution_default_67, primals_801, primals_799, primals_800, getitem_256, getitem_257, True, 1e-05, [True, True, True]);  to_dtype_305 = convolution_default_67 = primals_801 = primals_799 = primals_800 = getitem_256 = getitem_257 = None
        getitem_1256 = native_batch_norm_backward_default_102[0]
        getitem_1257 = native_batch_norm_backward_default_102[1]
        getitem_1258 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1256, add_tensor_19, primals_806, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1256 = add_tensor_19 = primals_806 = None
        getitem_1259 = convolution_backward_default_102[0]
        getitem_1260 = convolution_backward_default_102[1]
        getitem_1261 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(slice_tensor_81, getitem_1259);  slice_tensor_81 = None
        to_dtype_306 = torch.ops.aten.to.dtype(add_tensor_116, torch.float32);  add_tensor_116 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_272, to_dtype_306);  le_scalar_102 = new_zeros_default_272 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_308, convolution_default_66, primals_796, primals_794, primals_795, getitem_253, getitem_254, True, 1e-05, [True, True, True]);  to_dtype_308 = convolution_default_66 = primals_796 = primals_794 = primals_795 = getitem_253 = getitem_254 = None
        getitem_1262 = native_batch_norm_backward_default_103[0]
        getitem_1263 = native_batch_norm_backward_default_103[1]
        getitem_1264 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_1262, add_tensor_18, primals_805, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1262 = add_tensor_18 = primals_805 = None
        getitem_1265 = convolution_backward_default_103[0]
        getitem_1266 = convolution_backward_default_103[1]
        getitem_1267 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(slice_tensor_80, getitem_1265);  slice_tensor_80 = None
        to_dtype_309 = torch.ops.aten.to.dtype(add_tensor_117, torch.float32);  add_tensor_117 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_273, to_dtype_309);  le_scalar_103 = new_zeros_default_273 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_65, primals_791, primals_789, primals_790, getitem_250, getitem_251, True, 1e-05, [True, True, True]);  to_dtype_311 = convolution_default_65 = primals_791 = primals_789 = primals_790 = getitem_250 = getitem_251 = None
        getitem_1268 = native_batch_norm_backward_default_104[0]
        getitem_1269 = native_batch_norm_backward_default_104[1]
        getitem_1270 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_1268, getitem_245, primals_804, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1268 = getitem_245 = primals_804 = None
        getitem_1271 = convolution_backward_default_104[0]
        getitem_1272 = convolution_backward_default_104[1]
        getitem_1273 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        cat_default_53 = torch.ops.aten.cat.default([getitem_1271, getitem_1265, getitem_1259, slice_tensor_83], 1);  getitem_1271 = getitem_1265 = getitem_1259 = slice_tensor_83 = None
        to_dtype_312 = torch.ops.aten.to.dtype(cat_default_53, torch.float32);  cat_default_53 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_274 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_274, to_dtype_312);  le_scalar_104 = new_zeros_default_274 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_314, convolution_default_64, primals_781, primals_779, primals_780, getitem_243, getitem_244, True, 1e-05, [True, True, True]);  to_dtype_314 = convolution_default_64 = primals_781 = primals_779 = primals_780 = getitem_243 = getitem_244 = None
        getitem_1274 = native_batch_norm_backward_default_105[0]
        getitem_1275 = native_batch_norm_backward_default_105[1]
        getitem_1276 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_1274, relu__default_60, primals_802, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1274 = primals_802 = None
        getitem_1277 = convolution_backward_default_105[0]
        getitem_1278 = convolution_backward_default_105[1]
        getitem_1279 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(to_dtype_302, getitem_1277);  to_dtype_302 = getitem_1277 = None
        to_dtype_315 = torch.ops.aten.to.dtype(add_tensor_118, torch.float32);  add_tensor_118 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_275 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_275, to_dtype_315);  le_scalar_105 = new_zeros_default_275 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_317, convolution_default_63, primals_756, primals_754, primals_755, getitem_240, getitem_241, True, 1e-05, [True, True, True]);  convolution_default_63 = primals_756 = primals_754 = primals_755 = getitem_240 = getitem_241 = None
        getitem_1280 = native_batch_norm_backward_default_106[0]
        getitem_1281 = native_batch_norm_backward_default_106[1]
        getitem_1282 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_1280, cat_default_11, primals_773, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1280 = cat_default_11 = primals_773 = None
        getitem_1283 = convolution_backward_default_106[0]
        getitem_1284 = convolution_backward_default_106[1]
        getitem_1285 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        slice_tensor_84 = torch.ops.aten.slice.Tensor(getitem_1283, 1, 0, 104)
        slice_tensor_85 = torch.ops.aten.slice.Tensor(getitem_1283, 1, 104, 208)
        slice_tensor_86 = torch.ops.aten.slice.Tensor(getitem_1283, 1, 208, 312)
        slice_tensor_87 = torch.ops.aten.slice.Tensor(getitem_1283, 1, 312, 416);  getitem_1283 = None
        to_dtype_318 = torch.ops.aten.to.dtype(slice_tensor_86, torch.float32);  slice_tensor_86 = None
        to_dtype_319 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_319, 0);  to_dtype_319 = None
        new_zeros_default_276 = torch.ops.aten.new_zeros.default(to_dtype_318, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_276, to_dtype_318);  le_scalar_106 = new_zeros_default_276 = to_dtype_318 = None
        to_dtype_320 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_320, convolution_default_62, primals_771, primals_769, primals_770, getitem_237, getitem_238, True, 1e-05, [True, True, True]);  to_dtype_320 = convolution_default_62 = primals_771 = primals_769 = primals_770 = getitem_237 = getitem_238 = None
        getitem_1286 = native_batch_norm_backward_default_107[0]
        getitem_1287 = native_batch_norm_backward_default_107[1]
        getitem_1288 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_1286, add_tensor_17, primals_776, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1286 = add_tensor_17 = primals_776 = None
        getitem_1289 = convolution_backward_default_107[0]
        getitem_1290 = convolution_backward_default_107[1]
        getitem_1291 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(slice_tensor_85, getitem_1289);  slice_tensor_85 = None
        to_dtype_321 = torch.ops.aten.to.dtype(add_tensor_119, torch.float32);  add_tensor_119 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_277 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_277, to_dtype_321);  le_scalar_107 = new_zeros_default_277 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_323, convolution_default_61, primals_766, primals_764, primals_765, getitem_234, getitem_235, True, 1e-05, [True, True, True]);  to_dtype_323 = convolution_default_61 = primals_766 = primals_764 = primals_765 = getitem_234 = getitem_235 = None
        getitem_1292 = native_batch_norm_backward_default_108[0]
        getitem_1293 = native_batch_norm_backward_default_108[1]
        getitem_1294 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1292, add_tensor_16, primals_775, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1292 = add_tensor_16 = primals_775 = None
        getitem_1295 = convolution_backward_default_108[0]
        getitem_1296 = convolution_backward_default_108[1]
        getitem_1297 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(slice_tensor_84, getitem_1295);  slice_tensor_84 = None
        to_dtype_324 = torch.ops.aten.to.dtype(add_tensor_120, torch.float32);  add_tensor_120 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_278 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_278, to_dtype_324);  le_scalar_108 = new_zeros_default_278 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_326, convolution_default_60, primals_761, primals_759, primals_760, getitem_231, getitem_232, True, 1e-05, [True, True, True]);  to_dtype_326 = convolution_default_60 = primals_761 = primals_759 = primals_760 = getitem_231 = getitem_232 = None
        getitem_1298 = native_batch_norm_backward_default_109[0]
        getitem_1299 = native_batch_norm_backward_default_109[1]
        getitem_1300 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1298, getitem_226, primals_774, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1298 = getitem_226 = primals_774 = None
        getitem_1301 = convolution_backward_default_109[0]
        getitem_1302 = convolution_backward_default_109[1]
        getitem_1303 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        cat_default_54 = torch.ops.aten.cat.default([getitem_1301, getitem_1295, getitem_1289, slice_tensor_87], 1);  getitem_1301 = getitem_1295 = getitem_1289 = slice_tensor_87 = None
        to_dtype_327 = torch.ops.aten.to.dtype(cat_default_54, torch.float32);  cat_default_54 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_279 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_279, to_dtype_327);  le_scalar_109 = new_zeros_default_279 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_59, primals_751, primals_749, primals_750, getitem_224, getitem_225, True, 1e-05, [True, True, True]);  to_dtype_329 = convolution_default_59 = primals_751 = primals_749 = primals_750 = getitem_224 = getitem_225 = None
        getitem_1304 = native_batch_norm_backward_default_110[0]
        getitem_1305 = native_batch_norm_backward_default_110[1]
        getitem_1306 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1304, relu__default_55, primals_772, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1304 = primals_772 = None
        getitem_1307 = convolution_backward_default_110[0]
        getitem_1308 = convolution_backward_default_110[1]
        getitem_1309 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(to_dtype_317, getitem_1307);  to_dtype_317 = getitem_1307 = None
        to_dtype_330 = torch.ops.aten.to.dtype(add_tensor_121, torch.float32);  add_tensor_121 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_280 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_280, to_dtype_330);  le_scalar_110 = new_zeros_default_280 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_332, convolution_default_58, primals_726, primals_724, primals_725, getitem_221, getitem_222, True, 1e-05, [True, True, True]);  convolution_default_58 = primals_726 = primals_724 = primals_725 = getitem_221 = getitem_222 = None
        getitem_1310 = native_batch_norm_backward_default_111[0]
        getitem_1311 = native_batch_norm_backward_default_111[1]
        getitem_1312 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1310, cat_default_10, primals_743, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1310 = cat_default_10 = primals_743 = None
        getitem_1313 = convolution_backward_default_111[0]
        getitem_1314 = convolution_backward_default_111[1]
        getitem_1315 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        slice_tensor_88 = torch.ops.aten.slice.Tensor(getitem_1313, 1, 0, 104)
        slice_tensor_89 = torch.ops.aten.slice.Tensor(getitem_1313, 1, 104, 208)
        slice_tensor_90 = torch.ops.aten.slice.Tensor(getitem_1313, 1, 208, 312)
        slice_tensor_91 = torch.ops.aten.slice.Tensor(getitem_1313, 1, 312, 416);  getitem_1313 = None
        to_dtype_333 = torch.ops.aten.to.dtype(slice_tensor_90, torch.float32);  slice_tensor_90 = None
        to_dtype_334 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_334, 0);  to_dtype_334 = None
        new_zeros_default_281 = torch.ops.aten.new_zeros.default(to_dtype_333, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_281, to_dtype_333);  le_scalar_111 = new_zeros_default_281 = to_dtype_333 = None
        to_dtype_335 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_335, convolution_default_57, primals_741, primals_739, primals_740, getitem_218, getitem_219, True, 1e-05, [True, True, True]);  to_dtype_335 = convolution_default_57 = primals_741 = primals_739 = primals_740 = getitem_218 = getitem_219 = None
        getitem_1316 = native_batch_norm_backward_default_112[0]
        getitem_1317 = native_batch_norm_backward_default_112[1]
        getitem_1318 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_1316, add_tensor_15, primals_746, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1316 = add_tensor_15 = primals_746 = None
        getitem_1319 = convolution_backward_default_112[0]
        getitem_1320 = convolution_backward_default_112[1]
        getitem_1321 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(slice_tensor_89, getitem_1319);  slice_tensor_89 = None
        to_dtype_336 = torch.ops.aten.to.dtype(add_tensor_122, torch.float32);  add_tensor_122 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_282 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_282, to_dtype_336);  le_scalar_112 = new_zeros_default_282 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_338, convolution_default_56, primals_736, primals_734, primals_735, getitem_215, getitem_216, True, 1e-05, [True, True, True]);  to_dtype_338 = convolution_default_56 = primals_736 = primals_734 = primals_735 = getitem_215 = getitem_216 = None
        getitem_1322 = native_batch_norm_backward_default_113[0]
        getitem_1323 = native_batch_norm_backward_default_113[1]
        getitem_1324 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1322, add_tensor_14, primals_745, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1322 = add_tensor_14 = primals_745 = None
        getitem_1325 = convolution_backward_default_113[0]
        getitem_1326 = convolution_backward_default_113[1]
        getitem_1327 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(slice_tensor_88, getitem_1325);  slice_tensor_88 = None
        to_dtype_339 = torch.ops.aten.to.dtype(add_tensor_123, torch.float32);  add_tensor_123 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_283 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_283, to_dtype_339);  le_scalar_113 = new_zeros_default_283 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_55, primals_731, primals_729, primals_730, getitem_212, getitem_213, True, 1e-05, [True, True, True]);  to_dtype_341 = convolution_default_55 = primals_731 = primals_729 = primals_730 = getitem_212 = getitem_213 = None
        getitem_1328 = native_batch_norm_backward_default_114[0]
        getitem_1329 = native_batch_norm_backward_default_114[1]
        getitem_1330 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1328, getitem_207, primals_744, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1328 = getitem_207 = primals_744 = None
        getitem_1331 = convolution_backward_default_114[0]
        getitem_1332 = convolution_backward_default_114[1]
        getitem_1333 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        cat_default_55 = torch.ops.aten.cat.default([getitem_1331, getitem_1325, getitem_1319, slice_tensor_91], 1);  getitem_1331 = getitem_1325 = getitem_1319 = slice_tensor_91 = None
        to_dtype_342 = torch.ops.aten.to.dtype(cat_default_55, torch.float32);  cat_default_55 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_284 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_284, to_dtype_342);  le_scalar_114 = new_zeros_default_284 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_344, convolution_default_54, primals_721, primals_719, primals_720, getitem_205, getitem_206, True, 1e-05, [True, True, True]);  to_dtype_344 = convolution_default_54 = primals_721 = primals_719 = primals_720 = getitem_205 = getitem_206 = None
        getitem_1334 = native_batch_norm_backward_default_115[0]
        getitem_1335 = native_batch_norm_backward_default_115[1]
        getitem_1336 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1334, relu__default_50, primals_742, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1334 = primals_742 = None
        getitem_1337 = convolution_backward_default_115[0]
        getitem_1338 = convolution_backward_default_115[1]
        getitem_1339 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(to_dtype_332, getitem_1337);  to_dtype_332 = getitem_1337 = None
        to_dtype_345 = torch.ops.aten.to.dtype(add_tensor_124, torch.float32);  add_tensor_124 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_285 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_285, to_dtype_345);  le_scalar_115 = new_zeros_default_285 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_347, convolution_default_53, primals_696, primals_694, primals_695, getitem_202, getitem_203, True, 1e-05, [True, True, True]);  convolution_default_53 = primals_696 = primals_694 = primals_695 = getitem_202 = getitem_203 = None
        getitem_1340 = native_batch_norm_backward_default_116[0]
        getitem_1341 = native_batch_norm_backward_default_116[1]
        getitem_1342 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1340, cat_default_9, primals_713, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1340 = cat_default_9 = primals_713 = None
        getitem_1343 = convolution_backward_default_116[0]
        getitem_1344 = convolution_backward_default_116[1]
        getitem_1345 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        slice_tensor_92 = torch.ops.aten.slice.Tensor(getitem_1343, 1, 0, 104)
        slice_tensor_93 = torch.ops.aten.slice.Tensor(getitem_1343, 1, 104, 208)
        slice_tensor_94 = torch.ops.aten.slice.Tensor(getitem_1343, 1, 208, 312)
        slice_tensor_95 = torch.ops.aten.slice.Tensor(getitem_1343, 1, 312, 416);  getitem_1343 = None
        to_dtype_348 = torch.ops.aten.to.dtype(slice_tensor_94, torch.float32);  slice_tensor_94 = None
        to_dtype_349 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_349, 0);  to_dtype_349 = None
        new_zeros_default_286 = torch.ops.aten.new_zeros.default(to_dtype_348, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_286, to_dtype_348);  le_scalar_116 = new_zeros_default_286 = to_dtype_348 = None
        to_dtype_350 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_350, convolution_default_52, primals_711, primals_709, primals_710, getitem_199, getitem_200, True, 1e-05, [True, True, True]);  to_dtype_350 = convolution_default_52 = primals_711 = primals_709 = primals_710 = getitem_199 = getitem_200 = None
        getitem_1346 = native_batch_norm_backward_default_117[0]
        getitem_1347 = native_batch_norm_backward_default_117[1]
        getitem_1348 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_1346, add_tensor_13, primals_716, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1346 = add_tensor_13 = primals_716 = None
        getitem_1349 = convolution_backward_default_117[0]
        getitem_1350 = convolution_backward_default_117[1]
        getitem_1351 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(slice_tensor_93, getitem_1349);  slice_tensor_93 = None
        to_dtype_351 = torch.ops.aten.to.dtype(add_tensor_125, torch.float32);  add_tensor_125 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_287 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_287, to_dtype_351);  le_scalar_117 = new_zeros_default_287 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_353, convolution_default_51, primals_706, primals_704, primals_705, getitem_196, getitem_197, True, 1e-05, [True, True, True]);  to_dtype_353 = convolution_default_51 = primals_706 = primals_704 = primals_705 = getitem_196 = getitem_197 = None
        getitem_1352 = native_batch_norm_backward_default_118[0]
        getitem_1353 = native_batch_norm_backward_default_118[1]
        getitem_1354 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1352, add_tensor_12, primals_715, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1352 = add_tensor_12 = primals_715 = None
        getitem_1355 = convolution_backward_default_118[0]
        getitem_1356 = convolution_backward_default_118[1]
        getitem_1357 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(slice_tensor_92, getitem_1355);  slice_tensor_92 = None
        to_dtype_354 = torch.ops.aten.to.dtype(add_tensor_126, torch.float32);  add_tensor_126 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_288 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_288, to_dtype_354);  le_scalar_118 = new_zeros_default_288 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_356, convolution_default_50, primals_701, primals_699, primals_700, getitem_193, getitem_194, True, 1e-05, [True, True, True]);  to_dtype_356 = convolution_default_50 = primals_701 = primals_699 = primals_700 = getitem_193 = getitem_194 = None
        getitem_1358 = native_batch_norm_backward_default_119[0]
        getitem_1359 = native_batch_norm_backward_default_119[1]
        getitem_1360 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1358, getitem_188, primals_714, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1358 = getitem_188 = primals_714 = None
        getitem_1361 = convolution_backward_default_119[0]
        getitem_1362 = convolution_backward_default_119[1]
        getitem_1363 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        cat_default_56 = torch.ops.aten.cat.default([getitem_1361, getitem_1355, getitem_1349, slice_tensor_95], 1);  getitem_1361 = getitem_1355 = getitem_1349 = slice_tensor_95 = None
        to_dtype_357 = torch.ops.aten.to.dtype(cat_default_56, torch.float32);  cat_default_56 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_289 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_289, to_dtype_357);  le_scalar_119 = new_zeros_default_289 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_49, primals_691, primals_689, primals_690, getitem_186, getitem_187, True, 1e-05, [True, True, True]);  to_dtype_359 = convolution_default_49 = primals_691 = primals_689 = primals_690 = getitem_186 = getitem_187 = None
        getitem_1364 = native_batch_norm_backward_default_120[0]
        getitem_1365 = native_batch_norm_backward_default_120[1]
        getitem_1366 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1364, relu__default_45, primals_712, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1364 = primals_712 = None
        getitem_1367 = convolution_backward_default_120[0]
        getitem_1368 = convolution_backward_default_120[1]
        getitem_1369 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(to_dtype_347, getitem_1367);  to_dtype_347 = getitem_1367 = None
        to_dtype_360 = torch.ops.aten.to.dtype(add_tensor_127, torch.float32);  add_tensor_127 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_290 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_290, to_dtype_360);  le_scalar_120 = new_zeros_default_290 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_362, convolution_default_48, primals_576, primals_574, primals_575, getitem_183, getitem_184, True, 1e-05, [True, True, True]);  convolution_default_48 = primals_576 = primals_574 = primals_575 = getitem_183 = getitem_184 = None
        getitem_1370 = native_batch_norm_backward_default_121[0]
        getitem_1371 = native_batch_norm_backward_default_121[1]
        getitem_1372 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1370, cat_default_8, primals_593, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1370 = cat_default_8 = primals_593 = None
        getitem_1373 = convolution_backward_default_121[0]
        getitem_1374 = convolution_backward_default_121[1]
        getitem_1375 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        slice_tensor_96 = torch.ops.aten.slice.Tensor(getitem_1373, 1, 0, 104)
        slice_tensor_97 = torch.ops.aten.slice.Tensor(getitem_1373, 1, 104, 208)
        slice_tensor_98 = torch.ops.aten.slice.Tensor(getitem_1373, 1, 208, 312)
        slice_tensor_99 = torch.ops.aten.slice.Tensor(getitem_1373, 1, 312, 416);  getitem_1373 = None
        to_dtype_363 = torch.ops.aten.to.dtype(slice_tensor_98, torch.float32);  slice_tensor_98 = None
        to_dtype_364 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_364, 0);  to_dtype_364 = None
        new_zeros_default_291 = torch.ops.aten.new_zeros.default(to_dtype_363, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_291, to_dtype_363);  le_scalar_121 = new_zeros_default_291 = to_dtype_363 = None
        to_dtype_365 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_365, convolution_default_47, primals_591, primals_589, primals_590, getitem_180, getitem_181, True, 1e-05, [True, True, True]);  to_dtype_365 = convolution_default_47 = primals_591 = primals_589 = primals_590 = getitem_180 = getitem_181 = None
        getitem_1376 = native_batch_norm_backward_default_122[0]
        getitem_1377 = native_batch_norm_backward_default_122[1]
        getitem_1378 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1376, add_tensor_11, primals_596, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1376 = add_tensor_11 = primals_596 = None
        getitem_1379 = convolution_backward_default_122[0]
        getitem_1380 = convolution_backward_default_122[1]
        getitem_1381 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(slice_tensor_97, getitem_1379);  slice_tensor_97 = None
        to_dtype_366 = torch.ops.aten.to.dtype(add_tensor_128, torch.float32);  add_tensor_128 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_292 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_292, to_dtype_366);  le_scalar_122 = new_zeros_default_292 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_368, convolution_default_46, primals_586, primals_584, primals_585, getitem_177, getitem_178, True, 1e-05, [True, True, True]);  to_dtype_368 = convolution_default_46 = primals_586 = primals_584 = primals_585 = getitem_177 = getitem_178 = None
        getitem_1382 = native_batch_norm_backward_default_123[0]
        getitem_1383 = native_batch_norm_backward_default_123[1]
        getitem_1384 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1382, add_tensor_10, primals_595, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1382 = add_tensor_10 = primals_595 = None
        getitem_1385 = convolution_backward_default_123[0]
        getitem_1386 = convolution_backward_default_123[1]
        getitem_1387 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(slice_tensor_96, getitem_1385);  slice_tensor_96 = None
        to_dtype_369 = torch.ops.aten.to.dtype(add_tensor_129, torch.float32);  add_tensor_129 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_293 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_293, to_dtype_369);  le_scalar_123 = new_zeros_default_293 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_45, primals_581, primals_579, primals_580, getitem_174, getitem_175, True, 1e-05, [True, True, True]);  to_dtype_371 = convolution_default_45 = primals_581 = primals_579 = primals_580 = getitem_174 = getitem_175 = None
        getitem_1388 = native_batch_norm_backward_default_124[0]
        getitem_1389 = native_batch_norm_backward_default_124[1]
        getitem_1390 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1388, getitem_169, primals_594, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1388 = getitem_169 = primals_594 = None
        getitem_1391 = convolution_backward_default_124[0]
        getitem_1392 = convolution_backward_default_124[1]
        getitem_1393 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        cat_default_57 = torch.ops.aten.cat.default([getitem_1391, getitem_1385, getitem_1379, slice_tensor_99], 1);  getitem_1391 = getitem_1385 = getitem_1379 = slice_tensor_99 = None
        to_dtype_372 = torch.ops.aten.to.dtype(cat_default_57, torch.float32);  cat_default_57 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_294 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_294, to_dtype_372);  le_scalar_124 = new_zeros_default_294 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_374, convolution_default_44, primals_571, primals_569, primals_570, getitem_167, getitem_168, True, 1e-05, [True, True, True]);  to_dtype_374 = convolution_default_44 = primals_571 = primals_569 = primals_570 = getitem_167 = getitem_168 = None
        getitem_1394 = native_batch_norm_backward_default_125[0]
        getitem_1395 = native_batch_norm_backward_default_125[1]
        getitem_1396 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1394, relu__default_40, primals_592, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1394 = primals_592 = None
        getitem_1397 = convolution_backward_default_125[0]
        getitem_1398 = convolution_backward_default_125[1]
        getitem_1399 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(to_dtype_362, getitem_1397);  to_dtype_362 = getitem_1397 = None
        to_dtype_375 = torch.ops.aten.to.dtype(add_tensor_130, torch.float32);  add_tensor_130 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_295 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_295, to_dtype_375);  le_scalar_125 = new_zeros_default_295 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_43, primals_266, primals_264, primals_265, getitem_164, getitem_165, True, 1e-05, [True, True, True]);  convolution_default_43 = primals_266 = primals_264 = primals_265 = getitem_164 = getitem_165 = None
        getitem_1400 = native_batch_norm_backward_default_126[0]
        getitem_1401 = native_batch_norm_backward_default_126[1]
        getitem_1402 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1400, relu__default_35, primals_261, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1400 = primals_261 = None
        getitem_1403 = convolution_backward_default_126[0]
        getitem_1404 = convolution_backward_default_126[1]
        getitem_1405 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_42, primals_240, primals_238, primals_239, getitem_161, getitem_162, True, 1e-05, [True, True, True]);  to_dtype_377 = convolution_default_42 = primals_240 = primals_238 = primals_239 = getitem_161 = getitem_162 = None
        getitem_1406 = native_batch_norm_backward_default_127[0]
        getitem_1407 = native_batch_norm_backward_default_127[1]
        getitem_1408 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1406, cat_default_7, primals_257, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1406 = cat_default_7 = primals_257 = None
        getitem_1409 = convolution_backward_default_127[0]
        getitem_1410 = convolution_backward_default_127[1]
        getitem_1411 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        slice_tensor_100 = torch.ops.aten.slice.Tensor(getitem_1409, 1, 0, 104)
        slice_tensor_101 = torch.ops.aten.slice.Tensor(getitem_1409, 1, 104, 208)
        slice_tensor_102 = torch.ops.aten.slice.Tensor(getitem_1409, 1, 208, 312)
        slice_tensor_103 = torch.ops.aten.slice.Tensor(getitem_1409, 1, 312, 416);  getitem_1409 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_103, getitem_150, [3, 3], [2, 2], [1, 1], False, True, None);  slice_tensor_103 = getitem_150 = None
        to_dtype_378 = torch.ops.aten.to.dtype(slice_tensor_102, torch.float32);  slice_tensor_102 = None
        to_dtype_379 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_379, 0);  to_dtype_379 = None
        new_zeros_default_296 = torch.ops.aten.new_zeros.default(to_dtype_378, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_296, to_dtype_378);  le_scalar_126 = new_zeros_default_296 = to_dtype_378 = None
        to_dtype_380 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_380, convolution_default_41, primals_255, primals_253, primals_254, getitem_158, getitem_159, True, 1e-05, [True, True, True]);  to_dtype_380 = convolution_default_41 = primals_255 = primals_253 = primals_254 = getitem_158 = getitem_159 = None
        getitem_1412 = native_batch_norm_backward_default_128[0]
        getitem_1413 = native_batch_norm_backward_default_128[1]
        getitem_1414 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1412, getitem_149, primals_260, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1412 = getitem_149 = primals_260 = None
        getitem_1415 = convolution_backward_default_128[0]
        getitem_1416 = convolution_backward_default_128[1]
        getitem_1417 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        to_dtype_381 = torch.ops.aten.to.dtype(slice_tensor_101, torch.float32);  slice_tensor_101 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_297 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_297, to_dtype_381);  le_scalar_127 = new_zeros_default_297 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_383, convolution_default_40, primals_250, primals_248, primals_249, getitem_155, getitem_156, True, 1e-05, [True, True, True]);  to_dtype_383 = convolution_default_40 = primals_250 = primals_248 = primals_249 = getitem_155 = getitem_156 = None
        getitem_1418 = native_batch_norm_backward_default_129[0]
        getitem_1419 = native_batch_norm_backward_default_129[1]
        getitem_1420 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1418, getitem_148, primals_259, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1418 = getitem_148 = primals_259 = None
        getitem_1421 = convolution_backward_default_129[0]
        getitem_1422 = convolution_backward_default_129[1]
        getitem_1423 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        to_dtype_384 = torch.ops.aten.to.dtype(slice_tensor_100, torch.float32);  slice_tensor_100 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_298 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_298, to_dtype_384);  le_scalar_128 = new_zeros_default_298 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_39, primals_245, primals_243, primals_244, getitem_152, getitem_153, True, 1e-05, [True, True, True]);  to_dtype_386 = convolution_default_39 = primals_245 = primals_243 = primals_244 = getitem_152 = getitem_153 = None
        getitem_1424 = native_batch_norm_backward_default_130[0]
        getitem_1425 = native_batch_norm_backward_default_130[1]
        getitem_1426 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1424, getitem_147, primals_258, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1424 = getitem_147 = primals_258 = None
        getitem_1427 = convolution_backward_default_130[0]
        getitem_1428 = convolution_backward_default_130[1]
        getitem_1429 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        cat_default_58 = torch.ops.aten.cat.default([getitem_1427, getitem_1421, getitem_1415, avg_pool2d_backward_default_1], 1);  getitem_1427 = getitem_1421 = getitem_1415 = avg_pool2d_backward_default_1 = None
        to_dtype_387 = torch.ops.aten.to.dtype(cat_default_58, torch.float32);  cat_default_58 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_299 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_299, to_dtype_387);  le_scalar_129 = new_zeros_default_299 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_38, primals_235, primals_233, primals_234, getitem_145, getitem_146, True, 1e-05, [True, True, True]);  to_dtype_389 = convolution_default_38 = primals_235 = primals_233 = primals_234 = getitem_145 = getitem_146 = None
        getitem_1430 = native_batch_norm_backward_default_131[0]
        getitem_1431 = native_batch_norm_backward_default_131[1]
        getitem_1432 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1430, relu__default_35, primals_256, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1430 = primals_256 = None
        getitem_1433 = convolution_backward_default_131[0]
        getitem_1434 = convolution_backward_default_131[1]
        getitem_1435 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(getitem_1403, getitem_1433);  getitem_1403 = getitem_1433 = None
        to_dtype_390 = torch.ops.aten.to.dtype(add_tensor_131, torch.float32);  add_tensor_131 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_300 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_300, to_dtype_390);  le_scalar_130 = new_zeros_default_300 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_392, convolution_default_37, primals_210, primals_208, primals_209, getitem_142, getitem_143, True, 1e-05, [True, True, True]);  convolution_default_37 = primals_210 = primals_208 = primals_209 = getitem_142 = getitem_143 = None
        getitem_1436 = native_batch_norm_backward_default_132[0]
        getitem_1437 = native_batch_norm_backward_default_132[1]
        getitem_1438 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(getitem_1436, cat_default_6, primals_227, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1436 = cat_default_6 = primals_227 = None
        getitem_1439 = convolution_backward_default_132[0]
        getitem_1440 = convolution_backward_default_132[1]
        getitem_1441 = convolution_backward_default_132[2];  convolution_backward_default_132 = None
        slice_tensor_104 = torch.ops.aten.slice.Tensor(getitem_1439, 1, 0, 52)
        slice_tensor_105 = torch.ops.aten.slice.Tensor(getitem_1439, 1, 52, 104)
        slice_tensor_106 = torch.ops.aten.slice.Tensor(getitem_1439, 1, 104, 156)
        slice_tensor_107 = torch.ops.aten.slice.Tensor(getitem_1439, 1, 156, 208);  getitem_1439 = None
        to_dtype_393 = torch.ops.aten.to.dtype(slice_tensor_106, torch.float32);  slice_tensor_106 = None
        to_dtype_394 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_394, 0);  to_dtype_394 = None
        new_zeros_default_301 = torch.ops.aten.new_zeros.default(to_dtype_393, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_301, to_dtype_393);  le_scalar_131 = new_zeros_default_301 = to_dtype_393 = None
        to_dtype_395 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_395, convolution_default_36, primals_225, primals_223, primals_224, getitem_139, getitem_140, True, 1e-05, [True, True, True]);  to_dtype_395 = convolution_default_36 = primals_225 = primals_223 = primals_224 = getitem_139 = getitem_140 = None
        getitem_1442 = native_batch_norm_backward_default_133[0]
        getitem_1443 = native_batch_norm_backward_default_133[1]
        getitem_1444 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1442, add_tensor_9, primals_230, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1442 = add_tensor_9 = primals_230 = None
        getitem_1445 = convolution_backward_default_133[0]
        getitem_1446 = convolution_backward_default_133[1]
        getitem_1447 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(slice_tensor_105, getitem_1445);  slice_tensor_105 = None
        to_dtype_396 = torch.ops.aten.to.dtype(add_tensor_132, torch.float32);  add_tensor_132 = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_302 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_302, to_dtype_396);  le_scalar_132 = new_zeros_default_302 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_398, convolution_default_35, primals_220, primals_218, primals_219, getitem_136, getitem_137, True, 1e-05, [True, True, True]);  to_dtype_398 = convolution_default_35 = primals_220 = primals_218 = primals_219 = getitem_136 = getitem_137 = None
        getitem_1448 = native_batch_norm_backward_default_134[0]
        getitem_1449 = native_batch_norm_backward_default_134[1]
        getitem_1450 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1448, add_tensor_8, primals_229, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1448 = add_tensor_8 = primals_229 = None
        getitem_1451 = convolution_backward_default_134[0]
        getitem_1452 = convolution_backward_default_134[1]
        getitem_1453 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(slice_tensor_104, getitem_1451);  slice_tensor_104 = None
        to_dtype_399 = torch.ops.aten.to.dtype(add_tensor_133, torch.float32);  add_tensor_133 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_133 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_303 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_133 = torch.ops.aten.where.self(le_scalar_133, new_zeros_default_303, to_dtype_399);  le_scalar_133 = new_zeros_default_303 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_133, torch.float32);  where_self_133 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_34, primals_215, primals_213, primals_214, getitem_133, getitem_134, True, 1e-05, [True, True, True]);  to_dtype_401 = convolution_default_34 = primals_215 = primals_213 = primals_214 = getitem_133 = getitem_134 = None
        getitem_1454 = native_batch_norm_backward_default_135[0]
        getitem_1455 = native_batch_norm_backward_default_135[1]
        getitem_1456 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1454, getitem_128, primals_228, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1454 = getitem_128 = primals_228 = None
        getitem_1457 = convolution_backward_default_135[0]
        getitem_1458 = convolution_backward_default_135[1]
        getitem_1459 = convolution_backward_default_135[2];  convolution_backward_default_135 = None
        cat_default_59 = torch.ops.aten.cat.default([getitem_1457, getitem_1451, getitem_1445, slice_tensor_107], 1);  getitem_1457 = getitem_1451 = getitem_1445 = slice_tensor_107 = None
        to_dtype_402 = torch.ops.aten.to.dtype(cat_default_59, torch.float32);  cat_default_59 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_134 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_304 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_134 = torch.ops.aten.where.self(le_scalar_134, new_zeros_default_304, to_dtype_402);  le_scalar_134 = new_zeros_default_304 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_134, torch.float32);  where_self_134 = None
        native_batch_norm_backward_default_136 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_404, convolution_default_33, primals_205, primals_203, primals_204, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  to_dtype_404 = convolution_default_33 = primals_205 = primals_203 = primals_204 = getitem_126 = getitem_127 = None
        getitem_1460 = native_batch_norm_backward_default_136[0]
        getitem_1461 = native_batch_norm_backward_default_136[1]
        getitem_1462 = native_batch_norm_backward_default_136[2];  native_batch_norm_backward_default_136 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1460, relu__default_30, primals_226, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1460 = primals_226 = None
        getitem_1463 = convolution_backward_default_136[0]
        getitem_1464 = convolution_backward_default_136[1]
        getitem_1465 = convolution_backward_default_136[2];  convolution_backward_default_136 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(to_dtype_392, getitem_1463);  to_dtype_392 = getitem_1463 = None
        to_dtype_405 = torch.ops.aten.to.dtype(add_tensor_134, torch.float32);  add_tensor_134 = None
        to_dtype_406 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_135 = torch.ops.aten.le.Scalar(to_dtype_406, 0);  to_dtype_406 = None
        new_zeros_default_305 = torch.ops.aten.new_zeros.default(to_dtype_405, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_135 = torch.ops.aten.where.self(le_scalar_135, new_zeros_default_305, to_dtype_405);  le_scalar_135 = new_zeros_default_305 = to_dtype_405 = None
        to_dtype_407 = torch.ops.aten.to.dtype(where_self_135, torch.float32);  where_self_135 = None
        native_batch_norm_backward_default_137 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_407, convolution_default_32, primals_180, primals_178, primals_179, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  convolution_default_32 = primals_180 = primals_178 = primals_179 = getitem_123 = getitem_124 = None
        getitem_1466 = native_batch_norm_backward_default_137[0]
        getitem_1467 = native_batch_norm_backward_default_137[1]
        getitem_1468 = native_batch_norm_backward_default_137[2];  native_batch_norm_backward_default_137 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1466, cat_default_5, primals_197, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1466 = cat_default_5 = primals_197 = None
        getitem_1469 = convolution_backward_default_137[0]
        getitem_1470 = convolution_backward_default_137[1]
        getitem_1471 = convolution_backward_default_137[2];  convolution_backward_default_137 = None
        slice_tensor_108 = torch.ops.aten.slice.Tensor(getitem_1469, 1, 0, 52)
        slice_tensor_109 = torch.ops.aten.slice.Tensor(getitem_1469, 1, 52, 104)
        slice_tensor_110 = torch.ops.aten.slice.Tensor(getitem_1469, 1, 104, 156)
        slice_tensor_111 = torch.ops.aten.slice.Tensor(getitem_1469, 1, 156, 208);  getitem_1469 = None
        to_dtype_408 = torch.ops.aten.to.dtype(slice_tensor_110, torch.float32);  slice_tensor_110 = None
        to_dtype_409 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_136 = torch.ops.aten.le.Scalar(to_dtype_409, 0);  to_dtype_409 = None
        new_zeros_default_306 = torch.ops.aten.new_zeros.default(to_dtype_408, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_136 = torch.ops.aten.where.self(le_scalar_136, new_zeros_default_306, to_dtype_408);  le_scalar_136 = new_zeros_default_306 = to_dtype_408 = None
        to_dtype_410 = torch.ops.aten.to.dtype(where_self_136, torch.float32);  where_self_136 = None
        native_batch_norm_backward_default_138 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_410, convolution_default_31, primals_195, primals_193, primals_194, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  to_dtype_410 = convolution_default_31 = primals_195 = primals_193 = primals_194 = getitem_120 = getitem_121 = None
        getitem_1472 = native_batch_norm_backward_default_138[0]
        getitem_1473 = native_batch_norm_backward_default_138[1]
        getitem_1474 = native_batch_norm_backward_default_138[2];  native_batch_norm_backward_default_138 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1472, add_tensor_7, primals_200, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1472 = add_tensor_7 = primals_200 = None
        getitem_1475 = convolution_backward_default_138[0]
        getitem_1476 = convolution_backward_default_138[1]
        getitem_1477 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(slice_tensor_109, getitem_1475);  slice_tensor_109 = None
        to_dtype_411 = torch.ops.aten.to.dtype(add_tensor_135, torch.float32);  add_tensor_135 = None
        to_dtype_412 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_137 = torch.ops.aten.le.Scalar(to_dtype_412, 0);  to_dtype_412 = None
        new_zeros_default_307 = torch.ops.aten.new_zeros.default(to_dtype_411, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_137 = torch.ops.aten.where.self(le_scalar_137, new_zeros_default_307, to_dtype_411);  le_scalar_137 = new_zeros_default_307 = to_dtype_411 = None
        to_dtype_413 = torch.ops.aten.to.dtype(where_self_137, torch.float32);  where_self_137 = None
        native_batch_norm_backward_default_139 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_413, convolution_default_30, primals_190, primals_188, primals_189, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  to_dtype_413 = convolution_default_30 = primals_190 = primals_188 = primals_189 = getitem_117 = getitem_118 = None
        getitem_1478 = native_batch_norm_backward_default_139[0]
        getitem_1479 = native_batch_norm_backward_default_139[1]
        getitem_1480 = native_batch_norm_backward_default_139[2];  native_batch_norm_backward_default_139 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1478, add_tensor_6, primals_199, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1478 = add_tensor_6 = primals_199 = None
        getitem_1481 = convolution_backward_default_139[0]
        getitem_1482 = convolution_backward_default_139[1]
        getitem_1483 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(slice_tensor_108, getitem_1481);  slice_tensor_108 = None
        to_dtype_414 = torch.ops.aten.to.dtype(add_tensor_136, torch.float32);  add_tensor_136 = None
        to_dtype_415 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_138 = torch.ops.aten.le.Scalar(to_dtype_415, 0);  to_dtype_415 = None
        new_zeros_default_308 = torch.ops.aten.new_zeros.default(to_dtype_414, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_138 = torch.ops.aten.where.self(le_scalar_138, new_zeros_default_308, to_dtype_414);  le_scalar_138 = new_zeros_default_308 = to_dtype_414 = None
        to_dtype_416 = torch.ops.aten.to.dtype(where_self_138, torch.float32);  where_self_138 = None
        native_batch_norm_backward_default_140 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_416, convolution_default_29, primals_185, primals_183, primals_184, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  to_dtype_416 = convolution_default_29 = primals_185 = primals_183 = primals_184 = getitem_114 = getitem_115 = None
        getitem_1484 = native_batch_norm_backward_default_140[0]
        getitem_1485 = native_batch_norm_backward_default_140[1]
        getitem_1486 = native_batch_norm_backward_default_140[2];  native_batch_norm_backward_default_140 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1484, getitem_109, primals_198, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1484 = getitem_109 = primals_198 = None
        getitem_1487 = convolution_backward_default_140[0]
        getitem_1488 = convolution_backward_default_140[1]
        getitem_1489 = convolution_backward_default_140[2];  convolution_backward_default_140 = None
        cat_default_60 = torch.ops.aten.cat.default([getitem_1487, getitem_1481, getitem_1475, slice_tensor_111], 1);  getitem_1487 = getitem_1481 = getitem_1475 = slice_tensor_111 = None
        to_dtype_417 = torch.ops.aten.to.dtype(cat_default_60, torch.float32);  cat_default_60 = None
        to_dtype_418 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_139 = torch.ops.aten.le.Scalar(to_dtype_418, 0);  to_dtype_418 = None
        new_zeros_default_309 = torch.ops.aten.new_zeros.default(to_dtype_417, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_139 = torch.ops.aten.where.self(le_scalar_139, new_zeros_default_309, to_dtype_417);  le_scalar_139 = new_zeros_default_309 = to_dtype_417 = None
        to_dtype_419 = torch.ops.aten.to.dtype(where_self_139, torch.float32);  where_self_139 = None
        native_batch_norm_backward_default_141 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_419, convolution_default_28, primals_175, primals_173, primals_174, getitem_107, getitem_108, True, 1e-05, [True, True, True]);  to_dtype_419 = convolution_default_28 = primals_175 = primals_173 = primals_174 = getitem_107 = getitem_108 = None
        getitem_1490 = native_batch_norm_backward_default_141[0]
        getitem_1491 = native_batch_norm_backward_default_141[1]
        getitem_1492 = native_batch_norm_backward_default_141[2];  native_batch_norm_backward_default_141 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_1490, relu__default_25, primals_196, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1490 = primals_196 = None
        getitem_1493 = convolution_backward_default_141[0]
        getitem_1494 = convolution_backward_default_141[1]
        getitem_1495 = convolution_backward_default_141[2];  convolution_backward_default_141 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(to_dtype_407, getitem_1493);  to_dtype_407 = getitem_1493 = None
        to_dtype_420 = torch.ops.aten.to.dtype(add_tensor_137, torch.float32);  add_tensor_137 = None
        to_dtype_421 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_140 = torch.ops.aten.le.Scalar(to_dtype_421, 0);  to_dtype_421 = None
        new_zeros_default_310 = torch.ops.aten.new_zeros.default(to_dtype_420, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_140 = torch.ops.aten.where.self(le_scalar_140, new_zeros_default_310, to_dtype_420);  le_scalar_140 = new_zeros_default_310 = to_dtype_420 = None
        to_dtype_422 = torch.ops.aten.to.dtype(where_self_140, torch.float32);  where_self_140 = None
        native_batch_norm_backward_default_142 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_422, convolution_default_27, primals_150, primals_148, primals_149, getitem_104, getitem_105, True, 1e-05, [True, True, True]);  convolution_default_27 = primals_150 = primals_148 = primals_149 = getitem_104 = getitem_105 = None
        getitem_1496 = native_batch_norm_backward_default_142[0]
        getitem_1497 = native_batch_norm_backward_default_142[1]
        getitem_1498 = native_batch_norm_backward_default_142[2];  native_batch_norm_backward_default_142 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_1496, cat_default_4, primals_167, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1496 = cat_default_4 = primals_167 = None
        getitem_1499 = convolution_backward_default_142[0]
        getitem_1500 = convolution_backward_default_142[1]
        getitem_1501 = convolution_backward_default_142[2];  convolution_backward_default_142 = None
        slice_tensor_112 = torch.ops.aten.slice.Tensor(getitem_1499, 1, 0, 52)
        slice_tensor_113 = torch.ops.aten.slice.Tensor(getitem_1499, 1, 52, 104)
        slice_tensor_114 = torch.ops.aten.slice.Tensor(getitem_1499, 1, 104, 156)
        slice_tensor_115 = torch.ops.aten.slice.Tensor(getitem_1499, 1, 156, 208);  getitem_1499 = None
        to_dtype_423 = torch.ops.aten.to.dtype(slice_tensor_114, torch.float32);  slice_tensor_114 = None
        to_dtype_424 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_141 = torch.ops.aten.le.Scalar(to_dtype_424, 0);  to_dtype_424 = None
        new_zeros_default_311 = torch.ops.aten.new_zeros.default(to_dtype_423, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_141 = torch.ops.aten.where.self(le_scalar_141, new_zeros_default_311, to_dtype_423);  le_scalar_141 = new_zeros_default_311 = to_dtype_423 = None
        to_dtype_425 = torch.ops.aten.to.dtype(where_self_141, torch.float32);  where_self_141 = None
        native_batch_norm_backward_default_143 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_425, convolution_default_26, primals_165, primals_163, primals_164, getitem_101, getitem_102, True, 1e-05, [True, True, True]);  to_dtype_425 = convolution_default_26 = primals_165 = primals_163 = primals_164 = getitem_101 = getitem_102 = None
        getitem_1502 = native_batch_norm_backward_default_143[0]
        getitem_1503 = native_batch_norm_backward_default_143[1]
        getitem_1504 = native_batch_norm_backward_default_143[2];  native_batch_norm_backward_default_143 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(getitem_1502, add_tensor_5, primals_170, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1502 = add_tensor_5 = primals_170 = None
        getitem_1505 = convolution_backward_default_143[0]
        getitem_1506 = convolution_backward_default_143[1]
        getitem_1507 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(slice_tensor_113, getitem_1505);  slice_tensor_113 = None
        to_dtype_426 = torch.ops.aten.to.dtype(add_tensor_138, torch.float32);  add_tensor_138 = None
        to_dtype_427 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_142 = torch.ops.aten.le.Scalar(to_dtype_427, 0);  to_dtype_427 = None
        new_zeros_default_312 = torch.ops.aten.new_zeros.default(to_dtype_426, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_142 = torch.ops.aten.where.self(le_scalar_142, new_zeros_default_312, to_dtype_426);  le_scalar_142 = new_zeros_default_312 = to_dtype_426 = None
        to_dtype_428 = torch.ops.aten.to.dtype(where_self_142, torch.float32);  where_self_142 = None
        native_batch_norm_backward_default_144 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_428, convolution_default_25, primals_160, primals_158, primals_159, getitem_98, getitem_99, True, 1e-05, [True, True, True]);  to_dtype_428 = convolution_default_25 = primals_160 = primals_158 = primals_159 = getitem_98 = getitem_99 = None
        getitem_1508 = native_batch_norm_backward_default_144[0]
        getitem_1509 = native_batch_norm_backward_default_144[1]
        getitem_1510 = native_batch_norm_backward_default_144[2];  native_batch_norm_backward_default_144 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1508, add_tensor_4, primals_169, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1508 = add_tensor_4 = primals_169 = None
        getitem_1511 = convolution_backward_default_144[0]
        getitem_1512 = convolution_backward_default_144[1]
        getitem_1513 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(slice_tensor_112, getitem_1511);  slice_tensor_112 = None
        to_dtype_429 = torch.ops.aten.to.dtype(add_tensor_139, torch.float32);  add_tensor_139 = None
        to_dtype_430 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_143 = torch.ops.aten.le.Scalar(to_dtype_430, 0);  to_dtype_430 = None
        new_zeros_default_313 = torch.ops.aten.new_zeros.default(to_dtype_429, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_143 = torch.ops.aten.where.self(le_scalar_143, new_zeros_default_313, to_dtype_429);  le_scalar_143 = new_zeros_default_313 = to_dtype_429 = None
        to_dtype_431 = torch.ops.aten.to.dtype(where_self_143, torch.float32);  where_self_143 = None
        native_batch_norm_backward_default_145 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_431, convolution_default_24, primals_155, primals_153, primals_154, getitem_95, getitem_96, True, 1e-05, [True, True, True]);  to_dtype_431 = convolution_default_24 = primals_155 = primals_153 = primals_154 = getitem_95 = getitem_96 = None
        getitem_1514 = native_batch_norm_backward_default_145[0]
        getitem_1515 = native_batch_norm_backward_default_145[1]
        getitem_1516 = native_batch_norm_backward_default_145[2];  native_batch_norm_backward_default_145 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1514, getitem_90, primals_168, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1514 = getitem_90 = primals_168 = None
        getitem_1517 = convolution_backward_default_145[0]
        getitem_1518 = convolution_backward_default_145[1]
        getitem_1519 = convolution_backward_default_145[2];  convolution_backward_default_145 = None
        cat_default_61 = torch.ops.aten.cat.default([getitem_1517, getitem_1511, getitem_1505, slice_tensor_115], 1);  getitem_1517 = getitem_1511 = getitem_1505 = slice_tensor_115 = None
        to_dtype_432 = torch.ops.aten.to.dtype(cat_default_61, torch.float32);  cat_default_61 = None
        to_dtype_433 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_144 = torch.ops.aten.le.Scalar(to_dtype_433, 0);  to_dtype_433 = None
        new_zeros_default_314 = torch.ops.aten.new_zeros.default(to_dtype_432, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_144 = torch.ops.aten.where.self(le_scalar_144, new_zeros_default_314, to_dtype_432);  le_scalar_144 = new_zeros_default_314 = to_dtype_432 = None
        to_dtype_434 = torch.ops.aten.to.dtype(where_self_144, torch.float32);  where_self_144 = None
        native_batch_norm_backward_default_146 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_434, convolution_default_23, primals_145, primals_143, primals_144, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  to_dtype_434 = convolution_default_23 = primals_145 = primals_143 = primals_144 = getitem_88 = getitem_89 = None
        getitem_1520 = native_batch_norm_backward_default_146[0]
        getitem_1521 = native_batch_norm_backward_default_146[1]
        getitem_1522 = native_batch_norm_backward_default_146[2];  native_batch_norm_backward_default_146 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1520, relu__default_20, primals_166, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1520 = primals_166 = None
        getitem_1523 = convolution_backward_default_146[0]
        getitem_1524 = convolution_backward_default_146[1]
        getitem_1525 = convolution_backward_default_146[2];  convolution_backward_default_146 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(to_dtype_422, getitem_1523);  to_dtype_422 = getitem_1523 = None
        to_dtype_435 = torch.ops.aten.to.dtype(add_tensor_140, torch.float32);  add_tensor_140 = None
        to_dtype_436 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_145 = torch.ops.aten.le.Scalar(to_dtype_436, 0);  to_dtype_436 = None
        new_zeros_default_315 = torch.ops.aten.new_zeros.default(to_dtype_435, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_145 = torch.ops.aten.where.self(le_scalar_145, new_zeros_default_315, to_dtype_435);  le_scalar_145 = new_zeros_default_315 = to_dtype_435 = None
        to_dtype_437 = torch.ops.aten.to.dtype(where_self_145, torch.float32);  where_self_145 = None
        native_batch_norm_backward_default_147 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_22, primals_140, primals_138, primals_139, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  convolution_default_22 = primals_140 = primals_138 = primals_139 = getitem_85 = getitem_86 = None
        getitem_1526 = native_batch_norm_backward_default_147[0]
        getitem_1527 = native_batch_norm_backward_default_147[1]
        getitem_1528 = native_batch_norm_backward_default_147[2];  native_batch_norm_backward_default_147 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(getitem_1526, relu__default_15, primals_135, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1526 = primals_135 = None
        getitem_1529 = convolution_backward_default_147[0]
        getitem_1530 = convolution_backward_default_147[1]
        getitem_1531 = convolution_backward_default_147[2];  convolution_backward_default_147 = None
        native_batch_norm_backward_default_148 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_21, primals_114, primals_112, primals_113, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  to_dtype_437 = convolution_default_21 = primals_114 = primals_112 = primals_113 = getitem_82 = getitem_83 = None
        getitem_1532 = native_batch_norm_backward_default_148[0]
        getitem_1533 = native_batch_norm_backward_default_148[1]
        getitem_1534 = native_batch_norm_backward_default_148[2];  native_batch_norm_backward_default_148 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1532, cat_default_3, primals_131, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1532 = cat_default_3 = primals_131 = None
        getitem_1535 = convolution_backward_default_148[0]
        getitem_1536 = convolution_backward_default_148[1]
        getitem_1537 = convolution_backward_default_148[2];  convolution_backward_default_148 = None
        slice_tensor_116 = torch.ops.aten.slice.Tensor(getitem_1535, 1, 0, 52)
        slice_tensor_117 = torch.ops.aten.slice.Tensor(getitem_1535, 1, 52, 104)
        slice_tensor_118 = torch.ops.aten.slice.Tensor(getitem_1535, 1, 104, 156)
        slice_tensor_119 = torch.ops.aten.slice.Tensor(getitem_1535, 1, 156, 208);  getitem_1535 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_119, getitem_71, [3, 3], [2, 2], [1, 1], False, True, None);  slice_tensor_119 = getitem_71 = None
        to_dtype_438 = torch.ops.aten.to.dtype(slice_tensor_118, torch.float32);  slice_tensor_118 = None
        to_dtype_439 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_146 = torch.ops.aten.le.Scalar(to_dtype_439, 0);  to_dtype_439 = None
        new_zeros_default_316 = torch.ops.aten.new_zeros.default(to_dtype_438, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_146 = torch.ops.aten.where.self(le_scalar_146, new_zeros_default_316, to_dtype_438);  le_scalar_146 = new_zeros_default_316 = to_dtype_438 = None
        to_dtype_440 = torch.ops.aten.to.dtype(where_self_146, torch.float32);  where_self_146 = None
        native_batch_norm_backward_default_149 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_440, convolution_default_20, primals_129, primals_127, primals_128, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_440 = convolution_default_20 = primals_129 = primals_127 = primals_128 = getitem_79 = getitem_80 = None
        getitem_1538 = native_batch_norm_backward_default_149[0]
        getitem_1539 = native_batch_norm_backward_default_149[1]
        getitem_1540 = native_batch_norm_backward_default_149[2];  native_batch_norm_backward_default_149 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(getitem_1538, getitem_70, primals_134, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1538 = getitem_70 = primals_134 = None
        getitem_1541 = convolution_backward_default_149[0]
        getitem_1542 = convolution_backward_default_149[1]
        getitem_1543 = convolution_backward_default_149[2];  convolution_backward_default_149 = None
        to_dtype_441 = torch.ops.aten.to.dtype(slice_tensor_117, torch.float32);  slice_tensor_117 = None
        to_dtype_442 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_147 = torch.ops.aten.le.Scalar(to_dtype_442, 0);  to_dtype_442 = None
        new_zeros_default_317 = torch.ops.aten.new_zeros.default(to_dtype_441, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_147 = torch.ops.aten.where.self(le_scalar_147, new_zeros_default_317, to_dtype_441);  le_scalar_147 = new_zeros_default_317 = to_dtype_441 = None
        to_dtype_443 = torch.ops.aten.to.dtype(where_self_147, torch.float32);  where_self_147 = None
        native_batch_norm_backward_default_150 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_443, convolution_default_19, primals_124, primals_122, primals_123, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  to_dtype_443 = convolution_default_19 = primals_124 = primals_122 = primals_123 = getitem_76 = getitem_77 = None
        getitem_1544 = native_batch_norm_backward_default_150[0]
        getitem_1545 = native_batch_norm_backward_default_150[1]
        getitem_1546 = native_batch_norm_backward_default_150[2];  native_batch_norm_backward_default_150 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1544, getitem_69, primals_133, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1544 = getitem_69 = primals_133 = None
        getitem_1547 = convolution_backward_default_150[0]
        getitem_1548 = convolution_backward_default_150[1]
        getitem_1549 = convolution_backward_default_150[2];  convolution_backward_default_150 = None
        to_dtype_444 = torch.ops.aten.to.dtype(slice_tensor_116, torch.float32);  slice_tensor_116 = None
        to_dtype_445 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_148 = torch.ops.aten.le.Scalar(to_dtype_445, 0);  to_dtype_445 = None
        new_zeros_default_318 = torch.ops.aten.new_zeros.default(to_dtype_444, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_148 = torch.ops.aten.where.self(le_scalar_148, new_zeros_default_318, to_dtype_444);  le_scalar_148 = new_zeros_default_318 = to_dtype_444 = None
        to_dtype_446 = torch.ops.aten.to.dtype(where_self_148, torch.float32);  where_self_148 = None
        native_batch_norm_backward_default_151 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_446, convolution_default_18, primals_119, primals_117, primals_118, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_446 = convolution_default_18 = primals_119 = primals_117 = primals_118 = getitem_73 = getitem_74 = None
        getitem_1550 = native_batch_norm_backward_default_151[0]
        getitem_1551 = native_batch_norm_backward_default_151[1]
        getitem_1552 = native_batch_norm_backward_default_151[2];  native_batch_norm_backward_default_151 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(getitem_1550, getitem_68, primals_132, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1550 = getitem_68 = primals_132 = None
        getitem_1553 = convolution_backward_default_151[0]
        getitem_1554 = convolution_backward_default_151[1]
        getitem_1555 = convolution_backward_default_151[2];  convolution_backward_default_151 = None
        cat_default_62 = torch.ops.aten.cat.default([getitem_1553, getitem_1547, getitem_1541, avg_pool2d_backward_default_2], 1);  getitem_1553 = getitem_1547 = getitem_1541 = avg_pool2d_backward_default_2 = None
        to_dtype_447 = torch.ops.aten.to.dtype(cat_default_62, torch.float32);  cat_default_62 = None
        to_dtype_448 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_149 = torch.ops.aten.le.Scalar(to_dtype_448, 0);  to_dtype_448 = None
        new_zeros_default_319 = torch.ops.aten.new_zeros.default(to_dtype_447, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_149 = torch.ops.aten.where.self(le_scalar_149, new_zeros_default_319, to_dtype_447);  le_scalar_149 = new_zeros_default_319 = to_dtype_447 = None
        to_dtype_449 = torch.ops.aten.to.dtype(where_self_149, torch.float32);  where_self_149 = None
        native_batch_norm_backward_default_152 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_449, convolution_default_17, primals_109, primals_107, primals_108, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_449 = convolution_default_17 = primals_109 = primals_107 = primals_108 = getitem_66 = getitem_67 = None
        getitem_1556 = native_batch_norm_backward_default_152[0]
        getitem_1557 = native_batch_norm_backward_default_152[1]
        getitem_1558 = native_batch_norm_backward_default_152[2];  native_batch_norm_backward_default_152 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(getitem_1556, relu__default_15, primals_130, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1556 = primals_130 = None
        getitem_1559 = convolution_backward_default_152[0]
        getitem_1560 = convolution_backward_default_152[1]
        getitem_1561 = convolution_backward_default_152[2];  convolution_backward_default_152 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(getitem_1529, getitem_1559);  getitem_1529 = getitem_1559 = None
        to_dtype_450 = torch.ops.aten.to.dtype(add_tensor_141, torch.float32);  add_tensor_141 = None
        to_dtype_451 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_150 = torch.ops.aten.le.Scalar(to_dtype_451, 0);  to_dtype_451 = None
        new_zeros_default_320 = torch.ops.aten.new_zeros.default(to_dtype_450, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_150 = torch.ops.aten.where.self(le_scalar_150, new_zeros_default_320, to_dtype_450);  le_scalar_150 = new_zeros_default_320 = to_dtype_450 = None
        to_dtype_452 = torch.ops.aten.to.dtype(where_self_150, torch.float32);  where_self_150 = None
        native_batch_norm_backward_default_153 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_452, convolution_default_16, primals_84, primals_82, primals_83, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  convolution_default_16 = primals_84 = primals_82 = primals_83 = getitem_63 = getitem_64 = None
        getitem_1562 = native_batch_norm_backward_default_153[0]
        getitem_1563 = native_batch_norm_backward_default_153[1]
        getitem_1564 = native_batch_norm_backward_default_153[2];  native_batch_norm_backward_default_153 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_1562, cat_default_2, primals_101, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1562 = cat_default_2 = primals_101 = None
        getitem_1565 = convolution_backward_default_153[0]
        getitem_1566 = convolution_backward_default_153[1]
        getitem_1567 = convolution_backward_default_153[2];  convolution_backward_default_153 = None
        slice_tensor_120 = torch.ops.aten.slice.Tensor(getitem_1565, 1, 0, 26)
        slice_tensor_121 = torch.ops.aten.slice.Tensor(getitem_1565, 1, 26, 52)
        slice_tensor_122 = torch.ops.aten.slice.Tensor(getitem_1565, 1, 52, 78)
        slice_tensor_123 = torch.ops.aten.slice.Tensor(getitem_1565, 1, 78, 104);  getitem_1565 = None
        to_dtype_453 = torch.ops.aten.to.dtype(slice_tensor_122, torch.float32);  slice_tensor_122 = None
        to_dtype_454 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_151 = torch.ops.aten.le.Scalar(to_dtype_454, 0);  to_dtype_454 = None
        new_zeros_default_321 = torch.ops.aten.new_zeros.default(to_dtype_453, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_151 = torch.ops.aten.where.self(le_scalar_151, new_zeros_default_321, to_dtype_453);  le_scalar_151 = new_zeros_default_321 = to_dtype_453 = None
        to_dtype_455 = torch.ops.aten.to.dtype(where_self_151, torch.float32);  where_self_151 = None
        native_batch_norm_backward_default_154 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_455, convolution_default_15, primals_99, primals_97, primals_98, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  to_dtype_455 = convolution_default_15 = primals_99 = primals_97 = primals_98 = getitem_60 = getitem_61 = None
        getitem_1568 = native_batch_norm_backward_default_154[0]
        getitem_1569 = native_batch_norm_backward_default_154[1]
        getitem_1570 = native_batch_norm_backward_default_154[2];  native_batch_norm_backward_default_154 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(getitem_1568, add_tensor_3, primals_104, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1568 = add_tensor_3 = primals_104 = None
        getitem_1571 = convolution_backward_default_154[0]
        getitem_1572 = convolution_backward_default_154[1]
        getitem_1573 = convolution_backward_default_154[2];  convolution_backward_default_154 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(slice_tensor_121, getitem_1571);  slice_tensor_121 = None
        to_dtype_456 = torch.ops.aten.to.dtype(add_tensor_142, torch.float32);  add_tensor_142 = None
        to_dtype_457 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_152 = torch.ops.aten.le.Scalar(to_dtype_457, 0);  to_dtype_457 = None
        new_zeros_default_322 = torch.ops.aten.new_zeros.default(to_dtype_456, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_152 = torch.ops.aten.where.self(le_scalar_152, new_zeros_default_322, to_dtype_456);  le_scalar_152 = new_zeros_default_322 = to_dtype_456 = None
        to_dtype_458 = torch.ops.aten.to.dtype(where_self_152, torch.float32);  where_self_152 = None
        native_batch_norm_backward_default_155 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_458, convolution_default_14, primals_94, primals_92, primals_93, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_458 = convolution_default_14 = primals_94 = primals_92 = primals_93 = getitem_57 = getitem_58 = None
        getitem_1574 = native_batch_norm_backward_default_155[0]
        getitem_1575 = native_batch_norm_backward_default_155[1]
        getitem_1576 = native_batch_norm_backward_default_155[2];  native_batch_norm_backward_default_155 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1574, add_tensor_2, primals_103, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1574 = add_tensor_2 = primals_103 = None
        getitem_1577 = convolution_backward_default_155[0]
        getitem_1578 = convolution_backward_default_155[1]
        getitem_1579 = convolution_backward_default_155[2];  convolution_backward_default_155 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(slice_tensor_120, getitem_1577);  slice_tensor_120 = None
        to_dtype_459 = torch.ops.aten.to.dtype(add_tensor_143, torch.float32);  add_tensor_143 = None
        to_dtype_460 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_153 = torch.ops.aten.le.Scalar(to_dtype_460, 0);  to_dtype_460 = None
        new_zeros_default_323 = torch.ops.aten.new_zeros.default(to_dtype_459, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_153 = torch.ops.aten.where.self(le_scalar_153, new_zeros_default_323, to_dtype_459);  le_scalar_153 = new_zeros_default_323 = to_dtype_459 = None
        to_dtype_461 = torch.ops.aten.to.dtype(where_self_153, torch.float32);  where_self_153 = None
        native_batch_norm_backward_default_156 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_461, convolution_default_13, primals_89, primals_87, primals_88, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_461 = convolution_default_13 = primals_89 = primals_87 = primals_88 = getitem_54 = getitem_55 = None
        getitem_1580 = native_batch_norm_backward_default_156[0]
        getitem_1581 = native_batch_norm_backward_default_156[1]
        getitem_1582 = native_batch_norm_backward_default_156[2];  native_batch_norm_backward_default_156 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(getitem_1580, getitem_49, primals_102, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1580 = getitem_49 = primals_102 = None
        getitem_1583 = convolution_backward_default_156[0]
        getitem_1584 = convolution_backward_default_156[1]
        getitem_1585 = convolution_backward_default_156[2];  convolution_backward_default_156 = None
        cat_default_63 = torch.ops.aten.cat.default([getitem_1583, getitem_1577, getitem_1571, slice_tensor_123], 1);  getitem_1583 = getitem_1577 = getitem_1571 = slice_tensor_123 = None
        to_dtype_462 = torch.ops.aten.to.dtype(cat_default_63, torch.float32);  cat_default_63 = None
        to_dtype_463 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_154 = torch.ops.aten.le.Scalar(to_dtype_463, 0);  to_dtype_463 = None
        new_zeros_default_324 = torch.ops.aten.new_zeros.default(to_dtype_462, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_154 = torch.ops.aten.where.self(le_scalar_154, new_zeros_default_324, to_dtype_462);  le_scalar_154 = new_zeros_default_324 = to_dtype_462 = None
        to_dtype_464 = torch.ops.aten.to.dtype(where_self_154, torch.float32);  where_self_154 = None
        native_batch_norm_backward_default_157 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_464, convolution_default_12, primals_79, primals_77, primals_78, getitem_47, getitem_48, True, 1e-05, [True, True, True]);  to_dtype_464 = convolution_default_12 = primals_79 = primals_77 = primals_78 = getitem_47 = getitem_48 = None
        getitem_1586 = native_batch_norm_backward_default_157[0]
        getitem_1587 = native_batch_norm_backward_default_157[1]
        getitem_1588 = native_batch_norm_backward_default_157[2];  native_batch_norm_backward_default_157 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(getitem_1586, relu__default_10, primals_100, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1586 = primals_100 = None
        getitem_1589 = convolution_backward_default_157[0]
        getitem_1590 = convolution_backward_default_157[1]
        getitem_1591 = convolution_backward_default_157[2];  convolution_backward_default_157 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(to_dtype_452, getitem_1589);  to_dtype_452 = getitem_1589 = None
        to_dtype_465 = torch.ops.aten.to.dtype(add_tensor_144, torch.float32);  add_tensor_144 = None
        to_dtype_466 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_155 = torch.ops.aten.le.Scalar(to_dtype_466, 0);  to_dtype_466 = None
        new_zeros_default_325 = torch.ops.aten.new_zeros.default(to_dtype_465, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_155 = torch.ops.aten.where.self(le_scalar_155, new_zeros_default_325, to_dtype_465);  le_scalar_155 = new_zeros_default_325 = to_dtype_465 = None
        to_dtype_467 = torch.ops.aten.to.dtype(where_self_155, torch.float32);  where_self_155 = None
        native_batch_norm_backward_default_158 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_467, convolution_default_11, primals_54, primals_52, primals_53, getitem_44, getitem_45, True, 1e-05, [True, True, True]);  convolution_default_11 = primals_54 = primals_52 = primals_53 = getitem_44 = getitem_45 = None
        getitem_1592 = native_batch_norm_backward_default_158[0]
        getitem_1593 = native_batch_norm_backward_default_158[1]
        getitem_1594 = native_batch_norm_backward_default_158[2];  native_batch_norm_backward_default_158 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(getitem_1592, cat_default_1, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1592 = cat_default_1 = primals_71 = None
        getitem_1595 = convolution_backward_default_158[0]
        getitem_1596 = convolution_backward_default_158[1]
        getitem_1597 = convolution_backward_default_158[2];  convolution_backward_default_158 = None
        slice_tensor_124 = torch.ops.aten.slice.Tensor(getitem_1595, 1, 0, 26)
        slice_tensor_125 = torch.ops.aten.slice.Tensor(getitem_1595, 1, 26, 52)
        slice_tensor_126 = torch.ops.aten.slice.Tensor(getitem_1595, 1, 52, 78)
        slice_tensor_127 = torch.ops.aten.slice.Tensor(getitem_1595, 1, 78, 104);  getitem_1595 = None
        to_dtype_468 = torch.ops.aten.to.dtype(slice_tensor_126, torch.float32);  slice_tensor_126 = None
        to_dtype_469 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_156 = torch.ops.aten.le.Scalar(to_dtype_469, 0);  to_dtype_469 = None
        new_zeros_default_326 = torch.ops.aten.new_zeros.default(to_dtype_468, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_156 = torch.ops.aten.where.self(le_scalar_156, new_zeros_default_326, to_dtype_468);  le_scalar_156 = new_zeros_default_326 = to_dtype_468 = None
        to_dtype_470 = torch.ops.aten.to.dtype(where_self_156, torch.float32);  where_self_156 = None
        native_batch_norm_backward_default_159 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_470, convolution_default_10, primals_69, primals_67, primals_68, getitem_41, getitem_42, True, 1e-05, [True, True, True]);  to_dtype_470 = convolution_default_10 = primals_69 = primals_67 = primals_68 = getitem_41 = getitem_42 = None
        getitem_1598 = native_batch_norm_backward_default_159[0]
        getitem_1599 = native_batch_norm_backward_default_159[1]
        getitem_1600 = native_batch_norm_backward_default_159[2];  native_batch_norm_backward_default_159 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(getitem_1598, add_tensor_1, primals_74, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1598 = add_tensor_1 = primals_74 = None
        getitem_1601 = convolution_backward_default_159[0]
        getitem_1602 = convolution_backward_default_159[1]
        getitem_1603 = convolution_backward_default_159[2];  convolution_backward_default_159 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(slice_tensor_125, getitem_1601);  slice_tensor_125 = None
        to_dtype_471 = torch.ops.aten.to.dtype(add_tensor_145, torch.float32);  add_tensor_145 = None
        to_dtype_472 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_157 = torch.ops.aten.le.Scalar(to_dtype_472, 0);  to_dtype_472 = None
        new_zeros_default_327 = torch.ops.aten.new_zeros.default(to_dtype_471, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_157 = torch.ops.aten.where.self(le_scalar_157, new_zeros_default_327, to_dtype_471);  le_scalar_157 = new_zeros_default_327 = to_dtype_471 = None
        to_dtype_473 = torch.ops.aten.to.dtype(where_self_157, torch.float32);  where_self_157 = None
        native_batch_norm_backward_default_160 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_473, convolution_default_9, primals_64, primals_62, primals_63, getitem_38, getitem_39, True, 1e-05, [True, True, True]);  to_dtype_473 = convolution_default_9 = primals_64 = primals_62 = primals_63 = getitem_38 = getitem_39 = None
        getitem_1604 = native_batch_norm_backward_default_160[0]
        getitem_1605 = native_batch_norm_backward_default_160[1]
        getitem_1606 = native_batch_norm_backward_default_160[2];  native_batch_norm_backward_default_160 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1604, add_tensor, primals_73, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1604 = add_tensor = primals_73 = None
        getitem_1607 = convolution_backward_default_160[0]
        getitem_1608 = convolution_backward_default_160[1]
        getitem_1609 = convolution_backward_default_160[2];  convolution_backward_default_160 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(slice_tensor_124, getitem_1607);  slice_tensor_124 = None
        to_dtype_474 = torch.ops.aten.to.dtype(add_tensor_146, torch.float32);  add_tensor_146 = None
        to_dtype_475 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_158 = torch.ops.aten.le.Scalar(to_dtype_475, 0);  to_dtype_475 = None
        new_zeros_default_328 = torch.ops.aten.new_zeros.default(to_dtype_474, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_158 = torch.ops.aten.where.self(le_scalar_158, new_zeros_default_328, to_dtype_474);  le_scalar_158 = new_zeros_default_328 = to_dtype_474 = None
        to_dtype_476 = torch.ops.aten.to.dtype(where_self_158, torch.float32);  where_self_158 = None
        native_batch_norm_backward_default_161 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_476, convolution_default_8, primals_59, primals_57, primals_58, getitem_35, getitem_36, True, 1e-05, [True, True, True]);  to_dtype_476 = convolution_default_8 = primals_59 = primals_57 = primals_58 = getitem_35 = getitem_36 = None
        getitem_1610 = native_batch_norm_backward_default_161[0]
        getitem_1611 = native_batch_norm_backward_default_161[1]
        getitem_1612 = native_batch_norm_backward_default_161[2];  native_batch_norm_backward_default_161 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(getitem_1610, getitem_30, primals_72, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1610 = getitem_30 = primals_72 = None
        getitem_1613 = convolution_backward_default_161[0]
        getitem_1614 = convolution_backward_default_161[1]
        getitem_1615 = convolution_backward_default_161[2];  convolution_backward_default_161 = None
        cat_default_64 = torch.ops.aten.cat.default([getitem_1613, getitem_1607, getitem_1601, slice_tensor_127], 1);  getitem_1613 = getitem_1607 = getitem_1601 = slice_tensor_127 = None
        to_dtype_477 = torch.ops.aten.to.dtype(cat_default_64, torch.float32);  cat_default_64 = None
        to_dtype_478 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_159 = torch.ops.aten.le.Scalar(to_dtype_478, 0);  to_dtype_478 = None
        new_zeros_default_329 = torch.ops.aten.new_zeros.default(to_dtype_477, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_159 = torch.ops.aten.where.self(le_scalar_159, new_zeros_default_329, to_dtype_477);  le_scalar_159 = new_zeros_default_329 = to_dtype_477 = None
        to_dtype_479 = torch.ops.aten.to.dtype(where_self_159, torch.float32);  where_self_159 = None
        native_batch_norm_backward_default_162 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_479, convolution_default_7, primals_49, primals_47, primals_48, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_479 = convolution_default_7 = primals_49 = primals_47 = primals_48 = getitem_28 = getitem_29 = None
        getitem_1616 = native_batch_norm_backward_default_162[0]
        getitem_1617 = native_batch_norm_backward_default_162[1]
        getitem_1618 = native_batch_norm_backward_default_162[2];  native_batch_norm_backward_default_162 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(getitem_1616, relu__default_5, primals_70, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1616 = primals_70 = None
        getitem_1619 = convolution_backward_default_162[0]
        getitem_1620 = convolution_backward_default_162[1]
        getitem_1621 = convolution_backward_default_162[2];  convolution_backward_default_162 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(to_dtype_467, getitem_1619);  to_dtype_467 = getitem_1619 = None
        to_dtype_480 = torch.ops.aten.to.dtype(add_tensor_147, torch.float32);  add_tensor_147 = None
        to_dtype_481 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_160 = torch.ops.aten.le.Scalar(to_dtype_481, 0);  to_dtype_481 = None
        new_zeros_default_330 = torch.ops.aten.new_zeros.default(to_dtype_480, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_160 = torch.ops.aten.where.self(le_scalar_160, new_zeros_default_330, to_dtype_480);  le_scalar_160 = new_zeros_default_330 = to_dtype_480 = None
        to_dtype_482 = torch.ops.aten.to.dtype(where_self_160, torch.float32);  where_self_160 = None
        native_batch_norm_backward_default_163 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_482, convolution_default_6, primals_44, primals_42, primals_43, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  convolution_default_6 = primals_44 = primals_42 = primals_43 = getitem_25 = getitem_26 = None
        getitem_1622 = native_batch_norm_backward_default_163[0]
        getitem_1623 = native_batch_norm_backward_default_163[1]
        getitem_1624 = native_batch_norm_backward_default_163[2];  native_batch_norm_backward_default_163 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(getitem_1622, getitem_3, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1622 = primals_39 = None
        getitem_1625 = convolution_backward_default_163[0]
        getitem_1626 = convolution_backward_default_163[1]
        getitem_1627 = convolution_backward_default_163[2];  convolution_backward_default_163 = None
        native_batch_norm_backward_default_164 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_482, convolution_default_5, primals_18, primals_16, primals_17, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_482 = convolution_default_5 = primals_18 = primals_16 = primals_17 = getitem_22 = getitem_23 = None
        getitem_1628 = native_batch_norm_backward_default_164[0]
        getitem_1629 = native_batch_norm_backward_default_164[1]
        getitem_1630 = native_batch_norm_backward_default_164[2];  native_batch_norm_backward_default_164 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(getitem_1628, cat_default, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1628 = cat_default = primals_35 = None
        getitem_1631 = convolution_backward_default_164[0]
        getitem_1632 = convolution_backward_default_164[1]
        getitem_1633 = convolution_backward_default_164[2];  convolution_backward_default_164 = None
        slice_tensor_128 = torch.ops.aten.slice.Tensor(getitem_1631, 1, 0, 26)
        slice_tensor_129 = torch.ops.aten.slice.Tensor(getitem_1631, 1, 26, 52)
        slice_tensor_130 = torch.ops.aten.slice.Tensor(getitem_1631, 1, 52, 78)
        slice_tensor_131 = torch.ops.aten.slice.Tensor(getitem_1631, 1, 78, 104);  getitem_1631 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_131, getitem_11, [3, 3], [1, 1], [1, 1], False, True, None);  slice_tensor_131 = getitem_11 = None
        to_dtype_483 = torch.ops.aten.to.dtype(slice_tensor_130, torch.float32);  slice_tensor_130 = None
        to_dtype_484 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_161 = torch.ops.aten.le.Scalar(to_dtype_484, 0);  to_dtype_484 = None
        new_zeros_default_331 = torch.ops.aten.new_zeros.default(to_dtype_483, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_161 = torch.ops.aten.where.self(le_scalar_161, new_zeros_default_331, to_dtype_483);  le_scalar_161 = new_zeros_default_331 = to_dtype_483 = None
        to_dtype_485 = torch.ops.aten.to.dtype(where_self_161, torch.float32);  where_self_161 = None
        native_batch_norm_backward_default_165 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_485, convolution_default_4, primals_33, primals_31, primals_32, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_485 = convolution_default_4 = primals_33 = primals_31 = primals_32 = getitem_19 = getitem_20 = None
        getitem_1634 = native_batch_norm_backward_default_165[0]
        getitem_1635 = native_batch_norm_backward_default_165[1]
        getitem_1636 = native_batch_norm_backward_default_165[2];  native_batch_norm_backward_default_165 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(getitem_1634, getitem_10, primals_38, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1634 = getitem_10 = primals_38 = None
        getitem_1637 = convolution_backward_default_165[0]
        getitem_1638 = convolution_backward_default_165[1]
        getitem_1639 = convolution_backward_default_165[2];  convolution_backward_default_165 = None
        to_dtype_486 = torch.ops.aten.to.dtype(slice_tensor_129, torch.float32);  slice_tensor_129 = None
        to_dtype_487 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_162 = torch.ops.aten.le.Scalar(to_dtype_487, 0);  to_dtype_487 = None
        new_zeros_default_332 = torch.ops.aten.new_zeros.default(to_dtype_486, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_162 = torch.ops.aten.where.self(le_scalar_162, new_zeros_default_332, to_dtype_486);  le_scalar_162 = new_zeros_default_332 = to_dtype_486 = None
        to_dtype_488 = torch.ops.aten.to.dtype(where_self_162, torch.float32);  where_self_162 = None
        native_batch_norm_backward_default_166 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_488, convolution_default_3, primals_28, primals_26, primals_27, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  to_dtype_488 = convolution_default_3 = primals_28 = primals_26 = primals_27 = getitem_16 = getitem_17 = None
        getitem_1640 = native_batch_norm_backward_default_166[0]
        getitem_1641 = native_batch_norm_backward_default_166[1]
        getitem_1642 = native_batch_norm_backward_default_166[2];  native_batch_norm_backward_default_166 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(getitem_1640, getitem_9, primals_37, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1640 = getitem_9 = primals_37 = None
        getitem_1643 = convolution_backward_default_166[0]
        getitem_1644 = convolution_backward_default_166[1]
        getitem_1645 = convolution_backward_default_166[2];  convolution_backward_default_166 = None
        to_dtype_489 = torch.ops.aten.to.dtype(slice_tensor_128, torch.float32);  slice_tensor_128 = None
        to_dtype_490 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_163 = torch.ops.aten.le.Scalar(to_dtype_490, 0);  to_dtype_490 = None
        new_zeros_default_333 = torch.ops.aten.new_zeros.default(to_dtype_489, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_163 = torch.ops.aten.where.self(le_scalar_163, new_zeros_default_333, to_dtype_489);  le_scalar_163 = new_zeros_default_333 = to_dtype_489 = None
        to_dtype_491 = torch.ops.aten.to.dtype(where_self_163, torch.float32);  where_self_163 = None
        native_batch_norm_backward_default_167 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_491, convolution_default_2, primals_23, primals_21, primals_22, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_491 = convolution_default_2 = primals_23 = primals_21 = primals_22 = getitem_13 = getitem_14 = None
        getitem_1646 = native_batch_norm_backward_default_167[0]
        getitem_1647 = native_batch_norm_backward_default_167[1]
        getitem_1648 = native_batch_norm_backward_default_167[2];  native_batch_norm_backward_default_167 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(getitem_1646, getitem_8, primals_36, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1646 = getitem_8 = primals_36 = None
        getitem_1649 = convolution_backward_default_167[0]
        getitem_1650 = convolution_backward_default_167[1]
        getitem_1651 = convolution_backward_default_167[2];  convolution_backward_default_167 = None
        cat_default_65 = torch.ops.aten.cat.default([getitem_1649, getitem_1643, getitem_1637, avg_pool2d_backward_default_3], 1);  getitem_1649 = getitem_1643 = getitem_1637 = avg_pool2d_backward_default_3 = None
        to_dtype_492 = torch.ops.aten.to.dtype(cat_default_65, torch.float32);  cat_default_65 = None
        to_dtype_493 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_164 = torch.ops.aten.le.Scalar(to_dtype_493, 0);  to_dtype_493 = None
        new_zeros_default_334 = torch.ops.aten.new_zeros.default(to_dtype_492, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_164 = torch.ops.aten.where.self(le_scalar_164, new_zeros_default_334, to_dtype_492);  le_scalar_164 = new_zeros_default_334 = to_dtype_492 = None
        to_dtype_494 = torch.ops.aten.to.dtype(where_self_164, torch.float32);  where_self_164 = None
        native_batch_norm_backward_default_168 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_494, convolution_default_1, primals_13, primals_11, primals_12, getitem_6, getitem_7, True, 1e-05, [True, True, True]);  to_dtype_494 = convolution_default_1 = primals_13 = primals_11 = primals_12 = getitem_6 = getitem_7 = None
        getitem_1652 = native_batch_norm_backward_default_168[0]
        getitem_1653 = native_batch_norm_backward_default_168[1]
        getitem_1654 = native_batch_norm_backward_default_168[2];  native_batch_norm_backward_default_168 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1652, getitem_3, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1652 = getitem_3 = primals_34 = None
        getitem_1655 = convolution_backward_default_168[0]
        getitem_1656 = convolution_backward_default_168[1]
        getitem_1657 = convolution_backward_default_168[2];  convolution_backward_default_168 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(getitem_1625, getitem_1655);  getitem_1625 = getitem_1655 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_148, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  add_tensor_148 = getitem_4 = None
        to_dtype_495 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_496 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_165 = torch.ops.aten.le.Scalar(to_dtype_496, 0);  to_dtype_496 = None
        new_zeros_default_335 = torch.ops.aten.new_zeros.default(to_dtype_495, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_165 = torch.ops.aten.where.self(le_scalar_165, new_zeros_default_335, to_dtype_495);  le_scalar_165 = new_zeros_default_335 = to_dtype_495 = None
        to_dtype_497 = torch.ops.aten.to.dtype(where_self_165, torch.float32);  where_self_165 = None
        native_batch_norm_backward_default_169 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_497, convolution_default, primals_5, primals_3, primals_4, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_497 = convolution_default = primals_5 = primals_3 = primals_4 = getitem_1 = getitem_2 = None
        getitem_1658 = native_batch_norm_backward_default_169[0]
        getitem_1659 = native_batch_norm_backward_default_169[1]
        getitem_1660 = native_batch_norm_backward_default_169[2];  native_batch_norm_backward_default_169 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1658, primals_1023, primals_6, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1658 = primals_1023 = primals_6 = None
        getitem_1661 = convolution_backward_default_169[0]
        getitem_1662 = convolution_backward_default_169[1]
        getitem_1663 = convolution_backward_default_169[2];  convolution_backward_default_169 = None
        return [addmm_default, getitem_1660, None, None, None, getitem_1659, getitem_1662, view_default_1, t_default_4, getitem_1654, None, None, None, getitem_1653, getitem_1630, None, None, None, getitem_1629, getitem_1648, None, None, None, getitem_1647, getitem_1642, None, None, None, getitem_1641, getitem_1636, None, None, None, getitem_1635, getitem_1656, getitem_1632, getitem_1650, getitem_1644, getitem_1638, getitem_1626, getitem_1624, None, None, None, getitem_1623, getitem_1618, None, None, None, getitem_1617, getitem_1594, None, None, None, getitem_1593, getitem_1612, None, None, None, getitem_1611, getitem_1606, None, None, None, getitem_1605, getitem_1600, None, None, None, getitem_1599, getitem_1620, getitem_1596, getitem_1614, getitem_1608, getitem_1602, getitem_1588, None, None, None, getitem_1587, getitem_1564, None, None, None, getitem_1563, getitem_1582, None, None, None, getitem_1581, getitem_1576, None, None, None, getitem_1575, getitem_1570, None, None, None, getitem_1569, getitem_1590, getitem_1566, getitem_1584, getitem_1578, getitem_1572, getitem_1558, None, None, None, getitem_1557, getitem_1534, None, None, None, getitem_1533, getitem_1552, None, None, None, getitem_1551, getitem_1546, None, None, None, getitem_1545, getitem_1540, None, None, None, getitem_1539, getitem_1560, getitem_1536, getitem_1554, getitem_1548, getitem_1542, getitem_1530, getitem_1528, None, None, None, getitem_1527, getitem_1522, None, None, None, getitem_1521, getitem_1498, None, None, None, getitem_1497, getitem_1516, None, None, None, getitem_1515, getitem_1510, None, None, None, getitem_1509, getitem_1504, None, None, None, getitem_1503, getitem_1524, getitem_1500, getitem_1518, getitem_1512, getitem_1506, getitem_1492, None, None, None, getitem_1491, getitem_1468, None, None, None, getitem_1467, getitem_1486, None, None, None, getitem_1485, getitem_1480, None, None, None, getitem_1479, getitem_1474, None, None, None, getitem_1473, getitem_1494, getitem_1470, getitem_1488, getitem_1482, getitem_1476, getitem_1462, None, None, None, getitem_1461, getitem_1438, None, None, None, getitem_1437, getitem_1456, None, None, None, getitem_1455, getitem_1450, None, None, None, getitem_1449, getitem_1444, None, None, None, getitem_1443, getitem_1464, getitem_1440, getitem_1458, getitem_1452, getitem_1446, getitem_1432, None, None, None, getitem_1431, getitem_1408, None, None, None, getitem_1407, getitem_1426, None, None, None, getitem_1425, getitem_1420, None, None, None, getitem_1419, getitem_1414, None, None, None, getitem_1413, getitem_1434, getitem_1410, getitem_1428, getitem_1422, getitem_1416, getitem_1404, getitem_1402, None, None, None, getitem_1401, getitem_1126, None, None, None, getitem_1125, getitem_1102, None, None, None, getitem_1101, getitem_1120, None, None, None, getitem_1119, getitem_1114, None, None, None, getitem_1113, getitem_1108, None, None, None, getitem_1107, getitem_1128, getitem_1104, getitem_1122, getitem_1116, getitem_1110, getitem_1096, None, None, None, getitem_1095, getitem_1072, None, None, None, getitem_1071, getitem_1090, None, None, None, getitem_1089, getitem_1084, None, None, None, getitem_1083, getitem_1078, None, None, None, getitem_1077, getitem_1098, getitem_1074, getitem_1092, getitem_1086, getitem_1080, getitem_1066, None, None, None, getitem_1065, getitem_1042, None, None, None, getitem_1041, getitem_1060, None, None, None, getitem_1059, getitem_1054, None, None, None, getitem_1053, getitem_1048, None, None, None, getitem_1047, getitem_1068, getitem_1044, getitem_1062, getitem_1056, getitem_1050, getitem_1036, None, None, None, getitem_1035, getitem_1012, None, None, None, getitem_1011, getitem_1030, None, None, None, getitem_1029, getitem_1024, None, None, None, getitem_1023, getitem_1018, None, None, None, getitem_1017, getitem_1038, getitem_1014, getitem_1032, getitem_1026, getitem_1020, getitem_1006, None, None, None, getitem_1005, getitem_982, None, None, None, getitem_981, getitem_1000, None, None, None, getitem_999, getitem_994, None, None, None, getitem_993, getitem_988, None, None, None, getitem_987, getitem_1008, getitem_984, getitem_1002, getitem_996, getitem_990, getitem_976, None, None, None, getitem_975, getitem_952, None, None, None, getitem_951, getitem_970, None, None, None, getitem_969, getitem_964, None, None, None, getitem_963, getitem_958, None, None, None, getitem_957, getitem_978, getitem_954, getitem_972, getitem_966, getitem_960, getitem_946, None, None, None, getitem_945, getitem_922, None, None, None, getitem_921, getitem_940, None, None, None, getitem_939, getitem_934, None, None, None, getitem_933, getitem_928, None, None, None, getitem_927, getitem_948, getitem_924, getitem_942, getitem_936, getitem_930, getitem_916, None, None, None, getitem_915, getitem_892, None, None, None, getitem_891, getitem_910, None, None, None, getitem_909, getitem_904, None, None, None, getitem_903, getitem_898, None, None, None, getitem_897, getitem_918, getitem_894, getitem_912, getitem_906, getitem_900, getitem_886, None, None, None, getitem_885, getitem_862, None, None, None, getitem_861, getitem_880, None, None, None, getitem_879, getitem_874, None, None, None, getitem_873, getitem_868, None, None, None, getitem_867, getitem_888, getitem_864, getitem_882, getitem_876, getitem_870, getitem_856, None, None, None, getitem_855, getitem_832, None, None, None, getitem_831, getitem_850, None, None, None, getitem_849, getitem_844, None, None, None, getitem_843, getitem_838, None, None, None, getitem_837, getitem_858, getitem_834, getitem_852, getitem_846, getitem_840, getitem_1396, None, None, None, getitem_1395, getitem_1372, None, None, None, getitem_1371, getitem_1390, None, None, None, getitem_1389, getitem_1384, None, None, None, getitem_1383, getitem_1378, None, None, None, getitem_1377, getitem_1398, getitem_1374, getitem_1392, getitem_1386, getitem_1380, getitem_826, None, None, None, getitem_825, getitem_802, None, None, None, getitem_801, getitem_820, None, None, None, getitem_819, getitem_814, None, None, None, getitem_813, getitem_808, None, None, None, getitem_807, getitem_828, getitem_804, getitem_822, getitem_816, getitem_810, getitem_796, None, None, None, getitem_795, getitem_772, None, None, None, getitem_771, getitem_790, None, None, None, getitem_789, getitem_784, None, None, None, getitem_783, getitem_778, None, None, None, getitem_777, getitem_798, getitem_774, getitem_792, getitem_786, getitem_780, getitem_766, None, None, None, getitem_765, getitem_742, None, None, None, getitem_741, getitem_760, None, None, None, getitem_759, getitem_754, None, None, None, getitem_753, getitem_748, None, None, None, getitem_747, getitem_768, getitem_744, getitem_762, getitem_756, getitem_750, getitem_1366, None, None, None, getitem_1365, getitem_1342, None, None, None, getitem_1341, getitem_1360, None, None, None, getitem_1359, getitem_1354, None, None, None, getitem_1353, getitem_1348, None, None, None, getitem_1347, getitem_1368, getitem_1344, getitem_1362, getitem_1356, getitem_1350, getitem_1336, None, None, None, getitem_1335, getitem_1312, None, None, None, getitem_1311, getitem_1330, None, None, None, getitem_1329, getitem_1324, None, None, None, getitem_1323, getitem_1318, None, None, None, getitem_1317, getitem_1338, getitem_1314, getitem_1332, getitem_1326, getitem_1320, getitem_1306, None, None, None, getitem_1305, getitem_1282, None, None, None, getitem_1281, getitem_1300, None, None, None, getitem_1299, getitem_1294, None, None, None, getitem_1293, getitem_1288, None, None, None, getitem_1287, getitem_1308, getitem_1284, getitem_1302, getitem_1296, getitem_1290, getitem_1276, None, None, None, getitem_1275, getitem_1252, None, None, None, getitem_1251, getitem_1270, None, None, None, getitem_1269, getitem_1264, None, None, None, getitem_1263, getitem_1258, None, None, None, getitem_1257, getitem_1278, getitem_1254, getitem_1272, getitem_1266, getitem_1260, getitem_1246, None, None, None, getitem_1245, getitem_1222, None, None, None, getitem_1221, getitem_1240, None, None, None, getitem_1239, getitem_1234, None, None, None, getitem_1233, getitem_1228, None, None, None, getitem_1227, getitem_1248, getitem_1224, getitem_1242, getitem_1236, getitem_1230, getitem_1216, None, None, None, getitem_1215, getitem_1192, None, None, None, getitem_1191, getitem_1210, None, None, None, getitem_1209, getitem_1204, None, None, None, getitem_1203, getitem_1198, None, None, None, getitem_1197, getitem_1218, getitem_1194, getitem_1212, getitem_1206, getitem_1200, getitem_1186, None, None, None, getitem_1185, getitem_1162, None, None, None, getitem_1161, getitem_1180, None, None, None, getitem_1179, getitem_1174, None, None, None, getitem_1173, getitem_1168, None, None, None, getitem_1167, getitem_1188, getitem_1164, getitem_1182, getitem_1176, getitem_1170, getitem_1156, None, None, None, getitem_1155, getitem_1132, None, None, None, getitem_1131, getitem_1150, None, None, None, getitem_1149, getitem_1144, None, None, None, getitem_1143, getitem_1138, None, None, None, getitem_1137, getitem_1158, getitem_1134, getitem_1152, getitem_1146, getitem_1140, getitem_736, None, None, None, getitem_735, getitem_712, None, None, None, getitem_711, getitem_730, None, None, None, getitem_729, getitem_724, None, None, None, getitem_723, getitem_718, None, None, None, getitem_717, getitem_738, getitem_714, getitem_732, getitem_726, getitem_720, getitem_708, getitem_706, None, None, None, getitem_705, getitem_700, None, None, None, getitem_699, getitem_676, None, None, None, getitem_675, getitem_694, None, None, None, getitem_693, getitem_688, None, None, None, getitem_687, getitem_682, None, None, None, getitem_681, getitem_702, getitem_678, getitem_696, getitem_690, getitem_684, getitem_670, None, None, None, getitem_669, getitem_646, None, None, None, getitem_645, getitem_664, None, None, None, getitem_663, getitem_658, None, None, None, getitem_657, getitem_652, None, None, None, getitem_651, getitem_672, getitem_648, getitem_666, getitem_660, getitem_654, None]
        
