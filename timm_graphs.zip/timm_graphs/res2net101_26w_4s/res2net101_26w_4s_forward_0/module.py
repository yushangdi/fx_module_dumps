
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/res2net101_26w_4s/res2net101_26w_4s_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023):
        convolution_default = torch.ops.aten.convolution.default(primals_1023, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, True, 0.1, 1e-05);  primals_9 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        split_tensor = torch.ops.aten.split.Tensor(relu__default_1, 26, 1)
        getitem_8 = split_tensor[0]
        getitem_9 = split_tensor[1]
        getitem_10 = split_tensor[2]
        getitem_11 = split_tensor[3];  split_tensor = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_8, primals_36, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_23, primals_19, primals_21, primals_22, True, 0.1, 1e-05);  primals_19 = None
        getitem_12 = native_batch_norm_default_2[0]
        getitem_13 = native_batch_norm_default_2[1]
        getitem_14 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_28, primals_24, primals_26, primals_27, True, 0.1, 1e-05);  primals_24 = None
        getitem_15 = native_batch_norm_default_3[0]
        getitem_16 = native_batch_norm_default_3[1]
        getitem_17 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_10, primals_38, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_33, primals_29, primals_31, primals_32, True, 0.1, 1e-05);  primals_29 = None
        getitem_18 = native_batch_norm_default_4[0]
        getitem_19 = native_batch_norm_default_4[1]
        getitem_20 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(getitem_11, [3, 3], [1, 1], [1, 1])
        cat_default = torch.ops.aten.cat.default([relu__default_2, relu__default_3, relu__default_4, avg_pool2d_default], 1);  avg_pool2d_default = None
        convolution_default_5 = torch.ops.aten.convolution.default(cat_default, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_18, primals_14, primals_16, primals_17, True, 0.1, 1e-05);  primals_14 = None
        getitem_21 = native_batch_norm_default_5[0]
        getitem_22 = native_batch_norm_default_5[1]
        getitem_23 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_3, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_24 = native_batch_norm_default_6[0]
        getitem_25 = native_batch_norm_default_6[1]
        getitem_26 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_21, getitem_24);  getitem_21 = getitem_24 = None
        relu__default_5 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_49, primals_45, primals_47, primals_48, True, 0.1, 1e-05);  primals_45 = None
        getitem_27 = native_batch_norm_default_7[0]
        getitem_28 = native_batch_norm_default_7[1]
        getitem_29 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        split_tensor_1 = torch.ops.aten.split.Tensor(relu__default_6, 26, 1)
        getitem_30 = split_tensor_1[0]
        getitem_31 = split_tensor_1[1]
        getitem_32 = split_tensor_1[2]
        getitem_33 = split_tensor_1[3];  split_tensor_1 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_30, primals_72, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_59, primals_55, primals_57, primals_58, True, 0.1, 1e-05);  primals_55 = None
        getitem_34 = native_batch_norm_default_8[0]
        getitem_35 = native_batch_norm_default_8[1]
        getitem_36 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_34);  getitem_34 = None
        add_tensor = torch.ops.aten.add.Tensor(relu__default_7, getitem_31);  getitem_31 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor, primals_73, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_64, primals_60, primals_62, primals_63, True, 0.1, 1e-05);  primals_60 = None
        getitem_37 = native_batch_norm_default_9[0]
        getitem_38 = native_batch_norm_default_9[1]
        getitem_39 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_37);  getitem_37 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(relu__default_8, getitem_32);  getitem_32 = None
        convolution_default_10 = torch.ops.aten.convolution.default(add_tensor_1, primals_74, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_69, primals_65, primals_67, primals_68, True, 0.1, 1e-05);  primals_65 = None
        getitem_40 = native_batch_norm_default_10[0]
        getitem_41 = native_batch_norm_default_10[1]
        getitem_42 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_40);  getitem_40 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_7, relu__default_8, relu__default_9, getitem_33], 1);  getitem_33 = None
        convolution_default_11 = torch.ops.aten.convolution.default(cat_default_1, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_54, primals_50, primals_52, primals_53, True, 0.1, 1e-05);  primals_50 = None
        getitem_43 = native_batch_norm_default_11[0]
        getitem_44 = native_batch_norm_default_11[1]
        getitem_45 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        add__tensor_13 = torch.ops.aten.add_.Tensor(getitem_43, relu__default_5);  getitem_43 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_13);  add__tensor_13 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_10, primals_100, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_79, primals_75, primals_77, primals_78, True, 0.1, 1e-05);  primals_75 = None
        getitem_46 = native_batch_norm_default_12[0]
        getitem_47 = native_batch_norm_default_12[1]
        getitem_48 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_46);  getitem_46 = None
        split_tensor_2 = torch.ops.aten.split.Tensor(relu__default_11, 26, 1)
        getitem_49 = split_tensor_2[0]
        getitem_50 = split_tensor_2[1]
        getitem_51 = split_tensor_2[2]
        getitem_52 = split_tensor_2[3];  split_tensor_2 = None
        convolution_default_13 = torch.ops.aten.convolution.default(getitem_49, primals_102, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_89, primals_85, primals_87, primals_88, True, 0.1, 1e-05);  primals_85 = None
        getitem_53 = native_batch_norm_default_13[0]
        getitem_54 = native_batch_norm_default_13[1]
        getitem_55 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(relu__default_12, getitem_50);  getitem_50 = None
        convolution_default_14 = torch.ops.aten.convolution.default(add_tensor_2, primals_103, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_94, primals_90, primals_92, primals_93, True, 0.1, 1e-05);  primals_90 = None
        getitem_56 = native_batch_norm_default_14[0]
        getitem_57 = native_batch_norm_default_14[1]
        getitem_58 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(relu__default_13, getitem_51);  getitem_51 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_3, primals_104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_99, primals_95, primals_97, primals_98, True, 0.1, 1e-05);  primals_95 = None
        getitem_59 = native_batch_norm_default_15[0]
        getitem_60 = native_batch_norm_default_15[1]
        getitem_61 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_12, relu__default_13, relu__default_14, getitem_52], 1);  getitem_52 = None
        convolution_default_16 = torch.ops.aten.convolution.default(cat_default_2, primals_101, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_84, primals_80, primals_82, primals_83, True, 0.1, 1e-05);  primals_80 = None
        getitem_62 = native_batch_norm_default_16[0]
        getitem_63 = native_batch_norm_default_16[1]
        getitem_64 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        add__tensor_19 = torch.ops.aten.add_.Tensor(getitem_62, relu__default_10);  getitem_62 = None
        relu__default_15 = torch.ops.aten.relu_.default(add__tensor_19);  add__tensor_19 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_15, primals_130, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_109, primals_105, primals_107, primals_108, True, 0.1, 1e-05);  primals_105 = None
        getitem_65 = native_batch_norm_default_17[0]
        getitem_66 = native_batch_norm_default_17[1]
        getitem_67 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        split_tensor_3 = torch.ops.aten.split.Tensor(relu__default_16, 52, 1)
        getitem_68 = split_tensor_3[0]
        getitem_69 = split_tensor_3[1]
        getitem_70 = split_tensor_3[2]
        getitem_71 = split_tensor_3[3];  split_tensor_3 = None
        convolution_default_18 = torch.ops.aten.convolution.default(getitem_68, primals_132, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_119, primals_115, primals_117, primals_118, True, 0.1, 1e-05);  primals_115 = None
        getitem_72 = native_batch_norm_default_18[0]
        getitem_73 = native_batch_norm_default_18[1]
        getitem_74 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_19 = torch.ops.aten.convolution.default(getitem_69, primals_133, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_124, primals_120, primals_122, primals_123, True, 0.1, 1e-05);  primals_120 = None
        getitem_75 = native_batch_norm_default_19[0]
        getitem_76 = native_batch_norm_default_19[1]
        getitem_77 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_70, primals_134, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_129, primals_125, primals_127, primals_128, True, 0.1, 1e-05);  primals_125 = None
        getitem_78 = native_batch_norm_default_20[0]
        getitem_79 = native_batch_norm_default_20[1]
        getitem_80 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(getitem_71, [3, 3], [2, 2], [1, 1])
        cat_default_3 = torch.ops.aten.cat.default([relu__default_17, relu__default_18, relu__default_19, avg_pool2d_default_1], 1);  avg_pool2d_default_1 = None
        convolution_default_21 = torch.ops.aten.convolution.default(cat_default_3, primals_131, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_114, primals_110, primals_112, primals_113, True, 0.1, 1e-05);  primals_110 = None
        getitem_81 = native_batch_norm_default_21[0]
        getitem_82 = native_batch_norm_default_21[1]
        getitem_83 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_15, primals_135, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_140, primals_136, primals_138, primals_139, True, 0.1, 1e-05);  primals_136 = None
        getitem_84 = native_batch_norm_default_22[0]
        getitem_85 = native_batch_norm_default_22[1]
        getitem_86 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        add__tensor_26 = torch.ops.aten.add_.Tensor(getitem_81, getitem_84);  getitem_81 = getitem_84 = None
        relu__default_20 = torch.ops.aten.relu_.default(add__tensor_26);  add__tensor_26 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_20, primals_166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_145, primals_141, primals_143, primals_144, True, 0.1, 1e-05);  primals_141 = None
        getitem_87 = native_batch_norm_default_23[0]
        getitem_88 = native_batch_norm_default_23[1]
        getitem_89 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        split_tensor_4 = torch.ops.aten.split.Tensor(relu__default_21, 52, 1)
        getitem_90 = split_tensor_4[0]
        getitem_91 = split_tensor_4[1]
        getitem_92 = split_tensor_4[2]
        getitem_93 = split_tensor_4[3];  split_tensor_4 = None
        convolution_default_24 = torch.ops.aten.convolution.default(getitem_90, primals_168, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_155, primals_151, primals_153, primals_154, True, 0.1, 1e-05);  primals_151 = None
        getitem_94 = native_batch_norm_default_24[0]
        getitem_95 = native_batch_norm_default_24[1]
        getitem_96 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_94);  getitem_94 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(relu__default_22, getitem_91);  getitem_91 = None
        convolution_default_25 = torch.ops.aten.convolution.default(add_tensor_4, primals_169, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_160, primals_156, primals_158, primals_159, True, 0.1, 1e-05);  primals_156 = None
        getitem_97 = native_batch_norm_default_25[0]
        getitem_98 = native_batch_norm_default_25[1]
        getitem_99 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_97);  getitem_97 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(relu__default_23, getitem_92);  getitem_92 = None
        convolution_default_26 = torch.ops.aten.convolution.default(add_tensor_5, primals_170, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_165, primals_161, primals_163, primals_164, True, 0.1, 1e-05);  primals_161 = None
        getitem_100 = native_batch_norm_default_26[0]
        getitem_101 = native_batch_norm_default_26[1]
        getitem_102 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_100);  getitem_100 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_22, relu__default_23, relu__default_24, getitem_93], 1);  getitem_93 = None
        convolution_default_27 = torch.ops.aten.convolution.default(cat_default_4, primals_167, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_150, primals_146, primals_148, primals_149, True, 0.1, 1e-05);  primals_146 = None
        getitem_103 = native_batch_norm_default_27[0]
        getitem_104 = native_batch_norm_default_27[1]
        getitem_105 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        add__tensor_32 = torch.ops.aten.add_.Tensor(getitem_103, relu__default_20);  getitem_103 = None
        relu__default_25 = torch.ops.aten.relu_.default(add__tensor_32);  add__tensor_32 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_25, primals_196, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_175, primals_171, primals_173, primals_174, True, 0.1, 1e-05);  primals_171 = None
        getitem_106 = native_batch_norm_default_28[0]
        getitem_107 = native_batch_norm_default_28[1]
        getitem_108 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_106);  getitem_106 = None
        split_tensor_5 = torch.ops.aten.split.Tensor(relu__default_26, 52, 1)
        getitem_109 = split_tensor_5[0]
        getitem_110 = split_tensor_5[1]
        getitem_111 = split_tensor_5[2]
        getitem_112 = split_tensor_5[3];  split_tensor_5 = None
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_109, primals_198, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_185, primals_181, primals_183, primals_184, True, 0.1, 1e-05);  primals_181 = None
        getitem_113 = native_batch_norm_default_29[0]
        getitem_114 = native_batch_norm_default_29[1]
        getitem_115 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(relu__default_27, getitem_110);  getitem_110 = None
        convolution_default_30 = torch.ops.aten.convolution.default(add_tensor_6, primals_199, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_190, primals_186, primals_188, primals_189, True, 0.1, 1e-05);  primals_186 = None
        getitem_116 = native_batch_norm_default_30[0]
        getitem_117 = native_batch_norm_default_30[1]
        getitem_118 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(relu__default_28, getitem_111);  getitem_111 = None
        convolution_default_31 = torch.ops.aten.convolution.default(add_tensor_7, primals_200, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_195, primals_191, primals_193, primals_194, True, 0.1, 1e-05);  primals_191 = None
        getitem_119 = native_batch_norm_default_31[0]
        getitem_120 = native_batch_norm_default_31[1]
        getitem_121 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_27, relu__default_28, relu__default_29, getitem_112], 1);  getitem_112 = None
        convolution_default_32 = torch.ops.aten.convolution.default(cat_default_5, primals_197, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_180, primals_176, primals_178, primals_179, True, 0.1, 1e-05);  primals_176 = None
        getitem_122 = native_batch_norm_default_32[0]
        getitem_123 = native_batch_norm_default_32[1]
        getitem_124 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        add__tensor_38 = torch.ops.aten.add_.Tensor(getitem_122, relu__default_25);  getitem_122 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_38);  add__tensor_38 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_30, primals_226, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_205, primals_201, primals_203, primals_204, True, 0.1, 1e-05);  primals_201 = None
        getitem_125 = native_batch_norm_default_33[0]
        getitem_126 = native_batch_norm_default_33[1]
        getitem_127 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        split_tensor_6 = torch.ops.aten.split.Tensor(relu__default_31, 52, 1)
        getitem_128 = split_tensor_6[0]
        getitem_129 = split_tensor_6[1]
        getitem_130 = split_tensor_6[2]
        getitem_131 = split_tensor_6[3];  split_tensor_6 = None
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_128, primals_228, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_215, primals_211, primals_213, primals_214, True, 0.1, 1e-05);  primals_211 = None
        getitem_132 = native_batch_norm_default_34[0]
        getitem_133 = native_batch_norm_default_34[1]
        getitem_134 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(relu__default_32, getitem_129);  getitem_129 = None
        convolution_default_35 = torch.ops.aten.convolution.default(add_tensor_8, primals_229, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_220, primals_216, primals_218, primals_219, True, 0.1, 1e-05);  primals_216 = None
        getitem_135 = native_batch_norm_default_35[0]
        getitem_136 = native_batch_norm_default_35[1]
        getitem_137 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(relu__default_33, getitem_130);  getitem_130 = None
        convolution_default_36 = torch.ops.aten.convolution.default(add_tensor_9, primals_230, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_225, primals_221, primals_223, primals_224, True, 0.1, 1e-05);  primals_221 = None
        getitem_138 = native_batch_norm_default_36[0]
        getitem_139 = native_batch_norm_default_36[1]
        getitem_140 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        cat_default_6 = torch.ops.aten.cat.default([relu__default_32, relu__default_33, relu__default_34, getitem_131], 1);  getitem_131 = None
        convolution_default_37 = torch.ops.aten.convolution.default(cat_default_6, primals_227, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_210, primals_206, primals_208, primals_209, True, 0.1, 1e-05);  primals_206 = None
        getitem_141 = native_batch_norm_default_37[0]
        getitem_142 = native_batch_norm_default_37[1]
        getitem_143 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        add__tensor_44 = torch.ops.aten.add_.Tensor(getitem_141, relu__default_30);  getitem_141 = None
        relu__default_35 = torch.ops.aten.relu_.default(add__tensor_44);  add__tensor_44 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_35, primals_256, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_235, primals_231, primals_233, primals_234, True, 0.1, 1e-05);  primals_231 = None
        getitem_144 = native_batch_norm_default_38[0]
        getitem_145 = native_batch_norm_default_38[1]
        getitem_146 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        split_tensor_7 = torch.ops.aten.split.Tensor(relu__default_36, 104, 1)
        getitem_147 = split_tensor_7[0]
        getitem_148 = split_tensor_7[1]
        getitem_149 = split_tensor_7[2]
        getitem_150 = split_tensor_7[3];  split_tensor_7 = None
        convolution_default_39 = torch.ops.aten.convolution.default(getitem_147, primals_258, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_245, primals_241, primals_243, primals_244, True, 0.1, 1e-05);  primals_241 = None
        getitem_151 = native_batch_norm_default_39[0]
        getitem_152 = native_batch_norm_default_39[1]
        getitem_153 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_151);  getitem_151 = None
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_148, primals_259, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_250, primals_246, primals_248, primals_249, True, 0.1, 1e-05);  primals_246 = None
        getitem_154 = native_batch_norm_default_40[0]
        getitem_155 = native_batch_norm_default_40[1]
        getitem_156 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_154);  getitem_154 = None
        convolution_default_41 = torch.ops.aten.convolution.default(getitem_149, primals_260, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_255, primals_251, primals_253, primals_254, True, 0.1, 1e-05);  primals_251 = None
        getitem_157 = native_batch_norm_default_41[0]
        getitem_158 = native_batch_norm_default_41[1]
        getitem_159 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_157);  getitem_157 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(getitem_150, [3, 3], [2, 2], [1, 1])
        cat_default_7 = torch.ops.aten.cat.default([relu__default_37, relu__default_38, relu__default_39, avg_pool2d_default_2], 1);  avg_pool2d_default_2 = None
        convolution_default_42 = torch.ops.aten.convolution.default(cat_default_7, primals_257, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_240, primals_236, primals_238, primals_239, True, 0.1, 1e-05);  primals_236 = None
        getitem_160 = native_batch_norm_default_42[0]
        getitem_161 = native_batch_norm_default_42[1]
        getitem_162 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_35, primals_261, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_266, primals_262, primals_264, primals_265, True, 0.1, 1e-05);  primals_262 = None
        getitem_163 = native_batch_norm_default_43[0]
        getitem_164 = native_batch_norm_default_43[1]
        getitem_165 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        add__tensor_51 = torch.ops.aten.add_.Tensor(getitem_160, getitem_163);  getitem_160 = getitem_163 = None
        relu__default_40 = torch.ops.aten.relu_.default(add__tensor_51);  add__tensor_51 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_40, primals_592, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_571, primals_567, primals_569, primals_570, True, 0.1, 1e-05);  primals_567 = None
        getitem_166 = native_batch_norm_default_44[0]
        getitem_167 = native_batch_norm_default_44[1]
        getitem_168 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_166);  getitem_166 = None
        split_tensor_8 = torch.ops.aten.split.Tensor(relu__default_41, 104, 1)
        getitem_169 = split_tensor_8[0]
        getitem_170 = split_tensor_8[1]
        getitem_171 = split_tensor_8[2]
        getitem_172 = split_tensor_8[3];  split_tensor_8 = None
        convolution_default_45 = torch.ops.aten.convolution.default(getitem_169, primals_594, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_173 = native_batch_norm_default_45[0]
        getitem_174 = native_batch_norm_default_45[1]
        getitem_175 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_173);  getitem_173 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(relu__default_42, getitem_170);  getitem_170 = None
        convolution_default_46 = torch.ops.aten.convolution.default(add_tensor_10, primals_595, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_586, primals_582, primals_584, primals_585, True, 0.1, 1e-05);  primals_582 = None
        getitem_176 = native_batch_norm_default_46[0]
        getitem_177 = native_batch_norm_default_46[1]
        getitem_178 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(relu__default_43, getitem_171);  getitem_171 = None
        convolution_default_47 = torch.ops.aten.convolution.default(add_tensor_11, primals_596, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_591, primals_587, primals_589, primals_590, True, 0.1, 1e-05);  primals_587 = None
        getitem_179 = native_batch_norm_default_47[0]
        getitem_180 = native_batch_norm_default_47[1]
        getitem_181 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        cat_default_8 = torch.ops.aten.cat.default([relu__default_42, relu__default_43, relu__default_44, getitem_172], 1);  getitem_172 = None
        convolution_default_48 = torch.ops.aten.convolution.default(cat_default_8, primals_593, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_576, primals_572, primals_574, primals_575, True, 0.1, 1e-05);  primals_572 = None
        getitem_182 = native_batch_norm_default_48[0]
        getitem_183 = native_batch_norm_default_48[1]
        getitem_184 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        add__tensor_57 = torch.ops.aten.add_.Tensor(getitem_182, relu__default_40);  getitem_182 = None
        relu__default_45 = torch.ops.aten.relu_.default(add__tensor_57);  add__tensor_57 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_45, primals_712, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_185 = native_batch_norm_default_49[0]
        getitem_186 = native_batch_norm_default_49[1]
        getitem_187 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        split_tensor_9 = torch.ops.aten.split.Tensor(relu__default_46, 104, 1)
        getitem_188 = split_tensor_9[0]
        getitem_189 = split_tensor_9[1]
        getitem_190 = split_tensor_9[2]
        getitem_191 = split_tensor_9[3];  split_tensor_9 = None
        convolution_default_50 = torch.ops.aten.convolution.default(getitem_188, primals_714, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_701, primals_697, primals_699, primals_700, True, 0.1, 1e-05);  primals_697 = None
        getitem_192 = native_batch_norm_default_50[0]
        getitem_193 = native_batch_norm_default_50[1]
        getitem_194 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_192);  getitem_192 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(relu__default_47, getitem_189);  getitem_189 = None
        convolution_default_51 = torch.ops.aten.convolution.default(add_tensor_12, primals_715, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_706, primals_702, primals_704, primals_705, True, 0.1, 1e-05);  primals_702 = None
        getitem_195 = native_batch_norm_default_51[0]
        getitem_196 = native_batch_norm_default_51[1]
        getitem_197 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_195);  getitem_195 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(relu__default_48, getitem_190);  getitem_190 = None
        convolution_default_52 = torch.ops.aten.convolution.default(add_tensor_13, primals_716, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_711, primals_707, primals_709, primals_710, True, 0.1, 1e-05);  primals_707 = None
        getitem_198 = native_batch_norm_default_52[0]
        getitem_199 = native_batch_norm_default_52[1]
        getitem_200 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_198);  getitem_198 = None
        cat_default_9 = torch.ops.aten.cat.default([relu__default_47, relu__default_48, relu__default_49, getitem_191], 1);  getitem_191 = None
        convolution_default_53 = torch.ops.aten.convolution.default(cat_default_9, primals_713, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_696, primals_692, primals_694, primals_695, True, 0.1, 1e-05);  primals_692 = None
        getitem_201 = native_batch_norm_default_53[0]
        getitem_202 = native_batch_norm_default_53[1]
        getitem_203 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        add__tensor_63 = torch.ops.aten.add_.Tensor(getitem_201, relu__default_45);  getitem_201 = None
        relu__default_50 = torch.ops.aten.relu_.default(add__tensor_63);  add__tensor_63 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_50, primals_742, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_721, primals_717, primals_719, primals_720, True, 0.1, 1e-05);  primals_717 = None
        getitem_204 = native_batch_norm_default_54[0]
        getitem_205 = native_batch_norm_default_54[1]
        getitem_206 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_204);  getitem_204 = None
        split_tensor_10 = torch.ops.aten.split.Tensor(relu__default_51, 104, 1)
        getitem_207 = split_tensor_10[0]
        getitem_208 = split_tensor_10[1]
        getitem_209 = split_tensor_10[2]
        getitem_210 = split_tensor_10[3];  split_tensor_10 = None
        convolution_default_55 = torch.ops.aten.convolution.default(getitem_207, primals_744, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_731, primals_727, primals_729, primals_730, True, 0.1, 1e-05);  primals_727 = None
        getitem_211 = native_batch_norm_default_55[0]
        getitem_212 = native_batch_norm_default_55[1]
        getitem_213 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_211);  getitem_211 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(relu__default_52, getitem_208);  getitem_208 = None
        convolution_default_56 = torch.ops.aten.convolution.default(add_tensor_14, primals_745, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_736, primals_732, primals_734, primals_735, True, 0.1, 1e-05);  primals_732 = None
        getitem_214 = native_batch_norm_default_56[0]
        getitem_215 = native_batch_norm_default_56[1]
        getitem_216 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_214);  getitem_214 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(relu__default_53, getitem_209);  getitem_209 = None
        convolution_default_57 = torch.ops.aten.convolution.default(add_tensor_15, primals_746, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_741, primals_737, primals_739, primals_740, True, 0.1, 1e-05);  primals_737 = None
        getitem_217 = native_batch_norm_default_57[0]
        getitem_218 = native_batch_norm_default_57[1]
        getitem_219 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_217);  getitem_217 = None
        cat_default_10 = torch.ops.aten.cat.default([relu__default_52, relu__default_53, relu__default_54, getitem_210], 1);  getitem_210 = None
        convolution_default_58 = torch.ops.aten.convolution.default(cat_default_10, primals_743, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_726, primals_722, primals_724, primals_725, True, 0.1, 1e-05);  primals_722 = None
        getitem_220 = native_batch_norm_default_58[0]
        getitem_221 = native_batch_norm_default_58[1]
        getitem_222 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        add__tensor_69 = torch.ops.aten.add_.Tensor(getitem_220, relu__default_50);  getitem_220 = None
        relu__default_55 = torch.ops.aten.relu_.default(add__tensor_69);  add__tensor_69 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_55, primals_772, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_751, primals_747, primals_749, primals_750, True, 0.1, 1e-05);  primals_747 = None
        getitem_223 = native_batch_norm_default_59[0]
        getitem_224 = native_batch_norm_default_59[1]
        getitem_225 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_223);  getitem_223 = None
        split_tensor_11 = torch.ops.aten.split.Tensor(relu__default_56, 104, 1)
        getitem_226 = split_tensor_11[0]
        getitem_227 = split_tensor_11[1]
        getitem_228 = split_tensor_11[2]
        getitem_229 = split_tensor_11[3];  split_tensor_11 = None
        convolution_default_60 = torch.ops.aten.convolution.default(getitem_226, primals_774, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_761, primals_757, primals_759, primals_760, True, 0.1, 1e-05);  primals_757 = None
        getitem_230 = native_batch_norm_default_60[0]
        getitem_231 = native_batch_norm_default_60[1]
        getitem_232 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(relu__default_57, getitem_227);  getitem_227 = None
        convolution_default_61 = torch.ops.aten.convolution.default(add_tensor_16, primals_775, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_766, primals_762, primals_764, primals_765, True, 0.1, 1e-05);  primals_762 = None
        getitem_233 = native_batch_norm_default_61[0]
        getitem_234 = native_batch_norm_default_61[1]
        getitem_235 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_233);  getitem_233 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(relu__default_58, getitem_228);  getitem_228 = None
        convolution_default_62 = torch.ops.aten.convolution.default(add_tensor_17, primals_776, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_771, primals_767, primals_769, primals_770, True, 0.1, 1e-05);  primals_767 = None
        getitem_236 = native_batch_norm_default_62[0]
        getitem_237 = native_batch_norm_default_62[1]
        getitem_238 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        cat_default_11 = torch.ops.aten.cat.default([relu__default_57, relu__default_58, relu__default_59, getitem_229], 1);  getitem_229 = None
        convolution_default_63 = torch.ops.aten.convolution.default(cat_default_11, primals_773, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_756, primals_752, primals_754, primals_755, True, 0.1, 1e-05);  primals_752 = None
        getitem_239 = native_batch_norm_default_63[0]
        getitem_240 = native_batch_norm_default_63[1]
        getitem_241 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        add__tensor_75 = torch.ops.aten.add_.Tensor(getitem_239, relu__default_55);  getitem_239 = None
        relu__default_60 = torch.ops.aten.relu_.default(add__tensor_75);  add__tensor_75 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_60, primals_802, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_781, primals_777, primals_779, primals_780, True, 0.1, 1e-05);  primals_777 = None
        getitem_242 = native_batch_norm_default_64[0]
        getitem_243 = native_batch_norm_default_64[1]
        getitem_244 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        split_tensor_12 = torch.ops.aten.split.Tensor(relu__default_61, 104, 1)
        getitem_245 = split_tensor_12[0]
        getitem_246 = split_tensor_12[1]
        getitem_247 = split_tensor_12[2]
        getitem_248 = split_tensor_12[3];  split_tensor_12 = None
        convolution_default_65 = torch.ops.aten.convolution.default(getitem_245, primals_804, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_791, primals_787, primals_789, primals_790, True, 0.1, 1e-05);  primals_787 = None
        getitem_249 = native_batch_norm_default_65[0]
        getitem_250 = native_batch_norm_default_65[1]
        getitem_251 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_249);  getitem_249 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(relu__default_62, getitem_246);  getitem_246 = None
        convolution_default_66 = torch.ops.aten.convolution.default(add_tensor_18, primals_805, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_796, primals_792, primals_794, primals_795, True, 0.1, 1e-05);  primals_792 = None
        getitem_252 = native_batch_norm_default_66[0]
        getitem_253 = native_batch_norm_default_66[1]
        getitem_254 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_252);  getitem_252 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(relu__default_63, getitem_247);  getitem_247 = None
        convolution_default_67 = torch.ops.aten.convolution.default(add_tensor_19, primals_806, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_801, primals_797, primals_799, primals_800, True, 0.1, 1e-05);  primals_797 = None
        getitem_255 = native_batch_norm_default_67[0]
        getitem_256 = native_batch_norm_default_67[1]
        getitem_257 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_255);  getitem_255 = None
        cat_default_12 = torch.ops.aten.cat.default([relu__default_62, relu__default_63, relu__default_64, getitem_248], 1);  getitem_248 = None
        convolution_default_68 = torch.ops.aten.convolution.default(cat_default_12, primals_803, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_786, primals_782, primals_784, primals_785, True, 0.1, 1e-05);  primals_782 = None
        getitem_258 = native_batch_norm_default_68[0]
        getitem_259 = native_batch_norm_default_68[1]
        getitem_260 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        add__tensor_81 = torch.ops.aten.add_.Tensor(getitem_258, relu__default_60);  getitem_258 = None
        relu__default_65 = torch.ops.aten.relu_.default(add__tensor_81);  add__tensor_81 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_65, primals_832, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_811, primals_807, primals_809, primals_810, True, 0.1, 1e-05);  primals_807 = None
        getitem_261 = native_batch_norm_default_69[0]
        getitem_262 = native_batch_norm_default_69[1]
        getitem_263 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_261);  getitem_261 = None
        split_tensor_13 = torch.ops.aten.split.Tensor(relu__default_66, 104, 1)
        getitem_264 = split_tensor_13[0]
        getitem_265 = split_tensor_13[1]
        getitem_266 = split_tensor_13[2]
        getitem_267 = split_tensor_13[3];  split_tensor_13 = None
        convolution_default_70 = torch.ops.aten.convolution.default(getitem_264, primals_834, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_821, primals_817, primals_819, primals_820, True, 0.1, 1e-05);  primals_817 = None
        getitem_268 = native_batch_norm_default_70[0]
        getitem_269 = native_batch_norm_default_70[1]
        getitem_270 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_268);  getitem_268 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(relu__default_67, getitem_265);  getitem_265 = None
        convolution_default_71 = torch.ops.aten.convolution.default(add_tensor_20, primals_835, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_826, primals_822, primals_824, primals_825, True, 0.1, 1e-05);  primals_822 = None
        getitem_271 = native_batch_norm_default_71[0]
        getitem_272 = native_batch_norm_default_71[1]
        getitem_273 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_271);  getitem_271 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(relu__default_68, getitem_266);  getitem_266 = None
        convolution_default_72 = torch.ops.aten.convolution.default(add_tensor_21, primals_836, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_831, primals_827, primals_829, primals_830, True, 0.1, 1e-05);  primals_827 = None
        getitem_274 = native_batch_norm_default_72[0]
        getitem_275 = native_batch_norm_default_72[1]
        getitem_276 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_274);  getitem_274 = None
        cat_default_13 = torch.ops.aten.cat.default([relu__default_67, relu__default_68, relu__default_69, getitem_267], 1);  getitem_267 = None
        convolution_default_73 = torch.ops.aten.convolution.default(cat_default_13, primals_833, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_816, primals_812, primals_814, primals_815, True, 0.1, 1e-05);  primals_812 = None
        getitem_277 = native_batch_norm_default_73[0]
        getitem_278 = native_batch_norm_default_73[1]
        getitem_279 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        add__tensor_87 = torch.ops.aten.add_.Tensor(getitem_277, relu__default_65);  getitem_277 = None
        relu__default_70 = torch.ops.aten.relu_.default(add__tensor_87);  add__tensor_87 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_70, primals_862, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_841, primals_837, primals_839, primals_840, True, 0.1, 1e-05);  primals_837 = None
        getitem_280 = native_batch_norm_default_74[0]
        getitem_281 = native_batch_norm_default_74[1]
        getitem_282 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_280);  getitem_280 = None
        split_tensor_14 = torch.ops.aten.split.Tensor(relu__default_71, 104, 1)
        getitem_283 = split_tensor_14[0]
        getitem_284 = split_tensor_14[1]
        getitem_285 = split_tensor_14[2]
        getitem_286 = split_tensor_14[3];  split_tensor_14 = None
        convolution_default_75 = torch.ops.aten.convolution.default(getitem_283, primals_864, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_851, primals_847, primals_849, primals_850, True, 0.1, 1e-05);  primals_847 = None
        getitem_287 = native_batch_norm_default_75[0]
        getitem_288 = native_batch_norm_default_75[1]
        getitem_289 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(relu__default_72, getitem_284);  getitem_284 = None
        convolution_default_76 = torch.ops.aten.convolution.default(add_tensor_22, primals_865, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_856, primals_852, primals_854, primals_855, True, 0.1, 1e-05);  primals_852 = None
        getitem_290 = native_batch_norm_default_76[0]
        getitem_291 = native_batch_norm_default_76[1]
        getitem_292 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(relu__default_73, getitem_285);  getitem_285 = None
        convolution_default_77 = torch.ops.aten.convolution.default(add_tensor_23, primals_866, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_861, primals_857, primals_859, primals_860, True, 0.1, 1e-05);  primals_857 = None
        getitem_293 = native_batch_norm_default_77[0]
        getitem_294 = native_batch_norm_default_77[1]
        getitem_295 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_293);  getitem_293 = None
        cat_default_14 = torch.ops.aten.cat.default([relu__default_72, relu__default_73, relu__default_74, getitem_286], 1);  getitem_286 = None
        convolution_default_78 = torch.ops.aten.convolution.default(cat_default_14, primals_863, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_846, primals_842, primals_844, primals_845, True, 0.1, 1e-05);  primals_842 = None
        getitem_296 = native_batch_norm_default_78[0]
        getitem_297 = native_batch_norm_default_78[1]
        getitem_298 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        add__tensor_93 = torch.ops.aten.add_.Tensor(getitem_296, relu__default_70);  getitem_296 = None
        relu__default_75 = torch.ops.aten.relu_.default(add__tensor_93);  add__tensor_93 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_75, primals_892, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_871, primals_867, primals_869, primals_870, True, 0.1, 1e-05);  primals_867 = None
        getitem_299 = native_batch_norm_default_79[0]
        getitem_300 = native_batch_norm_default_79[1]
        getitem_301 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        split_tensor_15 = torch.ops.aten.split.Tensor(relu__default_76, 104, 1)
        getitem_302 = split_tensor_15[0]
        getitem_303 = split_tensor_15[1]
        getitem_304 = split_tensor_15[2]
        getitem_305 = split_tensor_15[3];  split_tensor_15 = None
        convolution_default_80 = torch.ops.aten.convolution.default(getitem_302, primals_894, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_881, primals_877, primals_879, primals_880, True, 0.1, 1e-05);  primals_877 = None
        getitem_306 = native_batch_norm_default_80[0]
        getitem_307 = native_batch_norm_default_80[1]
        getitem_308 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_306);  getitem_306 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(relu__default_77, getitem_303);  getitem_303 = None
        convolution_default_81 = torch.ops.aten.convolution.default(add_tensor_24, primals_895, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_886, primals_882, primals_884, primals_885, True, 0.1, 1e-05);  primals_882 = None
        getitem_309 = native_batch_norm_default_81[0]
        getitem_310 = native_batch_norm_default_81[1]
        getitem_311 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_309);  getitem_309 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(relu__default_78, getitem_304);  getitem_304 = None
        convolution_default_82 = torch.ops.aten.convolution.default(add_tensor_25, primals_896, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_891, primals_887, primals_889, primals_890, True, 0.1, 1e-05);  primals_887 = None
        getitem_312 = native_batch_norm_default_82[0]
        getitem_313 = native_batch_norm_default_82[1]
        getitem_314 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_312);  getitem_312 = None
        cat_default_15 = torch.ops.aten.cat.default([relu__default_77, relu__default_78, relu__default_79, getitem_305], 1);  getitem_305 = None
        convolution_default_83 = torch.ops.aten.convolution.default(cat_default_15, primals_893, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_876, primals_872, primals_874, primals_875, True, 0.1, 1e-05);  primals_872 = None
        getitem_315 = native_batch_norm_default_83[0]
        getitem_316 = native_batch_norm_default_83[1]
        getitem_317 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        add__tensor_99 = torch.ops.aten.add_.Tensor(getitem_315, relu__default_75);  getitem_315 = None
        relu__default_80 = torch.ops.aten.relu_.default(add__tensor_99);  add__tensor_99 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_80, primals_922, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_901, primals_897, primals_899, primals_900, True, 0.1, 1e-05);  primals_897 = None
        getitem_318 = native_batch_norm_default_84[0]
        getitem_319 = native_batch_norm_default_84[1]
        getitem_320 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_318);  getitem_318 = None
        split_tensor_16 = torch.ops.aten.split.Tensor(relu__default_81, 104, 1)
        getitem_321 = split_tensor_16[0]
        getitem_322 = split_tensor_16[1]
        getitem_323 = split_tensor_16[2]
        getitem_324 = split_tensor_16[3];  split_tensor_16 = None
        convolution_default_85 = torch.ops.aten.convolution.default(getitem_321, primals_924, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_911, primals_907, primals_909, primals_910, True, 0.1, 1e-05);  primals_907 = None
        getitem_325 = native_batch_norm_default_85[0]
        getitem_326 = native_batch_norm_default_85[1]
        getitem_327 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_325);  getitem_325 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(relu__default_82, getitem_322);  getitem_322 = None
        convolution_default_86 = torch.ops.aten.convolution.default(add_tensor_26, primals_925, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_916, primals_912, primals_914, primals_915, True, 0.1, 1e-05);  primals_912 = None
        getitem_328 = native_batch_norm_default_86[0]
        getitem_329 = native_batch_norm_default_86[1]
        getitem_330 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_328);  getitem_328 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(relu__default_83, getitem_323);  getitem_323 = None
        convolution_default_87 = torch.ops.aten.convolution.default(add_tensor_27, primals_926, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_921, primals_917, primals_919, primals_920, True, 0.1, 1e-05);  primals_917 = None
        getitem_331 = native_batch_norm_default_87[0]
        getitem_332 = native_batch_norm_default_87[1]
        getitem_333 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_331);  getitem_331 = None
        cat_default_16 = torch.ops.aten.cat.default([relu__default_82, relu__default_83, relu__default_84, getitem_324], 1);  getitem_324 = None
        convolution_default_88 = torch.ops.aten.convolution.default(cat_default_16, primals_923, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_906, primals_902, primals_904, primals_905, True, 0.1, 1e-05);  primals_902 = None
        getitem_334 = native_batch_norm_default_88[0]
        getitem_335 = native_batch_norm_default_88[1]
        getitem_336 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        add__tensor_105 = torch.ops.aten.add_.Tensor(getitem_334, relu__default_80);  getitem_334 = None
        relu__default_85 = torch.ops.aten.relu_.default(add__tensor_105);  add__tensor_105 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_85, primals_292, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_271, primals_267, primals_269, primals_270, True, 0.1, 1e-05);  primals_267 = None
        getitem_337 = native_batch_norm_default_89[0]
        getitem_338 = native_batch_norm_default_89[1]
        getitem_339 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_337);  getitem_337 = None
        split_tensor_17 = torch.ops.aten.split.Tensor(relu__default_86, 104, 1)
        getitem_340 = split_tensor_17[0]
        getitem_341 = split_tensor_17[1]
        getitem_342 = split_tensor_17[2]
        getitem_343 = split_tensor_17[3];  split_tensor_17 = None
        convolution_default_90 = torch.ops.aten.convolution.default(getitem_340, primals_294, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_281, primals_277, primals_279, primals_280, True, 0.1, 1e-05);  primals_277 = None
        getitem_344 = native_batch_norm_default_90[0]
        getitem_345 = native_batch_norm_default_90[1]
        getitem_346 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_344);  getitem_344 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(relu__default_87, getitem_341);  getitem_341 = None
        convolution_default_91 = torch.ops.aten.convolution.default(add_tensor_28, primals_295, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_286, primals_282, primals_284, primals_285, True, 0.1, 1e-05);  primals_282 = None
        getitem_347 = native_batch_norm_default_91[0]
        getitem_348 = native_batch_norm_default_91[1]
        getitem_349 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_347);  getitem_347 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(relu__default_88, getitem_342);  getitem_342 = None
        convolution_default_92 = torch.ops.aten.convolution.default(add_tensor_29, primals_296, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_291, primals_287, primals_289, primals_290, True, 0.1, 1e-05);  primals_287 = None
        getitem_350 = native_batch_norm_default_92[0]
        getitem_351 = native_batch_norm_default_92[1]
        getitem_352 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_350);  getitem_350 = None
        cat_default_17 = torch.ops.aten.cat.default([relu__default_87, relu__default_88, relu__default_89, getitem_343], 1);  getitem_343 = None
        convolution_default_93 = torch.ops.aten.convolution.default(cat_default_17, primals_293, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_276, primals_272, primals_274, primals_275, True, 0.1, 1e-05);  primals_272 = None
        getitem_353 = native_batch_norm_default_93[0]
        getitem_354 = native_batch_norm_default_93[1]
        getitem_355 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        add__tensor_111 = torch.ops.aten.add_.Tensor(getitem_353, relu__default_85);  getitem_353 = None
        relu__default_90 = torch.ops.aten.relu_.default(add__tensor_111);  add__tensor_111 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_90, primals_322, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_301, primals_297, primals_299, primals_300, True, 0.1, 1e-05);  primals_297 = None
        getitem_356 = native_batch_norm_default_94[0]
        getitem_357 = native_batch_norm_default_94[1]
        getitem_358 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_356);  getitem_356 = None
        split_tensor_18 = torch.ops.aten.split.Tensor(relu__default_91, 104, 1)
        getitem_359 = split_tensor_18[0]
        getitem_360 = split_tensor_18[1]
        getitem_361 = split_tensor_18[2]
        getitem_362 = split_tensor_18[3];  split_tensor_18 = None
        convolution_default_95 = torch.ops.aten.convolution.default(getitem_359, primals_324, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_311, primals_307, primals_309, primals_310, True, 0.1, 1e-05);  primals_307 = None
        getitem_363 = native_batch_norm_default_95[0]
        getitem_364 = native_batch_norm_default_95[1]
        getitem_365 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_363);  getitem_363 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(relu__default_92, getitem_360);  getitem_360 = None
        convolution_default_96 = torch.ops.aten.convolution.default(add_tensor_30, primals_325, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_316, primals_312, primals_314, primals_315, True, 0.1, 1e-05);  primals_312 = None
        getitem_366 = native_batch_norm_default_96[0]
        getitem_367 = native_batch_norm_default_96[1]
        getitem_368 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_366);  getitem_366 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(relu__default_93, getitem_361);  getitem_361 = None
        convolution_default_97 = torch.ops.aten.convolution.default(add_tensor_31, primals_326, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_321, primals_317, primals_319, primals_320, True, 0.1, 1e-05);  primals_317 = None
        getitem_369 = native_batch_norm_default_97[0]
        getitem_370 = native_batch_norm_default_97[1]
        getitem_371 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_369);  getitem_369 = None
        cat_default_18 = torch.ops.aten.cat.default([relu__default_92, relu__default_93, relu__default_94, getitem_362], 1);  getitem_362 = None
        convolution_default_98 = torch.ops.aten.convolution.default(cat_default_18, primals_323, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_306, primals_302, primals_304, primals_305, True, 0.1, 1e-05);  primals_302 = None
        getitem_372 = native_batch_norm_default_98[0]
        getitem_373 = native_batch_norm_default_98[1]
        getitem_374 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        add__tensor_117 = torch.ops.aten.add_.Tensor(getitem_372, relu__default_90);  getitem_372 = None
        relu__default_95 = torch.ops.aten.relu_.default(add__tensor_117);  add__tensor_117 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_95, primals_352, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_331, primals_327, primals_329, primals_330, True, 0.1, 1e-05);  primals_327 = None
        getitem_375 = native_batch_norm_default_99[0]
        getitem_376 = native_batch_norm_default_99[1]
        getitem_377 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_375);  getitem_375 = None
        split_tensor_19 = torch.ops.aten.split.Tensor(relu__default_96, 104, 1)
        getitem_378 = split_tensor_19[0]
        getitem_379 = split_tensor_19[1]
        getitem_380 = split_tensor_19[2]
        getitem_381 = split_tensor_19[3];  split_tensor_19 = None
        convolution_default_100 = torch.ops.aten.convolution.default(getitem_378, primals_354, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_341, primals_337, primals_339, primals_340, True, 0.1, 1e-05);  primals_337 = None
        getitem_382 = native_batch_norm_default_100[0]
        getitem_383 = native_batch_norm_default_100[1]
        getitem_384 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_382);  getitem_382 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(relu__default_97, getitem_379);  getitem_379 = None
        convolution_default_101 = torch.ops.aten.convolution.default(add_tensor_32, primals_355, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_346, primals_342, primals_344, primals_345, True, 0.1, 1e-05);  primals_342 = None
        getitem_385 = native_batch_norm_default_101[0]
        getitem_386 = native_batch_norm_default_101[1]
        getitem_387 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_385);  getitem_385 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(relu__default_98, getitem_380);  getitem_380 = None
        convolution_default_102 = torch.ops.aten.convolution.default(add_tensor_33, primals_356, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_351, primals_347, primals_349, primals_350, True, 0.1, 1e-05);  primals_347 = None
        getitem_388 = native_batch_norm_default_102[0]
        getitem_389 = native_batch_norm_default_102[1]
        getitem_390 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_388);  getitem_388 = None
        cat_default_19 = torch.ops.aten.cat.default([relu__default_97, relu__default_98, relu__default_99, getitem_381], 1);  getitem_381 = None
        convolution_default_103 = torch.ops.aten.convolution.default(cat_default_19, primals_353, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_336, primals_332, primals_334, primals_335, True, 0.1, 1e-05);  primals_332 = None
        getitem_391 = native_batch_norm_default_103[0]
        getitem_392 = native_batch_norm_default_103[1]
        getitem_393 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        add__tensor_123 = torch.ops.aten.add_.Tensor(getitem_391, relu__default_95);  getitem_391 = None
        relu__default_100 = torch.ops.aten.relu_.default(add__tensor_123);  add__tensor_123 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_100, primals_382, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_361, primals_357, primals_359, primals_360, True, 0.1, 1e-05);  primals_357 = None
        getitem_394 = native_batch_norm_default_104[0]
        getitem_395 = native_batch_norm_default_104[1]
        getitem_396 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu__default_101 = torch.ops.aten.relu_.default(getitem_394);  getitem_394 = None
        split_tensor_20 = torch.ops.aten.split.Tensor(relu__default_101, 104, 1)
        getitem_397 = split_tensor_20[0]
        getitem_398 = split_tensor_20[1]
        getitem_399 = split_tensor_20[2]
        getitem_400 = split_tensor_20[3];  split_tensor_20 = None
        convolution_default_105 = torch.ops.aten.convolution.default(getitem_397, primals_384, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_371, primals_367, primals_369, primals_370, True, 0.1, 1e-05);  primals_367 = None
        getitem_401 = native_batch_norm_default_105[0]
        getitem_402 = native_batch_norm_default_105[1]
        getitem_403 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        relu__default_102 = torch.ops.aten.relu_.default(getitem_401);  getitem_401 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(relu__default_102, getitem_398);  getitem_398 = None
        convolution_default_106 = torch.ops.aten.convolution.default(add_tensor_34, primals_385, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_376, primals_372, primals_374, primals_375, True, 0.1, 1e-05);  primals_372 = None
        getitem_404 = native_batch_norm_default_106[0]
        getitem_405 = native_batch_norm_default_106[1]
        getitem_406 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu__default_103 = torch.ops.aten.relu_.default(getitem_404);  getitem_404 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(relu__default_103, getitem_399);  getitem_399 = None
        convolution_default_107 = torch.ops.aten.convolution.default(add_tensor_35, primals_386, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_381, primals_377, primals_379, primals_380, True, 0.1, 1e-05);  primals_377 = None
        getitem_407 = native_batch_norm_default_107[0]
        getitem_408 = native_batch_norm_default_107[1]
        getitem_409 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        relu__default_104 = torch.ops.aten.relu_.default(getitem_407);  getitem_407 = None
        cat_default_20 = torch.ops.aten.cat.default([relu__default_102, relu__default_103, relu__default_104, getitem_400], 1);  getitem_400 = None
        convolution_default_108 = torch.ops.aten.convolution.default(cat_default_20, primals_383, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_366, primals_362, primals_364, primals_365, True, 0.1, 1e-05);  primals_362 = None
        getitem_410 = native_batch_norm_default_108[0]
        getitem_411 = native_batch_norm_default_108[1]
        getitem_412 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        add__tensor_129 = torch.ops.aten.add_.Tensor(getitem_410, relu__default_100);  getitem_410 = None
        relu__default_105 = torch.ops.aten.relu_.default(add__tensor_129);  add__tensor_129 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_105, primals_412, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_391, primals_387, primals_389, primals_390, True, 0.1, 1e-05);  primals_387 = None
        getitem_413 = native_batch_norm_default_109[0]
        getitem_414 = native_batch_norm_default_109[1]
        getitem_415 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        relu__default_106 = torch.ops.aten.relu_.default(getitem_413);  getitem_413 = None
        split_tensor_21 = torch.ops.aten.split.Tensor(relu__default_106, 104, 1)
        getitem_416 = split_tensor_21[0]
        getitem_417 = split_tensor_21[1]
        getitem_418 = split_tensor_21[2]
        getitem_419 = split_tensor_21[3];  split_tensor_21 = None
        convolution_default_110 = torch.ops.aten.convolution.default(getitem_416, primals_414, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_401, primals_397, primals_399, primals_400, True, 0.1, 1e-05);  primals_397 = None
        getitem_420 = native_batch_norm_default_110[0]
        getitem_421 = native_batch_norm_default_110[1]
        getitem_422 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        relu__default_107 = torch.ops.aten.relu_.default(getitem_420);  getitem_420 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(relu__default_107, getitem_417);  getitem_417 = None
        convolution_default_111 = torch.ops.aten.convolution.default(add_tensor_36, primals_415, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_406, primals_402, primals_404, primals_405, True, 0.1, 1e-05);  primals_402 = None
        getitem_423 = native_batch_norm_default_111[0]
        getitem_424 = native_batch_norm_default_111[1]
        getitem_425 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        relu__default_108 = torch.ops.aten.relu_.default(getitem_423);  getitem_423 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(relu__default_108, getitem_418);  getitem_418 = None
        convolution_default_112 = torch.ops.aten.convolution.default(add_tensor_37, primals_416, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_411, primals_407, primals_409, primals_410, True, 0.1, 1e-05);  primals_407 = None
        getitem_426 = native_batch_norm_default_112[0]
        getitem_427 = native_batch_norm_default_112[1]
        getitem_428 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        relu__default_109 = torch.ops.aten.relu_.default(getitem_426);  getitem_426 = None
        cat_default_21 = torch.ops.aten.cat.default([relu__default_107, relu__default_108, relu__default_109, getitem_419], 1);  getitem_419 = None
        convolution_default_113 = torch.ops.aten.convolution.default(cat_default_21, primals_413, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_396, primals_392, primals_394, primals_395, True, 0.1, 1e-05);  primals_392 = None
        getitem_429 = native_batch_norm_default_113[0]
        getitem_430 = native_batch_norm_default_113[1]
        getitem_431 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        add__tensor_135 = torch.ops.aten.add_.Tensor(getitem_429, relu__default_105);  getitem_429 = None
        relu__default_110 = torch.ops.aten.relu_.default(add__tensor_135);  add__tensor_135 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu__default_110, primals_442, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_421, primals_417, primals_419, primals_420, True, 0.1, 1e-05);  primals_417 = None
        getitem_432 = native_batch_norm_default_114[0]
        getitem_433 = native_batch_norm_default_114[1]
        getitem_434 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu__default_111 = torch.ops.aten.relu_.default(getitem_432);  getitem_432 = None
        split_tensor_22 = torch.ops.aten.split.Tensor(relu__default_111, 104, 1)
        getitem_435 = split_tensor_22[0]
        getitem_436 = split_tensor_22[1]
        getitem_437 = split_tensor_22[2]
        getitem_438 = split_tensor_22[3];  split_tensor_22 = None
        convolution_default_115 = torch.ops.aten.convolution.default(getitem_435, primals_444, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_431, primals_427, primals_429, primals_430, True, 0.1, 1e-05);  primals_427 = None
        getitem_439 = native_batch_norm_default_115[0]
        getitem_440 = native_batch_norm_default_115[1]
        getitem_441 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        relu__default_112 = torch.ops.aten.relu_.default(getitem_439);  getitem_439 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(relu__default_112, getitem_436);  getitem_436 = None
        convolution_default_116 = torch.ops.aten.convolution.default(add_tensor_38, primals_445, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_436, primals_432, primals_434, primals_435, True, 0.1, 1e-05);  primals_432 = None
        getitem_442 = native_batch_norm_default_116[0]
        getitem_443 = native_batch_norm_default_116[1]
        getitem_444 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        relu__default_113 = torch.ops.aten.relu_.default(getitem_442);  getitem_442 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(relu__default_113, getitem_437);  getitem_437 = None
        convolution_default_117 = torch.ops.aten.convolution.default(add_tensor_39, primals_446, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_441, primals_437, primals_439, primals_440, True, 0.1, 1e-05);  primals_437 = None
        getitem_445 = native_batch_norm_default_117[0]
        getitem_446 = native_batch_norm_default_117[1]
        getitem_447 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        relu__default_114 = torch.ops.aten.relu_.default(getitem_445);  getitem_445 = None
        cat_default_22 = torch.ops.aten.cat.default([relu__default_112, relu__default_113, relu__default_114, getitem_438], 1);  getitem_438 = None
        convolution_default_118 = torch.ops.aten.convolution.default(cat_default_22, primals_443, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_426, primals_422, primals_424, primals_425, True, 0.1, 1e-05);  primals_422 = None
        getitem_448 = native_batch_norm_default_118[0]
        getitem_449 = native_batch_norm_default_118[1]
        getitem_450 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        add__tensor_141 = torch.ops.aten.add_.Tensor(getitem_448, relu__default_110);  getitem_448 = None
        relu__default_115 = torch.ops.aten.relu_.default(add__tensor_141);  add__tensor_141 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu__default_115, primals_472, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_451, primals_447, primals_449, primals_450, True, 0.1, 1e-05);  primals_447 = None
        getitem_451 = native_batch_norm_default_119[0]
        getitem_452 = native_batch_norm_default_119[1]
        getitem_453 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        relu__default_116 = torch.ops.aten.relu_.default(getitem_451);  getitem_451 = None
        split_tensor_23 = torch.ops.aten.split.Tensor(relu__default_116, 104, 1)
        getitem_454 = split_tensor_23[0]
        getitem_455 = split_tensor_23[1]
        getitem_456 = split_tensor_23[2]
        getitem_457 = split_tensor_23[3];  split_tensor_23 = None
        convolution_default_120 = torch.ops.aten.convolution.default(getitem_454, primals_474, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_461, primals_457, primals_459, primals_460, True, 0.1, 1e-05);  primals_457 = None
        getitem_458 = native_batch_norm_default_120[0]
        getitem_459 = native_batch_norm_default_120[1]
        getitem_460 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        relu__default_117 = torch.ops.aten.relu_.default(getitem_458);  getitem_458 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(relu__default_117, getitem_455);  getitem_455 = None
        convolution_default_121 = torch.ops.aten.convolution.default(add_tensor_40, primals_475, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_466, primals_462, primals_464, primals_465, True, 0.1, 1e-05);  primals_462 = None
        getitem_461 = native_batch_norm_default_121[0]
        getitem_462 = native_batch_norm_default_121[1]
        getitem_463 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        relu__default_118 = torch.ops.aten.relu_.default(getitem_461);  getitem_461 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(relu__default_118, getitem_456);  getitem_456 = None
        convolution_default_122 = torch.ops.aten.convolution.default(add_tensor_41, primals_476, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_471, primals_467, primals_469, primals_470, True, 0.1, 1e-05);  primals_467 = None
        getitem_464 = native_batch_norm_default_122[0]
        getitem_465 = native_batch_norm_default_122[1]
        getitem_466 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        relu__default_119 = torch.ops.aten.relu_.default(getitem_464);  getitem_464 = None
        cat_default_23 = torch.ops.aten.cat.default([relu__default_117, relu__default_118, relu__default_119, getitem_457], 1);  getitem_457 = None
        convolution_default_123 = torch.ops.aten.convolution.default(cat_default_23, primals_473, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_456, primals_452, primals_454, primals_455, True, 0.1, 1e-05);  primals_452 = None
        getitem_467 = native_batch_norm_default_123[0]
        getitem_468 = native_batch_norm_default_123[1]
        getitem_469 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        add__tensor_147 = torch.ops.aten.add_.Tensor(getitem_467, relu__default_115);  getitem_467 = None
        relu__default_120 = torch.ops.aten.relu_.default(add__tensor_147);  add__tensor_147 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_120, primals_502, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_481, primals_477, primals_479, primals_480, True, 0.1, 1e-05);  primals_477 = None
        getitem_470 = native_batch_norm_default_124[0]
        getitem_471 = native_batch_norm_default_124[1]
        getitem_472 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        relu__default_121 = torch.ops.aten.relu_.default(getitem_470);  getitem_470 = None
        split_tensor_24 = torch.ops.aten.split.Tensor(relu__default_121, 104, 1)
        getitem_473 = split_tensor_24[0]
        getitem_474 = split_tensor_24[1]
        getitem_475 = split_tensor_24[2]
        getitem_476 = split_tensor_24[3];  split_tensor_24 = None
        convolution_default_125 = torch.ops.aten.convolution.default(getitem_473, primals_504, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_491, primals_487, primals_489, primals_490, True, 0.1, 1e-05);  primals_487 = None
        getitem_477 = native_batch_norm_default_125[0]
        getitem_478 = native_batch_norm_default_125[1]
        getitem_479 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        relu__default_122 = torch.ops.aten.relu_.default(getitem_477);  getitem_477 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(relu__default_122, getitem_474);  getitem_474 = None
        convolution_default_126 = torch.ops.aten.convolution.default(add_tensor_42, primals_505, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_496, primals_492, primals_494, primals_495, True, 0.1, 1e-05);  primals_492 = None
        getitem_480 = native_batch_norm_default_126[0]
        getitem_481 = native_batch_norm_default_126[1]
        getitem_482 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        relu__default_123 = torch.ops.aten.relu_.default(getitem_480);  getitem_480 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(relu__default_123, getitem_475);  getitem_475 = None
        convolution_default_127 = torch.ops.aten.convolution.default(add_tensor_43, primals_506, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_501, primals_497, primals_499, primals_500, True, 0.1, 1e-05);  primals_497 = None
        getitem_483 = native_batch_norm_default_127[0]
        getitem_484 = native_batch_norm_default_127[1]
        getitem_485 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        relu__default_124 = torch.ops.aten.relu_.default(getitem_483);  getitem_483 = None
        cat_default_24 = torch.ops.aten.cat.default([relu__default_122, relu__default_123, relu__default_124, getitem_476], 1);  getitem_476 = None
        convolution_default_128 = torch.ops.aten.convolution.default(cat_default_24, primals_503, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_486, primals_482, primals_484, primals_485, True, 0.1, 1e-05);  primals_482 = None
        getitem_486 = native_batch_norm_default_128[0]
        getitem_487 = native_batch_norm_default_128[1]
        getitem_488 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        add__tensor_153 = torch.ops.aten.add_.Tensor(getitem_486, relu__default_120);  getitem_486 = None
        relu__default_125 = torch.ops.aten.relu_.default(add__tensor_153);  add__tensor_153 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu__default_125, primals_532, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_511, primals_507, primals_509, primals_510, True, 0.1, 1e-05);  primals_507 = None
        getitem_489 = native_batch_norm_default_129[0]
        getitem_490 = native_batch_norm_default_129[1]
        getitem_491 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        relu__default_126 = torch.ops.aten.relu_.default(getitem_489);  getitem_489 = None
        split_tensor_25 = torch.ops.aten.split.Tensor(relu__default_126, 104, 1)
        getitem_492 = split_tensor_25[0]
        getitem_493 = split_tensor_25[1]
        getitem_494 = split_tensor_25[2]
        getitem_495 = split_tensor_25[3];  split_tensor_25 = None
        convolution_default_130 = torch.ops.aten.convolution.default(getitem_492, primals_534, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_521, primals_517, primals_519, primals_520, True, 0.1, 1e-05);  primals_517 = None
        getitem_496 = native_batch_norm_default_130[0]
        getitem_497 = native_batch_norm_default_130[1]
        getitem_498 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        relu__default_127 = torch.ops.aten.relu_.default(getitem_496);  getitem_496 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(relu__default_127, getitem_493);  getitem_493 = None
        convolution_default_131 = torch.ops.aten.convolution.default(add_tensor_44, primals_535, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_526, primals_522, primals_524, primals_525, True, 0.1, 1e-05);  primals_522 = None
        getitem_499 = native_batch_norm_default_131[0]
        getitem_500 = native_batch_norm_default_131[1]
        getitem_501 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        relu__default_128 = torch.ops.aten.relu_.default(getitem_499);  getitem_499 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(relu__default_128, getitem_494);  getitem_494 = None
        convolution_default_132 = torch.ops.aten.convolution.default(add_tensor_45, primals_536, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_531, primals_527, primals_529, primals_530, True, 0.1, 1e-05);  primals_527 = None
        getitem_502 = native_batch_norm_default_132[0]
        getitem_503 = native_batch_norm_default_132[1]
        getitem_504 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        relu__default_129 = torch.ops.aten.relu_.default(getitem_502);  getitem_502 = None
        cat_default_25 = torch.ops.aten.cat.default([relu__default_127, relu__default_128, relu__default_129, getitem_495], 1);  getitem_495 = None
        convolution_default_133 = torch.ops.aten.convolution.default(cat_default_25, primals_533, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_516, primals_512, primals_514, primals_515, True, 0.1, 1e-05);  primals_512 = None
        getitem_505 = native_batch_norm_default_133[0]
        getitem_506 = native_batch_norm_default_133[1]
        getitem_507 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        add__tensor_159 = torch.ops.aten.add_.Tensor(getitem_505, relu__default_125);  getitem_505 = None
        relu__default_130 = torch.ops.aten.relu_.default(add__tensor_159);  add__tensor_159 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_130, primals_562, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_541, primals_537, primals_539, primals_540, True, 0.1, 1e-05);  primals_537 = None
        getitem_508 = native_batch_norm_default_134[0]
        getitem_509 = native_batch_norm_default_134[1]
        getitem_510 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        relu__default_131 = torch.ops.aten.relu_.default(getitem_508);  getitem_508 = None
        split_tensor_26 = torch.ops.aten.split.Tensor(relu__default_131, 104, 1)
        getitem_511 = split_tensor_26[0]
        getitem_512 = split_tensor_26[1]
        getitem_513 = split_tensor_26[2]
        getitem_514 = split_tensor_26[3];  split_tensor_26 = None
        convolution_default_135 = torch.ops.aten.convolution.default(getitem_511, primals_564, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_551, primals_547, primals_549, primals_550, True, 0.1, 1e-05);  primals_547 = None
        getitem_515 = native_batch_norm_default_135[0]
        getitem_516 = native_batch_norm_default_135[1]
        getitem_517 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        relu__default_132 = torch.ops.aten.relu_.default(getitem_515);  getitem_515 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(relu__default_132, getitem_512);  getitem_512 = None
        convolution_default_136 = torch.ops.aten.convolution.default(add_tensor_46, primals_565, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_556, primals_552, primals_554, primals_555, True, 0.1, 1e-05);  primals_552 = None
        getitem_518 = native_batch_norm_default_136[0]
        getitem_519 = native_batch_norm_default_136[1]
        getitem_520 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        relu__default_133 = torch.ops.aten.relu_.default(getitem_518);  getitem_518 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(relu__default_133, getitem_513);  getitem_513 = None
        convolution_default_137 = torch.ops.aten.convolution.default(add_tensor_47, primals_566, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_561, primals_557, primals_559, primals_560, True, 0.1, 1e-05);  primals_557 = None
        getitem_521 = native_batch_norm_default_137[0]
        getitem_522 = native_batch_norm_default_137[1]
        getitem_523 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        relu__default_134 = torch.ops.aten.relu_.default(getitem_521);  getitem_521 = None
        cat_default_26 = torch.ops.aten.cat.default([relu__default_132, relu__default_133, relu__default_134, getitem_514], 1);  getitem_514 = None
        convolution_default_138 = torch.ops.aten.convolution.default(cat_default_26, primals_563, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_546, primals_542, primals_544, primals_545, True, 0.1, 1e-05);  primals_542 = None
        getitem_524 = native_batch_norm_default_138[0]
        getitem_525 = native_batch_norm_default_138[1]
        getitem_526 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        add__tensor_165 = torch.ops.aten.add_.Tensor(getitem_524, relu__default_130);  getitem_524 = None
        relu__default_135 = torch.ops.aten.relu_.default(add__tensor_165);  add__tensor_165 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu__default_135, primals_622, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_601, primals_597, primals_599, primals_600, True, 0.1, 1e-05);  primals_597 = None
        getitem_527 = native_batch_norm_default_139[0]
        getitem_528 = native_batch_norm_default_139[1]
        getitem_529 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        relu__default_136 = torch.ops.aten.relu_.default(getitem_527);  getitem_527 = None
        split_tensor_27 = torch.ops.aten.split.Tensor(relu__default_136, 104, 1)
        getitem_530 = split_tensor_27[0]
        getitem_531 = split_tensor_27[1]
        getitem_532 = split_tensor_27[2]
        getitem_533 = split_tensor_27[3];  split_tensor_27 = None
        convolution_default_140 = torch.ops.aten.convolution.default(getitem_530, primals_624, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_611, primals_607, primals_609, primals_610, True, 0.1, 1e-05);  primals_607 = None
        getitem_534 = native_batch_norm_default_140[0]
        getitem_535 = native_batch_norm_default_140[1]
        getitem_536 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        relu__default_137 = torch.ops.aten.relu_.default(getitem_534);  getitem_534 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(relu__default_137, getitem_531);  getitem_531 = None
        convolution_default_141 = torch.ops.aten.convolution.default(add_tensor_48, primals_625, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_616, primals_612, primals_614, primals_615, True, 0.1, 1e-05);  primals_612 = None
        getitem_537 = native_batch_norm_default_141[0]
        getitem_538 = native_batch_norm_default_141[1]
        getitem_539 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        relu__default_138 = torch.ops.aten.relu_.default(getitem_537);  getitem_537 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(relu__default_138, getitem_532);  getitem_532 = None
        convolution_default_142 = torch.ops.aten.convolution.default(add_tensor_49, primals_626, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_621, primals_617, primals_619, primals_620, True, 0.1, 1e-05);  primals_617 = None
        getitem_540 = native_batch_norm_default_142[0]
        getitem_541 = native_batch_norm_default_142[1]
        getitem_542 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        relu__default_139 = torch.ops.aten.relu_.default(getitem_540);  getitem_540 = None
        cat_default_27 = torch.ops.aten.cat.default([relu__default_137, relu__default_138, relu__default_139, getitem_533], 1);  getitem_533 = None
        convolution_default_143 = torch.ops.aten.convolution.default(cat_default_27, primals_623, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_606, primals_602, primals_604, primals_605, True, 0.1, 1e-05);  primals_602 = None
        getitem_543 = native_batch_norm_default_143[0]
        getitem_544 = native_batch_norm_default_143[1]
        getitem_545 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        add__tensor_171 = torch.ops.aten.add_.Tensor(getitem_543, relu__default_135);  getitem_543 = None
        relu__default_140 = torch.ops.aten.relu_.default(add__tensor_171);  add__tensor_171 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_140, primals_652, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_631, primals_627, primals_629, primals_630, True, 0.1, 1e-05);  primals_627 = None
        getitem_546 = native_batch_norm_default_144[0]
        getitem_547 = native_batch_norm_default_144[1]
        getitem_548 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        relu__default_141 = torch.ops.aten.relu_.default(getitem_546);  getitem_546 = None
        split_tensor_28 = torch.ops.aten.split.Tensor(relu__default_141, 104, 1)
        getitem_549 = split_tensor_28[0]
        getitem_550 = split_tensor_28[1]
        getitem_551 = split_tensor_28[2]
        getitem_552 = split_tensor_28[3];  split_tensor_28 = None
        convolution_default_145 = torch.ops.aten.convolution.default(getitem_549, primals_654, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_641, primals_637, primals_639, primals_640, True, 0.1, 1e-05);  primals_637 = None
        getitem_553 = native_batch_norm_default_145[0]
        getitem_554 = native_batch_norm_default_145[1]
        getitem_555 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        relu__default_142 = torch.ops.aten.relu_.default(getitem_553);  getitem_553 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(relu__default_142, getitem_550);  getitem_550 = None
        convolution_default_146 = torch.ops.aten.convolution.default(add_tensor_50, primals_655, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_646, primals_642, primals_644, primals_645, True, 0.1, 1e-05);  primals_642 = None
        getitem_556 = native_batch_norm_default_146[0]
        getitem_557 = native_batch_norm_default_146[1]
        getitem_558 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        relu__default_143 = torch.ops.aten.relu_.default(getitem_556);  getitem_556 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(relu__default_143, getitem_551);  getitem_551 = None
        convolution_default_147 = torch.ops.aten.convolution.default(add_tensor_51, primals_656, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_651, primals_647, primals_649, primals_650, True, 0.1, 1e-05);  primals_647 = None
        getitem_559 = native_batch_norm_default_147[0]
        getitem_560 = native_batch_norm_default_147[1]
        getitem_561 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        relu__default_144 = torch.ops.aten.relu_.default(getitem_559);  getitem_559 = None
        cat_default_28 = torch.ops.aten.cat.default([relu__default_142, relu__default_143, relu__default_144, getitem_552], 1);  getitem_552 = None
        convolution_default_148 = torch.ops.aten.convolution.default(cat_default_28, primals_653, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_636, primals_632, primals_634, primals_635, True, 0.1, 1e-05);  primals_632 = None
        getitem_562 = native_batch_norm_default_148[0]
        getitem_563 = native_batch_norm_default_148[1]
        getitem_564 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        add__tensor_177 = torch.ops.aten.add_.Tensor(getitem_562, relu__default_140);  getitem_562 = None
        relu__default_145 = torch.ops.aten.relu_.default(add__tensor_177);  add__tensor_177 = None
        convolution_default_149 = torch.ops.aten.convolution.default(relu__default_145, primals_682, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_661, primals_657, primals_659, primals_660, True, 0.1, 1e-05);  primals_657 = None
        getitem_565 = native_batch_norm_default_149[0]
        getitem_566 = native_batch_norm_default_149[1]
        getitem_567 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        relu__default_146 = torch.ops.aten.relu_.default(getitem_565);  getitem_565 = None
        split_tensor_29 = torch.ops.aten.split.Tensor(relu__default_146, 104, 1)
        getitem_568 = split_tensor_29[0]
        getitem_569 = split_tensor_29[1]
        getitem_570 = split_tensor_29[2]
        getitem_571 = split_tensor_29[3];  split_tensor_29 = None
        convolution_default_150 = torch.ops.aten.convolution.default(getitem_568, primals_684, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_671, primals_667, primals_669, primals_670, True, 0.1, 1e-05);  primals_667 = None
        getitem_572 = native_batch_norm_default_150[0]
        getitem_573 = native_batch_norm_default_150[1]
        getitem_574 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        relu__default_147 = torch.ops.aten.relu_.default(getitem_572);  getitem_572 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(relu__default_147, getitem_569);  getitem_569 = None
        convolution_default_151 = torch.ops.aten.convolution.default(add_tensor_52, primals_685, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_676, primals_672, primals_674, primals_675, True, 0.1, 1e-05);  primals_672 = None
        getitem_575 = native_batch_norm_default_151[0]
        getitem_576 = native_batch_norm_default_151[1]
        getitem_577 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        relu__default_148 = torch.ops.aten.relu_.default(getitem_575);  getitem_575 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(relu__default_148, getitem_570);  getitem_570 = None
        convolution_default_152 = torch.ops.aten.convolution.default(add_tensor_53, primals_686, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_681, primals_677, primals_679, primals_680, True, 0.1, 1e-05);  primals_677 = None
        getitem_578 = native_batch_norm_default_152[0]
        getitem_579 = native_batch_norm_default_152[1]
        getitem_580 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        relu__default_149 = torch.ops.aten.relu_.default(getitem_578);  getitem_578 = None
        cat_default_29 = torch.ops.aten.cat.default([relu__default_147, relu__default_148, relu__default_149, getitem_571], 1);  getitem_571 = None
        convolution_default_153 = torch.ops.aten.convolution.default(cat_default_29, primals_683, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_666, primals_662, primals_664, primals_665, True, 0.1, 1e-05);  primals_662 = None
        getitem_581 = native_batch_norm_default_153[0]
        getitem_582 = native_batch_norm_default_153[1]
        getitem_583 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        add__tensor_183 = torch.ops.aten.add_.Tensor(getitem_581, relu__default_145);  getitem_581 = None
        relu__default_150 = torch.ops.aten.relu_.default(add__tensor_183);  add__tensor_183 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu__default_150, primals_952, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_931, primals_927, primals_929, primals_930, True, 0.1, 1e-05);  primals_927 = None
        getitem_584 = native_batch_norm_default_154[0]
        getitem_585 = native_batch_norm_default_154[1]
        getitem_586 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        relu__default_151 = torch.ops.aten.relu_.default(getitem_584);  getitem_584 = None
        split_tensor_30 = torch.ops.aten.split.Tensor(relu__default_151, 208, 1)
        getitem_587 = split_tensor_30[0]
        getitem_588 = split_tensor_30[1]
        getitem_589 = split_tensor_30[2]
        getitem_590 = split_tensor_30[3];  split_tensor_30 = None
        convolution_default_155 = torch.ops.aten.convolution.default(getitem_587, primals_954, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_941, primals_937, primals_939, primals_940, True, 0.1, 1e-05);  primals_937 = None
        getitem_591 = native_batch_norm_default_155[0]
        getitem_592 = native_batch_norm_default_155[1]
        getitem_593 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        relu__default_152 = torch.ops.aten.relu_.default(getitem_591);  getitem_591 = None
        convolution_default_156 = torch.ops.aten.convolution.default(getitem_588, primals_955, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_946, primals_942, primals_944, primals_945, True, 0.1, 1e-05);  primals_942 = None
        getitem_594 = native_batch_norm_default_156[0]
        getitem_595 = native_batch_norm_default_156[1]
        getitem_596 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        relu__default_153 = torch.ops.aten.relu_.default(getitem_594);  getitem_594 = None
        convolution_default_157 = torch.ops.aten.convolution.default(getitem_589, primals_956, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_157 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_951, primals_947, primals_949, primals_950, True, 0.1, 1e-05);  primals_947 = None
        getitem_597 = native_batch_norm_default_157[0]
        getitem_598 = native_batch_norm_default_157[1]
        getitem_599 = native_batch_norm_default_157[2];  native_batch_norm_default_157 = None
        relu__default_154 = torch.ops.aten.relu_.default(getitem_597);  getitem_597 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(getitem_590, [3, 3], [2, 2], [1, 1])
        cat_default_30 = torch.ops.aten.cat.default([relu__default_152, relu__default_153, relu__default_154, avg_pool2d_default_3], 1);  avg_pool2d_default_3 = None
        convolution_default_158 = torch.ops.aten.convolution.default(cat_default_30, primals_953, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_158 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_936, primals_932, primals_934, primals_935, True, 0.1, 1e-05);  primals_932 = None
        getitem_600 = native_batch_norm_default_158[0]
        getitem_601 = native_batch_norm_default_158[1]
        getitem_602 = native_batch_norm_default_158[2];  native_batch_norm_default_158 = None
        convolution_default_159 = torch.ops.aten.convolution.default(relu__default_150, primals_957, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_159 = torch.ops.aten.native_batch_norm.default(convolution_default_159, primals_962, primals_958, primals_960, primals_961, True, 0.1, 1e-05);  primals_958 = None
        getitem_603 = native_batch_norm_default_159[0]
        getitem_604 = native_batch_norm_default_159[1]
        getitem_605 = native_batch_norm_default_159[2];  native_batch_norm_default_159 = None
        add__tensor_190 = torch.ops.aten.add_.Tensor(getitem_600, getitem_603);  getitem_600 = getitem_603 = None
        relu__default_155 = torch.ops.aten.relu_.default(add__tensor_190);  add__tensor_190 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu__default_155, primals_988, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_160 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_967, primals_963, primals_965, primals_966, True, 0.1, 1e-05);  primals_963 = None
        getitem_606 = native_batch_norm_default_160[0]
        getitem_607 = native_batch_norm_default_160[1]
        getitem_608 = native_batch_norm_default_160[2];  native_batch_norm_default_160 = None
        relu__default_156 = torch.ops.aten.relu_.default(getitem_606);  getitem_606 = None
        split_tensor_31 = torch.ops.aten.split.Tensor(relu__default_156, 208, 1)
        getitem_609 = split_tensor_31[0]
        getitem_610 = split_tensor_31[1]
        getitem_611 = split_tensor_31[2]
        getitem_612 = split_tensor_31[3];  split_tensor_31 = None
        convolution_default_161 = torch.ops.aten.convolution.default(getitem_609, primals_990, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_161 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_977, primals_973, primals_975, primals_976, True, 0.1, 1e-05);  primals_973 = None
        getitem_613 = native_batch_norm_default_161[0]
        getitem_614 = native_batch_norm_default_161[1]
        getitem_615 = native_batch_norm_default_161[2];  native_batch_norm_default_161 = None
        relu__default_157 = torch.ops.aten.relu_.default(getitem_613);  getitem_613 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(relu__default_157, getitem_610);  getitem_610 = None
        convolution_default_162 = torch.ops.aten.convolution.default(add_tensor_54, primals_991, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_162 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_982, primals_978, primals_980, primals_981, True, 0.1, 1e-05);  primals_978 = None
        getitem_616 = native_batch_norm_default_162[0]
        getitem_617 = native_batch_norm_default_162[1]
        getitem_618 = native_batch_norm_default_162[2];  native_batch_norm_default_162 = None
        relu__default_158 = torch.ops.aten.relu_.default(getitem_616);  getitem_616 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(relu__default_158, getitem_611);  getitem_611 = None
        convolution_default_163 = torch.ops.aten.convolution.default(add_tensor_55, primals_992, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_163 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_987, primals_983, primals_985, primals_986, True, 0.1, 1e-05);  primals_983 = None
        getitem_619 = native_batch_norm_default_163[0]
        getitem_620 = native_batch_norm_default_163[1]
        getitem_621 = native_batch_norm_default_163[2];  native_batch_norm_default_163 = None
        relu__default_159 = torch.ops.aten.relu_.default(getitem_619);  getitem_619 = None
        cat_default_31 = torch.ops.aten.cat.default([relu__default_157, relu__default_158, relu__default_159, getitem_612], 1);  getitem_612 = None
        convolution_default_164 = torch.ops.aten.convolution.default(cat_default_31, primals_989, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_164 = torch.ops.aten.native_batch_norm.default(convolution_default_164, primals_972, primals_968, primals_970, primals_971, True, 0.1, 1e-05);  primals_968 = None
        getitem_622 = native_batch_norm_default_164[0]
        getitem_623 = native_batch_norm_default_164[1]
        getitem_624 = native_batch_norm_default_164[2];  native_batch_norm_default_164 = None
        add__tensor_196 = torch.ops.aten.add_.Tensor(getitem_622, relu__default_155);  getitem_622 = None
        relu__default_160 = torch.ops.aten.relu_.default(add__tensor_196);  add__tensor_196 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_160, primals_1018, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_165 = torch.ops.aten.native_batch_norm.default(convolution_default_165, primals_997, primals_993, primals_995, primals_996, True, 0.1, 1e-05);  primals_993 = None
        getitem_625 = native_batch_norm_default_165[0]
        getitem_626 = native_batch_norm_default_165[1]
        getitem_627 = native_batch_norm_default_165[2];  native_batch_norm_default_165 = None
        relu__default_161 = torch.ops.aten.relu_.default(getitem_625);  getitem_625 = None
        split_tensor_32 = torch.ops.aten.split.Tensor(relu__default_161, 208, 1)
        getitem_628 = split_tensor_32[0]
        getitem_629 = split_tensor_32[1]
        getitem_630 = split_tensor_32[2]
        getitem_631 = split_tensor_32[3];  split_tensor_32 = None
        convolution_default_166 = torch.ops.aten.convolution.default(getitem_628, primals_1020, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_166 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_1007, primals_1003, primals_1005, primals_1006, True, 0.1, 1e-05);  primals_1003 = None
        getitem_632 = native_batch_norm_default_166[0]
        getitem_633 = native_batch_norm_default_166[1]
        getitem_634 = native_batch_norm_default_166[2];  native_batch_norm_default_166 = None
        relu__default_162 = torch.ops.aten.relu_.default(getitem_632);  getitem_632 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(relu__default_162, getitem_629);  getitem_629 = None
        convolution_default_167 = torch.ops.aten.convolution.default(add_tensor_56, primals_1021, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_167 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_1012, primals_1008, primals_1010, primals_1011, True, 0.1, 1e-05);  primals_1008 = None
        getitem_635 = native_batch_norm_default_167[0]
        getitem_636 = native_batch_norm_default_167[1]
        getitem_637 = native_batch_norm_default_167[2];  native_batch_norm_default_167 = None
        relu__default_163 = torch.ops.aten.relu_.default(getitem_635);  getitem_635 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(relu__default_163, getitem_630);  getitem_630 = None
        convolution_default_168 = torch.ops.aten.convolution.default(add_tensor_57, primals_1022, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_168 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_1017, primals_1013, primals_1015, primals_1016, True, 0.1, 1e-05);  primals_1013 = None
        getitem_638 = native_batch_norm_default_168[0]
        getitem_639 = native_batch_norm_default_168[1]
        getitem_640 = native_batch_norm_default_168[2];  native_batch_norm_default_168 = None
        relu__default_164 = torch.ops.aten.relu_.default(getitem_638);  getitem_638 = None
        cat_default_32 = torch.ops.aten.cat.default([relu__default_162, relu__default_163, relu__default_164, getitem_631], 1);  getitem_631 = None
        convolution_default_169 = torch.ops.aten.convolution.default(cat_default_32, primals_1019, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_169 = torch.ops.aten.native_batch_norm.default(convolution_default_169, primals_1002, primals_998, primals_1000, primals_1001, True, 0.1, 1e-05);  primals_998 = None
        getitem_641 = native_batch_norm_default_169[0]
        getitem_642 = native_batch_norm_default_169[1]
        getitem_643 = native_batch_norm_default_169[2];  native_batch_norm_default_169 = None
        add__tensor_202 = torch.ops.aten.add_.Tensor(getitem_641, relu__default_160);  getitem_641 = None
        relu__default_165 = torch.ops.aten.relu_.default(add__tensor_202);  add__tensor_202 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_165, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default, t_default);  primals_7 = None
        return [addmm_default, primals_325, getitem_20, primals_321, relu__default_42, primals_574, primals_322, primals_575, getitem_19, primals_323, relu__default_4, primals_576, getitem_251, primals_324, getitem_250, primals_326, getitem_178, getitem_177, primals_579, convolution_default_5, relu__default_62, primals_580, getitem_23, getitem_22, primals_581, primals_329, cat_default, relu__default_43, primals_330, add_tensor_18, primals_335, primals_331, primals_584, add_tensor_11, primals_585, convolution_default_6, getitem_254, getitem_253, primals_586, primals_334, cat_default_8, getitem_180, primals_336, getitem_25, relu__default_63, getitem_181, primals_589, primals_590, relu__default_44, convolution_default_67, primals_339, primals_591, add_tensor_19, relu__default_5, primals_592, getitem_26, primals_340, primals_593, convolution_default_7, convolution_default_73, primals_341, getitem_548, getitem_200, getitem_199, getitem_526, relu__default_141, primals_449, getitem_525, primals_450, getitem_549, relu__default_49, primals_451, convolution_default_146, convolution_default_145, convolution_default_147, primals_454, primals_455, relu__default_135, convolution_default_153, getitem_203, primals_456, cat_default_9, convolution_default_139, getitem_202, getitem_555, getitem_554, getitem_529, getitem_530, getitem_528, primals_459, primals_460, relu__default_142, primals_461, relu__default_136, relu__default_50, convolution_default_54, add_tensor_50, primals_464, convolution_default_140, primals_465, primals_466, getitem_205, convolution_default_143, convolution_default_59, relu__default_55, getitem_226, getitem_225, getitem_224, relu__default_56, convolution_default_61, convolution_default_66, convolution_default_60, add_tensor_16, getitem_231, getitem_232, primals_972, getitem_500, getitem_501, relu__default_128, primals_975, primals_976, add_tensor_45, primals_977, getitem_506, getitem_504, convolution_default, getitem_503, primals_980, primals_981, primals_982, relu__default_129, primals_985, primals_986, primals_987, primals_988, cat_default_25, primals_989, convolution_default_137, primals_990, primals_991, getitem_507, primals_992, primals_846, getitem_153, primals_849, getitem_152, getitem_479, getitem_478, primals_850, primals_79, primals_851, relu__default_37, relu__default_122, primals_78, primals_73, primals_854, primals_74, convolution_default_40, primals_855, add_tensor_42, primals_77, primals_856, primals_89, getitem_156, primals_87, getitem_155, primals_82, getitem_482, getitem_481, primals_859, primals_860, relu__default_38, primals_861, relu__default_123, primals_88, primals_862, primals_84, primals_863, convolution_default_41, convolution_default_127, primals_864, add_tensor_43, primals_83, primals_865, primals_866, convolution_default_133, primals_195, primals_720, primals_196, primals_721, convolution_default_160, primals_197, getitem_128, primals_198, primals_199, getitem_127, primals_724, getitem_126, primals_200, getitem_608, primals_725, getitem_609, getitem_607, primals_726, relu__default_31, primals_203, relu__default_156, primals_204, primals_729, primals_205, primals_730, getitem_133, primals_731, convolution_default_35, primals_208, convolution_default_162, primals_209, convolution_default_47, primals_734, primals_210, convolution_default_48, convolution_default_167, convolution_default_34, primals_735, convolution_default_169, convolution_default_161, primals_736, add_tensor_8, add_tensor_54, primals_213, primals_214, getitem_134, primals_739, getitem_614, primals_215, primals_740, getitem_615, primals_594, convolution_default_119, primals_595, relu__default_18, relu__default_115, getitem_77, primals_344, primals_596, convolution_default_20, getitem_454, primals_345, primals_346, getitem_453, getitem_452, primals_599, getitem_80, primals_600, getitem_79, primals_349, primals_601, relu__default_116, primals_350, relu__default_19, primals_351, primals_604, primals_356, primals_352, primals_605, primals_353, primals_606, primals_354, convolution_default_121, primals_355, convolution_default_126, getitem_82, primals_609, convolution_default_120, convolution_default_21, primals_610, cat_default_3, add_tensor_40, primals_359, primals_611, primals_360, getitem_459, primals_361, convolution_default_22, getitem_460, getitem_83, primals_614, getitem_102, getitem_101, relu__default_102, primals_469, primals_470, primals_995, primals_471, primals_996, relu__default_24, primals_472, primals_997, primals_473, getitem_406, getitem_405, primals_474, primals_475, primals_1000, primals_5, getitem_105, primals_476, primals_1001, cat_default_4, relu__default_103, primals_1002, getitem_104, primals_6, primals_479, add_tensor_35, primals_480, primals_1005, primals_481, primals_1006, cat_default_20, primals_1007, relu__default_25, convolution_default_28, getitem_408, getitem_409, primals_484, primals_485, primals_1010, relu__default_104, primals_486, primals_1011, primals_1012, getitem_107, getitem_108, convolution_default_26, getitem_428, getitem_427, getitem_355, getitem_583, primals_869, getitem_55, getitem_354, getitem_582, getitem_54, primals_870, getitem_634, primals_871, relu__default_109, getitem_633, relu__default_12, primals_874, relu__default_162, primals_875, relu__default_90, relu__default_150, add_tensor_2, getitem_431, primals_876, convolution_default_94, cat_default_21, convolution_default_154, getitem_430, add_tensor_56, getitem_58, getitem_358, getitem_586, getitem_359, getitem_587, getitem_57, getitem_357, getitem_585, primals_879, getitem_637, primals_880, getitem_636, primals_881, relu__default_13, relu__default_91, relu__default_151, relu__default_110, convolution_default_114, relu__default_163, primals_884, add_tensor_3, getitem_588, convolution_default_95, convolution_default_155, primals_885, convolution_default_168, add_tensor_57, primals_886, getitem_433, getitem_589, convolution_default_98, primals_741, getitem_377, primals_742, primals_218, getitem_30, relu__default_96, primals_743, primals_219, primals_744, getitem_378, getitem_29, primals_220, getitem_28, primals_745, convolution_default_101, primals_746, convolution_default_100, relu__default_6, convolution_default_102, primals_223, primals_749, convolution_default_108, primals_224, primals_750, primals_225, primals_751, getitem_384, primals_226, getitem_383, primals_227, convolution_default_9, primals_228, primals_754, convolution_default_14, primals_229, relu__default_97, primals_755, convolution_default_15, primals_230, convolution_default_8, primals_756, getitem_35, add_tensor_32, primals_233, primals_759, primals_234, add_tensor, primals_760, primals_235, getitem_36, primals_761, getitem_329, primals_615, getitem_557, primals_114, primals_113, primals_33, getitem_257, getitem_330, primals_616, getitem_256, getitem_558, primals_31, primals_37, relu__default_83, relu__default_143, getitem_308, getitem_536, primals_27, getitem_307, getitem_535, primals_34, primals_619, relu__default_64, primals_117, primals_119, primals_118, add_tensor_27, add_tensor_51, primals_36, primals_620, getitem_335, getitem_563, primals_621, relu__default_77, relu__default_137, primals_622, getitem_333, getitem_561, primals_32, getitem_332, getitem_560, primals_623, primals_112, getitem_260, primals_624, cat_default_12, add_tensor_24, add_tensor_48, getitem_259, primals_625, relu__default_84, relu__default_144, primals_23, primals_38, primals_626, primals_122, getitem_311, getitem_539, primals_28, primals_123, getitem_310, getitem_538, primals_124, primals_26, primals_39, primals_629, relu__default_65, primals_630, convolution_default_69, relu__default_78, relu__default_138, primals_35, primals_127, primals_631, cat_default_16, cat_default_28, primals_128, convolution_default_92, convolution_default_152, convolution_default_82, convolution_default_142, primals_129, add_tensor_25, add_tensor_49, primals_130, primals_634, getitem_336, getitem_564, getitem_262, primals_131, primals_635, convolution_default_88, convolution_default_148, convolution_default_74, getitem_206, relu__default_57, relu__default_70, relu__default_51, getitem_283, getitem_207, convolution_default_56, getitem_282, getitem_281, convolution_default_55, getitem_235, getitem_234, convolution_default_57, relu__default_71, convolution_default_63, relu__default_58, getitem_213, getitem_212, add_tensor_17, convolution_default_76, relu__default_52, cat_default_11, convolution_default_81, getitem_237, convolution_default_75, getitem_238, add_tensor_22, add_tensor_14, relu__default_59, getitem_288, getitem_289, primals_489, primals_490, primals_1015, getitem_184, primals_491, primals_1016, getitem_183, primals_1017, primals_1018, primals_494, primals_1019, primals_495, primals_1020, primals_496, primals_1021, primals_1022, relu__default_45, primals_1023, convolution_default_49, primals_499, primals_500, getitem_187, getitem_188, getitem_186, primals_501, primals_502, primals_503, relu__default_46, primals_504, primals_505, primals_506, convolution_default_50, primals_509, convolution_default_53, convolution_default_134, getitem_158, getitem_485, primals_364, primals_889, getitem_484, relu__default_130, getitem_159, primals_365, primals_890, getitem_511, primals_366, primals_891, relu__default_39, primals_892, relu__default_124, getitem_510, getitem_509, primals_893, primals_369, primals_894, primals_370, primals_895, relu__default_131, primals_371, primals_896, getitem_162, getitem_488, convolution_default_42, getitem_161, cat_default_24, cat_default_7, getitem_487, primals_374, primals_899, primals_375, primals_900, convolution_default_136, relu__default_40, primals_376, primals_901, convolution_default_43, convolution_default_141, relu__default_125, convolution_default_135, convolution_default_129, primals_379, primals_904, add_tensor_46, primals_380, primals_905, primals_381, primals_906, getitem_1, getitem_164, getitem_516, primals_382, getitem_165, getitem_517, getitem_490, primals_383, relu__default_26, primals_764, getitem_109, primals_765, convolution_default_30, primals_766, convolution_default_29, convolution_default_31, primals_769, convolution_default_37, primals_770, primals_771, getitem_115, primals_772, getitem_114, primals_773, primals_774, primals_775, relu__default_27, primals_776, add_tensor_6, primals_779, add_tensor_7, primals_780, primals_781, getitem_117, primals_636, primals_238, primals_239, primals_240, primals_639, primals_640, primals_641, primals_243, primals_244, primals_644, primals_245, primals_645, primals_646, primals_248, primals_249, primals_250, primals_649, primals_650, primals_651, primals_652, primals_253, primals_653, primals_254, primals_654, primals_255, convolution_default_11, primals_655, primals_256, primals_656, primals_257, primals_510, relu__default_32, primals_511, primals_3, primals_514, getitem_137, primals_515, getitem_136, primals_516, relu__default_33, primals_4, primals_519, primals_520, add_tensor_9, primals_521, primals_524, getitem_139, primals_525, getitem_140, primals_526, relu__default_34, primals_529, primals_530, cat_default_6, primals_384, relu__default, primals_385, getitem_412, relu__default_157, primals_102, getitem_2, primals_386, primals_107, getitem_86, getitem_411, relu__default_20, getitem_85, getitem_3, primals_93, primals_97, primals_389, getitem_618, primals_390, convolution_default_1, getitem_617, primals_92, primals_391, convolution_default_23, getitem_8, primals_99, relu__default_105, getitem_4, convolution_default_109, relu__default_158, getitem_7, getitem_6, primals_394, getitem_89, getitem_90, primals_395, getitem_88, getitem_415, getitem_416, getitem_414, add_tensor_55, primals_396, relu__default_1, primals_94, primals_101, relu__default_21, cat_default_31, relu__default_106, primals_399, getitem_620, getitem_9, primals_400, convolution_default_2, getitem_621, primals_98, primals_100, primals_104, primals_401, convolution_default_24, convolution_default_110, getitem_10, relu__default_159, getitem_11, primals_108, primals_109, convolution_default_27, primals_404, primals_103, convolution_default_113, getitem_590, primals_258, getitem_60, relu__default_117, primals_259, primals_260, relu__default_14, primals_261, getitem_365, getitem_593, getitem_364, getitem_592, getitem_61, getitem_463, getitem_462, primals_264, relu__default_92, relu__default_152, getitem_64, primals_265, cat_default_2, primals_266, getitem_63, relu__default_118, convolution_default_156, add_tensor_30, add_tensor_41, primals_269, getitem_596, getitem_368, getitem_595, primals_270, getitem_367, primals_275, relu__default_15, cat_default_23, primals_271, convolution_default_17, getitem_465, relu__default_153, relu__default_93, getitem_466, primals_274, convolution_default_97, relu__default_119, convolution_default_157, add_tensor_31, primals_276, getitem_66, getitem_67, convolution_default_103, getitem_434, primals_909, getitem_387, primals_910, relu__default_111, primals_911, getitem_386, relu__default_98, getitem_435, convolution_default_116, add_tensor_33, primals_914, convolution_default_115, getitem_392, primals_915, convolution_default_117, primals_916, getitem_390, getitem_389, convolution_default_123, primals_919, getitem_441, relu__default_99, getitem_440, primals_920, primals_921, primals_922, relu__default_112, primals_923, primals_924, primals_925, cat_default_19, add_tensor_38, primals_926, convolution_default_107, getitem_393, primals_929, convolution_default_89, relu__default_7, relu__default_72, getitem_314, primals_784, getitem_313, relu__default_85, getitem_640, getitem_639, primals_785, getitem_340, primals_786, relu__default_79, getitem_39, getitem_339, relu__default_164, getitem_38, getitem_338, getitem_292, getitem_291, primals_789, primals_790, relu__default_8, relu__default_86, primals_791, getitem_317, relu__default_73, getitem_643, cat_default_15, getitem_316, cat_default_32, getitem_642, add_tensor_1, primals_794, add_tensor_23, primals_795, convolution_default_91, primals_796, cat_default_14, getitem_41, convolution_default_96, getitem_42, relu__default_80, getitem_294, convolution_default_90, relu__default_165, convolution_default_84, getitem_295, primals_799, add_tensor_28, relu__default_9, primals_800, view_default, relu__default_74, primals_801, getitem_345, primals_802, getitem_346, getitem_319, primals_803, cat_default_1, t_default, getitem_542, getitem_541, primals_659, primals_660, primals_661, relu__default_139, primals_664, primals_665, getitem_545, primals_666, cat_default_27, getitem_544, primals_669, primals_670, primals_671, relu__default_140, convolution_default_144, primals_674, primals_675, primals_676, getitem_547, convolution_default_149, primals_531, convolution_default_3, getitem_263, primals_532, relu__default_145, getitem_14, relu__default_66, primals_533, getitem_13, getitem_568, primals_534, getitem_264, getitem_194, getitem_193, primals_535, convolution_default_71, getitem_567, getitem_566, primals_536, relu__default_2, convolution_default_70, relu__default_47, convolution_default_72, relu__default_146, primals_539, convolution_default_78, primals_540, add_tensor_12, primals_541, getitem_270, getitem_17, getitem_269, getitem_16, getitem_197, convolution_default_151, getitem_196, primals_544, relu__default_67, relu__default_3, primals_545, convolution_default_163, primals_546, convolution_default_164, convolution_default_150, relu__default_48, add_tensor_52, add_tensor_20, convolution_default_4, convolution_default_10, convolution_default_52, primals_549, add_tensor_13, getitem_573, primals_550, getitem_574, primals_551, convolution_default_58, primals_405, relu__default_132, primals_406, primals_409, primals_410, getitem_520, getitem_519, primals_411, primals_412, primals_413, relu__default_133, primals_414, primals_415, primals_416, add_tensor_47, cat_default_26, primals_419, primals_420, getitem_522, getitem_523, primals_421, relu__default_134, primals_424, primals_425, primals_153, primals_930, getitem_215, primals_154, convolution_default_44, primals_931, getitem_216, primals_155, getitem_241, getitem_240, relu__default_53, primals_934, getitem_168, primals_158, getitem_169, getitem_167, add_tensor_15, primals_935, getitem_221, primals_159, primals_936, primals_160, getitem_219, relu__default_41, getitem_218, relu__default_60, primals_939, convolution_default_64, primals_163, primals_940, relu__default_54, primals_164, primals_941, getitem_244, getitem_245, primals_165, getitem_243, convolution_default_46, primals_166, primals_167, primals_944, convolution_default_51, relu__default_61, primals_168, primals_945, convolution_default_45, primals_169, primals_946, add_tensor_10, cat_default_10, primals_170, convolution_default_62, convolution_default_65, getitem_174, primals_949, getitem_175, getitem_222, primals_173, primals_950, convolution_default_68, primals_279, primals_804, getitem_143, primals_280, primals_805, relu__default_35, getitem_142, primals_281, primals_806, primals_284, primals_809, primals_285, primals_810, primals_286, primals_811, convolution_default_38, primals_289, primals_814, getitem_146, primals_290, primals_815, getitem_147, getitem_145, primals_291, primals_816, primals_292, primals_293, relu__default_36, primals_294, primals_819, primals_295, primals_820, getitem_148, primals_296, primals_821, convolution_default_39, getitem_149, primals_299, primals_824, getitem_150, getitem_491, primals_679, getitem_469, relu__default_126, getitem_624, primals_680, primals_49, getitem_468, primals_681, getitem_492, getitem_623, primals_682, convolution_default_131, primals_683, convolution_default_130, primals_684, primals_43, convolution_default_132, primals_685, primals_686, relu__default_120, convolution_default_138, relu__default_160, convolution_default_124, convolution_default_165, getitem_498, getitem_497, primals_689, getitem_472, getitem_473, getitem_471, getitem_627, primals_690, getitem_628, getitem_626, primals_52, primals_691, relu__default_127, primals_44, relu__default_121, primals_47, relu__default_161, primals_694, add_tensor_44, primals_695, convolution_default_125, primals_696, convolution_default_166, primals_42, primals_48, convolution_default_128, getitem_599, convolution_default_36, getitem_598, primals_554, primals_57, getitem_96, primals_555, getitem_95, relu__default_154, primals_556, primals_59, relu__default_22, primals_54, primals_64, primals_68, primals_559, primals_560, add_tensor_4, getitem_602, primals_561, convolution_default_158, getitem_601, primals_58, primals_562, cat_default_30, primals_72, primals_563, primals_53, primals_63, getitem_99, primals_564, getitem_98, primals_67, primals_565, relu__default_155, convolution_default_159, primals_566, primals_71, relu__default_23, primals_69, primals_569, add_tensor_5, primals_570, primals_70, primals_571, getitem_604, convolution_default_32, getitem_605, primals_62, primals_132, getitem_443, primals_426, primals_133, getitem_118, getitem_444, primals_138, primals_22, primals_134, primals_12, relu__default_28, relu__default_113, primals_135, primals_429, getitem_422, getitem_421, primals_430, add_tensor_39, primals_431, getitem_449, primals_139, relu__default_107, getitem_121, getitem_120, getitem_447, primals_140, getitem_446, primals_434, primals_435, add_tensor_36, primals_436, relu__default_29, primals_13, relu__default_114, primals_143, primals_11, primals_144, getitem_425, getitem_424, primals_145, primals_439, primals_440, primals_17, primals_441, cat_default_5, relu__default_108, primals_18, primals_148, primals_21, primals_442, cat_default_22, primals_16, primals_149, relu__default_30, primals_443, convolution_default_122, convolution_default_112, primals_150, primals_444, convolution_default_33, add_tensor_37, getitem_123, getitem_124, primals_445, getitem_450, primals_446, convolution_default_118, primals_174, primals_300, primals_951, convolution_default_104, primals_175, relu__default_87, getitem_371, relu__default_147, primals_301, primals_952, getitem_370, relu__default_100, primals_953, getitem_397, primals_954, primals_178, primals_304, primals_955, relu__default_94, getitem_396, getitem_395, primals_179, primals_305, primals_956, getitem_349, getitem_577, primals_180, getitem_348, getitem_576, primals_306, primals_957, relu__default_101, getitem_374, relu__default_88, relu__default_148, primals_183, primals_309, primals_960, cat_default_18, getitem_373, primals_184, primals_310, primals_961, primals_185, primals_311, primals_962, add_tensor_29, add_tensor_53, convolution_default_106, cat_default_17, cat_default_29, primals_188, primals_314, primals_965, convolution_default_111, relu__default_95, primals_189, primals_315, primals_966, getitem_351, convolution_default_105, getitem_579, convolution_default_99, primals_190, getitem_352, getitem_580, primals_316, primals_967, add_tensor_34, relu__default_89, relu__default_149, primals_193, getitem_402, primals_319, primals_970, getitem_403, primals_194, getitem_376, primals_320, primals_971, primals_825, getitem_45, relu__default_16, primals_826, getitem_298, getitem_68, getitem_44, getitem_297, getitem_69, primals_829, convolution_default_18, getitem_70, primals_830, getitem_71, primals_831, primals_832, primals_833, convolution_default_12, relu__default_75, relu__default_10, primals_834, convolution_default_79, getitem_74, getitem_73, primals_835, getitem_48, getitem_49, getitem_47, primals_836, getitem_301, getitem_302, getitem_300, relu__default_17, relu__default_11, primals_839, relu__default_76, primals_840, convolution_default_19, primals_841, convolution_default_13, convolution_default_80, primals_844, convolution_default_16, getitem_76, primals_845, convolution_default_25, convolution_default_83, primals_699, getitem_320, getitem_273, primals_700, relu__default_81, primals_701, getitem_272, relu__default_68, getitem_321, convolution_default_86, add_tensor_21, primals_704, convolution_default_85, getitem_278, primals_705, convolution_default_87, primals_706, getitem_276, getitem_275, convolution_default_93, primals_709, getitem_327, relu__default_69, getitem_326, primals_710, primals_711, primals_712, relu__default_82, primals_713, primals_714, primals_715, cat_default_13, add_tensor_26, primals_716, convolution_default_77, getitem_279, primals_719]
        
