
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/res2net101_26w_4s/res2net101_26w_4s_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_325, getitem_20, primals_321, relu__default_42, primals_574, primals_322, primals_575, getitem_19, primals_323, relu__default_4, primals_576, getitem_251, primals_324, getitem_250, primals_326, getitem_178, getitem_177, primals_579, convolution_default_5, relu__default_62, primals_580, getitem_23, getitem_22, primals_581, primals_329, cat_default, relu__default_43, primals_330, add_tensor_18, primals_335, primals_331, primals_584, add_tensor_11, primals_585, convolution_default_6, getitem_254, getitem_253, primals_586, primals_334, cat_default_8, getitem_180, primals_336, getitem_25, relu__default_63, getitem_181, primals_589, primals_590, relu__default_44, convolution_default_67, primals_339, primals_591, add_tensor_19, relu__default_5, primals_592, getitem_26, primals_340, primals_593, convolution_default_7, convolution_default_73, primals_341, getitem_548, getitem_200, getitem_199, getitem_526, relu__default_141, primals_449, getitem_525, primals_450, getitem_549, relu__default_49, primals_451, convolution_default_146, convolution_default_145, convolution_default_147, primals_454, primals_455, relu__default_135, convolution_default_153, getitem_203, primals_456, cat_default_9, convolution_default_139, getitem_202, getitem_555, getitem_554, getitem_529, getitem_530, getitem_528, primals_459, primals_460, relu__default_142, primals_461, relu__default_136, relu__default_50, convolution_default_54, add_tensor_50, primals_464, convolution_default_140, primals_465, primals_466, getitem_205, convolution_default_143, convolution_default_59, relu__default_55, getitem_226, getitem_225, getitem_224, relu__default_56, convolution_default_61, convolution_default_66, convolution_default_60, add_tensor_16, getitem_231, getitem_232, primals_972, getitem_500, getitem_501, relu__default_128, primals_975, primals_976, add_tensor_45, primals_977, getitem_506, getitem_504, convolution_default, getitem_503, primals_980, primals_981, primals_982, relu__default_129, primals_985, primals_986, primals_987, primals_988, cat_default_25, primals_989, convolution_default_137, primals_990, primals_991, getitem_507, primals_992, primals_846, getitem_153, primals_849, getitem_152, getitem_479, getitem_478, primals_850, primals_79, primals_851, relu__default_37, relu__default_122, primals_78, primals_73, primals_854, primals_74, convolution_default_40, primals_855, add_tensor_42, primals_77, primals_856, primals_89, getitem_156, primals_87, getitem_155, primals_82, getitem_482, getitem_481, primals_859, primals_860, relu__default_38, primals_861, relu__default_123, primals_88, primals_862, primals_84, primals_863, convolution_default_41, convolution_default_127, primals_864, add_tensor_43, primals_83, primals_865, primals_866, convolution_default_133, primals_195, primals_720, primals_196, primals_721, convolution_default_160, primals_197, getitem_128, primals_198, primals_199, getitem_127, primals_724, getitem_126, primals_200, getitem_608, primals_725, getitem_609, getitem_607, primals_726, relu__default_31, primals_203, relu__default_156, primals_204, primals_729, primals_205, primals_730, getitem_133, primals_731, convolution_default_35, primals_208, convolution_default_162, primals_209, convolution_default_47, primals_734, primals_210, convolution_default_48, convolution_default_167, convolution_default_34, primals_735, convolution_default_169, convolution_default_161, primals_736, add_tensor_8, add_tensor_54, primals_213, primals_214, getitem_134, primals_739, getitem_614, primals_215, primals_740, getitem_615, primals_594, convolution_default_119, primals_595, relu__default_18, relu__default_115, getitem_77, primals_344, primals_596, convolution_default_20, getitem_454, primals_345, primals_346, getitem_453, getitem_452, primals_599, getitem_80, primals_600, getitem_79, primals_349, primals_601, relu__default_116, primals_350, relu__default_19, primals_351, primals_604, primals_356, primals_352, primals_605, primals_353, primals_606, primals_354, convolution_default_121, primals_355, convolution_default_126, getitem_82, primals_609, convolution_default_120, convolution_default_21, primals_610, cat_default_3, add_tensor_40, primals_359, primals_611, primals_360, getitem_459, primals_361, convolution_default_22, getitem_460, getitem_83, primals_614, getitem_102, getitem_101, relu__default_102, primals_469, primals_470, primals_995, primals_471, primals_996, relu__default_24, primals_472, primals_997, primals_473, getitem_406, getitem_405, primals_474, primals_475, primals_1000, primals_5, getitem_105, primals_476, primals_1001, cat_default_4, relu__default_103, primals_1002, getitem_104, primals_6, primals_479, add_tensor_35, primals_480, primals_1005, primals_481, primals_1006, cat_default_20, primals_1007, relu__default_25, convolution_default_28, getitem_408, getitem_409, primals_484, primals_485, primals_1010, relu__default_104, primals_486, primals_1011, primals_1012, getitem_107, getitem_108, convolution_default_26, getitem_428, getitem_427, getitem_355, getitem_583, primals_869, getitem_55, getitem_354, getitem_582, getitem_54, primals_870, getitem_634, primals_871, relu__default_109, getitem_633, relu__default_12, primals_874, relu__default_162, primals_875, relu__default_90, relu__default_150, add_tensor_2, getitem_431, primals_876, convolution_default_94, cat_default_21, convolution_default_154, getitem_430, add_tensor_56, getitem_58, getitem_358, getitem_586, getitem_359, getitem_587, getitem_57, getitem_357, getitem_585, primals_879, getitem_637, primals_880, getitem_636, primals_881, relu__default_13, relu__default_91, relu__default_151, relu__default_110, convolution_default_114, relu__default_163, primals_884, add_tensor_3, getitem_588, convolution_default_95, convolution_default_155, primals_885, convolution_default_168, add_tensor_57, primals_886, getitem_433, getitem_589, convolution_default_98, primals_741, getitem_377, primals_742, primals_218, getitem_30, relu__default_96, primals_743, primals_219, primals_744, getitem_378, getitem_29, primals_220, getitem_28, primals_745, convolution_default_101, primals_746, convolution_default_100, relu__default_6, convolution_default_102, primals_223, primals_749, convolution_default_108, primals_224, primals_750, primals_225, primals_751, getitem_384, primals_226, getitem_383, primals_227, convolution_default_9, primals_228, primals_754, convolution_default_14, primals_229, relu__default_97, primals_755, convolution_default_15, primals_230, convolution_default_8, primals_756, getitem_35, add_tensor_32, primals_233, primals_759, primals_234, add_tensor, primals_760, primals_235, getitem_36, primals_761, getitem_329, primals_615, getitem_557, primals_114, primals_113, primals_33, getitem_257, getitem_330, primals_616, getitem_256, getitem_558, primals_31, primals_37, relu__default_83, relu__default_143, getitem_308, getitem_536, primals_27, getitem_307, getitem_535, primals_34, primals_619, relu__default_64, primals_117, primals_119, primals_118, add_tensor_27, add_tensor_51, primals_36, primals_620, getitem_335, getitem_563, primals_621, relu__default_77, relu__default_137, primals_622, getitem_333, getitem_561, primals_32, getitem_332, getitem_560, primals_623, primals_112, getitem_260, primals_624, cat_default_12, add_tensor_24, add_tensor_48, getitem_259, primals_625, relu__default_84, relu__default_144, primals_23, primals_38, primals_626, primals_122, getitem_311, getitem_539, primals_28, primals_123, getitem_310, getitem_538, primals_124, primals_26, primals_39, primals_629, relu__default_65, primals_630, convolution_default_69, relu__default_78, relu__default_138, primals_35, primals_127, primals_631, cat_default_16, cat_default_28, primals_128, convolution_default_92, convolution_default_152, convolution_default_82, convolution_default_142, primals_129, add_tensor_25, add_tensor_49, primals_130, primals_634, getitem_336, getitem_564, getitem_262, primals_131, primals_635, convolution_default_88, convolution_default_148, convolution_default_74, getitem_206, relu__default_57, relu__default_70, relu__default_51, getitem_283, getitem_207, convolution_default_56, getitem_282, getitem_281, convolution_default_55, getitem_235, getitem_234, convolution_default_57, relu__default_71, convolution_default_63, relu__default_58, getitem_213, getitem_212, add_tensor_17, convolution_default_76, relu__default_52, cat_default_11, convolution_default_81, getitem_237, convolution_default_75, getitem_238, add_tensor_22, add_tensor_14, relu__default_59, getitem_288, getitem_289, primals_489, primals_490, primals_1015, getitem_184, primals_491, primals_1016, getitem_183, primals_1017, primals_1018, primals_494, primals_1019, primals_495, primals_1020, primals_496, primals_1021, primals_1022, relu__default_45, primals_1023, convolution_default_49, primals_499, primals_500, getitem_187, getitem_188, getitem_186, primals_501, primals_502, primals_503, relu__default_46, primals_504, primals_505, primals_506, convolution_default_50, primals_509, convolution_default_53, convolution_default_134, getitem_158, getitem_485, primals_364, primals_889, getitem_484, relu__default_130, getitem_159, primals_365, primals_890, getitem_511, primals_366, primals_891, relu__default_39, primals_892, relu__default_124, getitem_510, getitem_509, primals_893, primals_369, primals_894, primals_370, primals_895, relu__default_131, primals_371, primals_896, getitem_162, getitem_488, convolution_default_42, getitem_161, cat_default_24, cat_default_7, getitem_487, primals_374, primals_899, primals_375, primals_900, convolution_default_136, relu__default_40, primals_376, primals_901, convolution_default_43, convolution_default_141, relu__default_125, convolution_default_135, convolution_default_129, primals_379, primals_904, add_tensor_46, primals_380, primals_905, primals_381, primals_906, getitem_1, getitem_164, getitem_516, primals_382, getitem_165, getitem_517, getitem_490, primals_383, relu__default_26, primals_764, getitem_109, primals_765, convolution_default_30, primals_766, convolution_default_29, convolution_default_31, primals_769, convolution_default_37, primals_770, primals_771, getitem_115, primals_772, getitem_114, primals_773, primals_774, primals_775, relu__default_27, primals_776, add_tensor_6, primals_779, add_tensor_7, primals_780, primals_781, getitem_117, primals_636, primals_238, primals_239, primals_240, primals_639, primals_640, primals_641, primals_243, primals_244, primals_644, primals_245, primals_645, primals_646, primals_248, primals_249, primals_250, primals_649, primals_650, primals_651, primals_652, primals_253, primals_653, primals_254, primals_654, primals_255, convolution_default_11, primals_655, primals_256, primals_656, primals_257, primals_510, relu__default_32, primals_511, primals_3, primals_514, getitem_137, primals_515, getitem_136, primals_516, relu__default_33, primals_4, primals_519, primals_520, add_tensor_9, primals_521, primals_524, getitem_139, primals_525, getitem_140, primals_526, relu__default_34, primals_529, primals_530, cat_default_6, primals_384, relu__default, primals_385, getitem_412, relu__default_157, primals_102, getitem_2, primals_386, primals_107, getitem_86, getitem_411, relu__default_20, getitem_85, getitem_3, primals_93, primals_97, primals_389, getitem_618, primals_390, convolution_default_1, getitem_617, primals_92, primals_391, convolution_default_23, getitem_8, primals_99, relu__default_105, getitem_4, convolution_default_109, relu__default_158, getitem_7, getitem_6, primals_394, getitem_89, getitem_90, primals_395, getitem_88, getitem_415, getitem_416, getitem_414, add_tensor_55, primals_396, relu__default_1, primals_94, primals_101, relu__default_21, cat_default_31, relu__default_106, primals_399, getitem_620, getitem_9, primals_400, convolution_default_2, getitem_621, primals_98, primals_100, primals_104, primals_401, convolution_default_24, convolution_default_110, getitem_10, relu__default_159, getitem_11, primals_108, primals_109, convolution_default_27, primals_404, primals_103, convolution_default_113, getitem_590, primals_258, getitem_60, relu__default_117, primals_259, primals_260, relu__default_14, primals_261, getitem_365, getitem_593, getitem_364, getitem_592, getitem_61, getitem_463, getitem_462, primals_264, relu__default_92, relu__default_152, getitem_64, primals_265, cat_default_2, primals_266, getitem_63, relu__default_118, convolution_default_156, add_tensor_30, add_tensor_41, primals_269, getitem_596, getitem_368, getitem_595, primals_270, getitem_367, primals_275, relu__default_15, cat_default_23, primals_271, convolution_default_17, getitem_465, relu__default_153, relu__default_93, getitem_466, primals_274, convolution_default_97, relu__default_119, convolution_default_157, add_tensor_31, primals_276, getitem_66, getitem_67, convolution_default_103, getitem_434, primals_909, getitem_387, primals_910, relu__default_111, primals_911, getitem_386, relu__default_98, getitem_435, convolution_default_116, add_tensor_33, primals_914, convolution_default_115, getitem_392, primals_915, convolution_default_117, primals_916, getitem_390, getitem_389, convolution_default_123, primals_919, getitem_441, relu__default_99, getitem_440, primals_920, primals_921, primals_922, relu__default_112, primals_923, primals_924, primals_925, cat_default_19, add_tensor_38, primals_926, convolution_default_107, getitem_393, primals_929, convolution_default_89, relu__default_7, relu__default_72, getitem_314, primals_784, getitem_313, relu__default_85, getitem_640, getitem_639, primals_785, getitem_340, primals_786, relu__default_79, getitem_39, getitem_339, relu__default_164, getitem_38, getitem_338, getitem_292, getitem_291, primals_789, primals_790, relu__default_8, relu__default_86, primals_791, getitem_317, relu__default_73, getitem_643, cat_default_15, getitem_316, cat_default_32, getitem_642, add_tensor_1, primals_794, add_tensor_23, primals_795, convolution_default_91, primals_796, cat_default_14, getitem_41, convolution_default_96, getitem_42, relu__default_80, getitem_294, convolution_default_90, relu__default_165, convolution_default_84, getitem_295, primals_799, add_tensor_28, relu__default_9, primals_800, view_default, relu__default_74, primals_801, getitem_345, primals_802, getitem_346, getitem_319, primals_803, cat_default_1, t_default, getitem_542, getitem_541, primals_659, primals_660, primals_661, relu__default_139, primals_664, primals_665, getitem_545, primals_666, cat_default_27, getitem_544, primals_669, primals_670, primals_671, relu__default_140, convolution_default_144, primals_674, primals_675, primals_676, getitem_547, convolution_default_149, primals_531, convolution_default_3, getitem_263, primals_532, relu__default_145, getitem_14, relu__default_66, primals_533, getitem_13, getitem_568, primals_534, getitem_264, getitem_194, getitem_193, primals_535, convolution_default_71, getitem_567, getitem_566, primals_536, relu__default_2, convolution_default_70, relu__default_47, convolution_default_72, relu__default_146, primals_539, convolution_default_78, primals_540, add_tensor_12, primals_541, getitem_270, getitem_17, getitem_269, getitem_16, getitem_197, convolution_default_151, getitem_196, primals_544, relu__default_67, relu__default_3, primals_545, convolution_default_163, primals_546, convolution_default_164, convolution_default_150, relu__default_48, add_tensor_52, add_tensor_20, convolution_default_4, convolution_default_10, convolution_default_52, primals_549, add_tensor_13, getitem_573, primals_550, getitem_574, primals_551, convolution_default_58, primals_405, relu__default_132, primals_406, primals_409, primals_410, getitem_520, getitem_519, primals_411, primals_412, primals_413, relu__default_133, primals_414, primals_415, primals_416, add_tensor_47, cat_default_26, primals_419, primals_420, getitem_522, getitem_523, primals_421, relu__default_134, primals_424, primals_425, primals_153, primals_930, getitem_215, primals_154, convolution_default_44, primals_931, getitem_216, primals_155, getitem_241, getitem_240, relu__default_53, primals_934, getitem_168, primals_158, getitem_169, getitem_167, add_tensor_15, primals_935, getitem_221, primals_159, primals_936, primals_160, getitem_219, relu__default_41, getitem_218, relu__default_60, primals_939, convolution_default_64, primals_163, primals_940, relu__default_54, primals_164, primals_941, getitem_244, getitem_245, primals_165, getitem_243, convolution_default_46, primals_166, primals_167, primals_944, convolution_default_51, relu__default_61, primals_168, primals_945, convolution_default_45, primals_169, primals_946, add_tensor_10, cat_default_10, primals_170, convolution_default_62, convolution_default_65, getitem_174, primals_949, getitem_175, getitem_222, primals_173, primals_950, convolution_default_68, primals_279, primals_804, getitem_143, primals_280, primals_805, relu__default_35, getitem_142, primals_281, primals_806, primals_284, primals_809, primals_285, primals_810, primals_286, primals_811, convolution_default_38, primals_289, primals_814, getitem_146, primals_290, primals_815, getitem_147, getitem_145, primals_291, primals_816, primals_292, primals_293, relu__default_36, primals_294, primals_819, primals_295, primals_820, getitem_148, primals_296, primals_821, convolution_default_39, getitem_149, primals_299, primals_824, getitem_150, getitem_491, primals_679, getitem_469, relu__default_126, getitem_624, primals_680, primals_49, getitem_468, primals_681, getitem_492, getitem_623, primals_682, convolution_default_131, primals_683, convolution_default_130, primals_684, primals_43, convolution_default_132, primals_685, primals_686, relu__default_120, convolution_default_138, relu__default_160, convolution_default_124, convolution_default_165, getitem_498, getitem_497, primals_689, getitem_472, getitem_473, getitem_471, getitem_627, primals_690, getitem_628, getitem_626, primals_52, primals_691, relu__default_127, primals_44, relu__default_121, primals_47, relu__default_161, primals_694, add_tensor_44, primals_695, convolution_default_125, primals_696, convolution_default_166, primals_42, primals_48, convolution_default_128, getitem_599, convolution_default_36, getitem_598, primals_554, primals_57, getitem_96, primals_555, getitem_95, relu__default_154, primals_556, primals_59, relu__default_22, primals_54, primals_64, primals_68, primals_559, primals_560, add_tensor_4, getitem_602, primals_561, convolution_default_158, getitem_601, primals_58, primals_562, cat_default_30, primals_72, primals_563, primals_53, primals_63, getitem_99, primals_564, getitem_98, primals_67, primals_565, relu__default_155, convolution_default_159, primals_566, primals_71, relu__default_23, primals_69, primals_569, add_tensor_5, primals_570, primals_70, primals_571, getitem_604, convolution_default_32, getitem_605, primals_62, primals_132, getitem_443, primals_426, primals_133, getitem_118, getitem_444, primals_138, primals_22, primals_134, primals_12, relu__default_28, relu__default_113, primals_135, primals_429, getitem_422, getitem_421, primals_430, add_tensor_39, primals_431, getitem_449, primals_139, relu__default_107, getitem_121, getitem_120, getitem_447, primals_140, getitem_446, primals_434, primals_435, add_tensor_36, primals_436, relu__default_29, primals_13, relu__default_114, primals_143, primals_11, primals_144, getitem_425, getitem_424, primals_145, primals_439, primals_440, primals_17, primals_441, cat_default_5, relu__default_108, primals_18, primals_148, primals_21, primals_442, cat_default_22, primals_16, primals_149, relu__default_30, primals_443, convolution_default_122, convolution_default_112, primals_150, primals_444, convolution_default_33, add_tensor_37, getitem_123, getitem_124, primals_445, getitem_450, primals_446, convolution_default_118, primals_174, primals_300, primals_951, convolution_default_104, primals_175, relu__default_87, getitem_371, relu__default_147, primals_301, primals_952, getitem_370, relu__default_100, primals_953, getitem_397, primals_954, primals_178, primals_304, primals_955, relu__default_94, getitem_396, getitem_395, primals_179, primals_305, primals_956, getitem_349, getitem_577, primals_180, getitem_348, getitem_576, primals_306, primals_957, relu__default_101, getitem_374, relu__default_88, relu__default_148, primals_183, primals_309, primals_960, cat_default_18, getitem_373, primals_184, primals_310, primals_961, primals_185, primals_311, primals_962, add_tensor_29, add_tensor_53, convolution_default_106, cat_default_17, cat_default_29, primals_188, primals_314, primals_965, convolution_default_111, relu__default_95, primals_189, primals_315, primals_966, getitem_351, convolution_default_105, getitem_579, convolution_default_99, primals_190, getitem_352, getitem_580, primals_316, primals_967, add_tensor_34, relu__default_89, relu__default_149, primals_193, getitem_402, primals_319, primals_970, getitem_403, primals_194, getitem_376, primals_320, primals_971, primals_825, getitem_45, relu__default_16, primals_826, getitem_298, getitem_68, getitem_44, getitem_297, getitem_69, primals_829, convolution_default_18, getitem_70, primals_830, getitem_71, primals_831, primals_832, primals_833, convolution_default_12, relu__default_75, relu__default_10, primals_834, convolution_default_79, getitem_74, getitem_73, primals_835, getitem_48, getitem_49, getitem_47, primals_836, getitem_301, getitem_302, getitem_300, relu__default_17, relu__default_11, primals_839, relu__default_76, primals_840, convolution_default_19, primals_841, convolution_default_13, convolution_default_80, primals_844, convolution_default_16, getitem_76, primals_845, convolution_default_25, convolution_default_83, primals_699, getitem_320, getitem_273, primals_700, relu__default_81, primals_701, getitem_272, relu__default_68, getitem_321, convolution_default_86, add_tensor_21, primals_704, convolution_default_85, getitem_278, primals_705, convolution_default_87, primals_706, getitem_276, getitem_275, convolution_default_93, primals_709, getitem_327, relu__default_69, getitem_326, primals_710, primals_711, primals_712, relu__default_82, primals_713, primals_714, primals_715, cat_default_13, add_tensor_26, primals_716, convolution_default_77, getitem_279, primals_719, tangents_1):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 2048, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_165, torch.float32);  relu__default_165 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_170, to_dtype);  le_scalar = new_zeros_default_170 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_169, primals_1002, primals_1000, primals_1001, getitem_642, getitem_643, True, 1e-05, [True, True, True]);  convolution_default_169 = primals_1002 = primals_1000 = primals_1001 = getitem_642 = getitem_643 = None
        getitem_644 = native_batch_norm_backward_default[0]
        getitem_645 = native_batch_norm_backward_default[1]
        getitem_646 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_644, cat_default_32, primals_1019, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_644 = cat_default_32 = primals_1019 = None
        getitem_647 = convolution_backward_default[0]
        getitem_648 = convolution_backward_default[1];  convolution_backward_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_647, 1, 0, 208)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_647, 1, 208, 416)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_647, 1, 416, 624)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_647, 1, 624, 832);  getitem_647 = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor_2, torch.float32);  slice_tensor_2 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_164, torch.float32);  relu__default_164 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_171, to_dtype_3);  le_scalar_1 = new_zeros_default_171 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_168, primals_1017, primals_1015, primals_1016, getitem_639, getitem_640, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_168 = primals_1017 = primals_1015 = primals_1016 = getitem_639 = getitem_640 = None
        getitem_650 = native_batch_norm_backward_default_1[0]
        getitem_651 = native_batch_norm_backward_default_1[1]
        getitem_652 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_650, add_tensor_57, primals_1022, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_650 = add_tensor_57 = primals_1022 = None
        getitem_653 = convolution_backward_default_1[0]
        getitem_654 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(slice_tensor_1, getitem_653);  slice_tensor_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(add_tensor_58, torch.float32);  add_tensor_58 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_163, torch.float32);  relu__default_163 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_172, to_dtype_6);  le_scalar_2 = new_zeros_default_172 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_167, primals_1012, primals_1010, primals_1011, getitem_636, getitem_637, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_167 = primals_1012 = primals_1010 = primals_1011 = getitem_636 = getitem_637 = None
        getitem_656 = native_batch_norm_backward_default_2[0]
        getitem_657 = native_batch_norm_backward_default_2[1]
        getitem_658 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_656, add_tensor_56, primals_1021, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_656 = add_tensor_56 = primals_1021 = None
        getitem_659 = convolution_backward_default_2[0]
        getitem_660 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(slice_tensor, getitem_659);  slice_tensor = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_59, torch.float32);  add_tensor_59 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_162, torch.float32);  relu__default_162 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_173, to_dtype_9);  le_scalar_3 = new_zeros_default_173 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_166, primals_1007, primals_1005, primals_1006, getitem_633, getitem_634, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_166 = primals_1007 = primals_1005 = primals_1006 = getitem_633 = getitem_634 = None
        getitem_662 = native_batch_norm_backward_default_3[0]
        getitem_663 = native_batch_norm_backward_default_3[1]
        getitem_664 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_662, getitem_628, primals_1020, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_662 = getitem_628 = primals_1020 = None
        getitem_665 = convolution_backward_default_3[0]
        getitem_666 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        cat_default_33 = torch.ops.aten.cat.default([getitem_665, getitem_659, getitem_653, slice_tensor_3], 1);  getitem_665 = getitem_659 = getitem_653 = slice_tensor_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(cat_default_33, torch.float32);  cat_default_33 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_161, torch.float32);  relu__default_161 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_174, to_dtype_12);  le_scalar_4 = new_zeros_default_174 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_165, primals_997, primals_995, primals_996, getitem_626, getitem_627, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_165 = primals_997 = primals_995 = primals_996 = getitem_626 = getitem_627 = None
        getitem_668 = native_batch_norm_backward_default_4[0]
        getitem_669 = native_batch_norm_backward_default_4[1]
        getitem_670 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_668, relu__default_160, primals_1018, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_668 = primals_1018 = None
        getitem_671 = convolution_backward_default_4[0]
        getitem_672 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_671);  to_dtype_2 = getitem_671 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_60, torch.float32);  add_tensor_60 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_160, torch.float32);  relu__default_160 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_175, to_dtype_15);  le_scalar_5 = new_zeros_default_175 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_164, primals_972, primals_970, primals_971, getitem_623, getitem_624, True, 1e-05, [True, True, True]);  convolution_default_164 = primals_972 = primals_970 = primals_971 = getitem_623 = getitem_624 = None
        getitem_674 = native_batch_norm_backward_default_5[0]
        getitem_675 = native_batch_norm_backward_default_5[1]
        getitem_676 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_674, cat_default_31, primals_989, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_674 = cat_default_31 = primals_989 = None
        getitem_677 = convolution_backward_default_5[0]
        getitem_678 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_677, 1, 0, 208)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_677, 1, 208, 416)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_677, 1, 416, 624)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_677, 1, 624, 832);  getitem_677 = None
        to_dtype_18 = torch.ops.aten.to.dtype(slice_tensor_6, torch.float32);  slice_tensor_6 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_159, torch.float32);  relu__default_159 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_176, to_dtype_18);  le_scalar_6 = new_zeros_default_176 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_163, primals_987, primals_985, primals_986, getitem_620, getitem_621, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_163 = primals_987 = primals_985 = primals_986 = getitem_620 = getitem_621 = None
        getitem_680 = native_batch_norm_backward_default_6[0]
        getitem_681 = native_batch_norm_backward_default_6[1]
        getitem_682 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_680, add_tensor_55, primals_992, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_680 = add_tensor_55 = primals_992 = None
        getitem_683 = convolution_backward_default_6[0]
        getitem_684 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(slice_tensor_5, getitem_683);  slice_tensor_5 = None
        to_dtype_21 = torch.ops.aten.to.dtype(add_tensor_61, torch.float32);  add_tensor_61 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_158, torch.float32);  relu__default_158 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_177, to_dtype_21);  le_scalar_7 = new_zeros_default_177 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_162, primals_982, primals_980, primals_981, getitem_617, getitem_618, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_162 = primals_982 = primals_980 = primals_981 = getitem_617 = getitem_618 = None
        getitem_686 = native_batch_norm_backward_default_7[0]
        getitem_687 = native_batch_norm_backward_default_7[1]
        getitem_688 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_686, add_tensor_54, primals_991, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_686 = add_tensor_54 = primals_991 = None
        getitem_689 = convolution_backward_default_7[0]
        getitem_690 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(slice_tensor_4, getitem_689);  slice_tensor_4 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_157, torch.float32);  relu__default_157 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_178, to_dtype_24);  le_scalar_8 = new_zeros_default_178 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_161, primals_977, primals_975, primals_976, getitem_614, getitem_615, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_161 = primals_977 = primals_975 = primals_976 = getitem_614 = getitem_615 = None
        getitem_692 = native_batch_norm_backward_default_8[0]
        getitem_693 = native_batch_norm_backward_default_8[1]
        getitem_694 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_692, getitem_609, primals_990, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_692 = getitem_609 = primals_990 = None
        getitem_695 = convolution_backward_default_8[0]
        getitem_696 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        cat_default_34 = torch.ops.aten.cat.default([getitem_695, getitem_689, getitem_683, slice_tensor_7], 1);  getitem_695 = getitem_689 = getitem_683 = slice_tensor_7 = None
        to_dtype_27 = torch.ops.aten.to.dtype(cat_default_34, torch.float32);  cat_default_34 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_156, torch.float32);  relu__default_156 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_179, to_dtype_27);  le_scalar_9 = new_zeros_default_179 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_160, primals_967, primals_965, primals_966, getitem_607, getitem_608, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_160 = primals_967 = primals_965 = primals_966 = getitem_607 = getitem_608 = None
        getitem_698 = native_batch_norm_backward_default_9[0]
        getitem_699 = native_batch_norm_backward_default_9[1]
        getitem_700 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_698, relu__default_155, primals_988, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_698 = primals_988 = None
        getitem_701 = convolution_backward_default_9[0]
        getitem_702 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(to_dtype_17, getitem_701);  to_dtype_17 = getitem_701 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_63, torch.float32);  add_tensor_63 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_155, torch.float32);  relu__default_155 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_180, to_dtype_30);  le_scalar_10 = new_zeros_default_180 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_159, primals_962, primals_960, primals_961, getitem_604, getitem_605, True, 1e-05, [True, True, True]);  convolution_default_159 = primals_962 = primals_960 = primals_961 = getitem_604 = getitem_605 = None
        getitem_704 = native_batch_norm_backward_default_10[0]
        getitem_705 = native_batch_norm_backward_default_10[1]
        getitem_706 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_704, relu__default_150, primals_957, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_704 = primals_957 = None
        getitem_707 = convolution_backward_default_10[0]
        getitem_708 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_158, primals_936, primals_934, primals_935, getitem_601, getitem_602, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_158 = primals_936 = primals_934 = primals_935 = getitem_601 = getitem_602 = None
        getitem_710 = native_batch_norm_backward_default_11[0]
        getitem_711 = native_batch_norm_backward_default_11[1]
        getitem_712 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_710, cat_default_30, primals_953, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_710 = cat_default_30 = primals_953 = None
        getitem_713 = convolution_backward_default_11[0]
        getitem_714 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(getitem_713, 1, 0, 208)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(getitem_713, 1, 208, 416)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_713, 1, 416, 624)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_713, 1, 624, 832);  getitem_713 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_11, getitem_590, [3, 3], [2, 2], [1, 1], False, True, None);  slice_tensor_11 = getitem_590 = None
        to_dtype_33 = torch.ops.aten.to.dtype(slice_tensor_10, torch.float32);  slice_tensor_10 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_154, torch.float32);  relu__default_154 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_181, to_dtype_33);  le_scalar_11 = new_zeros_default_181 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_157, primals_951, primals_949, primals_950, getitem_598, getitem_599, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_157 = primals_951 = primals_949 = primals_950 = getitem_598 = getitem_599 = None
        getitem_716 = native_batch_norm_backward_default_12[0]
        getitem_717 = native_batch_norm_backward_default_12[1]
        getitem_718 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_716, getitem_589, primals_956, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_716 = getitem_589 = primals_956 = None
        getitem_719 = convolution_backward_default_12[0]
        getitem_720 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        to_dtype_36 = torch.ops.aten.to.dtype(slice_tensor_9, torch.float32);  slice_tensor_9 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_153, torch.float32);  relu__default_153 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_182, to_dtype_36);  le_scalar_12 = new_zeros_default_182 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_156, primals_946, primals_944, primals_945, getitem_595, getitem_596, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_156 = primals_946 = primals_944 = primals_945 = getitem_595 = getitem_596 = None
        getitem_722 = native_batch_norm_backward_default_13[0]
        getitem_723 = native_batch_norm_backward_default_13[1]
        getitem_724 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_722, getitem_588, primals_955, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_722 = getitem_588 = primals_955 = None
        getitem_725 = convolution_backward_default_13[0]
        getitem_726 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(slice_tensor_8, torch.float32);  slice_tensor_8 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_152, torch.float32);  relu__default_152 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_183, to_dtype_39);  le_scalar_13 = new_zeros_default_183 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_155, primals_941, primals_939, primals_940, getitem_592, getitem_593, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_155 = primals_941 = primals_939 = primals_940 = getitem_592 = getitem_593 = None
        getitem_728 = native_batch_norm_backward_default_14[0]
        getitem_729 = native_batch_norm_backward_default_14[1]
        getitem_730 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_728, getitem_587, primals_954, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_728 = getitem_587 = primals_954 = None
        getitem_731 = convolution_backward_default_14[0]
        getitem_732 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        cat_default_35 = torch.ops.aten.cat.default([getitem_731, getitem_725, getitem_719, avg_pool2d_backward_default], 1);  getitem_731 = getitem_725 = getitem_719 = avg_pool2d_backward_default = None
        to_dtype_42 = torch.ops.aten.to.dtype(cat_default_35, torch.float32);  cat_default_35 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_151, torch.float32);  relu__default_151 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_184, to_dtype_42);  le_scalar_14 = new_zeros_default_184 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_154, primals_931, primals_929, primals_930, getitem_585, getitem_586, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_154 = primals_931 = primals_929 = primals_930 = getitem_585 = getitem_586 = None
        getitem_734 = native_batch_norm_backward_default_15[0]
        getitem_735 = native_batch_norm_backward_default_15[1]
        getitem_736 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_734, relu__default_150, primals_952, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_734 = primals_952 = None
        getitem_737 = convolution_backward_default_15[0]
        getitem_738 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(getitem_707, getitem_737);  getitem_707 = getitem_737 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_64, torch.float32);  add_tensor_64 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_150, torch.float32);  relu__default_150 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_185, to_dtype_45);  le_scalar_15 = new_zeros_default_185 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_153, primals_666, primals_664, primals_665, getitem_582, getitem_583, True, 1e-05, [True, True, True]);  convolution_default_153 = primals_666 = primals_664 = primals_665 = getitem_582 = getitem_583 = None
        getitem_740 = native_batch_norm_backward_default_16[0]
        getitem_741 = native_batch_norm_backward_default_16[1]
        getitem_742 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_740, cat_default_29, primals_683, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_740 = cat_default_29 = primals_683 = None
        getitem_743 = convolution_backward_default_16[0]
        getitem_744 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(getitem_743, 1, 0, 104)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(getitem_743, 1, 104, 208)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(getitem_743, 1, 208, 312)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_743, 1, 312, 416);  getitem_743 = None
        to_dtype_48 = torch.ops.aten.to.dtype(slice_tensor_14, torch.float32);  slice_tensor_14 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_149, torch.float32);  relu__default_149 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_186, to_dtype_48);  le_scalar_16 = new_zeros_default_186 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_152, primals_681, primals_679, primals_680, getitem_579, getitem_580, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_152 = primals_681 = primals_679 = primals_680 = getitem_579 = getitem_580 = None
        getitem_746 = native_batch_norm_backward_default_17[0]
        getitem_747 = native_batch_norm_backward_default_17[1]
        getitem_748 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_746, add_tensor_53, primals_686, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_746 = add_tensor_53 = primals_686 = None
        getitem_749 = convolution_backward_default_17[0]
        getitem_750 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(slice_tensor_13, getitem_749);  slice_tensor_13 = None
        to_dtype_51 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_148, torch.float32);  relu__default_148 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_187, to_dtype_51);  le_scalar_17 = new_zeros_default_187 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_151, primals_676, primals_674, primals_675, getitem_576, getitem_577, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_151 = primals_676 = primals_674 = primals_675 = getitem_576 = getitem_577 = None
        getitem_752 = native_batch_norm_backward_default_18[0]
        getitem_753 = native_batch_norm_backward_default_18[1]
        getitem_754 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_752, add_tensor_52, primals_685, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_752 = add_tensor_52 = primals_685 = None
        getitem_755 = convolution_backward_default_18[0]
        getitem_756 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(slice_tensor_12, getitem_755);  slice_tensor_12 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_147, torch.float32);  relu__default_147 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_188, to_dtype_54);  le_scalar_18 = new_zeros_default_188 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_150, primals_671, primals_669, primals_670, getitem_573, getitem_574, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_150 = primals_671 = primals_669 = primals_670 = getitem_573 = getitem_574 = None
        getitem_758 = native_batch_norm_backward_default_19[0]
        getitem_759 = native_batch_norm_backward_default_19[1]
        getitem_760 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_758, getitem_568, primals_684, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_758 = getitem_568 = primals_684 = None
        getitem_761 = convolution_backward_default_19[0]
        getitem_762 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        cat_default_36 = torch.ops.aten.cat.default([getitem_761, getitem_755, getitem_749, slice_tensor_15], 1);  getitem_761 = getitem_755 = getitem_749 = slice_tensor_15 = None
        to_dtype_57 = torch.ops.aten.to.dtype(cat_default_36, torch.float32);  cat_default_36 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_146, torch.float32);  relu__default_146 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_189, to_dtype_57);  le_scalar_19 = new_zeros_default_189 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_149, primals_661, primals_659, primals_660, getitem_566, getitem_567, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_149 = primals_661 = primals_659 = primals_660 = getitem_566 = getitem_567 = None
        getitem_764 = native_batch_norm_backward_default_20[0]
        getitem_765 = native_batch_norm_backward_default_20[1]
        getitem_766 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_764, relu__default_145, primals_682, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_764 = primals_682 = None
        getitem_767 = convolution_backward_default_20[0]
        getitem_768 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(to_dtype_47, getitem_767);  to_dtype_47 = getitem_767 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_67, torch.float32);  add_tensor_67 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_145, torch.float32);  relu__default_145 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_190, to_dtype_60);  le_scalar_20 = new_zeros_default_190 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_148, primals_636, primals_634, primals_635, getitem_563, getitem_564, True, 1e-05, [True, True, True]);  convolution_default_148 = primals_636 = primals_634 = primals_635 = getitem_563 = getitem_564 = None
        getitem_770 = native_batch_norm_backward_default_21[0]
        getitem_771 = native_batch_norm_backward_default_21[1]
        getitem_772 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_770, cat_default_28, primals_653, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_770 = cat_default_28 = primals_653 = None
        getitem_773 = convolution_backward_default_21[0]
        getitem_774 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(getitem_773, 1, 0, 104)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(getitem_773, 1, 104, 208)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(getitem_773, 1, 208, 312)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(getitem_773, 1, 312, 416);  getitem_773 = None
        to_dtype_63 = torch.ops.aten.to.dtype(slice_tensor_18, torch.float32);  slice_tensor_18 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_144, torch.float32);  relu__default_144 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_191, to_dtype_63);  le_scalar_21 = new_zeros_default_191 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_147, primals_651, primals_649, primals_650, getitem_560, getitem_561, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_147 = primals_651 = primals_649 = primals_650 = getitem_560 = getitem_561 = None
        getitem_776 = native_batch_norm_backward_default_22[0]
        getitem_777 = native_batch_norm_backward_default_22[1]
        getitem_778 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_776, add_tensor_51, primals_656, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_776 = add_tensor_51 = primals_656 = None
        getitem_779 = convolution_backward_default_22[0]
        getitem_780 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(slice_tensor_17, getitem_779);  slice_tensor_17 = None
        to_dtype_66 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_143, torch.float32);  relu__default_143 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_192, to_dtype_66);  le_scalar_22 = new_zeros_default_192 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_146, primals_646, primals_644, primals_645, getitem_557, getitem_558, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_146 = primals_646 = primals_644 = primals_645 = getitem_557 = getitem_558 = None
        getitem_782 = native_batch_norm_backward_default_23[0]
        getitem_783 = native_batch_norm_backward_default_23[1]
        getitem_784 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_782, add_tensor_50, primals_655, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_782 = add_tensor_50 = primals_655 = None
        getitem_785 = convolution_backward_default_23[0]
        getitem_786 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(slice_tensor_16, getitem_785);  slice_tensor_16 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_69, torch.float32);  add_tensor_69 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_142, torch.float32);  relu__default_142 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_193, to_dtype_69);  le_scalar_23 = new_zeros_default_193 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_145, primals_641, primals_639, primals_640, getitem_554, getitem_555, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_145 = primals_641 = primals_639 = primals_640 = getitem_554 = getitem_555 = None
        getitem_788 = native_batch_norm_backward_default_24[0]
        getitem_789 = native_batch_norm_backward_default_24[1]
        getitem_790 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_788, getitem_549, primals_654, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_788 = getitem_549 = primals_654 = None
        getitem_791 = convolution_backward_default_24[0]
        getitem_792 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        cat_default_37 = torch.ops.aten.cat.default([getitem_791, getitem_785, getitem_779, slice_tensor_19], 1);  getitem_791 = getitem_785 = getitem_779 = slice_tensor_19 = None
        to_dtype_72 = torch.ops.aten.to.dtype(cat_default_37, torch.float32);  cat_default_37 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_141, torch.float32);  relu__default_141 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_194, to_dtype_72);  le_scalar_24 = new_zeros_default_194 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_144, primals_631, primals_629, primals_630, getitem_547, getitem_548, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_144 = primals_631 = primals_629 = primals_630 = getitem_547 = getitem_548 = None
        getitem_794 = native_batch_norm_backward_default_25[0]
        getitem_795 = native_batch_norm_backward_default_25[1]
        getitem_796 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_794, relu__default_140, primals_652, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_794 = primals_652 = None
        getitem_797 = convolution_backward_default_25[0]
        getitem_798 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_797);  to_dtype_62 = getitem_797 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_70, torch.float32);  add_tensor_70 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_140, torch.float32);  relu__default_140 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_195, to_dtype_75);  le_scalar_25 = new_zeros_default_195 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_143, primals_606, primals_604, primals_605, getitem_544, getitem_545, True, 1e-05, [True, True, True]);  convolution_default_143 = primals_606 = primals_604 = primals_605 = getitem_544 = getitem_545 = None
        getitem_800 = native_batch_norm_backward_default_26[0]
        getitem_801 = native_batch_norm_backward_default_26[1]
        getitem_802 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_800, cat_default_27, primals_623, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_800 = cat_default_27 = primals_623 = None
        getitem_803 = convolution_backward_default_26[0]
        getitem_804 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(getitem_803, 1, 0, 104)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(getitem_803, 1, 104, 208)
        slice_tensor_22 = torch.ops.aten.slice.Tensor(getitem_803, 1, 208, 312)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(getitem_803, 1, 312, 416);  getitem_803 = None
        to_dtype_78 = torch.ops.aten.to.dtype(slice_tensor_22, torch.float32);  slice_tensor_22 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_139, torch.float32);  relu__default_139 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_196, to_dtype_78);  le_scalar_26 = new_zeros_default_196 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_142, primals_621, primals_619, primals_620, getitem_541, getitem_542, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_142 = primals_621 = primals_619 = primals_620 = getitem_541 = getitem_542 = None
        getitem_806 = native_batch_norm_backward_default_27[0]
        getitem_807 = native_batch_norm_backward_default_27[1]
        getitem_808 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_806, add_tensor_49, primals_626, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_806 = add_tensor_49 = primals_626 = None
        getitem_809 = convolution_backward_default_27[0]
        getitem_810 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(slice_tensor_21, getitem_809);  slice_tensor_21 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_71, torch.float32);  add_tensor_71 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_138, torch.float32);  relu__default_138 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_197, to_dtype_81);  le_scalar_27 = new_zeros_default_197 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_141, primals_616, primals_614, primals_615, getitem_538, getitem_539, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_141 = primals_616 = primals_614 = primals_615 = getitem_538 = getitem_539 = None
        getitem_812 = native_batch_norm_backward_default_28[0]
        getitem_813 = native_batch_norm_backward_default_28[1]
        getitem_814 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_812, add_tensor_48, primals_625, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_812 = add_tensor_48 = primals_625 = None
        getitem_815 = convolution_backward_default_28[0]
        getitem_816 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(slice_tensor_20, getitem_815);  slice_tensor_20 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_72, torch.float32);  add_tensor_72 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_137, torch.float32);  relu__default_137 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_198, to_dtype_84);  le_scalar_28 = new_zeros_default_198 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_140, primals_611, primals_609, primals_610, getitem_535, getitem_536, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_140 = primals_611 = primals_609 = primals_610 = getitem_535 = getitem_536 = None
        getitem_818 = native_batch_norm_backward_default_29[0]
        getitem_819 = native_batch_norm_backward_default_29[1]
        getitem_820 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_818, getitem_530, primals_624, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_818 = getitem_530 = primals_624 = None
        getitem_821 = convolution_backward_default_29[0]
        getitem_822 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        cat_default_38 = torch.ops.aten.cat.default([getitem_821, getitem_815, getitem_809, slice_tensor_23], 1);  getitem_821 = getitem_815 = getitem_809 = slice_tensor_23 = None
        to_dtype_87 = torch.ops.aten.to.dtype(cat_default_38, torch.float32);  cat_default_38 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_136, torch.float32);  relu__default_136 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_199, to_dtype_87);  le_scalar_29 = new_zeros_default_199 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_139, primals_601, primals_599, primals_600, getitem_528, getitem_529, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_139 = primals_601 = primals_599 = primals_600 = getitem_528 = getitem_529 = None
        getitem_824 = native_batch_norm_backward_default_30[0]
        getitem_825 = native_batch_norm_backward_default_30[1]
        getitem_826 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_824, relu__default_135, primals_622, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_824 = primals_622 = None
        getitem_827 = convolution_backward_default_30[0]
        getitem_828 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(to_dtype_77, getitem_827);  to_dtype_77 = getitem_827 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_73, torch.float32);  add_tensor_73 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_135, torch.float32);  relu__default_135 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_200, to_dtype_90);  le_scalar_30 = new_zeros_default_200 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_138, primals_546, primals_544, primals_545, getitem_525, getitem_526, True, 1e-05, [True, True, True]);  convolution_default_138 = primals_546 = primals_544 = primals_545 = getitem_525 = getitem_526 = None
        getitem_830 = native_batch_norm_backward_default_31[0]
        getitem_831 = native_batch_norm_backward_default_31[1]
        getitem_832 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_830, cat_default_26, primals_563, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_830 = cat_default_26 = primals_563 = None
        getitem_833 = convolution_backward_default_31[0]
        getitem_834 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(getitem_833, 1, 0, 104)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(getitem_833, 1, 104, 208)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(getitem_833, 1, 208, 312)
        slice_tensor_27 = torch.ops.aten.slice.Tensor(getitem_833, 1, 312, 416);  getitem_833 = None
        to_dtype_93 = torch.ops.aten.to.dtype(slice_tensor_26, torch.float32);  slice_tensor_26 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_134, torch.float32);  relu__default_134 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_201, to_dtype_93);  le_scalar_31 = new_zeros_default_201 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_137, primals_561, primals_559, primals_560, getitem_522, getitem_523, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_137 = primals_561 = primals_559 = primals_560 = getitem_522 = getitem_523 = None
        getitem_836 = native_batch_norm_backward_default_32[0]
        getitem_837 = native_batch_norm_backward_default_32[1]
        getitem_838 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_836, add_tensor_47, primals_566, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_836 = add_tensor_47 = primals_566 = None
        getitem_839 = convolution_backward_default_32[0]
        getitem_840 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(slice_tensor_25, getitem_839);  slice_tensor_25 = None
        to_dtype_96 = torch.ops.aten.to.dtype(add_tensor_74, torch.float32);  add_tensor_74 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_133, torch.float32);  relu__default_133 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_202, to_dtype_96);  le_scalar_32 = new_zeros_default_202 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_136, primals_556, primals_554, primals_555, getitem_519, getitem_520, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_136 = primals_556 = primals_554 = primals_555 = getitem_519 = getitem_520 = None
        getitem_842 = native_batch_norm_backward_default_33[0]
        getitem_843 = native_batch_norm_backward_default_33[1]
        getitem_844 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_842, add_tensor_46, primals_565, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_842 = add_tensor_46 = primals_565 = None
        getitem_845 = convolution_backward_default_33[0]
        getitem_846 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(slice_tensor_24, getitem_845);  slice_tensor_24 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_75, torch.float32);  add_tensor_75 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_132, torch.float32);  relu__default_132 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_203, to_dtype_99);  le_scalar_33 = new_zeros_default_203 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_135, primals_551, primals_549, primals_550, getitem_516, getitem_517, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_135 = primals_551 = primals_549 = primals_550 = getitem_516 = getitem_517 = None
        getitem_848 = native_batch_norm_backward_default_34[0]
        getitem_849 = native_batch_norm_backward_default_34[1]
        getitem_850 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_848, getitem_511, primals_564, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_848 = getitem_511 = primals_564 = None
        getitem_851 = convolution_backward_default_34[0]
        getitem_852 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        cat_default_39 = torch.ops.aten.cat.default([getitem_851, getitem_845, getitem_839, slice_tensor_27], 1);  getitem_851 = getitem_845 = getitem_839 = slice_tensor_27 = None
        to_dtype_102 = torch.ops.aten.to.dtype(cat_default_39, torch.float32);  cat_default_39 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_131, torch.float32);  relu__default_131 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_204, to_dtype_102);  le_scalar_34 = new_zeros_default_204 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_134, primals_541, primals_539, primals_540, getitem_509, getitem_510, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_134 = primals_541 = primals_539 = primals_540 = getitem_509 = getitem_510 = None
        getitem_854 = native_batch_norm_backward_default_35[0]
        getitem_855 = native_batch_norm_backward_default_35[1]
        getitem_856 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_854, relu__default_130, primals_562, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_854 = primals_562 = None
        getitem_857 = convolution_backward_default_35[0]
        getitem_858 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(to_dtype_92, getitem_857);  to_dtype_92 = getitem_857 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_76, torch.float32);  add_tensor_76 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_130, torch.float32);  relu__default_130 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_205, to_dtype_105);  le_scalar_35 = new_zeros_default_205 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_133, primals_516, primals_514, primals_515, getitem_506, getitem_507, True, 1e-05, [True, True, True]);  convolution_default_133 = primals_516 = primals_514 = primals_515 = getitem_506 = getitem_507 = None
        getitem_860 = native_batch_norm_backward_default_36[0]
        getitem_861 = native_batch_norm_backward_default_36[1]
        getitem_862 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_860, cat_default_25, primals_533, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_860 = cat_default_25 = primals_533 = None
        getitem_863 = convolution_backward_default_36[0]
        getitem_864 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        slice_tensor_28 = torch.ops.aten.slice.Tensor(getitem_863, 1, 0, 104)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(getitem_863, 1, 104, 208)
        slice_tensor_30 = torch.ops.aten.slice.Tensor(getitem_863, 1, 208, 312)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(getitem_863, 1, 312, 416);  getitem_863 = None
        to_dtype_108 = torch.ops.aten.to.dtype(slice_tensor_30, torch.float32);  slice_tensor_30 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_129, torch.float32);  relu__default_129 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_206, to_dtype_108);  le_scalar_36 = new_zeros_default_206 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_132, primals_531, primals_529, primals_530, getitem_503, getitem_504, True, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_132 = primals_531 = primals_529 = primals_530 = getitem_503 = getitem_504 = None
        getitem_866 = native_batch_norm_backward_default_37[0]
        getitem_867 = native_batch_norm_backward_default_37[1]
        getitem_868 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_866, add_tensor_45, primals_536, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_866 = add_tensor_45 = primals_536 = None
        getitem_869 = convolution_backward_default_37[0]
        getitem_870 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(slice_tensor_29, getitem_869);  slice_tensor_29 = None
        to_dtype_111 = torch.ops.aten.to.dtype(add_tensor_77, torch.float32);  add_tensor_77 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_128, torch.float32);  relu__default_128 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_207, to_dtype_111);  le_scalar_37 = new_zeros_default_207 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_131, primals_526, primals_524, primals_525, getitem_500, getitem_501, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_131 = primals_526 = primals_524 = primals_525 = getitem_500 = getitem_501 = None
        getitem_872 = native_batch_norm_backward_default_38[0]
        getitem_873 = native_batch_norm_backward_default_38[1]
        getitem_874 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_872, add_tensor_44, primals_535, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_872 = add_tensor_44 = primals_535 = None
        getitem_875 = convolution_backward_default_38[0]
        getitem_876 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(slice_tensor_28, getitem_875);  slice_tensor_28 = None
        to_dtype_114 = torch.ops.aten.to.dtype(add_tensor_78, torch.float32);  add_tensor_78 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_127, torch.float32);  relu__default_127 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_208, to_dtype_114);  le_scalar_38 = new_zeros_default_208 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_130, primals_521, primals_519, primals_520, getitem_497, getitem_498, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_130 = primals_521 = primals_519 = primals_520 = getitem_497 = getitem_498 = None
        getitem_878 = native_batch_norm_backward_default_39[0]
        getitem_879 = native_batch_norm_backward_default_39[1]
        getitem_880 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_878, getitem_492, primals_534, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_878 = getitem_492 = primals_534 = None
        getitem_881 = convolution_backward_default_39[0]
        getitem_882 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        cat_default_40 = torch.ops.aten.cat.default([getitem_881, getitem_875, getitem_869, slice_tensor_31], 1);  getitem_881 = getitem_875 = getitem_869 = slice_tensor_31 = None
        to_dtype_117 = torch.ops.aten.to.dtype(cat_default_40, torch.float32);  cat_default_40 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_126, torch.float32);  relu__default_126 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_209, to_dtype_117);  le_scalar_39 = new_zeros_default_209 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_129, primals_511, primals_509, primals_510, getitem_490, getitem_491, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_129 = primals_511 = primals_509 = primals_510 = getitem_490 = getitem_491 = None
        getitem_884 = native_batch_norm_backward_default_40[0]
        getitem_885 = native_batch_norm_backward_default_40[1]
        getitem_886 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_884, relu__default_125, primals_532, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_884 = primals_532 = None
        getitem_887 = convolution_backward_default_40[0]
        getitem_888 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(to_dtype_107, getitem_887);  to_dtype_107 = getitem_887 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_79, torch.float32);  add_tensor_79 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_125, torch.float32);  relu__default_125 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_210, to_dtype_120);  le_scalar_40 = new_zeros_default_210 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_128, primals_486, primals_484, primals_485, getitem_487, getitem_488, True, 1e-05, [True, True, True]);  convolution_default_128 = primals_486 = primals_484 = primals_485 = getitem_487 = getitem_488 = None
        getitem_890 = native_batch_norm_backward_default_41[0]
        getitem_891 = native_batch_norm_backward_default_41[1]
        getitem_892 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_890, cat_default_24, primals_503, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_890 = cat_default_24 = primals_503 = None
        getitem_893 = convolution_backward_default_41[0]
        getitem_894 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        slice_tensor_32 = torch.ops.aten.slice.Tensor(getitem_893, 1, 0, 104)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(getitem_893, 1, 104, 208)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(getitem_893, 1, 208, 312)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(getitem_893, 1, 312, 416);  getitem_893 = None
        to_dtype_123 = torch.ops.aten.to.dtype(slice_tensor_34, torch.float32);  slice_tensor_34 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_124, torch.float32);  relu__default_124 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_211, to_dtype_123);  le_scalar_41 = new_zeros_default_211 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_127, primals_501, primals_499, primals_500, getitem_484, getitem_485, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_127 = primals_501 = primals_499 = primals_500 = getitem_484 = getitem_485 = None
        getitem_896 = native_batch_norm_backward_default_42[0]
        getitem_897 = native_batch_norm_backward_default_42[1]
        getitem_898 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_896, add_tensor_43, primals_506, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_896 = add_tensor_43 = primals_506 = None
        getitem_899 = convolution_backward_default_42[0]
        getitem_900 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(slice_tensor_33, getitem_899);  slice_tensor_33 = None
        to_dtype_126 = torch.ops.aten.to.dtype(add_tensor_80, torch.float32);  add_tensor_80 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_123, torch.float32);  relu__default_123 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_212, to_dtype_126);  le_scalar_42 = new_zeros_default_212 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_126, primals_496, primals_494, primals_495, getitem_481, getitem_482, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default_126 = primals_496 = primals_494 = primals_495 = getitem_481 = getitem_482 = None
        getitem_902 = native_batch_norm_backward_default_43[0]
        getitem_903 = native_batch_norm_backward_default_43[1]
        getitem_904 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_902, add_tensor_42, primals_505, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_902 = add_tensor_42 = primals_505 = None
        getitem_905 = convolution_backward_default_43[0]
        getitem_906 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(slice_tensor_32, getitem_905);  slice_tensor_32 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_81, torch.float32);  add_tensor_81 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_122, torch.float32);  relu__default_122 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_213, to_dtype_129);  le_scalar_43 = new_zeros_default_213 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_125, primals_491, primals_489, primals_490, getitem_478, getitem_479, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_125 = primals_491 = primals_489 = primals_490 = getitem_478 = getitem_479 = None
        getitem_908 = native_batch_norm_backward_default_44[0]
        getitem_909 = native_batch_norm_backward_default_44[1]
        getitem_910 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_908, getitem_473, primals_504, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_908 = getitem_473 = primals_504 = None
        getitem_911 = convolution_backward_default_44[0]
        getitem_912 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        cat_default_41 = torch.ops.aten.cat.default([getitem_911, getitem_905, getitem_899, slice_tensor_35], 1);  getitem_911 = getitem_905 = getitem_899 = slice_tensor_35 = None
        to_dtype_132 = torch.ops.aten.to.dtype(cat_default_41, torch.float32);  cat_default_41 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_121, torch.float32);  relu__default_121 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_214, to_dtype_132);  le_scalar_44 = new_zeros_default_214 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_124, primals_481, primals_479, primals_480, getitem_471, getitem_472, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_124 = primals_481 = primals_479 = primals_480 = getitem_471 = getitem_472 = None
        getitem_914 = native_batch_norm_backward_default_45[0]
        getitem_915 = native_batch_norm_backward_default_45[1]
        getitem_916 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_914, relu__default_120, primals_502, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_914 = primals_502 = None
        getitem_917 = convolution_backward_default_45[0]
        getitem_918 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(to_dtype_122, getitem_917);  to_dtype_122 = getitem_917 = None
        to_dtype_135 = torch.ops.aten.to.dtype(add_tensor_82, torch.float32);  add_tensor_82 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_120, torch.float32);  relu__default_120 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_215, to_dtype_135);  le_scalar_45 = new_zeros_default_215 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_123, primals_456, primals_454, primals_455, getitem_468, getitem_469, True, 1e-05, [True, True, True]);  convolution_default_123 = primals_456 = primals_454 = primals_455 = getitem_468 = getitem_469 = None
        getitem_920 = native_batch_norm_backward_default_46[0]
        getitem_921 = native_batch_norm_backward_default_46[1]
        getitem_922 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_920, cat_default_23, primals_473, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_920 = cat_default_23 = primals_473 = None
        getitem_923 = convolution_backward_default_46[0]
        getitem_924 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        slice_tensor_36 = torch.ops.aten.slice.Tensor(getitem_923, 1, 0, 104)
        slice_tensor_37 = torch.ops.aten.slice.Tensor(getitem_923, 1, 104, 208)
        slice_tensor_38 = torch.ops.aten.slice.Tensor(getitem_923, 1, 208, 312)
        slice_tensor_39 = torch.ops.aten.slice.Tensor(getitem_923, 1, 312, 416);  getitem_923 = None
        to_dtype_138 = torch.ops.aten.to.dtype(slice_tensor_38, torch.float32);  slice_tensor_38 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_119, torch.float32);  relu__default_119 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_216, to_dtype_138);  le_scalar_46 = new_zeros_default_216 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_122, primals_471, primals_469, primals_470, getitem_465, getitem_466, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_122 = primals_471 = primals_469 = primals_470 = getitem_465 = getitem_466 = None
        getitem_926 = native_batch_norm_backward_default_47[0]
        getitem_927 = native_batch_norm_backward_default_47[1]
        getitem_928 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_926, add_tensor_41, primals_476, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_926 = add_tensor_41 = primals_476 = None
        getitem_929 = convolution_backward_default_47[0]
        getitem_930 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(slice_tensor_37, getitem_929);  slice_tensor_37 = None
        to_dtype_141 = torch.ops.aten.to.dtype(add_tensor_83, torch.float32);  add_tensor_83 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_118, torch.float32);  relu__default_118 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_217, to_dtype_141);  le_scalar_47 = new_zeros_default_217 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_121, primals_466, primals_464, primals_465, getitem_462, getitem_463, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_121 = primals_466 = primals_464 = primals_465 = getitem_462 = getitem_463 = None
        getitem_932 = native_batch_norm_backward_default_48[0]
        getitem_933 = native_batch_norm_backward_default_48[1]
        getitem_934 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_932, add_tensor_40, primals_475, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_932 = add_tensor_40 = primals_475 = None
        getitem_935 = convolution_backward_default_48[0]
        getitem_936 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(slice_tensor_36, getitem_935);  slice_tensor_36 = None
        to_dtype_144 = torch.ops.aten.to.dtype(add_tensor_84, torch.float32);  add_tensor_84 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_117, torch.float32);  relu__default_117 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_218, to_dtype_144);  le_scalar_48 = new_zeros_default_218 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_120, primals_461, primals_459, primals_460, getitem_459, getitem_460, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_120 = primals_461 = primals_459 = primals_460 = getitem_459 = getitem_460 = None
        getitem_938 = native_batch_norm_backward_default_49[0]
        getitem_939 = native_batch_norm_backward_default_49[1]
        getitem_940 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_938, getitem_454, primals_474, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_938 = getitem_454 = primals_474 = None
        getitem_941 = convolution_backward_default_49[0]
        getitem_942 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        cat_default_42 = torch.ops.aten.cat.default([getitem_941, getitem_935, getitem_929, slice_tensor_39], 1);  getitem_941 = getitem_935 = getitem_929 = slice_tensor_39 = None
        to_dtype_147 = torch.ops.aten.to.dtype(cat_default_42, torch.float32);  cat_default_42 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_116, torch.float32);  relu__default_116 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_219, to_dtype_147);  le_scalar_49 = new_zeros_default_219 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_119, primals_451, primals_449, primals_450, getitem_452, getitem_453, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_119 = primals_451 = primals_449 = primals_450 = getitem_452 = getitem_453 = None
        getitem_944 = native_batch_norm_backward_default_50[0]
        getitem_945 = native_batch_norm_backward_default_50[1]
        getitem_946 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_944, relu__default_115, primals_472, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_944 = primals_472 = None
        getitem_947 = convolution_backward_default_50[0]
        getitem_948 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(to_dtype_137, getitem_947);  to_dtype_137 = getitem_947 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_85, torch.float32);  add_tensor_85 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_115, torch.float32);  relu__default_115 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_220, to_dtype_150);  le_scalar_50 = new_zeros_default_220 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_118, primals_426, primals_424, primals_425, getitem_449, getitem_450, True, 1e-05, [True, True, True]);  convolution_default_118 = primals_426 = primals_424 = primals_425 = getitem_449 = getitem_450 = None
        getitem_950 = native_batch_norm_backward_default_51[0]
        getitem_951 = native_batch_norm_backward_default_51[1]
        getitem_952 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_950, cat_default_22, primals_443, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_950 = cat_default_22 = primals_443 = None
        getitem_953 = convolution_backward_default_51[0]
        getitem_954 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        slice_tensor_40 = torch.ops.aten.slice.Tensor(getitem_953, 1, 0, 104)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(getitem_953, 1, 104, 208)
        slice_tensor_42 = torch.ops.aten.slice.Tensor(getitem_953, 1, 208, 312)
        slice_tensor_43 = torch.ops.aten.slice.Tensor(getitem_953, 1, 312, 416);  getitem_953 = None
        to_dtype_153 = torch.ops.aten.to.dtype(slice_tensor_42, torch.float32);  slice_tensor_42 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_114, torch.float32);  relu__default_114 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_221, to_dtype_153);  le_scalar_51 = new_zeros_default_221 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_117, primals_441, primals_439, primals_440, getitem_446, getitem_447, True, 1e-05, [True, True, True]);  to_dtype_155 = convolution_default_117 = primals_441 = primals_439 = primals_440 = getitem_446 = getitem_447 = None
        getitem_956 = native_batch_norm_backward_default_52[0]
        getitem_957 = native_batch_norm_backward_default_52[1]
        getitem_958 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_956, add_tensor_39, primals_446, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_956 = add_tensor_39 = primals_446 = None
        getitem_959 = convolution_backward_default_52[0]
        getitem_960 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(slice_tensor_41, getitem_959);  slice_tensor_41 = None
        to_dtype_156 = torch.ops.aten.to.dtype(add_tensor_86, torch.float32);  add_tensor_86 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_113, torch.float32);  relu__default_113 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_222, to_dtype_156);  le_scalar_52 = new_zeros_default_222 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_116, primals_436, primals_434, primals_435, getitem_443, getitem_444, True, 1e-05, [True, True, True]);  to_dtype_158 = convolution_default_116 = primals_436 = primals_434 = primals_435 = getitem_443 = getitem_444 = None
        getitem_962 = native_batch_norm_backward_default_53[0]
        getitem_963 = native_batch_norm_backward_default_53[1]
        getitem_964 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_962, add_tensor_38, primals_445, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_962 = add_tensor_38 = primals_445 = None
        getitem_965 = convolution_backward_default_53[0]
        getitem_966 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(slice_tensor_40, getitem_965);  slice_tensor_40 = None
        to_dtype_159 = torch.ops.aten.to.dtype(add_tensor_87, torch.float32);  add_tensor_87 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_112, torch.float32);  relu__default_112 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_223, to_dtype_159);  le_scalar_53 = new_zeros_default_223 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_115, primals_431, primals_429, primals_430, getitem_440, getitem_441, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_115 = primals_431 = primals_429 = primals_430 = getitem_440 = getitem_441 = None
        getitem_968 = native_batch_norm_backward_default_54[0]
        getitem_969 = native_batch_norm_backward_default_54[1]
        getitem_970 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_968, getitem_435, primals_444, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_968 = getitem_435 = primals_444 = None
        getitem_971 = convolution_backward_default_54[0]
        getitem_972 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        cat_default_43 = torch.ops.aten.cat.default([getitem_971, getitem_965, getitem_959, slice_tensor_43], 1);  getitem_971 = getitem_965 = getitem_959 = slice_tensor_43 = None
        to_dtype_162 = torch.ops.aten.to.dtype(cat_default_43, torch.float32);  cat_default_43 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_111, torch.float32);  relu__default_111 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_224, to_dtype_162);  le_scalar_54 = new_zeros_default_224 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_114, primals_421, primals_419, primals_420, getitem_433, getitem_434, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_114 = primals_421 = primals_419 = primals_420 = getitem_433 = getitem_434 = None
        getitem_974 = native_batch_norm_backward_default_55[0]
        getitem_975 = native_batch_norm_backward_default_55[1]
        getitem_976 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_974, relu__default_110, primals_442, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_974 = primals_442 = None
        getitem_977 = convolution_backward_default_55[0]
        getitem_978 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(to_dtype_152, getitem_977);  to_dtype_152 = getitem_977 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_88, torch.float32);  add_tensor_88 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_110, torch.float32);  relu__default_110 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_225, to_dtype_165);  le_scalar_55 = new_zeros_default_225 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_113, primals_396, primals_394, primals_395, getitem_430, getitem_431, True, 1e-05, [True, True, True]);  convolution_default_113 = primals_396 = primals_394 = primals_395 = getitem_430 = getitem_431 = None
        getitem_980 = native_batch_norm_backward_default_56[0]
        getitem_981 = native_batch_norm_backward_default_56[1]
        getitem_982 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_980, cat_default_21, primals_413, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_980 = cat_default_21 = primals_413 = None
        getitem_983 = convolution_backward_default_56[0]
        getitem_984 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        slice_tensor_44 = torch.ops.aten.slice.Tensor(getitem_983, 1, 0, 104)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(getitem_983, 1, 104, 208)
        slice_tensor_46 = torch.ops.aten.slice.Tensor(getitem_983, 1, 208, 312)
        slice_tensor_47 = torch.ops.aten.slice.Tensor(getitem_983, 1, 312, 416);  getitem_983 = None
        to_dtype_168 = torch.ops.aten.to.dtype(slice_tensor_46, torch.float32);  slice_tensor_46 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_226, to_dtype_168);  le_scalar_56 = new_zeros_default_226 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_112, primals_411, primals_409, primals_410, getitem_427, getitem_428, True, 1e-05, [True, True, True]);  to_dtype_170 = convolution_default_112 = primals_411 = primals_409 = primals_410 = getitem_427 = getitem_428 = None
        getitem_986 = native_batch_norm_backward_default_57[0]
        getitem_987 = native_batch_norm_backward_default_57[1]
        getitem_988 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_986, add_tensor_37, primals_416, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_986 = add_tensor_37 = primals_416 = None
        getitem_989 = convolution_backward_default_57[0]
        getitem_990 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(slice_tensor_45, getitem_989);  slice_tensor_45 = None
        to_dtype_171 = torch.ops.aten.to.dtype(add_tensor_89, torch.float32);  add_tensor_89 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_227, to_dtype_171);  le_scalar_57 = new_zeros_default_227 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_111, primals_406, primals_404, primals_405, getitem_424, getitem_425, True, 1e-05, [True, True, True]);  to_dtype_173 = convolution_default_111 = primals_406 = primals_404 = primals_405 = getitem_424 = getitem_425 = None
        getitem_992 = native_batch_norm_backward_default_58[0]
        getitem_993 = native_batch_norm_backward_default_58[1]
        getitem_994 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_992, add_tensor_36, primals_415, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_992 = add_tensor_36 = primals_415 = None
        getitem_995 = convolution_backward_default_58[0]
        getitem_996 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(slice_tensor_44, getitem_995);  slice_tensor_44 = None
        to_dtype_174 = torch.ops.aten.to.dtype(add_tensor_90, torch.float32);  add_tensor_90 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_228, to_dtype_174);  le_scalar_58 = new_zeros_default_228 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_110, primals_401, primals_399, primals_400, getitem_421, getitem_422, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_110 = primals_401 = primals_399 = primals_400 = getitem_421 = getitem_422 = None
        getitem_998 = native_batch_norm_backward_default_59[0]
        getitem_999 = native_batch_norm_backward_default_59[1]
        getitem_1000 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_998, getitem_416, primals_414, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_998 = getitem_416 = primals_414 = None
        getitem_1001 = convolution_backward_default_59[0]
        getitem_1002 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        cat_default_44 = torch.ops.aten.cat.default([getitem_1001, getitem_995, getitem_989, slice_tensor_47], 1);  getitem_1001 = getitem_995 = getitem_989 = slice_tensor_47 = None
        to_dtype_177 = torch.ops.aten.to.dtype(cat_default_44, torch.float32);  cat_default_44 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_229, to_dtype_177);  le_scalar_59 = new_zeros_default_229 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_109, primals_391, primals_389, primals_390, getitem_414, getitem_415, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_109 = primals_391 = primals_389 = primals_390 = getitem_414 = getitem_415 = None
        getitem_1004 = native_batch_norm_backward_default_60[0]
        getitem_1005 = native_batch_norm_backward_default_60[1]
        getitem_1006 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_1004, relu__default_105, primals_412, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1004 = primals_412 = None
        getitem_1007 = convolution_backward_default_60[0]
        getitem_1008 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(to_dtype_167, getitem_1007);  to_dtype_167 = getitem_1007 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_91, torch.float32);  add_tensor_91 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_230, to_dtype_180);  le_scalar_60 = new_zeros_default_230 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_108, primals_366, primals_364, primals_365, getitem_411, getitem_412, True, 1e-05, [True, True, True]);  convolution_default_108 = primals_366 = primals_364 = primals_365 = getitem_411 = getitem_412 = None
        getitem_1010 = native_batch_norm_backward_default_61[0]
        getitem_1011 = native_batch_norm_backward_default_61[1]
        getitem_1012 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_1010, cat_default_20, primals_383, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1010 = cat_default_20 = primals_383 = None
        getitem_1013 = convolution_backward_default_61[0]
        getitem_1014 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        slice_tensor_48 = torch.ops.aten.slice.Tensor(getitem_1013, 1, 0, 104)
        slice_tensor_49 = torch.ops.aten.slice.Tensor(getitem_1013, 1, 104, 208)
        slice_tensor_50 = torch.ops.aten.slice.Tensor(getitem_1013, 1, 208, 312)
        slice_tensor_51 = torch.ops.aten.slice.Tensor(getitem_1013, 1, 312, 416);  getitem_1013 = None
        to_dtype_183 = torch.ops.aten.to.dtype(slice_tensor_50, torch.float32);  slice_tensor_50 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_231, to_dtype_183);  le_scalar_61 = new_zeros_default_231 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_107, primals_381, primals_379, primals_380, getitem_408, getitem_409, True, 1e-05, [True, True, True]);  to_dtype_185 = convolution_default_107 = primals_381 = primals_379 = primals_380 = getitem_408 = getitem_409 = None
        getitem_1016 = native_batch_norm_backward_default_62[0]
        getitem_1017 = native_batch_norm_backward_default_62[1]
        getitem_1018 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_1016, add_tensor_35, primals_386, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1016 = add_tensor_35 = primals_386 = None
        getitem_1019 = convolution_backward_default_62[0]
        getitem_1020 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(slice_tensor_49, getitem_1019);  slice_tensor_49 = None
        to_dtype_186 = torch.ops.aten.to.dtype(add_tensor_92, torch.float32);  add_tensor_92 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_232, to_dtype_186);  le_scalar_62 = new_zeros_default_232 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_106, primals_376, primals_374, primals_375, getitem_405, getitem_406, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_106 = primals_376 = primals_374 = primals_375 = getitem_405 = getitem_406 = None
        getitem_1022 = native_batch_norm_backward_default_63[0]
        getitem_1023 = native_batch_norm_backward_default_63[1]
        getitem_1024 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_1022, add_tensor_34, primals_385, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1022 = add_tensor_34 = primals_385 = None
        getitem_1025 = convolution_backward_default_63[0]
        getitem_1026 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(slice_tensor_48, getitem_1025);  slice_tensor_48 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_93, torch.float32);  add_tensor_93 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_233, to_dtype_189);  le_scalar_63 = new_zeros_default_233 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_105, primals_371, primals_369, primals_370, getitem_402, getitem_403, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_105 = primals_371 = primals_369 = primals_370 = getitem_402 = getitem_403 = None
        getitem_1028 = native_batch_norm_backward_default_64[0]
        getitem_1029 = native_batch_norm_backward_default_64[1]
        getitem_1030 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_1028, getitem_397, primals_384, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1028 = getitem_397 = primals_384 = None
        getitem_1031 = convolution_backward_default_64[0]
        getitem_1032 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        cat_default_45 = torch.ops.aten.cat.default([getitem_1031, getitem_1025, getitem_1019, slice_tensor_51], 1);  getitem_1031 = getitem_1025 = getitem_1019 = slice_tensor_51 = None
        to_dtype_192 = torch.ops.aten.to.dtype(cat_default_45, torch.float32);  cat_default_45 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_234, to_dtype_192);  le_scalar_64 = new_zeros_default_234 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_104, primals_361, primals_359, primals_360, getitem_395, getitem_396, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default_104 = primals_361 = primals_359 = primals_360 = getitem_395 = getitem_396 = None
        getitem_1034 = native_batch_norm_backward_default_65[0]
        getitem_1035 = native_batch_norm_backward_default_65[1]
        getitem_1036 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_1034, relu__default_100, primals_382, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1034 = primals_382 = None
        getitem_1037 = convolution_backward_default_65[0]
        getitem_1038 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(to_dtype_182, getitem_1037);  to_dtype_182 = getitem_1037 = None
        to_dtype_195 = torch.ops.aten.to.dtype(add_tensor_94, torch.float32);  add_tensor_94 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_235, to_dtype_195);  le_scalar_65 = new_zeros_default_235 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_103, primals_336, primals_334, primals_335, getitem_392, getitem_393, True, 1e-05, [True, True, True]);  convolution_default_103 = primals_336 = primals_334 = primals_335 = getitem_392 = getitem_393 = None
        getitem_1040 = native_batch_norm_backward_default_66[0]
        getitem_1041 = native_batch_norm_backward_default_66[1]
        getitem_1042 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_1040, cat_default_19, primals_353, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1040 = cat_default_19 = primals_353 = None
        getitem_1043 = convolution_backward_default_66[0]
        getitem_1044 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        slice_tensor_52 = torch.ops.aten.slice.Tensor(getitem_1043, 1, 0, 104)
        slice_tensor_53 = torch.ops.aten.slice.Tensor(getitem_1043, 1, 104, 208)
        slice_tensor_54 = torch.ops.aten.slice.Tensor(getitem_1043, 1, 208, 312)
        slice_tensor_55 = torch.ops.aten.slice.Tensor(getitem_1043, 1, 312, 416);  getitem_1043 = None
        to_dtype_198 = torch.ops.aten.to.dtype(slice_tensor_54, torch.float32);  slice_tensor_54 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_236, to_dtype_198);  le_scalar_66 = new_zeros_default_236 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_102, primals_351, primals_349, primals_350, getitem_389, getitem_390, True, 1e-05, [True, True, True]);  to_dtype_200 = convolution_default_102 = primals_351 = primals_349 = primals_350 = getitem_389 = getitem_390 = None
        getitem_1046 = native_batch_norm_backward_default_67[0]
        getitem_1047 = native_batch_norm_backward_default_67[1]
        getitem_1048 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_1046, add_tensor_33, primals_356, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1046 = add_tensor_33 = primals_356 = None
        getitem_1049 = convolution_backward_default_67[0]
        getitem_1050 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(slice_tensor_53, getitem_1049);  slice_tensor_53 = None
        to_dtype_201 = torch.ops.aten.to.dtype(add_tensor_95, torch.float32);  add_tensor_95 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_237 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_237, to_dtype_201);  le_scalar_67 = new_zeros_default_237 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_101, primals_346, primals_344, primals_345, getitem_386, getitem_387, True, 1e-05, [True, True, True]);  to_dtype_203 = convolution_default_101 = primals_346 = primals_344 = primals_345 = getitem_386 = getitem_387 = None
        getitem_1052 = native_batch_norm_backward_default_68[0]
        getitem_1053 = native_batch_norm_backward_default_68[1]
        getitem_1054 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_1052, add_tensor_32, primals_355, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1052 = add_tensor_32 = primals_355 = None
        getitem_1055 = convolution_backward_default_68[0]
        getitem_1056 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(slice_tensor_52, getitem_1055);  slice_tensor_52 = None
        to_dtype_204 = torch.ops.aten.to.dtype(add_tensor_96, torch.float32);  add_tensor_96 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_238 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_238, to_dtype_204);  le_scalar_68 = new_zeros_default_238 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_100, primals_341, primals_339, primals_340, getitem_383, getitem_384, True, 1e-05, [True, True, True]);  to_dtype_206 = convolution_default_100 = primals_341 = primals_339 = primals_340 = getitem_383 = getitem_384 = None
        getitem_1058 = native_batch_norm_backward_default_69[0]
        getitem_1059 = native_batch_norm_backward_default_69[1]
        getitem_1060 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_1058, getitem_378, primals_354, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1058 = getitem_378 = primals_354 = None
        getitem_1061 = convolution_backward_default_69[0]
        getitem_1062 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        cat_default_46 = torch.ops.aten.cat.default([getitem_1061, getitem_1055, getitem_1049, slice_tensor_55], 1);  getitem_1061 = getitem_1055 = getitem_1049 = slice_tensor_55 = None
        to_dtype_207 = torch.ops.aten.to.dtype(cat_default_46, torch.float32);  cat_default_46 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_239 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_239, to_dtype_207);  le_scalar_69 = new_zeros_default_239 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_99, primals_331, primals_329, primals_330, getitem_376, getitem_377, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_99 = primals_331 = primals_329 = primals_330 = getitem_376 = getitem_377 = None
        getitem_1064 = native_batch_norm_backward_default_70[0]
        getitem_1065 = native_batch_norm_backward_default_70[1]
        getitem_1066 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_1064, relu__default_95, primals_352, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1064 = primals_352 = None
        getitem_1067 = convolution_backward_default_70[0]
        getitem_1068 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(to_dtype_197, getitem_1067);  to_dtype_197 = getitem_1067 = None
        to_dtype_210 = torch.ops.aten.to.dtype(add_tensor_97, torch.float32);  add_tensor_97 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_240 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_240, to_dtype_210);  le_scalar_70 = new_zeros_default_240 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_98, primals_306, primals_304, primals_305, getitem_373, getitem_374, True, 1e-05, [True, True, True]);  convolution_default_98 = primals_306 = primals_304 = primals_305 = getitem_373 = getitem_374 = None
        getitem_1070 = native_batch_norm_backward_default_71[0]
        getitem_1071 = native_batch_norm_backward_default_71[1]
        getitem_1072 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_1070, cat_default_18, primals_323, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1070 = cat_default_18 = primals_323 = None
        getitem_1073 = convolution_backward_default_71[0]
        getitem_1074 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        slice_tensor_56 = torch.ops.aten.slice.Tensor(getitem_1073, 1, 0, 104)
        slice_tensor_57 = torch.ops.aten.slice.Tensor(getitem_1073, 1, 104, 208)
        slice_tensor_58 = torch.ops.aten.slice.Tensor(getitem_1073, 1, 208, 312)
        slice_tensor_59 = torch.ops.aten.slice.Tensor(getitem_1073, 1, 312, 416);  getitem_1073 = None
        to_dtype_213 = torch.ops.aten.to.dtype(slice_tensor_58, torch.float32);  slice_tensor_58 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_241 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_241, to_dtype_213);  le_scalar_71 = new_zeros_default_241 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_97, primals_321, primals_319, primals_320, getitem_370, getitem_371, True, 1e-05, [True, True, True]);  to_dtype_215 = convolution_default_97 = primals_321 = primals_319 = primals_320 = getitem_370 = getitem_371 = None
        getitem_1076 = native_batch_norm_backward_default_72[0]
        getitem_1077 = native_batch_norm_backward_default_72[1]
        getitem_1078 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_1076, add_tensor_31, primals_326, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1076 = add_tensor_31 = primals_326 = None
        getitem_1079 = convolution_backward_default_72[0]
        getitem_1080 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(slice_tensor_57, getitem_1079);  slice_tensor_57 = None
        to_dtype_216 = torch.ops.aten.to.dtype(add_tensor_98, torch.float32);  add_tensor_98 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_242 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_242, to_dtype_216);  le_scalar_72 = new_zeros_default_242 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_96, primals_316, primals_314, primals_315, getitem_367, getitem_368, True, 1e-05, [True, True, True]);  to_dtype_218 = convolution_default_96 = primals_316 = primals_314 = primals_315 = getitem_367 = getitem_368 = None
        getitem_1082 = native_batch_norm_backward_default_73[0]
        getitem_1083 = native_batch_norm_backward_default_73[1]
        getitem_1084 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_1082, add_tensor_30, primals_325, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1082 = add_tensor_30 = primals_325 = None
        getitem_1085 = convolution_backward_default_73[0]
        getitem_1086 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(slice_tensor_56, getitem_1085);  slice_tensor_56 = None
        to_dtype_219 = torch.ops.aten.to.dtype(add_tensor_99, torch.float32);  add_tensor_99 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_243 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_243, to_dtype_219);  le_scalar_73 = new_zeros_default_243 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_95, primals_311, primals_309, primals_310, getitem_364, getitem_365, True, 1e-05, [True, True, True]);  to_dtype_221 = convolution_default_95 = primals_311 = primals_309 = primals_310 = getitem_364 = getitem_365 = None
        getitem_1088 = native_batch_norm_backward_default_74[0]
        getitem_1089 = native_batch_norm_backward_default_74[1]
        getitem_1090 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_1088, getitem_359, primals_324, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1088 = getitem_359 = primals_324 = None
        getitem_1091 = convolution_backward_default_74[0]
        getitem_1092 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        cat_default_47 = torch.ops.aten.cat.default([getitem_1091, getitem_1085, getitem_1079, slice_tensor_59], 1);  getitem_1091 = getitem_1085 = getitem_1079 = slice_tensor_59 = None
        to_dtype_222 = torch.ops.aten.to.dtype(cat_default_47, torch.float32);  cat_default_47 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_244 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_244, to_dtype_222);  le_scalar_74 = new_zeros_default_244 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_94, primals_301, primals_299, primals_300, getitem_357, getitem_358, True, 1e-05, [True, True, True]);  to_dtype_224 = convolution_default_94 = primals_301 = primals_299 = primals_300 = getitem_357 = getitem_358 = None
        getitem_1094 = native_batch_norm_backward_default_75[0]
        getitem_1095 = native_batch_norm_backward_default_75[1]
        getitem_1096 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_1094, relu__default_90, primals_322, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1094 = primals_322 = None
        getitem_1097 = convolution_backward_default_75[0]
        getitem_1098 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(to_dtype_212, getitem_1097);  to_dtype_212 = getitem_1097 = None
        to_dtype_225 = torch.ops.aten.to.dtype(add_tensor_100, torch.float32);  add_tensor_100 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_245 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_245, to_dtype_225);  le_scalar_75 = new_zeros_default_245 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_93, primals_276, primals_274, primals_275, getitem_354, getitem_355, True, 1e-05, [True, True, True]);  convolution_default_93 = primals_276 = primals_274 = primals_275 = getitem_354 = getitem_355 = None
        getitem_1100 = native_batch_norm_backward_default_76[0]
        getitem_1101 = native_batch_norm_backward_default_76[1]
        getitem_1102 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_1100, cat_default_17, primals_293, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1100 = cat_default_17 = primals_293 = None
        getitem_1103 = convolution_backward_default_76[0]
        getitem_1104 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        slice_tensor_60 = torch.ops.aten.slice.Tensor(getitem_1103, 1, 0, 104)
        slice_tensor_61 = torch.ops.aten.slice.Tensor(getitem_1103, 1, 104, 208)
        slice_tensor_62 = torch.ops.aten.slice.Tensor(getitem_1103, 1, 208, 312)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(getitem_1103, 1, 312, 416);  getitem_1103 = None
        to_dtype_228 = torch.ops.aten.to.dtype(slice_tensor_62, torch.float32);  slice_tensor_62 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_246 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_246, to_dtype_228);  le_scalar_76 = new_zeros_default_246 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_92, primals_291, primals_289, primals_290, getitem_351, getitem_352, True, 1e-05, [True, True, True]);  to_dtype_230 = convolution_default_92 = primals_291 = primals_289 = primals_290 = getitem_351 = getitem_352 = None
        getitem_1106 = native_batch_norm_backward_default_77[0]
        getitem_1107 = native_batch_norm_backward_default_77[1]
        getitem_1108 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_1106, add_tensor_29, primals_296, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1106 = add_tensor_29 = primals_296 = None
        getitem_1109 = convolution_backward_default_77[0]
        getitem_1110 = convolution_backward_default_77[1];  convolution_backward_default_77 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(slice_tensor_61, getitem_1109);  slice_tensor_61 = None
        to_dtype_231 = torch.ops.aten.to.dtype(add_tensor_101, torch.float32);  add_tensor_101 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_247 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_247, to_dtype_231);  le_scalar_77 = new_zeros_default_247 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_91, primals_286, primals_284, primals_285, getitem_348, getitem_349, True, 1e-05, [True, True, True]);  to_dtype_233 = convolution_default_91 = primals_286 = primals_284 = primals_285 = getitem_348 = getitem_349 = None
        getitem_1112 = native_batch_norm_backward_default_78[0]
        getitem_1113 = native_batch_norm_backward_default_78[1]
        getitem_1114 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_1112, add_tensor_28, primals_295, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1112 = add_tensor_28 = primals_295 = None
        getitem_1115 = convolution_backward_default_78[0]
        getitem_1116 = convolution_backward_default_78[1];  convolution_backward_default_78 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(slice_tensor_60, getitem_1115);  slice_tensor_60 = None
        to_dtype_234 = torch.ops.aten.to.dtype(add_tensor_102, torch.float32);  add_tensor_102 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_248 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_248, to_dtype_234);  le_scalar_78 = new_zeros_default_248 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_90, primals_281, primals_279, primals_280, getitem_345, getitem_346, True, 1e-05, [True, True, True]);  to_dtype_236 = convolution_default_90 = primals_281 = primals_279 = primals_280 = getitem_345 = getitem_346 = None
        getitem_1118 = native_batch_norm_backward_default_79[0]
        getitem_1119 = native_batch_norm_backward_default_79[1]
        getitem_1120 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_1118, getitem_340, primals_294, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1118 = getitem_340 = primals_294 = None
        getitem_1121 = convolution_backward_default_79[0]
        getitem_1122 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        cat_default_48 = torch.ops.aten.cat.default([getitem_1121, getitem_1115, getitem_1109, slice_tensor_63], 1);  getitem_1121 = getitem_1115 = getitem_1109 = slice_tensor_63 = None
        to_dtype_237 = torch.ops.aten.to.dtype(cat_default_48, torch.float32);  cat_default_48 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_249 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_249, to_dtype_237);  le_scalar_79 = new_zeros_default_249 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_89, primals_271, primals_269, primals_270, getitem_338, getitem_339, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_89 = primals_271 = primals_269 = primals_270 = getitem_338 = getitem_339 = None
        getitem_1124 = native_batch_norm_backward_default_80[0]
        getitem_1125 = native_batch_norm_backward_default_80[1]
        getitem_1126 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_1124, relu__default_85, primals_292, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1124 = primals_292 = None
        getitem_1127 = convolution_backward_default_80[0]
        getitem_1128 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(to_dtype_227, getitem_1127);  to_dtype_227 = getitem_1127 = None
        to_dtype_240 = torch.ops.aten.to.dtype(add_tensor_103, torch.float32);  add_tensor_103 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_250 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_250, to_dtype_240);  le_scalar_80 = new_zeros_default_250 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_88, primals_906, primals_904, primals_905, getitem_335, getitem_336, True, 1e-05, [True, True, True]);  convolution_default_88 = primals_906 = primals_904 = primals_905 = getitem_335 = getitem_336 = None
        getitem_1130 = native_batch_norm_backward_default_81[0]
        getitem_1131 = native_batch_norm_backward_default_81[1]
        getitem_1132 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_1130, cat_default_16, primals_923, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1130 = cat_default_16 = primals_923 = None
        getitem_1133 = convolution_backward_default_81[0]
        getitem_1134 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        slice_tensor_64 = torch.ops.aten.slice.Tensor(getitem_1133, 1, 0, 104)
        slice_tensor_65 = torch.ops.aten.slice.Tensor(getitem_1133, 1, 104, 208)
        slice_tensor_66 = torch.ops.aten.slice.Tensor(getitem_1133, 1, 208, 312)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(getitem_1133, 1, 312, 416);  getitem_1133 = None
        to_dtype_243 = torch.ops.aten.to.dtype(slice_tensor_66, torch.float32);  slice_tensor_66 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_251 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_251, to_dtype_243);  le_scalar_81 = new_zeros_default_251 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_245, convolution_default_87, primals_921, primals_919, primals_920, getitem_332, getitem_333, True, 1e-05, [True, True, True]);  to_dtype_245 = convolution_default_87 = primals_921 = primals_919 = primals_920 = getitem_332 = getitem_333 = None
        getitem_1136 = native_batch_norm_backward_default_82[0]
        getitem_1137 = native_batch_norm_backward_default_82[1]
        getitem_1138 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_1136, add_tensor_27, primals_926, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1136 = add_tensor_27 = primals_926 = None
        getitem_1139 = convolution_backward_default_82[0]
        getitem_1140 = convolution_backward_default_82[1];  convolution_backward_default_82 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(slice_tensor_65, getitem_1139);  slice_tensor_65 = None
        to_dtype_246 = torch.ops.aten.to.dtype(add_tensor_104, torch.float32);  add_tensor_104 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_252 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_252, to_dtype_246);  le_scalar_82 = new_zeros_default_252 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_86, primals_916, primals_914, primals_915, getitem_329, getitem_330, True, 1e-05, [True, True, True]);  to_dtype_248 = convolution_default_86 = primals_916 = primals_914 = primals_915 = getitem_329 = getitem_330 = None
        getitem_1142 = native_batch_norm_backward_default_83[0]
        getitem_1143 = native_batch_norm_backward_default_83[1]
        getitem_1144 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_1142, add_tensor_26, primals_925, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1142 = add_tensor_26 = primals_925 = None
        getitem_1145 = convolution_backward_default_83[0]
        getitem_1146 = convolution_backward_default_83[1];  convolution_backward_default_83 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(slice_tensor_64, getitem_1145);  slice_tensor_64 = None
        to_dtype_249 = torch.ops.aten.to.dtype(add_tensor_105, torch.float32);  add_tensor_105 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_253 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_253, to_dtype_249);  le_scalar_83 = new_zeros_default_253 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_85, primals_911, primals_909, primals_910, getitem_326, getitem_327, True, 1e-05, [True, True, True]);  to_dtype_251 = convolution_default_85 = primals_911 = primals_909 = primals_910 = getitem_326 = getitem_327 = None
        getitem_1148 = native_batch_norm_backward_default_84[0]
        getitem_1149 = native_batch_norm_backward_default_84[1]
        getitem_1150 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_1148, getitem_321, primals_924, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1148 = getitem_321 = primals_924 = None
        getitem_1151 = convolution_backward_default_84[0]
        getitem_1152 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        cat_default_49 = torch.ops.aten.cat.default([getitem_1151, getitem_1145, getitem_1139, slice_tensor_67], 1);  getitem_1151 = getitem_1145 = getitem_1139 = slice_tensor_67 = None
        to_dtype_252 = torch.ops.aten.to.dtype(cat_default_49, torch.float32);  cat_default_49 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_254 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_254, to_dtype_252);  le_scalar_84 = new_zeros_default_254 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_84, primals_901, primals_899, primals_900, getitem_319, getitem_320, True, 1e-05, [True, True, True]);  to_dtype_254 = convolution_default_84 = primals_901 = primals_899 = primals_900 = getitem_319 = getitem_320 = None
        getitem_1154 = native_batch_norm_backward_default_85[0]
        getitem_1155 = native_batch_norm_backward_default_85[1]
        getitem_1156 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_1154, relu__default_80, primals_922, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1154 = primals_922 = None
        getitem_1157 = convolution_backward_default_85[0]
        getitem_1158 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(to_dtype_242, getitem_1157);  to_dtype_242 = getitem_1157 = None
        to_dtype_255 = torch.ops.aten.to.dtype(add_tensor_106, torch.float32);  add_tensor_106 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_255 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_255, to_dtype_255);  le_scalar_85 = new_zeros_default_255 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_257, convolution_default_83, primals_876, primals_874, primals_875, getitem_316, getitem_317, True, 1e-05, [True, True, True]);  convolution_default_83 = primals_876 = primals_874 = primals_875 = getitem_316 = getitem_317 = None
        getitem_1160 = native_batch_norm_backward_default_86[0]
        getitem_1161 = native_batch_norm_backward_default_86[1]
        getitem_1162 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_1160, cat_default_15, primals_893, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1160 = cat_default_15 = primals_893 = None
        getitem_1163 = convolution_backward_default_86[0]
        getitem_1164 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        slice_tensor_68 = torch.ops.aten.slice.Tensor(getitem_1163, 1, 0, 104)
        slice_tensor_69 = torch.ops.aten.slice.Tensor(getitem_1163, 1, 104, 208)
        slice_tensor_70 = torch.ops.aten.slice.Tensor(getitem_1163, 1, 208, 312)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(getitem_1163, 1, 312, 416);  getitem_1163 = None
        to_dtype_258 = torch.ops.aten.to.dtype(slice_tensor_70, torch.float32);  slice_tensor_70 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_256 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_256, to_dtype_258);  le_scalar_86 = new_zeros_default_256 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_82, primals_891, primals_889, primals_890, getitem_313, getitem_314, True, 1e-05, [True, True, True]);  to_dtype_260 = convolution_default_82 = primals_891 = primals_889 = primals_890 = getitem_313 = getitem_314 = None
        getitem_1166 = native_batch_norm_backward_default_87[0]
        getitem_1167 = native_batch_norm_backward_default_87[1]
        getitem_1168 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_1166, add_tensor_25, primals_896, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1166 = add_tensor_25 = primals_896 = None
        getitem_1169 = convolution_backward_default_87[0]
        getitem_1170 = convolution_backward_default_87[1];  convolution_backward_default_87 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(slice_tensor_69, getitem_1169);  slice_tensor_69 = None
        to_dtype_261 = torch.ops.aten.to.dtype(add_tensor_107, torch.float32);  add_tensor_107 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_257 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_257, to_dtype_261);  le_scalar_87 = new_zeros_default_257 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_81, primals_886, primals_884, primals_885, getitem_310, getitem_311, True, 1e-05, [True, True, True]);  to_dtype_263 = convolution_default_81 = primals_886 = primals_884 = primals_885 = getitem_310 = getitem_311 = None
        getitem_1172 = native_batch_norm_backward_default_88[0]
        getitem_1173 = native_batch_norm_backward_default_88[1]
        getitem_1174 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_1172, add_tensor_24, primals_895, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1172 = add_tensor_24 = primals_895 = None
        getitem_1175 = convolution_backward_default_88[0]
        getitem_1176 = convolution_backward_default_88[1];  convolution_backward_default_88 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(slice_tensor_68, getitem_1175);  slice_tensor_68 = None
        to_dtype_264 = torch.ops.aten.to.dtype(add_tensor_108, torch.float32);  add_tensor_108 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_258 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_258, to_dtype_264);  le_scalar_88 = new_zeros_default_258 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_80, primals_881, primals_879, primals_880, getitem_307, getitem_308, True, 1e-05, [True, True, True]);  to_dtype_266 = convolution_default_80 = primals_881 = primals_879 = primals_880 = getitem_307 = getitem_308 = None
        getitem_1178 = native_batch_norm_backward_default_89[0]
        getitem_1179 = native_batch_norm_backward_default_89[1]
        getitem_1180 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_1178, getitem_302, primals_894, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1178 = getitem_302 = primals_894 = None
        getitem_1181 = convolution_backward_default_89[0]
        getitem_1182 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        cat_default_50 = torch.ops.aten.cat.default([getitem_1181, getitem_1175, getitem_1169, slice_tensor_71], 1);  getitem_1181 = getitem_1175 = getitem_1169 = slice_tensor_71 = None
        to_dtype_267 = torch.ops.aten.to.dtype(cat_default_50, torch.float32);  cat_default_50 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_259 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_259, to_dtype_267);  le_scalar_89 = new_zeros_default_259 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_79, primals_871, primals_869, primals_870, getitem_300, getitem_301, True, 1e-05, [True, True, True]);  to_dtype_269 = convolution_default_79 = primals_871 = primals_869 = primals_870 = getitem_300 = getitem_301 = None
        getitem_1184 = native_batch_norm_backward_default_90[0]
        getitem_1185 = native_batch_norm_backward_default_90[1]
        getitem_1186 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_1184, relu__default_75, primals_892, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1184 = primals_892 = None
        getitem_1187 = convolution_backward_default_90[0]
        getitem_1188 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(to_dtype_257, getitem_1187);  to_dtype_257 = getitem_1187 = None
        to_dtype_270 = torch.ops.aten.to.dtype(add_tensor_109, torch.float32);  add_tensor_109 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_260 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_260, to_dtype_270);  le_scalar_90 = new_zeros_default_260 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_78, primals_846, primals_844, primals_845, getitem_297, getitem_298, True, 1e-05, [True, True, True]);  convolution_default_78 = primals_846 = primals_844 = primals_845 = getitem_297 = getitem_298 = None
        getitem_1190 = native_batch_norm_backward_default_91[0]
        getitem_1191 = native_batch_norm_backward_default_91[1]
        getitem_1192 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_1190, cat_default_14, primals_863, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1190 = cat_default_14 = primals_863 = None
        getitem_1193 = convolution_backward_default_91[0]
        getitem_1194 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        slice_tensor_72 = torch.ops.aten.slice.Tensor(getitem_1193, 1, 0, 104)
        slice_tensor_73 = torch.ops.aten.slice.Tensor(getitem_1193, 1, 104, 208)
        slice_tensor_74 = torch.ops.aten.slice.Tensor(getitem_1193, 1, 208, 312)
        slice_tensor_75 = torch.ops.aten.slice.Tensor(getitem_1193, 1, 312, 416);  getitem_1193 = None
        to_dtype_273 = torch.ops.aten.to.dtype(slice_tensor_74, torch.float32);  slice_tensor_74 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_261 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_261, to_dtype_273);  le_scalar_91 = new_zeros_default_261 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_77, primals_861, primals_859, primals_860, getitem_294, getitem_295, True, 1e-05, [True, True, True]);  to_dtype_275 = convolution_default_77 = primals_861 = primals_859 = primals_860 = getitem_294 = getitem_295 = None
        getitem_1196 = native_batch_norm_backward_default_92[0]
        getitem_1197 = native_batch_norm_backward_default_92[1]
        getitem_1198 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_1196, add_tensor_23, primals_866, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1196 = add_tensor_23 = primals_866 = None
        getitem_1199 = convolution_backward_default_92[0]
        getitem_1200 = convolution_backward_default_92[1];  convolution_backward_default_92 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(slice_tensor_73, getitem_1199);  slice_tensor_73 = None
        to_dtype_276 = torch.ops.aten.to.dtype(add_tensor_110, torch.float32);  add_tensor_110 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_262 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_262, to_dtype_276);  le_scalar_92 = new_zeros_default_262 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_278, convolution_default_76, primals_856, primals_854, primals_855, getitem_291, getitem_292, True, 1e-05, [True, True, True]);  to_dtype_278 = convolution_default_76 = primals_856 = primals_854 = primals_855 = getitem_291 = getitem_292 = None
        getitem_1202 = native_batch_norm_backward_default_93[0]
        getitem_1203 = native_batch_norm_backward_default_93[1]
        getitem_1204 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_1202, add_tensor_22, primals_865, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1202 = add_tensor_22 = primals_865 = None
        getitem_1205 = convolution_backward_default_93[0]
        getitem_1206 = convolution_backward_default_93[1];  convolution_backward_default_93 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(slice_tensor_72, getitem_1205);  slice_tensor_72 = None
        to_dtype_279 = torch.ops.aten.to.dtype(add_tensor_111, torch.float32);  add_tensor_111 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_263 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_263, to_dtype_279);  le_scalar_93 = new_zeros_default_263 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_75, primals_851, primals_849, primals_850, getitem_288, getitem_289, True, 1e-05, [True, True, True]);  to_dtype_281 = convolution_default_75 = primals_851 = primals_849 = primals_850 = getitem_288 = getitem_289 = None
        getitem_1208 = native_batch_norm_backward_default_94[0]
        getitem_1209 = native_batch_norm_backward_default_94[1]
        getitem_1210 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_1208, getitem_283, primals_864, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1208 = getitem_283 = primals_864 = None
        getitem_1211 = convolution_backward_default_94[0]
        getitem_1212 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        cat_default_51 = torch.ops.aten.cat.default([getitem_1211, getitem_1205, getitem_1199, slice_tensor_75], 1);  getitem_1211 = getitem_1205 = getitem_1199 = slice_tensor_75 = None
        to_dtype_282 = torch.ops.aten.to.dtype(cat_default_51, torch.float32);  cat_default_51 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_264, to_dtype_282);  le_scalar_94 = new_zeros_default_264 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_74, primals_841, primals_839, primals_840, getitem_281, getitem_282, True, 1e-05, [True, True, True]);  to_dtype_284 = convolution_default_74 = primals_841 = primals_839 = primals_840 = getitem_281 = getitem_282 = None
        getitem_1214 = native_batch_norm_backward_default_95[0]
        getitem_1215 = native_batch_norm_backward_default_95[1]
        getitem_1216 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_1214, relu__default_70, primals_862, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1214 = primals_862 = None
        getitem_1217 = convolution_backward_default_95[0]
        getitem_1218 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(to_dtype_272, getitem_1217);  to_dtype_272 = getitem_1217 = None
        to_dtype_285 = torch.ops.aten.to.dtype(add_tensor_112, torch.float32);  add_tensor_112 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_265, to_dtype_285);  le_scalar_95 = new_zeros_default_265 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_287, convolution_default_73, primals_816, primals_814, primals_815, getitem_278, getitem_279, True, 1e-05, [True, True, True]);  convolution_default_73 = primals_816 = primals_814 = primals_815 = getitem_278 = getitem_279 = None
        getitem_1220 = native_batch_norm_backward_default_96[0]
        getitem_1221 = native_batch_norm_backward_default_96[1]
        getitem_1222 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_1220, cat_default_13, primals_833, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1220 = cat_default_13 = primals_833 = None
        getitem_1223 = convolution_backward_default_96[0]
        getitem_1224 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        slice_tensor_76 = torch.ops.aten.slice.Tensor(getitem_1223, 1, 0, 104)
        slice_tensor_77 = torch.ops.aten.slice.Tensor(getitem_1223, 1, 104, 208)
        slice_tensor_78 = torch.ops.aten.slice.Tensor(getitem_1223, 1, 208, 312)
        slice_tensor_79 = torch.ops.aten.slice.Tensor(getitem_1223, 1, 312, 416);  getitem_1223 = None
        to_dtype_288 = torch.ops.aten.to.dtype(slice_tensor_78, torch.float32);  slice_tensor_78 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_266, to_dtype_288);  le_scalar_96 = new_zeros_default_266 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_72, primals_831, primals_829, primals_830, getitem_275, getitem_276, True, 1e-05, [True, True, True]);  to_dtype_290 = convolution_default_72 = primals_831 = primals_829 = primals_830 = getitem_275 = getitem_276 = None
        getitem_1226 = native_batch_norm_backward_default_97[0]
        getitem_1227 = native_batch_norm_backward_default_97[1]
        getitem_1228 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_1226, add_tensor_21, primals_836, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1226 = add_tensor_21 = primals_836 = None
        getitem_1229 = convolution_backward_default_97[0]
        getitem_1230 = convolution_backward_default_97[1];  convolution_backward_default_97 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(slice_tensor_77, getitem_1229);  slice_tensor_77 = None
        to_dtype_291 = torch.ops.aten.to.dtype(add_tensor_113, torch.float32);  add_tensor_113 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_267, to_dtype_291);  le_scalar_97 = new_zeros_default_267 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_293, convolution_default_71, primals_826, primals_824, primals_825, getitem_272, getitem_273, True, 1e-05, [True, True, True]);  to_dtype_293 = convolution_default_71 = primals_826 = primals_824 = primals_825 = getitem_272 = getitem_273 = None
        getitem_1232 = native_batch_norm_backward_default_98[0]
        getitem_1233 = native_batch_norm_backward_default_98[1]
        getitem_1234 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_1232, add_tensor_20, primals_835, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1232 = add_tensor_20 = primals_835 = None
        getitem_1235 = convolution_backward_default_98[0]
        getitem_1236 = convolution_backward_default_98[1];  convolution_backward_default_98 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(slice_tensor_76, getitem_1235);  slice_tensor_76 = None
        to_dtype_294 = torch.ops.aten.to.dtype(add_tensor_114, torch.float32);  add_tensor_114 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_268, to_dtype_294);  le_scalar_98 = new_zeros_default_268 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_70, primals_821, primals_819, primals_820, getitem_269, getitem_270, True, 1e-05, [True, True, True]);  to_dtype_296 = convolution_default_70 = primals_821 = primals_819 = primals_820 = getitem_269 = getitem_270 = None
        getitem_1238 = native_batch_norm_backward_default_99[0]
        getitem_1239 = native_batch_norm_backward_default_99[1]
        getitem_1240 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_1238, getitem_264, primals_834, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1238 = getitem_264 = primals_834 = None
        getitem_1241 = convolution_backward_default_99[0]
        getitem_1242 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        cat_default_52 = torch.ops.aten.cat.default([getitem_1241, getitem_1235, getitem_1229, slice_tensor_79], 1);  getitem_1241 = getitem_1235 = getitem_1229 = slice_tensor_79 = None
        to_dtype_297 = torch.ops.aten.to.dtype(cat_default_52, torch.float32);  cat_default_52 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_269, to_dtype_297);  le_scalar_99 = new_zeros_default_269 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_69, primals_811, primals_809, primals_810, getitem_262, getitem_263, True, 1e-05, [True, True, True]);  to_dtype_299 = convolution_default_69 = primals_811 = primals_809 = primals_810 = getitem_262 = getitem_263 = None
        getitem_1244 = native_batch_norm_backward_default_100[0]
        getitem_1245 = native_batch_norm_backward_default_100[1]
        getitem_1246 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_1244, relu__default_65, primals_832, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1244 = primals_832 = None
        getitem_1247 = convolution_backward_default_100[0]
        getitem_1248 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(to_dtype_287, getitem_1247);  to_dtype_287 = getitem_1247 = None
        to_dtype_300 = torch.ops.aten.to.dtype(add_tensor_115, torch.float32);  add_tensor_115 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_270, to_dtype_300);  le_scalar_100 = new_zeros_default_270 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_68, primals_786, primals_784, primals_785, getitem_259, getitem_260, True, 1e-05, [True, True, True]);  convolution_default_68 = primals_786 = primals_784 = primals_785 = getitem_259 = getitem_260 = None
        getitem_1250 = native_batch_norm_backward_default_101[0]
        getitem_1251 = native_batch_norm_backward_default_101[1]
        getitem_1252 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1250, cat_default_12, primals_803, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1250 = cat_default_12 = primals_803 = None
        getitem_1253 = convolution_backward_default_101[0]
        getitem_1254 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        slice_tensor_80 = torch.ops.aten.slice.Tensor(getitem_1253, 1, 0, 104)
        slice_tensor_81 = torch.ops.aten.slice.Tensor(getitem_1253, 1, 104, 208)
        slice_tensor_82 = torch.ops.aten.slice.Tensor(getitem_1253, 1, 208, 312)
        slice_tensor_83 = torch.ops.aten.slice.Tensor(getitem_1253, 1, 312, 416);  getitem_1253 = None
        to_dtype_303 = torch.ops.aten.to.dtype(slice_tensor_82, torch.float32);  slice_tensor_82 = None
        to_dtype_304 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_304, 0);  to_dtype_304 = None
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(to_dtype_303, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_271, to_dtype_303);  le_scalar_101 = new_zeros_default_271 = to_dtype_303 = None
        to_dtype_305 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_305, convolution_default_67, primals_801, primals_799, primals_800, getitem_256, getitem_257, True, 1e-05, [True, True, True]);  to_dtype_305 = convolution_default_67 = primals_801 = primals_799 = primals_800 = getitem_256 = getitem_257 = None
        getitem_1256 = native_batch_norm_backward_default_102[0]
        getitem_1257 = native_batch_norm_backward_default_102[1]
        getitem_1258 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1256, add_tensor_19, primals_806, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1256 = add_tensor_19 = primals_806 = None
        getitem_1259 = convolution_backward_default_102[0]
        getitem_1260 = convolution_backward_default_102[1];  convolution_backward_default_102 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(slice_tensor_81, getitem_1259);  slice_tensor_81 = None
        to_dtype_306 = torch.ops.aten.to.dtype(add_tensor_116, torch.float32);  add_tensor_116 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_272, to_dtype_306);  le_scalar_102 = new_zeros_default_272 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_308, convolution_default_66, primals_796, primals_794, primals_795, getitem_253, getitem_254, True, 1e-05, [True, True, True]);  to_dtype_308 = convolution_default_66 = primals_796 = primals_794 = primals_795 = getitem_253 = getitem_254 = None
        getitem_1262 = native_batch_norm_backward_default_103[0]
        getitem_1263 = native_batch_norm_backward_default_103[1]
        getitem_1264 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_1262, add_tensor_18, primals_805, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1262 = add_tensor_18 = primals_805 = None
        getitem_1265 = convolution_backward_default_103[0]
        getitem_1266 = convolution_backward_default_103[1];  convolution_backward_default_103 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(slice_tensor_80, getitem_1265);  slice_tensor_80 = None
        to_dtype_309 = torch.ops.aten.to.dtype(add_tensor_117, torch.float32);  add_tensor_117 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_273, to_dtype_309);  le_scalar_103 = new_zeros_default_273 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_65, primals_791, primals_789, primals_790, getitem_250, getitem_251, True, 1e-05, [True, True, True]);  to_dtype_311 = convolution_default_65 = primals_791 = primals_789 = primals_790 = getitem_250 = getitem_251 = None
        getitem_1268 = native_batch_norm_backward_default_104[0]
        getitem_1269 = native_batch_norm_backward_default_104[1]
        getitem_1270 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_1268, getitem_245, primals_804, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1268 = getitem_245 = primals_804 = None
        getitem_1271 = convolution_backward_default_104[0]
        getitem_1272 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        cat_default_53 = torch.ops.aten.cat.default([getitem_1271, getitem_1265, getitem_1259, slice_tensor_83], 1);  getitem_1271 = getitem_1265 = getitem_1259 = slice_tensor_83 = None
        to_dtype_312 = torch.ops.aten.to.dtype(cat_default_53, torch.float32);  cat_default_53 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_274 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_274, to_dtype_312);  le_scalar_104 = new_zeros_default_274 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_314, convolution_default_64, primals_781, primals_779, primals_780, getitem_243, getitem_244, True, 1e-05, [True, True, True]);  to_dtype_314 = convolution_default_64 = primals_781 = primals_779 = primals_780 = getitem_243 = getitem_244 = None
        getitem_1274 = native_batch_norm_backward_default_105[0]
        getitem_1275 = native_batch_norm_backward_default_105[1]
        getitem_1276 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_1274, relu__default_60, primals_802, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1274 = primals_802 = None
        getitem_1277 = convolution_backward_default_105[0]
        getitem_1278 = convolution_backward_default_105[1];  convolution_backward_default_105 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(to_dtype_302, getitem_1277);  to_dtype_302 = getitem_1277 = None
        to_dtype_315 = torch.ops.aten.to.dtype(add_tensor_118, torch.float32);  add_tensor_118 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_275 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_275, to_dtype_315);  le_scalar_105 = new_zeros_default_275 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_317, convolution_default_63, primals_756, primals_754, primals_755, getitem_240, getitem_241, True, 1e-05, [True, True, True]);  convolution_default_63 = primals_756 = primals_754 = primals_755 = getitem_240 = getitem_241 = None
        getitem_1280 = native_batch_norm_backward_default_106[0]
        getitem_1281 = native_batch_norm_backward_default_106[1]
        getitem_1282 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_1280, cat_default_11, primals_773, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1280 = cat_default_11 = primals_773 = None
        getitem_1283 = convolution_backward_default_106[0]
        getitem_1284 = convolution_backward_default_106[1];  convolution_backward_default_106 = None
        slice_tensor_84 = torch.ops.aten.slice.Tensor(getitem_1283, 1, 0, 104)
        slice_tensor_85 = torch.ops.aten.slice.Tensor(getitem_1283, 1, 104, 208)
        slice_tensor_86 = torch.ops.aten.slice.Tensor(getitem_1283, 1, 208, 312)
        slice_tensor_87 = torch.ops.aten.slice.Tensor(getitem_1283, 1, 312, 416);  getitem_1283 = None
        to_dtype_318 = torch.ops.aten.to.dtype(slice_tensor_86, torch.float32);  slice_tensor_86 = None
        to_dtype_319 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_319, 0);  to_dtype_319 = None
        new_zeros_default_276 = torch.ops.aten.new_zeros.default(to_dtype_318, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_276, to_dtype_318);  le_scalar_106 = new_zeros_default_276 = to_dtype_318 = None
        to_dtype_320 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_320, convolution_default_62, primals_771, primals_769, primals_770, getitem_237, getitem_238, True, 1e-05, [True, True, True]);  to_dtype_320 = convolution_default_62 = primals_771 = primals_769 = primals_770 = getitem_237 = getitem_238 = None
        getitem_1286 = native_batch_norm_backward_default_107[0]
        getitem_1287 = native_batch_norm_backward_default_107[1]
        getitem_1288 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_1286, add_tensor_17, primals_776, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1286 = add_tensor_17 = primals_776 = None
        getitem_1289 = convolution_backward_default_107[0]
        getitem_1290 = convolution_backward_default_107[1];  convolution_backward_default_107 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(slice_tensor_85, getitem_1289);  slice_tensor_85 = None
        to_dtype_321 = torch.ops.aten.to.dtype(add_tensor_119, torch.float32);  add_tensor_119 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_277 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_277, to_dtype_321);  le_scalar_107 = new_zeros_default_277 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_323, convolution_default_61, primals_766, primals_764, primals_765, getitem_234, getitem_235, True, 1e-05, [True, True, True]);  to_dtype_323 = convolution_default_61 = primals_766 = primals_764 = primals_765 = getitem_234 = getitem_235 = None
        getitem_1292 = native_batch_norm_backward_default_108[0]
        getitem_1293 = native_batch_norm_backward_default_108[1]
        getitem_1294 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1292, add_tensor_16, primals_775, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1292 = add_tensor_16 = primals_775 = None
        getitem_1295 = convolution_backward_default_108[0]
        getitem_1296 = convolution_backward_default_108[1];  convolution_backward_default_108 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(slice_tensor_84, getitem_1295);  slice_tensor_84 = None
        to_dtype_324 = torch.ops.aten.to.dtype(add_tensor_120, torch.float32);  add_tensor_120 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_278 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_278, to_dtype_324);  le_scalar_108 = new_zeros_default_278 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_326, convolution_default_60, primals_761, primals_759, primals_760, getitem_231, getitem_232, True, 1e-05, [True, True, True]);  to_dtype_326 = convolution_default_60 = primals_761 = primals_759 = primals_760 = getitem_231 = getitem_232 = None
        getitem_1298 = native_batch_norm_backward_default_109[0]
        getitem_1299 = native_batch_norm_backward_default_109[1]
        getitem_1300 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1298, getitem_226, primals_774, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1298 = getitem_226 = primals_774 = None
        getitem_1301 = convolution_backward_default_109[0]
        getitem_1302 = convolution_backward_default_109[1];  convolution_backward_default_109 = None
        cat_default_54 = torch.ops.aten.cat.default([getitem_1301, getitem_1295, getitem_1289, slice_tensor_87], 1);  getitem_1301 = getitem_1295 = getitem_1289 = slice_tensor_87 = None
        to_dtype_327 = torch.ops.aten.to.dtype(cat_default_54, torch.float32);  cat_default_54 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_279 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_279, to_dtype_327);  le_scalar_109 = new_zeros_default_279 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_59, primals_751, primals_749, primals_750, getitem_224, getitem_225, True, 1e-05, [True, True, True]);  to_dtype_329 = convolution_default_59 = primals_751 = primals_749 = primals_750 = getitem_224 = getitem_225 = None
        getitem_1304 = native_batch_norm_backward_default_110[0]
        getitem_1305 = native_batch_norm_backward_default_110[1]
        getitem_1306 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1304, relu__default_55, primals_772, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1304 = primals_772 = None
        getitem_1307 = convolution_backward_default_110[0]
        getitem_1308 = convolution_backward_default_110[1];  convolution_backward_default_110 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(to_dtype_317, getitem_1307);  to_dtype_317 = getitem_1307 = None
        to_dtype_330 = torch.ops.aten.to.dtype(add_tensor_121, torch.float32);  add_tensor_121 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_280 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_280, to_dtype_330);  le_scalar_110 = new_zeros_default_280 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_332, convolution_default_58, primals_726, primals_724, primals_725, getitem_221, getitem_222, True, 1e-05, [True, True, True]);  convolution_default_58 = primals_726 = primals_724 = primals_725 = getitem_221 = getitem_222 = None
        getitem_1310 = native_batch_norm_backward_default_111[0]
        getitem_1311 = native_batch_norm_backward_default_111[1]
        getitem_1312 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1310, cat_default_10, primals_743, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1310 = cat_default_10 = primals_743 = None
        getitem_1313 = convolution_backward_default_111[0]
        getitem_1314 = convolution_backward_default_111[1];  convolution_backward_default_111 = None
        slice_tensor_88 = torch.ops.aten.slice.Tensor(getitem_1313, 1, 0, 104)
        slice_tensor_89 = torch.ops.aten.slice.Tensor(getitem_1313, 1, 104, 208)
        slice_tensor_90 = torch.ops.aten.slice.Tensor(getitem_1313, 1, 208, 312)
        slice_tensor_91 = torch.ops.aten.slice.Tensor(getitem_1313, 1, 312, 416);  getitem_1313 = None
        to_dtype_333 = torch.ops.aten.to.dtype(slice_tensor_90, torch.float32);  slice_tensor_90 = None
        to_dtype_334 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_334, 0);  to_dtype_334 = None
        new_zeros_default_281 = torch.ops.aten.new_zeros.default(to_dtype_333, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_281, to_dtype_333);  le_scalar_111 = new_zeros_default_281 = to_dtype_333 = None
        to_dtype_335 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_335, convolution_default_57, primals_741, primals_739, primals_740, getitem_218, getitem_219, True, 1e-05, [True, True, True]);  to_dtype_335 = convolution_default_57 = primals_741 = primals_739 = primals_740 = getitem_218 = getitem_219 = None
        getitem_1316 = native_batch_norm_backward_default_112[0]
        getitem_1317 = native_batch_norm_backward_default_112[1]
        getitem_1318 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_1316, add_tensor_15, primals_746, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1316 = add_tensor_15 = primals_746 = None
        getitem_1319 = convolution_backward_default_112[0]
        getitem_1320 = convolution_backward_default_112[1];  convolution_backward_default_112 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(slice_tensor_89, getitem_1319);  slice_tensor_89 = None
        to_dtype_336 = torch.ops.aten.to.dtype(add_tensor_122, torch.float32);  add_tensor_122 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_282 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_282, to_dtype_336);  le_scalar_112 = new_zeros_default_282 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_338, convolution_default_56, primals_736, primals_734, primals_735, getitem_215, getitem_216, True, 1e-05, [True, True, True]);  to_dtype_338 = convolution_default_56 = primals_736 = primals_734 = primals_735 = getitem_215 = getitem_216 = None
        getitem_1322 = native_batch_norm_backward_default_113[0]
        getitem_1323 = native_batch_norm_backward_default_113[1]
        getitem_1324 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1322, add_tensor_14, primals_745, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1322 = add_tensor_14 = primals_745 = None
        getitem_1325 = convolution_backward_default_113[0]
        getitem_1326 = convolution_backward_default_113[1];  convolution_backward_default_113 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(slice_tensor_88, getitem_1325);  slice_tensor_88 = None
        to_dtype_339 = torch.ops.aten.to.dtype(add_tensor_123, torch.float32);  add_tensor_123 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_283 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_283, to_dtype_339);  le_scalar_113 = new_zeros_default_283 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_55, primals_731, primals_729, primals_730, getitem_212, getitem_213, True, 1e-05, [True, True, True]);  to_dtype_341 = convolution_default_55 = primals_731 = primals_729 = primals_730 = getitem_212 = getitem_213 = None
        getitem_1328 = native_batch_norm_backward_default_114[0]
        getitem_1329 = native_batch_norm_backward_default_114[1]
        getitem_1330 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1328, getitem_207, primals_744, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1328 = getitem_207 = primals_744 = None
        getitem_1331 = convolution_backward_default_114[0]
        getitem_1332 = convolution_backward_default_114[1];  convolution_backward_default_114 = None
        cat_default_55 = torch.ops.aten.cat.default([getitem_1331, getitem_1325, getitem_1319, slice_tensor_91], 1);  getitem_1331 = getitem_1325 = getitem_1319 = slice_tensor_91 = None
        to_dtype_342 = torch.ops.aten.to.dtype(cat_default_55, torch.float32);  cat_default_55 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_284 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_284, to_dtype_342);  le_scalar_114 = new_zeros_default_284 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_344, convolution_default_54, primals_721, primals_719, primals_720, getitem_205, getitem_206, True, 1e-05, [True, True, True]);  to_dtype_344 = convolution_default_54 = primals_721 = primals_719 = primals_720 = getitem_205 = getitem_206 = None
        getitem_1334 = native_batch_norm_backward_default_115[0]
        getitem_1335 = native_batch_norm_backward_default_115[1]
        getitem_1336 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1334, relu__default_50, primals_742, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1334 = primals_742 = None
        getitem_1337 = convolution_backward_default_115[0]
        getitem_1338 = convolution_backward_default_115[1];  convolution_backward_default_115 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(to_dtype_332, getitem_1337);  to_dtype_332 = getitem_1337 = None
        to_dtype_345 = torch.ops.aten.to.dtype(add_tensor_124, torch.float32);  add_tensor_124 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_285 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_285, to_dtype_345);  le_scalar_115 = new_zeros_default_285 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_347, convolution_default_53, primals_696, primals_694, primals_695, getitem_202, getitem_203, True, 1e-05, [True, True, True]);  convolution_default_53 = primals_696 = primals_694 = primals_695 = getitem_202 = getitem_203 = None
        getitem_1340 = native_batch_norm_backward_default_116[0]
        getitem_1341 = native_batch_norm_backward_default_116[1]
        getitem_1342 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1340, cat_default_9, primals_713, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1340 = cat_default_9 = primals_713 = None
        getitem_1343 = convolution_backward_default_116[0]
        getitem_1344 = convolution_backward_default_116[1];  convolution_backward_default_116 = None
        slice_tensor_92 = torch.ops.aten.slice.Tensor(getitem_1343, 1, 0, 104)
        slice_tensor_93 = torch.ops.aten.slice.Tensor(getitem_1343, 1, 104, 208)
        slice_tensor_94 = torch.ops.aten.slice.Tensor(getitem_1343, 1, 208, 312)
        slice_tensor_95 = torch.ops.aten.slice.Tensor(getitem_1343, 1, 312, 416);  getitem_1343 = None
        to_dtype_348 = torch.ops.aten.to.dtype(slice_tensor_94, torch.float32);  slice_tensor_94 = None
        to_dtype_349 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_349, 0);  to_dtype_349 = None
        new_zeros_default_286 = torch.ops.aten.new_zeros.default(to_dtype_348, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_286, to_dtype_348);  le_scalar_116 = new_zeros_default_286 = to_dtype_348 = None
        to_dtype_350 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_350, convolution_default_52, primals_711, primals_709, primals_710, getitem_199, getitem_200, True, 1e-05, [True, True, True]);  to_dtype_350 = convolution_default_52 = primals_711 = primals_709 = primals_710 = getitem_199 = getitem_200 = None
        getitem_1346 = native_batch_norm_backward_default_117[0]
        getitem_1347 = native_batch_norm_backward_default_117[1]
        getitem_1348 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_1346, add_tensor_13, primals_716, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1346 = add_tensor_13 = primals_716 = None
        getitem_1349 = convolution_backward_default_117[0]
        getitem_1350 = convolution_backward_default_117[1];  convolution_backward_default_117 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(slice_tensor_93, getitem_1349);  slice_tensor_93 = None
        to_dtype_351 = torch.ops.aten.to.dtype(add_tensor_125, torch.float32);  add_tensor_125 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_287 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_287, to_dtype_351);  le_scalar_117 = new_zeros_default_287 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_353, convolution_default_51, primals_706, primals_704, primals_705, getitem_196, getitem_197, True, 1e-05, [True, True, True]);  to_dtype_353 = convolution_default_51 = primals_706 = primals_704 = primals_705 = getitem_196 = getitem_197 = None
        getitem_1352 = native_batch_norm_backward_default_118[0]
        getitem_1353 = native_batch_norm_backward_default_118[1]
        getitem_1354 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1352, add_tensor_12, primals_715, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1352 = add_tensor_12 = primals_715 = None
        getitem_1355 = convolution_backward_default_118[0]
        getitem_1356 = convolution_backward_default_118[1];  convolution_backward_default_118 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(slice_tensor_92, getitem_1355);  slice_tensor_92 = None
        to_dtype_354 = torch.ops.aten.to.dtype(add_tensor_126, torch.float32);  add_tensor_126 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_288 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_288, to_dtype_354);  le_scalar_118 = new_zeros_default_288 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_356, convolution_default_50, primals_701, primals_699, primals_700, getitem_193, getitem_194, True, 1e-05, [True, True, True]);  to_dtype_356 = convolution_default_50 = primals_701 = primals_699 = primals_700 = getitem_193 = getitem_194 = None
        getitem_1358 = native_batch_norm_backward_default_119[0]
        getitem_1359 = native_batch_norm_backward_default_119[1]
        getitem_1360 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1358, getitem_188, primals_714, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1358 = getitem_188 = primals_714 = None
        getitem_1361 = convolution_backward_default_119[0]
        getitem_1362 = convolution_backward_default_119[1];  convolution_backward_default_119 = None
        cat_default_56 = torch.ops.aten.cat.default([getitem_1361, getitem_1355, getitem_1349, slice_tensor_95], 1);  getitem_1361 = getitem_1355 = getitem_1349 = slice_tensor_95 = None
        to_dtype_357 = torch.ops.aten.to.dtype(cat_default_56, torch.float32);  cat_default_56 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_289 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_289, to_dtype_357);  le_scalar_119 = new_zeros_default_289 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_49, primals_691, primals_689, primals_690, getitem_186, getitem_187, True, 1e-05, [True, True, True]);  to_dtype_359 = convolution_default_49 = primals_691 = primals_689 = primals_690 = getitem_186 = getitem_187 = None
        getitem_1364 = native_batch_norm_backward_default_120[0]
        getitem_1365 = native_batch_norm_backward_default_120[1]
        getitem_1366 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1364, relu__default_45, primals_712, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1364 = primals_712 = None
        getitem_1367 = convolution_backward_default_120[0]
        getitem_1368 = convolution_backward_default_120[1];  convolution_backward_default_120 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(to_dtype_347, getitem_1367);  to_dtype_347 = getitem_1367 = None
        to_dtype_360 = torch.ops.aten.to.dtype(add_tensor_127, torch.float32);  add_tensor_127 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_290 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_290, to_dtype_360);  le_scalar_120 = new_zeros_default_290 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_362, convolution_default_48, primals_576, primals_574, primals_575, getitem_183, getitem_184, True, 1e-05, [True, True, True]);  convolution_default_48 = primals_576 = primals_574 = primals_575 = getitem_183 = getitem_184 = None
        getitem_1370 = native_batch_norm_backward_default_121[0]
        getitem_1371 = native_batch_norm_backward_default_121[1]
        getitem_1372 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1370, cat_default_8, primals_593, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1370 = cat_default_8 = primals_593 = None
        getitem_1373 = convolution_backward_default_121[0]
        getitem_1374 = convolution_backward_default_121[1];  convolution_backward_default_121 = None
        slice_tensor_96 = torch.ops.aten.slice.Tensor(getitem_1373, 1, 0, 104)
        slice_tensor_97 = torch.ops.aten.slice.Tensor(getitem_1373, 1, 104, 208)
        slice_tensor_98 = torch.ops.aten.slice.Tensor(getitem_1373, 1, 208, 312)
        slice_tensor_99 = torch.ops.aten.slice.Tensor(getitem_1373, 1, 312, 416);  getitem_1373 = None
        to_dtype_363 = torch.ops.aten.to.dtype(slice_tensor_98, torch.float32);  slice_tensor_98 = None
        to_dtype_364 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_364, 0);  to_dtype_364 = None
        new_zeros_default_291 = torch.ops.aten.new_zeros.default(to_dtype_363, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_291, to_dtype_363);  le_scalar_121 = new_zeros_default_291 = to_dtype_363 = None
        to_dtype_365 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_365, convolution_default_47, primals_591, primals_589, primals_590, getitem_180, getitem_181, True, 1e-05, [True, True, True]);  to_dtype_365 = convolution_default_47 = primals_591 = primals_589 = primals_590 = getitem_180 = getitem_181 = None
        getitem_1376 = native_batch_norm_backward_default_122[0]
        getitem_1377 = native_batch_norm_backward_default_122[1]
        getitem_1378 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1376, add_tensor_11, primals_596, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1376 = add_tensor_11 = primals_596 = None
        getitem_1379 = convolution_backward_default_122[0]
        getitem_1380 = convolution_backward_default_122[1];  convolution_backward_default_122 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(slice_tensor_97, getitem_1379);  slice_tensor_97 = None
        to_dtype_366 = torch.ops.aten.to.dtype(add_tensor_128, torch.float32);  add_tensor_128 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_292 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_292, to_dtype_366);  le_scalar_122 = new_zeros_default_292 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_368, convolution_default_46, primals_586, primals_584, primals_585, getitem_177, getitem_178, True, 1e-05, [True, True, True]);  to_dtype_368 = convolution_default_46 = primals_586 = primals_584 = primals_585 = getitem_177 = getitem_178 = None
        getitem_1382 = native_batch_norm_backward_default_123[0]
        getitem_1383 = native_batch_norm_backward_default_123[1]
        getitem_1384 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1382, add_tensor_10, primals_595, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1382 = add_tensor_10 = primals_595 = None
        getitem_1385 = convolution_backward_default_123[0]
        getitem_1386 = convolution_backward_default_123[1];  convolution_backward_default_123 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(slice_tensor_96, getitem_1385);  slice_tensor_96 = None
        to_dtype_369 = torch.ops.aten.to.dtype(add_tensor_129, torch.float32);  add_tensor_129 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_293 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_293, to_dtype_369);  le_scalar_123 = new_zeros_default_293 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_45, primals_581, primals_579, primals_580, getitem_174, getitem_175, True, 1e-05, [True, True, True]);  to_dtype_371 = convolution_default_45 = primals_581 = primals_579 = primals_580 = getitem_174 = getitem_175 = None
        getitem_1388 = native_batch_norm_backward_default_124[0]
        getitem_1389 = native_batch_norm_backward_default_124[1]
        getitem_1390 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1388, getitem_169, primals_594, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1388 = getitem_169 = primals_594 = None
        getitem_1391 = convolution_backward_default_124[0]
        getitem_1392 = convolution_backward_default_124[1];  convolution_backward_default_124 = None
        cat_default_57 = torch.ops.aten.cat.default([getitem_1391, getitem_1385, getitem_1379, slice_tensor_99], 1);  getitem_1391 = getitem_1385 = getitem_1379 = slice_tensor_99 = None
        to_dtype_372 = torch.ops.aten.to.dtype(cat_default_57, torch.float32);  cat_default_57 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_294 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_294, to_dtype_372);  le_scalar_124 = new_zeros_default_294 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_374, convolution_default_44, primals_571, primals_569, primals_570, getitem_167, getitem_168, True, 1e-05, [True, True, True]);  to_dtype_374 = convolution_default_44 = primals_571 = primals_569 = primals_570 = getitem_167 = getitem_168 = None
        getitem_1394 = native_batch_norm_backward_default_125[0]
        getitem_1395 = native_batch_norm_backward_default_125[1]
        getitem_1396 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1394, relu__default_40, primals_592, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1394 = primals_592 = None
        getitem_1397 = convolution_backward_default_125[0]
        getitem_1398 = convolution_backward_default_125[1];  convolution_backward_default_125 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(to_dtype_362, getitem_1397);  to_dtype_362 = getitem_1397 = None
        to_dtype_375 = torch.ops.aten.to.dtype(add_tensor_130, torch.float32);  add_tensor_130 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_295 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_295, to_dtype_375);  le_scalar_125 = new_zeros_default_295 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_43, primals_266, primals_264, primals_265, getitem_164, getitem_165, True, 1e-05, [True, True, True]);  convolution_default_43 = primals_266 = primals_264 = primals_265 = getitem_164 = getitem_165 = None
        getitem_1400 = native_batch_norm_backward_default_126[0]
        getitem_1401 = native_batch_norm_backward_default_126[1]
        getitem_1402 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1400, relu__default_35, primals_261, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1400 = primals_261 = None
        getitem_1403 = convolution_backward_default_126[0]
        getitem_1404 = convolution_backward_default_126[1];  convolution_backward_default_126 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_42, primals_240, primals_238, primals_239, getitem_161, getitem_162, True, 1e-05, [True, True, True]);  to_dtype_377 = convolution_default_42 = primals_240 = primals_238 = primals_239 = getitem_161 = getitem_162 = None
        getitem_1406 = native_batch_norm_backward_default_127[0]
        getitem_1407 = native_batch_norm_backward_default_127[1]
        getitem_1408 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1406, cat_default_7, primals_257, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1406 = cat_default_7 = primals_257 = None
        getitem_1409 = convolution_backward_default_127[0]
        getitem_1410 = convolution_backward_default_127[1];  convolution_backward_default_127 = None
        slice_tensor_100 = torch.ops.aten.slice.Tensor(getitem_1409, 1, 0, 104)
        slice_tensor_101 = torch.ops.aten.slice.Tensor(getitem_1409, 1, 104, 208)
        slice_tensor_102 = torch.ops.aten.slice.Tensor(getitem_1409, 1, 208, 312)
        slice_tensor_103 = torch.ops.aten.slice.Tensor(getitem_1409, 1, 312, 416);  getitem_1409 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_103, getitem_150, [3, 3], [2, 2], [1, 1], False, True, None);  slice_tensor_103 = getitem_150 = None
        to_dtype_378 = torch.ops.aten.to.dtype(slice_tensor_102, torch.float32);  slice_tensor_102 = None
        to_dtype_379 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_379, 0);  to_dtype_379 = None
        new_zeros_default_296 = torch.ops.aten.new_zeros.default(to_dtype_378, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_296, to_dtype_378);  le_scalar_126 = new_zeros_default_296 = to_dtype_378 = None
        to_dtype_380 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_380, convolution_default_41, primals_255, primals_253, primals_254, getitem_158, getitem_159, True, 1e-05, [True, True, True]);  to_dtype_380 = convolution_default_41 = primals_255 = primals_253 = primals_254 = getitem_158 = getitem_159 = None
        getitem_1412 = native_batch_norm_backward_default_128[0]
        getitem_1413 = native_batch_norm_backward_default_128[1]
        getitem_1414 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1412, getitem_149, primals_260, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1412 = getitem_149 = primals_260 = None
        getitem_1415 = convolution_backward_default_128[0]
        getitem_1416 = convolution_backward_default_128[1];  convolution_backward_default_128 = None
        to_dtype_381 = torch.ops.aten.to.dtype(slice_tensor_101, torch.float32);  slice_tensor_101 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_297 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_297, to_dtype_381);  le_scalar_127 = new_zeros_default_297 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_383, convolution_default_40, primals_250, primals_248, primals_249, getitem_155, getitem_156, True, 1e-05, [True, True, True]);  to_dtype_383 = convolution_default_40 = primals_250 = primals_248 = primals_249 = getitem_155 = getitem_156 = None
        getitem_1418 = native_batch_norm_backward_default_129[0]
        getitem_1419 = native_batch_norm_backward_default_129[1]
        getitem_1420 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1418, getitem_148, primals_259, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1418 = getitem_148 = primals_259 = None
        getitem_1421 = convolution_backward_default_129[0]
        getitem_1422 = convolution_backward_default_129[1];  convolution_backward_default_129 = None
        to_dtype_384 = torch.ops.aten.to.dtype(slice_tensor_100, torch.float32);  slice_tensor_100 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_298 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_298, to_dtype_384);  le_scalar_128 = new_zeros_default_298 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_39, primals_245, primals_243, primals_244, getitem_152, getitem_153, True, 1e-05, [True, True, True]);  to_dtype_386 = convolution_default_39 = primals_245 = primals_243 = primals_244 = getitem_152 = getitem_153 = None
        getitem_1424 = native_batch_norm_backward_default_130[0]
        getitem_1425 = native_batch_norm_backward_default_130[1]
        getitem_1426 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1424, getitem_147, primals_258, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1424 = getitem_147 = primals_258 = None
        getitem_1427 = convolution_backward_default_130[0]
        getitem_1428 = convolution_backward_default_130[1];  convolution_backward_default_130 = None
        cat_default_58 = torch.ops.aten.cat.default([getitem_1427, getitem_1421, getitem_1415, avg_pool2d_backward_default_1], 1);  getitem_1427 = getitem_1421 = getitem_1415 = avg_pool2d_backward_default_1 = None
        to_dtype_387 = torch.ops.aten.to.dtype(cat_default_58, torch.float32);  cat_default_58 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_299 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_299, to_dtype_387);  le_scalar_129 = new_zeros_default_299 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_38, primals_235, primals_233, primals_234, getitem_145, getitem_146, True, 1e-05, [True, True, True]);  to_dtype_389 = convolution_default_38 = primals_235 = primals_233 = primals_234 = getitem_145 = getitem_146 = None
        getitem_1430 = native_batch_norm_backward_default_131[0]
        getitem_1431 = native_batch_norm_backward_default_131[1]
        getitem_1432 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1430, relu__default_35, primals_256, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1430 = primals_256 = None
        getitem_1433 = convolution_backward_default_131[0]
        getitem_1434 = convolution_backward_default_131[1];  convolution_backward_default_131 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(getitem_1403, getitem_1433);  getitem_1403 = getitem_1433 = None
        to_dtype_390 = torch.ops.aten.to.dtype(add_tensor_131, torch.float32);  add_tensor_131 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_300 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_300, to_dtype_390);  le_scalar_130 = new_zeros_default_300 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_392, convolution_default_37, primals_210, primals_208, primals_209, getitem_142, getitem_143, True, 1e-05, [True, True, True]);  convolution_default_37 = primals_210 = primals_208 = primals_209 = getitem_142 = getitem_143 = None
        getitem_1436 = native_batch_norm_backward_default_132[0]
        getitem_1437 = native_batch_norm_backward_default_132[1]
        getitem_1438 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(getitem_1436, cat_default_6, primals_227, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1436 = cat_default_6 = primals_227 = None
        getitem_1439 = convolution_backward_default_132[0]
        getitem_1440 = convolution_backward_default_132[1];  convolution_backward_default_132 = None
        slice_tensor_104 = torch.ops.aten.slice.Tensor(getitem_1439, 1, 0, 52)
        slice_tensor_105 = torch.ops.aten.slice.Tensor(getitem_1439, 1, 52, 104)
        slice_tensor_106 = torch.ops.aten.slice.Tensor(getitem_1439, 1, 104, 156)
        slice_tensor_107 = torch.ops.aten.slice.Tensor(getitem_1439, 1, 156, 208);  getitem_1439 = None
        to_dtype_393 = torch.ops.aten.to.dtype(slice_tensor_106, torch.float32);  slice_tensor_106 = None
        to_dtype_394 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_394, 0);  to_dtype_394 = None
        new_zeros_default_301 = torch.ops.aten.new_zeros.default(to_dtype_393, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_301, to_dtype_393);  le_scalar_131 = new_zeros_default_301 = to_dtype_393 = None
        to_dtype_395 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_395, convolution_default_36, primals_225, primals_223, primals_224, getitem_139, getitem_140, True, 1e-05, [True, True, True]);  to_dtype_395 = convolution_default_36 = primals_225 = primals_223 = primals_224 = getitem_139 = getitem_140 = None
        getitem_1442 = native_batch_norm_backward_default_133[0]
        getitem_1443 = native_batch_norm_backward_default_133[1]
        getitem_1444 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1442, add_tensor_9, primals_230, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1442 = add_tensor_9 = primals_230 = None
        getitem_1445 = convolution_backward_default_133[0]
        getitem_1446 = convolution_backward_default_133[1];  convolution_backward_default_133 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(slice_tensor_105, getitem_1445);  slice_tensor_105 = None
        to_dtype_396 = torch.ops.aten.to.dtype(add_tensor_132, torch.float32);  add_tensor_132 = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_302 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_302, to_dtype_396);  le_scalar_132 = new_zeros_default_302 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_398, convolution_default_35, primals_220, primals_218, primals_219, getitem_136, getitem_137, True, 1e-05, [True, True, True]);  to_dtype_398 = convolution_default_35 = primals_220 = primals_218 = primals_219 = getitem_136 = getitem_137 = None
        getitem_1448 = native_batch_norm_backward_default_134[0]
        getitem_1449 = native_batch_norm_backward_default_134[1]
        getitem_1450 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1448, add_tensor_8, primals_229, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1448 = add_tensor_8 = primals_229 = None
        getitem_1451 = convolution_backward_default_134[0]
        getitem_1452 = convolution_backward_default_134[1];  convolution_backward_default_134 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(slice_tensor_104, getitem_1451);  slice_tensor_104 = None
        to_dtype_399 = torch.ops.aten.to.dtype(add_tensor_133, torch.float32);  add_tensor_133 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_133 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_303 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_133 = torch.ops.aten.where.self(le_scalar_133, new_zeros_default_303, to_dtype_399);  le_scalar_133 = new_zeros_default_303 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_133, torch.float32);  where_self_133 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_34, primals_215, primals_213, primals_214, getitem_133, getitem_134, True, 1e-05, [True, True, True]);  to_dtype_401 = convolution_default_34 = primals_215 = primals_213 = primals_214 = getitem_133 = getitem_134 = None
        getitem_1454 = native_batch_norm_backward_default_135[0]
        getitem_1455 = native_batch_norm_backward_default_135[1]
        getitem_1456 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1454, getitem_128, primals_228, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1454 = getitem_128 = primals_228 = None
        getitem_1457 = convolution_backward_default_135[0]
        getitem_1458 = convolution_backward_default_135[1];  convolution_backward_default_135 = None
        cat_default_59 = torch.ops.aten.cat.default([getitem_1457, getitem_1451, getitem_1445, slice_tensor_107], 1);  getitem_1457 = getitem_1451 = getitem_1445 = slice_tensor_107 = None
        to_dtype_402 = torch.ops.aten.to.dtype(cat_default_59, torch.float32);  cat_default_59 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_134 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_304 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_134 = torch.ops.aten.where.self(le_scalar_134, new_zeros_default_304, to_dtype_402);  le_scalar_134 = new_zeros_default_304 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_134, torch.float32);  where_self_134 = None
        native_batch_norm_backward_default_136 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_404, convolution_default_33, primals_205, primals_203, primals_204, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  to_dtype_404 = convolution_default_33 = primals_205 = primals_203 = primals_204 = getitem_126 = getitem_127 = None
        getitem_1460 = native_batch_norm_backward_default_136[0]
        getitem_1461 = native_batch_norm_backward_default_136[1]
        getitem_1462 = native_batch_norm_backward_default_136[2];  native_batch_norm_backward_default_136 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1460, relu__default_30, primals_226, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1460 = primals_226 = None
        getitem_1463 = convolution_backward_default_136[0]
        getitem_1464 = convolution_backward_default_136[1];  convolution_backward_default_136 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(to_dtype_392, getitem_1463);  to_dtype_392 = getitem_1463 = None
        to_dtype_405 = torch.ops.aten.to.dtype(add_tensor_134, torch.float32);  add_tensor_134 = None
        to_dtype_406 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_135 = torch.ops.aten.le.Scalar(to_dtype_406, 0);  to_dtype_406 = None
        new_zeros_default_305 = torch.ops.aten.new_zeros.default(to_dtype_405, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_135 = torch.ops.aten.where.self(le_scalar_135, new_zeros_default_305, to_dtype_405);  le_scalar_135 = new_zeros_default_305 = to_dtype_405 = None
        to_dtype_407 = torch.ops.aten.to.dtype(where_self_135, torch.float32);  where_self_135 = None
        native_batch_norm_backward_default_137 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_407, convolution_default_32, primals_180, primals_178, primals_179, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  convolution_default_32 = primals_180 = primals_178 = primals_179 = getitem_123 = getitem_124 = None
        getitem_1466 = native_batch_norm_backward_default_137[0]
        getitem_1467 = native_batch_norm_backward_default_137[1]
        getitem_1468 = native_batch_norm_backward_default_137[2];  native_batch_norm_backward_default_137 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1466, cat_default_5, primals_197, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1466 = cat_default_5 = primals_197 = None
        getitem_1469 = convolution_backward_default_137[0]
        getitem_1470 = convolution_backward_default_137[1];  convolution_backward_default_137 = None
        slice_tensor_108 = torch.ops.aten.slice.Tensor(getitem_1469, 1, 0, 52)
        slice_tensor_109 = torch.ops.aten.slice.Tensor(getitem_1469, 1, 52, 104)
        slice_tensor_110 = torch.ops.aten.slice.Tensor(getitem_1469, 1, 104, 156)
        slice_tensor_111 = torch.ops.aten.slice.Tensor(getitem_1469, 1, 156, 208);  getitem_1469 = None
        to_dtype_408 = torch.ops.aten.to.dtype(slice_tensor_110, torch.float32);  slice_tensor_110 = None
        to_dtype_409 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_136 = torch.ops.aten.le.Scalar(to_dtype_409, 0);  to_dtype_409 = None
        new_zeros_default_306 = torch.ops.aten.new_zeros.default(to_dtype_408, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_136 = torch.ops.aten.where.self(le_scalar_136, new_zeros_default_306, to_dtype_408);  le_scalar_136 = new_zeros_default_306 = to_dtype_408 = None
        to_dtype_410 = torch.ops.aten.to.dtype(where_self_136, torch.float32);  where_self_136 = None
        native_batch_norm_backward_default_138 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_410, convolution_default_31, primals_195, primals_193, primals_194, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  to_dtype_410 = convolution_default_31 = primals_195 = primals_193 = primals_194 = getitem_120 = getitem_121 = None
        getitem_1472 = native_batch_norm_backward_default_138[0]
        getitem_1473 = native_batch_norm_backward_default_138[1]
        getitem_1474 = native_batch_norm_backward_default_138[2];  native_batch_norm_backward_default_138 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1472, add_tensor_7, primals_200, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1472 = add_tensor_7 = primals_200 = None
        getitem_1475 = convolution_backward_default_138[0]
        getitem_1476 = convolution_backward_default_138[1];  convolution_backward_default_138 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(slice_tensor_109, getitem_1475);  slice_tensor_109 = None
        to_dtype_411 = torch.ops.aten.to.dtype(add_tensor_135, torch.float32);  add_tensor_135 = None
        to_dtype_412 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_137 = torch.ops.aten.le.Scalar(to_dtype_412, 0);  to_dtype_412 = None
        new_zeros_default_307 = torch.ops.aten.new_zeros.default(to_dtype_411, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_137 = torch.ops.aten.where.self(le_scalar_137, new_zeros_default_307, to_dtype_411);  le_scalar_137 = new_zeros_default_307 = to_dtype_411 = None
        to_dtype_413 = torch.ops.aten.to.dtype(where_self_137, torch.float32);  where_self_137 = None
        native_batch_norm_backward_default_139 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_413, convolution_default_30, primals_190, primals_188, primals_189, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  to_dtype_413 = convolution_default_30 = primals_190 = primals_188 = primals_189 = getitem_117 = getitem_118 = None
        getitem_1478 = native_batch_norm_backward_default_139[0]
        getitem_1479 = native_batch_norm_backward_default_139[1]
        getitem_1480 = native_batch_norm_backward_default_139[2];  native_batch_norm_backward_default_139 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1478, add_tensor_6, primals_199, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1478 = add_tensor_6 = primals_199 = None
        getitem_1481 = convolution_backward_default_139[0]
        getitem_1482 = convolution_backward_default_139[1];  convolution_backward_default_139 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(slice_tensor_108, getitem_1481);  slice_tensor_108 = None
        to_dtype_414 = torch.ops.aten.to.dtype(add_tensor_136, torch.float32);  add_tensor_136 = None
        to_dtype_415 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_138 = torch.ops.aten.le.Scalar(to_dtype_415, 0);  to_dtype_415 = None
        new_zeros_default_308 = torch.ops.aten.new_zeros.default(to_dtype_414, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_138 = torch.ops.aten.where.self(le_scalar_138, new_zeros_default_308, to_dtype_414);  le_scalar_138 = new_zeros_default_308 = to_dtype_414 = None
        to_dtype_416 = torch.ops.aten.to.dtype(where_self_138, torch.float32);  where_self_138 = None
        native_batch_norm_backward_default_140 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_416, convolution_default_29, primals_185, primals_183, primals_184, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  to_dtype_416 = convolution_default_29 = primals_185 = primals_183 = primals_184 = getitem_114 = getitem_115 = None
        getitem_1484 = native_batch_norm_backward_default_140[0]
        getitem_1485 = native_batch_norm_backward_default_140[1]
        getitem_1486 = native_batch_norm_backward_default_140[2];  native_batch_norm_backward_default_140 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1484, getitem_109, primals_198, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1484 = getitem_109 = primals_198 = None
        getitem_1487 = convolution_backward_default_140[0]
        getitem_1488 = convolution_backward_default_140[1];  convolution_backward_default_140 = None
        cat_default_60 = torch.ops.aten.cat.default([getitem_1487, getitem_1481, getitem_1475, slice_tensor_111], 1);  getitem_1487 = getitem_1481 = getitem_1475 = slice_tensor_111 = None
        to_dtype_417 = torch.ops.aten.to.dtype(cat_default_60, torch.float32);  cat_default_60 = None
        to_dtype_418 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_139 = torch.ops.aten.le.Scalar(to_dtype_418, 0);  to_dtype_418 = None
        new_zeros_default_309 = torch.ops.aten.new_zeros.default(to_dtype_417, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_139 = torch.ops.aten.where.self(le_scalar_139, new_zeros_default_309, to_dtype_417);  le_scalar_139 = new_zeros_default_309 = to_dtype_417 = None
        to_dtype_419 = torch.ops.aten.to.dtype(where_self_139, torch.float32);  where_self_139 = None
        native_batch_norm_backward_default_141 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_419, convolution_default_28, primals_175, primals_173, primals_174, getitem_107, getitem_108, True, 1e-05, [True, True, True]);  to_dtype_419 = convolution_default_28 = primals_175 = primals_173 = primals_174 = getitem_107 = getitem_108 = None
        getitem_1490 = native_batch_norm_backward_default_141[0]
        getitem_1491 = native_batch_norm_backward_default_141[1]
        getitem_1492 = native_batch_norm_backward_default_141[2];  native_batch_norm_backward_default_141 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_1490, relu__default_25, primals_196, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1490 = primals_196 = None
        getitem_1493 = convolution_backward_default_141[0]
        getitem_1494 = convolution_backward_default_141[1];  convolution_backward_default_141 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(to_dtype_407, getitem_1493);  to_dtype_407 = getitem_1493 = None
        to_dtype_420 = torch.ops.aten.to.dtype(add_tensor_137, torch.float32);  add_tensor_137 = None
        to_dtype_421 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_140 = torch.ops.aten.le.Scalar(to_dtype_421, 0);  to_dtype_421 = None
        new_zeros_default_310 = torch.ops.aten.new_zeros.default(to_dtype_420, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_140 = torch.ops.aten.where.self(le_scalar_140, new_zeros_default_310, to_dtype_420);  le_scalar_140 = new_zeros_default_310 = to_dtype_420 = None
        to_dtype_422 = torch.ops.aten.to.dtype(where_self_140, torch.float32);  where_self_140 = None
        native_batch_norm_backward_default_142 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_422, convolution_default_27, primals_150, primals_148, primals_149, getitem_104, getitem_105, True, 1e-05, [True, True, True]);  convolution_default_27 = primals_150 = primals_148 = primals_149 = getitem_104 = getitem_105 = None
        getitem_1496 = native_batch_norm_backward_default_142[0]
        getitem_1497 = native_batch_norm_backward_default_142[1]
        getitem_1498 = native_batch_norm_backward_default_142[2];  native_batch_norm_backward_default_142 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_1496, cat_default_4, primals_167, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1496 = cat_default_4 = primals_167 = None
        getitem_1499 = convolution_backward_default_142[0]
        getitem_1500 = convolution_backward_default_142[1];  convolution_backward_default_142 = None
        slice_tensor_112 = torch.ops.aten.slice.Tensor(getitem_1499, 1, 0, 52)
        slice_tensor_113 = torch.ops.aten.slice.Tensor(getitem_1499, 1, 52, 104)
        slice_tensor_114 = torch.ops.aten.slice.Tensor(getitem_1499, 1, 104, 156)
        slice_tensor_115 = torch.ops.aten.slice.Tensor(getitem_1499, 1, 156, 208);  getitem_1499 = None
        to_dtype_423 = torch.ops.aten.to.dtype(slice_tensor_114, torch.float32);  slice_tensor_114 = None
        to_dtype_424 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_141 = torch.ops.aten.le.Scalar(to_dtype_424, 0);  to_dtype_424 = None
        new_zeros_default_311 = torch.ops.aten.new_zeros.default(to_dtype_423, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_141 = torch.ops.aten.where.self(le_scalar_141, new_zeros_default_311, to_dtype_423);  le_scalar_141 = new_zeros_default_311 = to_dtype_423 = None
        to_dtype_425 = torch.ops.aten.to.dtype(where_self_141, torch.float32);  where_self_141 = None
        native_batch_norm_backward_default_143 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_425, convolution_default_26, primals_165, primals_163, primals_164, getitem_101, getitem_102, True, 1e-05, [True, True, True]);  to_dtype_425 = convolution_default_26 = primals_165 = primals_163 = primals_164 = getitem_101 = getitem_102 = None
        getitem_1502 = native_batch_norm_backward_default_143[0]
        getitem_1503 = native_batch_norm_backward_default_143[1]
        getitem_1504 = native_batch_norm_backward_default_143[2];  native_batch_norm_backward_default_143 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(getitem_1502, add_tensor_5, primals_170, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1502 = add_tensor_5 = primals_170 = None
        getitem_1505 = convolution_backward_default_143[0]
        getitem_1506 = convolution_backward_default_143[1];  convolution_backward_default_143 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(slice_tensor_113, getitem_1505);  slice_tensor_113 = None
        to_dtype_426 = torch.ops.aten.to.dtype(add_tensor_138, torch.float32);  add_tensor_138 = None
        to_dtype_427 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_142 = torch.ops.aten.le.Scalar(to_dtype_427, 0);  to_dtype_427 = None
        new_zeros_default_312 = torch.ops.aten.new_zeros.default(to_dtype_426, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_142 = torch.ops.aten.where.self(le_scalar_142, new_zeros_default_312, to_dtype_426);  le_scalar_142 = new_zeros_default_312 = to_dtype_426 = None
        to_dtype_428 = torch.ops.aten.to.dtype(where_self_142, torch.float32);  where_self_142 = None
        native_batch_norm_backward_default_144 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_428, convolution_default_25, primals_160, primals_158, primals_159, getitem_98, getitem_99, True, 1e-05, [True, True, True]);  to_dtype_428 = convolution_default_25 = primals_160 = primals_158 = primals_159 = getitem_98 = getitem_99 = None
        getitem_1508 = native_batch_norm_backward_default_144[0]
        getitem_1509 = native_batch_norm_backward_default_144[1]
        getitem_1510 = native_batch_norm_backward_default_144[2];  native_batch_norm_backward_default_144 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1508, add_tensor_4, primals_169, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1508 = add_tensor_4 = primals_169 = None
        getitem_1511 = convolution_backward_default_144[0]
        getitem_1512 = convolution_backward_default_144[1];  convolution_backward_default_144 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(slice_tensor_112, getitem_1511);  slice_tensor_112 = None
        to_dtype_429 = torch.ops.aten.to.dtype(add_tensor_139, torch.float32);  add_tensor_139 = None
        to_dtype_430 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_143 = torch.ops.aten.le.Scalar(to_dtype_430, 0);  to_dtype_430 = None
        new_zeros_default_313 = torch.ops.aten.new_zeros.default(to_dtype_429, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_143 = torch.ops.aten.where.self(le_scalar_143, new_zeros_default_313, to_dtype_429);  le_scalar_143 = new_zeros_default_313 = to_dtype_429 = None
        to_dtype_431 = torch.ops.aten.to.dtype(where_self_143, torch.float32);  where_self_143 = None
        native_batch_norm_backward_default_145 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_431, convolution_default_24, primals_155, primals_153, primals_154, getitem_95, getitem_96, True, 1e-05, [True, True, True]);  to_dtype_431 = convolution_default_24 = primals_155 = primals_153 = primals_154 = getitem_95 = getitem_96 = None
        getitem_1514 = native_batch_norm_backward_default_145[0]
        getitem_1515 = native_batch_norm_backward_default_145[1]
        getitem_1516 = native_batch_norm_backward_default_145[2];  native_batch_norm_backward_default_145 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1514, getitem_90, primals_168, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1514 = getitem_90 = primals_168 = None
        getitem_1517 = convolution_backward_default_145[0]
        getitem_1518 = convolution_backward_default_145[1];  convolution_backward_default_145 = None
        cat_default_61 = torch.ops.aten.cat.default([getitem_1517, getitem_1511, getitem_1505, slice_tensor_115], 1);  getitem_1517 = getitem_1511 = getitem_1505 = slice_tensor_115 = None
        to_dtype_432 = torch.ops.aten.to.dtype(cat_default_61, torch.float32);  cat_default_61 = None
        to_dtype_433 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_144 = torch.ops.aten.le.Scalar(to_dtype_433, 0);  to_dtype_433 = None
        new_zeros_default_314 = torch.ops.aten.new_zeros.default(to_dtype_432, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_144 = torch.ops.aten.where.self(le_scalar_144, new_zeros_default_314, to_dtype_432);  le_scalar_144 = new_zeros_default_314 = to_dtype_432 = None
        to_dtype_434 = torch.ops.aten.to.dtype(where_self_144, torch.float32);  where_self_144 = None
        native_batch_norm_backward_default_146 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_434, convolution_default_23, primals_145, primals_143, primals_144, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  to_dtype_434 = convolution_default_23 = primals_145 = primals_143 = primals_144 = getitem_88 = getitem_89 = None
        getitem_1520 = native_batch_norm_backward_default_146[0]
        getitem_1521 = native_batch_norm_backward_default_146[1]
        getitem_1522 = native_batch_norm_backward_default_146[2];  native_batch_norm_backward_default_146 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1520, relu__default_20, primals_166, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1520 = primals_166 = None
        getitem_1523 = convolution_backward_default_146[0]
        getitem_1524 = convolution_backward_default_146[1];  convolution_backward_default_146 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(to_dtype_422, getitem_1523);  to_dtype_422 = getitem_1523 = None
        to_dtype_435 = torch.ops.aten.to.dtype(add_tensor_140, torch.float32);  add_tensor_140 = None
        to_dtype_436 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_145 = torch.ops.aten.le.Scalar(to_dtype_436, 0);  to_dtype_436 = None
        new_zeros_default_315 = torch.ops.aten.new_zeros.default(to_dtype_435, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_145 = torch.ops.aten.where.self(le_scalar_145, new_zeros_default_315, to_dtype_435);  le_scalar_145 = new_zeros_default_315 = to_dtype_435 = None
        to_dtype_437 = torch.ops.aten.to.dtype(where_self_145, torch.float32);  where_self_145 = None
        native_batch_norm_backward_default_147 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_22, primals_140, primals_138, primals_139, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  convolution_default_22 = primals_140 = primals_138 = primals_139 = getitem_85 = getitem_86 = None
        getitem_1526 = native_batch_norm_backward_default_147[0]
        getitem_1527 = native_batch_norm_backward_default_147[1]
        getitem_1528 = native_batch_norm_backward_default_147[2];  native_batch_norm_backward_default_147 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(getitem_1526, relu__default_15, primals_135, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1526 = primals_135 = None
        getitem_1529 = convolution_backward_default_147[0]
        getitem_1530 = convolution_backward_default_147[1];  convolution_backward_default_147 = None
        native_batch_norm_backward_default_148 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_21, primals_114, primals_112, primals_113, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  to_dtype_437 = convolution_default_21 = primals_114 = primals_112 = primals_113 = getitem_82 = getitem_83 = None
        getitem_1532 = native_batch_norm_backward_default_148[0]
        getitem_1533 = native_batch_norm_backward_default_148[1]
        getitem_1534 = native_batch_norm_backward_default_148[2];  native_batch_norm_backward_default_148 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1532, cat_default_3, primals_131, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1532 = cat_default_3 = primals_131 = None
        getitem_1535 = convolution_backward_default_148[0]
        getitem_1536 = convolution_backward_default_148[1];  convolution_backward_default_148 = None
        slice_tensor_116 = torch.ops.aten.slice.Tensor(getitem_1535, 1, 0, 52)
        slice_tensor_117 = torch.ops.aten.slice.Tensor(getitem_1535, 1, 52, 104)
        slice_tensor_118 = torch.ops.aten.slice.Tensor(getitem_1535, 1, 104, 156)
        slice_tensor_119 = torch.ops.aten.slice.Tensor(getitem_1535, 1, 156, 208);  getitem_1535 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_119, getitem_71, [3, 3], [2, 2], [1, 1], False, True, None);  slice_tensor_119 = getitem_71 = None
        to_dtype_438 = torch.ops.aten.to.dtype(slice_tensor_118, torch.float32);  slice_tensor_118 = None
        to_dtype_439 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_146 = torch.ops.aten.le.Scalar(to_dtype_439, 0);  to_dtype_439 = None
        new_zeros_default_316 = torch.ops.aten.new_zeros.default(to_dtype_438, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_146 = torch.ops.aten.where.self(le_scalar_146, new_zeros_default_316, to_dtype_438);  le_scalar_146 = new_zeros_default_316 = to_dtype_438 = None
        to_dtype_440 = torch.ops.aten.to.dtype(where_self_146, torch.float32);  where_self_146 = None
        native_batch_norm_backward_default_149 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_440, convolution_default_20, primals_129, primals_127, primals_128, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_440 = convolution_default_20 = primals_129 = primals_127 = primals_128 = getitem_79 = getitem_80 = None
        getitem_1538 = native_batch_norm_backward_default_149[0]
        getitem_1539 = native_batch_norm_backward_default_149[1]
        getitem_1540 = native_batch_norm_backward_default_149[2];  native_batch_norm_backward_default_149 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(getitem_1538, getitem_70, primals_134, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1538 = getitem_70 = primals_134 = None
        getitem_1541 = convolution_backward_default_149[0]
        getitem_1542 = convolution_backward_default_149[1];  convolution_backward_default_149 = None
        to_dtype_441 = torch.ops.aten.to.dtype(slice_tensor_117, torch.float32);  slice_tensor_117 = None
        to_dtype_442 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_147 = torch.ops.aten.le.Scalar(to_dtype_442, 0);  to_dtype_442 = None
        new_zeros_default_317 = torch.ops.aten.new_zeros.default(to_dtype_441, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_147 = torch.ops.aten.where.self(le_scalar_147, new_zeros_default_317, to_dtype_441);  le_scalar_147 = new_zeros_default_317 = to_dtype_441 = None
        to_dtype_443 = torch.ops.aten.to.dtype(where_self_147, torch.float32);  where_self_147 = None
        native_batch_norm_backward_default_150 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_443, convolution_default_19, primals_124, primals_122, primals_123, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  to_dtype_443 = convolution_default_19 = primals_124 = primals_122 = primals_123 = getitem_76 = getitem_77 = None
        getitem_1544 = native_batch_norm_backward_default_150[0]
        getitem_1545 = native_batch_norm_backward_default_150[1]
        getitem_1546 = native_batch_norm_backward_default_150[2];  native_batch_norm_backward_default_150 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1544, getitem_69, primals_133, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1544 = getitem_69 = primals_133 = None
        getitem_1547 = convolution_backward_default_150[0]
        getitem_1548 = convolution_backward_default_150[1];  convolution_backward_default_150 = None
        to_dtype_444 = torch.ops.aten.to.dtype(slice_tensor_116, torch.float32);  slice_tensor_116 = None
        to_dtype_445 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_148 = torch.ops.aten.le.Scalar(to_dtype_445, 0);  to_dtype_445 = None
        new_zeros_default_318 = torch.ops.aten.new_zeros.default(to_dtype_444, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_148 = torch.ops.aten.where.self(le_scalar_148, new_zeros_default_318, to_dtype_444);  le_scalar_148 = new_zeros_default_318 = to_dtype_444 = None
        to_dtype_446 = torch.ops.aten.to.dtype(where_self_148, torch.float32);  where_self_148 = None
        native_batch_norm_backward_default_151 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_446, convolution_default_18, primals_119, primals_117, primals_118, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_446 = convolution_default_18 = primals_119 = primals_117 = primals_118 = getitem_73 = getitem_74 = None
        getitem_1550 = native_batch_norm_backward_default_151[0]
        getitem_1551 = native_batch_norm_backward_default_151[1]
        getitem_1552 = native_batch_norm_backward_default_151[2];  native_batch_norm_backward_default_151 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(getitem_1550, getitem_68, primals_132, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1550 = getitem_68 = primals_132 = None
        getitem_1553 = convolution_backward_default_151[0]
        getitem_1554 = convolution_backward_default_151[1];  convolution_backward_default_151 = None
        cat_default_62 = torch.ops.aten.cat.default([getitem_1553, getitem_1547, getitem_1541, avg_pool2d_backward_default_2], 1);  getitem_1553 = getitem_1547 = getitem_1541 = avg_pool2d_backward_default_2 = None
        to_dtype_447 = torch.ops.aten.to.dtype(cat_default_62, torch.float32);  cat_default_62 = None
        to_dtype_448 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_149 = torch.ops.aten.le.Scalar(to_dtype_448, 0);  to_dtype_448 = None
        new_zeros_default_319 = torch.ops.aten.new_zeros.default(to_dtype_447, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_149 = torch.ops.aten.where.self(le_scalar_149, new_zeros_default_319, to_dtype_447);  le_scalar_149 = new_zeros_default_319 = to_dtype_447 = None
        to_dtype_449 = torch.ops.aten.to.dtype(where_self_149, torch.float32);  where_self_149 = None
        native_batch_norm_backward_default_152 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_449, convolution_default_17, primals_109, primals_107, primals_108, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_449 = convolution_default_17 = primals_109 = primals_107 = primals_108 = getitem_66 = getitem_67 = None
        getitem_1556 = native_batch_norm_backward_default_152[0]
        getitem_1557 = native_batch_norm_backward_default_152[1]
        getitem_1558 = native_batch_norm_backward_default_152[2];  native_batch_norm_backward_default_152 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(getitem_1556, relu__default_15, primals_130, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1556 = primals_130 = None
        getitem_1559 = convolution_backward_default_152[0]
        getitem_1560 = convolution_backward_default_152[1];  convolution_backward_default_152 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(getitem_1529, getitem_1559);  getitem_1529 = getitem_1559 = None
        to_dtype_450 = torch.ops.aten.to.dtype(add_tensor_141, torch.float32);  add_tensor_141 = None
        to_dtype_451 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_150 = torch.ops.aten.le.Scalar(to_dtype_451, 0);  to_dtype_451 = None
        new_zeros_default_320 = torch.ops.aten.new_zeros.default(to_dtype_450, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_150 = torch.ops.aten.where.self(le_scalar_150, new_zeros_default_320, to_dtype_450);  le_scalar_150 = new_zeros_default_320 = to_dtype_450 = None
        to_dtype_452 = torch.ops.aten.to.dtype(where_self_150, torch.float32);  where_self_150 = None
        native_batch_norm_backward_default_153 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_452, convolution_default_16, primals_84, primals_82, primals_83, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  convolution_default_16 = primals_84 = primals_82 = primals_83 = getitem_63 = getitem_64 = None
        getitem_1562 = native_batch_norm_backward_default_153[0]
        getitem_1563 = native_batch_norm_backward_default_153[1]
        getitem_1564 = native_batch_norm_backward_default_153[2];  native_batch_norm_backward_default_153 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_1562, cat_default_2, primals_101, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1562 = cat_default_2 = primals_101 = None
        getitem_1565 = convolution_backward_default_153[0]
        getitem_1566 = convolution_backward_default_153[1];  convolution_backward_default_153 = None
        slice_tensor_120 = torch.ops.aten.slice.Tensor(getitem_1565, 1, 0, 26)
        slice_tensor_121 = torch.ops.aten.slice.Tensor(getitem_1565, 1, 26, 52)
        slice_tensor_122 = torch.ops.aten.slice.Tensor(getitem_1565, 1, 52, 78)
        slice_tensor_123 = torch.ops.aten.slice.Tensor(getitem_1565, 1, 78, 104);  getitem_1565 = None
        to_dtype_453 = torch.ops.aten.to.dtype(slice_tensor_122, torch.float32);  slice_tensor_122 = None
        to_dtype_454 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_151 = torch.ops.aten.le.Scalar(to_dtype_454, 0);  to_dtype_454 = None
        new_zeros_default_321 = torch.ops.aten.new_zeros.default(to_dtype_453, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_151 = torch.ops.aten.where.self(le_scalar_151, new_zeros_default_321, to_dtype_453);  le_scalar_151 = new_zeros_default_321 = to_dtype_453 = None
        to_dtype_455 = torch.ops.aten.to.dtype(where_self_151, torch.float32);  where_self_151 = None
        native_batch_norm_backward_default_154 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_455, convolution_default_15, primals_99, primals_97, primals_98, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  to_dtype_455 = convolution_default_15 = primals_99 = primals_97 = primals_98 = getitem_60 = getitem_61 = None
        getitem_1568 = native_batch_norm_backward_default_154[0]
        getitem_1569 = native_batch_norm_backward_default_154[1]
        getitem_1570 = native_batch_norm_backward_default_154[2];  native_batch_norm_backward_default_154 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(getitem_1568, add_tensor_3, primals_104, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1568 = add_tensor_3 = primals_104 = None
        getitem_1571 = convolution_backward_default_154[0]
        getitem_1572 = convolution_backward_default_154[1];  convolution_backward_default_154 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(slice_tensor_121, getitem_1571);  slice_tensor_121 = None
        to_dtype_456 = torch.ops.aten.to.dtype(add_tensor_142, torch.float32);  add_tensor_142 = None
        to_dtype_457 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_152 = torch.ops.aten.le.Scalar(to_dtype_457, 0);  to_dtype_457 = None
        new_zeros_default_322 = torch.ops.aten.new_zeros.default(to_dtype_456, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_152 = torch.ops.aten.where.self(le_scalar_152, new_zeros_default_322, to_dtype_456);  le_scalar_152 = new_zeros_default_322 = to_dtype_456 = None
        to_dtype_458 = torch.ops.aten.to.dtype(where_self_152, torch.float32);  where_self_152 = None
        native_batch_norm_backward_default_155 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_458, convolution_default_14, primals_94, primals_92, primals_93, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_458 = convolution_default_14 = primals_94 = primals_92 = primals_93 = getitem_57 = getitem_58 = None
        getitem_1574 = native_batch_norm_backward_default_155[0]
        getitem_1575 = native_batch_norm_backward_default_155[1]
        getitem_1576 = native_batch_norm_backward_default_155[2];  native_batch_norm_backward_default_155 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1574, add_tensor_2, primals_103, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1574 = add_tensor_2 = primals_103 = None
        getitem_1577 = convolution_backward_default_155[0]
        getitem_1578 = convolution_backward_default_155[1];  convolution_backward_default_155 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(slice_tensor_120, getitem_1577);  slice_tensor_120 = None
        to_dtype_459 = torch.ops.aten.to.dtype(add_tensor_143, torch.float32);  add_tensor_143 = None
        to_dtype_460 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_153 = torch.ops.aten.le.Scalar(to_dtype_460, 0);  to_dtype_460 = None
        new_zeros_default_323 = torch.ops.aten.new_zeros.default(to_dtype_459, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_153 = torch.ops.aten.where.self(le_scalar_153, new_zeros_default_323, to_dtype_459);  le_scalar_153 = new_zeros_default_323 = to_dtype_459 = None
        to_dtype_461 = torch.ops.aten.to.dtype(where_self_153, torch.float32);  where_self_153 = None
        native_batch_norm_backward_default_156 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_461, convolution_default_13, primals_89, primals_87, primals_88, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_461 = convolution_default_13 = primals_89 = primals_87 = primals_88 = getitem_54 = getitem_55 = None
        getitem_1580 = native_batch_norm_backward_default_156[0]
        getitem_1581 = native_batch_norm_backward_default_156[1]
        getitem_1582 = native_batch_norm_backward_default_156[2];  native_batch_norm_backward_default_156 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(getitem_1580, getitem_49, primals_102, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1580 = getitem_49 = primals_102 = None
        getitem_1583 = convolution_backward_default_156[0]
        getitem_1584 = convolution_backward_default_156[1];  convolution_backward_default_156 = None
        cat_default_63 = torch.ops.aten.cat.default([getitem_1583, getitem_1577, getitem_1571, slice_tensor_123], 1);  getitem_1583 = getitem_1577 = getitem_1571 = slice_tensor_123 = None
        to_dtype_462 = torch.ops.aten.to.dtype(cat_default_63, torch.float32);  cat_default_63 = None
        to_dtype_463 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_154 = torch.ops.aten.le.Scalar(to_dtype_463, 0);  to_dtype_463 = None
        new_zeros_default_324 = torch.ops.aten.new_zeros.default(to_dtype_462, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_154 = torch.ops.aten.where.self(le_scalar_154, new_zeros_default_324, to_dtype_462);  le_scalar_154 = new_zeros_default_324 = to_dtype_462 = None
        to_dtype_464 = torch.ops.aten.to.dtype(where_self_154, torch.float32);  where_self_154 = None
        native_batch_norm_backward_default_157 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_464, convolution_default_12, primals_79, primals_77, primals_78, getitem_47, getitem_48, True, 1e-05, [True, True, True]);  to_dtype_464 = convolution_default_12 = primals_79 = primals_77 = primals_78 = getitem_47 = getitem_48 = None
        getitem_1586 = native_batch_norm_backward_default_157[0]
        getitem_1587 = native_batch_norm_backward_default_157[1]
        getitem_1588 = native_batch_norm_backward_default_157[2];  native_batch_norm_backward_default_157 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(getitem_1586, relu__default_10, primals_100, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1586 = primals_100 = None
        getitem_1589 = convolution_backward_default_157[0]
        getitem_1590 = convolution_backward_default_157[1];  convolution_backward_default_157 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(to_dtype_452, getitem_1589);  to_dtype_452 = getitem_1589 = None
        to_dtype_465 = torch.ops.aten.to.dtype(add_tensor_144, torch.float32);  add_tensor_144 = None
        to_dtype_466 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_155 = torch.ops.aten.le.Scalar(to_dtype_466, 0);  to_dtype_466 = None
        new_zeros_default_325 = torch.ops.aten.new_zeros.default(to_dtype_465, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_155 = torch.ops.aten.where.self(le_scalar_155, new_zeros_default_325, to_dtype_465);  le_scalar_155 = new_zeros_default_325 = to_dtype_465 = None
        to_dtype_467 = torch.ops.aten.to.dtype(where_self_155, torch.float32);  where_self_155 = None
        native_batch_norm_backward_default_158 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_467, convolution_default_11, primals_54, primals_52, primals_53, getitem_44, getitem_45, True, 1e-05, [True, True, True]);  convolution_default_11 = primals_54 = primals_52 = primals_53 = getitem_44 = getitem_45 = None
        getitem_1592 = native_batch_norm_backward_default_158[0]
        getitem_1593 = native_batch_norm_backward_default_158[1]
        getitem_1594 = native_batch_norm_backward_default_158[2];  native_batch_norm_backward_default_158 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(getitem_1592, cat_default_1, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1592 = cat_default_1 = primals_71 = None
        getitem_1595 = convolution_backward_default_158[0]
        getitem_1596 = convolution_backward_default_158[1];  convolution_backward_default_158 = None
        slice_tensor_124 = torch.ops.aten.slice.Tensor(getitem_1595, 1, 0, 26)
        slice_tensor_125 = torch.ops.aten.slice.Tensor(getitem_1595, 1, 26, 52)
        slice_tensor_126 = torch.ops.aten.slice.Tensor(getitem_1595, 1, 52, 78)
        slice_tensor_127 = torch.ops.aten.slice.Tensor(getitem_1595, 1, 78, 104);  getitem_1595 = None
        to_dtype_468 = torch.ops.aten.to.dtype(slice_tensor_126, torch.float32);  slice_tensor_126 = None
        to_dtype_469 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_156 = torch.ops.aten.le.Scalar(to_dtype_469, 0);  to_dtype_469 = None
        new_zeros_default_326 = torch.ops.aten.new_zeros.default(to_dtype_468, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_156 = torch.ops.aten.where.self(le_scalar_156, new_zeros_default_326, to_dtype_468);  le_scalar_156 = new_zeros_default_326 = to_dtype_468 = None
        to_dtype_470 = torch.ops.aten.to.dtype(where_self_156, torch.float32);  where_self_156 = None
        native_batch_norm_backward_default_159 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_470, convolution_default_10, primals_69, primals_67, primals_68, getitem_41, getitem_42, True, 1e-05, [True, True, True]);  to_dtype_470 = convolution_default_10 = primals_69 = primals_67 = primals_68 = getitem_41 = getitem_42 = None
        getitem_1598 = native_batch_norm_backward_default_159[0]
        getitem_1599 = native_batch_norm_backward_default_159[1]
        getitem_1600 = native_batch_norm_backward_default_159[2];  native_batch_norm_backward_default_159 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(getitem_1598, add_tensor_1, primals_74, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1598 = add_tensor_1 = primals_74 = None
        getitem_1601 = convolution_backward_default_159[0]
        getitem_1602 = convolution_backward_default_159[1];  convolution_backward_default_159 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(slice_tensor_125, getitem_1601);  slice_tensor_125 = None
        to_dtype_471 = torch.ops.aten.to.dtype(add_tensor_145, torch.float32);  add_tensor_145 = None
        to_dtype_472 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_157 = torch.ops.aten.le.Scalar(to_dtype_472, 0);  to_dtype_472 = None
        new_zeros_default_327 = torch.ops.aten.new_zeros.default(to_dtype_471, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_157 = torch.ops.aten.where.self(le_scalar_157, new_zeros_default_327, to_dtype_471);  le_scalar_157 = new_zeros_default_327 = to_dtype_471 = None
        to_dtype_473 = torch.ops.aten.to.dtype(where_self_157, torch.float32);  where_self_157 = None
        native_batch_norm_backward_default_160 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_473, convolution_default_9, primals_64, primals_62, primals_63, getitem_38, getitem_39, True, 1e-05, [True, True, True]);  to_dtype_473 = convolution_default_9 = primals_64 = primals_62 = primals_63 = getitem_38 = getitem_39 = None
        getitem_1604 = native_batch_norm_backward_default_160[0]
        getitem_1605 = native_batch_norm_backward_default_160[1]
        getitem_1606 = native_batch_norm_backward_default_160[2];  native_batch_norm_backward_default_160 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1604, add_tensor, primals_73, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1604 = add_tensor = primals_73 = None
        getitem_1607 = convolution_backward_default_160[0]
        getitem_1608 = convolution_backward_default_160[1];  convolution_backward_default_160 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(slice_tensor_124, getitem_1607);  slice_tensor_124 = None
        to_dtype_474 = torch.ops.aten.to.dtype(add_tensor_146, torch.float32);  add_tensor_146 = None
        to_dtype_475 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_158 = torch.ops.aten.le.Scalar(to_dtype_475, 0);  to_dtype_475 = None
        new_zeros_default_328 = torch.ops.aten.new_zeros.default(to_dtype_474, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_158 = torch.ops.aten.where.self(le_scalar_158, new_zeros_default_328, to_dtype_474);  le_scalar_158 = new_zeros_default_328 = to_dtype_474 = None
        to_dtype_476 = torch.ops.aten.to.dtype(where_self_158, torch.float32);  where_self_158 = None
        native_batch_norm_backward_default_161 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_476, convolution_default_8, primals_59, primals_57, primals_58, getitem_35, getitem_36, True, 1e-05, [True, True, True]);  to_dtype_476 = convolution_default_8 = primals_59 = primals_57 = primals_58 = getitem_35 = getitem_36 = None
        getitem_1610 = native_batch_norm_backward_default_161[0]
        getitem_1611 = native_batch_norm_backward_default_161[1]
        getitem_1612 = native_batch_norm_backward_default_161[2];  native_batch_norm_backward_default_161 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(getitem_1610, getitem_30, primals_72, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1610 = getitem_30 = primals_72 = None
        getitem_1613 = convolution_backward_default_161[0]
        getitem_1614 = convolution_backward_default_161[1];  convolution_backward_default_161 = None
        cat_default_64 = torch.ops.aten.cat.default([getitem_1613, getitem_1607, getitem_1601, slice_tensor_127], 1);  getitem_1613 = getitem_1607 = getitem_1601 = slice_tensor_127 = None
        to_dtype_477 = torch.ops.aten.to.dtype(cat_default_64, torch.float32);  cat_default_64 = None
        to_dtype_478 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_159 = torch.ops.aten.le.Scalar(to_dtype_478, 0);  to_dtype_478 = None
        new_zeros_default_329 = torch.ops.aten.new_zeros.default(to_dtype_477, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_159 = torch.ops.aten.where.self(le_scalar_159, new_zeros_default_329, to_dtype_477);  le_scalar_159 = new_zeros_default_329 = to_dtype_477 = None
        to_dtype_479 = torch.ops.aten.to.dtype(where_self_159, torch.float32);  where_self_159 = None
        native_batch_norm_backward_default_162 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_479, convolution_default_7, primals_49, primals_47, primals_48, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_479 = convolution_default_7 = primals_49 = primals_47 = primals_48 = getitem_28 = getitem_29 = None
        getitem_1616 = native_batch_norm_backward_default_162[0]
        getitem_1617 = native_batch_norm_backward_default_162[1]
        getitem_1618 = native_batch_norm_backward_default_162[2];  native_batch_norm_backward_default_162 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(getitem_1616, relu__default_5, primals_70, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1616 = primals_70 = None
        getitem_1619 = convolution_backward_default_162[0]
        getitem_1620 = convolution_backward_default_162[1];  convolution_backward_default_162 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(to_dtype_467, getitem_1619);  to_dtype_467 = getitem_1619 = None
        to_dtype_480 = torch.ops.aten.to.dtype(add_tensor_147, torch.float32);  add_tensor_147 = None
        to_dtype_481 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_160 = torch.ops.aten.le.Scalar(to_dtype_481, 0);  to_dtype_481 = None
        new_zeros_default_330 = torch.ops.aten.new_zeros.default(to_dtype_480, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_160 = torch.ops.aten.where.self(le_scalar_160, new_zeros_default_330, to_dtype_480);  le_scalar_160 = new_zeros_default_330 = to_dtype_480 = None
        to_dtype_482 = torch.ops.aten.to.dtype(where_self_160, torch.float32);  where_self_160 = None
        native_batch_norm_backward_default_163 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_482, convolution_default_6, primals_44, primals_42, primals_43, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  convolution_default_6 = primals_44 = primals_42 = primals_43 = getitem_25 = getitem_26 = None
        getitem_1622 = native_batch_norm_backward_default_163[0]
        getitem_1623 = native_batch_norm_backward_default_163[1]
        getitem_1624 = native_batch_norm_backward_default_163[2];  native_batch_norm_backward_default_163 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(getitem_1622, getitem_3, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1622 = primals_39 = None
        getitem_1625 = convolution_backward_default_163[0]
        getitem_1626 = convolution_backward_default_163[1];  convolution_backward_default_163 = None
        native_batch_norm_backward_default_164 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_482, convolution_default_5, primals_18, primals_16, primals_17, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_482 = convolution_default_5 = primals_18 = primals_16 = primals_17 = getitem_22 = getitem_23 = None
        getitem_1628 = native_batch_norm_backward_default_164[0]
        getitem_1629 = native_batch_norm_backward_default_164[1]
        getitem_1630 = native_batch_norm_backward_default_164[2];  native_batch_norm_backward_default_164 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(getitem_1628, cat_default, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1628 = cat_default = primals_35 = None
        getitem_1631 = convolution_backward_default_164[0]
        getitem_1632 = convolution_backward_default_164[1];  convolution_backward_default_164 = None
        slice_tensor_128 = torch.ops.aten.slice.Tensor(getitem_1631, 1, 0, 26)
        slice_tensor_129 = torch.ops.aten.slice.Tensor(getitem_1631, 1, 26, 52)
        slice_tensor_130 = torch.ops.aten.slice.Tensor(getitem_1631, 1, 52, 78)
        slice_tensor_131 = torch.ops.aten.slice.Tensor(getitem_1631, 1, 78, 104);  getitem_1631 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_131, getitem_11, [3, 3], [1, 1], [1, 1], False, True, None);  slice_tensor_131 = getitem_11 = None
        to_dtype_483 = torch.ops.aten.to.dtype(slice_tensor_130, torch.float32);  slice_tensor_130 = None
        to_dtype_484 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_161 = torch.ops.aten.le.Scalar(to_dtype_484, 0);  to_dtype_484 = None
        new_zeros_default_331 = torch.ops.aten.new_zeros.default(to_dtype_483, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_161 = torch.ops.aten.where.self(le_scalar_161, new_zeros_default_331, to_dtype_483);  le_scalar_161 = new_zeros_default_331 = to_dtype_483 = None
        to_dtype_485 = torch.ops.aten.to.dtype(where_self_161, torch.float32);  where_self_161 = None
        native_batch_norm_backward_default_165 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_485, convolution_default_4, primals_33, primals_31, primals_32, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_485 = convolution_default_4 = primals_33 = primals_31 = primals_32 = getitem_19 = getitem_20 = None
        getitem_1634 = native_batch_norm_backward_default_165[0]
        getitem_1635 = native_batch_norm_backward_default_165[1]
        getitem_1636 = native_batch_norm_backward_default_165[2];  native_batch_norm_backward_default_165 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(getitem_1634, getitem_10, primals_38, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1634 = getitem_10 = primals_38 = None
        getitem_1637 = convolution_backward_default_165[0]
        getitem_1638 = convolution_backward_default_165[1];  convolution_backward_default_165 = None
        to_dtype_486 = torch.ops.aten.to.dtype(slice_tensor_129, torch.float32);  slice_tensor_129 = None
        to_dtype_487 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_162 = torch.ops.aten.le.Scalar(to_dtype_487, 0);  to_dtype_487 = None
        new_zeros_default_332 = torch.ops.aten.new_zeros.default(to_dtype_486, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_162 = torch.ops.aten.where.self(le_scalar_162, new_zeros_default_332, to_dtype_486);  le_scalar_162 = new_zeros_default_332 = to_dtype_486 = None
        to_dtype_488 = torch.ops.aten.to.dtype(where_self_162, torch.float32);  where_self_162 = None
        native_batch_norm_backward_default_166 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_488, convolution_default_3, primals_28, primals_26, primals_27, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  to_dtype_488 = convolution_default_3 = primals_28 = primals_26 = primals_27 = getitem_16 = getitem_17 = None
        getitem_1640 = native_batch_norm_backward_default_166[0]
        getitem_1641 = native_batch_norm_backward_default_166[1]
        getitem_1642 = native_batch_norm_backward_default_166[2];  native_batch_norm_backward_default_166 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(getitem_1640, getitem_9, primals_37, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1640 = getitem_9 = primals_37 = None
        getitem_1643 = convolution_backward_default_166[0]
        getitem_1644 = convolution_backward_default_166[1];  convolution_backward_default_166 = None
        to_dtype_489 = torch.ops.aten.to.dtype(slice_tensor_128, torch.float32);  slice_tensor_128 = None
        to_dtype_490 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_163 = torch.ops.aten.le.Scalar(to_dtype_490, 0);  to_dtype_490 = None
        new_zeros_default_333 = torch.ops.aten.new_zeros.default(to_dtype_489, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_163 = torch.ops.aten.where.self(le_scalar_163, new_zeros_default_333, to_dtype_489);  le_scalar_163 = new_zeros_default_333 = to_dtype_489 = None
        to_dtype_491 = torch.ops.aten.to.dtype(where_self_163, torch.float32);  where_self_163 = None
        native_batch_norm_backward_default_167 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_491, convolution_default_2, primals_23, primals_21, primals_22, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_491 = convolution_default_2 = primals_23 = primals_21 = primals_22 = getitem_13 = getitem_14 = None
        getitem_1646 = native_batch_norm_backward_default_167[0]
        getitem_1647 = native_batch_norm_backward_default_167[1]
        getitem_1648 = native_batch_norm_backward_default_167[2];  native_batch_norm_backward_default_167 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(getitem_1646, getitem_8, primals_36, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1646 = getitem_8 = primals_36 = None
        getitem_1649 = convolution_backward_default_167[0]
        getitem_1650 = convolution_backward_default_167[1];  convolution_backward_default_167 = None
        cat_default_65 = torch.ops.aten.cat.default([getitem_1649, getitem_1643, getitem_1637, avg_pool2d_backward_default_3], 1);  getitem_1649 = getitem_1643 = getitem_1637 = avg_pool2d_backward_default_3 = None
        to_dtype_492 = torch.ops.aten.to.dtype(cat_default_65, torch.float32);  cat_default_65 = None
        to_dtype_493 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_164 = torch.ops.aten.le.Scalar(to_dtype_493, 0);  to_dtype_493 = None
        new_zeros_default_334 = torch.ops.aten.new_zeros.default(to_dtype_492, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_164 = torch.ops.aten.where.self(le_scalar_164, new_zeros_default_334, to_dtype_492);  le_scalar_164 = new_zeros_default_334 = to_dtype_492 = None
        to_dtype_494 = torch.ops.aten.to.dtype(where_self_164, torch.float32);  where_self_164 = None
        native_batch_norm_backward_default_168 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_494, convolution_default_1, primals_13, primals_11, primals_12, getitem_6, getitem_7, True, 1e-05, [True, True, True]);  to_dtype_494 = convolution_default_1 = primals_13 = primals_11 = primals_12 = getitem_6 = getitem_7 = None
        getitem_1652 = native_batch_norm_backward_default_168[0]
        getitem_1653 = native_batch_norm_backward_default_168[1]
        getitem_1654 = native_batch_norm_backward_default_168[2];  native_batch_norm_backward_default_168 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1652, getitem_3, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1652 = getitem_3 = primals_34 = None
        getitem_1655 = convolution_backward_default_168[0]
        getitem_1656 = convolution_backward_default_168[1];  convolution_backward_default_168 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(getitem_1625, getitem_1655);  getitem_1625 = getitem_1655 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_148, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  add_tensor_148 = getitem_4 = None
        to_dtype_495 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_496 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_165 = torch.ops.aten.le.Scalar(to_dtype_496, 0);  to_dtype_496 = None
        new_zeros_default_335 = torch.ops.aten.new_zeros.default(to_dtype_495, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_165 = torch.ops.aten.where.self(le_scalar_165, new_zeros_default_335, to_dtype_495);  le_scalar_165 = new_zeros_default_335 = to_dtype_495 = None
        to_dtype_497 = torch.ops.aten.to.dtype(where_self_165, torch.float32);  where_self_165 = None
        native_batch_norm_backward_default_169 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_497, convolution_default, primals_5, primals_3, primals_4, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_497 = convolution_default = primals_5 = primals_3 = primals_4 = getitem_1 = getitem_2 = None
        getitem_1658 = native_batch_norm_backward_default_169[0]
        getitem_1659 = native_batch_norm_backward_default_169[1]
        getitem_1660 = native_batch_norm_backward_default_169[2];  native_batch_norm_backward_default_169 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1658, primals_1023, primals_6, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1658 = primals_1023 = primals_6 = None
        getitem_1662 = convolution_backward_default_169[1];  convolution_backward_default_169 = None
        return [getitem_1660, None, None, None, getitem_1659, getitem_1662, view_default_1, t_default_4, getitem_1654, None, None, None, getitem_1653, getitem_1630, None, None, None, getitem_1629, getitem_1648, None, None, None, getitem_1647, getitem_1642, None, None, None, getitem_1641, getitem_1636, None, None, None, getitem_1635, getitem_1656, getitem_1632, getitem_1650, getitem_1644, getitem_1638, getitem_1626, getitem_1624, None, None, None, getitem_1623, getitem_1618, None, None, None, getitem_1617, getitem_1594, None, None, None, getitem_1593, getitem_1612, None, None, None, getitem_1611, getitem_1606, None, None, None, getitem_1605, getitem_1600, None, None, None, getitem_1599, getitem_1620, getitem_1596, getitem_1614, getitem_1608, getitem_1602, getitem_1588, None, None, None, getitem_1587, getitem_1564, None, None, None, getitem_1563, getitem_1582, None, None, None, getitem_1581, getitem_1576, None, None, None, getitem_1575, getitem_1570, None, None, None, getitem_1569, getitem_1590, getitem_1566, getitem_1584, getitem_1578, getitem_1572, getitem_1558, None, None, None, getitem_1557, getitem_1534, None, None, None, getitem_1533, getitem_1552, None, None, None, getitem_1551, getitem_1546, None, None, None, getitem_1545, getitem_1540, None, None, None, getitem_1539, getitem_1560, getitem_1536, getitem_1554, getitem_1548, getitem_1542, getitem_1530, getitem_1528, None, None, None, getitem_1527, getitem_1522, None, None, None, getitem_1521, getitem_1498, None, None, None, getitem_1497, getitem_1516, None, None, None, getitem_1515, getitem_1510, None, None, None, getitem_1509, getitem_1504, None, None, None, getitem_1503, getitem_1524, getitem_1500, getitem_1518, getitem_1512, getitem_1506, getitem_1492, None, None, None, getitem_1491, getitem_1468, None, None, None, getitem_1467, getitem_1486, None, None, None, getitem_1485, getitem_1480, None, None, None, getitem_1479, getitem_1474, None, None, None, getitem_1473, getitem_1494, getitem_1470, getitem_1488, getitem_1482, getitem_1476, getitem_1462, None, None, None, getitem_1461, getitem_1438, None, None, None, getitem_1437, getitem_1456, None, None, None, getitem_1455, getitem_1450, None, None, None, getitem_1449, getitem_1444, None, None, None, getitem_1443, getitem_1464, getitem_1440, getitem_1458, getitem_1452, getitem_1446, getitem_1432, None, None, None, getitem_1431, getitem_1408, None, None, None, getitem_1407, getitem_1426, None, None, None, getitem_1425, getitem_1420, None, None, None, getitem_1419, getitem_1414, None, None, None, getitem_1413, getitem_1434, getitem_1410, getitem_1428, getitem_1422, getitem_1416, getitem_1404, getitem_1402, None, None, None, getitem_1401, getitem_1126, None, None, None, getitem_1125, getitem_1102, None, None, None, getitem_1101, getitem_1120, None, None, None, getitem_1119, getitem_1114, None, None, None, getitem_1113, getitem_1108, None, None, None, getitem_1107, getitem_1128, getitem_1104, getitem_1122, getitem_1116, getitem_1110, getitem_1096, None, None, None, getitem_1095, getitem_1072, None, None, None, getitem_1071, getitem_1090, None, None, None, getitem_1089, getitem_1084, None, None, None, getitem_1083, getitem_1078, None, None, None, getitem_1077, getitem_1098, getitem_1074, getitem_1092, getitem_1086, getitem_1080, getitem_1066, None, None, None, getitem_1065, getitem_1042, None, None, None, getitem_1041, getitem_1060, None, None, None, getitem_1059, getitem_1054, None, None, None, getitem_1053, getitem_1048, None, None, None, getitem_1047, getitem_1068, getitem_1044, getitem_1062, getitem_1056, getitem_1050, getitem_1036, None, None, None, getitem_1035, getitem_1012, None, None, None, getitem_1011, getitem_1030, None, None, None, getitem_1029, getitem_1024, None, None, None, getitem_1023, getitem_1018, None, None, None, getitem_1017, getitem_1038, getitem_1014, getitem_1032, getitem_1026, getitem_1020, getitem_1006, None, None, None, getitem_1005, getitem_982, None, None, None, getitem_981, getitem_1000, None, None, None, getitem_999, getitem_994, None, None, None, getitem_993, getitem_988, None, None, None, getitem_987, getitem_1008, getitem_984, getitem_1002, getitem_996, getitem_990, getitem_976, None, None, None, getitem_975, getitem_952, None, None, None, getitem_951, getitem_970, None, None, None, getitem_969, getitem_964, None, None, None, getitem_963, getitem_958, None, None, None, getitem_957, getitem_978, getitem_954, getitem_972, getitem_966, getitem_960, getitem_946, None, None, None, getitem_945, getitem_922, None, None, None, getitem_921, getitem_940, None, None, None, getitem_939, getitem_934, None, None, None, getitem_933, getitem_928, None, None, None, getitem_927, getitem_948, getitem_924, getitem_942, getitem_936, getitem_930, getitem_916, None, None, None, getitem_915, getitem_892, None, None, None, getitem_891, getitem_910, None, None, None, getitem_909, getitem_904, None, None, None, getitem_903, getitem_898, None, None, None, getitem_897, getitem_918, getitem_894, getitem_912, getitem_906, getitem_900, getitem_886, None, None, None, getitem_885, getitem_862, None, None, None, getitem_861, getitem_880, None, None, None, getitem_879, getitem_874, None, None, None, getitem_873, getitem_868, None, None, None, getitem_867, getitem_888, getitem_864, getitem_882, getitem_876, getitem_870, getitem_856, None, None, None, getitem_855, getitem_832, None, None, None, getitem_831, getitem_850, None, None, None, getitem_849, getitem_844, None, None, None, getitem_843, getitem_838, None, None, None, getitem_837, getitem_858, getitem_834, getitem_852, getitem_846, getitem_840, getitem_1396, None, None, None, getitem_1395, getitem_1372, None, None, None, getitem_1371, getitem_1390, None, None, None, getitem_1389, getitem_1384, None, None, None, getitem_1383, getitem_1378, None, None, None, getitem_1377, getitem_1398, getitem_1374, getitem_1392, getitem_1386, getitem_1380, getitem_826, None, None, None, getitem_825, getitem_802, None, None, None, getitem_801, getitem_820, None, None, None, getitem_819, getitem_814, None, None, None, getitem_813, getitem_808, None, None, None, getitem_807, getitem_828, getitem_804, getitem_822, getitem_816, getitem_810, getitem_796, None, None, None, getitem_795, getitem_772, None, None, None, getitem_771, getitem_790, None, None, None, getitem_789, getitem_784, None, None, None, getitem_783, getitem_778, None, None, None, getitem_777, getitem_798, getitem_774, getitem_792, getitem_786, getitem_780, getitem_766, None, None, None, getitem_765, getitem_742, None, None, None, getitem_741, getitem_760, None, None, None, getitem_759, getitem_754, None, None, None, getitem_753, getitem_748, None, None, None, getitem_747, getitem_768, getitem_744, getitem_762, getitem_756, getitem_750, getitem_1366, None, None, None, getitem_1365, getitem_1342, None, None, None, getitem_1341, getitem_1360, None, None, None, getitem_1359, getitem_1354, None, None, None, getitem_1353, getitem_1348, None, None, None, getitem_1347, getitem_1368, getitem_1344, getitem_1362, getitem_1356, getitem_1350, getitem_1336, None, None, None, getitem_1335, getitem_1312, None, None, None, getitem_1311, getitem_1330, None, None, None, getitem_1329, getitem_1324, None, None, None, getitem_1323, getitem_1318, None, None, None, getitem_1317, getitem_1338, getitem_1314, getitem_1332, getitem_1326, getitem_1320, getitem_1306, None, None, None, getitem_1305, getitem_1282, None, None, None, getitem_1281, getitem_1300, None, None, None, getitem_1299, getitem_1294, None, None, None, getitem_1293, getitem_1288, None, None, None, getitem_1287, getitem_1308, getitem_1284, getitem_1302, getitem_1296, getitem_1290, getitem_1276, None, None, None, getitem_1275, getitem_1252, None, None, None, getitem_1251, getitem_1270, None, None, None, getitem_1269, getitem_1264, None, None, None, getitem_1263, getitem_1258, None, None, None, getitem_1257, getitem_1278, getitem_1254, getitem_1272, getitem_1266, getitem_1260, getitem_1246, None, None, None, getitem_1245, getitem_1222, None, None, None, getitem_1221, getitem_1240, None, None, None, getitem_1239, getitem_1234, None, None, None, getitem_1233, getitem_1228, None, None, None, getitem_1227, getitem_1248, getitem_1224, getitem_1242, getitem_1236, getitem_1230, getitem_1216, None, None, None, getitem_1215, getitem_1192, None, None, None, getitem_1191, getitem_1210, None, None, None, getitem_1209, getitem_1204, None, None, None, getitem_1203, getitem_1198, None, None, None, getitem_1197, getitem_1218, getitem_1194, getitem_1212, getitem_1206, getitem_1200, getitem_1186, None, None, None, getitem_1185, getitem_1162, None, None, None, getitem_1161, getitem_1180, None, None, None, getitem_1179, getitem_1174, None, None, None, getitem_1173, getitem_1168, None, None, None, getitem_1167, getitem_1188, getitem_1164, getitem_1182, getitem_1176, getitem_1170, getitem_1156, None, None, None, getitem_1155, getitem_1132, None, None, None, getitem_1131, getitem_1150, None, None, None, getitem_1149, getitem_1144, None, None, None, getitem_1143, getitem_1138, None, None, None, getitem_1137, getitem_1158, getitem_1134, getitem_1152, getitem_1146, getitem_1140, getitem_736, None, None, None, getitem_735, getitem_712, None, None, None, getitem_711, getitem_730, None, None, None, getitem_729, getitem_724, None, None, None, getitem_723, getitem_718, None, None, None, getitem_717, getitem_738, getitem_714, getitem_732, getitem_726, getitem_720, getitem_708, getitem_706, None, None, None, getitem_705, getitem_700, None, None, None, getitem_699, getitem_676, None, None, None, getitem_675, getitem_694, None, None, None, getitem_693, getitem_688, None, None, None, getitem_687, getitem_682, None, None, None, getitem_681, getitem_702, getitem_678, getitem_696, getitem_690, getitem_684, getitem_670, None, None, None, getitem_669, getitem_646, None, None, None, getitem_645, getitem_664, None, None, None, getitem_663, getitem_658, None, None, None, getitem_657, getitem_652, None, None, None, getitem_651, getitem_672, getitem_648, getitem_666, getitem_660, getitem_654, None]
        
