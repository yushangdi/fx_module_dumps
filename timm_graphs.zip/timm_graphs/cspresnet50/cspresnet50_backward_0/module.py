
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/cspresnet50/cspresnet50_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_14, primals_181, getitem_94, primals_13, getitem_93, primals_31, convolution_default_8, primals_30, getitem_130, primals_29, primals_87, relu__default_19, getitem_129, primals_28, primals_127, getitem_30, primals_82, primals_26, getitem_29, convolution_default_29, primals_25, primals_24, primals_81, relu__default_27, getitem_97, relu_default_6, primals_23, primals_91, getitem_96, relu__default_5, convolution_default_41, primals_22, primals_21, primals_125, getitem_32, convolution_default_9, primals_12, getitem_133, primals_16, primals_90, relu__default_20, getitem_132, primals_27, primals_15, primals_92, convolution_default_30, primals_86, primals_180, primals_17, getitem_33, relu__default_6, primals_182, relu__default_28, primals_18, convolution_default_10, primals_85, convolution_default_42, primals_19, getitem_99, primals_126, primals_20, getitem_100, primals_321, convolution_default_3, primals_320, relu__default_11, getitem_121, relu__default_1, getitem_65, primals_157, primals_152, getitem_64, relu__default_25, primals_317, convolution_default_38, getitem_59, getitem_58, relu__default_13, primals_315, getitem_11, primals_156, getitem_12, getitem_124, primals_162, getitem_123, convolution_default_20, relu_default_3, primals_316, convolution_default_2, getitem_68, primals_257, convolution_default_18, getitem_61, getitem_67, relu__default_26, convolution_default_44, getitem_9, convolution_default_39, getitem_126, getitem_62, relu_default_4, primals_155, primals_255, getitem_6, getitem_7, convolution_default_40, relu_default_9, relu__default_12, convolution_default_21, getitem_127, primals_256, convolution_default_19, getitem_141, primals_58, primals_287, relu__default, getitem_142, primals_192, primals_190, primals_57, convolution_default_12, getitem_36, primals_56, getitem_35, relu__default_30, primals_55, convolution_default_45, primals_54, primals_52, convolution_default, relu_default_2, primals_51, getitem_145, primals_50, getitem_144, primals_295, primals_49, convolution_default_11, primals_187, primals_186, primals_48, primals_296, primals_44, primals_191, getitem_39, primals_46, relu__default_31, getitem_38, primals_291, primals_45, convolution_default_46, primals_60, getitem_147, primals_61, cat_default, relu__default_7, primals_47, primals_185, primals_292, primals_53, primals_62, primals_286, primals_290, primals_285, getitem_148, getitem_71, getitem_136, getitem_42, primals_197, primals_230, primals_241, primals_235, getitem_135, getitem_41, getitem_70, primals_240, convolution_default_31, primals_172, primals_227, relu__default_14, primals_226, convolution_default_22, relu__default_8, relu_default_10, primals_210, primals_216, getitem_103, getitem_102, convolution_default_13, convolution_default_43, getitem_74, convolution_default_1, primals_206, getitem_1, getitem_73, primals_242, primals_217, getitem_45, primals_205, primals_212, getitem_139, primals_202, getitem_44, primals_160, relu__default_21, getitem_138, primals_170, primals_236, primals_196, primals_171, primals_211, primals_161, primals_232, primals_237, primals_225, relu__default_15, primals_195, convolution_default_32, getitem_105, convolution_default_23, primals_200, relu__default_9, primals_201, cat_default_2, relu_default_5, relu__default_29, convolution_default_14, getitem_76, primals_166, primals_165, relu__default_22, primals_207, getitem_106, primals_167, primals_231, primals_215, convolution_default_33, getitem_77, getitem_47, primals_260, getitem_164, getitem_48, getitem_165, convolution_default_54, primals_37, primals_101, getitem_50, primals_262, getitem_109, primals_272, getitem_108, convolution_default_15, relu__default_35, primals_42, primals_8, primals_32, primals_270, convolution_default_52, primals_331, primals_35, primals_38, primals_325, primals_100, primals_41, primals_326, getitem_53, convolution_default_25, primals_11, relu_default_7, getitem_52, primals_5, primals_43, getitem_168, primals_261, primals_332, getitem_167, primals_36, primals_271, convolution_default_34, primals_34, primals_265, primals_267, primals_97, primals_102, primals_33, relu__default_10, primals_96, getitem_112, relu_default_12, getitem_111, convolution_default_16, primals_4, primals_3, primals_6, primals_95, convolution_default_53, primals_9, getitem_55, primals_40, relu__default_23, primals_10, primals_266, primals_327, convolution_default_35, primals_7, getitem_170, getitem_56, primals_39, getitem_171, primals_330, convolution_default_17, getitem_21, convolution_default_24, relu__default_2, getitem_150, convolution_default_4, getitem_20, relu__default_36, convolution_default_47, primals_251, relu__default_3, cat_default_3, getitem_14, getitem_80, getitem_153, getitem_17, getitem_79, getitem_152, getitem_174, convolution_default_6, getitem_173, getitem_24, relu_default_1, getitem_23, cat_default_1, relu__default_16, relu__default_32, relu_default, relu__default_37, getitem_155, primals_250, convolution_default_48, convolution_default_5, relu__default_4, view_default, primals_245, getitem_82, convolution_default_7, getitem_156, getitem_83, getitem_18, t_default, primals_246, relu__default_17, relu__default_33, convolution_default_49, primals_247, getitem_15, getitem_26, primals_252, convolution_default_26, getitem_27, primals_177, primals_322, primals_276, primals_275, primals_141, getitem_159, primals_280, getitem_158, primals_146, relu_default_11, primals_151, primals_277, getitem_2, convolution_default_50, getitem_4, getitem_162, primals_145, getitem_161, primals_281, relu__default_34, primals_176, primals_142, convolution_default_51, primals_282, primals_147, primals_150, primals_175, primals_76, primals_116, getitem_115, primals_112, primals_71, primals_77, primals_120, primals_137, getitem_114, primals_75, primals_107, getitem_86, primals_306, primals_111, getitem_85, primals_70, primals_300, primals_222, primals_301, primals_72, relu__default_24, primals_136, primals_305, primals_302, primals_106, primals_130, relu__default_18, convolution_default_36, primals_80, primals_105, primals_117, convolution_default_27, getitem_118, getitem_117, primals_121, primals_122, primals_311, getitem_89, primals_115, getitem_88, primals_66, primals_65, primals_140, primals_135, primals_307, relu_default_8, primals_221, primals_132, primals_312, primals_67, primals_131, getitem_3, primals_220, getitem_91, convolution_default_37, primals_110, primals_310, convolution_default_28, getitem_120, primals_297, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50, tangents_51, tangents_52, tangents_53, tangents_54, tangents_55, tangents_56):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1024, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1024, 8, 8]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 64);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_55, to_dtype);  le_scalar = new_zeros_default_55 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_54, primals_332, primals_330, primals_331, getitem_173, getitem_174, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_54 = primals_332 = primals_330 = primals_331 = getitem_173 = getitem_174 = None
        getitem_175 = native_batch_norm_backward_default[0]
        getitem_176 = native_batch_norm_backward_default[1]
        getitem_177 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_175, cat_default_3, primals_56, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_175 = cat_default_3 = primals_56 = None
        getitem_178 = convolution_backward_default[0]
        getitem_179 = convolution_backward_default[1];  convolution_backward_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_178, 1, 0, 1024)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_178, 1, 1024, 2048);  getitem_178 = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor_1, torch.float32);  slice_tensor_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_56, to_dtype_3);  le_scalar_1 = new_zeros_default_56 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_53, primals_327, primals_325, primals_326, getitem_170, getitem_171, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_53 = primals_327 = primals_325 = primals_326 = getitem_170 = getitem_171 = None
        getitem_181 = native_batch_norm_backward_default_1[0]
        getitem_182 = native_batch_norm_backward_default_1[1]
        getitem_183 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_181, relu_default_12, primals_55, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_181 = primals_55 = None
        getitem_184 = convolution_backward_default_1[0]
        getitem_185 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_184, torch.float32);  getitem_184 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_57, to_dtype_6);  le_scalar_2 = new_zeros_default_57 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_52, primals_322, primals_320, primals_321, getitem_167, getitem_168, True, 1e-05, [True, True, True]);  convolution_default_52 = primals_322 = primals_320 = primals_321 = getitem_167 = getitem_168 = None
        getitem_187 = native_batch_norm_backward_default_2[0]
        getitem_188 = native_batch_norm_backward_default_2[1]
        getitem_189 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_187, relu__default_35, primals_52, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_187 = primals_52 = None
        getitem_190 = convolution_backward_default_2[0]
        getitem_191 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_190, torch.float32);  getitem_190 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_58, to_dtype_9);  le_scalar_3 = new_zeros_default_58 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_51, primals_317, primals_315, primals_316, getitem_164, getitem_165, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_51 = primals_317 = primals_315 = primals_316 = getitem_164 = getitem_165 = None
        getitem_193 = native_batch_norm_backward_default_3[0]
        getitem_194 = native_batch_norm_backward_default_3[1]
        getitem_195 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_193, relu__default_34, primals_51, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_193 = primals_51 = None
        getitem_196 = convolution_backward_default_3[0]
        getitem_197 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_196, torch.float32);  getitem_196 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_59, to_dtype_12);  le_scalar_4 = new_zeros_default_59 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_50, primals_312, primals_310, primals_311, getitem_161, getitem_162, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_50 = primals_312 = primals_310 = primals_311 = getitem_161 = getitem_162 = None
        getitem_199 = native_batch_norm_backward_default_4[0]
        getitem_200 = native_batch_norm_backward_default_4[1]
        getitem_201 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_199, relu_default_11, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_199 = primals_50 = None
        getitem_202 = convolution_backward_default_4[0]
        getitem_203 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(to_dtype_8, getitem_202);  to_dtype_8 = getitem_202 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_60, to_dtype_15);  le_scalar_5 = new_zeros_default_60 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_49, primals_307, primals_305, primals_306, getitem_158, getitem_159, True, 1e-05, [True, True, True]);  convolution_default_49 = primals_307 = primals_305 = primals_306 = getitem_158 = getitem_159 = None
        getitem_205 = native_batch_norm_backward_default_5[0]
        getitem_206 = native_batch_norm_backward_default_5[1]
        getitem_207 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_205, relu__default_33, primals_49, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_205 = primals_49 = None
        getitem_208 = convolution_backward_default_5[0]
        getitem_209 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_208, torch.float32);  getitem_208 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_61, to_dtype_18);  le_scalar_6 = new_zeros_default_61 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_48, primals_302, primals_300, primals_301, getitem_155, getitem_156, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_48 = primals_302 = primals_300 = primals_301 = getitem_155 = getitem_156 = None
        getitem_211 = native_batch_norm_backward_default_6[0]
        getitem_212 = native_batch_norm_backward_default_6[1]
        getitem_213 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_211, relu__default_32, primals_48, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_211 = primals_48 = None
        getitem_214 = convolution_backward_default_6[0]
        getitem_215 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_214, torch.float32);  getitem_214 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_62, to_dtype_21);  le_scalar_7 = new_zeros_default_62 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_47, primals_297, primals_295, primals_296, getitem_152, getitem_153, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_47 = primals_297 = primals_295 = primals_296 = getitem_152 = getitem_153 = None
        getitem_217 = native_batch_norm_backward_default_7[0]
        getitem_218 = native_batch_norm_backward_default_7[1]
        getitem_219 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_217, getitem_150, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_217 = getitem_150 = primals_47 = None
        getitem_220 = convolution_backward_default_7[0]
        getitem_221 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(to_dtype_17, getitem_220);  to_dtype_17 = getitem_220 = None
        cat_default_4 = torch.ops.aten.cat.default([slice_tensor, add_tensor_69], 1);  slice_tensor = add_tensor_69 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(cat_default_4, convolution_default_46, primals_292, primals_290, primals_291, getitem_147, getitem_148, True, 1e-05, [True, True, True]);  cat_default_4 = convolution_default_46 = primals_292 = primals_290 = primals_291 = getitem_147 = getitem_148 = None
        getitem_223 = native_batch_norm_backward_default_8[0]
        getitem_224 = native_batch_norm_backward_default_8[1]
        getitem_225 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_223, relu__default_31, primals_54, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_223 = primals_54 = None
        getitem_226 = convolution_backward_default_8[0]
        getitem_227 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_226, torch.float32);  getitem_226 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_63, to_dtype_24);  le_scalar_8 = new_zeros_default_63 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_45, primals_287, primals_285, primals_286, getitem_144, getitem_145, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_45 = primals_287 = primals_285 = primals_286 = getitem_144 = getitem_145 = None
        getitem_229 = native_batch_norm_backward_default_9[0]
        getitem_230 = native_batch_norm_backward_default_9[1]
        getitem_231 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_229, relu__default_30, primals_53, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_229 = primals_53 = None
        getitem_232 = convolution_backward_default_9[0]
        getitem_233 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_232, torch.float32);  getitem_232 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_64, to_dtype_27);  le_scalar_9 = new_zeros_default_64 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_44, primals_282, primals_280, primals_281, getitem_141, getitem_142, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_44 = primals_282 = primals_280 = primals_281 = getitem_141 = getitem_142 = None
        getitem_235 = native_batch_norm_backward_default_10[0]
        getitem_236 = native_batch_norm_backward_default_10[1]
        getitem_237 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_235, cat_default_2, primals_46, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_235 = cat_default_2 = primals_46 = None
        getitem_238 = convolution_backward_default_10[0]
        getitem_239 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_238, 1, 0, 512)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_238, 1, 512, 1024);  getitem_238 = None
        to_dtype_30 = torch.ops.aten.to.dtype(slice_tensor_3, torch.float32);  slice_tensor_3 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_65, to_dtype_30);  le_scalar_10 = new_zeros_default_65 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_43, primals_277, primals_275, primals_276, getitem_138, getitem_139, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_43 = primals_277 = primals_275 = primals_276 = getitem_138 = getitem_139 = None
        getitem_241 = native_batch_norm_backward_default_11[0]
        getitem_242 = native_batch_norm_backward_default_11[1]
        getitem_243 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_241, relu_default_10, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_241 = primals_45 = None
        getitem_244 = convolution_backward_default_11[0]
        getitem_245 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_244, torch.float32);  getitem_244 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_66, to_dtype_33);  le_scalar_11 = new_zeros_default_66 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_42, primals_272, primals_270, primals_271, getitem_135, getitem_136, True, 1e-05, [True, True, True]);  convolution_default_42 = primals_272 = primals_270 = primals_271 = getitem_135 = getitem_136 = None
        getitem_247 = native_batch_norm_backward_default_12[0]
        getitem_248 = native_batch_norm_backward_default_12[1]
        getitem_249 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_247, relu__default_28, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_247 = primals_42 = None
        getitem_250 = convolution_backward_default_12[0]
        getitem_251 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_250, torch.float32);  getitem_250 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_67, to_dtype_36);  le_scalar_12 = new_zeros_default_67 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_41, primals_267, primals_265, primals_266, getitem_132, getitem_133, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_41 = primals_267 = primals_265 = primals_266 = getitem_132 = getitem_133 = None
        getitem_253 = native_batch_norm_backward_default_13[0]
        getitem_254 = native_batch_norm_backward_default_13[1]
        getitem_255 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_253, relu__default_27, primals_41, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_253 = primals_41 = None
        getitem_256 = convolution_backward_default_13[0]
        getitem_257 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_256, torch.float32);  getitem_256 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_68, to_dtype_39);  le_scalar_13 = new_zeros_default_68 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_40, primals_262, primals_260, primals_261, getitem_129, getitem_130, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_40 = primals_262 = primals_260 = primals_261 = getitem_129 = getitem_130 = None
        getitem_259 = native_batch_norm_backward_default_14[0]
        getitem_260 = native_batch_norm_backward_default_14[1]
        getitem_261 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_259, relu_default_9, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_259 = primals_40 = None
        getitem_262 = convolution_backward_default_14[0]
        getitem_263 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(to_dtype_35, getitem_262);  to_dtype_35 = getitem_262 = None
        to_dtype_42 = torch.ops.aten.to.dtype(add_tensor_70, torch.float32);  add_tensor_70 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_69, to_dtype_42);  le_scalar_14 = new_zeros_default_69 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_39, primals_257, primals_255, primals_256, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  convolution_default_39 = primals_257 = primals_255 = primals_256 = getitem_126 = getitem_127 = None
        getitem_265 = native_batch_norm_backward_default_15[0]
        getitem_266 = native_batch_norm_backward_default_15[1]
        getitem_267 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_265, relu__default_26, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_265 = primals_39 = None
        getitem_268 = convolution_backward_default_15[0]
        getitem_269 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_268, torch.float32);  getitem_268 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_70, to_dtype_45);  le_scalar_15 = new_zeros_default_70 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_38, primals_252, primals_250, primals_251, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_38 = primals_252 = primals_250 = primals_251 = getitem_123 = getitem_124 = None
        getitem_271 = native_batch_norm_backward_default_16[0]
        getitem_272 = native_batch_norm_backward_default_16[1]
        getitem_273 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_271, relu__default_25, primals_38, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_271 = primals_38 = None
        getitem_274 = convolution_backward_default_16[0]
        getitem_275 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_274, torch.float32);  getitem_274 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_71, to_dtype_48);  le_scalar_16 = new_zeros_default_71 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_37, primals_247, primals_245, primals_246, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_37 = primals_247 = primals_245 = primals_246 = getitem_120 = getitem_121 = None
        getitem_277 = native_batch_norm_backward_default_17[0]
        getitem_278 = native_batch_norm_backward_default_17[1]
        getitem_279 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_277, relu_default_8, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_277 = primals_37 = None
        getitem_280 = convolution_backward_default_17[0]
        getitem_281 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(to_dtype_44, getitem_280);  to_dtype_44 = getitem_280 = None
        to_dtype_51 = torch.ops.aten.to.dtype(add_tensor_71, torch.float32);  add_tensor_71 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_72, to_dtype_51);  le_scalar_17 = new_zeros_default_72 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_36, primals_242, primals_240, primals_241, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  convolution_default_36 = primals_242 = primals_240 = primals_241 = getitem_117 = getitem_118 = None
        getitem_283 = native_batch_norm_backward_default_18[0]
        getitem_284 = native_batch_norm_backward_default_18[1]
        getitem_285 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_283, relu__default_24, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_283 = primals_36 = None
        getitem_286 = convolution_backward_default_18[0]
        getitem_287 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_286, torch.float32);  getitem_286 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_73, to_dtype_54);  le_scalar_18 = new_zeros_default_73 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_35, primals_237, primals_235, primals_236, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_35 = primals_237 = primals_235 = primals_236 = getitem_114 = getitem_115 = None
        getitem_289 = native_batch_norm_backward_default_19[0]
        getitem_290 = native_batch_norm_backward_default_19[1]
        getitem_291 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_289, relu__default_23, primals_35, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_289 = primals_35 = None
        getitem_292 = convolution_backward_default_19[0]
        getitem_293 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_292, torch.float32);  getitem_292 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_74, to_dtype_57);  le_scalar_19 = new_zeros_default_74 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_34, primals_232, primals_230, primals_231, getitem_111, getitem_112, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_34 = primals_232 = primals_230 = primals_231 = getitem_111 = getitem_112 = None
        getitem_295 = native_batch_norm_backward_default_20[0]
        getitem_296 = native_batch_norm_backward_default_20[1]
        getitem_297 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_295, relu_default_7, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_295 = primals_34 = None
        getitem_298 = convolution_backward_default_20[0]
        getitem_299 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(to_dtype_53, getitem_298);  to_dtype_53 = getitem_298 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_72, torch.float32);  add_tensor_72 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_75, to_dtype_60);  le_scalar_20 = new_zeros_default_75 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_33, primals_227, primals_225, primals_226, getitem_108, getitem_109, True, 1e-05, [True, True, True]);  convolution_default_33 = primals_227 = primals_225 = primals_226 = getitem_108 = getitem_109 = None
        getitem_301 = native_batch_norm_backward_default_21[0]
        getitem_302 = native_batch_norm_backward_default_21[1]
        getitem_303 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_301, relu__default_22, primals_33, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_301 = primals_33 = None
        getitem_304 = convolution_backward_default_21[0]
        getitem_305 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_304, torch.float32);  getitem_304 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_76, to_dtype_63);  le_scalar_21 = new_zeros_default_76 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_32, primals_222, primals_220, primals_221, getitem_105, getitem_106, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_32 = primals_222 = primals_220 = primals_221 = getitem_105 = getitem_106 = None
        getitem_307 = native_batch_norm_backward_default_22[0]
        getitem_308 = native_batch_norm_backward_default_22[1]
        getitem_309 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_307, relu__default_21, primals_32, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_307 = primals_32 = None
        getitem_310 = convolution_backward_default_22[0]
        getitem_311 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_310, torch.float32);  getitem_310 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_77, to_dtype_66);  le_scalar_22 = new_zeros_default_77 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_31, primals_217, primals_215, primals_216, getitem_102, getitem_103, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_31 = primals_217 = primals_215 = primals_216 = getitem_102 = getitem_103 = None
        getitem_313 = native_batch_norm_backward_default_23[0]
        getitem_314 = native_batch_norm_backward_default_23[1]
        getitem_315 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_313, relu_default_6, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_313 = primals_31 = None
        getitem_316 = convolution_backward_default_23[0]
        getitem_317 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_316);  to_dtype_62 = getitem_316 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_73, torch.float32);  add_tensor_73 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_78, to_dtype_69);  le_scalar_23 = new_zeros_default_78 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_30, primals_212, primals_210, primals_211, getitem_99, getitem_100, True, 1e-05, [True, True, True]);  convolution_default_30 = primals_212 = primals_210 = primals_211 = getitem_99 = getitem_100 = None
        getitem_319 = native_batch_norm_backward_default_24[0]
        getitem_320 = native_batch_norm_backward_default_24[1]
        getitem_321 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_319, relu__default_20, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_319 = primals_30 = None
        getitem_322 = convolution_backward_default_24[0]
        getitem_323 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_322, torch.float32);  getitem_322 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_79, to_dtype_72);  le_scalar_24 = new_zeros_default_79 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_29, primals_207, primals_205, primals_206, getitem_96, getitem_97, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_29 = primals_207 = primals_205 = primals_206 = getitem_96 = getitem_97 = None
        getitem_325 = native_batch_norm_backward_default_25[0]
        getitem_326 = native_batch_norm_backward_default_25[1]
        getitem_327 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_325, relu__default_19, primals_29, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_325 = primals_29 = None
        getitem_328 = convolution_backward_default_25[0]
        getitem_329 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_328, torch.float32);  getitem_328 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_80, to_dtype_75);  le_scalar_25 = new_zeros_default_80 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_28, primals_202, primals_200, primals_201, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_28 = primals_202 = primals_200 = primals_201 = getitem_93 = getitem_94 = None
        getitem_331 = native_batch_norm_backward_default_26[0]
        getitem_332 = native_batch_norm_backward_default_26[1]
        getitem_333 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_331, getitem_91, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_331 = getitem_91 = primals_28 = None
        getitem_334 = convolution_backward_default_26[0]
        getitem_335 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(to_dtype_71, getitem_334);  to_dtype_71 = getitem_334 = None
        cat_default_5 = torch.ops.aten.cat.default([slice_tensor_2, add_tensor_74], 1);  slice_tensor_2 = add_tensor_74 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(cat_default_5, convolution_default_27, primals_197, primals_195, primals_196, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  cat_default_5 = convolution_default_27 = primals_197 = primals_195 = primals_196 = getitem_88 = getitem_89 = None
        getitem_337 = native_batch_norm_backward_default_27[0]
        getitem_338 = native_batch_norm_backward_default_27[1]
        getitem_339 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_337, relu__default_18, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_337 = primals_44 = None
        getitem_340 = convolution_backward_default_27[0]
        getitem_341 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_340, torch.float32);  getitem_340 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_81, to_dtype_78);  le_scalar_26 = new_zeros_default_81 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_26, primals_192, primals_190, primals_191, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_26 = primals_192 = primals_190 = primals_191 = getitem_85 = getitem_86 = None
        getitem_343 = native_batch_norm_backward_default_28[0]
        getitem_344 = native_batch_norm_backward_default_28[1]
        getitem_345 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_343, relu__default_17, primals_43, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_343 = primals_43 = None
        getitem_346 = convolution_backward_default_28[0]
        getitem_347 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_346, torch.float32);  getitem_346 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_82, to_dtype_81);  le_scalar_27 = new_zeros_default_82 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_25, primals_187, primals_185, primals_186, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_25 = primals_187 = primals_185 = primals_186 = getitem_82 = getitem_83 = None
        getitem_349 = native_batch_norm_backward_default_29[0]
        getitem_350 = native_batch_norm_backward_default_29[1]
        getitem_351 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_349, cat_default_1, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_349 = cat_default_1 = primals_27 = None
        getitem_352 = convolution_backward_default_29[0]
        getitem_353 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_352, 1, 0, 256)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_352, 1, 256, 512);  getitem_352 = None
        to_dtype_84 = torch.ops.aten.to.dtype(slice_tensor_5, torch.float32);  slice_tensor_5 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_83, to_dtype_84);  le_scalar_28 = new_zeros_default_83 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_24, primals_182, primals_180, primals_181, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_24 = primals_182 = primals_180 = primals_181 = getitem_79 = getitem_80 = None
        getitem_355 = native_batch_norm_backward_default_30[0]
        getitem_356 = native_batch_norm_backward_default_30[1]
        getitem_357 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_355, relu_default_5, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_355 = primals_26 = None
        getitem_358 = convolution_backward_default_30[0]
        getitem_359 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_358, torch.float32);  getitem_358 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_84, to_dtype_87);  le_scalar_29 = new_zeros_default_84 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_23, primals_177, primals_175, primals_176, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  convolution_default_23 = primals_177 = primals_175 = primals_176 = getitem_76 = getitem_77 = None
        getitem_361 = native_batch_norm_backward_default_31[0]
        getitem_362 = native_batch_norm_backward_default_31[1]
        getitem_363 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_361, relu__default_15, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_361 = primals_23 = None
        getitem_364 = convolution_backward_default_31[0]
        getitem_365 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_364, torch.float32);  getitem_364 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_85, to_dtype_90);  le_scalar_30 = new_zeros_default_85 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_22, primals_172, primals_170, primals_171, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_22 = primals_172 = primals_170 = primals_171 = getitem_73 = getitem_74 = None
        getitem_367 = native_batch_norm_backward_default_32[0]
        getitem_368 = native_batch_norm_backward_default_32[1]
        getitem_369 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_367, relu__default_14, primals_22, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_367 = primals_22 = None
        getitem_370 = convolution_backward_default_32[0]
        getitem_371 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_370, torch.float32);  getitem_370 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_86, to_dtype_93);  le_scalar_31 = new_zeros_default_86 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_21, primals_167, primals_165, primals_166, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_21 = primals_167 = primals_165 = primals_166 = getitem_70 = getitem_71 = None
        getitem_373 = native_batch_norm_backward_default_33[0]
        getitem_374 = native_batch_norm_backward_default_33[1]
        getitem_375 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_373, relu_default_4, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_373 = primals_21 = None
        getitem_376 = convolution_backward_default_33[0]
        getitem_377 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(to_dtype_89, getitem_376);  to_dtype_89 = getitem_376 = None
        to_dtype_96 = torch.ops.aten.to.dtype(add_tensor_75, torch.float32);  add_tensor_75 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_87, to_dtype_96);  le_scalar_32 = new_zeros_default_87 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_20, primals_162, primals_160, primals_161, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  convolution_default_20 = primals_162 = primals_160 = primals_161 = getitem_67 = getitem_68 = None
        getitem_379 = native_batch_norm_backward_default_34[0]
        getitem_380 = native_batch_norm_backward_default_34[1]
        getitem_381 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_379, relu__default_13, primals_20, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_379 = primals_20 = None
        getitem_382 = convolution_backward_default_34[0]
        getitem_383 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_382, torch.float32);  getitem_382 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_88, to_dtype_99);  le_scalar_33 = new_zeros_default_88 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_19, primals_157, primals_155, primals_156, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_19 = primals_157 = primals_155 = primals_156 = getitem_64 = getitem_65 = None
        getitem_385 = native_batch_norm_backward_default_35[0]
        getitem_386 = native_batch_norm_backward_default_35[1]
        getitem_387 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_385, relu__default_12, primals_19, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_385 = primals_19 = None
        getitem_388 = convolution_backward_default_35[0]
        getitem_389 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_388, torch.float32);  getitem_388 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_89, to_dtype_102);  le_scalar_34 = new_zeros_default_89 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_18, primals_152, primals_150, primals_151, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_18 = primals_152 = primals_150 = primals_151 = getitem_61 = getitem_62 = None
        getitem_391 = native_batch_norm_backward_default_36[0]
        getitem_392 = native_batch_norm_backward_default_36[1]
        getitem_393 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_391, relu_default_3, primals_18, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_391 = primals_18 = None
        getitem_394 = convolution_backward_default_36[0]
        getitem_395 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(to_dtype_98, getitem_394);  to_dtype_98 = getitem_394 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_76, torch.float32);  add_tensor_76 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_90, to_dtype_105);  le_scalar_35 = new_zeros_default_90 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_17, primals_147, primals_145, primals_146, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  convolution_default_17 = primals_147 = primals_145 = primals_146 = getitem_58 = getitem_59 = None
        getitem_397 = native_batch_norm_backward_default_37[0]
        getitem_398 = native_batch_norm_backward_default_37[1]
        getitem_399 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_397, relu__default_11, primals_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_397 = primals_17 = None
        getitem_400 = convolution_backward_default_37[0]
        getitem_401 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_400, torch.float32);  getitem_400 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_91, to_dtype_108);  le_scalar_36 = new_zeros_default_91 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_16, primals_142, primals_140, primals_141, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_16 = primals_142 = primals_140 = primals_141 = getitem_55 = getitem_56 = None
        getitem_403 = native_batch_norm_backward_default_38[0]
        getitem_404 = native_batch_norm_backward_default_38[1]
        getitem_405 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_403, relu__default_10, primals_16, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_403 = primals_16 = None
        getitem_406 = convolution_backward_default_38[0]
        getitem_407 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_406, torch.float32);  getitem_406 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_92, to_dtype_111);  le_scalar_37 = new_zeros_default_92 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_15, primals_137, primals_135, primals_136, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_15 = primals_137 = primals_135 = primals_136 = getitem_52 = getitem_53 = None
        getitem_409 = native_batch_norm_backward_default_39[0]
        getitem_410 = native_batch_norm_backward_default_39[1]
        getitem_411 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_409, getitem_50, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_409 = getitem_50 = primals_15 = None
        getitem_412 = convolution_backward_default_39[0]
        getitem_413 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(to_dtype_107, getitem_412);  to_dtype_107 = getitem_412 = None
        cat_default_6 = torch.ops.aten.cat.default([slice_tensor_4, add_tensor_77], 1);  slice_tensor_4 = add_tensor_77 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(cat_default_6, convolution_default_14, primals_132, primals_130, primals_131, getitem_47, getitem_48, True, 1e-05, [True, True, True]);  cat_default_6 = convolution_default_14 = primals_132 = primals_130 = primals_131 = getitem_47 = getitem_48 = None
        getitem_415 = native_batch_norm_backward_default_40[0]
        getitem_416 = native_batch_norm_backward_default_40[1]
        getitem_417 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_415, relu__default_9, primals_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_415 = primals_25 = None
        getitem_418 = convolution_backward_default_40[0]
        getitem_419 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_418, torch.float32);  getitem_418 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_93, to_dtype_114);  le_scalar_38 = new_zeros_default_93 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_13, primals_127, primals_125, primals_126, getitem_44, getitem_45, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_13 = primals_127 = primals_125 = primals_126 = getitem_44 = getitem_45 = None
        getitem_421 = native_batch_norm_backward_default_41[0]
        getitem_422 = native_batch_norm_backward_default_41[1]
        getitem_423 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_421, relu__default_8, primals_24, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_421 = primals_24 = None
        getitem_424 = convolution_backward_default_41[0]
        getitem_425 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_424, torch.float32);  getitem_424 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_94, to_dtype_117);  le_scalar_39 = new_zeros_default_94 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_12, primals_122, primals_120, primals_121, getitem_41, getitem_42, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_12 = primals_122 = primals_120 = primals_121 = getitem_41 = getitem_42 = None
        getitem_427 = native_batch_norm_backward_default_42[0]
        getitem_428 = native_batch_norm_backward_default_42[1]
        getitem_429 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_427, cat_default, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_427 = cat_default = primals_14 = None
        getitem_430 = convolution_backward_default_42[0]
        getitem_431 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_430, 1, 0, 128)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_430, 1, 128, 256);  getitem_430 = None
        to_dtype_120 = torch.ops.aten.to.dtype(slice_tensor_7, torch.float32);  slice_tensor_7 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_95, to_dtype_120);  le_scalar_40 = new_zeros_default_95 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_11, primals_117, primals_115, primals_116, getitem_38, getitem_39, True, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_11 = primals_117 = primals_115 = primals_116 = getitem_38 = getitem_39 = None
        getitem_433 = native_batch_norm_backward_default_43[0]
        getitem_434 = native_batch_norm_backward_default_43[1]
        getitem_435 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_433, relu_default_2, primals_13, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_433 = primals_13 = None
        getitem_436 = convolution_backward_default_43[0]
        getitem_437 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_436, torch.float32);  getitem_436 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_96, to_dtype_123);  le_scalar_41 = new_zeros_default_96 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_10, primals_112, primals_110, primals_111, getitem_35, getitem_36, True, 1e-05, [True, True, True]);  convolution_default_10 = primals_112 = primals_110 = primals_111 = getitem_35 = getitem_36 = None
        getitem_439 = native_batch_norm_backward_default_44[0]
        getitem_440 = native_batch_norm_backward_default_44[1]
        getitem_441 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_439, relu__default_6, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_439 = primals_11 = None
        getitem_442 = convolution_backward_default_44[0]
        getitem_443 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_442, torch.float32);  getitem_442 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_97, to_dtype_126);  le_scalar_42 = new_zeros_default_97 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_9, primals_107, primals_105, primals_106, getitem_32, getitem_33, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default_9 = primals_107 = primals_105 = primals_106 = getitem_32 = getitem_33 = None
        getitem_445 = native_batch_norm_backward_default_45[0]
        getitem_446 = native_batch_norm_backward_default_45[1]
        getitem_447 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_445, relu__default_5, primals_10, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_445 = primals_10 = None
        getitem_448 = convolution_backward_default_45[0]
        getitem_449 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_448, torch.float32);  getitem_448 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_98, to_dtype_129);  le_scalar_43 = new_zeros_default_98 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_8, primals_102, primals_100, primals_101, getitem_29, getitem_30, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_8 = primals_102 = primals_100 = primals_101 = getitem_29 = getitem_30 = None
        getitem_451 = native_batch_norm_backward_default_46[0]
        getitem_452 = native_batch_norm_backward_default_46[1]
        getitem_453 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_451, relu_default_1, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_451 = primals_9 = None
        getitem_454 = convolution_backward_default_46[0]
        getitem_455 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(to_dtype_125, getitem_454);  to_dtype_125 = getitem_454 = None
        to_dtype_132 = torch.ops.aten.to.dtype(add_tensor_78, torch.float32);  add_tensor_78 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_99, to_dtype_132);  le_scalar_44 = new_zeros_default_99 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_7, primals_97, primals_95, primals_96, getitem_26, getitem_27, True, 1e-05, [True, True, True]);  convolution_default_7 = primals_97 = primals_95 = primals_96 = getitem_26 = getitem_27 = None
        getitem_457 = native_batch_norm_backward_default_47[0]
        getitem_458 = native_batch_norm_backward_default_47[1]
        getitem_459 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_457, relu__default_4, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_457 = primals_8 = None
        getitem_460 = convolution_backward_default_47[0]
        getitem_461 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_460, torch.float32);  getitem_460 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_100, to_dtype_135);  le_scalar_45 = new_zeros_default_100 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_6, primals_92, primals_90, primals_91, getitem_23, getitem_24, True, 1e-05, [True, True, True]);  to_dtype_137 = convolution_default_6 = primals_92 = primals_90 = primals_91 = getitem_23 = getitem_24 = None
        getitem_463 = native_batch_norm_backward_default_48[0]
        getitem_464 = native_batch_norm_backward_default_48[1]
        getitem_465 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_463, relu__default_3, primals_7, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_463 = primals_7 = None
        getitem_466 = convolution_backward_default_48[0]
        getitem_467 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_466, torch.float32);  getitem_466 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_101, to_dtype_138);  le_scalar_46 = new_zeros_default_101 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_5, primals_87, primals_85, primals_86, getitem_20, getitem_21, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_5 = primals_87 = primals_85 = primals_86 = getitem_20 = getitem_21 = None
        getitem_469 = native_batch_norm_backward_default_49[0]
        getitem_470 = native_batch_norm_backward_default_49[1]
        getitem_471 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_469, relu_default, primals_6, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_469 = primals_6 = None
        getitem_472 = convolution_backward_default_49[0]
        getitem_473 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(to_dtype_134, getitem_472);  to_dtype_134 = getitem_472 = None
        to_dtype_141 = torch.ops.aten.to.dtype(add_tensor_79, torch.float32);  add_tensor_79 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_102, to_dtype_141);  le_scalar_47 = new_zeros_default_102 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_4, primals_82, primals_80, primals_81, getitem_17, getitem_18, True, 1e-05, [True, True, True]);  convolution_default_4 = primals_82 = primals_80 = primals_81 = getitem_17 = getitem_18 = None
        getitem_475 = native_batch_norm_backward_default_50[0]
        getitem_476 = native_batch_norm_backward_default_50[1]
        getitem_477 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_475, relu__default_2, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_475 = primals_5 = None
        getitem_478 = convolution_backward_default_50[0]
        getitem_479 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_478, torch.float32);  getitem_478 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_103, to_dtype_144);  le_scalar_48 = new_zeros_default_103 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_3, primals_77, primals_75, primals_76, getitem_14, getitem_15, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_3 = primals_77 = primals_75 = primals_76 = getitem_14 = getitem_15 = None
        getitem_481 = native_batch_norm_backward_default_51[0]
        getitem_482 = native_batch_norm_backward_default_51[1]
        getitem_483 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_481, relu__default_1, primals_4, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_481 = primals_4 = None
        getitem_484 = convolution_backward_default_51[0]
        getitem_485 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_484, torch.float32);  getitem_484 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_104, to_dtype_147);  le_scalar_49 = new_zeros_default_104 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_2, primals_72, primals_70, primals_71, getitem_11, getitem_12, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_2 = primals_72 = primals_70 = primals_71 = getitem_11 = getitem_12 = None
        getitem_487 = native_batch_norm_backward_default_52[0]
        getitem_488 = native_batch_norm_backward_default_52[1]
        getitem_489 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_487, getitem_9, primals_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_487 = getitem_9 = primals_3 = None
        getitem_490 = convolution_backward_default_52[0]
        getitem_491 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(to_dtype_143, getitem_490);  to_dtype_143 = getitem_490 = None
        cat_default_7 = torch.ops.aten.cat.default([slice_tensor_6, add_tensor_80], 1);  slice_tensor_6 = add_tensor_80 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(cat_default_7, convolution_default_1, primals_67, primals_65, primals_66, getitem_6, getitem_7, True, 1e-05, [True, True, True]);  cat_default_7 = convolution_default_1 = primals_67 = primals_65 = primals_66 = getitem_6 = getitem_7 = None
        getitem_493 = native_batch_norm_backward_default_53[0]
        getitem_494 = native_batch_norm_backward_default_53[1]
        getitem_495 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_493, getitem_3, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_493 = getitem_3 = primals_12 = None
        getitem_496 = convolution_backward_default_53[0]
        getitem_497 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_496, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  getitem_496 = getitem_4 = None
        to_dtype_150 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_105, to_dtype_150);  le_scalar_50 = new_zeros_default_105 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default, primals_62, primals_60, primals_61, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_152 = convolution_default = primals_62 = primals_60 = primals_61 = getitem_1 = getitem_2 = None
        getitem_499 = native_batch_norm_backward_default_54[0]
        getitem_500 = native_batch_norm_backward_default_54[1]
        getitem_501 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_499, primals_58, primals_57, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_499 = primals_58 = primals_57 = None
        getitem_503 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        return [view_default_1, t_default_4, getitem_491, getitem_485, getitem_479, getitem_473, getitem_467, getitem_461, getitem_455, getitem_449, getitem_443, getitem_497, getitem_437, getitem_431, getitem_413, getitem_407, getitem_401, getitem_395, getitem_389, getitem_383, getitem_377, getitem_371, getitem_365, getitem_425, getitem_419, getitem_359, getitem_353, getitem_335, getitem_329, getitem_323, getitem_317, getitem_311, getitem_305, getitem_299, getitem_293, getitem_287, getitem_281, getitem_275, getitem_269, getitem_263, getitem_257, getitem_251, getitem_347, getitem_341, getitem_245, getitem_239, getitem_221, getitem_215, getitem_209, getitem_203, getitem_197, getitem_191, getitem_233, getitem_227, getitem_185, getitem_179, getitem_503, None, None, None, None, getitem_500, getitem_501, None, None, None, getitem_494, getitem_495, None, None, None, getitem_488, getitem_489, None, None, None, getitem_482, getitem_483, None, None, None, getitem_476, getitem_477, None, None, None, getitem_470, getitem_471, None, None, None, getitem_464, getitem_465, None, None, None, getitem_458, getitem_459, None, None, None, getitem_452, getitem_453, None, None, None, getitem_446, getitem_447, None, None, None, getitem_440, getitem_441, None, None, None, getitem_434, getitem_435, None, None, None, getitem_428, getitem_429, None, None, None, getitem_422, getitem_423, None, None, None, getitem_416, getitem_417, None, None, None, getitem_410, getitem_411, None, None, None, getitem_404, getitem_405, None, None, None, getitem_398, getitem_399, None, None, None, getitem_392, getitem_393, None, None, None, getitem_386, getitem_387, None, None, None, getitem_380, getitem_381, None, None, None, getitem_374, getitem_375, None, None, None, getitem_368, getitem_369, None, None, None, getitem_362, getitem_363, None, None, None, getitem_356, getitem_357, None, None, None, getitem_350, getitem_351, None, None, None, getitem_344, getitem_345, None, None, None, getitem_338, getitem_339, None, None, None, getitem_332, getitem_333, None, None, None, getitem_326, getitem_327, None, None, None, getitem_320, getitem_321, None, None, None, getitem_314, getitem_315, None, None, None, getitem_308, getitem_309, None, None, None, getitem_302, getitem_303, None, None, None, getitem_296, getitem_297, None, None, None, getitem_290, getitem_291, None, None, None, getitem_284, getitem_285, None, None, None, getitem_278, getitem_279, None, None, None, getitem_272, getitem_273, None, None, None, getitem_266, getitem_267, None, None, None, getitem_260, getitem_261, None, None, None, getitem_254, getitem_255, None, None, None, getitem_248, getitem_249, None, None, None, getitem_242, getitem_243, None, None, None, getitem_236, getitem_237, None, None, None, getitem_230, getitem_231, None, None, None, getitem_224, getitem_225, None, None, None, getitem_218, getitem_219, None, None, None, getitem_212, getitem_213, None, None, None, getitem_206, getitem_207, None, None, None, getitem_200, getitem_201, None, None, None, getitem_194, getitem_195, None, None, None, getitem_188, getitem_189, None, None, None, getitem_182, getitem_183, None, None, None, getitem_176, getitem_177]
        
