
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/tf_efficientnet_lite0/tf_efficientnet_lite0_backward_0/state_dict.pt'))

    
    
    def forward(self, getitem_59, getitem_11, primals_84, getitem_10, primals_81, convolution_default_20, getitem_9, getitem_103, primals_224, primals_85, hardtanh__default_13, getitem_102, convolution_default_4, primals_80, primals_194, primals_195, primals_90, getitem_62, getitem_104, getitem_61, primals_79, primals_274, getitem_12, primals_200, constant_pad_nd_default_1, getitem_64, getitem_13, getitem_14, primals_225, add_tensor_23, convolution_default_21, convolution_default, getitem_1, getitem_63, getitem, primals_89, hardtanh__default_23, convolution_default_35, primals_86, getitem_106, getitem_105, getitem_65, primals_201, primals_236, hardtanh__default_3, getitem_2, convolution_default_5, primals_196, convolution_default_22, primals_199, getitem_107, convolution_default_1, getitem_95, primals_159, primals_185, getitem_94, getitem_93, hardtanh__default, primals_130, getitem_5, getitem_4, convolution_default_32, primals_135, primals_131, primals_184, convolution_default_2, hardtanh__default_21, getitem_3, primals_161, primals_210, getitem_98, constant_pad_nd_default_4, getitem_97, primals_180, getitem_6, primals_215, primals_160, hardtanh__default_1, getitem_99, primals_211, getitem_7, primals_186, primals_136, primals_181, convolution_default_33, add_tensor_38, primals_179, getitem_8, primals_164, primals_214, convolution_default_34, primals_134, convolution_default_3, getitem_100, getitem_101, primals_204, primals_31, primals_6, primals_29, getitem_33, getitem_31, primals_24, primals_14, primals_54, primals_234, primals_21, getitem_32, primals_33, primals_7, primals_30, primals_55, primals_101, primals_8, primals_105, convolution_default_11, primals_43, primals_94, primals_104, primals_28, primals_9, primals_56, primals_46, primals_45, getitem_30, primals_32, primals_25, hardtanh__default_7, primals_22, primals_205, primals_235, getitem_35, primals_11, primals_209, getitem_34, primals_206, primals_5, primals_15, getitem_36, primals_50, primals_13, primals_47, primals_16, primals_51, primals_27, primals_106, convolution_default_12, primals_17, primals_91, primals_44, primals_18, primals_23, primals_26, getitem_37, primals_10, primals_12, convolution_default_36, getitem_142, getitem_79, getitem_16, convolution_default_13, getitem_143, getitem_80, getitem_108, getitem_17, getitem_38, hardtanh__default_28, primals_269, getitem_110, convolution_default_48, convolution_default_27, getitem_111, convolution_default_6, getitem_39, getitem_15, getitem_109, getitem_131, primals_290, getitem_81, getitem_144, getitem_18, getitem_130, primals_271, hardtanh__default_8, getitem_146, getitem_83, getitem_20, getitem_145, getitem_82, primals_231, getitem_19, getitem_41, view_default, convolution_default_37, getitem_40, primals_265, convolution_default_44, getitem_129, primals_294, hardtanh__default_24, hardtanh__default_29, getitem_113, getitem_133, getitem_85, getitem_22, getitem_112, convolution_default_15, hardtanh__default_18, hardtanh__default_4, convolution_default_28, getitem_134, convolution_default_7, hardtanh__default_9, primals_270, getitem_84, getitem_21, convolution_default_14, primals_296, getitem_43, t_default, add_tensor_53, convolution_default_45, primals_291, getitem_86, getitem_23, primals_266, add_tensor_16, convolution_default_29, convolution_default_8, hardtanh__default_25, convolution_default_38, getitem_44, primals_295, primals_2, primals_70, primals_110, primals_19, hardtanh__default_14, primals_20, primals_114, primals_124, primals_176, getitem_68, primals_3, getitem_67, primals_95, primals_126, primals_129, primals_111, primals_191, primals_259, convolution_default_23, primals_69, getitem_66, primals_125, primals_65, primals_190, primals_284, primals_66, primals_59, hardtanh__default_15, primals_71, getitem_70, primals_64, primals_60, primals_286, getitem_71, primals_289, primals_109, primals_4, primals_96, add_tensor_27, convolution_default_24, primals_61, primals_285, primals_1, getitem_51, getitem_122, primals_240, primals_241, primals_156, getitem_53, getitem_54, convolution_default_41, getitem_52, hardtanh__default_19, getitem_89, convolution_default_30, primals_244, getitem_88, getitem_90, hardtanh__default_27, convolution_default_18, primals_100, getitem_125, primals_249, convolution_default_42, primals_239, getitem_124, getitem_56, add_tensor_34, getitem_126, getitem_55, getitem_92, getitem_127, add_tensor_49, getitem_91, primals_251, primals_99, getitem_57, getitem_128, primals_246, hardtanh__default_12, primals_254, convolution_default_19, convolution_default_31, convolution_default_43, primals_245, hardtanh__default_20, getitem_58, primals_250, getitem_74, primals_175, primals_281, getitem_73, primals_171, primals_166, primals_144, hardtanh__default_5, getitem_72, primals_37, primals_74, getitem_26, convolution_default_25, convolution_default_9, primals_41, getitem_25, primals_139, primals_75, getitem_27, primals_34, primals_264, getitem_75, primals_174, primals_149, primals_169, hardtanh__default_16, primals_280, add_tensor_9, primals_155, primals_260, getitem_77, getitem_76, primals_165, primals_42, getitem_29, primals_145, primals_146, getitem_28, primals_140, constant_pad_nd_default_2, primals_38, primals_261, primals_279, primals_151, primals_150, primals_39, primals_170, primals_35, primals_141, hardtanh__default_17, primals_40, primals_154, primals_189, convolution_default_26, primals_276, primals_36, convolution_default_10, getitem_78, primals_76, getitem_137, primals_229, primals_219, getitem_117, getitem_136, convolution_default_39, getitem_116, primals_221, getitem_115, primals_115, getitem_135, getitem_47, getitem_46, convolution_default_46, primals_275, add_tensor_45, primals_120, getitem_138, hardtanh__default_30, primals_230, getitem_119, getitem_45, convolution_default_16, getitem_118, getitem_140, getitem_141, getitem_139, primals_256, primals_116, getitem_48, primals_119, constant_pad_nd_default_3, primals_121, getitem_49, getitem_50, primals_226, constant_pad_nd_default, getitem_120, primals_255, hardtanh__default_26, convolution_default_17, convolution_default_40, hardtanh__default_31, primals_220, convolution_default_47, primals_216, hardtanh__default_11, getitem_121, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50):
        clone_default = torch.ops.aten.clone.default(getitem);  getitem = None
        clone_default_1 = torch.ops.aten.clone.default(getitem_3);  getitem_3 = None
        clone_default_2 = torch.ops.aten.clone.default(getitem_9);  getitem_9 = None
        clone_default_3 = torch.ops.aten.clone.default(getitem_12);  getitem_12 = None
        clone_default_4 = torch.ops.aten.clone.default(getitem_18);  getitem_18 = None
        clone_default_5 = torch.ops.aten.clone.default(getitem_21);  getitem_21 = None
        clone_default_6 = torch.ops.aten.clone.default(getitem_27);  getitem_27 = None
        clone_default_7 = torch.ops.aten.clone.default(getitem_30);  getitem_30 = None
        clone_default_8 = torch.ops.aten.clone.default(getitem_36);  getitem_36 = None
        clone_default_9 = torch.ops.aten.clone.default(getitem_39);  getitem_39 = None
        clone_default_10 = torch.ops.aten.clone.default(getitem_45);  getitem_45 = None
        clone_default_11 = torch.ops.aten.clone.default(getitem_48);  getitem_48 = None
        clone_default_12 = torch.ops.aten.clone.default(getitem_54);  getitem_54 = None
        clone_default_13 = torch.ops.aten.clone.default(getitem_57);  getitem_57 = None
        clone_default_14 = torch.ops.aten.clone.default(getitem_63);  getitem_63 = None
        clone_default_15 = torch.ops.aten.clone.default(getitem_66);  getitem_66 = None
        clone_default_16 = torch.ops.aten.clone.default(getitem_72);  getitem_72 = None
        clone_default_17 = torch.ops.aten.clone.default(getitem_75);  getitem_75 = None
        clone_default_18 = torch.ops.aten.clone.default(getitem_81);  getitem_81 = None
        clone_default_19 = torch.ops.aten.clone.default(getitem_84);  getitem_84 = None
        clone_default_20 = torch.ops.aten.clone.default(getitem_90);  getitem_90 = None
        clone_default_21 = torch.ops.aten.clone.default(getitem_93);  getitem_93 = None
        clone_default_22 = torch.ops.aten.clone.default(getitem_99);  getitem_99 = None
        clone_default_23 = torch.ops.aten.clone.default(getitem_102);  getitem_102 = None
        clone_default_24 = torch.ops.aten.clone.default(getitem_108);  getitem_108 = None
        clone_default_25 = torch.ops.aten.clone.default(getitem_111);  getitem_111 = None
        clone_default_26 = torch.ops.aten.clone.default(getitem_117);  getitem_117 = None
        clone_default_27 = torch.ops.aten.clone.default(getitem_120);  getitem_120 = None
        clone_default_28 = torch.ops.aten.clone.default(getitem_126);  getitem_126 = None
        clone_default_29 = torch.ops.aten.clone.default(getitem_129);  getitem_129 = None
        clone_default_30 = torch.ops.aten.clone.default(getitem_135);  getitem_135 = None
        clone_default_31 = torch.ops.aten.clone.default(getitem_138);  getitem_138 = None
        clone_default_32 = torch.ops.aten.clone.default(getitem_144);  getitem_144 = None
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1280, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1280, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(clone_default_32, torch.float32);  clone_default_32 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0.0)
        ge_scalar = torch.ops.aten.ge.Scalar(to_dtype_1, 6.0);  to_dtype_1 = None
        __or___tensor = torch.ops.aten.__or__.Tensor(le_scalar, ge_scalar);  le_scalar = ge_scalar = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(__or___tensor, new_zeros_default_49, to_dtype);  __or___tensor = new_zeros_default_49 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_48, primals_296, primals_294, primals_295, getitem_145, getitem_146, True, 0.001, [True, True, True]);  to_dtype_2 = convolution_default_48 = primals_296 = primals_294 = primals_295 = getitem_145 = getitem_146 = None
        getitem_147 = native_batch_norm_backward_default[0]
        getitem_148 = native_batch_norm_backward_default[1]
        getitem_149 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_147, getitem_141, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_147 = getitem_141 = primals_50 = None
        getitem_150 = convolution_backward_default[0]
        getitem_151 = convolution_backward_default[1];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_150, convolution_default_47, primals_291, primals_289, primals_290, getitem_142, getitem_143, True, 0.001, [True, True, True]);  getitem_150 = convolution_default_47 = primals_291 = primals_289 = primals_290 = getitem_142 = getitem_143 = None
        getitem_153 = native_batch_norm_backward_default_1[0]
        getitem_154 = native_batch_norm_backward_default_1[1]
        getitem_155 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_153, hardtanh__default_31, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_153 = hardtanh__default_31 = primals_47 = None
        getitem_156 = convolution_backward_default_1[0]
        getitem_157 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_156, torch.float32);  getitem_156 = None
        to_dtype_4 = torch.ops.aten.to.dtype(clone_default_31, torch.float32);  clone_default_31 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0.0)
        ge_scalar_1 = torch.ops.aten.ge.Scalar(to_dtype_4, 6.0);  to_dtype_4 = None
        __or___tensor_1 = torch.ops.aten.__or__.Tensor(le_scalar_1, ge_scalar_1);  le_scalar_1 = ge_scalar_1 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(__or___tensor_1, new_zeros_default_50, to_dtype_3);  __or___tensor_1 = new_zeros_default_50 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_46, primals_286, primals_284, primals_285, getitem_139, getitem_140, True, 0.001, [True, True, True]);  to_dtype_5 = convolution_default_46 = primals_286 = primals_284 = primals_285 = getitem_139 = getitem_140 = None
        getitem_159 = native_batch_norm_backward_default_2[0]
        getitem_160 = native_batch_norm_backward_default_2[1]
        getitem_161 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_159, hardtanh__default_30, primals_45, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_159 = hardtanh__default_30 = primals_45 = None
        getitem_162 = convolution_backward_default_2[0]
        getitem_163 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_162, torch.float32);  getitem_162 = None
        to_dtype_7 = torch.ops.aten.to.dtype(clone_default_30, torch.float32);  clone_default_30 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0.0)
        ge_scalar_2 = torch.ops.aten.ge.Scalar(to_dtype_7, 6.0);  to_dtype_7 = None
        __or___tensor_2 = torch.ops.aten.__or__.Tensor(le_scalar_2, ge_scalar_2);  le_scalar_2 = ge_scalar_2 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(__or___tensor_2, new_zeros_default_51, to_dtype_6);  __or___tensor_2 = new_zeros_default_51 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_45, primals_281, primals_279, primals_280, getitem_136, getitem_137, True, 0.001, [True, True, True]);  to_dtype_8 = convolution_default_45 = primals_281 = primals_279 = primals_280 = getitem_136 = getitem_137 = None
        getitem_165 = native_batch_norm_backward_default_3[0]
        getitem_166 = native_batch_norm_backward_default_3[1]
        getitem_167 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_165, add_tensor_53, primals_46, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_165 = add_tensor_53 = primals_46 = None
        getitem_168 = convolution_backward_default_3[0]
        getitem_169 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(getitem_168, convolution_default_44, primals_276, primals_274, primals_275, getitem_133, getitem_134, True, 0.001, [True, True, True]);  convolution_default_44 = primals_276 = primals_274 = primals_275 = getitem_133 = getitem_134 = None
        getitem_171 = native_batch_norm_backward_default_4[0]
        getitem_172 = native_batch_norm_backward_default_4[1]
        getitem_173 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_171, hardtanh__default_29, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_171 = hardtanh__default_29 = primals_44 = None
        getitem_174 = convolution_backward_default_4[0]
        getitem_175 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_174, torch.float32);  getitem_174 = None
        to_dtype_10 = torch.ops.aten.to.dtype(clone_default_29, torch.float32);  clone_default_29 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0.0)
        ge_scalar_3 = torch.ops.aten.ge.Scalar(to_dtype_10, 6.0);  to_dtype_10 = None
        __or___tensor_3 = torch.ops.aten.__or__.Tensor(le_scalar_3, ge_scalar_3);  le_scalar_3 = ge_scalar_3 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(__or___tensor_3, new_zeros_default_52, to_dtype_9);  __or___tensor_3 = new_zeros_default_52 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_43, primals_271, primals_269, primals_270, getitem_130, getitem_131, True, 0.001, [True, True, True]);  to_dtype_11 = convolution_default_43 = primals_271 = primals_269 = primals_270 = getitem_130 = getitem_131 = None
        getitem_177 = native_batch_norm_backward_default_5[0]
        getitem_178 = native_batch_norm_backward_default_5[1]
        getitem_179 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_177, hardtanh__default_28, primals_42, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_177 = hardtanh__default_28 = primals_42 = None
        getitem_180 = convolution_backward_default_5[0]
        getitem_181 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_180, torch.float32);  getitem_180 = None
        to_dtype_13 = torch.ops.aten.to.dtype(clone_default_28, torch.float32);  clone_default_28 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0.0)
        ge_scalar_4 = torch.ops.aten.ge.Scalar(to_dtype_13, 6.0);  to_dtype_13 = None
        __or___tensor_4 = torch.ops.aten.__or__.Tensor(le_scalar_4, ge_scalar_4);  le_scalar_4 = ge_scalar_4 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(__or___tensor_4, new_zeros_default_53, to_dtype_12);  __or___tensor_4 = new_zeros_default_53 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_42, primals_266, primals_264, primals_265, getitem_127, getitem_128, True, 0.001, [True, True, True]);  to_dtype_14 = convolution_default_42 = primals_266 = primals_264 = primals_265 = getitem_127 = getitem_128 = None
        getitem_183 = native_batch_norm_backward_default_6[0]
        getitem_184 = native_batch_norm_backward_default_6[1]
        getitem_185 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_183, add_tensor_49, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_183 = add_tensor_49 = primals_43 = None
        getitem_186 = convolution_backward_default_6[0]
        getitem_187 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(getitem_168, getitem_186);  getitem_168 = getitem_186 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_58, convolution_default_41, primals_261, primals_259, primals_260, getitem_124, getitem_125, True, 0.001, [True, True, True]);  convolution_default_41 = primals_261 = primals_259 = primals_260 = getitem_124 = getitem_125 = None
        getitem_189 = native_batch_norm_backward_default_7[0]
        getitem_190 = native_batch_norm_backward_default_7[1]
        getitem_191 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_189, hardtanh__default_27, primals_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_189 = hardtanh__default_27 = primals_41 = None
        getitem_192 = convolution_backward_default_7[0]
        getitem_193 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_192, torch.float32);  getitem_192 = None
        to_dtype_16 = torch.ops.aten.to.dtype(clone_default_27, torch.float32);  clone_default_27 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0.0)
        ge_scalar_5 = torch.ops.aten.ge.Scalar(to_dtype_16, 6.0);  to_dtype_16 = None
        __or___tensor_5 = torch.ops.aten.__or__.Tensor(le_scalar_5, ge_scalar_5);  le_scalar_5 = ge_scalar_5 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(__or___tensor_5, new_zeros_default_54, to_dtype_15);  __or___tensor_5 = new_zeros_default_54 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_40, primals_256, primals_254, primals_255, getitem_121, getitem_122, True, 0.001, [True, True, True]);  to_dtype_17 = convolution_default_40 = primals_256 = primals_254 = primals_255 = getitem_121 = getitem_122 = None
        getitem_195 = native_batch_norm_backward_default_8[0]
        getitem_196 = native_batch_norm_backward_default_8[1]
        getitem_197 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_195, hardtanh__default_26, primals_39, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_195 = hardtanh__default_26 = primals_39 = None
        getitem_198 = convolution_backward_default_8[0]
        getitem_199 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_198, torch.float32);  getitem_198 = None
        to_dtype_19 = torch.ops.aten.to.dtype(clone_default_26, torch.float32);  clone_default_26 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0.0)
        ge_scalar_6 = torch.ops.aten.ge.Scalar(to_dtype_19, 6.0);  to_dtype_19 = None
        __or___tensor_6 = torch.ops.aten.__or__.Tensor(le_scalar_6, ge_scalar_6);  le_scalar_6 = ge_scalar_6 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(__or___tensor_6, new_zeros_default_55, to_dtype_18);  __or___tensor_6 = new_zeros_default_55 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_39, primals_251, primals_249, primals_250, getitem_118, getitem_119, True, 0.001, [True, True, True]);  to_dtype_20 = convolution_default_39 = primals_251 = primals_249 = primals_250 = getitem_118 = getitem_119 = None
        getitem_201 = native_batch_norm_backward_default_9[0]
        getitem_202 = native_batch_norm_backward_default_9[1]
        getitem_203 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_201, add_tensor_45, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_201 = add_tensor_45 = primals_40 = None
        getitem_204 = convolution_backward_default_9[0]
        getitem_205 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(add_tensor_58, getitem_204);  add_tensor_58 = getitem_204 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_59, convolution_default_38, primals_246, primals_244, primals_245, getitem_115, getitem_116, True, 0.001, [True, True, True]);  convolution_default_38 = primals_246 = primals_244 = primals_245 = getitem_115 = getitem_116 = None
        getitem_207 = native_batch_norm_backward_default_10[0]
        getitem_208 = native_batch_norm_backward_default_10[1]
        getitem_209 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_207, hardtanh__default_25, primals_38, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_207 = hardtanh__default_25 = primals_38 = None
        getitem_210 = convolution_backward_default_10[0]
        getitem_211 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_210, torch.float32);  getitem_210 = None
        to_dtype_22 = torch.ops.aten.to.dtype(clone_default_25, torch.float32);  clone_default_25 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0.0)
        ge_scalar_7 = torch.ops.aten.ge.Scalar(to_dtype_22, 6.0);  to_dtype_22 = None
        __or___tensor_7 = torch.ops.aten.__or__.Tensor(le_scalar_7, ge_scalar_7);  le_scalar_7 = ge_scalar_7 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(__or___tensor_7, new_zeros_default_56, to_dtype_21);  __or___tensor_7 = new_zeros_default_56 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_37, primals_241, primals_239, primals_240, getitem_112, getitem_113, True, 0.001, [True, True, True]);  to_dtype_23 = convolution_default_37 = primals_241 = primals_239 = primals_240 = getitem_112 = getitem_113 = None
        getitem_213 = native_batch_norm_backward_default_11[0]
        getitem_214 = native_batch_norm_backward_default_11[1]
        getitem_215 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_213, hardtanh__default_24, primals_36, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_213 = hardtanh__default_24 = primals_36 = None
        getitem_216 = convolution_backward_default_11[0]
        getitem_217 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_216, torch.float32);  getitem_216 = None
        to_dtype_25 = torch.ops.aten.to.dtype(clone_default_24, torch.float32);  clone_default_24 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0.0)
        ge_scalar_8 = torch.ops.aten.ge.Scalar(to_dtype_25, 6.0);  to_dtype_25 = None
        __or___tensor_8 = torch.ops.aten.__or__.Tensor(le_scalar_8, ge_scalar_8);  le_scalar_8 = ge_scalar_8 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(__or___tensor_8, new_zeros_default_57, to_dtype_24);  __or___tensor_8 = new_zeros_default_57 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_36, primals_236, primals_234, primals_235, getitem_109, getitem_110, True, 0.001, [True, True, True]);  to_dtype_26 = convolution_default_36 = primals_236 = primals_234 = primals_235 = getitem_109 = getitem_110 = None
        getitem_219 = native_batch_norm_backward_default_12[0]
        getitem_220 = native_batch_norm_backward_default_12[1]
        getitem_221 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_219, getitem_105, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_219 = getitem_105 = primals_37 = None
        getitem_222 = convolution_backward_default_12[0]
        getitem_223 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_59, getitem_222);  add_tensor_59 = getitem_222 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_60, convolution_default_35, primals_231, primals_229, primals_230, getitem_106, getitem_107, True, 0.001, [True, True, True]);  add_tensor_60 = convolution_default_35 = primals_231 = primals_229 = primals_230 = getitem_106 = getitem_107 = None
        getitem_225 = native_batch_norm_backward_default_13[0]
        getitem_226 = native_batch_norm_backward_default_13[1]
        getitem_227 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_225, hardtanh__default_23, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_225 = hardtanh__default_23 = primals_35 = None
        getitem_228 = convolution_backward_default_13[0]
        getitem_229 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_228, torch.float32);  getitem_228 = None
        to_dtype_28 = torch.ops.aten.to.dtype(clone_default_23, torch.float32);  clone_default_23 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0.0)
        ge_scalar_9 = torch.ops.aten.ge.Scalar(to_dtype_28, 6.0);  to_dtype_28 = None
        __or___tensor_9 = torch.ops.aten.__or__.Tensor(le_scalar_9, ge_scalar_9);  le_scalar_9 = ge_scalar_9 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(__or___tensor_9, new_zeros_default_58, to_dtype_27);  __or___tensor_9 = new_zeros_default_58 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_34, primals_226, primals_224, primals_225, getitem_103, getitem_104, True, 0.001, [True, True, True]);  to_dtype_29 = convolution_default_34 = primals_226 = primals_224 = primals_225 = getitem_103 = getitem_104 = None
        getitem_231 = native_batch_norm_backward_default_14[0]
        getitem_232 = native_batch_norm_backward_default_14[1]
        getitem_233 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_231, constant_pad_nd_default_4, primals_33, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_231 = constant_pad_nd_default_4 = primals_33 = None
        getitem_234 = convolution_backward_default_14[0]
        getitem_235 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(getitem_234, [-1, -2, -1, -2]);  getitem_234 = None
        to_dtype_30 = torch.ops.aten.to.dtype(constant_pad_nd_default_5, torch.float32);  constant_pad_nd_default_5 = None
        to_dtype_31 = torch.ops.aten.to.dtype(clone_default_22, torch.float32);  clone_default_22 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0.0)
        ge_scalar_10 = torch.ops.aten.ge.Scalar(to_dtype_31, 6.0);  to_dtype_31 = None
        __or___tensor_10 = torch.ops.aten.__or__.Tensor(le_scalar_10, ge_scalar_10);  le_scalar_10 = ge_scalar_10 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(__or___tensor_10, new_zeros_default_59, to_dtype_30);  __or___tensor_10 = new_zeros_default_59 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_33, primals_221, primals_219, primals_220, getitem_100, getitem_101, True, 0.001, [True, True, True]);  to_dtype_32 = convolution_default_33 = primals_221 = primals_219 = primals_220 = getitem_100 = getitem_101 = None
        getitem_237 = native_batch_norm_backward_default_15[0]
        getitem_238 = native_batch_norm_backward_default_15[1]
        getitem_239 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_237, add_tensor_38, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_237 = add_tensor_38 = primals_34 = None
        getitem_240 = convolution_backward_default_15[0]
        getitem_241 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_240, convolution_default_32, primals_216, primals_214, primals_215, getitem_97, getitem_98, True, 0.001, [True, True, True]);  convolution_default_32 = primals_216 = primals_214 = primals_215 = getitem_97 = getitem_98 = None
        getitem_243 = native_batch_norm_backward_default_16[0]
        getitem_244 = native_batch_norm_backward_default_16[1]
        getitem_245 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_243, hardtanh__default_21, primals_32, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_243 = hardtanh__default_21 = primals_32 = None
        getitem_246 = convolution_backward_default_16[0]
        getitem_247 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_246, torch.float32);  getitem_246 = None
        to_dtype_34 = torch.ops.aten.to.dtype(clone_default_21, torch.float32);  clone_default_21 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0.0)
        ge_scalar_11 = torch.ops.aten.ge.Scalar(to_dtype_34, 6.0);  to_dtype_34 = None
        __or___tensor_11 = torch.ops.aten.__or__.Tensor(le_scalar_11, ge_scalar_11);  le_scalar_11 = ge_scalar_11 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(__or___tensor_11, new_zeros_default_60, to_dtype_33);  __or___tensor_11 = new_zeros_default_60 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_31, primals_211, primals_209, primals_210, getitem_94, getitem_95, True, 0.001, [True, True, True]);  to_dtype_35 = convolution_default_31 = primals_211 = primals_209 = primals_210 = getitem_94 = getitem_95 = None
        getitem_249 = native_batch_norm_backward_default_17[0]
        getitem_250 = native_batch_norm_backward_default_17[1]
        getitem_251 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_249, hardtanh__default_20, primals_30, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_249 = hardtanh__default_20 = primals_30 = None
        getitem_252 = convolution_backward_default_17[0]
        getitem_253 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_252, torch.float32);  getitem_252 = None
        to_dtype_37 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0.0)
        ge_scalar_12 = torch.ops.aten.ge.Scalar(to_dtype_37, 6.0);  to_dtype_37 = None
        __or___tensor_12 = torch.ops.aten.__or__.Tensor(le_scalar_12, ge_scalar_12);  le_scalar_12 = ge_scalar_12 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(__or___tensor_12, new_zeros_default_61, to_dtype_36);  __or___tensor_12 = new_zeros_default_61 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_30, primals_206, primals_204, primals_205, getitem_91, getitem_92, True, 0.001, [True, True, True]);  to_dtype_38 = convolution_default_30 = primals_206 = primals_204 = primals_205 = getitem_91 = getitem_92 = None
        getitem_255 = native_batch_norm_backward_default_18[0]
        getitem_256 = native_batch_norm_backward_default_18[1]
        getitem_257 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_255, add_tensor_34, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_255 = add_tensor_34 = primals_31 = None
        getitem_258 = convolution_backward_default_18[0]
        getitem_259 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(getitem_240, getitem_258);  getitem_240 = getitem_258 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_61, convolution_default_29, primals_201, primals_199, primals_200, getitem_88, getitem_89, True, 0.001, [True, True, True]);  convolution_default_29 = primals_201 = primals_199 = primals_200 = getitem_88 = getitem_89 = None
        getitem_261 = native_batch_norm_backward_default_19[0]
        getitem_262 = native_batch_norm_backward_default_19[1]
        getitem_263 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_261, hardtanh__default_19, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_261 = hardtanh__default_19 = primals_29 = None
        getitem_264 = convolution_backward_default_19[0]
        getitem_265 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_264, torch.float32);  getitem_264 = None
        to_dtype_40 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0.0)
        ge_scalar_13 = torch.ops.aten.ge.Scalar(to_dtype_40, 6.0);  to_dtype_40 = None
        __or___tensor_13 = torch.ops.aten.__or__.Tensor(le_scalar_13, ge_scalar_13);  le_scalar_13 = ge_scalar_13 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(__or___tensor_13, new_zeros_default_62, to_dtype_39);  __or___tensor_13 = new_zeros_default_62 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_28, primals_196, primals_194, primals_195, getitem_85, getitem_86, True, 0.001, [True, True, True]);  to_dtype_41 = convolution_default_28 = primals_196 = primals_194 = primals_195 = getitem_85 = getitem_86 = None
        getitem_267 = native_batch_norm_backward_default_20[0]
        getitem_268 = native_batch_norm_backward_default_20[1]
        getitem_269 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_267, hardtanh__default_18, primals_27, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_267 = hardtanh__default_18 = primals_27 = None
        getitem_270 = convolution_backward_default_20[0]
        getitem_271 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_270, torch.float32);  getitem_270 = None
        to_dtype_43 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0.0)
        ge_scalar_14 = torch.ops.aten.ge.Scalar(to_dtype_43, 6.0);  to_dtype_43 = None
        __or___tensor_14 = torch.ops.aten.__or__.Tensor(le_scalar_14, ge_scalar_14);  le_scalar_14 = ge_scalar_14 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(__or___tensor_14, new_zeros_default_63, to_dtype_42);  __or___tensor_14 = new_zeros_default_63 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_27, primals_191, primals_189, primals_190, getitem_82, getitem_83, True, 0.001, [True, True, True]);  to_dtype_44 = convolution_default_27 = primals_191 = primals_189 = primals_190 = getitem_82 = getitem_83 = None
        getitem_273 = native_batch_norm_backward_default_21[0]
        getitem_274 = native_batch_norm_backward_default_21[1]
        getitem_275 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_273, getitem_78, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_273 = getitem_78 = primals_28 = None
        getitem_276 = convolution_backward_default_21[0]
        getitem_277 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(add_tensor_61, getitem_276);  add_tensor_61 = getitem_276 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_62, convolution_default_26, primals_186, primals_184, primals_185, getitem_79, getitem_80, True, 0.001, [True, True, True]);  add_tensor_62 = convolution_default_26 = primals_186 = primals_184 = primals_185 = getitem_79 = getitem_80 = None
        getitem_279 = native_batch_norm_backward_default_22[0]
        getitem_280 = native_batch_norm_backward_default_22[1]
        getitem_281 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_279, hardtanh__default_17, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_279 = hardtanh__default_17 = primals_26 = None
        getitem_282 = convolution_backward_default_22[0]
        getitem_283 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_282, torch.float32);  getitem_282 = None
        to_dtype_46 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0.0)
        ge_scalar_15 = torch.ops.aten.ge.Scalar(to_dtype_46, 6.0);  to_dtype_46 = None
        __or___tensor_15 = torch.ops.aten.__or__.Tensor(le_scalar_15, ge_scalar_15);  le_scalar_15 = ge_scalar_15 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(__or___tensor_15, new_zeros_default_64, to_dtype_45);  __or___tensor_15 = new_zeros_default_64 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_25, primals_181, primals_179, primals_180, getitem_76, getitem_77, True, 0.001, [True, True, True]);  to_dtype_47 = convolution_default_25 = primals_181 = primals_179 = primals_180 = getitem_76 = getitem_77 = None
        getitem_285 = native_batch_norm_backward_default_23[0]
        getitem_286 = native_batch_norm_backward_default_23[1]
        getitem_287 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_285, hardtanh__default_16, primals_24, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_285 = hardtanh__default_16 = primals_24 = None
        getitem_288 = convolution_backward_default_23[0]
        getitem_289 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_288, torch.float32);  getitem_288 = None
        to_dtype_49 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0.0)
        ge_scalar_16 = torch.ops.aten.ge.Scalar(to_dtype_49, 6.0);  to_dtype_49 = None
        __or___tensor_16 = torch.ops.aten.__or__.Tensor(le_scalar_16, ge_scalar_16);  le_scalar_16 = ge_scalar_16 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(__or___tensor_16, new_zeros_default_65, to_dtype_48);  __or___tensor_16 = new_zeros_default_65 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_24, primals_176, primals_174, primals_175, getitem_73, getitem_74, True, 0.001, [True, True, True]);  to_dtype_50 = convolution_default_24 = primals_176 = primals_174 = primals_175 = getitem_73 = getitem_74 = None
        getitem_291 = native_batch_norm_backward_default_24[0]
        getitem_292 = native_batch_norm_backward_default_24[1]
        getitem_293 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_291, add_tensor_27, primals_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_291 = add_tensor_27 = primals_25 = None
        getitem_294 = convolution_backward_default_24[0]
        getitem_295 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(getitem_294, convolution_default_23, primals_171, primals_169, primals_170, getitem_70, getitem_71, True, 0.001, [True, True, True]);  convolution_default_23 = primals_171 = primals_169 = primals_170 = getitem_70 = getitem_71 = None
        getitem_297 = native_batch_norm_backward_default_25[0]
        getitem_298 = native_batch_norm_backward_default_25[1]
        getitem_299 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_297, hardtanh__default_15, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_297 = hardtanh__default_15 = primals_23 = None
        getitem_300 = convolution_backward_default_25[0]
        getitem_301 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_300, torch.float32);  getitem_300 = None
        to_dtype_52 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0.0)
        ge_scalar_17 = torch.ops.aten.ge.Scalar(to_dtype_52, 6.0);  to_dtype_52 = None
        __or___tensor_17 = torch.ops.aten.__or__.Tensor(le_scalar_17, ge_scalar_17);  le_scalar_17 = ge_scalar_17 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(__or___tensor_17, new_zeros_default_66, to_dtype_51);  __or___tensor_17 = new_zeros_default_66 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_22, primals_166, primals_164, primals_165, getitem_67, getitem_68, True, 0.001, [True, True, True]);  to_dtype_53 = convolution_default_22 = primals_166 = primals_164 = primals_165 = getitem_67 = getitem_68 = None
        getitem_303 = native_batch_norm_backward_default_26[0]
        getitem_304 = native_batch_norm_backward_default_26[1]
        getitem_305 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_303, hardtanh__default_14, primals_21, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_303 = hardtanh__default_14 = primals_21 = None
        getitem_306 = convolution_backward_default_26[0]
        getitem_307 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_306, torch.float32);  getitem_306 = None
        to_dtype_55 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0.0)
        ge_scalar_18 = torch.ops.aten.ge.Scalar(to_dtype_55, 6.0);  to_dtype_55 = None
        __or___tensor_18 = torch.ops.aten.__or__.Tensor(le_scalar_18, ge_scalar_18);  le_scalar_18 = ge_scalar_18 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(__or___tensor_18, new_zeros_default_67, to_dtype_54);  __or___tensor_18 = new_zeros_default_67 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_21, primals_161, primals_159, primals_160, getitem_64, getitem_65, True, 0.001, [True, True, True]);  to_dtype_56 = convolution_default_21 = primals_161 = primals_159 = primals_160 = getitem_64 = getitem_65 = None
        getitem_309 = native_batch_norm_backward_default_27[0]
        getitem_310 = native_batch_norm_backward_default_27[1]
        getitem_311 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_309, add_tensor_23, primals_22, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_309 = add_tensor_23 = primals_22 = None
        getitem_312 = convolution_backward_default_27[0]
        getitem_313 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(getitem_294, getitem_312);  getitem_294 = getitem_312 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_63, convolution_default_20, primals_156, primals_154, primals_155, getitem_61, getitem_62, True, 0.001, [True, True, True]);  convolution_default_20 = primals_156 = primals_154 = primals_155 = getitem_61 = getitem_62 = None
        getitem_315 = native_batch_norm_backward_default_28[0]
        getitem_316 = native_batch_norm_backward_default_28[1]
        getitem_317 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_315, hardtanh__default_13, primals_20, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_315 = hardtanh__default_13 = primals_20 = None
        getitem_318 = convolution_backward_default_28[0]
        getitem_319 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_318, torch.float32);  getitem_318 = None
        to_dtype_58 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0.0)
        ge_scalar_19 = torch.ops.aten.ge.Scalar(to_dtype_58, 6.0);  to_dtype_58 = None
        __or___tensor_19 = torch.ops.aten.__or__.Tensor(le_scalar_19, ge_scalar_19);  le_scalar_19 = ge_scalar_19 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(__or___tensor_19, new_zeros_default_68, to_dtype_57);  __or___tensor_19 = new_zeros_default_68 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_19, primals_151, primals_149, primals_150, getitem_58, getitem_59, True, 0.001, [True, True, True]);  to_dtype_59 = convolution_default_19 = primals_151 = primals_149 = primals_150 = getitem_58 = getitem_59 = None
        getitem_321 = native_batch_norm_backward_default_29[0]
        getitem_322 = native_batch_norm_backward_default_29[1]
        getitem_323 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_321, hardtanh__default_12, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_321 = hardtanh__default_12 = primals_18 = None
        getitem_324 = convolution_backward_default_29[0]
        getitem_325 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_324, torch.float32);  getitem_324 = None
        to_dtype_61 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0.0)
        ge_scalar_20 = torch.ops.aten.ge.Scalar(to_dtype_61, 6.0);  to_dtype_61 = None
        __or___tensor_20 = torch.ops.aten.__or__.Tensor(le_scalar_20, ge_scalar_20);  le_scalar_20 = ge_scalar_20 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(__or___tensor_20, new_zeros_default_69, to_dtype_60);  __or___tensor_20 = new_zeros_default_69 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_18, primals_146, primals_144, primals_145, getitem_55, getitem_56, True, 0.001, [True, True, True]);  to_dtype_62 = convolution_default_18 = primals_146 = primals_144 = primals_145 = getitem_55 = getitem_56 = None
        getitem_327 = native_batch_norm_backward_default_30[0]
        getitem_328 = native_batch_norm_backward_default_30[1]
        getitem_329 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_327, getitem_51, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_327 = getitem_51 = primals_19 = None
        getitem_330 = convolution_backward_default_30[0]
        getitem_331 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_63, getitem_330);  add_tensor_63 = getitem_330 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_64, convolution_default_17, primals_141, primals_139, primals_140, getitem_52, getitem_53, True, 0.001, [True, True, True]);  add_tensor_64 = convolution_default_17 = primals_141 = primals_139 = primals_140 = getitem_52 = getitem_53 = None
        getitem_333 = native_batch_norm_backward_default_31[0]
        getitem_334 = native_batch_norm_backward_default_31[1]
        getitem_335 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_333, hardtanh__default_11, primals_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_333 = hardtanh__default_11 = primals_17 = None
        getitem_336 = convolution_backward_default_31[0]
        getitem_337 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_336, torch.float32);  getitem_336 = None
        to_dtype_64 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0.0)
        ge_scalar_21 = torch.ops.aten.ge.Scalar(to_dtype_64, 6.0);  to_dtype_64 = None
        __or___tensor_21 = torch.ops.aten.__or__.Tensor(le_scalar_21, ge_scalar_21);  le_scalar_21 = ge_scalar_21 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(__or___tensor_21, new_zeros_default_70, to_dtype_63);  __or___tensor_21 = new_zeros_default_70 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_16, primals_136, primals_134, primals_135, getitem_49, getitem_50, True, 0.001, [True, True, True]);  to_dtype_65 = convolution_default_16 = primals_136 = primals_134 = primals_135 = getitem_49 = getitem_50 = None
        getitem_339 = native_batch_norm_backward_default_32[0]
        getitem_340 = native_batch_norm_backward_default_32[1]
        getitem_341 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_339, constant_pad_nd_default_3, primals_15, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_339 = constant_pad_nd_default_3 = primals_15 = None
        getitem_342 = convolution_backward_default_32[0]
        getitem_343 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_342, [0, -1, 0, -1]);  getitem_342 = None
        to_dtype_66 = torch.ops.aten.to.dtype(constant_pad_nd_default_6, torch.float32);  constant_pad_nd_default_6 = None
        to_dtype_67 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0.0)
        ge_scalar_22 = torch.ops.aten.ge.Scalar(to_dtype_67, 6.0);  to_dtype_67 = None
        __or___tensor_22 = torch.ops.aten.__or__.Tensor(le_scalar_22, ge_scalar_22);  le_scalar_22 = ge_scalar_22 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(__or___tensor_22, new_zeros_default_71, to_dtype_66);  __or___tensor_22 = new_zeros_default_71 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_15, primals_131, primals_129, primals_130, getitem_46, getitem_47, True, 0.001, [True, True, True]);  to_dtype_68 = convolution_default_15 = primals_131 = primals_129 = primals_130 = getitem_46 = getitem_47 = None
        getitem_345 = native_batch_norm_backward_default_33[0]
        getitem_346 = native_batch_norm_backward_default_33[1]
        getitem_347 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_345, add_tensor_16, primals_16, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_345 = add_tensor_16 = primals_16 = None
        getitem_348 = convolution_backward_default_33[0]
        getitem_349 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(getitem_348, convolution_default_14, primals_126, primals_124, primals_125, getitem_43, getitem_44, True, 0.001, [True, True, True]);  convolution_default_14 = primals_126 = primals_124 = primals_125 = getitem_43 = getitem_44 = None
        getitem_351 = native_batch_norm_backward_default_34[0]
        getitem_352 = native_batch_norm_backward_default_34[1]
        getitem_353 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_351, hardtanh__default_9, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_351 = hardtanh__default_9 = primals_14 = None
        getitem_354 = convolution_backward_default_34[0]
        getitem_355 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_354, torch.float32);  getitem_354 = None
        to_dtype_70 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0.0)
        ge_scalar_23 = torch.ops.aten.ge.Scalar(to_dtype_70, 6.0);  to_dtype_70 = None
        __or___tensor_23 = torch.ops.aten.__or__.Tensor(le_scalar_23, ge_scalar_23);  le_scalar_23 = ge_scalar_23 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(__or___tensor_23, new_zeros_default_72, to_dtype_69);  __or___tensor_23 = new_zeros_default_72 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_13, primals_121, primals_119, primals_120, getitem_40, getitem_41, True, 0.001, [True, True, True]);  to_dtype_71 = convolution_default_13 = primals_121 = primals_119 = primals_120 = getitem_40 = getitem_41 = None
        getitem_357 = native_batch_norm_backward_default_35[0]
        getitem_358 = native_batch_norm_backward_default_35[1]
        getitem_359 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_357, hardtanh__default_8, primals_12, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_357 = hardtanh__default_8 = primals_12 = None
        getitem_360 = convolution_backward_default_35[0]
        getitem_361 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_360, torch.float32);  getitem_360 = None
        to_dtype_73 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0.0)
        ge_scalar_24 = torch.ops.aten.ge.Scalar(to_dtype_73, 6.0);  to_dtype_73 = None
        __or___tensor_24 = torch.ops.aten.__or__.Tensor(le_scalar_24, ge_scalar_24);  le_scalar_24 = ge_scalar_24 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(__or___tensor_24, new_zeros_default_73, to_dtype_72);  __or___tensor_24 = new_zeros_default_73 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_12, primals_116, primals_114, primals_115, getitem_37, getitem_38, True, 0.001, [True, True, True]);  to_dtype_74 = convolution_default_12 = primals_116 = primals_114 = primals_115 = getitem_37 = getitem_38 = None
        getitem_363 = native_batch_norm_backward_default_36[0]
        getitem_364 = native_batch_norm_backward_default_36[1]
        getitem_365 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_363, getitem_33, primals_13, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_363 = getitem_33 = primals_13 = None
        getitem_366 = convolution_backward_default_36[0]
        getitem_367 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_348, getitem_366);  getitem_348 = getitem_366 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_65, convolution_default_11, primals_111, primals_109, primals_110, getitem_34, getitem_35, True, 0.001, [True, True, True]);  add_tensor_65 = convolution_default_11 = primals_111 = primals_109 = primals_110 = getitem_34 = getitem_35 = None
        getitem_369 = native_batch_norm_backward_default_37[0]
        getitem_370 = native_batch_norm_backward_default_37[1]
        getitem_371 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_369, hardtanh__default_7, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_369 = hardtanh__default_7 = primals_11 = None
        getitem_372 = convolution_backward_default_37[0]
        getitem_373 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_372, torch.float32);  getitem_372 = None
        to_dtype_76 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0.0)
        ge_scalar_25 = torch.ops.aten.ge.Scalar(to_dtype_76, 6.0);  to_dtype_76 = None
        __or___tensor_25 = torch.ops.aten.__or__.Tensor(le_scalar_25, ge_scalar_25);  le_scalar_25 = ge_scalar_25 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(__or___tensor_25, new_zeros_default_74, to_dtype_75);  __or___tensor_25 = new_zeros_default_74 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_10, primals_106, primals_104, primals_105, getitem_31, getitem_32, True, 0.001, [True, True, True]);  to_dtype_77 = convolution_default_10 = primals_106 = primals_104 = primals_105 = getitem_31 = getitem_32 = None
        getitem_375 = native_batch_norm_backward_default_38[0]
        getitem_376 = native_batch_norm_backward_default_38[1]
        getitem_377 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_375, constant_pad_nd_default_2, primals_9, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_375 = constant_pad_nd_default_2 = primals_9 = None
        getitem_378 = convolution_backward_default_38[0]
        getitem_379 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(getitem_378, [-1, -2, -1, -2]);  getitem_378 = None
        to_dtype_78 = torch.ops.aten.to.dtype(constant_pad_nd_default_7, torch.float32);  constant_pad_nd_default_7 = None
        to_dtype_79 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0.0)
        ge_scalar_26 = torch.ops.aten.ge.Scalar(to_dtype_79, 6.0);  to_dtype_79 = None
        __or___tensor_26 = torch.ops.aten.__or__.Tensor(le_scalar_26, ge_scalar_26);  le_scalar_26 = ge_scalar_26 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(__or___tensor_26, new_zeros_default_75, to_dtype_78);  __or___tensor_26 = new_zeros_default_75 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_9, primals_101, primals_99, primals_100, getitem_28, getitem_29, True, 0.001, [True, True, True]);  to_dtype_80 = convolution_default_9 = primals_101 = primals_99 = primals_100 = getitem_28 = getitem_29 = None
        getitem_381 = native_batch_norm_backward_default_39[0]
        getitem_382 = native_batch_norm_backward_default_39[1]
        getitem_383 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_381, add_tensor_9, primals_10, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_381 = add_tensor_9 = primals_10 = None
        getitem_384 = convolution_backward_default_39[0]
        getitem_385 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(getitem_384, convolution_default_8, primals_96, primals_94, primals_95, getitem_25, getitem_26, True, 0.001, [True, True, True]);  convolution_default_8 = primals_96 = primals_94 = primals_95 = getitem_25 = getitem_26 = None
        getitem_387 = native_batch_norm_backward_default_40[0]
        getitem_388 = native_batch_norm_backward_default_40[1]
        getitem_389 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_387, hardtanh__default_5, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_387 = hardtanh__default_5 = primals_8 = None
        getitem_390 = convolution_backward_default_40[0]
        getitem_391 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_390, torch.float32);  getitem_390 = None
        to_dtype_82 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0.0)
        ge_scalar_27 = torch.ops.aten.ge.Scalar(to_dtype_82, 6.0);  to_dtype_82 = None
        __or___tensor_27 = torch.ops.aten.__or__.Tensor(le_scalar_27, ge_scalar_27);  le_scalar_27 = ge_scalar_27 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(__or___tensor_27, new_zeros_default_76, to_dtype_81);  __or___tensor_27 = new_zeros_default_76 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_7, primals_91, primals_89, primals_90, getitem_22, getitem_23, True, 0.001, [True, True, True]);  to_dtype_83 = convolution_default_7 = primals_91 = primals_89 = primals_90 = getitem_22 = getitem_23 = None
        getitem_393 = native_batch_norm_backward_default_41[0]
        getitem_394 = native_batch_norm_backward_default_41[1]
        getitem_395 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_393, hardtanh__default_4, primals_6, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_393 = hardtanh__default_4 = primals_6 = None
        getitem_396 = convolution_backward_default_41[0]
        getitem_397 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_396, torch.float32);  getitem_396 = None
        to_dtype_85 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0.0)
        ge_scalar_28 = torch.ops.aten.ge.Scalar(to_dtype_85, 6.0);  to_dtype_85 = None
        __or___tensor_28 = torch.ops.aten.__or__.Tensor(le_scalar_28, ge_scalar_28);  le_scalar_28 = ge_scalar_28 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(__or___tensor_28, new_zeros_default_77, to_dtype_84);  __or___tensor_28 = new_zeros_default_77 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_6, primals_86, primals_84, primals_85, getitem_19, getitem_20, True, 0.001, [True, True, True]);  to_dtype_86 = convolution_default_6 = primals_86 = primals_84 = primals_85 = getitem_19 = getitem_20 = None
        getitem_399 = native_batch_norm_backward_default_42[0]
        getitem_400 = native_batch_norm_backward_default_42[1]
        getitem_401 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_399, getitem_15, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_399 = getitem_15 = primals_7 = None
        getitem_402 = convolution_backward_default_42[0]
        getitem_403 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(getitem_384, getitem_402);  getitem_384 = getitem_402 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_66, convolution_default_5, primals_81, primals_79, primals_80, getitem_16, getitem_17, True, 0.001, [True, True, True]);  add_tensor_66 = convolution_default_5 = primals_81 = primals_79 = primals_80 = getitem_16 = getitem_17 = None
        getitem_405 = native_batch_norm_backward_default_43[0]
        getitem_406 = native_batch_norm_backward_default_43[1]
        getitem_407 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_405, hardtanh__default_3, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_405 = hardtanh__default_3 = primals_5 = None
        getitem_408 = convolution_backward_default_43[0]
        getitem_409 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_408, torch.float32);  getitem_408 = None
        to_dtype_88 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0.0)
        ge_scalar_29 = torch.ops.aten.ge.Scalar(to_dtype_88, 6.0);  to_dtype_88 = None
        __or___tensor_29 = torch.ops.aten.__or__.Tensor(le_scalar_29, ge_scalar_29);  le_scalar_29 = ge_scalar_29 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(__or___tensor_29, new_zeros_default_78, to_dtype_87);  __or___tensor_29 = new_zeros_default_78 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_4, primals_76, primals_74, primals_75, getitem_13, getitem_14, True, 0.001, [True, True, True]);  to_dtype_89 = convolution_default_4 = primals_76 = primals_74 = primals_75 = getitem_13 = getitem_14 = None
        getitem_411 = native_batch_norm_backward_default_44[0]
        getitem_412 = native_batch_norm_backward_default_44[1]
        getitem_413 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_411, constant_pad_nd_default_1, primals_3, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_411 = constant_pad_nd_default_1 = primals_3 = None
        getitem_414 = convolution_backward_default_44[0]
        getitem_415 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(getitem_414, [0, -1, 0, -1]);  getitem_414 = None
        to_dtype_90 = torch.ops.aten.to.dtype(constant_pad_nd_default_8, torch.float32);  constant_pad_nd_default_8 = None
        to_dtype_91 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0.0)
        ge_scalar_30 = torch.ops.aten.ge.Scalar(to_dtype_91, 6.0);  to_dtype_91 = None
        __or___tensor_30 = torch.ops.aten.__or__.Tensor(le_scalar_30, ge_scalar_30);  le_scalar_30 = ge_scalar_30 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(__or___tensor_30, new_zeros_default_79, to_dtype_90);  __or___tensor_30 = new_zeros_default_79 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_3, primals_71, primals_69, primals_70, getitem_10, getitem_11, True, 0.001, [True, True, True]);  to_dtype_92 = convolution_default_3 = primals_71 = primals_69 = primals_70 = getitem_10 = getitem_11 = None
        getitem_417 = native_batch_norm_backward_default_45[0]
        getitem_418 = native_batch_norm_backward_default_45[1]
        getitem_419 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_417, getitem_6, primals_4, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_417 = getitem_6 = primals_4 = None
        getitem_420 = convolution_backward_default_45[0]
        getitem_421 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(getitem_420, convolution_default_2, primals_66, primals_64, primals_65, getitem_7, getitem_8, True, 0.001, [True, True, True]);  getitem_420 = convolution_default_2 = primals_66 = primals_64 = primals_65 = getitem_7 = getitem_8 = None
        getitem_423 = native_batch_norm_backward_default_46[0]
        getitem_424 = native_batch_norm_backward_default_46[1]
        getitem_425 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_423, hardtanh__default_1, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_423 = hardtanh__default_1 = primals_2 = None
        getitem_426 = convolution_backward_default_46[0]
        getitem_427 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_426, torch.float32);  getitem_426 = None
        to_dtype_94 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0.0)
        ge_scalar_31 = torch.ops.aten.ge.Scalar(to_dtype_94, 6.0);  to_dtype_94 = None
        __or___tensor_31 = torch.ops.aten.__or__.Tensor(le_scalar_31, ge_scalar_31);  le_scalar_31 = ge_scalar_31 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(__or___tensor_31, new_zeros_default_80, to_dtype_93);  __or___tensor_31 = new_zeros_default_80 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_1, primals_61, primals_59, primals_60, getitem_4, getitem_5, True, 0.001, [True, True, True]);  to_dtype_95 = convolution_default_1 = primals_61 = primals_59 = primals_60 = getitem_4 = getitem_5 = None
        getitem_429 = native_batch_norm_backward_default_47[0]
        getitem_430 = native_batch_norm_backward_default_47[1]
        getitem_431 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_429, hardtanh__default, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_429 = hardtanh__default = primals_1 = None
        getitem_432 = convolution_backward_default_47[0]
        getitem_433 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_432, torch.float32);  getitem_432 = None
        to_dtype_97 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0.0)
        ge_scalar_32 = torch.ops.aten.ge.Scalar(to_dtype_97, 6.0);  to_dtype_97 = None
        __or___tensor_32 = torch.ops.aten.__or__.Tensor(le_scalar_32, ge_scalar_32);  le_scalar_32 = ge_scalar_32 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(__or___tensor_32, new_zeros_default_81, to_dtype_96);  __or___tensor_32 = new_zeros_default_81 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default, primals_56, primals_54, primals_55, getitem_1, getitem_2, True, 0.001, [True, True, True]);  to_dtype_98 = convolution_default = primals_56 = primals_54 = primals_55 = getitem_1 = getitem_2 = None
        getitem_435 = native_batch_norm_backward_default_48[0]
        getitem_436 = native_batch_norm_backward_default_48[1]
        getitem_437 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_435, constant_pad_nd_default, primals_51, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_435 = constant_pad_nd_default = primals_51 = None
        getitem_439 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        return [getitem_433, getitem_427, getitem_415, getitem_421, getitem_409, getitem_397, getitem_403, getitem_391, getitem_379, getitem_385, getitem_373, getitem_361, getitem_367, getitem_355, getitem_343, getitem_349, getitem_337, getitem_325, getitem_331, getitem_319, getitem_307, getitem_313, getitem_301, getitem_289, getitem_295, getitem_283, getitem_271, getitem_277, getitem_265, getitem_253, getitem_259, getitem_247, getitem_235, getitem_241, getitem_229, getitem_217, getitem_223, getitem_211, getitem_199, getitem_205, getitem_193, getitem_181, getitem_187, getitem_175, getitem_163, getitem_169, getitem_157, view_default_1, t_default_4, getitem_151, getitem_439, None, None, None, None, getitem_436, getitem_437, None, None, None, getitem_430, getitem_431, None, None, None, getitem_424, getitem_425, None, None, None, getitem_418, getitem_419, None, None, None, getitem_412, getitem_413, None, None, None, getitem_406, getitem_407, None, None, None, getitem_400, getitem_401, None, None, None, getitem_394, getitem_395, None, None, None, getitem_388, getitem_389, None, None, None, getitem_382, getitem_383, None, None, None, getitem_376, getitem_377, None, None, None, getitem_370, getitem_371, None, None, None, getitem_364, getitem_365, None, None, None, getitem_358, getitem_359, None, None, None, getitem_352, getitem_353, None, None, None, getitem_346, getitem_347, None, None, None, getitem_340, getitem_341, None, None, None, getitem_334, getitem_335, None, None, None, getitem_328, getitem_329, None, None, None, getitem_322, getitem_323, None, None, None, getitem_316, getitem_317, None, None, None, getitem_310, getitem_311, None, None, None, getitem_304, getitem_305, None, None, None, getitem_298, getitem_299, None, None, None, getitem_292, getitem_293, None, None, None, getitem_286, getitem_287, None, None, None, getitem_280, getitem_281, None, None, None, getitem_274, getitem_275, None, None, None, getitem_268, getitem_269, None, None, None, getitem_262, getitem_263, None, None, None, getitem_256, getitem_257, None, None, None, getitem_250, getitem_251, None, None, None, getitem_244, getitem_245, None, None, None, getitem_238, getitem_239, None, None, None, getitem_232, getitem_233, None, None, None, getitem_226, getitem_227, None, None, None, getitem_220, getitem_221, None, None, None, getitem_214, getitem_215, None, None, None, getitem_208, getitem_209, None, None, None, getitem_202, getitem_203, None, None, None, getitem_196, getitem_197, None, None, None, getitem_190, getitem_191, None, None, None, getitem_184, getitem_185, None, None, None, getitem_178, getitem_179, None, None, None, getitem_172, getitem_173, None, None, None, getitem_166, getitem_167, None, None, None, getitem_160, getitem_161, None, None, None, getitem_154, getitem_155, None, None, None, getitem_148, getitem_149]
        
