
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/selecsls42b/selecsls42b_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249):
        convolution_default = torch.ops.aten.convolution.default(primals_249, primals_243, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_248, primals_244, primals_246, primals_247, True, 0.1, 1e-05);  primals_244 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_8, primals_4, primals_6, primals_7, True, 0.1, 1e-05);  primals_4 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_14, primals_10, primals_12, primals_13, True, 0.1, 1e-05);  primals_10 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_15, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_20, primals_16, primals_18, primals_19, True, 0.1, 1e-05);  primals_16 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_26, primals_22, primals_24, primals_25, True, 0.1, 1e-05);  primals_22 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_32, primals_28, primals_30, primals_31, True, 0.1, 1e-05);  primals_28 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        cat_default = torch.ops.aten.cat.default([relu__default_1, relu__default_3, relu__default_5], 1)
        convolution_default_6 = torch.ops.aten.convolution.default(cat_default, primals_33, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_38, primals_34, primals_36, primals_37, True, 0.1, 1e-05);  primals_34 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_39, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_7, primals_45, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_50, primals_46, primals_48, primals_49, True, 0.1, 1e-05);  primals_46 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_51, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_56, primals_52, primals_54, primals_55, True, 0.1, 1e-05);  primals_52 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_9, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_62, primals_58, primals_60, primals_61, True, 0.1, 1e-05);  primals_58 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_10, primals_63, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_68, primals_64, primals_66, primals_67, True, 0.1, 1e-05);  primals_64 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_33);  getitem_33 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_7, relu__default_9, relu__default_11, relu__default_6], 1)
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default_1, primals_69, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_74, primals_70, primals_72, primals_73, True, 0.1, 1e-05);  primals_70 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_12, primals_75, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_80, primals_76, primals_78, primals_79, True, 0.1, 1e-05);  primals_76 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_13, primals_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_86, primals_82, primals_84, primals_85, True, 0.1, 1e-05);  primals_82 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_42);  getitem_42 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_14, primals_87, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_92, primals_88, primals_90, primals_91, True, 0.1, 1e-05);  primals_88 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_15, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_98, primals_94, primals_96, primals_97, True, 0.1, 1e-05);  primals_94 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_16, primals_99, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_104, primals_100, primals_102, primals_103, True, 0.1, 1e-05);  primals_100 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_51);  getitem_51 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_13, relu__default_15, relu__default_17], 1)
        convolution_default_18 = torch.ops.aten.convolution.default(cat_default_2, primals_105, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_110, primals_106, primals_108, primals_109, True, 0.1, 1e-05);  primals_106 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_18, primals_111, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_116, primals_112, primals_114, primals_115, True, 0.1, 1e-05);  primals_112 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_19, primals_117, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_122, primals_118, primals_120, primals_121, True, 0.1, 1e-05);  primals_118 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_20, primals_123, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_128, primals_124, primals_126, primals_127, True, 0.1, 1e-05);  primals_124 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_63);  getitem_63 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_21, primals_129, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_134, primals_130, primals_132, primals_133, True, 0.1, 1e-05);  primals_130 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_22, primals_135, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_140, primals_136, primals_138, primals_139, True, 0.1, 1e-05);  primals_136 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_19, relu__default_21, relu__default_23, relu__default_18], 1)
        convolution_default_24 = torch.ops.aten.convolution.default(cat_default_3, primals_141, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_146, primals_142, primals_144, primals_145, True, 0.1, 1e-05);  primals_142 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_24, primals_147, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_152, primals_148, primals_150, primals_151, True, 0.1, 1e-05);  primals_148 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_25, primals_153, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_158, primals_154, primals_156, primals_157, True, 0.1, 1e-05);  primals_154 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_26, primals_159, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_164, primals_160, primals_162, primals_163, True, 0.1, 1e-05);  primals_160 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_81);  getitem_81 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_27, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_170, primals_166, primals_168, primals_169, True, 0.1, 1e-05);  primals_166 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_84);  getitem_84 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_28, primals_171, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_176, primals_172, primals_174, primals_175, True, 0.1, 1e-05);  primals_172 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_25, relu__default_27, relu__default_29], 1)
        convolution_default_30 = torch.ops.aten.convolution.default(cat_default_4, primals_177, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_182, primals_178, primals_180, primals_181, True, 0.1, 1e-05);  primals_178 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_30, primals_183, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_188, primals_184, primals_186, primals_187, True, 0.1, 1e-05);  primals_184 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_31, primals_189, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_194, primals_190, primals_192, primals_193, True, 0.1, 1e-05);  primals_190 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_32, primals_195, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_200, primals_196, primals_198, primals_199, True, 0.1, 1e-05);  primals_196 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_99);  getitem_99 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_33, primals_201, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_206, primals_202, primals_204, primals_205, True, 0.1, 1e-05);  primals_202 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_34, primals_207, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_212, primals_208, primals_210, primals_211, True, 0.1, 1e-05);  primals_208 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_31, relu__default_33, relu__default_35, relu__default_30], 1)
        convolution_default_36 = torch.ops.aten.convolution.default(cat_default_5, primals_213, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_218, primals_214, primals_216, primals_217, True, 0.1, 1e-05);  primals_214 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_36, primals_219, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_224, primals_220, primals_222, primals_223, True, 0.1, 1e-05);  primals_220 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_37, primals_225, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_230, primals_226, primals_228, primals_229, True, 0.1, 1e-05);  primals_226 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_38, primals_231, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_236, primals_232, primals_234, primals_235, True, 0.1, 1e-05);  primals_232 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_117);  getitem_117 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_39, primals_237, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_242, primals_238, primals_240, primals_241, True, 0.1, 1e-05);  primals_238 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_40, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 1024]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        return [addmm_default, getitem_62, primals_174, getitem_61, primals_68, primals_116, primals_91, relu__default_20, convolution_default_21, primals_93, primals_92, primals_171, primals_66, primals_55, primals_67, primals_69, getitem_65, primals_61, primals_114, getitem_64, primals_56, primals_115, primals_63, primals_62, primals_60, relu__default_21, primals_54, primals_57, convolution_default_22, primals_90, primals_73, primals_192, getitem_67, primals_72, primals_193, getitem_68, primals_74, primals_128, primals_181, primals_235, primals_85, getitem_82, primals_180, primals_240, primals_109, primals_8, primals_222, relu__default_27, getitem_98, getitem_97, convolution_default_28, primals_228, primals_177, primals_242, primals_132, primals_223, primals_182, primals_13, getitem_83, primals_133, primals_225, relu__default_32, primals_7, primals_134, primals_123, primals_135, convolution_default_33, primals_6, getitem_86, primals_241, getitem_85, primals_236, primals_12, primals_234, primals_248, getitem_2, primals_224, primals_75, primals_138, primals_110, relu__default_28, getitem_100, getitem_101, getitem_1, primals_3, primals_87, primals_140, primals_230, primals_14, convolution_default_29, relu__default_33, primals_9, primals_175, primals_15, cat_default_4, relu__default, primals_141, primals_243, primals_229, primals_249, primals_144, primals_86, convolution_default_34, convolution_default_1, getitem_88, getitem_89, primals_231, primals_247, primals_129, primals_139, primals_237, primals_246, primals_126, getitem_104, relu__default_34, convolution_default_35, getitem_103, convolution_default_36, getitem_107, getitem_106, relu__default_35, primals_127, cat_default_5, getitem_109, getitem_110, getitem_47, primals_122, getitem_26, convolution_default_40, primals_183, relu__default_15, getitem_119, getitem_118, relu__default_8, convolution_default_16, getitem_25, convolution_default_17, convolution_default_9, relu__default_39, primals_168, getitem_50, primals_165, getitem_49, getitem_29, getitem_28, primals_186, primals_187, relu__default_16, primals_121, relu__default_9, getitem_122, getitem_121, primals_188, convolution_default_10, primals_189, relu__default_40, cat_default_2, getitem_52, getitem_53, convolution_default_11, getitem_31, getitem_32, relu__default_17, t_default, relu__default_10, view_default, primals_81, primals_97, primals_84, getitem_14, getitem_13, relu__default_4, primals_80, convolution_default, convolution_default_5, primals_96, primals_99, cat_default, getitem_17, primals_98, getitem_16, relu__default_5, primals_120, primals_169, convolution_default_6, getitem_5, relu__default_29, relu__default_22, getitem_4, primals_104, relu__default_1, convolution_default_23, convolution_default_24, primals_117, convolution_default_31, getitem_35, convolution_default_2, getitem_34, primals_33, convolution_default_30, primals_32, getitem_71, primals_102, getitem_70, getitem_92, relu__default_11, getitem_91, getitem_8, primals_19, getitem_7, primals_20, convolution_default_12, relu__default_23, relu__default_30, primals_21, primals_105, relu__default_2, primals_30, primals_18, primals_176, cat_default_1, primals_31, getitem_38, convolution_default_3, getitem_37, cat_default_3, getitem_94, getitem_10, primals_27, relu__default_12, getitem_95, primals_36, primals_111, relu__default_24, primals_26, getitem_73, primals_103, getitem_74, relu__default_31, convolution_default_13, primals_25, getitem_11, convolution_default_32, convolution_default_4, convolution_default_25, relu__default_3, primals_24, primals_79, convolution_default_18, convolution_default_19, relu__default_36, getitem_20, primals_194, convolution_default_37, primals_199, convolution_default_38, getitem_19, primals_37, getitem_56, getitem_55, relu__default_6, getitem_113, primals_45, getitem_112, primals_38, primals_39, convolution_default_7, relu__default_18, primals_44, relu__default_37, primals_42, primals_48, getitem_23, primals_195, getitem_22, getitem_59, primals_50, getitem_58, relu__default_7, convolution_default_39, getitem_115, primals_198, getitem_116, relu__default_19, convolution_default_8, primals_78, primals_200, primals_51, relu__default_38, primals_43, convolution_default_20, primals_49, primals_147, convolution_default_14, primals_146, primals_201, primals_210, getitem_41, getitem_40, getitem_77, primals_217, getitem_76, primals_108, relu__default_13, primals_163, primals_204, relu__default_25, primals_164, primals_205, convolution_default_26, primals_159, primals_213, getitem_44, primals_206, getitem_43, primals_158, primals_162, primals_157, primals_207, getitem_80, primals_156, getitem_79, relu__default_14, primals_212, primals_170, primals_219, relu__default_26, primals_153, convolution_default_15, primals_211, primals_145, primals_152, primals_151, convolution_default_27, primals_150, primals_218, getitem_46, primals_216]
        
