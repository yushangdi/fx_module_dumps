
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/regnetx_002/regnetx_002_backward_0/state_dict.pt'))

    
    
    def forward(self, convolution_default_31, getitem_92, getitem_122, relu_default_11, t_default, getitem_128, relu_default_6, convolution_default_30, primals_176, getitem_125, getitem_127, relu__default_17, getitem_121, convolution_default_25, primals_151, getitem_88, getitem_7, getitem_89, primals_13, convolution_default_36, getitem_76, relu__default_18, getitem_74, relu__default_26, primals_6, getitem_4, primals_5, getitem_109, convolution_default_43, primals_179, primals_7, getitem_5, getitem_130, primals_149, getitem_77, convolution_default_41, getitem_8, convolution_default_17, primals_180, primals_12, primals_144, getitem_73, convolution_default_26, getitem_131, primals_8, getitem_106, relu__default_25, primals_145, getitem_107, primals_146, getitem_110, relu__default_1, relu__default_9, primals_11, relu_default_12, primals_181, convolution_default_3, getitem_50, relu__default_21, convolution_default_42, relu__default_2, getitem_124, getitem_49, getitem_91, primals_10, primals_9, primals_150, view_default, convolution_default_2, relu_default_9, relu_default_5, convolution_default_21, getitem_94, primals_229, getitem_13, getitem_65, getitem_61, getitem_52, getitem_100, getitem_103, relu__default_20, convolution_default_34, getitem_104, primals_4, primals_231, getitem_95, primals_225, relu__default_14, relu__default_12, convolution_default_4, primals_224, getitem_62, relu_default_10, getitem_101, primals_230, getitem_64, relu_default_8, convolution_default_22, primals_226, primals_3, convolution_default_35, getitem_14, primals_199, primals_200, convolution_default_32, primals_15, getitem_2, relu__default_16, getitem_85, getitem_86, primals_196, convolution_default_28, primals_74, relu__default_15, relu_default_7, primals_16, getitem_83, primals_76, primals_19, convolution_default_16, primals_20, getitem_46, convolution_default_27, primals_18, primals_194, convolution_default_1, primals_195, primals_14, convolution_default_29, relu__default, primals_17, getitem_82, getitem_1, getitem_47, primals_75, convolution_default, primals_139, primals_51, primals_234, primals_134, primals_235, primals_135, primals_240, primals_239, primals_56, primals_244, primals_140, primals_241, getitem_11, primals_236, relu_default, primals_49, primals_50, primals_54, primals_141, primals_59, primals_136, primals_55, primals_159, relu__default_8, convolution_default_20, convolution_default_7, convolution_default_6, getitem_41, primals_105, primals_154, getitem_10, getitem_22, primals_160, primals_101, getitem_17, getitem_53, convolution_default_8, getitem_19, primals_104, convolution_default_9, convolution_default_14, relu_default_3, primals_109, primals_89, relu__default_13, getitem_79, primals_106, relu__default_10, getitem_25, relu__default_11, getitem_67, relu__default_3, getitem_68, getitem_23, primals_219, convolution_default_13, primals_220, getitem_56, relu_default_4, getitem_55, primals_156, getitem_59, primals_90, getitem_26, convolution_default_19, getitem_80, relu_default_1, getitem_37, getitem_20, primals_91, convolution_default_15, relu__default_4, primals_155, primals_221, getitem_58, primals_161, primals_110, convolution_default_23, relu__default_7, getitem_44, convolution_default_18, getitem_40, getitem_16, getitem_38, getitem_43, getitem_119, primals_264, primals_256, primals_255, primals_45, getitem_29, getitem_118, relu__default_24, relu__default_19, primals_44, primals_81, primals_85, primals_39, convolution_default_5, convolution_default_40, primals_259, primals_260, getitem_113, primals_79, primals_266, primals_46, primals_265, relu__default_22, primals_47, convolution_default_33, getitem_97, convolution_default_37, primals_261, primals_41, getitem_28, primals_42, primals_86, primals_254, primals_40, convolution_default_10, primals_84, primals_80, relu__default_5, getitem_98, primals_43, getitem_112, relu__default_23, primals_174, primals_186, primals_66, primals_60, primals_119, primals_215, primals_99, primals_116, primals_30, primals_164, primals_64, primals_190, primals_120, primals_61, primals_95, primals_165, primals_251, getitem_115, primals_29, primals_209, primals_114, primals_249, primals_31, primals_210, primals_191, convolution_default_38, primals_71, primals_96, primals_65, primals_184, primals_70, primals_214, primals_115, primals_170, primals_69, primals_100, primals_245, primals_94, primals_216, primals_166, primals_111, primals_189, primals_250, primals_171, getitem_116, primals_246, primals_185, primals_211, primals_169, primals_175, convolution_default_39, primals_37, primals_28, primals_125, convolution_default_12, primals_121, primals_131, primals_26, primals_35, getitem_32, getitem_31, convolution_default_11, primals_126, primals_25, primals_23, primals_32, primals_34, primals_21, relu_default_2, primals_205, relu__default_6, primals_38, primals_130, getitem_35, primals_36, getitem_71, primals_129, convolution_default_24, primals_206, primals_204, primals_201, getitem_34, getitem_70, primals_27, primals_24, primals_22, primals_33, primals_124, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 368, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 368, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_44, to_dtype);  le_scalar = new_zeros_default_44 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_43, primals_266, primals_264, primals_265, getitem_130, getitem_131, True, 1e-05, [True, True, True]);  convolution_default_43 = primals_266 = primals_264 = primals_265 = getitem_130 = getitem_131 = None
        getitem_132 = native_batch_norm_backward_default[0]
        getitem_133 = native_batch_norm_backward_default[1]
        getitem_134 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_132, relu__default_26, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_132 = primals_45 = None
        getitem_135 = convolution_backward_default[0]
        getitem_136 = convolution_backward_default[1];  convolution_backward_default = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_135, torch.float32);  getitem_135 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_45, to_dtype_3);  le_scalar_1 = new_zeros_default_45 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_42, primals_261, primals_259, primals_260, getitem_127, getitem_128, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_42 = primals_261 = primals_259 = primals_260 = getitem_127 = getitem_128 = None
        getitem_138 = native_batch_norm_backward_default_1[0]
        getitem_139 = native_batch_norm_backward_default_1[1]
        getitem_140 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_138, relu__default_25, primals_44, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_138 = primals_44 = None
        getitem_141 = convolution_backward_default_1[0]
        getitem_142 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_141, torch.float32);  getitem_141 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_46, to_dtype_6);  le_scalar_2 = new_zeros_default_46 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_41, primals_256, primals_254, primals_255, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_41 = primals_256 = primals_254 = primals_255 = getitem_124 = getitem_125 = None
        getitem_144 = native_batch_norm_backward_default_2[0]
        getitem_145 = native_batch_norm_backward_default_2[1]
        getitem_146 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_144, relu_default_11, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_144 = primals_43 = None
        getitem_147 = convolution_backward_default_2[0]
        getitem_148 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_147);  to_dtype_2 = getitem_147 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_57, torch.float32);  add_tensor_57 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_47, to_dtype_9);  le_scalar_3 = new_zeros_default_47 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_40, primals_251, primals_249, primals_250, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  convolution_default_40 = primals_251 = primals_249 = primals_250 = getitem_121 = getitem_122 = None
        getitem_150 = native_batch_norm_backward_default_3[0]
        getitem_151 = native_batch_norm_backward_default_3[1]
        getitem_152 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_150, relu__default_24, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_150 = primals_42 = None
        getitem_153 = convolution_backward_default_3[0]
        getitem_154 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_153, torch.float32);  getitem_153 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_48, to_dtype_12);  le_scalar_4 = new_zeros_default_48 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_39, primals_246, primals_244, primals_245, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_39 = primals_246 = primals_244 = primals_245 = getitem_118 = getitem_119 = None
        getitem_156 = native_batch_norm_backward_default_4[0]
        getitem_157 = native_batch_norm_backward_default_4[1]
        getitem_158 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_156, relu__default_23, primals_41, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_156 = primals_41 = None
        getitem_159 = convolution_backward_default_4[0]
        getitem_160 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_159, torch.float32);  getitem_159 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_49, to_dtype_15);  le_scalar_5 = new_zeros_default_49 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_38, primals_241, primals_239, primals_240, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_38 = primals_241 = primals_239 = primals_240 = getitem_115 = getitem_116 = None
        getitem_162 = native_batch_norm_backward_default_5[0]
        getitem_163 = native_batch_norm_backward_default_5[1]
        getitem_164 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_162, relu_default_10, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_162 = primals_40 = None
        getitem_165 = convolution_backward_default_5[0]
        getitem_166 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(to_dtype_11, getitem_165);  to_dtype_11 = getitem_165 = None
        to_dtype_18 = torch.ops.aten.to.dtype(add_tensor_58, torch.float32);  add_tensor_58 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_50, to_dtype_18);  le_scalar_6 = new_zeros_default_50 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_37, primals_236, primals_234, primals_235, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  convolution_default_37 = primals_236 = primals_234 = primals_235 = getitem_112 = getitem_113 = None
        getitem_168 = native_batch_norm_backward_default_6[0]
        getitem_169 = native_batch_norm_backward_default_6[1]
        getitem_170 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_168, relu__default_22, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_168 = primals_39 = None
        getitem_171 = convolution_backward_default_6[0]
        getitem_172 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_171, torch.float32);  getitem_171 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_51, to_dtype_21);  le_scalar_7 = new_zeros_default_51 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_36, primals_231, primals_229, primals_230, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_36 = primals_231 = primals_229 = primals_230 = getitem_109 = getitem_110 = None
        getitem_174 = native_batch_norm_backward_default_7[0]
        getitem_175 = native_batch_norm_backward_default_7[1]
        getitem_176 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_174, relu__default_21, primals_38, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_174 = primals_38 = None
        getitem_177 = convolution_backward_default_7[0]
        getitem_178 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_177, torch.float32);  getitem_177 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_52, to_dtype_24);  le_scalar_8 = new_zeros_default_52 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_35, primals_226, primals_224, primals_225, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_35 = primals_226 = primals_224 = primals_225 = getitem_106 = getitem_107 = None
        getitem_180 = native_batch_norm_backward_default_8[0]
        getitem_181 = native_batch_norm_backward_default_8[1]
        getitem_182 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_180, relu_default_9, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_180 = primals_37 = None
        getitem_183 = convolution_backward_default_8[0]
        getitem_184 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(to_dtype_20, getitem_183);  to_dtype_20 = getitem_183 = None
        to_dtype_27 = torch.ops.aten.to.dtype(add_tensor_59, torch.float32);  add_tensor_59 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_53, to_dtype_27);  le_scalar_9 = new_zeros_default_53 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_34, primals_221, primals_219, primals_220, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  convolution_default_34 = primals_221 = primals_219 = primals_220 = getitem_103 = getitem_104 = None
        getitem_186 = native_batch_norm_backward_default_9[0]
        getitem_187 = native_batch_norm_backward_default_9[1]
        getitem_188 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_186, relu__default_20, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_186 = primals_36 = None
        getitem_189 = convolution_backward_default_9[0]
        getitem_190 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_189, torch.float32);  getitem_189 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_54, to_dtype_30);  le_scalar_10 = new_zeros_default_54 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_33, primals_216, primals_214, primals_215, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_33 = primals_216 = primals_214 = primals_215 = getitem_100 = getitem_101 = None
        getitem_192 = native_batch_norm_backward_default_10[0]
        getitem_193 = native_batch_norm_backward_default_10[1]
        getitem_194 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_192, relu__default_19, primals_35, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_192 = primals_35 = None
        getitem_195 = convolution_backward_default_10[0]
        getitem_196 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_195, torch.float32);  getitem_195 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_55, to_dtype_33);  le_scalar_11 = new_zeros_default_55 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_32, primals_211, primals_209, primals_210, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_32 = primals_211 = primals_209 = primals_210 = getitem_97 = getitem_98 = None
        getitem_198 = native_batch_norm_backward_default_11[0]
        getitem_199 = native_batch_norm_backward_default_11[1]
        getitem_200 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_198, relu_default_8, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_198 = primals_34 = None
        getitem_201 = convolution_backward_default_11[0]
        getitem_202 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(to_dtype_29, getitem_201);  to_dtype_29 = getitem_201 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_60, torch.float32);  add_tensor_60 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_56, to_dtype_36);  le_scalar_12 = new_zeros_default_56 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_31, primals_206, primals_204, primals_205, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  convolution_default_31 = primals_206 = primals_204 = primals_205 = getitem_94 = getitem_95 = None
        getitem_204 = native_batch_norm_backward_default_12[0]
        getitem_205 = native_batch_norm_backward_default_12[1]
        getitem_206 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_204, relu__default_18, primals_33, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_204 = primals_33 = None
        getitem_207 = convolution_backward_default_12[0]
        getitem_208 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_207, torch.float32);  getitem_207 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_57, to_dtype_39);  le_scalar_13 = new_zeros_default_57 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_30, primals_201, primals_199, primals_200, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_30 = primals_201 = primals_199 = primals_200 = getitem_91 = getitem_92 = None
        getitem_210 = native_batch_norm_backward_default_13[0]
        getitem_211 = native_batch_norm_backward_default_13[1]
        getitem_212 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_210, relu__default_17, primals_32, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_210 = primals_32 = None
        getitem_213 = convolution_backward_default_13[0]
        getitem_214 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_213, torch.float32);  getitem_213 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_58, to_dtype_42);  le_scalar_14 = new_zeros_default_58 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_29, primals_196, primals_194, primals_195, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_29 = primals_196 = primals_194 = primals_195 = getitem_88 = getitem_89 = None
        getitem_216 = native_batch_norm_backward_default_14[0]
        getitem_217 = native_batch_norm_backward_default_14[1]
        getitem_218 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_216, relu_default_7, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_216 = primals_31 = None
        getitem_219 = convolution_backward_default_14[0]
        getitem_220 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(to_dtype_38, getitem_219);  to_dtype_38 = getitem_219 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_61, torch.float32);  add_tensor_61 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_59, to_dtype_45);  le_scalar_15 = new_zeros_default_59 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_28, primals_191, primals_189, primals_190, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  convolution_default_28 = primals_191 = primals_189 = primals_190 = getitem_85 = getitem_86 = None
        getitem_222 = native_batch_norm_backward_default_15[0]
        getitem_223 = native_batch_norm_backward_default_15[1]
        getitem_224 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_222, relu__default_16, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_222 = primals_30 = None
        getitem_225 = convolution_backward_default_15[0]
        getitem_226 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_225, torch.float32);  getitem_225 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_60, to_dtype_48);  le_scalar_16 = new_zeros_default_60 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_27, primals_186, primals_184, primals_185, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_27 = primals_186 = primals_184 = primals_185 = getitem_82 = getitem_83 = None
        getitem_228 = native_batch_norm_backward_default_16[0]
        getitem_229 = native_batch_norm_backward_default_16[1]
        getitem_230 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_228, relu__default_15, primals_29, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_228 = primals_29 = None
        getitem_231 = convolution_backward_default_16[0]
        getitem_232 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_231, torch.float32);  getitem_231 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_61, to_dtype_51);  le_scalar_17 = new_zeros_default_61 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_26, primals_181, primals_179, primals_180, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_26 = primals_181 = primals_179 = primals_180 = getitem_79 = getitem_80 = None
        getitem_234 = native_batch_norm_backward_default_17[0]
        getitem_235 = native_batch_norm_backward_default_17[1]
        getitem_236 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_234, relu_default_6, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_234 = primals_28 = None
        getitem_237 = convolution_backward_default_17[0]
        getitem_238 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(to_dtype_47, getitem_237);  to_dtype_47 = getitem_237 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_62, to_dtype_54);  le_scalar_18 = new_zeros_default_62 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_25, primals_176, primals_174, primals_175, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  convolution_default_25 = primals_176 = primals_174 = primals_175 = getitem_76 = getitem_77 = None
        getitem_240 = native_batch_norm_backward_default_18[0]
        getitem_241 = native_batch_norm_backward_default_18[1]
        getitem_242 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_240, relu_default_5, primals_27, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_240 = primals_27 = None
        getitem_243 = convolution_backward_default_18[0]
        getitem_244 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_24, primals_171, primals_169, primals_170, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_24 = primals_171 = primals_169 = primals_170 = getitem_73 = getitem_74 = None
        getitem_246 = native_batch_norm_backward_default_19[0]
        getitem_247 = native_batch_norm_backward_default_19[1]
        getitem_248 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_246, relu__default_14, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_246 = primals_26 = None
        getitem_249 = convolution_backward_default_19[0]
        getitem_250 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_249, torch.float32);  getitem_249 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_63, to_dtype_57);  le_scalar_19 = new_zeros_default_63 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_23, primals_166, primals_164, primals_165, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_23 = primals_166 = primals_164 = primals_165 = getitem_70 = getitem_71 = None
        getitem_252 = native_batch_norm_backward_default_20[0]
        getitem_253 = native_batch_norm_backward_default_20[1]
        getitem_254 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_252, relu__default_13, primals_25, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 46, [True, True, False]);  getitem_252 = primals_25 = None
        getitem_255 = convolution_backward_default_20[0]
        getitem_256 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_255, torch.float32);  getitem_255 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_64, to_dtype_60);  le_scalar_20 = new_zeros_default_64 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_22, primals_161, primals_159, primals_160, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_22 = primals_161 = primals_159 = primals_160 = getitem_67 = getitem_68 = None
        getitem_258 = native_batch_norm_backward_default_21[0]
        getitem_259 = native_batch_norm_backward_default_21[1]
        getitem_260 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_258, relu_default_5, primals_24, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_258 = primals_24 = None
        getitem_261 = convolution_backward_default_21[0]
        getitem_262 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(getitem_243, getitem_261);  getitem_243 = getitem_261 = None
        to_dtype_63 = torch.ops.aten.to.dtype(add_tensor_63, torch.float32);  add_tensor_63 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_65, to_dtype_63);  le_scalar_21 = new_zeros_default_65 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_21, primals_156, primals_154, primals_155, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  convolution_default_21 = primals_156 = primals_154 = primals_155 = getitem_64 = getitem_65 = None
        getitem_264 = native_batch_norm_backward_default_22[0]
        getitem_265 = native_batch_norm_backward_default_22[1]
        getitem_266 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_264, relu__default_12, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_264 = primals_23 = None
        getitem_267 = convolution_backward_default_22[0]
        getitem_268 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_267, torch.float32);  getitem_267 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_66, to_dtype_66);  le_scalar_22 = new_zeros_default_66 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_20, primals_151, primals_149, primals_150, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_20 = primals_151 = primals_149 = primals_150 = getitem_61 = getitem_62 = None
        getitem_270 = native_batch_norm_backward_default_23[0]
        getitem_271 = native_batch_norm_backward_default_23[1]
        getitem_272 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_270, relu__default_11, primals_22, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 19, [True, True, False]);  getitem_270 = primals_22 = None
        getitem_273 = convolution_backward_default_23[0]
        getitem_274 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_273, torch.float32);  getitem_273 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_67, to_dtype_69);  le_scalar_23 = new_zeros_default_67 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_19, primals_146, primals_144, primals_145, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_19 = primals_146 = primals_144 = primals_145 = getitem_58 = getitem_59 = None
        getitem_276 = native_batch_norm_backward_default_24[0]
        getitem_277 = native_batch_norm_backward_default_24[1]
        getitem_278 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_276, relu_default_4, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_276 = primals_21 = None
        getitem_279 = convolution_backward_default_24[0]
        getitem_280 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(to_dtype_65, getitem_279);  to_dtype_65 = getitem_279 = None
        to_dtype_72 = torch.ops.aten.to.dtype(add_tensor_64, torch.float32);  add_tensor_64 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_68, to_dtype_72);  le_scalar_24 = new_zeros_default_68 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_18, primals_141, primals_139, primals_140, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  convolution_default_18 = primals_141 = primals_139 = primals_140 = getitem_55 = getitem_56 = None
        getitem_282 = native_batch_norm_backward_default_25[0]
        getitem_283 = native_batch_norm_backward_default_25[1]
        getitem_284 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_282, relu__default_10, primals_20, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_282 = primals_20 = None
        getitem_285 = convolution_backward_default_25[0]
        getitem_286 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_285, torch.float32);  getitem_285 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_69, to_dtype_75);  le_scalar_25 = new_zeros_default_69 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_17, primals_136, primals_134, primals_135, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_17 = primals_136 = primals_134 = primals_135 = getitem_52 = getitem_53 = None
        getitem_288 = native_batch_norm_backward_default_26[0]
        getitem_289 = native_batch_norm_backward_default_26[1]
        getitem_290 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_288, relu__default_9, primals_19, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 19, [True, True, False]);  getitem_288 = primals_19 = None
        getitem_291 = convolution_backward_default_26[0]
        getitem_292 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_291, torch.float32);  getitem_291 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_70, to_dtype_78);  le_scalar_26 = new_zeros_default_70 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_16, primals_131, primals_129, primals_130, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_16 = primals_131 = primals_129 = primals_130 = getitem_49 = getitem_50 = None
        getitem_294 = native_batch_norm_backward_default_27[0]
        getitem_295 = native_batch_norm_backward_default_27[1]
        getitem_296 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_294, relu_default_3, primals_18, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_294 = primals_18 = None
        getitem_297 = convolution_backward_default_27[0]
        getitem_298 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(to_dtype_74, getitem_297);  to_dtype_74 = getitem_297 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_71, to_dtype_81);  le_scalar_27 = new_zeros_default_71 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_15, primals_126, primals_124, primals_125, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  convolution_default_15 = primals_126 = primals_124 = primals_125 = getitem_46 = getitem_47 = None
        getitem_300 = native_batch_norm_backward_default_28[0]
        getitem_301 = native_batch_norm_backward_default_28[1]
        getitem_302 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_300, relu__default_8, primals_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_300 = primals_17 = None
        getitem_303 = convolution_backward_default_28[0]
        getitem_304 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_303, torch.float32);  getitem_303 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_72, to_dtype_84);  le_scalar_28 = new_zeros_default_72 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_14, primals_121, primals_119, primals_120, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_14 = primals_121 = primals_119 = primals_120 = getitem_43 = getitem_44 = None
        getitem_306 = native_batch_norm_backward_default_29[0]
        getitem_307 = native_batch_norm_backward_default_29[1]
        getitem_308 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_306, relu__default_7, primals_16, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 19, [True, True, False]);  getitem_306 = primals_16 = None
        getitem_309 = convolution_backward_default_29[0]
        getitem_310 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_309, torch.float32);  getitem_309 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_73, to_dtype_87);  le_scalar_29 = new_zeros_default_73 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_13, primals_116, primals_114, primals_115, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_13 = primals_116 = primals_114 = primals_115 = getitem_40 = getitem_41 = None
        getitem_312 = native_batch_norm_backward_default_30[0]
        getitem_313 = native_batch_norm_backward_default_30[1]
        getitem_314 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_312, relu_default_2, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_312 = primals_15 = None
        getitem_315 = convolution_backward_default_30[0]
        getitem_316 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(to_dtype_83, getitem_315);  to_dtype_83 = getitem_315 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_74, to_dtype_90);  le_scalar_30 = new_zeros_default_74 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_12, primals_111, primals_109, primals_110, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  convolution_default_12 = primals_111 = primals_109 = primals_110 = getitem_37 = getitem_38 = None
        getitem_318 = native_batch_norm_backward_default_31[0]
        getitem_319 = native_batch_norm_backward_default_31[1]
        getitem_320 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_318, relu_default_1, primals_14, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_318 = primals_14 = None
        getitem_321 = convolution_backward_default_31[0]
        getitem_322 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_11, primals_106, primals_104, primals_105, getitem_34, getitem_35, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_11 = primals_106 = primals_104 = primals_105 = getitem_34 = getitem_35 = None
        getitem_324 = native_batch_norm_backward_default_32[0]
        getitem_325 = native_batch_norm_backward_default_32[1]
        getitem_326 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_324, relu__default_6, primals_13, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_324 = primals_13 = None
        getitem_327 = convolution_backward_default_32[0]
        getitem_328 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_327, torch.float32);  getitem_327 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_75, to_dtype_93);  le_scalar_31 = new_zeros_default_75 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_10, primals_101, primals_99, primals_100, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_10 = primals_101 = primals_99 = primals_100 = getitem_31 = getitem_32 = None
        getitem_330 = native_batch_norm_backward_default_33[0]
        getitem_331 = native_batch_norm_backward_default_33[1]
        getitem_332 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_330, relu__default_5, primals_12, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 19, [True, True, False]);  getitem_330 = primals_12 = None
        getitem_333 = convolution_backward_default_33[0]
        getitem_334 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_333, torch.float32);  getitem_333 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_76, to_dtype_96);  le_scalar_32 = new_zeros_default_76 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_9, primals_96, primals_94, primals_95, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_9 = primals_96 = primals_94 = primals_95 = getitem_28 = getitem_29 = None
        getitem_336 = native_batch_norm_backward_default_34[0]
        getitem_337 = native_batch_norm_backward_default_34[1]
        getitem_338 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_336, relu_default_1, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_336 = primals_11 = None
        getitem_339 = convolution_backward_default_34[0]
        getitem_340 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(getitem_321, getitem_339);  getitem_321 = getitem_339 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_67, torch.float32);  add_tensor_67 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_77, to_dtype_99);  le_scalar_33 = new_zeros_default_77 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_8, primals_91, primals_89, primals_90, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  convolution_default_8 = primals_91 = primals_89 = primals_90 = getitem_25 = getitem_26 = None
        getitem_342 = native_batch_norm_backward_default_35[0]
        getitem_343 = native_batch_norm_backward_default_35[1]
        getitem_344 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_342, relu_default, primals_10, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_342 = primals_10 = None
        getitem_345 = convolution_backward_default_35[0]
        getitem_346 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_7, primals_86, primals_84, primals_85, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_7 = primals_86 = primals_84 = primals_85 = getitem_22 = getitem_23 = None
        getitem_348 = native_batch_norm_backward_default_36[0]
        getitem_349 = native_batch_norm_backward_default_36[1]
        getitem_350 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_348, relu__default_4, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_348 = primals_9 = None
        getitem_351 = convolution_backward_default_36[0]
        getitem_352 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_351, torch.float32);  getitem_351 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_78, to_dtype_102);  le_scalar_34 = new_zeros_default_78 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_6, primals_81, primals_79, primals_80, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_6 = primals_81 = primals_79 = primals_80 = getitem_19 = getitem_20 = None
        getitem_354 = native_batch_norm_backward_default_37[0]
        getitem_355 = native_batch_norm_backward_default_37[1]
        getitem_356 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_354, relu__default_3, primals_8, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 7, [True, True, False]);  getitem_354 = primals_8 = None
        getitem_357 = convolution_backward_default_37[0]
        getitem_358 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_357, torch.float32);  getitem_357 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_79, to_dtype_105);  le_scalar_35 = new_zeros_default_79 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_5, primals_76, primals_74, primals_75, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_5 = primals_76 = primals_74 = primals_75 = getitem_16 = getitem_17 = None
        getitem_360 = native_batch_norm_backward_default_38[0]
        getitem_361 = native_batch_norm_backward_default_38[1]
        getitem_362 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_360, relu_default, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_360 = primals_7 = None
        getitem_363 = convolution_backward_default_38[0]
        getitem_364 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_345, getitem_363);  getitem_345 = getitem_363 = None
        to_dtype_108 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_80, to_dtype_108);  le_scalar_36 = new_zeros_default_80 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_4, primals_71, primals_69, primals_70, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  convolution_default_4 = primals_71 = primals_69 = primals_70 = getitem_13 = getitem_14 = None
        getitem_366 = native_batch_norm_backward_default_39[0]
        getitem_367 = native_batch_norm_backward_default_39[1]
        getitem_368 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_366, relu__default, primals_6, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_366 = primals_6 = None
        getitem_369 = convolution_backward_default_39[0]
        getitem_370 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_3, primals_66, primals_64, primals_65, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_3 = primals_66 = primals_64 = primals_65 = getitem_10 = getitem_11 = None
        getitem_372 = native_batch_norm_backward_default_40[0]
        getitem_373 = native_batch_norm_backward_default_40[1]
        getitem_374 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_372, relu__default_2, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_372 = primals_5 = None
        getitem_375 = convolution_backward_default_40[0]
        getitem_376 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_375, torch.float32);  getitem_375 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_81, to_dtype_111);  le_scalar_37 = new_zeros_default_81 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_2, primals_61, primals_59, primals_60, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_2 = primals_61 = primals_59 = primals_60 = getitem_7 = getitem_8 = None
        getitem_378 = native_batch_norm_backward_default_41[0]
        getitem_379 = native_batch_norm_backward_default_41[1]
        getitem_380 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_378, relu__default_1, primals_4, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 3, [True, True, False]);  getitem_378 = primals_4 = None
        getitem_381 = convolution_backward_default_41[0]
        getitem_382 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_381, torch.float32);  getitem_381 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_82, to_dtype_114);  le_scalar_38 = new_zeros_default_82 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_1, primals_56, primals_54, primals_55, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_1 = primals_56 = primals_54 = primals_55 = getitem_4 = getitem_5 = None
        getitem_384 = native_batch_norm_backward_default_42[0]
        getitem_385 = native_batch_norm_backward_default_42[1]
        getitem_386 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_384, relu__default, primals_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_384 = primals_3 = None
        getitem_387 = convolution_backward_default_42[0]
        getitem_388 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(getitem_369, getitem_387);  getitem_369 = getitem_387 = None
        to_dtype_117 = torch.ops.aten.to.dtype(add_tensor_69, torch.float32);  add_tensor_69 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_83, to_dtype_117);  le_scalar_39 = new_zeros_default_83 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default, primals_51, primals_49, primals_50, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default = primals_51 = primals_49 = primals_50 = getitem_1 = getitem_2 = None
        getitem_390 = native_batch_norm_backward_default_43[0]
        getitem_391 = native_batch_norm_backward_default_43[1]
        getitem_392 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_390, primals_47, primals_46, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_390 = primals_47 = primals_46 = None
        getitem_394 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        return [view_default_1, t_default_4, getitem_388, getitem_382, getitem_376, getitem_370, getitem_364, getitem_358, getitem_352, getitem_346, getitem_340, getitem_334, getitem_328, getitem_322, getitem_316, getitem_310, getitem_304, getitem_298, getitem_292, getitem_286, getitem_280, getitem_274, getitem_268, getitem_262, getitem_256, getitem_250, getitem_244, getitem_238, getitem_232, getitem_226, getitem_220, getitem_214, getitem_208, getitem_202, getitem_196, getitem_190, getitem_184, getitem_178, getitem_172, getitem_166, getitem_160, getitem_154, getitem_148, getitem_142, getitem_136, getitem_394, None, None, None, None, getitem_391, getitem_392, None, None, None, getitem_385, getitem_386, None, None, None, getitem_379, getitem_380, None, None, None, getitem_373, getitem_374, None, None, None, getitem_367, getitem_368, None, None, None, getitem_361, getitem_362, None, None, None, getitem_355, getitem_356, None, None, None, getitem_349, getitem_350, None, None, None, getitem_343, getitem_344, None, None, None, getitem_337, getitem_338, None, None, None, getitem_331, getitem_332, None, None, None, getitem_325, getitem_326, None, None, None, getitem_319, getitem_320, None, None, None, getitem_313, getitem_314, None, None, None, getitem_307, getitem_308, None, None, None, getitem_301, getitem_302, None, None, None, getitem_295, getitem_296, None, None, None, getitem_289, getitem_290, None, None, None, getitem_283, getitem_284, None, None, None, getitem_277, getitem_278, None, None, None, getitem_271, getitem_272, None, None, None, getitem_265, getitem_266, None, None, None, getitem_259, getitem_260, None, None, None, getitem_253, getitem_254, None, None, None, getitem_247, getitem_248, None, None, None, getitem_241, getitem_242, None, None, None, getitem_235, getitem_236, None, None, None, getitem_229, getitem_230, None, None, None, getitem_223, getitem_224, None, None, None, getitem_217, getitem_218, None, None, None, getitem_211, getitem_212, None, None, None, getitem_205, getitem_206, None, None, None, getitem_199, getitem_200, None, None, None, getitem_193, getitem_194, None, None, None, getitem_187, getitem_188, None, None, None, getitem_181, getitem_182, None, None, None, getitem_175, getitem_176, None, None, None, getitem_169, getitem_170, None, None, None, getitem_163, getitem_164, None, None, None, getitem_157, getitem_158, None, None, None, getitem_151, getitem_152, None, None, None, getitem_145, getitem_146, None, None, None, getitem_139, getitem_140, None, None, None, getitem_133, getitem_134]
        
