
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/skresnet18/skresnet18_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25):
        convolution_default = torch.ops.aten.convolution.default(primals_107, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        split_tensor = torch.ops.aten.split.Tensor(getitem_3, 32, 1)
        getitem_5 = split_tensor[0]
        getitem_6 = split_tensor[1];  split_tensor = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_5, primals_16, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_108, 1);  primals_108 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_111, primals_112, primals_109, primals_110, True, 0.1, 1e-05);  primals_112 = None
        getitem_7 = native_batch_norm_default_1[0]
        getitem_8 = native_batch_norm_default_1[1]
        getitem_9 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_7);  getitem_7 = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_6, primals_17, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_113, 1);  primals_113 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_116, primals_117, primals_114, primals_115, True, 0.1, 1e-05);  primals_117 = None
        getitem_10 = native_batch_norm_default_2[0]
        getitem_11 = native_batch_norm_default_2[1]
        getitem_12 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_10);  getitem_10 = None
        stack_default = torch.ops.aten.stack.default([relu__default_1, relu__default_2], 1)
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(stack_default, [1])
        mean_dim = torch.ops.aten.mean.dim(sum_dim_int_list, [2, 3], True);  sum_dim_int_list = None
        convolution_default_3 = torch.ops.aten.convolution.default(mean_dim, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_10, 1);  primals_10 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_13, primals_9, primals_11, primals_12, True, 0.1, 1e-05);  primals_9 = None
        getitem_13 = native_batch_norm_default_3[0]
        getitem_14 = native_batch_norm_default_3[1]
        getitem_15 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_13);  getitem_13 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default = torch.ops.aten.view.default(convolution_default_4, [128, 2, 64, 1, 1]);  convolution_default_4 = None
        _softmax_default = torch.ops.aten._softmax.default(view_default, 1, False);  view_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(stack_default, _softmax_default)
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor, [1]);  mul_tensor = None
        convolution_default_5 = torch.ops.aten.convolution.default(sum_dim_int_list_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_118, 1);  primals_118 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_121, primals_122, primals_119, primals_120, True, 0.1, 1e-05);  primals_122 = None
        getitem_16 = native_batch_norm_default_4[0]
        getitem_17 = native_batch_norm_default_4[1]
        getitem_18 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_16, getitem_3);  getitem_16 = getitem_3 = None
        relu__default_4 = torch.ops.aten.relu_.default(add__tensor_2);  add__tensor_2 = None
        split_tensor_1 = torch.ops.aten.split.Tensor(relu__default_4, 32, 1)
        getitem_19 = split_tensor_1[0]
        getitem_20 = split_tensor_1[1];  split_tensor_1 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_19, primals_26, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_123, 1);  primals_123 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_126, primals_127, primals_124, primals_125, True, 0.1, 1e-05);  primals_127 = None
        getitem_21 = native_batch_norm_default_5[0]
        getitem_22 = native_batch_norm_default_5[1]
        getitem_23 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_20, primals_27, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_128, 1);  primals_128 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_131, primals_132, primals_129, primals_130, True, 0.1, 1e-05);  primals_132 = None
        getitem_24 = native_batch_norm_default_6[0]
        getitem_25 = native_batch_norm_default_6[1]
        getitem_26 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        stack_default_1 = torch.ops.aten.stack.default([relu__default_5, relu__default_6], 1)
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(stack_default_1, [1])
        mean_dim_1 = torch.ops.aten.mean.dim(sum_dim_int_list_2, [2, 3], True);  sum_dim_int_list_2 = None
        convolution_default_8 = torch.ops.aten.convolution.default(mean_dim_1, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_20, 1);  primals_20 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_23, primals_19, primals_21, primals_22, True, 0.1, 1e-05);  primals_19 = None
        getitem_27 = native_batch_norm_default_7[0]
        getitem_28 = native_batch_norm_default_7[1]
        getitem_29 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_1 = torch.ops.aten.view.default(convolution_default_9, [128, 2, 64, 1, 1]);  convolution_default_9 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(view_default_1, 1, False);  view_default_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(stack_default_1, _softmax_default_1)
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_1, [1]);  mul_tensor_1 = None
        convolution_default_10 = torch.ops.aten.convolution.default(sum_dim_int_list_3, primals_28, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_133, 1);  primals_133 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_136, primals_137, primals_134, primals_135, True, 0.1, 1e-05);  primals_137 = None
        getitem_30 = native_batch_norm_default_8[0]
        getitem_31 = native_batch_norm_default_8[1]
        getitem_32 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_30, relu__default_4);  getitem_30 = None
        relu__default_8 = torch.ops.aten.relu_.default(add__tensor_4);  add__tensor_4 = None
        split_tensor_2 = torch.ops.aten.split.Tensor(relu__default_8, 32, 1)
        getitem_33 = split_tensor_2[0]
        getitem_34 = split_tensor_2[1];  split_tensor_2 = None
        convolution_default_11 = torch.ops.aten.convolution.default(getitem_33, primals_36, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_138, 1);  primals_138 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_141, primals_142, primals_139, primals_140, True, 0.1, 1e-05);  primals_142 = None
        getitem_35 = native_batch_norm_default_9[0]
        getitem_36 = native_batch_norm_default_9[1]
        getitem_37 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_12 = torch.ops.aten.convolution.default(getitem_34, primals_37, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_143, 1);  primals_143 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_146, primals_147, primals_144, primals_145, True, 0.1, 1e-05);  primals_147 = None
        getitem_38 = native_batch_norm_default_10[0]
        getitem_39 = native_batch_norm_default_10[1]
        getitem_40 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        stack_default_2 = torch.ops.aten.stack.default([relu__default_9, relu__default_10], 1)
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(stack_default_2, [1])
        mean_dim_2 = torch.ops.aten.mean.dim(sum_dim_int_list_4, [2, 3], True);  sum_dim_int_list_4 = None
        convolution_default_13 = torch.ops.aten.convolution.default(mean_dim_2, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_30, 1);  primals_30 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_33, primals_29, primals_31, primals_32, True, 0.1, 1e-05);  primals_29 = None
        getitem_41 = native_batch_norm_default_11[0]
        getitem_42 = native_batch_norm_default_11[1]
        getitem_43 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_11, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_2 = torch.ops.aten.view.default(convolution_default_14, [128, 2, 128, 1, 1]);  convolution_default_14 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(view_default_2, 1, False);  view_default_2 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(stack_default_2, _softmax_default_2)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_2, [1]);  mul_tensor_2 = None
        convolution_default_15 = torch.ops.aten.convolution.default(sum_dim_int_list_5, primals_38, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_148, 1);  primals_148 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_151, primals_152, primals_149, primals_150, True, 0.1, 1e-05);  primals_152 = None
        getitem_44 = native_batch_norm_default_12[0]
        getitem_45 = native_batch_norm_default_12[1]
        getitem_46 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_8, primals_39, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_41, 1);  primals_41 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_47 = native_batch_norm_default_13[0]
        getitem_48 = native_batch_norm_default_13[1]
        getitem_49 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_44, getitem_47);  getitem_44 = getitem_47 = None
        relu__default_12 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        split_tensor_3 = torch.ops.aten.split.Tensor(relu__default_12, 64, 1)
        getitem_50 = split_tensor_3[0]
        getitem_51 = split_tensor_3[1];  split_tensor_3 = None
        convolution_default_17 = torch.ops.aten.convolution.default(getitem_50, primals_52, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_153, 1);  primals_153 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_156, primals_157, primals_154, primals_155, True, 0.1, 1e-05);  primals_157 = None
        getitem_52 = native_batch_norm_default_14[0]
        getitem_53 = native_batch_norm_default_14[1]
        getitem_54 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        convolution_default_18 = torch.ops.aten.convolution.default(getitem_51, primals_53, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_158, 1);  primals_158 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_161, primals_162, primals_159, primals_160, True, 0.1, 1e-05);  primals_162 = None
        getitem_55 = native_batch_norm_default_15[0]
        getitem_56 = native_batch_norm_default_15[1]
        getitem_57 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        stack_default_3 = torch.ops.aten.stack.default([relu__default_13, relu__default_14], 1)
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(stack_default_3, [1])
        mean_dim_3 = torch.ops.aten.mean.dim(sum_dim_int_list_6, [2, 3], True);  sum_dim_int_list_6 = None
        convolution_default_19 = torch.ops.aten.convolution.default(mean_dim_3, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_46, 1);  primals_46 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_49, primals_45, primals_47, primals_48, True, 0.1, 1e-05);  primals_45 = None
        getitem_58 = native_batch_norm_default_16[0]
        getitem_59 = native_batch_norm_default_16[1]
        getitem_60 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_58);  getitem_58 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_15, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_3 = torch.ops.aten.view.default(convolution_default_20, [128, 2, 128, 1, 1]);  convolution_default_20 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(view_default_3, 1, False);  view_default_3 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(stack_default_3, _softmax_default_3)
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_3, [1]);  mul_tensor_3 = None
        convolution_default_21 = torch.ops.aten.convolution.default(sum_dim_int_list_7, primals_54, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_163, 1);  primals_163 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_166, primals_167, primals_164, primals_165, True, 0.1, 1e-05);  primals_167 = None
        getitem_61 = native_batch_norm_default_17[0]
        getitem_62 = native_batch_norm_default_17[1]
        getitem_63 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_9 = torch.ops.aten.add_.Tensor(getitem_61, relu__default_12);  getitem_61 = None
        relu__default_16 = torch.ops.aten.relu_.default(add__tensor_9);  add__tensor_9 = None
        split_tensor_4 = torch.ops.aten.split.Tensor(relu__default_16, 64, 1)
        getitem_64 = split_tensor_4[0]
        getitem_65 = split_tensor_4[1];  split_tensor_4 = None
        convolution_default_22 = torch.ops.aten.convolution.default(getitem_64, primals_62, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_168, 1);  primals_168 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_171, primals_172, primals_169, primals_170, True, 0.1, 1e-05);  primals_172 = None
        getitem_66 = native_batch_norm_default_18[0]
        getitem_67 = native_batch_norm_default_18[1]
        getitem_68 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_23 = torch.ops.aten.convolution.default(getitem_65, primals_63, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_173, 1);  primals_173 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_176, primals_177, primals_174, primals_175, True, 0.1, 1e-05);  primals_177 = None
        getitem_69 = native_batch_norm_default_19[0]
        getitem_70 = native_batch_norm_default_19[1]
        getitem_71 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        stack_default_4 = torch.ops.aten.stack.default([relu__default_17, relu__default_18], 1)
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(stack_default_4, [1])
        mean_dim_4 = torch.ops.aten.mean.dim(sum_dim_int_list_8, [2, 3], True);  sum_dim_int_list_8 = None
        convolution_default_24 = torch.ops.aten.convolution.default(mean_dim_4, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_56, 1);  primals_56 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_59, primals_55, primals_57, primals_58, True, 0.1, 1e-05);  primals_55 = None
        getitem_72 = native_batch_norm_default_20[0]
        getitem_73 = native_batch_norm_default_20[1]
        getitem_74 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_19, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_4 = torch.ops.aten.view.default(convolution_default_25, [128, 2, 256, 1, 1]);  convolution_default_25 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(view_default_4, 1, False);  view_default_4 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(stack_default_4, _softmax_default_4)
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_4, [1]);  mul_tensor_4 = None
        convolution_default_26 = torch.ops.aten.convolution.default(sum_dim_int_list_9, primals_64, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_178, 1);  primals_178 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_181, primals_182, primals_179, primals_180, True, 0.1, 1e-05);  primals_182 = None
        getitem_75 = native_batch_norm_default_21[0]
        getitem_76 = native_batch_norm_default_21[1]
        getitem_77 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_16, primals_65, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(primals_67, 1);  primals_67 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_70, primals_66, primals_68, primals_69, True, 0.1, 1e-05);  primals_66 = None
        getitem_78 = native_batch_norm_default_22[0]
        getitem_79 = native_batch_norm_default_22[1]
        getitem_80 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_12 = torch.ops.aten.add_.Tensor(getitem_75, getitem_78);  getitem_75 = getitem_78 = None
        relu__default_20 = torch.ops.aten.relu_.default(add__tensor_12);  add__tensor_12 = None
        split_tensor_5 = torch.ops.aten.split.Tensor(relu__default_20, 128, 1)
        getitem_81 = split_tensor_5[0]
        getitem_82 = split_tensor_5[1];  split_tensor_5 = None
        convolution_default_28 = torch.ops.aten.convolution.default(getitem_81, primals_78, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_183, 1);  primals_183 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_186, primals_187, primals_184, primals_185, True, 0.1, 1e-05);  primals_187 = None
        getitem_83 = native_batch_norm_default_23[0]
        getitem_84 = native_batch_norm_default_23[1]
        getitem_85 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_82, primals_79, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_188, 1);  primals_188 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_191, primals_192, primals_189, primals_190, True, 0.1, 1e-05);  primals_192 = None
        getitem_86 = native_batch_norm_default_24[0]
        getitem_87 = native_batch_norm_default_24[1]
        getitem_88 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        stack_default_5 = torch.ops.aten.stack.default([relu__default_21, relu__default_22], 1)
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(stack_default_5, [1])
        mean_dim_5 = torch.ops.aten.mean.dim(sum_dim_int_list_10, [2, 3], True);  sum_dim_int_list_10 = None
        convolution_default_30 = torch.ops.aten.convolution.default(mean_dim_5, primals_76, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_72, 1);  primals_72 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_75, primals_71, primals_73, primals_74, True, 0.1, 1e-05);  primals_71 = None
        getitem_89 = native_batch_norm_default_25[0]
        getitem_90 = native_batch_norm_default_25[1]
        getitem_91 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_23, primals_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_5 = torch.ops.aten.view.default(convolution_default_31, [128, 2, 256, 1, 1]);  convolution_default_31 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(view_default_5, 1, False);  view_default_5 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(stack_default_5, _softmax_default_5)
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_5, [1]);  mul_tensor_5 = None
        convolution_default_32 = torch.ops.aten.convolution.default(sum_dim_int_list_11, primals_80, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_193, 1);  primals_193 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_196, primals_197, primals_194, primals_195, True, 0.1, 1e-05);  primals_197 = None
        getitem_92 = native_batch_norm_default_26[0]
        getitem_93 = native_batch_norm_default_26[1]
        getitem_94 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_14 = torch.ops.aten.add_.Tensor(getitem_92, relu__default_20);  getitem_92 = None
        relu__default_24 = torch.ops.aten.relu_.default(add__tensor_14);  add__tensor_14 = None
        split_tensor_6 = torch.ops.aten.split.Tensor(relu__default_24, 128, 1)
        getitem_95 = split_tensor_6[0]
        getitem_96 = split_tensor_6[1];  split_tensor_6 = None
        convolution_default_33 = torch.ops.aten.convolution.default(getitem_95, primals_88, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_198, 1);  primals_198 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_201, primals_202, primals_199, primals_200, True, 0.1, 1e-05);  primals_202 = None
        getitem_97 = native_batch_norm_default_27[0]
        getitem_98 = native_batch_norm_default_27[1]
        getitem_99 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_97);  getitem_97 = None
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_96, primals_89, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_203, 1);  primals_203 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_206, primals_207, primals_204, primals_205, True, 0.1, 1e-05);  primals_207 = None
        getitem_100 = native_batch_norm_default_28[0]
        getitem_101 = native_batch_norm_default_28[1]
        getitem_102 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_100);  getitem_100 = None
        stack_default_6 = torch.ops.aten.stack.default([relu__default_25, relu__default_26], 1)
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(stack_default_6, [1])
        mean_dim_6 = torch.ops.aten.mean.dim(sum_dim_int_list_12, [2, 3], True);  sum_dim_int_list_12 = None
        convolution_default_35 = torch.ops.aten.convolution.default(mean_dim_6, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_82, 1);  primals_82 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_103 = native_batch_norm_default_29[0]
        getitem_104 = native_batch_norm_default_29[1]
        getitem_105 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_103);  getitem_103 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_27, primals_87, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_6 = torch.ops.aten.view.default(convolution_default_36, [128, 2, 512, 1, 1]);  convolution_default_36 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(view_default_6, 1, False);  view_default_6 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(stack_default_6, _softmax_default_6)
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_6, [1]);  mul_tensor_6 = None
        convolution_default_37 = torch.ops.aten.convolution.default(sum_dim_int_list_13, primals_90, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_208, 1);  primals_208 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_211, primals_212, primals_209, primals_210, True, 0.1, 1e-05);  primals_212 = None
        getitem_106 = native_batch_norm_default_30[0]
        getitem_107 = native_batch_norm_default_30[1]
        getitem_108 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_24, primals_91, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_93, 1);  primals_93 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_96, primals_92, primals_94, primals_95, True, 0.1, 1e-05);  primals_92 = None
        getitem_109 = native_batch_norm_default_31[0]
        getitem_110 = native_batch_norm_default_31[1]
        getitem_111 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_17 = torch.ops.aten.add_.Tensor(getitem_106, getitem_109);  getitem_106 = getitem_109 = None
        relu__default_28 = torch.ops.aten.relu_.default(add__tensor_17);  add__tensor_17 = None
        split_tensor_7 = torch.ops.aten.split.Tensor(relu__default_28, 256, 1)
        getitem_112 = split_tensor_7[0]
        getitem_113 = split_tensor_7[1];  split_tensor_7 = None
        convolution_default_39 = torch.ops.aten.convolution.default(getitem_112, primals_104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_213, 1);  primals_213 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_216, primals_217, primals_214, primals_215, True, 0.1, 1e-05);  primals_217 = None
        getitem_114 = native_batch_norm_default_32[0]
        getitem_115 = native_batch_norm_default_32[1]
        getitem_116 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_113, primals_105, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_218, 1);  primals_218 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_221, primals_222, primals_219, primals_220, True, 0.1, 1e-05);  primals_222 = None
        getitem_117 = native_batch_norm_default_33[0]
        getitem_118 = native_batch_norm_default_33[1]
        getitem_119 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_117);  getitem_117 = None
        stack_default_7 = torch.ops.aten.stack.default([relu__default_29, relu__default_30], 1)
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(stack_default_7, [1])
        mean_dim_7 = torch.ops.aten.mean.dim(sum_dim_int_list_14, [2, 3], True);  sum_dim_int_list_14 = None
        convolution_default_41 = torch.ops.aten.convolution.default(mean_dim_7, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_98, 1);  primals_98 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_101, primals_97, primals_99, primals_100, True, 0.1, 1e-05);  primals_97 = None
        getitem_120 = native_batch_norm_default_34[0]
        getitem_121 = native_batch_norm_default_34[1]
        getitem_122 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_31, primals_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_7 = torch.ops.aten.view.default(convolution_default_42, [128, 2, 512, 1, 1]);  convolution_default_42 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(view_default_7, 1, False);  view_default_7 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(stack_default_7, _softmax_default_7)
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_7, [1]);  mul_tensor_7 = None
        convolution_default_43 = torch.ops.aten.convolution.default(sum_dim_int_list_15, primals_106, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_223, 1);  primals_223 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_226, primals_227, primals_224, primals_225, True, 0.1, 1e-05);  primals_227 = None
        getitem_123 = native_batch_norm_default_35[0]
        getitem_124 = native_batch_norm_default_35[1]
        getitem_125 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_19 = torch.ops.aten.add_.Tensor(getitem_123, relu__default_28);  getitem_123 = None
        relu__default_32 = torch.ops.aten.relu_.default(add__tensor_19);  add__tensor_19 = None
        mean_dim_8 = torch.ops.aten.mean.dim(relu__default_32, [-1, -2], True)
        view_default_8 = torch.ops.aten.view.default(mean_dim_8, [128, 512]);  mean_dim_8 = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default_8, t_default);  primals_7 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default_8);  t_default_2 = view_default_8 = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_9 = torch.ops.aten.view.default(sum_dim_int_list_16, [1000]);  sum_dim_int_list_16 = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_10 = torch.ops.aten.view.default(mm_default, [128, 512, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_10, [128, 512, 7, 7]);  view_default_10 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_36, to_dtype);  le_scalar = new_zeros_default_36 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_43, primals_226, primals_224, primals_225, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  convolution_default_43 = primals_226 = primals_224 = primals_225 = getitem_124 = getitem_125 = None
        getitem_126 = native_batch_norm_backward_default[0]
        getitem_127 = native_batch_norm_backward_default[1]
        getitem_128 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_126, sum_dim_int_list_15, primals_106, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_126 = sum_dim_int_list_15 = primals_106 = None
        getitem_129 = convolution_backward_default[0]
        getitem_130 = convolution_backward_default[1]
        getitem_131 = convolution_backward_default[2];  convolution_backward_default = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(getitem_129, 1);  getitem_129 = None
        expand_default_1 = torch.ops.aten.expand.default(unsqueeze_default, [128, 2, 512, 7, 7]);  unsqueeze_default = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(expand_default_1, stack_default_7);  stack_default_7 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(expand_default_1, _softmax_default_7);  expand_default_1 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_8, [3, 4], True);  mul_tensor_8 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_17, _softmax_default_7, 1, torch.float32);  sum_dim_int_list_17 = _softmax_default_7 = None
        view_default_11 = torch.ops.aten.view.default(_softmax_backward_data_default, [128, 1024, 1, 1]);  _softmax_backward_data_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(view_default_11, relu__default_31, primals_103, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_11 = primals_103 = None
        getitem_132 = convolution_backward_default_1[0]
        getitem_133 = convolution_backward_default_1[1]
        getitem_134 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_132, torch.float32);  getitem_132 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_37, to_dtype_3);  le_scalar_1 = new_zeros_default_37 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_41, primals_101, primals_99, primals_100, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_41 = primals_101 = primals_99 = primals_100 = getitem_121 = getitem_122 = None
        getitem_135 = native_batch_norm_backward_default_1[0]
        getitem_136 = native_batch_norm_backward_default_1[1]
        getitem_137 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_135, mean_dim_7, primals_102, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_135 = mean_dim_7 = primals_102 = None
        getitem_138 = convolution_backward_default_2[0]
        getitem_139 = convolution_backward_default_2[1]
        getitem_140 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_138, [128, 512, 7, 7]);  getitem_138 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(div_scalar_1, 1);  div_scalar_1 = None
        expand_default_3 = torch.ops.aten.expand.default(unsqueeze_default_1, [128, 2, 512, 7, 7]);  unsqueeze_default_1 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_9, expand_default_3);  mul_tensor_9 = expand_default_3 = None
        unbind_int = torch.ops.aten.unbind.int(add_tensor_24, 1);  add_tensor_24 = None
        getitem_141 = unbind_int[0]
        getitem_142 = unbind_int[1];  unbind_int = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_142, torch.float32);  getitem_142 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_38, to_dtype_6);  le_scalar_2 = new_zeros_default_38 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_40, primals_221, primals_219, primals_220, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_40 = primals_221 = primals_219 = primals_220 = getitem_118 = getitem_119 = None
        getitem_143 = native_batch_norm_backward_default_2[0]
        getitem_144 = native_batch_norm_backward_default_2[1]
        getitem_145 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_143, getitem_113, primals_105, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 1, [True, True, False]);  getitem_143 = getitem_113 = primals_105 = None
        getitem_146 = convolution_backward_default_3[0]
        getitem_147 = convolution_backward_default_3[1]
        getitem_148 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_141, torch.float32);  getitem_141 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_39, to_dtype_9);  le_scalar_3 = new_zeros_default_39 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_39, primals_216, primals_214, primals_215, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_39 = primals_216 = primals_214 = primals_215 = getitem_115 = getitem_116 = None
        getitem_149 = native_batch_norm_backward_default_3[0]
        getitem_150 = native_batch_norm_backward_default_3[1]
        getitem_151 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_149, getitem_112, primals_104, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_149 = getitem_112 = primals_104 = None
        getitem_152 = convolution_backward_default_4[0]
        getitem_153 = convolution_backward_default_4[1]
        getitem_154 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        cat_default = torch.ops.aten.cat.default([getitem_152, getitem_146], 1);  getitem_152 = getitem_146 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(to_dtype_2, cat_default);  to_dtype_2 = cat_default = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_25, torch.float32);  add_tensor_25 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_40, to_dtype_12);  le_scalar_4 = new_zeros_default_40 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_38, primals_96, primals_94, primals_95, getitem_110, getitem_111, True, 1e-05, [True, True, True]);  convolution_default_38 = primals_96 = primals_94 = primals_95 = getitem_110 = getitem_111 = None
        getitem_155 = native_batch_norm_backward_default_4[0]
        getitem_156 = native_batch_norm_backward_default_4[1]
        getitem_157 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_155, relu__default_24, primals_91, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_155 = primals_91 = None
        getitem_158 = convolution_backward_default_5[0]
        getitem_159 = convolution_backward_default_5[1]
        getitem_160 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_37, primals_211, primals_209, primals_210, getitem_107, getitem_108, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_37 = primals_211 = primals_209 = primals_210 = getitem_107 = getitem_108 = None
        getitem_161 = native_batch_norm_backward_default_5[0]
        getitem_162 = native_batch_norm_backward_default_5[1]
        getitem_163 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_161, sum_dim_int_list_13, primals_90, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_161 = sum_dim_int_list_13 = primals_90 = None
        getitem_164 = convolution_backward_default_6[0]
        getitem_165 = convolution_backward_default_6[1]
        getitem_166 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(getitem_164, 1);  getitem_164 = None
        expand_default_4 = torch.ops.aten.expand.default(unsqueeze_default_2, [128, 2, 512, 7, 7]);  unsqueeze_default_2 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(expand_default_4, stack_default_6);  stack_default_6 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(expand_default_4, _softmax_default_6);  expand_default_4 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(mul_tensor_10, [3, 4], True);  mul_tensor_10 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_18, _softmax_default_6, 1, torch.float32);  sum_dim_int_list_18 = _softmax_default_6 = None
        view_default_12 = torch.ops.aten.view.default(_softmax_backward_data_default_1, [128, 1024, 1, 1]);  _softmax_backward_data_default_1 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(view_default_12, relu__default_27, primals_87, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_12 = primals_87 = None
        getitem_167 = convolution_backward_default_7[0]
        getitem_168 = convolution_backward_default_7[1]
        getitem_169 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_167, torch.float32);  getitem_167 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_41, to_dtype_15);  le_scalar_5 = new_zeros_default_41 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_35, primals_85, primals_83, primals_84, getitem_104, getitem_105, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_35 = primals_85 = primals_83 = primals_84 = getitem_104 = getitem_105 = None
        getitem_170 = native_batch_norm_backward_default_6[0]
        getitem_171 = native_batch_norm_backward_default_6[1]
        getitem_172 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_170, mean_dim_6, primals_86, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_170 = mean_dim_6 = primals_86 = None
        getitem_173 = convolution_backward_default_8[0]
        getitem_174 = convolution_backward_default_8[1]
        getitem_175 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_173, [128, 512, 7, 7]);  getitem_173 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_5, 49);  expand_default_5 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(div_scalar_2, 1);  div_scalar_2 = None
        expand_default_6 = torch.ops.aten.expand.default(unsqueeze_default_3, [128, 2, 512, 7, 7]);  unsqueeze_default_3 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_11, expand_default_6);  mul_tensor_11 = expand_default_6 = None
        unbind_int_1 = torch.ops.aten.unbind.int(add_tensor_26, 1);  add_tensor_26 = None
        getitem_176 = unbind_int_1[0]
        getitem_177 = unbind_int_1[1];  unbind_int_1 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_177, torch.float32);  getitem_177 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_42, to_dtype_18);  le_scalar_6 = new_zeros_default_42 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_34, primals_206, primals_204, primals_205, getitem_101, getitem_102, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_34 = primals_206 = primals_204 = primals_205 = getitem_101 = getitem_102 = None
        getitem_178 = native_batch_norm_backward_default_7[0]
        getitem_179 = native_batch_norm_backward_default_7[1]
        getitem_180 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_178, getitem_96, primals_89, [0], [2, 2], [2, 2], [2, 2], False, [0, 0], 1, [True, True, False]);  getitem_178 = getitem_96 = primals_89 = None
        getitem_181 = convolution_backward_default_9[0]
        getitem_182 = convolution_backward_default_9[1]
        getitem_183 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_176, torch.float32);  getitem_176 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_43, to_dtype_21);  le_scalar_7 = new_zeros_default_43 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_33, primals_201, primals_199, primals_200, getitem_98, getitem_99, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_33 = primals_201 = primals_199 = primals_200 = getitem_98 = getitem_99 = None
        getitem_184 = native_batch_norm_backward_default_8[0]
        getitem_185 = native_batch_norm_backward_default_8[1]
        getitem_186 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_184, getitem_95, primals_88, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_184 = getitem_95 = primals_88 = None
        getitem_187 = convolution_backward_default_10[0]
        getitem_188 = convolution_backward_default_10[1]
        getitem_189 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        cat_default_1 = torch.ops.aten.cat.default([getitem_187, getitem_181], 1);  getitem_187 = getitem_181 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_158, cat_default_1);  getitem_158 = cat_default_1 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_27, torch.float32);  add_tensor_27 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_44, to_dtype_24);  le_scalar_8 = new_zeros_default_44 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_32, primals_196, primals_194, primals_195, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  convolution_default_32 = primals_196 = primals_194 = primals_195 = getitem_93 = getitem_94 = None
        getitem_190 = native_batch_norm_backward_default_9[0]
        getitem_191 = native_batch_norm_backward_default_9[1]
        getitem_192 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_190, sum_dim_int_list_11, primals_80, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_190 = sum_dim_int_list_11 = primals_80 = None
        getitem_193 = convolution_backward_default_11[0]
        getitem_194 = convolution_backward_default_11[1]
        getitem_195 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(getitem_193, 1);  getitem_193 = None
        expand_default_7 = torch.ops.aten.expand.default(unsqueeze_default_4, [128, 2, 256, 14, 14]);  unsqueeze_default_4 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(expand_default_7, stack_default_5);  stack_default_5 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(expand_default_7, _softmax_default_5);  expand_default_7 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(mul_tensor_12, [3, 4], True);  mul_tensor_12 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_19, _softmax_default_5, 1, torch.float32);  sum_dim_int_list_19 = _softmax_default_5 = None
        view_default_13 = torch.ops.aten.view.default(_softmax_backward_data_default_2, [128, 512, 1, 1]);  _softmax_backward_data_default_2 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(view_default_13, relu__default_23, primals_77, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_13 = primals_77 = None
        getitem_196 = convolution_backward_default_12[0]
        getitem_197 = convolution_backward_default_12[1]
        getitem_198 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_196, torch.float32);  getitem_196 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_45, to_dtype_27);  le_scalar_9 = new_zeros_default_45 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_30, primals_75, primals_73, primals_74, getitem_90, getitem_91, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_30 = primals_75 = primals_73 = primals_74 = getitem_90 = getitem_91 = None
        getitem_199 = native_batch_norm_backward_default_10[0]
        getitem_200 = native_batch_norm_backward_default_10[1]
        getitem_201 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_199, mean_dim_5, primals_76, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_199 = mean_dim_5 = primals_76 = None
        getitem_202 = convolution_backward_default_13[0]
        getitem_203 = convolution_backward_default_13[1]
        getitem_204 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_202, [128, 256, 14, 14]);  getitem_202 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_8, 196);  expand_default_8 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(div_scalar_3, 1);  div_scalar_3 = None
        expand_default_9 = torch.ops.aten.expand.default(unsqueeze_default_5, [128, 2, 256, 14, 14]);  unsqueeze_default_5 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(mul_tensor_13, expand_default_9);  mul_tensor_13 = expand_default_9 = None
        unbind_int_2 = torch.ops.aten.unbind.int(add_tensor_28, 1);  add_tensor_28 = None
        getitem_205 = unbind_int_2[0]
        getitem_206 = unbind_int_2[1];  unbind_int_2 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_206, torch.float32);  getitem_206 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_46, to_dtype_30);  le_scalar_10 = new_zeros_default_46 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_29, primals_191, primals_189, primals_190, getitem_87, getitem_88, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_29 = primals_191 = primals_189 = primals_190 = getitem_87 = getitem_88 = None
        getitem_207 = native_batch_norm_backward_default_11[0]
        getitem_208 = native_batch_norm_backward_default_11[1]
        getitem_209 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_207, getitem_82, primals_79, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 1, [True, True, False]);  getitem_207 = getitem_82 = primals_79 = None
        getitem_210 = convolution_backward_default_14[0]
        getitem_211 = convolution_backward_default_14[1]
        getitem_212 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_205, torch.float32);  getitem_205 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_47, to_dtype_33);  le_scalar_11 = new_zeros_default_47 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_28, primals_186, primals_184, primals_185, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_28 = primals_186 = primals_184 = primals_185 = getitem_84 = getitem_85 = None
        getitem_213 = native_batch_norm_backward_default_12[0]
        getitem_214 = native_batch_norm_backward_default_12[1]
        getitem_215 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_213, getitem_81, primals_78, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_213 = getitem_81 = primals_78 = None
        getitem_216 = convolution_backward_default_15[0]
        getitem_217 = convolution_backward_default_15[1]
        getitem_218 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        cat_default_2 = torch.ops.aten.cat.default([getitem_216, getitem_210], 1);  getitem_216 = getitem_210 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(to_dtype_26, cat_default_2);  to_dtype_26 = cat_default_2 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_29, torch.float32);  add_tensor_29 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_48, to_dtype_36);  le_scalar_12 = new_zeros_default_48 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_27, primals_70, primals_68, primals_69, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  convolution_default_27 = primals_70 = primals_68 = primals_69 = getitem_79 = getitem_80 = None
        getitem_219 = native_batch_norm_backward_default_13[0]
        getitem_220 = native_batch_norm_backward_default_13[1]
        getitem_221 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_219, relu__default_16, primals_65, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_219 = primals_65 = None
        getitem_222 = convolution_backward_default_16[0]
        getitem_223 = convolution_backward_default_16[1]
        getitem_224 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_26, primals_181, primals_179, primals_180, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_26 = primals_181 = primals_179 = primals_180 = getitem_76 = getitem_77 = None
        getitem_225 = native_batch_norm_backward_default_14[0]
        getitem_226 = native_batch_norm_backward_default_14[1]
        getitem_227 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_225, sum_dim_int_list_9, primals_64, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_225 = sum_dim_int_list_9 = primals_64 = None
        getitem_228 = convolution_backward_default_17[0]
        getitem_229 = convolution_backward_default_17[1]
        getitem_230 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(getitem_228, 1);  getitem_228 = None
        expand_default_10 = torch.ops.aten.expand.default(unsqueeze_default_6, [128, 2, 256, 14, 14]);  unsqueeze_default_6 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(expand_default_10, stack_default_4);  stack_default_4 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(expand_default_10, _softmax_default_4);  expand_default_10 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(mul_tensor_14, [3, 4], True);  mul_tensor_14 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_20, _softmax_default_4, 1, torch.float32);  sum_dim_int_list_20 = _softmax_default_4 = None
        view_default_14 = torch.ops.aten.view.default(_softmax_backward_data_default_3, [128, 512, 1, 1]);  _softmax_backward_data_default_3 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(view_default_14, relu__default_19, primals_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_14 = primals_61 = None
        getitem_231 = convolution_backward_default_18[0]
        getitem_232 = convolution_backward_default_18[1]
        getitem_233 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_231, torch.float32);  getitem_231 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_49, to_dtype_39);  le_scalar_13 = new_zeros_default_49 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_24, primals_59, primals_57, primals_58, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_24 = primals_59 = primals_57 = primals_58 = getitem_73 = getitem_74 = None
        getitem_234 = native_batch_norm_backward_default_15[0]
        getitem_235 = native_batch_norm_backward_default_15[1]
        getitem_236 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_234, mean_dim_4, primals_60, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_234 = mean_dim_4 = primals_60 = None
        getitem_237 = convolution_backward_default_19[0]
        getitem_238 = convolution_backward_default_19[1]
        getitem_239 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_237, [128, 256, 14, 14]);  getitem_237 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_11, 196);  expand_default_11 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(div_scalar_4, 1);  div_scalar_4 = None
        expand_default_12 = torch.ops.aten.expand.default(unsqueeze_default_7, [128, 2, 256, 14, 14]);  unsqueeze_default_7 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_15, expand_default_12);  mul_tensor_15 = expand_default_12 = None
        unbind_int_3 = torch.ops.aten.unbind.int(add_tensor_30, 1);  add_tensor_30 = None
        getitem_240 = unbind_int_3[0]
        getitem_241 = unbind_int_3[1];  unbind_int_3 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_241, torch.float32);  getitem_241 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_50, to_dtype_42);  le_scalar_14 = new_zeros_default_50 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_23, primals_176, primals_174, primals_175, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_23 = primals_176 = primals_174 = primals_175 = getitem_70 = getitem_71 = None
        getitem_242 = native_batch_norm_backward_default_16[0]
        getitem_243 = native_batch_norm_backward_default_16[1]
        getitem_244 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_242, getitem_65, primals_63, [0], [2, 2], [2, 2], [2, 2], False, [0, 0], 1, [True, True, False]);  getitem_242 = getitem_65 = primals_63 = None
        getitem_245 = convolution_backward_default_20[0]
        getitem_246 = convolution_backward_default_20[1]
        getitem_247 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_240, torch.float32);  getitem_240 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_51, to_dtype_45);  le_scalar_15 = new_zeros_default_51 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_22, primals_171, primals_169, primals_170, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_22 = primals_171 = primals_169 = primals_170 = getitem_67 = getitem_68 = None
        getitem_248 = native_batch_norm_backward_default_17[0]
        getitem_249 = native_batch_norm_backward_default_17[1]
        getitem_250 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_248, getitem_64, primals_62, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_248 = getitem_64 = primals_62 = None
        getitem_251 = convolution_backward_default_21[0]
        getitem_252 = convolution_backward_default_21[1]
        getitem_253 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        cat_default_3 = torch.ops.aten.cat.default([getitem_251, getitem_245], 1);  getitem_251 = getitem_245 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(getitem_222, cat_default_3);  getitem_222 = cat_default_3 = None
        to_dtype_48 = torch.ops.aten.to.dtype(add_tensor_31, torch.float32);  add_tensor_31 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_52, to_dtype_48);  le_scalar_16 = new_zeros_default_52 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_21, primals_166, primals_164, primals_165, getitem_62, getitem_63, True, 1e-05, [True, True, True]);  convolution_default_21 = primals_166 = primals_164 = primals_165 = getitem_62 = getitem_63 = None
        getitem_254 = native_batch_norm_backward_default_18[0]
        getitem_255 = native_batch_norm_backward_default_18[1]
        getitem_256 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_254, sum_dim_int_list_7, primals_54, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_254 = sum_dim_int_list_7 = primals_54 = None
        getitem_257 = convolution_backward_default_22[0]
        getitem_258 = convolution_backward_default_22[1]
        getitem_259 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(getitem_257, 1);  getitem_257 = None
        expand_default_13 = torch.ops.aten.expand.default(unsqueeze_default_8, [128, 2, 128, 28, 28]);  unsqueeze_default_8 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(expand_default_13, stack_default_3);  stack_default_3 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(expand_default_13, _softmax_default_3);  expand_default_13 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(mul_tensor_16, [3, 4], True);  mul_tensor_16 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_21, _softmax_default_3, 1, torch.float32);  sum_dim_int_list_21 = _softmax_default_3 = None
        view_default_15 = torch.ops.aten.view.default(_softmax_backward_data_default_4, [128, 256, 1, 1]);  _softmax_backward_data_default_4 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(view_default_15, relu__default_15, primals_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_15 = primals_51 = None
        getitem_260 = convolution_backward_default_23[0]
        getitem_261 = convolution_backward_default_23[1]
        getitem_262 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_260, torch.float32);  getitem_260 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_53, to_dtype_51);  le_scalar_17 = new_zeros_default_53 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_19, primals_49, primals_47, primals_48, getitem_59, getitem_60, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_19 = primals_49 = primals_47 = primals_48 = getitem_59 = getitem_60 = None
        getitem_263 = native_batch_norm_backward_default_19[0]
        getitem_264 = native_batch_norm_backward_default_19[1]
        getitem_265 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_263, mean_dim_3, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_263 = mean_dim_3 = primals_50 = None
        getitem_266 = convolution_backward_default_24[0]
        getitem_267 = convolution_backward_default_24[1]
        getitem_268 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        expand_default_14 = torch.ops.aten.expand.default(getitem_266, [128, 128, 28, 28]);  getitem_266 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_14, 784);  expand_default_14 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(div_scalar_5, 1);  div_scalar_5 = None
        expand_default_15 = torch.ops.aten.expand.default(unsqueeze_default_9, [128, 2, 128, 28, 28]);  unsqueeze_default_9 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_17, expand_default_15);  mul_tensor_17 = expand_default_15 = None
        unbind_int_4 = torch.ops.aten.unbind.int(add_tensor_32, 1);  add_tensor_32 = None
        getitem_269 = unbind_int_4[0]
        getitem_270 = unbind_int_4[1];  unbind_int_4 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_270, torch.float32);  getitem_270 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_54, to_dtype_54);  le_scalar_18 = new_zeros_default_54 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_18, primals_161, primals_159, primals_160, getitem_56, getitem_57, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_18 = primals_161 = primals_159 = primals_160 = getitem_56 = getitem_57 = None
        getitem_271 = native_batch_norm_backward_default_20[0]
        getitem_272 = native_batch_norm_backward_default_20[1]
        getitem_273 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_271, getitem_51, primals_53, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 1, [True, True, False]);  getitem_271 = getitem_51 = primals_53 = None
        getitem_274 = convolution_backward_default_25[0]
        getitem_275 = convolution_backward_default_25[1]
        getitem_276 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_269, torch.float32);  getitem_269 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_55, to_dtype_57);  le_scalar_19 = new_zeros_default_55 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_17, primals_156, primals_154, primals_155, getitem_53, getitem_54, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_17 = primals_156 = primals_154 = primals_155 = getitem_53 = getitem_54 = None
        getitem_277 = native_batch_norm_backward_default_21[0]
        getitem_278 = native_batch_norm_backward_default_21[1]
        getitem_279 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_277, getitem_50, primals_52, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_277 = getitem_50 = primals_52 = None
        getitem_280 = convolution_backward_default_26[0]
        getitem_281 = convolution_backward_default_26[1]
        getitem_282 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        cat_default_4 = torch.ops.aten.cat.default([getitem_280, getitem_274], 1);  getitem_280 = getitem_274 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(to_dtype_50, cat_default_4);  to_dtype_50 = cat_default_4 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_33, torch.float32);  add_tensor_33 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_56, to_dtype_60);  le_scalar_20 = new_zeros_default_56 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_16, primals_44, primals_42, primals_43, getitem_48, getitem_49, True, 1e-05, [True, True, True]);  convolution_default_16 = primals_44 = primals_42 = primals_43 = getitem_48 = getitem_49 = None
        getitem_283 = native_batch_norm_backward_default_22[0]
        getitem_284 = native_batch_norm_backward_default_22[1]
        getitem_285 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_283, relu__default_8, primals_39, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_283 = primals_39 = None
        getitem_286 = convolution_backward_default_27[0]
        getitem_287 = convolution_backward_default_27[1]
        getitem_288 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_15, primals_151, primals_149, primals_150, getitem_45, getitem_46, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_15 = primals_151 = primals_149 = primals_150 = getitem_45 = getitem_46 = None
        getitem_289 = native_batch_norm_backward_default_23[0]
        getitem_290 = native_batch_norm_backward_default_23[1]
        getitem_291 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_289, sum_dim_int_list_5, primals_38, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_289 = sum_dim_int_list_5 = primals_38 = None
        getitem_292 = convolution_backward_default_28[0]
        getitem_293 = convolution_backward_default_28[1]
        getitem_294 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(getitem_292, 1);  getitem_292 = None
        expand_default_16 = torch.ops.aten.expand.default(unsqueeze_default_10, [128, 2, 128, 28, 28]);  unsqueeze_default_10 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(expand_default_16, stack_default_2);  stack_default_2 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(expand_default_16, _softmax_default_2);  expand_default_16 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(mul_tensor_18, [3, 4], True);  mul_tensor_18 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_22, _softmax_default_2, 1, torch.float32);  sum_dim_int_list_22 = _softmax_default_2 = None
        view_default_16 = torch.ops.aten.view.default(_softmax_backward_data_default_5, [128, 256, 1, 1]);  _softmax_backward_data_default_5 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(view_default_16, relu__default_11, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_16 = primals_35 = None
        getitem_295 = convolution_backward_default_29[0]
        getitem_296 = convolution_backward_default_29[1]
        getitem_297 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_295, torch.float32);  getitem_295 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_57, to_dtype_63);  le_scalar_21 = new_zeros_default_57 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_13, primals_33, primals_31, primals_32, getitem_42, getitem_43, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_13 = primals_33 = primals_31 = primals_32 = getitem_42 = getitem_43 = None
        getitem_298 = native_batch_norm_backward_default_24[0]
        getitem_299 = native_batch_norm_backward_default_24[1]
        getitem_300 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_298, mean_dim_2, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_298 = mean_dim_2 = primals_34 = None
        getitem_301 = convolution_backward_default_30[0]
        getitem_302 = convolution_backward_default_30[1]
        getitem_303 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        expand_default_17 = torch.ops.aten.expand.default(getitem_301, [128, 128, 28, 28]);  getitem_301 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_17, 784);  expand_default_17 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(div_scalar_6, 1);  div_scalar_6 = None
        expand_default_18 = torch.ops.aten.expand.default(unsqueeze_default_11, [128, 2, 128, 28, 28]);  unsqueeze_default_11 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(mul_tensor_19, expand_default_18);  mul_tensor_19 = expand_default_18 = None
        unbind_int_5 = torch.ops.aten.unbind.int(add_tensor_34, 1);  add_tensor_34 = None
        getitem_304 = unbind_int_5[0]
        getitem_305 = unbind_int_5[1];  unbind_int_5 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_305, torch.float32);  getitem_305 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_58, to_dtype_66);  le_scalar_22 = new_zeros_default_58 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_12, primals_146, primals_144, primals_145, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_12 = primals_146 = primals_144 = primals_145 = getitem_39 = getitem_40 = None
        getitem_306 = native_batch_norm_backward_default_25[0]
        getitem_307 = native_batch_norm_backward_default_25[1]
        getitem_308 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_306, getitem_34, primals_37, [0], [2, 2], [2, 2], [2, 2], False, [0, 0], 1, [True, True, False]);  getitem_306 = getitem_34 = primals_37 = None
        getitem_309 = convolution_backward_default_31[0]
        getitem_310 = convolution_backward_default_31[1]
        getitem_311 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_304, torch.float32);  getitem_304 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_59, to_dtype_69);  le_scalar_23 = new_zeros_default_59 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_11, primals_141, primals_139, primals_140, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_11 = primals_141 = primals_139 = primals_140 = getitem_36 = getitem_37 = None
        getitem_312 = native_batch_norm_backward_default_26[0]
        getitem_313 = native_batch_norm_backward_default_26[1]
        getitem_314 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_312, getitem_33, primals_36, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_312 = getitem_33 = primals_36 = None
        getitem_315 = convolution_backward_default_32[0]
        getitem_316 = convolution_backward_default_32[1]
        getitem_317 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        cat_default_5 = torch.ops.aten.cat.default([getitem_315, getitem_309], 1);  getitem_315 = getitem_309 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_286, cat_default_5);  getitem_286 = cat_default_5 = None
        to_dtype_72 = torch.ops.aten.to.dtype(add_tensor_35, torch.float32);  add_tensor_35 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_60, to_dtype_72);  le_scalar_24 = new_zeros_default_60 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_10, primals_136, primals_134, primals_135, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  convolution_default_10 = primals_136 = primals_134 = primals_135 = getitem_31 = getitem_32 = None
        getitem_318 = native_batch_norm_backward_default_27[0]
        getitem_319 = native_batch_norm_backward_default_27[1]
        getitem_320 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_318, sum_dim_int_list_3, primals_28, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_318 = sum_dim_int_list_3 = primals_28 = None
        getitem_321 = convolution_backward_default_33[0]
        getitem_322 = convolution_backward_default_33[1]
        getitem_323 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(getitem_321, 1);  getitem_321 = None
        expand_default_19 = torch.ops.aten.expand.default(unsqueeze_default_12, [128, 2, 64, 56, 56]);  unsqueeze_default_12 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(expand_default_19, stack_default_1);  stack_default_1 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(expand_default_19, _softmax_default_1);  expand_default_19 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(mul_tensor_20, [3, 4], True);  mul_tensor_20 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_23, _softmax_default_1, 1, torch.float32);  sum_dim_int_list_23 = _softmax_default_1 = None
        view_default_17 = torch.ops.aten.view.default(_softmax_backward_data_default_6, [128, 128, 1, 1]);  _softmax_backward_data_default_6 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(view_default_17, relu__default_7, primals_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_17 = primals_25 = None
        getitem_324 = convolution_backward_default_34[0]
        getitem_325 = convolution_backward_default_34[1]
        getitem_326 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_324, torch.float32);  getitem_324 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_61, to_dtype_75);  le_scalar_25 = new_zeros_default_61 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_8, primals_23, primals_21, primals_22, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_8 = primals_23 = primals_21 = primals_22 = getitem_28 = getitem_29 = None
        getitem_327 = native_batch_norm_backward_default_28[0]
        getitem_328 = native_batch_norm_backward_default_28[1]
        getitem_329 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_327, mean_dim_1, primals_24, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_327 = mean_dim_1 = primals_24 = None
        getitem_330 = convolution_backward_default_35[0]
        getitem_331 = convolution_backward_default_35[1]
        getitem_332 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        expand_default_20 = torch.ops.aten.expand.default(getitem_330, [128, 64, 56, 56]);  getitem_330 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_20, 3136);  expand_default_20 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(div_scalar_7, 1);  div_scalar_7 = None
        expand_default_21 = torch.ops.aten.expand.default(unsqueeze_default_13, [128, 2, 64, 56, 56]);  unsqueeze_default_13 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(mul_tensor_21, expand_default_21);  mul_tensor_21 = expand_default_21 = None
        unbind_int_6 = torch.ops.aten.unbind.int(add_tensor_36, 1);  add_tensor_36 = None
        getitem_333 = unbind_int_6[0]
        getitem_334 = unbind_int_6[1];  unbind_int_6 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_334, torch.float32);  getitem_334 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_62, to_dtype_78);  le_scalar_26 = new_zeros_default_62 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_7, primals_131, primals_129, primals_130, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_7 = primals_131 = primals_129 = primals_130 = getitem_25 = getitem_26 = None
        getitem_335 = native_batch_norm_backward_default_29[0]
        getitem_336 = native_batch_norm_backward_default_29[1]
        getitem_337 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_335, getitem_20, primals_27, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 1, [True, True, False]);  getitem_335 = getitem_20 = primals_27 = None
        getitem_338 = convolution_backward_default_36[0]
        getitem_339 = convolution_backward_default_36[1]
        getitem_340 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_333, torch.float32);  getitem_333 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_63, to_dtype_81);  le_scalar_27 = new_zeros_default_63 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_6, primals_126, primals_124, primals_125, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_6 = primals_126 = primals_124 = primals_125 = getitem_22 = getitem_23 = None
        getitem_341 = native_batch_norm_backward_default_30[0]
        getitem_342 = native_batch_norm_backward_default_30[1]
        getitem_343 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_341, getitem_19, primals_26, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_341 = getitem_19 = primals_26 = None
        getitem_344 = convolution_backward_default_37[0]
        getitem_345 = convolution_backward_default_37[1]
        getitem_346 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        cat_default_6 = torch.ops.aten.cat.default([getitem_344, getitem_338], 1);  getitem_344 = getitem_338 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(to_dtype_74, cat_default_6);  to_dtype_74 = cat_default_6 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_37, torch.float32);  add_tensor_37 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_64, to_dtype_84);  le_scalar_28 = new_zeros_default_64 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_5, primals_121, primals_119, primals_120, getitem_17, getitem_18, True, 1e-05, [True, True, True]);  convolution_default_5 = primals_121 = primals_119 = primals_120 = getitem_17 = getitem_18 = None
        getitem_347 = native_batch_norm_backward_default_31[0]
        getitem_348 = native_batch_norm_backward_default_31[1]
        getitem_349 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_347, sum_dim_int_list_1, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_347 = sum_dim_int_list_1 = primals_18 = None
        getitem_350 = convolution_backward_default_38[0]
        getitem_351 = convolution_backward_default_38[1]
        getitem_352 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(getitem_350, 1);  getitem_350 = None
        expand_default_22 = torch.ops.aten.expand.default(unsqueeze_default_14, [128, 2, 64, 56, 56]);  unsqueeze_default_14 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(expand_default_22, stack_default);  stack_default = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(expand_default_22, _softmax_default);  expand_default_22 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(mul_tensor_22, [3, 4], True);  mul_tensor_22 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(sum_dim_int_list_24, _softmax_default, 1, torch.float32);  sum_dim_int_list_24 = _softmax_default = None
        view_default_18 = torch.ops.aten.view.default(_softmax_backward_data_default_7, [128, 128, 1, 1]);  _softmax_backward_data_default_7 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(view_default_18, relu__default_3, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_18 = primals_15 = None
        getitem_353 = convolution_backward_default_39[0]
        getitem_354 = convolution_backward_default_39[1]
        getitem_355 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_353, torch.float32);  getitem_353 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_65, to_dtype_87);  le_scalar_29 = new_zeros_default_65 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_3, primals_13, primals_11, primals_12, getitem_14, getitem_15, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_3 = primals_13 = primals_11 = primals_12 = getitem_14 = getitem_15 = None
        getitem_356 = native_batch_norm_backward_default_32[0]
        getitem_357 = native_batch_norm_backward_default_32[1]
        getitem_358 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_356, mean_dim, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_356 = mean_dim = primals_14 = None
        getitem_359 = convolution_backward_default_40[0]
        getitem_360 = convolution_backward_default_40[1]
        getitem_361 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        expand_default_23 = torch.ops.aten.expand.default(getitem_359, [128, 64, 56, 56]);  getitem_359 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_23, 3136);  expand_default_23 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(div_scalar_8, 1);  div_scalar_8 = None
        expand_default_24 = torch.ops.aten.expand.default(unsqueeze_default_15, [128, 2, 64, 56, 56]);  unsqueeze_default_15 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_23, expand_default_24);  mul_tensor_23 = expand_default_24 = None
        unbind_int_7 = torch.ops.aten.unbind.int(add_tensor_38, 1);  add_tensor_38 = None
        getitem_362 = unbind_int_7[0]
        getitem_363 = unbind_int_7[1];  unbind_int_7 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_363, torch.float32);  getitem_363 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_66, to_dtype_90);  le_scalar_30 = new_zeros_default_66 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_2, primals_116, primals_114, primals_115, getitem_11, getitem_12, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_2 = primals_116 = primals_114 = primals_115 = getitem_11 = getitem_12 = None
        getitem_364 = native_batch_norm_backward_default_33[0]
        getitem_365 = native_batch_norm_backward_default_33[1]
        getitem_366 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_364, getitem_6, primals_17, [0], [1, 1], [2, 2], [2, 2], False, [0, 0], 1, [True, True, False]);  getitem_364 = getitem_6 = primals_17 = None
        getitem_367 = convolution_backward_default_41[0]
        getitem_368 = convolution_backward_default_41[1]
        getitem_369 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_362, torch.float32);  getitem_362 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_67, to_dtype_93);  le_scalar_31 = new_zeros_default_67 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_1, primals_111, primals_109, primals_110, getitem_8, getitem_9, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_1 = primals_111 = primals_109 = primals_110 = getitem_8 = getitem_9 = None
        getitem_370 = native_batch_norm_backward_default_34[0]
        getitem_371 = native_batch_norm_backward_default_34[1]
        getitem_372 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_370, getitem_5, primals_16, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_370 = getitem_5 = primals_16 = None
        getitem_373 = convolution_backward_default_42[0]
        getitem_374 = convolution_backward_default_42[1]
        getitem_375 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        cat_default_7 = torch.ops.aten.cat.default([getitem_373, getitem_367], 1);  getitem_373 = getitem_367 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(to_dtype_86, cat_default_7);  to_dtype_86 = cat_default_7 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_39, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  add_tensor_39 = getitem_4 = None
        to_dtype_96 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_68, to_dtype_96);  le_scalar_32 = new_zeros_default_68 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default, primals_5, primals_3, primals_4, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default = primals_5 = primals_3 = primals_4 = getitem_1 = getitem_2 = None
        getitem_376 = native_batch_norm_backward_default_35[0]
        getitem_377 = native_batch_norm_backward_default_35[1]
        getitem_378 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_376, primals_107, primals_6, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_376 = primals_107 = primals_6 = None
        getitem_379 = convolution_backward_default_43[0]
        getitem_380 = convolution_backward_default_43[1]
        getitem_381 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_23, getitem_378, None, None, None, getitem_377, getitem_380, view_default_9, t_default_4, getitem_358, None, None, None, getitem_357, getitem_360, getitem_354, getitem_374, getitem_368, getitem_351, getitem_329, None, None, None, getitem_328, getitem_331, getitem_325, getitem_345, getitem_339, getitem_322, getitem_300, None, None, None, getitem_299, getitem_302, getitem_296, getitem_316, getitem_310, getitem_293, getitem_287, getitem_285, None, None, None, getitem_284, getitem_265, None, None, None, getitem_264, getitem_267, getitem_261, getitem_281, getitem_275, getitem_258, getitem_236, None, None, None, getitem_235, getitem_238, getitem_232, getitem_252, getitem_246, getitem_229, getitem_223, getitem_221, None, None, None, getitem_220, getitem_201, None, None, None, getitem_200, getitem_203, getitem_197, getitem_217, getitem_211, getitem_194, getitem_172, None, None, None, getitem_171, getitem_174, getitem_168, getitem_188, getitem_182, getitem_165, getitem_159, getitem_157, None, None, None, getitem_156, getitem_137, None, None, None, getitem_136, getitem_139, getitem_133, getitem_153, getitem_147, getitem_130, None, None, None, None, getitem_371, getitem_372, None, None, None, getitem_365, getitem_366, None, None, None, getitem_348, getitem_349, None, None, None, getitem_342, getitem_343, None, None, None, getitem_336, getitem_337, None, None, None, getitem_319, getitem_320, None, None, None, getitem_313, getitem_314, None, None, None, getitem_307, getitem_308, None, None, None, getitem_290, getitem_291, None, None, None, getitem_278, getitem_279, None, None, None, getitem_272, getitem_273, None, None, None, getitem_255, getitem_256, None, None, None, getitem_249, getitem_250, None, None, None, getitem_243, getitem_244, None, None, None, getitem_226, getitem_227, None, None, None, getitem_214, getitem_215, None, None, None, getitem_208, getitem_209, None, None, None, getitem_191, getitem_192, None, None, None, getitem_185, getitem_186, None, None, None, getitem_179, getitem_180, None, None, None, getitem_162, getitem_163, None, None, None, getitem_150, getitem_151, None, None, None, getitem_144, getitem_145, None, None, None, getitem_127, getitem_128]
        
