
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/skresnet18/skresnet18_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227):
        convolution_default = torch.ops.aten.convolution.default(primals_107, primals_6, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        split_tensor = torch.ops.aten.split.Tensor(getitem_3, 32, 1)
        getitem_5 = split_tensor[0]
        getitem_6 = split_tensor[1];  split_tensor = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_5, primals_16, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_108, 1);  primals_108 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_111, primals_112, primals_109, primals_110, True, 0.1, 1e-05);  primals_112 = None
        getitem_7 = native_batch_norm_default_1[0]
        getitem_8 = native_batch_norm_default_1[1]
        getitem_9 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_7);  getitem_7 = None
        convolution_default_2 = torch.ops.aten.convolution.default(getitem_6, primals_17, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_113, 1);  primals_113 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_116, primals_117, primals_114, primals_115, True, 0.1, 1e-05);  primals_117 = None
        getitem_10 = native_batch_norm_default_2[0]
        getitem_11 = native_batch_norm_default_2[1]
        getitem_12 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_10);  getitem_10 = None
        stack_default = torch.ops.aten.stack.default([relu__default_1, relu__default_2], 1)
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(stack_default, [1])
        mean_dim = torch.ops.aten.mean.dim(sum_dim_int_list, [2, 3], True);  sum_dim_int_list = None
        convolution_default_3 = torch.ops.aten.convolution.default(mean_dim, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_13, primals_9, primals_11, primals_12, True, 0.1, 1e-05);  primals_9 = None
        getitem_13 = native_batch_norm_default_3[0]
        getitem_14 = native_batch_norm_default_3[1]
        getitem_15 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_13);  getitem_13 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default = torch.ops.aten.view.default(convolution_default_4, [128, 2, 64, 1, 1]);  convolution_default_4 = None
        _softmax_default = torch.ops.aten._softmax.default(view_default, 1, False);  view_default = None
        mul_tensor = torch.ops.aten.mul.Tensor(stack_default, _softmax_default)
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor, [1]);  mul_tensor = None
        convolution_default_5 = torch.ops.aten.convolution.default(sum_dim_int_list_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_118, 1);  primals_118 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_121, primals_122, primals_119, primals_120, True, 0.1, 1e-05);  primals_122 = None
        getitem_16 = native_batch_norm_default_4[0]
        getitem_17 = native_batch_norm_default_4[1]
        getitem_18 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        add__tensor_2 = torch.ops.aten.add_.Tensor(getitem_16, getitem_3);  getitem_16 = getitem_3 = None
        relu__default_4 = torch.ops.aten.relu_.default(add__tensor_2);  add__tensor_2 = None
        split_tensor_1 = torch.ops.aten.split.Tensor(relu__default_4, 32, 1)
        getitem_19 = split_tensor_1[0]
        getitem_20 = split_tensor_1[1];  split_tensor_1 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_19, primals_26, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_123, 1);  primals_123 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_126, primals_127, primals_124, primals_125, True, 0.1, 1e-05);  primals_127 = None
        getitem_21 = native_batch_norm_default_5[0]
        getitem_22 = native_batch_norm_default_5[1]
        getitem_23 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_20, primals_27, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_128, 1);  primals_128 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_131, primals_132, primals_129, primals_130, True, 0.1, 1e-05);  primals_132 = None
        getitem_24 = native_batch_norm_default_6[0]
        getitem_25 = native_batch_norm_default_6[1]
        getitem_26 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        stack_default_1 = torch.ops.aten.stack.default([relu__default_5, relu__default_6], 1)
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(stack_default_1, [1])
        mean_dim_1 = torch.ops.aten.mean.dim(sum_dim_int_list_2, [2, 3], True);  sum_dim_int_list_2 = None
        convolution_default_8 = torch.ops.aten.convolution.default(mean_dim_1, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_23, primals_19, primals_21, primals_22, True, 0.1, 1e-05);  primals_19 = None
        getitem_27 = native_batch_norm_default_7[0]
        getitem_28 = native_batch_norm_default_7[1]
        getitem_29 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, primals_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_1 = torch.ops.aten.view.default(convolution_default_9, [128, 2, 64, 1, 1]);  convolution_default_9 = None
        _softmax_default_1 = torch.ops.aten._softmax.default(view_default_1, 1, False);  view_default_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(stack_default_1, _softmax_default_1)
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_1, [1]);  mul_tensor_1 = None
        convolution_default_10 = torch.ops.aten.convolution.default(sum_dim_int_list_3, primals_28, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_133, 1);  primals_133 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_136, primals_137, primals_134, primals_135, True, 0.1, 1e-05);  primals_137 = None
        getitem_30 = native_batch_norm_default_8[0]
        getitem_31 = native_batch_norm_default_8[1]
        getitem_32 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add__tensor_4 = torch.ops.aten.add_.Tensor(getitem_30, relu__default_4);  getitem_30 = None
        relu__default_8 = torch.ops.aten.relu_.default(add__tensor_4);  add__tensor_4 = None
        split_tensor_2 = torch.ops.aten.split.Tensor(relu__default_8, 32, 1)
        getitem_33 = split_tensor_2[0]
        getitem_34 = split_tensor_2[1];  split_tensor_2 = None
        convolution_default_11 = torch.ops.aten.convolution.default(getitem_33, primals_36, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_138, 1);  primals_138 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_141, primals_142, primals_139, primals_140, True, 0.1, 1e-05);  primals_142 = None
        getitem_35 = native_batch_norm_default_9[0]
        getitem_36 = native_batch_norm_default_9[1]
        getitem_37 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_12 = torch.ops.aten.convolution.default(getitem_34, primals_37, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_143, 1);  primals_143 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_146, primals_147, primals_144, primals_145, True, 0.1, 1e-05);  primals_147 = None
        getitem_38 = native_batch_norm_default_10[0]
        getitem_39 = native_batch_norm_default_10[1]
        getitem_40 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        stack_default_2 = torch.ops.aten.stack.default([relu__default_9, relu__default_10], 1)
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(stack_default_2, [1])
        mean_dim_2 = torch.ops.aten.mean.dim(sum_dim_int_list_4, [2, 3], True);  sum_dim_int_list_4 = None
        convolution_default_13 = torch.ops.aten.convolution.default(mean_dim_2, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_33, primals_29, primals_31, primals_32, True, 0.1, 1e-05);  primals_29 = None
        getitem_41 = native_batch_norm_default_11[0]
        getitem_42 = native_batch_norm_default_11[1]
        getitem_43 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_11, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_2 = torch.ops.aten.view.default(convolution_default_14, [128, 2, 128, 1, 1]);  convolution_default_14 = None
        _softmax_default_2 = torch.ops.aten._softmax.default(view_default_2, 1, False);  view_default_2 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(stack_default_2, _softmax_default_2)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_2, [1]);  mul_tensor_2 = None
        convolution_default_15 = torch.ops.aten.convolution.default(sum_dim_int_list_5, primals_38, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_148, 1);  primals_148 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_151, primals_152, primals_149, primals_150, True, 0.1, 1e-05);  primals_152 = None
        getitem_44 = native_batch_norm_default_12[0]
        getitem_45 = native_batch_norm_default_12[1]
        getitem_46 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_8, primals_39, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_47 = native_batch_norm_default_13[0]
        getitem_48 = native_batch_norm_default_13[1]
        getitem_49 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        add__tensor_7 = torch.ops.aten.add_.Tensor(getitem_44, getitem_47);  getitem_44 = getitem_47 = None
        relu__default_12 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        split_tensor_3 = torch.ops.aten.split.Tensor(relu__default_12, 64, 1)
        getitem_50 = split_tensor_3[0]
        getitem_51 = split_tensor_3[1];  split_tensor_3 = None
        convolution_default_17 = torch.ops.aten.convolution.default(getitem_50, primals_52, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_153, 1);  primals_153 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_156, primals_157, primals_154, primals_155, True, 0.1, 1e-05);  primals_157 = None
        getitem_52 = native_batch_norm_default_14[0]
        getitem_53 = native_batch_norm_default_14[1]
        getitem_54 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        convolution_default_18 = torch.ops.aten.convolution.default(getitem_51, primals_53, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_158, 1);  primals_158 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_161, primals_162, primals_159, primals_160, True, 0.1, 1e-05);  primals_162 = None
        getitem_55 = native_batch_norm_default_15[0]
        getitem_56 = native_batch_norm_default_15[1]
        getitem_57 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        stack_default_3 = torch.ops.aten.stack.default([relu__default_13, relu__default_14], 1)
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(stack_default_3, [1])
        mean_dim_3 = torch.ops.aten.mean.dim(sum_dim_int_list_6, [2, 3], True);  sum_dim_int_list_6 = None
        convolution_default_19 = torch.ops.aten.convolution.default(mean_dim_3, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_49, primals_45, primals_47, primals_48, True, 0.1, 1e-05);  primals_45 = None
        getitem_58 = native_batch_norm_default_16[0]
        getitem_59 = native_batch_norm_default_16[1]
        getitem_60 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_58);  getitem_58 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_15, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_3 = torch.ops.aten.view.default(convolution_default_20, [128, 2, 128, 1, 1]);  convolution_default_20 = None
        _softmax_default_3 = torch.ops.aten._softmax.default(view_default_3, 1, False);  view_default_3 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(stack_default_3, _softmax_default_3)
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_3, [1]);  mul_tensor_3 = None
        convolution_default_21 = torch.ops.aten.convolution.default(sum_dim_int_list_7, primals_54, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_163, 1);  primals_163 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_166, primals_167, primals_164, primals_165, True, 0.1, 1e-05);  primals_167 = None
        getitem_61 = native_batch_norm_default_17[0]
        getitem_62 = native_batch_norm_default_17[1]
        getitem_63 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        add__tensor_9 = torch.ops.aten.add_.Tensor(getitem_61, relu__default_12);  getitem_61 = None
        relu__default_16 = torch.ops.aten.relu_.default(add__tensor_9);  add__tensor_9 = None
        split_tensor_4 = torch.ops.aten.split.Tensor(relu__default_16, 64, 1)
        getitem_64 = split_tensor_4[0]
        getitem_65 = split_tensor_4[1];  split_tensor_4 = None
        convolution_default_22 = torch.ops.aten.convolution.default(getitem_64, primals_62, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_168, 1);  primals_168 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_171, primals_172, primals_169, primals_170, True, 0.1, 1e-05);  primals_172 = None
        getitem_66 = native_batch_norm_default_18[0]
        getitem_67 = native_batch_norm_default_18[1]
        getitem_68 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_23 = torch.ops.aten.convolution.default(getitem_65, primals_63, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_173, 1);  primals_173 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_176, primals_177, primals_174, primals_175, True, 0.1, 1e-05);  primals_177 = None
        getitem_69 = native_batch_norm_default_19[0]
        getitem_70 = native_batch_norm_default_19[1]
        getitem_71 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        stack_default_4 = torch.ops.aten.stack.default([relu__default_17, relu__default_18], 1)
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(stack_default_4, [1])
        mean_dim_4 = torch.ops.aten.mean.dim(sum_dim_int_list_8, [2, 3], True);  sum_dim_int_list_8 = None
        convolution_default_24 = torch.ops.aten.convolution.default(mean_dim_4, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_59, primals_55, primals_57, primals_58, True, 0.1, 1e-05);  primals_55 = None
        getitem_72 = native_batch_norm_default_20[0]
        getitem_73 = native_batch_norm_default_20[1]
        getitem_74 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_19, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_4 = torch.ops.aten.view.default(convolution_default_25, [128, 2, 256, 1, 1]);  convolution_default_25 = None
        _softmax_default_4 = torch.ops.aten._softmax.default(view_default_4, 1, False);  view_default_4 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(stack_default_4, _softmax_default_4)
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_4, [1]);  mul_tensor_4 = None
        convolution_default_26 = torch.ops.aten.convolution.default(sum_dim_int_list_9, primals_64, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_178, 1);  primals_178 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_181, primals_182, primals_179, primals_180, True, 0.1, 1e-05);  primals_182 = None
        getitem_75 = native_batch_norm_default_21[0]
        getitem_76 = native_batch_norm_default_21[1]
        getitem_77 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_16, primals_65, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_70, primals_66, primals_68, primals_69, True, 0.1, 1e-05);  primals_66 = None
        getitem_78 = native_batch_norm_default_22[0]
        getitem_79 = native_batch_norm_default_22[1]
        getitem_80 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        add__tensor_12 = torch.ops.aten.add_.Tensor(getitem_75, getitem_78);  getitem_75 = getitem_78 = None
        relu__default_20 = torch.ops.aten.relu_.default(add__tensor_12);  add__tensor_12 = None
        split_tensor_5 = torch.ops.aten.split.Tensor(relu__default_20, 128, 1)
        getitem_81 = split_tensor_5[0]
        getitem_82 = split_tensor_5[1];  split_tensor_5 = None
        convolution_default_28 = torch.ops.aten.convolution.default(getitem_81, primals_78, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_183, 1);  primals_183 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_186, primals_187, primals_184, primals_185, True, 0.1, 1e-05);  primals_187 = None
        getitem_83 = native_batch_norm_default_23[0]
        getitem_84 = native_batch_norm_default_23[1]
        getitem_85 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_82, primals_79, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_188, 1);  primals_188 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_191, primals_192, primals_189, primals_190, True, 0.1, 1e-05);  primals_192 = None
        getitem_86 = native_batch_norm_default_24[0]
        getitem_87 = native_batch_norm_default_24[1]
        getitem_88 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        stack_default_5 = torch.ops.aten.stack.default([relu__default_21, relu__default_22], 1)
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(stack_default_5, [1])
        mean_dim_5 = torch.ops.aten.mean.dim(sum_dim_int_list_10, [2, 3], True);  sum_dim_int_list_10 = None
        convolution_default_30 = torch.ops.aten.convolution.default(mean_dim_5, primals_76, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_75, primals_71, primals_73, primals_74, True, 0.1, 1e-05);  primals_71 = None
        getitem_89 = native_batch_norm_default_25[0]
        getitem_90 = native_batch_norm_default_25[1]
        getitem_91 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_23, primals_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_5 = torch.ops.aten.view.default(convolution_default_31, [128, 2, 256, 1, 1]);  convolution_default_31 = None
        _softmax_default_5 = torch.ops.aten._softmax.default(view_default_5, 1, False);  view_default_5 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(stack_default_5, _softmax_default_5)
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_5, [1]);  mul_tensor_5 = None
        convolution_default_32 = torch.ops.aten.convolution.default(sum_dim_int_list_11, primals_80, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_193, 1);  primals_193 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_196, primals_197, primals_194, primals_195, True, 0.1, 1e-05);  primals_197 = None
        getitem_92 = native_batch_norm_default_26[0]
        getitem_93 = native_batch_norm_default_26[1]
        getitem_94 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        add__tensor_14 = torch.ops.aten.add_.Tensor(getitem_92, relu__default_20);  getitem_92 = None
        relu__default_24 = torch.ops.aten.relu_.default(add__tensor_14);  add__tensor_14 = None
        split_tensor_6 = torch.ops.aten.split.Tensor(relu__default_24, 128, 1)
        getitem_95 = split_tensor_6[0]
        getitem_96 = split_tensor_6[1];  split_tensor_6 = None
        convolution_default_33 = torch.ops.aten.convolution.default(getitem_95, primals_88, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_198, 1);  primals_198 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_201, primals_202, primals_199, primals_200, True, 0.1, 1e-05);  primals_202 = None
        getitem_97 = native_batch_norm_default_27[0]
        getitem_98 = native_batch_norm_default_27[1]
        getitem_99 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_97);  getitem_97 = None
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_96, primals_89, None, [2, 2], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_203, 1);  primals_203 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_206, primals_207, primals_204, primals_205, True, 0.1, 1e-05);  primals_207 = None
        getitem_100 = native_batch_norm_default_28[0]
        getitem_101 = native_batch_norm_default_28[1]
        getitem_102 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_100);  getitem_100 = None
        stack_default_6 = torch.ops.aten.stack.default([relu__default_25, relu__default_26], 1)
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(stack_default_6, [1])
        mean_dim_6 = torch.ops.aten.mean.dim(sum_dim_int_list_12, [2, 3], True);  sum_dim_int_list_12 = None
        convolution_default_35 = torch.ops.aten.convolution.default(mean_dim_6, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_103 = native_batch_norm_default_29[0]
        getitem_104 = native_batch_norm_default_29[1]
        getitem_105 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_103);  getitem_103 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_27, primals_87, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_6 = torch.ops.aten.view.default(convolution_default_36, [128, 2, 512, 1, 1]);  convolution_default_36 = None
        _softmax_default_6 = torch.ops.aten._softmax.default(view_default_6, 1, False);  view_default_6 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(stack_default_6, _softmax_default_6)
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_6, [1]);  mul_tensor_6 = None
        convolution_default_37 = torch.ops.aten.convolution.default(sum_dim_int_list_13, primals_90, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_208, 1);  primals_208 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_211, primals_212, primals_209, primals_210, True, 0.1, 1e-05);  primals_212 = None
        getitem_106 = native_batch_norm_default_30[0]
        getitem_107 = native_batch_norm_default_30[1]
        getitem_108 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_24, primals_91, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_96, primals_92, primals_94, primals_95, True, 0.1, 1e-05);  primals_92 = None
        getitem_109 = native_batch_norm_default_31[0]
        getitem_110 = native_batch_norm_default_31[1]
        getitem_111 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        add__tensor_17 = torch.ops.aten.add_.Tensor(getitem_106, getitem_109);  getitem_106 = getitem_109 = None
        relu__default_28 = torch.ops.aten.relu_.default(add__tensor_17);  add__tensor_17 = None
        split_tensor_7 = torch.ops.aten.split.Tensor(relu__default_28, 256, 1)
        getitem_112 = split_tensor_7[0]
        getitem_113 = split_tensor_7[1];  split_tensor_7 = None
        convolution_default_39 = torch.ops.aten.convolution.default(getitem_112, primals_104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_213, 1);  primals_213 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_216, primals_217, primals_214, primals_215, True, 0.1, 1e-05);  primals_217 = None
        getitem_114 = native_batch_norm_default_32[0]
        getitem_115 = native_batch_norm_default_32[1]
        getitem_116 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_113, primals_105, None, [1, 1], [2, 2], [2, 2], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_218, 1);  primals_218 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_221, primals_222, primals_219, primals_220, True, 0.1, 1e-05);  primals_222 = None
        getitem_117 = native_batch_norm_default_33[0]
        getitem_118 = native_batch_norm_default_33[1]
        getitem_119 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_117);  getitem_117 = None
        stack_default_7 = torch.ops.aten.stack.default([relu__default_29, relu__default_30], 1)
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(stack_default_7, [1])
        mean_dim_7 = torch.ops.aten.mean.dim(sum_dim_int_list_14, [2, 3], True);  sum_dim_int_list_14 = None
        convolution_default_41 = torch.ops.aten.convolution.default(mean_dim_7, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_101, primals_97, primals_99, primals_100, True, 0.1, 1e-05);  primals_97 = None
        getitem_120 = native_batch_norm_default_34[0]
        getitem_121 = native_batch_norm_default_34[1]
        getitem_122 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_31, primals_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_7 = torch.ops.aten.view.default(convolution_default_42, [128, 2, 512, 1, 1]);  convolution_default_42 = None
        _softmax_default_7 = torch.ops.aten._softmax.default(view_default_7, 1, False);  view_default_7 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(stack_default_7, _softmax_default_7)
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_7, [1]);  mul_tensor_7 = None
        convolution_default_43 = torch.ops.aten.convolution.default(sum_dim_int_list_15, primals_106, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_223, 1);  primals_223 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_226, primals_227, primals_224, primals_225, True, 0.1, 1e-05);  primals_227 = None
        getitem_123 = native_batch_norm_default_35[0]
        getitem_124 = native_batch_norm_default_35[1]
        getitem_125 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        add__tensor_19 = torch.ops.aten.add_.Tensor(getitem_123, relu__default_28);  getitem_123 = None
        relu__default_32 = torch.ops.aten.relu_.default(add__tensor_19);  add__tensor_19 = None
        mean_dim_8 = torch.ops.aten.mean.dim(relu__default_32, [-1, -2], True)
        view_default_8 = torch.ops.aten.view.default(mean_dim_8, [128, 512]);  mean_dim_8 = None
        t_default = torch.ops.aten.t.default(primals_8);  primals_8 = None
        addmm_default = torch.ops.aten.addmm.default(primals_7, view_default_8, t_default);  primals_7 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_23, primals_102, primals_101, convolution_default_33, mean_dim_6, getitem_33, getitem_99, convolution_default_34, relu__default_26, convolution_default_11, getitem_101, getitem_34, getitem_102, primals_99, stack_default_6, sum_dim_int_list_3, primals_106, primals_100, relu__default_7, relu__default_25, getitem_31, convolution_default_10, getitem_105, primals_107, primals_103, convolution_default_35, getitem_95, getitem_104, primals_105, relu__default_8, relu__default_27, primals_104, getitem_98, getitem_96, _softmax_default_6, getitem_32, getitem_57, stack_default_3, sum_dim_int_list_9, relu__default_30, convolution_default_24, stack_default_7, convolution_default_6, convolution_default_26, getitem_22, getitem_20, getitem_107, sum_dim_int_list_15, getitem_118, getitem_54, getitem_119, getitem_73, convolution_default_37, getitem_56, mean_dim_7, relu__default_19, relu__default_5, getitem_108, relu__default_14, convolution_default_41, getitem_121, convolution_default_7, getitem_23, convolution_default_18, mean_dim_4, _softmax_default_7, getitem_122, _softmax_default_4, getitem_53, relu__default_31, convolution_default_38, sum_dim_int_list_13, getitem_74, relu__default_13, getitem_19, convolution_default_43, convolution_default_29, primals_205, primals_220, primals_165, primals_221, getitem_84, primals_215, relu__default_21, getitem_70, primals_216, primals_226, getitem_125, primals_110, primals_219, primals_166, primals_206, primals_209, primals_214, primals_170, mean_dim_5, primals_130, getitem_88, relu__default_32, getitem_85, view_default_8, primals_94, primals_89, relu__default_18, primals_210, primals_91, primals_224, primals_87, stack_default_5, convolution_default_30, primals_164, getitem_71, primals_169, primals_109, primals_161, primals_225, primals_90, primals_211, primals_131, getitem_87, stack_default_4, relu__default_22, primals_88, getitem_124, getitem_15, primals_38, relu__default_28, relu__default_29, primals_33, convolution_default_5, getitem_112, getitem_25, convolution_default_40, t_default, _softmax_default, mean_dim, relu__default_2, getitem_11, primals_32, sum_dim_int_list_1, getitem_14, primals_39, getitem_110, getitem_113, getitem_116, primals_35, getitem_28, stack_default_1, primals_43, primals_34, getitem_111, getitem_26, _softmax_default_1, primals_37, convolution_default_8, relu__default_6, primals_36, stack_default, getitem_29, primals_47, convolution_default_3, convolution_default_39, mean_dim_1, getitem_115, primals_42, getitem_12, relu__default_3, primals_44, primals_181, primals_185, primals_194, getitem_81, primals_83, primals_190, getitem_76, primals_174, getitem_1, primals_186, primals_79, primals_86, primals_85, getitem_82, primals_175, getitem_77, primals_191, primals_184, getitem_79, getitem_2, primals_180, primals_77, convolution_default_28, primals_176, convolution_default_27, primals_84, primals_195, primals_179, primals_80, getitem_80, primals_189, primals_171, primals_78, relu__default_20, primals_149, convolution_default_17, primals_139, primals_126, primals_125, getitem_18, primals_119, primals_141, primals_150, primals_121, getitem_48, primals_146, getitem_50, primals_144, relu__default_4, primals_151, primals_135, primals_124, getitem_49, convolution_default_16, primals_120, relu__default_12, getitem_51, primals_145, primals_140, primals_129, primals_134, primals_136, getitem_17, getitem_67, getitem_64, primals_114, primals_52, primals_199, primals_64, getitem_45, _softmax_default_2, convolution_default_22, primals_21, relu__default_11, primals_14, primals_15, primals_196, primals_54, primals_204, primals_61, primals_115, primals_60, getitem_62, primals_17, primals_200, primals_111, primals_16, primals_49, relu__default_17, convolution_default_23, primals_50, primals_116, primals_57, primals_53, primals_48, primals_12, primals_13, primals_58, getitem_63, primals_23, primals_51, primals_22, primals_59, convolution_default_15, getitem_68, primals_11, primals_201, primals_24, getitem_43, primals_63, getitem_42, primals_62, getitem_46, relu__default_16, primals_18, getitem_65, sum_dim_int_list_5, primals_65, convolution_default_19, primals_31, primals_69, convolution_default, getitem_36, convolution_default_1, convolution_default_12, relu__default_23, primals_95, primals_75, relu__default_1, relu__default_15, primals_25, getitem_91, primals_26, getitem_59, primals_159, getitem_5, sum_dim_int_list_11, stack_default_2, getitem_40, convolution_default_21, primals_27, primals_68, relu__default_24, primals_74, primals_73, primals_155, getitem_93, primals_96, primals_156, getitem_9, getitem_8, primals_6, relu__default_9, mean_dim_3, mean_dim_2, primals_4, getitem_4, convolution_default_32, sum_dim_int_list_7, relu__default, primals_28, _softmax_default_3, primals_160, getitem_60, primals_76, primals_70, primals_154, convolution_default_2, getitem_90, getitem_39, getitem_6, relu__default_10, convolution_default_13, _softmax_default_5, getitem_94, getitem_37, primals_3, primals_5]
        
