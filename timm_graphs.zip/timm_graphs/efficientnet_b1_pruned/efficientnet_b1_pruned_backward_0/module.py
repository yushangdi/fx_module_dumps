
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/efficientnet_b1_pruned/efficientnet_b1_pruned_backward_0/state_dict.pt'))

    
    
    def forward(self, getitem_27, primals_38, getitem_25, silu__default_19, primals_457, getitem_26, silu__default_26, primals_34, mul_tensor_6, silu__default_10, convolution_default_30, silu__default_7, getitem_24, sigmoid_default_6, silu__default_17, convolution_default_33, mul_tensor_3, primals_461, getitem_21, getitem_54, getitem_83, primals_89, convolution_default_15, mean_dim_9, sigmoid_default_2, sigmoid_default_3, getitem_82, silu__default_8, convolution_default_18, convolution_default_13, getitem_56, primals_308, mean_dim_6, primals_306, primals_463, getitem_55, primals_427, getitem_58, getitem_59, getitem_61, primals_411, getitem_29, mean_dim_3, getitem_28, getitem_81, getitem_31, getitem_32, primals_90, primals_29, getitem_22, getitem_23, primals_443, silu__default_27, primals_36, mul_tensor_2, primals_326, convolution_default_34, add_tensor_23, convolution_default_46, silu__default_18, primals_87, primals_462, primals_35, convolution_default_19, add_tensor_12, primals_458, convolution_default_16, convolution_default_31, primals_322, silu__default_9, primals_33, primals_506, convolution_default_14, primals_327, getitem_60, primals_177, primals_307, primals_323, primals_448, primals_40, getitem_33, getitem_62, primals_426, silu__default_28, primals_91, primals_31, primals_139, primals_292, getitem_117, convolution_default_68, convolution_default_89, getitem_159, sigmoid_default_10, primals_20, silu__default_29, primals_278, getitem_158, primals_22, primals_134, primals_241, convolution_default_53, getitem_119, getitem_5, mean_dim, convolution_default_35, getitem_4, getitem_118, convolution_default_66, silu__default_20, mean_dim_13, convolution_default_69, convolution_default_2, primals_140, getitem_121, primals_138, getitem_122, primals_317, getitem_63, primals_238, getitem_92, mean_dim_10, primals_237, primals_366, getitem_91, add_tensor_64, primals_136, primals_236, primals_368, getitem_95, convolution_default_54, getitem_123, primals_481, primals_145, primals_286, getitem_65, primals_483, mean_dim_7, getitem_94, getitem_64, getitem_96, getitem_186, primals_28, primals_141, getitem_3, primals_21, primals_233, primals_281, primals_477, add_tensor_49, primals_473, getitem_162, primals_143, primals_318, primals_476, silu__default_39, silu__default_1, getitem_160, primals_412, getitem_90, primals_232, primals_147, getitem_97, primals_26, add_tensor_38, getitem_125, primals_282, primals_17, silu__default_30, getitem_124, primals_24, primals_478, mul_tensor_10, primals_243, primals_283, primals_242, convolution_default_51, primals_482, silu__default_21, primals_403, primals_291, getitem_98, silu__default_53, primals_287, convolution_default_36, primals_246, silu__default_40, silu__default_2, primals_247, primals_146, convolution_default_90, primals_19, primals_433, mul_tensor_13, primals_231, mul_tensor, silu__default_41, primals_248, convolution_default_55, sigmoid_default_13, primals_367, sigmoid_default, silu__default_31, primals_27, primals_321, primals_472, convolution_default_70, convolution_default_71, getitem_153, primals_4, convolution_default_86, convolution_default_104, silu__default_22, mean_dim_17, getitem_35, getitem_154, getitem_184, mean_dim_14, primals_491, getitem_128, getitem_185, getitem_155, primals_61, mul_tensor_7, getitem_127, primals_70, getitem_34, sigmoid_default_7, add_tensor_76, convolution_default_38, primals_77, primals_296, primals_417, primals_2, primals_69, primals_297, primals_6, convolution_default_20, silu__default_60, silu__default_11, primals_122, primals_62, getitem_188, mean_dim_21, primals_59, primals_303, getitem_36, primals_441, silu__default_51, getitem_187, convolution_default_101, primals_124, primals_487, primals_64, primals_125, getitem_67, primals_492, getitem_68, silu__default_42, getitem_126, getitem_38, mean_dim_4, primals_508, getitem_37, constant_pad_nd_default_3, primals_438, primals_507, silu__default_61, primals_73, primals_66, primals_496, primals_75, primals_227, primals_298, primals_63, primals_76, primals_228, primals_301, silu__default_52, primals_71, convolution_default_39, add_tensor_27, silu__default_62, primals_423, primals_486, primals_1, primals_302, primals_442, mul_tensor_20, convolution_default_105, primals_103, getitem_70, sigmoid_default_20, silu__default_43, getitem_189, silu__default_12, primals_488, getitem_69, primals_493, convolution_default_40, sigmoid_default_17, convolution_default_103, primals_416, primals_453, convolution_default_21, mul_tensor_17, getitem_190, mul_tensor_14, convolution_default_88, primals_226, getitem_71, primals_422, getitem_191, primals_68, sigmoid_default_14, primals_352, primals_362, primals_397, primals_104, primals_392, convolution_default_73, getitem_194, primals_106, primals_223, primals_391, convolution_default_58, primals_401, primals_503, silu__default_13, convolution_default_109, primals_213, getitem_131, getitem_195, convolution_default_74, primals_471, mul_tensor_4, getitem_130, primals_217, primals_373, getitem_132, getitem_104, getitem_157, sigmoid_default_4, convolution_default_59, getitem_197, convolution_default_23, getitem_196, getitem_103, primals_396, primals_222, primals_357, getitem_105, add_tensor_53, primals_216, getitem_40, add_tensor_42, getitem_134, getitem_41, primals_361, primals_468, constant_pad_nd_default_2, primals_407, getitem_133, primals_348, primals_353, getitem_42, silu__default_65, primals_176, primals_378, getitem_107, primals_402, getitem_106, primals_466, primals_356, convolution_default_110, mean_dim_22, primals_406, primals_388, convolution_default_24, primals_351, primals_363, add_tensor_16, getitem_199, primals_393, primals_108, primals_218, primals_467, primals_105, getitem_198, primals_173, primals_221, convolution_default_25, silu__default_44, primals_398, primals_358, primals_502, primals_376, convolution_default_60, getitem_200, primals_501, primals_377, getitem_43, convolution_default_75, silu__default_35, getitem_44, mean_dim_15, silu__default_32, primals_83, getitem_167, getitem_168, primals_14, getitem_137, getitem_135, getitem_166, getitem_136, constant_pad_nd_default_4, getitem_73, silu__default_63, getitem_101, primals_451, mean_dim_11, getitem_100, add_tensor_68, primals_49, mean_dim_8, getitem_46, primals_47, getitem_72, primals_10, convolution_default_106, primals_78, mean_dim_5, getitem_170, primals_126, getitem_74, convolution_default_94, getitem_45, silu__default_45, mean_dim_19, convolution_default_76, primals_8, getitem_169, primals_131, primals_13, getitem_99, primals_84, getitem_47, silu__default_64, primals_7, primals_48, silu__default_33, getitem_161, primals_132, primals_168, primals_12, sigmoid_default_11, convolution_default_56, primals_172, primals_418, mul_tensor_21, primals_15, silu__default_24, silu__default_46, primals_129, silu__default_56, sigmoid_default_21, primals_171, convolution_default_41, primals_80, primals_127, silu__default_15, getitem_192, convolution_default_95, convolution_default_108, getitem_171, primals_82, convolution_default_26, sigmoid_default_15, primals_45, primals_428, silu__default_34, primals_133, mul_tensor_11, mul_tensor_15, silu__default_25, getitem_172, getitem_193, convolution_default_78, mean_dim_18, getitem_163, primals_118, getitem_16, primals_202, getitem_6, convolution_default_63, primals_456, primals_212, getitem_164, primals_41, primals_452, getitem_111, primals_313, primals_191, getitem_15, getitem_140, primals_208, getitem_9, getitem_141, getitem_7, convolution_default_79, getitem_8, primals_193, silu__default_4, getitem_139, getitem_113, convolution_default_4, getitem_17, getitem_112, getitem_114, silu__default_54, primals_211, sigmoid_default_1, add_tensor_57, convolution_default_91, convolution_default_8, convolution_default_10, primals_112, primals_201, primals_113, convolution_default_5, primals_288, primals_196, primals_293, convolution_default, convolution_default_64, getitem_143, primals_42, primals_311, getitem, getitem_18, primals_383, getitem_142, primals_312, primals_387, primals_110, getitem_11, constant_pad_nd_default_1, getitem_1, getitem_19, getitem_10, getitem_20, getitem_116, silu__default_55, getitem_13, primals_197, getitem_14, getitem_115, primals_119, getitem_2, mul_tensor_1, primals_111, primals_316, sigmoid_default_18, convolution_default_11, primals_117, convolution_default_9, mul_tensor_18, add_tensor_5, mean_dim_1, silu__default_6, convolution_default_65, convolution_default_93, primals_192, primals_386, primals_43, convolution_default_1, silu__default_3, primals_120, silu__default_38, primals_198, silu__default, primals_115, convolution_default_6, mean_dim_2, convolution_default_80, primals_342, primals_206, primals_159, getitem_75, primals_381, silu__default_16, mul_tensor_8, primals_92, primals_181, primals_437, primals_271, add_tensor_83, primals_257, primals_162, mul_tensor_5, sigmoid_default_8, silu__default_66, getitem_110, primals_85, primals_178, primals_258, getitem_48, convolution_default_43, mean_dim_12, sigmoid_default_5, getitem_109, primals_341, getitem_206, convolution_default_28, getitem_205, convolution_default_111, view_default, primals_183, primals_272, primals_338, getitem_76, primals_273, getitem_77, primals_497, getitem_108, silu__default_67, primals_261, primals_347, primals_148, primals_203, getitem_79, primals_166, primals_421, getitem_49, primals_153, primals_262, getitem_50, silu__default_36, convolution_default_114, getitem_204, primals_346, primals_167, primals_182, sigmoid_default_22, primals_382, getitem_51, primals_413, constant_pad_nd_default, convolution_default_61, primals_267, convolution_default_44, primals_186, primals_163, primals_157, primals_150, primals_263, primals_187, primals_207, convolution_default_29, getitem_78, primals_154, convolution_default_113, primals_276, primals_498, t_default, primals_277, primals_436, primals_94, primals_268, convolution_default_45, getitem_80, getitem_202, silu__default_37, primals_152, mul_tensor_22, getitem_52, sigmoid_default_12, primals_188, primals_343, mul_tensor_12, primals_155, getitem_53, primals_266, getitem_203, getitem_147, primals_447, getitem_173, getitem_177, mul_tensor_9, mean_dim_16, getitem_145, getitem_175, convolution_default_99, primals_57, primals_96, getitem_144, primals_101, sigmoid_default_9, getitem_146, getitem_149, getitem_150, getitem_176, primals_431, convolution_default_48, getitem_148, primals_252, primals_56, primals_331, add_tensor_72, silu__default_57, primals_97, primals_432, convolution_default_84, getitem_85, primals_336, primals_408, getitem_86, convolution_default_49, convolution_default_81, getitem_179, mean_dim_20, primals_98, silu__default_48, getitem_178, convolution_default_96, primals_371, getitem_87, getitem_152, getitem_151, primals_333, silu__default_58, getitem_88, primals_50, add_tensor_34, primals_446, primals_328, convolution_default_83, primals_332, silu__default_49, silu__default_59, primals_99, primals_54, sigmoid_default_19, primals_372, primals_55, getitem_89, convolution_default_100, silu__default_50, getitem_180, primals_337, mul_tensor_19, primals_52, primals_253, sigmoid_default_16, convolution_default_98, primals_251, convolution_default_85, mul_tensor_16, getitem_181, primals_256, getitem_182, convolution_default_50, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50, tangents_51, tangents_52, tangents_53, tangents_54, tangents_55, tangents_56, tangents_57, tangents_58, tangents_59, tangents_60, tangents_61, tangents_62, tangents_63, tangents_64, tangents_65, tangents_66, tangents_67, tangents_68, tangents_69, tangents_70):
        clone_default = torch.ops.aten.clone.default(getitem);  getitem = None
        clone_default_1 = torch.ops.aten.clone.default(getitem_3);  getitem_3 = None
        clone_default_2 = torch.ops.aten.clone.default(convolution_default_2);  convolution_default_2 = None
        clone_default_3 = torch.ops.aten.clone.default(getitem_9);  getitem_9 = None
        clone_default_4 = torch.ops.aten.clone.default(convolution_default_6);  convolution_default_6 = None
        clone_default_5 = torch.ops.aten.clone.default(getitem_15);  getitem_15 = None
        clone_default_6 = torch.ops.aten.clone.default(getitem_18);  getitem_18 = None
        clone_default_7 = torch.ops.aten.clone.default(convolution_default_11);  convolution_default_11 = None
        clone_default_8 = torch.ops.aten.clone.default(getitem_24);  getitem_24 = None
        clone_default_9 = torch.ops.aten.clone.default(getitem_27);  getitem_27 = None
        clone_default_10 = torch.ops.aten.clone.default(convolution_default_16);  convolution_default_16 = None
        clone_default_11 = torch.ops.aten.clone.default(getitem_33);  getitem_33 = None
        clone_default_12 = torch.ops.aten.clone.default(getitem_36);  getitem_36 = None
        clone_default_13 = torch.ops.aten.clone.default(convolution_default_21);  convolution_default_21 = None
        clone_default_14 = torch.ops.aten.clone.default(getitem_42);  getitem_42 = None
        clone_default_15 = torch.ops.aten.clone.default(getitem_45);  getitem_45 = None
        clone_default_16 = torch.ops.aten.clone.default(convolution_default_26);  convolution_default_26 = None
        clone_default_17 = torch.ops.aten.clone.default(getitem_51);  getitem_51 = None
        clone_default_18 = torch.ops.aten.clone.default(getitem_54);  getitem_54 = None
        clone_default_19 = torch.ops.aten.clone.default(convolution_default_31);  convolution_default_31 = None
        clone_default_20 = torch.ops.aten.clone.default(getitem_60);  getitem_60 = None
        clone_default_21 = torch.ops.aten.clone.default(getitem_63);  getitem_63 = None
        clone_default_22 = torch.ops.aten.clone.default(convolution_default_36);  convolution_default_36 = None
        clone_default_23 = torch.ops.aten.clone.default(getitem_69);  getitem_69 = None
        clone_default_24 = torch.ops.aten.clone.default(getitem_72);  getitem_72 = None
        clone_default_25 = torch.ops.aten.clone.default(convolution_default_41);  convolution_default_41 = None
        clone_default_26 = torch.ops.aten.clone.default(getitem_78);  getitem_78 = None
        clone_default_27 = torch.ops.aten.clone.default(getitem_81);  getitem_81 = None
        clone_default_28 = torch.ops.aten.clone.default(convolution_default_46);  convolution_default_46 = None
        clone_default_29 = torch.ops.aten.clone.default(getitem_87);  getitem_87 = None
        clone_default_30 = torch.ops.aten.clone.default(getitem_90);  getitem_90 = None
        clone_default_31 = torch.ops.aten.clone.default(convolution_default_51);  convolution_default_51 = None
        clone_default_32 = torch.ops.aten.clone.default(getitem_96);  getitem_96 = None
        clone_default_33 = torch.ops.aten.clone.default(getitem_99);  getitem_99 = None
        clone_default_34 = torch.ops.aten.clone.default(convolution_default_56);  convolution_default_56 = None
        clone_default_35 = torch.ops.aten.clone.default(getitem_105);  getitem_105 = None
        clone_default_36 = torch.ops.aten.clone.default(getitem_108);  getitem_108 = None
        clone_default_37 = torch.ops.aten.clone.default(convolution_default_61);  convolution_default_61 = None
        clone_default_38 = torch.ops.aten.clone.default(getitem_114);  getitem_114 = None
        clone_default_39 = torch.ops.aten.clone.default(getitem_117);  getitem_117 = None
        clone_default_40 = torch.ops.aten.clone.default(convolution_default_66);  convolution_default_66 = None
        clone_default_41 = torch.ops.aten.clone.default(getitem_123);  getitem_123 = None
        clone_default_42 = torch.ops.aten.clone.default(getitem_126);  getitem_126 = None
        clone_default_43 = torch.ops.aten.clone.default(convolution_default_71);  convolution_default_71 = None
        clone_default_44 = torch.ops.aten.clone.default(getitem_132);  getitem_132 = None
        clone_default_45 = torch.ops.aten.clone.default(getitem_135);  getitem_135 = None
        clone_default_46 = torch.ops.aten.clone.default(convolution_default_76);  convolution_default_76 = None
        clone_default_47 = torch.ops.aten.clone.default(getitem_141);  getitem_141 = None
        clone_default_48 = torch.ops.aten.clone.default(getitem_144);  getitem_144 = None
        clone_default_49 = torch.ops.aten.clone.default(convolution_default_81);  convolution_default_81 = None
        clone_default_50 = torch.ops.aten.clone.default(getitem_150);  getitem_150 = None
        clone_default_51 = torch.ops.aten.clone.default(getitem_153);  getitem_153 = None
        clone_default_52 = torch.ops.aten.clone.default(convolution_default_86);  convolution_default_86 = None
        clone_default_53 = torch.ops.aten.clone.default(getitem_159);  getitem_159 = None
        clone_default_54 = torch.ops.aten.clone.default(getitem_162);  getitem_162 = None
        clone_default_55 = torch.ops.aten.clone.default(convolution_default_91);  convolution_default_91 = None
        clone_default_56 = torch.ops.aten.clone.default(getitem_168);  getitem_168 = None
        clone_default_57 = torch.ops.aten.clone.default(getitem_171);  getitem_171 = None
        clone_default_58 = torch.ops.aten.clone.default(convolution_default_96);  convolution_default_96 = None
        clone_default_59 = torch.ops.aten.clone.default(getitem_177);  getitem_177 = None
        clone_default_60 = torch.ops.aten.clone.default(getitem_180);  getitem_180 = None
        clone_default_61 = torch.ops.aten.clone.default(convolution_default_101);  convolution_default_101 = None
        clone_default_62 = torch.ops.aten.clone.default(getitem_186);  getitem_186 = None
        clone_default_63 = torch.ops.aten.clone.default(getitem_189);  getitem_189 = None
        clone_default_64 = torch.ops.aten.clone.default(convolution_default_106);  convolution_default_106 = None
        clone_default_65 = torch.ops.aten.clone.default(getitem_195);  getitem_195 = None
        clone_default_66 = torch.ops.aten.clone.default(getitem_198);  getitem_198 = None
        clone_default_67 = torch.ops.aten.clone.default(convolution_default_111);  convolution_default_111 = None
        clone_default_68 = torch.ops.aten.clone.default(getitem_204);  getitem_204 = None
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1280, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1280, 8, 8]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 64);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(clone_default_68, torch.float32);  clone_default_68 = None
        neg_default = torch.ops.aten.neg.default(to_dtype_1)
        exp_default = torch.ops.aten.exp.default(neg_default);  neg_default = None
        add_tensor_85 = torch.ops.aten.add.Tensor(exp_default, 1);  exp_default = None
        reciprocal_default = torch.ops.aten.reciprocal.default(add_tensor_85);  add_tensor_85 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(reciprocal_default, 1);  reciprocal_default = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype, mul_tensor_23);  to_dtype = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor_23, 1);  mul_tensor_23 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_1, rsub_scalar);  to_dtype_1 = rsub_scalar = None
        add_tensor_86 = torch.ops.aten.add.Tensor(mul_tensor_25, 1);  mul_tensor_25 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(mul_tensor_24, add_tensor_86);  mul_tensor_24 = add_tensor_86 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_26, torch.float32);  mul_tensor_26 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_114, primals_508, primals_506, primals_507, getitem_205, getitem_206, True, 0.001, [True, True, True]);  to_dtype_2 = convolution_default_114 = primals_508 = primals_506 = primals_507 = getitem_205 = getitem_206 = None
        getitem_207 = native_batch_norm_backward_default[0]
        getitem_208 = native_batch_norm_backward_default[1]
        getitem_209 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_207, add_tensor_83, primals_162, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_207 = add_tensor_83 = primals_162 = None
        getitem_210 = convolution_backward_default[0]
        getitem_211 = convolution_backward_default[1];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_210, convolution_default_113, primals_503, primals_501, primals_502, getitem_202, getitem_203, True, 0.001, [True, True, True]);  convolution_default_113 = primals_503 = primals_501 = primals_502 = getitem_202 = getitem_203 = None
        getitem_213 = native_batch_norm_backward_default_1[0]
        getitem_214 = native_batch_norm_backward_default_1[1]
        getitem_215 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_213, mul_tensor_22, primals_155, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_213 = mul_tensor_22 = primals_155 = None
        getitem_216 = convolution_backward_default_1[0]
        getitem_217 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(getitem_216, silu__default_66);  silu__default_66 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(getitem_216, sigmoid_default_22);  getitem_216 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_27, [2, 3], True);  mul_tensor_27 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_22, torch.float32);  sigmoid_default_22 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar_1);  to_dtype_4 = rsub_scalar_1 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_29);  mul_tensor_29 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_30, torch.float32);  mul_tensor_30 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_5, silu__default_67, primals_157, [1912], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = silu__default_67 = primals_157 = None
        getitem_219 = convolution_backward_default_2[0]
        getitem_220 = convolution_backward_default_2[1]
        getitem_221 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_219, torch.float32);  getitem_219 = None
        to_dtype_7 = torch.ops.aten.to.dtype(clone_default_67, torch.float32);  clone_default_67 = None
        neg_default_1 = torch.ops.aten.neg.default(to_dtype_7)
        exp_default_1 = torch.ops.aten.exp.default(neg_default_1);  neg_default_1 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(exp_default_1, 1);  exp_default_1 = None
        reciprocal_default_1 = torch.ops.aten.reciprocal.default(add_tensor_87);  add_tensor_87 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(reciprocal_default_1, 1);  reciprocal_default_1 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(to_dtype_6, mul_tensor_31);  to_dtype_6 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(mul_tensor_31, 1);  mul_tensor_31 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_7, rsub_scalar_2);  to_dtype_7 = rsub_scalar_2 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(mul_tensor_33, 1);  mul_tensor_33 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(mul_tensor_32, add_tensor_88);  mul_tensor_32 = add_tensor_88 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_34, torch.float32);  mul_tensor_34 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_22, primals_159, [80], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_22 = primals_159 = None
        getitem_222 = convolution_backward_default_3[0]
        getitem_223 = convolution_backward_default_3[1]
        getitem_224 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_222, [128, 1912, 8, 8]);  getitem_222 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 64);  expand_default_1 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(mul_tensor_28, div_scalar_1);  mul_tensor_28 = div_scalar_1 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_89, torch.float32);  add_tensor_89 = None
        to_dtype_10 = torch.ops.aten.to.dtype(clone_default_66, torch.float32);  clone_default_66 = None
        neg_default_2 = torch.ops.aten.neg.default(to_dtype_10)
        exp_default_2 = torch.ops.aten.exp.default(neg_default_2);  neg_default_2 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(exp_default_2, 1);  exp_default_2 = None
        reciprocal_default_2 = torch.ops.aten.reciprocal.default(add_tensor_90);  add_tensor_90 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(reciprocal_default_2, 1);  reciprocal_default_2 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_9, mul_tensor_35);  to_dtype_9 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(mul_tensor_35, 1);  mul_tensor_35 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_10, rsub_scalar_3);  to_dtype_10 = rsub_scalar_3 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(mul_tensor_37, 1);  mul_tensor_37 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(mul_tensor_36, add_tensor_91);  mul_tensor_36 = add_tensor_91 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_38, torch.float32);  mul_tensor_38 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_110, primals_498, primals_496, primals_497, getitem_199, getitem_200, True, 0.001, [True, True, True]);  to_dtype_11 = convolution_default_110 = primals_498 = primals_496 = primals_497 = getitem_199 = getitem_200 = None
        getitem_225 = native_batch_norm_backward_default_2[0]
        getitem_226 = native_batch_norm_backward_default_2[1]
        getitem_227 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_225, silu__default_65, primals_153, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1912, [True, True, False]);  getitem_225 = silu__default_65 = primals_153 = None
        getitem_228 = convolution_backward_default_4[0]
        getitem_229 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_228, torch.float32);  getitem_228 = None
        to_dtype_13 = torch.ops.aten.to.dtype(clone_default_65, torch.float32);  clone_default_65 = None
        neg_default_3 = torch.ops.aten.neg.default(to_dtype_13)
        exp_default_3 = torch.ops.aten.exp.default(neg_default_3);  neg_default_3 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(exp_default_3, 1);  exp_default_3 = None
        reciprocal_default_3 = torch.ops.aten.reciprocal.default(add_tensor_92);  add_tensor_92 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(reciprocal_default_3, 1);  reciprocal_default_3 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_12, mul_tensor_39);  to_dtype_12 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(mul_tensor_39, 1);  mul_tensor_39 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_13, rsub_scalar_4);  to_dtype_13 = rsub_scalar_4 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(mul_tensor_41, 1);  mul_tensor_41 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(mul_tensor_40, add_tensor_93);  mul_tensor_40 = add_tensor_93 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_42, torch.float32);  mul_tensor_42 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_109, primals_493, primals_491, primals_492, getitem_196, getitem_197, True, 0.001, [True, True, True]);  to_dtype_14 = convolution_default_109 = primals_493 = primals_491 = primals_492 = getitem_196 = getitem_197 = None
        getitem_231 = native_batch_norm_backward_default_3[0]
        getitem_232 = native_batch_norm_backward_default_3[1]
        getitem_233 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_231, getitem_192, primals_154, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_231 = getitem_192 = primals_154 = None
        getitem_234 = convolution_backward_default_5[0]
        getitem_235 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(getitem_210, getitem_234);  getitem_210 = getitem_234 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_94, convolution_default_108, primals_488, primals_486, primals_487, getitem_193, getitem_194, True, 0.001, [True, True, True]);  add_tensor_94 = convolution_default_108 = primals_488 = primals_486 = primals_487 = getitem_193 = getitem_194 = None
        getitem_237 = native_batch_norm_backward_default_4[0]
        getitem_238 = native_batch_norm_backward_default_4[1]
        getitem_239 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_237, mul_tensor_21, primals_148, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_237 = mul_tensor_21 = primals_148 = None
        getitem_240 = convolution_backward_default_6[0]
        getitem_241 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(getitem_240, silu__default_63);  silu__default_63 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(getitem_240, sigmoid_default_21);  getitem_240 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_43, [2, 3], True);  mul_tensor_43 = None
        to_dtype_15 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_16 = torch.ops.aten.to.dtype(sigmoid_default_21, torch.float32);  sigmoid_default_21 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_16, 1)
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_16, rsub_scalar_5);  to_dtype_16 = rsub_scalar_5 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_45);  mul_tensor_45 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_15, conj_physical_default_1);  to_dtype_15 = conj_physical_default_1 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_46, torch.float32);  mul_tensor_46 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_17, silu__default_64, primals_150, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_17 = silu__default_64 = primals_150 = None
        getitem_243 = convolution_backward_default_7[0]
        getitem_244 = convolution_backward_default_7[1]
        getitem_245 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_243, torch.float32);  getitem_243 = None
        to_dtype_19 = torch.ops.aten.to.dtype(clone_default_64, torch.float32);  clone_default_64 = None
        neg_default_4 = torch.ops.aten.neg.default(to_dtype_19)
        exp_default_4 = torch.ops.aten.exp.default(neg_default_4);  neg_default_4 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(exp_default_4, 1);  exp_default_4 = None
        reciprocal_default_4 = torch.ops.aten.reciprocal.default(add_tensor_95);  add_tensor_95 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(reciprocal_default_4, 1);  reciprocal_default_4 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_18, mul_tensor_47);  to_dtype_18 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(mul_tensor_47, 1);  mul_tensor_47 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_6);  to_dtype_19 = rsub_scalar_6 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(mul_tensor_49, 1);  mul_tensor_49 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(mul_tensor_48, add_tensor_96);  mul_tensor_48 = add_tensor_96 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_50, torch.float32);  mul_tensor_50 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_20, mean_dim_21, primals_152, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = mean_dim_21 = primals_152 = None
        getitem_246 = convolution_backward_default_8[0]
        getitem_247 = convolution_backward_default_8[1]
        getitem_248 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_246, [128, 1152, 8, 8]);  getitem_246 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 64);  expand_default_2 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mul_tensor_44, div_scalar_2);  mul_tensor_44 = div_scalar_2 = None
        to_dtype_21 = torch.ops.aten.to.dtype(add_tensor_97, torch.float32);  add_tensor_97 = None
        to_dtype_22 = torch.ops.aten.to.dtype(clone_default_63, torch.float32);  clone_default_63 = None
        neg_default_5 = torch.ops.aten.neg.default(to_dtype_22)
        exp_default_5 = torch.ops.aten.exp.default(neg_default_5);  neg_default_5 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(exp_default_5, 1);  exp_default_5 = None
        reciprocal_default_5 = torch.ops.aten.reciprocal.default(add_tensor_98);  add_tensor_98 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(reciprocal_default_5, 1);  reciprocal_default_5 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_21, mul_tensor_51);  to_dtype_21 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(mul_tensor_51, 1);  mul_tensor_51 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_22, rsub_scalar_7);  to_dtype_22 = rsub_scalar_7 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(mul_tensor_53, 1);  mul_tensor_53 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(mul_tensor_52, add_tensor_99);  mul_tensor_52 = add_tensor_99 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_54, torch.float32);  mul_tensor_54 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_105, primals_483, primals_481, primals_482, getitem_190, getitem_191, True, 0.001, [True, True, True]);  to_dtype_23 = convolution_default_105 = primals_483 = primals_481 = primals_482 = getitem_190 = getitem_191 = None
        getitem_249 = native_batch_norm_backward_default_5[0]
        getitem_250 = native_batch_norm_backward_default_5[1]
        getitem_251 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_249, silu__default_62, primals_146, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_249 = silu__default_62 = primals_146 = None
        getitem_252 = convolution_backward_default_9[0]
        getitem_253 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_252, torch.float32);  getitem_252 = None
        to_dtype_25 = torch.ops.aten.to.dtype(clone_default_62, torch.float32);  clone_default_62 = None
        neg_default_6 = torch.ops.aten.neg.default(to_dtype_25)
        exp_default_6 = torch.ops.aten.exp.default(neg_default_6);  neg_default_6 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(exp_default_6, 1);  exp_default_6 = None
        reciprocal_default_6 = torch.ops.aten.reciprocal.default(add_tensor_100);  add_tensor_100 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(reciprocal_default_6, 1);  reciprocal_default_6 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_24, mul_tensor_55);  to_dtype_24 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(mul_tensor_55, 1);  mul_tensor_55 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_25, rsub_scalar_8);  to_dtype_25 = rsub_scalar_8 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(mul_tensor_57, 1);  mul_tensor_57 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(mul_tensor_56, add_tensor_101);  mul_tensor_56 = add_tensor_101 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_58, torch.float32);  mul_tensor_58 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_104, primals_478, primals_476, primals_477, getitem_187, getitem_188, True, 0.001, [True, True, True]);  to_dtype_26 = convolution_default_104 = primals_478 = primals_476 = primals_477 = getitem_187 = getitem_188 = None
        getitem_255 = native_batch_norm_backward_default_6[0]
        getitem_256 = native_batch_norm_backward_default_6[1]
        getitem_257 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_255, add_tensor_76, primals_147, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_255 = add_tensor_76 = primals_147 = None
        getitem_258 = convolution_backward_default_10[0]
        getitem_259 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(getitem_258, convolution_default_103, primals_473, primals_471, primals_472, getitem_184, getitem_185, True, 0.001, [True, True, True]);  convolution_default_103 = primals_473 = primals_471 = primals_472 = getitem_184 = getitem_185 = None
        getitem_261 = native_batch_norm_backward_default_7[0]
        getitem_262 = native_batch_norm_backward_default_7[1]
        getitem_263 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_261, mul_tensor_20, primals_141, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_261 = mul_tensor_20 = primals_141 = None
        getitem_264 = convolution_backward_default_11[0]
        getitem_265 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(getitem_264, silu__default_60);  silu__default_60 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(getitem_264, sigmoid_default_20);  getitem_264 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_59, [2, 3], True);  mul_tensor_59 = None
        to_dtype_27 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_28 = torch.ops.aten.to.dtype(sigmoid_default_20, torch.float32);  sigmoid_default_20 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(to_dtype_28, 1)
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_28, rsub_scalar_9);  to_dtype_28 = rsub_scalar_9 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_61);  mul_tensor_61 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_27, conj_physical_default_2);  to_dtype_27 = conj_physical_default_2 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_62, torch.float32);  mul_tensor_62 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_29, silu__default_61, primals_143, [990], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_29 = silu__default_61 = primals_143 = None
        getitem_267 = convolution_backward_default_12[0]
        getitem_268 = convolution_backward_default_12[1]
        getitem_269 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_267, torch.float32);  getitem_267 = None
        to_dtype_31 = torch.ops.aten.to.dtype(clone_default_61, torch.float32);  clone_default_61 = None
        neg_default_7 = torch.ops.aten.neg.default(to_dtype_31)
        exp_default_7 = torch.ops.aten.exp.default(neg_default_7);  neg_default_7 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(exp_default_7, 1);  exp_default_7 = None
        reciprocal_default_7 = torch.ops.aten.reciprocal.default(add_tensor_102);  add_tensor_102 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(reciprocal_default_7, 1);  reciprocal_default_7 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(to_dtype_30, mul_tensor_63);  to_dtype_30 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(mul_tensor_63, 1);  mul_tensor_63 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_31, rsub_scalar_10);  to_dtype_31 = rsub_scalar_10 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(mul_tensor_65, 1);  mul_tensor_65 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(mul_tensor_64, add_tensor_103);  mul_tensor_64 = add_tensor_103 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_66, torch.float32);  mul_tensor_66 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_32, mean_dim_20, primals_145, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_32 = mean_dim_20 = primals_145 = None
        getitem_270 = convolution_backward_default_13[0]
        getitem_271 = convolution_backward_default_13[1]
        getitem_272 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_270, [128, 990, 8, 8]);  getitem_270 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 64);  expand_default_3 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(mul_tensor_60, div_scalar_3);  mul_tensor_60 = div_scalar_3 = None
        to_dtype_33 = torch.ops.aten.to.dtype(add_tensor_104, torch.float32);  add_tensor_104 = None
        to_dtype_34 = torch.ops.aten.to.dtype(clone_default_60, torch.float32);  clone_default_60 = None
        neg_default_8 = torch.ops.aten.neg.default(to_dtype_34)
        exp_default_8 = torch.ops.aten.exp.default(neg_default_8);  neg_default_8 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(exp_default_8, 1);  exp_default_8 = None
        reciprocal_default_8 = torch.ops.aten.reciprocal.default(add_tensor_105);  add_tensor_105 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(reciprocal_default_8, 1);  reciprocal_default_8 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_33, mul_tensor_67);  to_dtype_33 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(mul_tensor_67, 1);  mul_tensor_67 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_11);  to_dtype_34 = rsub_scalar_11 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(mul_tensor_69, 1);  mul_tensor_69 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(mul_tensor_68, add_tensor_106);  mul_tensor_68 = add_tensor_106 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_70, torch.float32);  mul_tensor_70 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_100, primals_468, primals_466, primals_467, getitem_181, getitem_182, True, 0.001, [True, True, True]);  to_dtype_35 = convolution_default_100 = primals_468 = primals_466 = primals_467 = getitem_181 = getitem_182 = None
        getitem_273 = native_batch_norm_backward_default_8[0]
        getitem_274 = native_batch_norm_backward_default_8[1]
        getitem_275 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_273, silu__default_59, primals_139, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 990, [True, True, False]);  getitem_273 = silu__default_59 = primals_139 = None
        getitem_276 = convolution_backward_default_14[0]
        getitem_277 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_276, torch.float32);  getitem_276 = None
        to_dtype_37 = torch.ops.aten.to.dtype(clone_default_59, torch.float32);  clone_default_59 = None
        neg_default_9 = torch.ops.aten.neg.default(to_dtype_37)
        exp_default_9 = torch.ops.aten.exp.default(neg_default_9);  neg_default_9 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(exp_default_9, 1);  exp_default_9 = None
        reciprocal_default_9 = torch.ops.aten.reciprocal.default(add_tensor_107);  add_tensor_107 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(reciprocal_default_9, 1);  reciprocal_default_9 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(to_dtype_36, mul_tensor_71);  to_dtype_36 = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(mul_tensor_71, 1);  mul_tensor_71 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_37, rsub_scalar_12);  to_dtype_37 = rsub_scalar_12 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(mul_tensor_73, 1);  mul_tensor_73 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(mul_tensor_72, add_tensor_108);  mul_tensor_72 = add_tensor_108 = None
        to_dtype_38 = torch.ops.aten.to.dtype(mul_tensor_74, torch.float32);  mul_tensor_74 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_99, primals_463, primals_461, primals_462, getitem_178, getitem_179, True, 0.001, [True, True, True]);  to_dtype_38 = convolution_default_99 = primals_463 = primals_461 = primals_462 = getitem_178 = getitem_179 = None
        getitem_279 = native_batch_norm_backward_default_9[0]
        getitem_280 = native_batch_norm_backward_default_9[1]
        getitem_281 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_279, add_tensor_72, primals_140, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_279 = add_tensor_72 = primals_140 = None
        getitem_282 = convolution_backward_default_15[0]
        getitem_283 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(getitem_258, getitem_282);  getitem_258 = getitem_282 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_109, convolution_default_98, primals_458, primals_456, primals_457, getitem_175, getitem_176, True, 0.001, [True, True, True]);  convolution_default_98 = primals_458 = primals_456 = primals_457 = getitem_175 = getitem_176 = None
        getitem_285 = native_batch_norm_backward_default_10[0]
        getitem_286 = native_batch_norm_backward_default_10[1]
        getitem_287 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_285, mul_tensor_19, primals_134, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_285 = mul_tensor_19 = primals_134 = None
        getitem_288 = convolution_backward_default_16[0]
        getitem_289 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(getitem_288, silu__default_57);  silu__default_57 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(getitem_288, sigmoid_default_19);  getitem_288 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_75, [2, 3], True);  mul_tensor_75 = None
        to_dtype_39 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_40 = torch.ops.aten.to.dtype(sigmoid_default_19, torch.float32);  sigmoid_default_19 = None
        rsub_scalar_13 = torch.ops.aten.rsub.Scalar(to_dtype_40, 1)
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_40, rsub_scalar_13);  to_dtype_40 = rsub_scalar_13 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_77);  mul_tensor_77 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(to_dtype_39, conj_physical_default_3);  to_dtype_39 = conj_physical_default_3 = None
        to_dtype_41 = torch.ops.aten.to.dtype(mul_tensor_78, torch.float32);  mul_tensor_78 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_41, silu__default_58, primals_136, [891], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_41 = silu__default_58 = primals_136 = None
        getitem_291 = convolution_backward_default_17[0]
        getitem_292 = convolution_backward_default_17[1]
        getitem_293 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_291, torch.float32);  getitem_291 = None
        to_dtype_43 = torch.ops.aten.to.dtype(clone_default_58, torch.float32);  clone_default_58 = None
        neg_default_10 = torch.ops.aten.neg.default(to_dtype_43)
        exp_default_10 = torch.ops.aten.exp.default(neg_default_10);  neg_default_10 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(exp_default_10, 1);  exp_default_10 = None
        reciprocal_default_10 = torch.ops.aten.reciprocal.default(add_tensor_110);  add_tensor_110 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(reciprocal_default_10, 1);  reciprocal_default_10 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(to_dtype_42, mul_tensor_79);  to_dtype_42 = None
        rsub_scalar_14 = torch.ops.aten.rsub.Scalar(mul_tensor_79, 1);  mul_tensor_79 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_43, rsub_scalar_14);  to_dtype_43 = rsub_scalar_14 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(mul_tensor_81, 1);  mul_tensor_81 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(mul_tensor_80, add_tensor_111);  mul_tensor_80 = add_tensor_111 = None
        to_dtype_44 = torch.ops.aten.to.dtype(mul_tensor_82, torch.float32);  mul_tensor_82 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_44, mean_dim_19, primals_138, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_44 = mean_dim_19 = primals_138 = None
        getitem_294 = convolution_backward_default_18[0]
        getitem_295 = convolution_backward_default_18[1]
        getitem_296 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_294, [128, 891, 8, 8]);  getitem_294 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 64);  expand_default_4 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(mul_tensor_76, div_scalar_4);  mul_tensor_76 = div_scalar_4 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_112, torch.float32);  add_tensor_112 = None
        to_dtype_46 = torch.ops.aten.to.dtype(clone_default_57, torch.float32);  clone_default_57 = None
        neg_default_11 = torch.ops.aten.neg.default(to_dtype_46)
        exp_default_11 = torch.ops.aten.exp.default(neg_default_11);  neg_default_11 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(exp_default_11, 1);  exp_default_11 = None
        reciprocal_default_11 = torch.ops.aten.reciprocal.default(add_tensor_113);  add_tensor_113 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(reciprocal_default_11, 1);  reciprocal_default_11 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_45, mul_tensor_83);  to_dtype_45 = None
        rsub_scalar_15 = torch.ops.aten.rsub.Scalar(mul_tensor_83, 1);  mul_tensor_83 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(to_dtype_46, rsub_scalar_15);  to_dtype_46 = rsub_scalar_15 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(mul_tensor_85, 1);  mul_tensor_85 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(mul_tensor_84, add_tensor_114);  mul_tensor_84 = add_tensor_114 = None
        to_dtype_47 = torch.ops.aten.to.dtype(mul_tensor_86, torch.float32);  mul_tensor_86 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_95, primals_453, primals_451, primals_452, getitem_172, getitem_173, True, 0.001, [True, True, True]);  to_dtype_47 = convolution_default_95 = primals_453 = primals_451 = primals_452 = getitem_172 = getitem_173 = None
        getitem_297 = native_batch_norm_backward_default_11[0]
        getitem_298 = native_batch_norm_backward_default_11[1]
        getitem_299 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_297, silu__default_56, primals_132, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 891, [True, True, False]);  getitem_297 = silu__default_56 = primals_132 = None
        getitem_300 = convolution_backward_default_19[0]
        getitem_301 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_300, torch.float32);  getitem_300 = None
        to_dtype_49 = torch.ops.aten.to.dtype(clone_default_56, torch.float32);  clone_default_56 = None
        neg_default_12 = torch.ops.aten.neg.default(to_dtype_49)
        exp_default_12 = torch.ops.aten.exp.default(neg_default_12);  neg_default_12 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(exp_default_12, 1);  exp_default_12 = None
        reciprocal_default_12 = torch.ops.aten.reciprocal.default(add_tensor_115);  add_tensor_115 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(reciprocal_default_12, 1);  reciprocal_default_12 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(to_dtype_48, mul_tensor_87);  to_dtype_48 = None
        rsub_scalar_16 = torch.ops.aten.rsub.Scalar(mul_tensor_87, 1);  mul_tensor_87 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_16);  to_dtype_49 = rsub_scalar_16 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(mul_tensor_89, 1);  mul_tensor_89 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(mul_tensor_88, add_tensor_116);  mul_tensor_88 = add_tensor_116 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_90, torch.float32);  mul_tensor_90 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_94, primals_448, primals_446, primals_447, getitem_169, getitem_170, True, 0.001, [True, True, True]);  to_dtype_50 = convolution_default_94 = primals_448 = primals_446 = primals_447 = getitem_169 = getitem_170 = None
        getitem_303 = native_batch_norm_backward_default_12[0]
        getitem_304 = native_batch_norm_backward_default_12[1]
        getitem_305 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_303, add_tensor_68, primals_133, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_303 = add_tensor_68 = primals_133 = None
        getitem_306 = convolution_backward_default_20[0]
        getitem_307 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(add_tensor_109, getitem_306);  add_tensor_109 = getitem_306 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_117, convolution_default_93, primals_443, primals_441, primals_442, getitem_166, getitem_167, True, 0.001, [True, True, True]);  convolution_default_93 = primals_443 = primals_441 = primals_442 = getitem_166 = getitem_167 = None
        getitem_309 = native_batch_norm_backward_default_13[0]
        getitem_310 = native_batch_norm_backward_default_13[1]
        getitem_311 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_309, mul_tensor_18, primals_127, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_309 = mul_tensor_18 = primals_127 = None
        getitem_312 = convolution_backward_default_21[0]
        getitem_313 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(getitem_312, silu__default_54);  silu__default_54 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(getitem_312, sigmoid_default_18);  getitem_312 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_91, [2, 3], True);  mul_tensor_91 = None
        to_dtype_51 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_52 = torch.ops.aten.to.dtype(sigmoid_default_18, torch.float32);  sigmoid_default_18 = None
        rsub_scalar_17 = torch.ops.aten.rsub.Scalar(to_dtype_52, 1)
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_52, rsub_scalar_17);  to_dtype_52 = rsub_scalar_17 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_93);  mul_tensor_93 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_51, conj_physical_default_4);  to_dtype_51 = conj_physical_default_4 = None
        to_dtype_53 = torch.ops.aten.to.dtype(mul_tensor_94, torch.float32);  mul_tensor_94 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_53, silu__default_55, primals_129, [798], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = silu__default_55 = primals_129 = None
        getitem_315 = convolution_backward_default_22[0]
        getitem_316 = convolution_backward_default_22[1]
        getitem_317 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_315, torch.float32);  getitem_315 = None
        to_dtype_55 = torch.ops.aten.to.dtype(clone_default_55, torch.float32);  clone_default_55 = None
        neg_default_13 = torch.ops.aten.neg.default(to_dtype_55)
        exp_default_13 = torch.ops.aten.exp.default(neg_default_13);  neg_default_13 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(exp_default_13, 1);  exp_default_13 = None
        reciprocal_default_13 = torch.ops.aten.reciprocal.default(add_tensor_118);  add_tensor_118 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(reciprocal_default_13, 1);  reciprocal_default_13 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(to_dtype_54, mul_tensor_95);  to_dtype_54 = None
        rsub_scalar_18 = torch.ops.aten.rsub.Scalar(mul_tensor_95, 1);  mul_tensor_95 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_55, rsub_scalar_18);  to_dtype_55 = rsub_scalar_18 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(mul_tensor_97, 1);  mul_tensor_97 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(mul_tensor_96, add_tensor_119);  mul_tensor_96 = add_tensor_119 = None
        to_dtype_56 = torch.ops.aten.to.dtype(mul_tensor_98, torch.float32);  mul_tensor_98 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_56, mean_dim_18, primals_131, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_56 = mean_dim_18 = primals_131 = None
        getitem_318 = convolution_backward_default_23[0]
        getitem_319 = convolution_backward_default_23[1]
        getitem_320 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_318, [128, 798, 8, 8]);  getitem_318 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 64);  expand_default_5 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(mul_tensor_92, div_scalar_5);  mul_tensor_92 = div_scalar_5 = None
        to_dtype_57 = torch.ops.aten.to.dtype(add_tensor_120, torch.float32);  add_tensor_120 = None
        to_dtype_58 = torch.ops.aten.to.dtype(clone_default_54, torch.float32);  clone_default_54 = None
        neg_default_14 = torch.ops.aten.neg.default(to_dtype_58)
        exp_default_14 = torch.ops.aten.exp.default(neg_default_14);  neg_default_14 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(exp_default_14, 1);  exp_default_14 = None
        reciprocal_default_14 = torch.ops.aten.reciprocal.default(add_tensor_121);  add_tensor_121 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(reciprocal_default_14, 1);  reciprocal_default_14 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(to_dtype_57, mul_tensor_99);  to_dtype_57 = None
        rsub_scalar_19 = torch.ops.aten.rsub.Scalar(mul_tensor_99, 1);  mul_tensor_99 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_58, rsub_scalar_19);  to_dtype_58 = rsub_scalar_19 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(mul_tensor_101, 1);  mul_tensor_101 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(mul_tensor_100, add_tensor_122);  mul_tensor_100 = add_tensor_122 = None
        to_dtype_59 = torch.ops.aten.to.dtype(mul_tensor_102, torch.float32);  mul_tensor_102 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_90, primals_438, primals_436, primals_437, getitem_163, getitem_164, True, 0.001, [True, True, True]);  to_dtype_59 = convolution_default_90 = primals_438 = primals_436 = primals_437 = getitem_163 = getitem_164 = None
        getitem_321 = native_batch_norm_backward_default_14[0]
        getitem_322 = native_batch_norm_backward_default_14[1]
        getitem_323 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_321, silu__default_53, primals_125, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 798, [True, True, False]);  getitem_321 = silu__default_53 = primals_125 = None
        getitem_324 = convolution_backward_default_24[0]
        getitem_325 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_324, torch.float32);  getitem_324 = None
        to_dtype_61 = torch.ops.aten.to.dtype(clone_default_53, torch.float32);  clone_default_53 = None
        neg_default_15 = torch.ops.aten.neg.default(to_dtype_61)
        exp_default_15 = torch.ops.aten.exp.default(neg_default_15);  neg_default_15 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(exp_default_15, 1);  exp_default_15 = None
        reciprocal_default_15 = torch.ops.aten.reciprocal.default(add_tensor_123);  add_tensor_123 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(reciprocal_default_15, 1);  reciprocal_default_15 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(to_dtype_60, mul_tensor_103);  to_dtype_60 = None
        rsub_scalar_20 = torch.ops.aten.rsub.Scalar(mul_tensor_103, 1);  mul_tensor_103 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_61, rsub_scalar_20);  to_dtype_61 = rsub_scalar_20 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(mul_tensor_105, 1);  mul_tensor_105 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(mul_tensor_104, add_tensor_124);  mul_tensor_104 = add_tensor_124 = None
        to_dtype_62 = torch.ops.aten.to.dtype(mul_tensor_106, torch.float32);  mul_tensor_106 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_89, primals_433, primals_431, primals_432, getitem_160, getitem_161, True, 0.001, [True, True, True]);  to_dtype_62 = convolution_default_89 = primals_433 = primals_431 = primals_432 = getitem_160 = getitem_161 = None
        getitem_327 = native_batch_norm_backward_default_15[0]
        getitem_328 = native_batch_norm_backward_default_15[1]
        getitem_329 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_327, add_tensor_64, primals_126, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_327 = add_tensor_64 = primals_126 = None
        getitem_330 = convolution_backward_default_25[0]
        getitem_331 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(add_tensor_117, getitem_330);  add_tensor_117 = getitem_330 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_125, convolution_default_88, primals_428, primals_426, primals_427, getitem_157, getitem_158, True, 0.001, [True, True, True]);  convolution_default_88 = primals_428 = primals_426 = primals_427 = getitem_157 = getitem_158 = None
        getitem_333 = native_batch_norm_backward_default_16[0]
        getitem_334 = native_batch_norm_backward_default_16[1]
        getitem_335 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_333, mul_tensor_17, primals_120, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_333 = mul_tensor_17 = primals_120 = None
        getitem_336 = convolution_backward_default_26[0]
        getitem_337 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(getitem_336, silu__default_51);  silu__default_51 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(getitem_336, sigmoid_default_17);  getitem_336 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_107, [2, 3], True);  mul_tensor_107 = None
        to_dtype_63 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_17, torch.float32);  sigmoid_default_17 = None
        rsub_scalar_21 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_21);  to_dtype_64 = rsub_scalar_21 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_109);  mul_tensor_109 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_5);  to_dtype_63 = conj_physical_default_5 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_110, torch.float32);  mul_tensor_110 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_65, silu__default_52, primals_122, [806], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = silu__default_52 = primals_122 = None
        getitem_339 = convolution_backward_default_27[0]
        getitem_340 = convolution_backward_default_27[1]
        getitem_341 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_339, torch.float32);  getitem_339 = None
        to_dtype_67 = torch.ops.aten.to.dtype(clone_default_52, torch.float32);  clone_default_52 = None
        neg_default_16 = torch.ops.aten.neg.default(to_dtype_67)
        exp_default_16 = torch.ops.aten.exp.default(neg_default_16);  neg_default_16 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(exp_default_16, 1);  exp_default_16 = None
        reciprocal_default_16 = torch.ops.aten.reciprocal.default(add_tensor_126);  add_tensor_126 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(reciprocal_default_16, 1);  reciprocal_default_16 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_66, mul_tensor_111);  to_dtype_66 = None
        rsub_scalar_22 = torch.ops.aten.rsub.Scalar(mul_tensor_111, 1);  mul_tensor_111 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(to_dtype_67, rsub_scalar_22);  to_dtype_67 = rsub_scalar_22 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(mul_tensor_113, 1);  mul_tensor_113 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(mul_tensor_112, add_tensor_127);  mul_tensor_112 = add_tensor_127 = None
        to_dtype_68 = torch.ops.aten.to.dtype(mul_tensor_114, torch.float32);  mul_tensor_114 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(to_dtype_68, mean_dim_17, primals_124, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = mean_dim_17 = primals_124 = None
        getitem_342 = convolution_backward_default_28[0]
        getitem_343 = convolution_backward_default_28[1]
        getitem_344 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_342, [128, 806, 8, 8]);  getitem_342 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 64);  expand_default_6 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(mul_tensor_108, div_scalar_6);  mul_tensor_108 = div_scalar_6 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_128, torch.float32);  add_tensor_128 = None
        to_dtype_70 = torch.ops.aten.to.dtype(clone_default_51, torch.float32);  clone_default_51 = None
        neg_default_17 = torch.ops.aten.neg.default(to_dtype_70)
        exp_default_17 = torch.ops.aten.exp.default(neg_default_17);  neg_default_17 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(exp_default_17, 1);  exp_default_17 = None
        reciprocal_default_17 = torch.ops.aten.reciprocal.default(add_tensor_129);  add_tensor_129 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(reciprocal_default_17, 1);  reciprocal_default_17 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(to_dtype_69, mul_tensor_115);  to_dtype_69 = None
        rsub_scalar_23 = torch.ops.aten.rsub.Scalar(mul_tensor_115, 1);  mul_tensor_115 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_70, rsub_scalar_23);  to_dtype_70 = rsub_scalar_23 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(mul_tensor_117, 1);  mul_tensor_117 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(mul_tensor_116, add_tensor_130);  mul_tensor_116 = add_tensor_130 = None
        to_dtype_71 = torch.ops.aten.to.dtype(mul_tensor_118, torch.float32);  mul_tensor_118 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_85, primals_423, primals_421, primals_422, getitem_154, getitem_155, True, 0.001, [True, True, True]);  to_dtype_71 = convolution_default_85 = primals_423 = primals_421 = primals_422 = getitem_154 = getitem_155 = None
        getitem_345 = native_batch_norm_backward_default_17[0]
        getitem_346 = native_batch_norm_backward_default_17[1]
        getitem_347 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_345, silu__default_50, primals_118, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 806, [True, True, False]);  getitem_345 = silu__default_50 = primals_118 = None
        getitem_348 = convolution_backward_default_29[0]
        getitem_349 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_348, torch.float32);  getitem_348 = None
        to_dtype_73 = torch.ops.aten.to.dtype(clone_default_50, torch.float32);  clone_default_50 = None
        neg_default_18 = torch.ops.aten.neg.default(to_dtype_73)
        exp_default_18 = torch.ops.aten.exp.default(neg_default_18);  neg_default_18 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(exp_default_18, 1);  exp_default_18 = None
        reciprocal_default_18 = torch.ops.aten.reciprocal.default(add_tensor_131);  add_tensor_131 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(reciprocal_default_18, 1);  reciprocal_default_18 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_72, mul_tensor_119);  to_dtype_72 = None
        rsub_scalar_24 = torch.ops.aten.rsub.Scalar(mul_tensor_119, 1);  mul_tensor_119 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_73, rsub_scalar_24);  to_dtype_73 = rsub_scalar_24 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(mul_tensor_121, 1);  mul_tensor_121 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(mul_tensor_120, add_tensor_132);  mul_tensor_120 = add_tensor_132 = None
        to_dtype_74 = torch.ops.aten.to.dtype(mul_tensor_122, torch.float32);  mul_tensor_122 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_84, primals_418, primals_416, primals_417, getitem_151, getitem_152, True, 0.001, [True, True, True]);  to_dtype_74 = convolution_default_84 = primals_418 = primals_416 = primals_417 = getitem_151 = getitem_152 = None
        getitem_351 = native_batch_norm_backward_default_18[0]
        getitem_352 = native_batch_norm_backward_default_18[1]
        getitem_353 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_351, getitem_147, primals_119, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_351 = getitem_147 = primals_119 = None
        getitem_354 = convolution_backward_default_30[0]
        getitem_355 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_125, getitem_354);  add_tensor_125 = getitem_354 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_133, convolution_default_83, primals_413, primals_411, primals_412, getitem_148, getitem_149, True, 0.001, [True, True, True]);  add_tensor_133 = convolution_default_83 = primals_413 = primals_411 = primals_412 = getitem_148 = getitem_149 = None
        getitem_357 = native_batch_norm_backward_default_19[0]
        getitem_358 = native_batch_norm_backward_default_19[1]
        getitem_359 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_357, mul_tensor_16, primals_113, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_357 = mul_tensor_16 = primals_113 = None
        getitem_360 = convolution_backward_default_31[0]
        getitem_361 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(getitem_360, silu__default_48);  silu__default_48 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(getitem_360, sigmoid_default_16);  getitem_360 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_123, [2, 3], True);  mul_tensor_123 = None
        to_dtype_75 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_76 = torch.ops.aten.to.dtype(sigmoid_default_16, torch.float32);  sigmoid_default_16 = None
        rsub_scalar_25 = torch.ops.aten.rsub.Scalar(to_dtype_76, 1)
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_76, rsub_scalar_25);  to_dtype_76 = rsub_scalar_25 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_125);  mul_tensor_125 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_75, conj_physical_default_6);  to_dtype_75 = conj_physical_default_6 = None
        to_dtype_77 = torch.ops.aten.to.dtype(mul_tensor_126, torch.float32);  mul_tensor_126 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(to_dtype_77, silu__default_49, primals_115, [637], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_77 = silu__default_49 = primals_115 = None
        getitem_363 = convolution_backward_default_32[0]
        getitem_364 = convolution_backward_default_32[1]
        getitem_365 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_363, torch.float32);  getitem_363 = None
        to_dtype_79 = torch.ops.aten.to.dtype(clone_default_49, torch.float32);  clone_default_49 = None
        neg_default_19 = torch.ops.aten.neg.default(to_dtype_79)
        exp_default_19 = torch.ops.aten.exp.default(neg_default_19);  neg_default_19 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(exp_default_19, 1);  exp_default_19 = None
        reciprocal_default_19 = torch.ops.aten.reciprocal.default(add_tensor_134);  add_tensor_134 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(reciprocal_default_19, 1);  reciprocal_default_19 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(to_dtype_78, mul_tensor_127);  to_dtype_78 = None
        rsub_scalar_26 = torch.ops.aten.rsub.Scalar(mul_tensor_127, 1);  mul_tensor_127 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_26);  to_dtype_79 = rsub_scalar_26 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(mul_tensor_129, 1);  mul_tensor_129 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(mul_tensor_128, add_tensor_135);  mul_tensor_128 = add_tensor_135 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_130, torch.float32);  mul_tensor_130 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(to_dtype_80, mean_dim_16, primals_117, [27], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = mean_dim_16 = primals_117 = None
        getitem_366 = convolution_backward_default_33[0]
        getitem_367 = convolution_backward_default_33[1]
        getitem_368 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_366, [128, 637, 8, 8]);  getitem_366 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 64);  expand_default_7 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(mul_tensor_124, div_scalar_7);  mul_tensor_124 = div_scalar_7 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_136, torch.float32);  add_tensor_136 = None
        to_dtype_82 = torch.ops.aten.to.dtype(clone_default_48, torch.float32);  clone_default_48 = None
        neg_default_20 = torch.ops.aten.neg.default(to_dtype_82)
        exp_default_20 = torch.ops.aten.exp.default(neg_default_20);  neg_default_20 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(exp_default_20, 1);  exp_default_20 = None
        reciprocal_default_20 = torch.ops.aten.reciprocal.default(add_tensor_137);  add_tensor_137 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(reciprocal_default_20, 1);  reciprocal_default_20 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(to_dtype_81, mul_tensor_131);  to_dtype_81 = None
        rsub_scalar_27 = torch.ops.aten.rsub.Scalar(mul_tensor_131, 1);  mul_tensor_131 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_82, rsub_scalar_27);  to_dtype_82 = rsub_scalar_27 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(mul_tensor_133, 1);  mul_tensor_133 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(mul_tensor_132, add_tensor_138);  mul_tensor_132 = add_tensor_138 = None
        to_dtype_83 = torch.ops.aten.to.dtype(mul_tensor_134, torch.float32);  mul_tensor_134 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_80, primals_408, primals_406, primals_407, getitem_145, getitem_146, True, 0.001, [True, True, True]);  to_dtype_83 = convolution_default_80 = primals_408 = primals_406 = primals_407 = getitem_145 = getitem_146 = None
        getitem_369 = native_batch_norm_backward_default_20[0]
        getitem_370 = native_batch_norm_backward_default_20[1]
        getitem_371 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_369, constant_pad_nd_default_4, primals_111, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 637, [True, True, False]);  getitem_369 = constant_pad_nd_default_4 = primals_111 = None
        getitem_372 = convolution_backward_default_34[0]
        getitem_373 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(getitem_372, [-2, -2, -2, -2]);  getitem_372 = None
        to_dtype_84 = torch.ops.aten.to.dtype(constant_pad_nd_default_5, torch.float32);  constant_pad_nd_default_5 = None
        to_dtype_85 = torch.ops.aten.to.dtype(clone_default_47, torch.float32);  clone_default_47 = None
        neg_default_21 = torch.ops.aten.neg.default(to_dtype_85)
        exp_default_21 = torch.ops.aten.exp.default(neg_default_21);  neg_default_21 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(exp_default_21, 1);  exp_default_21 = None
        reciprocal_default_21 = torch.ops.aten.reciprocal.default(add_tensor_139);  add_tensor_139 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(reciprocal_default_21, 1);  reciprocal_default_21 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(to_dtype_84, mul_tensor_135);  to_dtype_84 = None
        rsub_scalar_28 = torch.ops.aten.rsub.Scalar(mul_tensor_135, 1);  mul_tensor_135 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_85, rsub_scalar_28);  to_dtype_85 = rsub_scalar_28 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(mul_tensor_137, 1);  mul_tensor_137 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(mul_tensor_136, add_tensor_140);  mul_tensor_136 = add_tensor_140 = None
        to_dtype_86 = torch.ops.aten.to.dtype(mul_tensor_138, torch.float32);  mul_tensor_138 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_79, primals_403, primals_401, primals_402, getitem_142, getitem_143, True, 0.001, [True, True, True]);  to_dtype_86 = convolution_default_79 = primals_403 = primals_401 = primals_402 = getitem_142 = getitem_143 = None
        getitem_375 = native_batch_norm_backward_default_21[0]
        getitem_376 = native_batch_norm_backward_default_21[1]
        getitem_377 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_375, add_tensor_57, primals_112, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_375 = add_tensor_57 = primals_112 = None
        getitem_378 = convolution_backward_default_35[0]
        getitem_379 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(getitem_378, convolution_default_78, primals_398, primals_396, primals_397, getitem_139, getitem_140, True, 0.001, [True, True, True]);  convolution_default_78 = primals_398 = primals_396 = primals_397 = getitem_139 = getitem_140 = None
        getitem_381 = native_batch_norm_backward_default_22[0]
        getitem_382 = native_batch_norm_backward_default_22[1]
        getitem_383 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_381, mul_tensor_15, primals_106, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_381 = mul_tensor_15 = primals_106 = None
        getitem_384 = convolution_backward_default_36[0]
        getitem_385 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(getitem_384, silu__default_45);  silu__default_45 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(getitem_384, sigmoid_default_15);  getitem_384 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_139, [2, 3], True);  mul_tensor_139 = None
        to_dtype_87 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_88 = torch.ops.aten.to.dtype(sigmoid_default_15, torch.float32);  sigmoid_default_15 = None
        rsub_scalar_29 = torch.ops.aten.rsub.Scalar(to_dtype_88, 1)
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_88, rsub_scalar_29);  to_dtype_88 = rsub_scalar_29 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_141);  mul_tensor_141 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_87, conj_physical_default_7);  to_dtype_87 = conj_physical_default_7 = None
        to_dtype_89 = torch.ops.aten.to.dtype(mul_tensor_142, torch.float32);  mul_tensor_142 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_89, silu__default_46, primals_108, [213], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_89 = silu__default_46 = primals_108 = None
        getitem_387 = convolution_backward_default_37[0]
        getitem_388 = convolution_backward_default_37[1]
        getitem_389 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_387, torch.float32);  getitem_387 = None
        to_dtype_91 = torch.ops.aten.to.dtype(clone_default_46, torch.float32);  clone_default_46 = None
        neg_default_22 = torch.ops.aten.neg.default(to_dtype_91)
        exp_default_22 = torch.ops.aten.exp.default(neg_default_22);  neg_default_22 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(exp_default_22, 1);  exp_default_22 = None
        reciprocal_default_22 = torch.ops.aten.reciprocal.default(add_tensor_141);  add_tensor_141 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(reciprocal_default_22, 1);  reciprocal_default_22 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_90, mul_tensor_143);  to_dtype_90 = None
        rsub_scalar_30 = torch.ops.aten.rsub.Scalar(mul_tensor_143, 1);  mul_tensor_143 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_91, rsub_scalar_30);  to_dtype_91 = rsub_scalar_30 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(mul_tensor_145, 1);  mul_tensor_145 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(mul_tensor_144, add_tensor_142);  mul_tensor_144 = add_tensor_142 = None
        to_dtype_92 = torch.ops.aten.to.dtype(mul_tensor_146, torch.float32);  mul_tensor_146 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(to_dtype_92, mean_dim_15, primals_110, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_92 = mean_dim_15 = primals_110 = None
        getitem_390 = convolution_backward_default_38[0]
        getitem_391 = convolution_backward_default_38[1]
        getitem_392 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_390, [128, 213, 15, 15]);  getitem_390 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 225);  expand_default_8 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(mul_tensor_140, div_scalar_8);  mul_tensor_140 = div_scalar_8 = None
        to_dtype_93 = torch.ops.aten.to.dtype(add_tensor_143, torch.float32);  add_tensor_143 = None
        to_dtype_94 = torch.ops.aten.to.dtype(clone_default_45, torch.float32);  clone_default_45 = None
        neg_default_23 = torch.ops.aten.neg.default(to_dtype_94)
        exp_default_23 = torch.ops.aten.exp.default(neg_default_23);  neg_default_23 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(exp_default_23, 1);  exp_default_23 = None
        reciprocal_default_23 = torch.ops.aten.reciprocal.default(add_tensor_144);  add_tensor_144 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(reciprocal_default_23, 1);  reciprocal_default_23 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(to_dtype_93, mul_tensor_147);  to_dtype_93 = None
        rsub_scalar_31 = torch.ops.aten.rsub.Scalar(mul_tensor_147, 1);  mul_tensor_147 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_31);  to_dtype_94 = rsub_scalar_31 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(mul_tensor_149, 1);  mul_tensor_149 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(mul_tensor_148, add_tensor_145);  mul_tensor_148 = add_tensor_145 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_150, torch.float32);  mul_tensor_150 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_75, primals_393, primals_391, primals_392, getitem_136, getitem_137, True, 0.001, [True, True, True]);  to_dtype_95 = convolution_default_75 = primals_393 = primals_391 = primals_392 = getitem_136 = getitem_137 = None
        getitem_393 = native_batch_norm_backward_default_23[0]
        getitem_394 = native_batch_norm_backward_default_23[1]
        getitem_395 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_393, silu__default_44, primals_104, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 213, [True, True, False]);  getitem_393 = silu__default_44 = primals_104 = None
        getitem_396 = convolution_backward_default_39[0]
        getitem_397 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_396, torch.float32);  getitem_396 = None
        to_dtype_97 = torch.ops.aten.to.dtype(clone_default_44, torch.float32);  clone_default_44 = None
        neg_default_24 = torch.ops.aten.neg.default(to_dtype_97)
        exp_default_24 = torch.ops.aten.exp.default(neg_default_24);  neg_default_24 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(exp_default_24, 1);  exp_default_24 = None
        reciprocal_default_24 = torch.ops.aten.reciprocal.default(add_tensor_146);  add_tensor_146 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(reciprocal_default_24, 1);  reciprocal_default_24 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_96, mul_tensor_151);  to_dtype_96 = None
        rsub_scalar_32 = torch.ops.aten.rsub.Scalar(mul_tensor_151, 1);  mul_tensor_151 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_97, rsub_scalar_32);  to_dtype_97 = rsub_scalar_32 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(mul_tensor_153, 1);  mul_tensor_153 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(mul_tensor_152, add_tensor_147);  mul_tensor_152 = add_tensor_147 = None
        to_dtype_98 = torch.ops.aten.to.dtype(mul_tensor_154, torch.float32);  mul_tensor_154 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_74, primals_388, primals_386, primals_387, getitem_133, getitem_134, True, 0.001, [True, True, True]);  to_dtype_98 = convolution_default_74 = primals_388 = primals_386 = primals_387 = getitem_133 = getitem_134 = None
        getitem_399 = native_batch_norm_backward_default_24[0]
        getitem_400 = native_batch_norm_backward_default_24[1]
        getitem_401 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_399, add_tensor_53, primals_105, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_399 = add_tensor_53 = primals_105 = None
        getitem_402 = convolution_backward_default_40[0]
        getitem_403 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(getitem_378, getitem_402);  getitem_378 = getitem_402 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_148, convolution_default_73, primals_383, primals_381, primals_382, getitem_130, getitem_131, True, 0.001, [True, True, True]);  convolution_default_73 = primals_383 = primals_381 = primals_382 = getitem_130 = getitem_131 = None
        getitem_405 = native_batch_norm_backward_default_25[0]
        getitem_406 = native_batch_norm_backward_default_25[1]
        getitem_407 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_405, mul_tensor_14, primals_99, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_405 = mul_tensor_14 = primals_99 = None
        getitem_408 = convolution_backward_default_41[0]
        getitem_409 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(getitem_408, silu__default_42);  silu__default_42 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(getitem_408, sigmoid_default_14);  getitem_408 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_155, [2, 3], True);  mul_tensor_155 = None
        to_dtype_99 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_100 = torch.ops.aten.to.dtype(sigmoid_default_14, torch.float32);  sigmoid_default_14 = None
        rsub_scalar_33 = torch.ops.aten.rsub.Scalar(to_dtype_100, 1)
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_100, rsub_scalar_33);  to_dtype_100 = rsub_scalar_33 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_157);  mul_tensor_157 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(to_dtype_99, conj_physical_default_8);  to_dtype_99 = conj_physical_default_8 = None
        to_dtype_101 = torch.ops.aten.to.dtype(mul_tensor_158, torch.float32);  mul_tensor_158 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(to_dtype_101, silu__default_43, primals_101, [160], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_101 = silu__default_43 = primals_101 = None
        getitem_411 = convolution_backward_default_42[0]
        getitem_412 = convolution_backward_default_42[1]
        getitem_413 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_411, torch.float32);  getitem_411 = None
        to_dtype_103 = torch.ops.aten.to.dtype(clone_default_43, torch.float32);  clone_default_43 = None
        neg_default_25 = torch.ops.aten.neg.default(to_dtype_103)
        exp_default_25 = torch.ops.aten.exp.default(neg_default_25);  neg_default_25 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(exp_default_25, 1);  exp_default_25 = None
        reciprocal_default_25 = torch.ops.aten.reciprocal.default(add_tensor_149);  add_tensor_149 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(reciprocal_default_25, 1);  reciprocal_default_25 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(to_dtype_102, mul_tensor_159);  to_dtype_102 = None
        rsub_scalar_34 = torch.ops.aten.rsub.Scalar(mul_tensor_159, 1);  mul_tensor_159 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(to_dtype_103, rsub_scalar_34);  to_dtype_103 = rsub_scalar_34 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(mul_tensor_161, 1);  mul_tensor_161 = None
        mul_tensor_162 = torch.ops.aten.mul.Tensor(mul_tensor_160, add_tensor_150);  mul_tensor_160 = add_tensor_150 = None
        to_dtype_104 = torch.ops.aten.to.dtype(mul_tensor_162, torch.float32);  mul_tensor_162 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(to_dtype_104, mean_dim_14, primals_103, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_104 = mean_dim_14 = primals_103 = None
        getitem_414 = convolution_backward_default_43[0]
        getitem_415 = convolution_backward_default_43[1]
        getitem_416 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        expand_default_9 = torch.ops.aten.expand.default(getitem_414, [128, 160, 15, 15]);  getitem_414 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_9, 225);  expand_default_9 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(mul_tensor_156, div_scalar_9);  mul_tensor_156 = div_scalar_9 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_151, torch.float32);  add_tensor_151 = None
        to_dtype_106 = torch.ops.aten.to.dtype(clone_default_42, torch.float32);  clone_default_42 = None
        neg_default_26 = torch.ops.aten.neg.default(to_dtype_106)
        exp_default_26 = torch.ops.aten.exp.default(neg_default_26);  neg_default_26 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(exp_default_26, 1);  exp_default_26 = None
        reciprocal_default_26 = torch.ops.aten.reciprocal.default(add_tensor_152);  add_tensor_152 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(reciprocal_default_26, 1);  reciprocal_default_26 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(to_dtype_105, mul_tensor_163);  to_dtype_105 = None
        rsub_scalar_35 = torch.ops.aten.rsub.Scalar(mul_tensor_163, 1);  mul_tensor_163 = None
        mul_tensor_165 = torch.ops.aten.mul.Tensor(to_dtype_106, rsub_scalar_35);  to_dtype_106 = rsub_scalar_35 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(mul_tensor_165, 1);  mul_tensor_165 = None
        mul_tensor_166 = torch.ops.aten.mul.Tensor(mul_tensor_164, add_tensor_153);  mul_tensor_164 = add_tensor_153 = None
        to_dtype_107 = torch.ops.aten.to.dtype(mul_tensor_166, torch.float32);  mul_tensor_166 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_70, primals_378, primals_376, primals_377, getitem_127, getitem_128, True, 0.001, [True, True, True]);  to_dtype_107 = convolution_default_70 = primals_378 = primals_376 = primals_377 = getitem_127 = getitem_128 = None
        getitem_417 = native_batch_norm_backward_default_26[0]
        getitem_418 = native_batch_norm_backward_default_26[1]
        getitem_419 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_417, silu__default_41, primals_97, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 160, [True, True, False]);  getitem_417 = silu__default_41 = primals_97 = None
        getitem_420 = convolution_backward_default_44[0]
        getitem_421 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_420, torch.float32);  getitem_420 = None
        to_dtype_109 = torch.ops.aten.to.dtype(clone_default_41, torch.float32);  clone_default_41 = None
        neg_default_27 = torch.ops.aten.neg.default(to_dtype_109)
        exp_default_27 = torch.ops.aten.exp.default(neg_default_27);  neg_default_27 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(exp_default_27, 1);  exp_default_27 = None
        reciprocal_default_27 = torch.ops.aten.reciprocal.default(add_tensor_154);  add_tensor_154 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(reciprocal_default_27, 1);  reciprocal_default_27 = None
        mul_tensor_168 = torch.ops.aten.mul.Tensor(to_dtype_108, mul_tensor_167);  to_dtype_108 = None
        rsub_scalar_36 = torch.ops.aten.rsub.Scalar(mul_tensor_167, 1);  mul_tensor_167 = None
        mul_tensor_169 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_36);  to_dtype_109 = rsub_scalar_36 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(mul_tensor_169, 1);  mul_tensor_169 = None
        mul_tensor_170 = torch.ops.aten.mul.Tensor(mul_tensor_168, add_tensor_155);  mul_tensor_168 = add_tensor_155 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_170, torch.float32);  mul_tensor_170 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_69, primals_373, primals_371, primals_372, getitem_124, getitem_125, True, 0.001, [True, True, True]);  to_dtype_110 = convolution_default_69 = primals_373 = primals_371 = primals_372 = getitem_124 = getitem_125 = None
        getitem_423 = native_batch_norm_backward_default_27[0]
        getitem_424 = native_batch_norm_backward_default_27[1]
        getitem_425 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_423, add_tensor_49, primals_98, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_423 = add_tensor_49 = primals_98 = None
        getitem_426 = convolution_backward_default_45[0]
        getitem_427 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(add_tensor_148, getitem_426);  add_tensor_148 = getitem_426 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_156, convolution_default_68, primals_368, primals_366, primals_367, getitem_121, getitem_122, True, 0.001, [True, True, True]);  convolution_default_68 = primals_368 = primals_366 = primals_367 = getitem_121 = getitem_122 = None
        getitem_429 = native_batch_norm_backward_default_28[0]
        getitem_430 = native_batch_norm_backward_default_28[1]
        getitem_431 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_429, mul_tensor_13, primals_92, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_429 = mul_tensor_13 = primals_92 = None
        getitem_432 = convolution_backward_default_46[0]
        getitem_433 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        mul_tensor_171 = torch.ops.aten.mul.Tensor(getitem_432, silu__default_39);  silu__default_39 = None
        mul_tensor_172 = torch.ops.aten.mul.Tensor(getitem_432, sigmoid_default_13);  getitem_432 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_171, [2, 3], True);  mul_tensor_171 = None
        to_dtype_111 = torch.ops.aten.to.dtype(sum_dim_int_list_10, torch.float32);  sum_dim_int_list_10 = None
        to_dtype_112 = torch.ops.aten.to.dtype(sigmoid_default_13, torch.float32);  sigmoid_default_13 = None
        rsub_scalar_37 = torch.ops.aten.rsub.Scalar(to_dtype_112, 1)
        mul_tensor_173 = torch.ops.aten.mul.Tensor(to_dtype_112, rsub_scalar_37);  to_dtype_112 = rsub_scalar_37 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_173);  mul_tensor_173 = None
        mul_tensor_174 = torch.ops.aten.mul.Tensor(to_dtype_111, conj_physical_default_9);  to_dtype_111 = conj_physical_default_9 = None
        to_dtype_113 = torch.ops.aten.to.dtype(mul_tensor_174, torch.float32);  mul_tensor_174 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(to_dtype_113, silu__default_40, primals_94, [201], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = silu__default_40 = primals_94 = None
        getitem_435 = convolution_backward_default_47[0]
        getitem_436 = convolution_backward_default_47[1]
        getitem_437 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_435, torch.float32);  getitem_435 = None
        to_dtype_115 = torch.ops.aten.to.dtype(clone_default_40, torch.float32);  clone_default_40 = None
        neg_default_28 = torch.ops.aten.neg.default(to_dtype_115)
        exp_default_28 = torch.ops.aten.exp.default(neg_default_28);  neg_default_28 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(exp_default_28, 1);  exp_default_28 = None
        reciprocal_default_28 = torch.ops.aten.reciprocal.default(add_tensor_157);  add_tensor_157 = None
        mul_tensor_175 = torch.ops.aten.mul.Tensor(reciprocal_default_28, 1);  reciprocal_default_28 = None
        mul_tensor_176 = torch.ops.aten.mul.Tensor(to_dtype_114, mul_tensor_175);  to_dtype_114 = None
        rsub_scalar_38 = torch.ops.aten.rsub.Scalar(mul_tensor_175, 1);  mul_tensor_175 = None
        mul_tensor_177 = torch.ops.aten.mul.Tensor(to_dtype_115, rsub_scalar_38);  to_dtype_115 = rsub_scalar_38 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(mul_tensor_177, 1);  mul_tensor_177 = None
        mul_tensor_178 = torch.ops.aten.mul.Tensor(mul_tensor_176, add_tensor_158);  mul_tensor_176 = add_tensor_158 = None
        to_dtype_116 = torch.ops.aten.to.dtype(mul_tensor_178, torch.float32);  mul_tensor_178 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(to_dtype_116, mean_dim_13, primals_96, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_116 = mean_dim_13 = primals_96 = None
        getitem_438 = convolution_backward_default_48[0]
        getitem_439 = convolution_backward_default_48[1]
        getitem_440 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        expand_default_10 = torch.ops.aten.expand.default(getitem_438, [128, 201, 15, 15]);  getitem_438 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_10, 225);  expand_default_10 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(mul_tensor_172, div_scalar_10);  mul_tensor_172 = div_scalar_10 = None
        to_dtype_117 = torch.ops.aten.to.dtype(add_tensor_159, torch.float32);  add_tensor_159 = None
        to_dtype_118 = torch.ops.aten.to.dtype(clone_default_39, torch.float32);  clone_default_39 = None
        neg_default_29 = torch.ops.aten.neg.default(to_dtype_118)
        exp_default_29 = torch.ops.aten.exp.default(neg_default_29);  neg_default_29 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(exp_default_29, 1);  exp_default_29 = None
        reciprocal_default_29 = torch.ops.aten.reciprocal.default(add_tensor_160);  add_tensor_160 = None
        mul_tensor_179 = torch.ops.aten.mul.Tensor(reciprocal_default_29, 1);  reciprocal_default_29 = None
        mul_tensor_180 = torch.ops.aten.mul.Tensor(to_dtype_117, mul_tensor_179);  to_dtype_117 = None
        rsub_scalar_39 = torch.ops.aten.rsub.Scalar(mul_tensor_179, 1);  mul_tensor_179 = None
        mul_tensor_181 = torch.ops.aten.mul.Tensor(to_dtype_118, rsub_scalar_39);  to_dtype_118 = rsub_scalar_39 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(mul_tensor_181, 1);  mul_tensor_181 = None
        mul_tensor_182 = torch.ops.aten.mul.Tensor(mul_tensor_180, add_tensor_161);  mul_tensor_180 = add_tensor_161 = None
        to_dtype_119 = torch.ops.aten.to.dtype(mul_tensor_182, torch.float32);  mul_tensor_182 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_65, primals_363, primals_361, primals_362, getitem_118, getitem_119, True, 0.001, [True, True, True]);  to_dtype_119 = convolution_default_65 = primals_363 = primals_361 = primals_362 = getitem_118 = getitem_119 = None
        getitem_441 = native_batch_norm_backward_default_29[0]
        getitem_442 = native_batch_norm_backward_default_29[1]
        getitem_443 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_441, silu__default_38, primals_90, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 201, [True, True, False]);  getitem_441 = silu__default_38 = primals_90 = None
        getitem_444 = convolution_backward_default_49[0]
        getitem_445 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_444, torch.float32);  getitem_444 = None
        to_dtype_121 = torch.ops.aten.to.dtype(clone_default_38, torch.float32);  clone_default_38 = None
        neg_default_30 = torch.ops.aten.neg.default(to_dtype_121)
        exp_default_30 = torch.ops.aten.exp.default(neg_default_30);  neg_default_30 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(exp_default_30, 1);  exp_default_30 = None
        reciprocal_default_30 = torch.ops.aten.reciprocal.default(add_tensor_162);  add_tensor_162 = None
        mul_tensor_183 = torch.ops.aten.mul.Tensor(reciprocal_default_30, 1);  reciprocal_default_30 = None
        mul_tensor_184 = torch.ops.aten.mul.Tensor(to_dtype_120, mul_tensor_183);  to_dtype_120 = None
        rsub_scalar_40 = torch.ops.aten.rsub.Scalar(mul_tensor_183, 1);  mul_tensor_183 = None
        mul_tensor_185 = torch.ops.aten.mul.Tensor(to_dtype_121, rsub_scalar_40);  to_dtype_121 = rsub_scalar_40 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(mul_tensor_185, 1);  mul_tensor_185 = None
        mul_tensor_186 = torch.ops.aten.mul.Tensor(mul_tensor_184, add_tensor_163);  mul_tensor_184 = add_tensor_163 = None
        to_dtype_122 = torch.ops.aten.to.dtype(mul_tensor_186, torch.float32);  mul_tensor_186 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_64, primals_358, primals_356, primals_357, getitem_115, getitem_116, True, 0.001, [True, True, True]);  to_dtype_122 = convolution_default_64 = primals_358 = primals_356 = primals_357 = getitem_115 = getitem_116 = None
        getitem_447 = native_batch_norm_backward_default_30[0]
        getitem_448 = native_batch_norm_backward_default_30[1]
        getitem_449 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_447, getitem_111, primals_91, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_447 = getitem_111 = primals_91 = None
        getitem_450 = convolution_backward_default_50[0]
        getitem_451 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(add_tensor_156, getitem_450);  add_tensor_156 = getitem_450 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_164, convolution_default_63, primals_353, primals_351, primals_352, getitem_112, getitem_113, True, 0.001, [True, True, True]);  add_tensor_164 = convolution_default_63 = primals_353 = primals_351 = primals_352 = getitem_112 = getitem_113 = None
        getitem_453 = native_batch_norm_backward_default_31[0]
        getitem_454 = native_batch_norm_backward_default_31[1]
        getitem_455 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_453, mul_tensor_12, primals_85, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_453 = mul_tensor_12 = primals_85 = None
        getitem_456 = convolution_backward_default_51[0]
        getitem_457 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        mul_tensor_187 = torch.ops.aten.mul.Tensor(getitem_456, silu__default_36);  silu__default_36 = None
        mul_tensor_188 = torch.ops.aten.mul.Tensor(getitem_456, sigmoid_default_12);  getitem_456 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_187, [2, 3], True);  mul_tensor_187 = None
        to_dtype_123 = torch.ops.aten.to.dtype(sum_dim_int_list_11, torch.float32);  sum_dim_int_list_11 = None
        to_dtype_124 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar_41 = torch.ops.aten.rsub.Scalar(to_dtype_124, 1)
        mul_tensor_189 = torch.ops.aten.mul.Tensor(to_dtype_124, rsub_scalar_41);  to_dtype_124 = rsub_scalar_41 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_189);  mul_tensor_189 = None
        mul_tensor_190 = torch.ops.aten.mul.Tensor(to_dtype_123, conj_physical_default_10);  to_dtype_123 = conj_physical_default_10 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_190, torch.float32);  mul_tensor_190 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(to_dtype_125, silu__default_37, primals_87, [399], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = silu__default_37 = primals_87 = None
        getitem_459 = convolution_backward_default_52[0]
        getitem_460 = convolution_backward_default_52[1]
        getitem_461 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_459, torch.float32);  getitem_459 = None
        to_dtype_127 = torch.ops.aten.to.dtype(clone_default_37, torch.float32);  clone_default_37 = None
        neg_default_31 = torch.ops.aten.neg.default(to_dtype_127)
        exp_default_31 = torch.ops.aten.exp.default(neg_default_31);  neg_default_31 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(exp_default_31, 1);  exp_default_31 = None
        reciprocal_default_31 = torch.ops.aten.reciprocal.default(add_tensor_165);  add_tensor_165 = None
        mul_tensor_191 = torch.ops.aten.mul.Tensor(reciprocal_default_31, 1);  reciprocal_default_31 = None
        mul_tensor_192 = torch.ops.aten.mul.Tensor(to_dtype_126, mul_tensor_191);  to_dtype_126 = None
        rsub_scalar_42 = torch.ops.aten.rsub.Scalar(mul_tensor_191, 1);  mul_tensor_191 = None
        mul_tensor_193 = torch.ops.aten.mul.Tensor(to_dtype_127, rsub_scalar_42);  to_dtype_127 = rsub_scalar_42 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(mul_tensor_193, 1);  mul_tensor_193 = None
        mul_tensor_194 = torch.ops.aten.mul.Tensor(mul_tensor_192, add_tensor_166);  mul_tensor_192 = add_tensor_166 = None
        to_dtype_128 = torch.ops.aten.to.dtype(mul_tensor_194, torch.float32);  mul_tensor_194 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(to_dtype_128, mean_dim_12, primals_89, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_128 = mean_dim_12 = primals_89 = None
        getitem_462 = convolution_backward_default_53[0]
        getitem_463 = convolution_backward_default_53[1]
        getitem_464 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_462, [128, 399, 15, 15]);  getitem_462 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_11, 225);  expand_default_11 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(mul_tensor_188, div_scalar_11);  mul_tensor_188 = div_scalar_11 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_167, torch.float32);  add_tensor_167 = None
        to_dtype_130 = torch.ops.aten.to.dtype(clone_default_36, torch.float32);  clone_default_36 = None
        neg_default_32 = torch.ops.aten.neg.default(to_dtype_130)
        exp_default_32 = torch.ops.aten.exp.default(neg_default_32);  neg_default_32 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(exp_default_32, 1);  exp_default_32 = None
        reciprocal_default_32 = torch.ops.aten.reciprocal.default(add_tensor_168);  add_tensor_168 = None
        mul_tensor_195 = torch.ops.aten.mul.Tensor(reciprocal_default_32, 1);  reciprocal_default_32 = None
        mul_tensor_196 = torch.ops.aten.mul.Tensor(to_dtype_129, mul_tensor_195);  to_dtype_129 = None
        rsub_scalar_43 = torch.ops.aten.rsub.Scalar(mul_tensor_195, 1);  mul_tensor_195 = None
        mul_tensor_197 = torch.ops.aten.mul.Tensor(to_dtype_130, rsub_scalar_43);  to_dtype_130 = rsub_scalar_43 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(mul_tensor_197, 1);  mul_tensor_197 = None
        mul_tensor_198 = torch.ops.aten.mul.Tensor(mul_tensor_196, add_tensor_169);  mul_tensor_196 = add_tensor_169 = None
        to_dtype_131 = torch.ops.aten.to.dtype(mul_tensor_198, torch.float32);  mul_tensor_198 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_60, primals_348, primals_346, primals_347, getitem_109, getitem_110, True, 0.001, [True, True, True]);  to_dtype_131 = convolution_default_60 = primals_348 = primals_346 = primals_347 = getitem_109 = getitem_110 = None
        getitem_465 = native_batch_norm_backward_default_32[0]
        getitem_466 = native_batch_norm_backward_default_32[1]
        getitem_467 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_465, silu__default_35, primals_83, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 399, [True, True, False]);  getitem_465 = silu__default_35 = primals_83 = None
        getitem_468 = convolution_backward_default_54[0]
        getitem_469 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_468, torch.float32);  getitem_468 = None
        to_dtype_133 = torch.ops.aten.to.dtype(clone_default_35, torch.float32);  clone_default_35 = None
        neg_default_33 = torch.ops.aten.neg.default(to_dtype_133)
        exp_default_33 = torch.ops.aten.exp.default(neg_default_33);  neg_default_33 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(exp_default_33, 1);  exp_default_33 = None
        reciprocal_default_33 = torch.ops.aten.reciprocal.default(add_tensor_170);  add_tensor_170 = None
        mul_tensor_199 = torch.ops.aten.mul.Tensor(reciprocal_default_33, 1);  reciprocal_default_33 = None
        mul_tensor_200 = torch.ops.aten.mul.Tensor(to_dtype_132, mul_tensor_199);  to_dtype_132 = None
        rsub_scalar_44 = torch.ops.aten.rsub.Scalar(mul_tensor_199, 1);  mul_tensor_199 = None
        mul_tensor_201 = torch.ops.aten.mul.Tensor(to_dtype_133, rsub_scalar_44);  to_dtype_133 = rsub_scalar_44 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(mul_tensor_201, 1);  mul_tensor_201 = None
        mul_tensor_202 = torch.ops.aten.mul.Tensor(mul_tensor_200, add_tensor_171);  mul_tensor_200 = add_tensor_171 = None
        to_dtype_134 = torch.ops.aten.to.dtype(mul_tensor_202, torch.float32);  mul_tensor_202 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_59, primals_343, primals_341, primals_342, getitem_106, getitem_107, True, 0.001, [True, True, True]);  to_dtype_134 = convolution_default_59 = primals_343 = primals_341 = primals_342 = getitem_106 = getitem_107 = None
        getitem_471 = native_batch_norm_backward_default_33[0]
        getitem_472 = native_batch_norm_backward_default_33[1]
        getitem_473 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_471, add_tensor_42, primals_84, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_471 = add_tensor_42 = primals_84 = None
        getitem_474 = convolution_backward_default_55[0]
        getitem_475 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(getitem_474, convolution_default_58, primals_338, primals_336, primals_337, getitem_103, getitem_104, True, 0.001, [True, True, True]);  convolution_default_58 = primals_338 = primals_336 = primals_337 = getitem_103 = getitem_104 = None
        getitem_477 = native_batch_norm_backward_default_34[0]
        getitem_478 = native_batch_norm_backward_default_34[1]
        getitem_479 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_477, mul_tensor_11, primals_78, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_477 = mul_tensor_11 = primals_78 = None
        getitem_480 = convolution_backward_default_56[0]
        getitem_481 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        mul_tensor_203 = torch.ops.aten.mul.Tensor(getitem_480, silu__default_33);  silu__default_33 = None
        mul_tensor_204 = torch.ops.aten.mul.Tensor(getitem_480, sigmoid_default_11);  getitem_480 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_203, [2, 3], True);  mul_tensor_203 = None
        to_dtype_135 = torch.ops.aten.to.dtype(sum_dim_int_list_12, torch.float32);  sum_dim_int_list_12 = None
        to_dtype_136 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_45 = torch.ops.aten.rsub.Scalar(to_dtype_136, 1)
        mul_tensor_205 = torch.ops.aten.mul.Tensor(to_dtype_136, rsub_scalar_45);  to_dtype_136 = rsub_scalar_45 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_205);  mul_tensor_205 = None
        mul_tensor_206 = torch.ops.aten.mul.Tensor(to_dtype_135, conj_physical_default_11);  to_dtype_135 = conj_physical_default_11 = None
        to_dtype_137 = torch.ops.aten.to.dtype(mul_tensor_206, torch.float32);  mul_tensor_206 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(to_dtype_137, silu__default_34, primals_80, [164], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_137 = silu__default_34 = primals_80 = None
        getitem_483 = convolution_backward_default_57[0]
        getitem_484 = convolution_backward_default_57[1]
        getitem_485 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_483, torch.float32);  getitem_483 = None
        to_dtype_139 = torch.ops.aten.to.dtype(clone_default_34, torch.float32);  clone_default_34 = None
        neg_default_34 = torch.ops.aten.neg.default(to_dtype_139)
        exp_default_34 = torch.ops.aten.exp.default(neg_default_34);  neg_default_34 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(exp_default_34, 1);  exp_default_34 = None
        reciprocal_default_34 = torch.ops.aten.reciprocal.default(add_tensor_172);  add_tensor_172 = None
        mul_tensor_207 = torch.ops.aten.mul.Tensor(reciprocal_default_34, 1);  reciprocal_default_34 = None
        mul_tensor_208 = torch.ops.aten.mul.Tensor(to_dtype_138, mul_tensor_207);  to_dtype_138 = None
        rsub_scalar_46 = torch.ops.aten.rsub.Scalar(mul_tensor_207, 1);  mul_tensor_207 = None
        mul_tensor_209 = torch.ops.aten.mul.Tensor(to_dtype_139, rsub_scalar_46);  to_dtype_139 = rsub_scalar_46 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(mul_tensor_209, 1);  mul_tensor_209 = None
        mul_tensor_210 = torch.ops.aten.mul.Tensor(mul_tensor_208, add_tensor_173);  mul_tensor_208 = add_tensor_173 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_210, torch.float32);  mul_tensor_210 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(to_dtype_140, mean_dim_11, primals_82, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_140 = mean_dim_11 = primals_82 = None
        getitem_486 = convolution_backward_default_58[0]
        getitem_487 = convolution_backward_default_58[1]
        getitem_488 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        expand_default_12 = torch.ops.aten.expand.default(getitem_486, [128, 164, 15, 15]);  getitem_486 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_12, 225);  expand_default_12 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(mul_tensor_204, div_scalar_12);  mul_tensor_204 = div_scalar_12 = None
        to_dtype_141 = torch.ops.aten.to.dtype(add_tensor_174, torch.float32);  add_tensor_174 = None
        to_dtype_142 = torch.ops.aten.to.dtype(clone_default_33, torch.float32);  clone_default_33 = None
        neg_default_35 = torch.ops.aten.neg.default(to_dtype_142)
        exp_default_35 = torch.ops.aten.exp.default(neg_default_35);  neg_default_35 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(exp_default_35, 1);  exp_default_35 = None
        reciprocal_default_35 = torch.ops.aten.reciprocal.default(add_tensor_175);  add_tensor_175 = None
        mul_tensor_211 = torch.ops.aten.mul.Tensor(reciprocal_default_35, 1);  reciprocal_default_35 = None
        mul_tensor_212 = torch.ops.aten.mul.Tensor(to_dtype_141, mul_tensor_211);  to_dtype_141 = None
        rsub_scalar_47 = torch.ops.aten.rsub.Scalar(mul_tensor_211, 1);  mul_tensor_211 = None
        mul_tensor_213 = torch.ops.aten.mul.Tensor(to_dtype_142, rsub_scalar_47);  to_dtype_142 = rsub_scalar_47 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(mul_tensor_213, 1);  mul_tensor_213 = None
        mul_tensor_214 = torch.ops.aten.mul.Tensor(mul_tensor_212, add_tensor_176);  mul_tensor_212 = add_tensor_176 = None
        to_dtype_143 = torch.ops.aten.to.dtype(mul_tensor_214, torch.float32);  mul_tensor_214 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_55, primals_333, primals_331, primals_332, getitem_100, getitem_101, True, 0.001, [True, True, True]);  to_dtype_143 = convolution_default_55 = primals_333 = primals_331 = primals_332 = getitem_100 = getitem_101 = None
        getitem_489 = native_batch_norm_backward_default_35[0]
        getitem_490 = native_batch_norm_backward_default_35[1]
        getitem_491 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_489, silu__default_32, primals_76, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 164, [True, True, False]);  getitem_489 = silu__default_32 = primals_76 = None
        getitem_492 = convolution_backward_default_59[0]
        getitem_493 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_492, torch.float32);  getitem_492 = None
        to_dtype_145 = torch.ops.aten.to.dtype(clone_default_32, torch.float32);  clone_default_32 = None
        neg_default_36 = torch.ops.aten.neg.default(to_dtype_145)
        exp_default_36 = torch.ops.aten.exp.default(neg_default_36);  neg_default_36 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(exp_default_36, 1);  exp_default_36 = None
        reciprocal_default_36 = torch.ops.aten.reciprocal.default(add_tensor_177);  add_tensor_177 = None
        mul_tensor_215 = torch.ops.aten.mul.Tensor(reciprocal_default_36, 1);  reciprocal_default_36 = None
        mul_tensor_216 = torch.ops.aten.mul.Tensor(to_dtype_144, mul_tensor_215);  to_dtype_144 = None
        rsub_scalar_48 = torch.ops.aten.rsub.Scalar(mul_tensor_215, 1);  mul_tensor_215 = None
        mul_tensor_217 = torch.ops.aten.mul.Tensor(to_dtype_145, rsub_scalar_48);  to_dtype_145 = rsub_scalar_48 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(mul_tensor_217, 1);  mul_tensor_217 = None
        mul_tensor_218 = torch.ops.aten.mul.Tensor(mul_tensor_216, add_tensor_178);  mul_tensor_216 = add_tensor_178 = None
        to_dtype_146 = torch.ops.aten.to.dtype(mul_tensor_218, torch.float32);  mul_tensor_218 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_54, primals_328, primals_326, primals_327, getitem_97, getitem_98, True, 0.001, [True, True, True]);  to_dtype_146 = convolution_default_54 = primals_328 = primals_326 = primals_327 = getitem_97 = getitem_98 = None
        getitem_495 = native_batch_norm_backward_default_36[0]
        getitem_496 = native_batch_norm_backward_default_36[1]
        getitem_497 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_495, add_tensor_38, primals_77, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_495 = add_tensor_38 = primals_77 = None
        getitem_498 = convolution_backward_default_60[0]
        getitem_499 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(getitem_474, getitem_498);  getitem_474 = getitem_498 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_179, convolution_default_53, primals_323, primals_321, primals_322, getitem_94, getitem_95, True, 0.001, [True, True, True]);  convolution_default_53 = primals_323 = primals_321 = primals_322 = getitem_94 = getitem_95 = None
        getitem_501 = native_batch_norm_backward_default_37[0]
        getitem_502 = native_batch_norm_backward_default_37[1]
        getitem_503 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_501, mul_tensor_10, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_501 = mul_tensor_10 = primals_71 = None
        getitem_504 = convolution_backward_default_61[0]
        getitem_505 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        mul_tensor_219 = torch.ops.aten.mul.Tensor(getitem_504, silu__default_30);  silu__default_30 = None
        mul_tensor_220 = torch.ops.aten.mul.Tensor(getitem_504, sigmoid_default_10);  getitem_504 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_219, [2, 3], True);  mul_tensor_219 = None
        to_dtype_147 = torch.ops.aten.to.dtype(sum_dim_int_list_13, torch.float32);  sum_dim_int_list_13 = None
        to_dtype_148 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_49 = torch.ops.aten.rsub.Scalar(to_dtype_148, 1)
        mul_tensor_221 = torch.ops.aten.mul.Tensor(to_dtype_148, rsub_scalar_49);  to_dtype_148 = rsub_scalar_49 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_221);  mul_tensor_221 = None
        mul_tensor_222 = torch.ops.aten.mul.Tensor(to_dtype_147, conj_physical_default_12);  to_dtype_147 = conj_physical_default_12 = None
        to_dtype_149 = torch.ops.aten.to.dtype(mul_tensor_222, torch.float32);  mul_tensor_222 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(to_dtype_149, silu__default_31, primals_73, [137], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_149 = silu__default_31 = primals_73 = None
        getitem_507 = convolution_backward_default_62[0]
        getitem_508 = convolution_backward_default_62[1]
        getitem_509 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_507, torch.float32);  getitem_507 = None
        to_dtype_151 = torch.ops.aten.to.dtype(clone_default_31, torch.float32);  clone_default_31 = None
        neg_default_37 = torch.ops.aten.neg.default(to_dtype_151)
        exp_default_37 = torch.ops.aten.exp.default(neg_default_37);  neg_default_37 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(exp_default_37, 1);  exp_default_37 = None
        reciprocal_default_37 = torch.ops.aten.reciprocal.default(add_tensor_180);  add_tensor_180 = None
        mul_tensor_223 = torch.ops.aten.mul.Tensor(reciprocal_default_37, 1);  reciprocal_default_37 = None
        mul_tensor_224 = torch.ops.aten.mul.Tensor(to_dtype_150, mul_tensor_223);  to_dtype_150 = None
        rsub_scalar_50 = torch.ops.aten.rsub.Scalar(mul_tensor_223, 1);  mul_tensor_223 = None
        mul_tensor_225 = torch.ops.aten.mul.Tensor(to_dtype_151, rsub_scalar_50);  to_dtype_151 = rsub_scalar_50 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(mul_tensor_225, 1);  mul_tensor_225 = None
        mul_tensor_226 = torch.ops.aten.mul.Tensor(mul_tensor_224, add_tensor_181);  mul_tensor_224 = add_tensor_181 = None
        to_dtype_152 = torch.ops.aten.to.dtype(mul_tensor_226, torch.float32);  mul_tensor_226 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(to_dtype_152, mean_dim_10, primals_75, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_152 = mean_dim_10 = primals_75 = None
        getitem_510 = convolution_backward_default_63[0]
        getitem_511 = convolution_backward_default_63[1]
        getitem_512 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        expand_default_13 = torch.ops.aten.expand.default(getitem_510, [128, 137, 15, 15]);  getitem_510 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_13, 225);  expand_default_13 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(mul_tensor_220, div_scalar_13);  mul_tensor_220 = div_scalar_13 = None
        to_dtype_153 = torch.ops.aten.to.dtype(add_tensor_182, torch.float32);  add_tensor_182 = None
        to_dtype_154 = torch.ops.aten.to.dtype(clone_default_30, torch.float32);  clone_default_30 = None
        neg_default_38 = torch.ops.aten.neg.default(to_dtype_154)
        exp_default_38 = torch.ops.aten.exp.default(neg_default_38);  neg_default_38 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(exp_default_38, 1);  exp_default_38 = None
        reciprocal_default_38 = torch.ops.aten.reciprocal.default(add_tensor_183);  add_tensor_183 = None
        mul_tensor_227 = torch.ops.aten.mul.Tensor(reciprocal_default_38, 1);  reciprocal_default_38 = None
        mul_tensor_228 = torch.ops.aten.mul.Tensor(to_dtype_153, mul_tensor_227);  to_dtype_153 = None
        rsub_scalar_51 = torch.ops.aten.rsub.Scalar(mul_tensor_227, 1);  mul_tensor_227 = None
        mul_tensor_229 = torch.ops.aten.mul.Tensor(to_dtype_154, rsub_scalar_51);  to_dtype_154 = rsub_scalar_51 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(mul_tensor_229, 1);  mul_tensor_229 = None
        mul_tensor_230 = torch.ops.aten.mul.Tensor(mul_tensor_228, add_tensor_184);  mul_tensor_228 = add_tensor_184 = None
        to_dtype_155 = torch.ops.aten.to.dtype(mul_tensor_230, torch.float32);  mul_tensor_230 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_50, primals_318, primals_316, primals_317, getitem_91, getitem_92, True, 0.001, [True, True, True]);  to_dtype_155 = convolution_default_50 = primals_318 = primals_316 = primals_317 = getitem_91 = getitem_92 = None
        getitem_513 = native_batch_norm_backward_default_38[0]
        getitem_514 = native_batch_norm_backward_default_38[1]
        getitem_515 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_513, silu__default_29, primals_69, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 137, [True, True, False]);  getitem_513 = silu__default_29 = primals_69 = None
        getitem_516 = convolution_backward_default_64[0]
        getitem_517 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_516, torch.float32);  getitem_516 = None
        to_dtype_157 = torch.ops.aten.to.dtype(clone_default_29, torch.float32);  clone_default_29 = None
        neg_default_39 = torch.ops.aten.neg.default(to_dtype_157)
        exp_default_39 = torch.ops.aten.exp.default(neg_default_39);  neg_default_39 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(exp_default_39, 1);  exp_default_39 = None
        reciprocal_default_39 = torch.ops.aten.reciprocal.default(add_tensor_185);  add_tensor_185 = None
        mul_tensor_231 = torch.ops.aten.mul.Tensor(reciprocal_default_39, 1);  reciprocal_default_39 = None
        mul_tensor_232 = torch.ops.aten.mul.Tensor(to_dtype_156, mul_tensor_231);  to_dtype_156 = None
        rsub_scalar_52 = torch.ops.aten.rsub.Scalar(mul_tensor_231, 1);  mul_tensor_231 = None
        mul_tensor_233 = torch.ops.aten.mul.Tensor(to_dtype_157, rsub_scalar_52);  to_dtype_157 = rsub_scalar_52 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(mul_tensor_233, 1);  mul_tensor_233 = None
        mul_tensor_234 = torch.ops.aten.mul.Tensor(mul_tensor_232, add_tensor_186);  mul_tensor_232 = add_tensor_186 = None
        to_dtype_158 = torch.ops.aten.to.dtype(mul_tensor_234, torch.float32);  mul_tensor_234 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_49, primals_313, primals_311, primals_312, getitem_88, getitem_89, True, 0.001, [True, True, True]);  to_dtype_158 = convolution_default_49 = primals_313 = primals_311 = primals_312 = getitem_88 = getitem_89 = None
        getitem_519 = native_batch_norm_backward_default_39[0]
        getitem_520 = native_batch_norm_backward_default_39[1]
        getitem_521 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_519, add_tensor_34, primals_70, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_519 = add_tensor_34 = primals_70 = None
        getitem_522 = convolution_backward_default_65[0]
        getitem_523 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(add_tensor_179, getitem_522);  add_tensor_179 = getitem_522 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_187, convolution_default_48, primals_308, primals_306, primals_307, getitem_85, getitem_86, True, 0.001, [True, True, True]);  convolution_default_48 = primals_308 = primals_306 = primals_307 = getitem_85 = getitem_86 = None
        getitem_525 = native_batch_norm_backward_default_40[0]
        getitem_526 = native_batch_norm_backward_default_40[1]
        getitem_527 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_525, mul_tensor_9, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_525 = mul_tensor_9 = primals_64 = None
        getitem_528 = convolution_backward_default_66[0]
        getitem_529 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        mul_tensor_235 = torch.ops.aten.mul.Tensor(getitem_528, silu__default_27);  silu__default_27 = None
        mul_tensor_236 = torch.ops.aten.mul.Tensor(getitem_528, sigmoid_default_9);  getitem_528 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(mul_tensor_235, [2, 3], True);  mul_tensor_235 = None
        to_dtype_159 = torch.ops.aten.to.dtype(sum_dim_int_list_14, torch.float32);  sum_dim_int_list_14 = None
        to_dtype_160 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_53 = torch.ops.aten.rsub.Scalar(to_dtype_160, 1)
        mul_tensor_237 = torch.ops.aten.mul.Tensor(to_dtype_160, rsub_scalar_53);  to_dtype_160 = rsub_scalar_53 = None
        conj_physical_default_13 = torch.ops.aten.conj_physical.default(mul_tensor_237);  mul_tensor_237 = None
        mul_tensor_238 = torch.ops.aten.mul.Tensor(to_dtype_159, conj_physical_default_13);  to_dtype_159 = conj_physical_default_13 = None
        to_dtype_161 = torch.ops.aten.to.dtype(mul_tensor_238, torch.float32);  mul_tensor_238 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(to_dtype_161, silu__default_28, primals_66, [188], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_161 = silu__default_28 = primals_66 = None
        getitem_531 = convolution_backward_default_67[0]
        getitem_532 = convolution_backward_default_67[1]
        getitem_533 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_531, torch.float32);  getitem_531 = None
        to_dtype_163 = torch.ops.aten.to.dtype(clone_default_28, torch.float32);  clone_default_28 = None
        neg_default_40 = torch.ops.aten.neg.default(to_dtype_163)
        exp_default_40 = torch.ops.aten.exp.default(neg_default_40);  neg_default_40 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(exp_default_40, 1);  exp_default_40 = None
        reciprocal_default_40 = torch.ops.aten.reciprocal.default(add_tensor_188);  add_tensor_188 = None
        mul_tensor_239 = torch.ops.aten.mul.Tensor(reciprocal_default_40, 1);  reciprocal_default_40 = None
        mul_tensor_240 = torch.ops.aten.mul.Tensor(to_dtype_162, mul_tensor_239);  to_dtype_162 = None
        rsub_scalar_54 = torch.ops.aten.rsub.Scalar(mul_tensor_239, 1);  mul_tensor_239 = None
        mul_tensor_241 = torch.ops.aten.mul.Tensor(to_dtype_163, rsub_scalar_54);  to_dtype_163 = rsub_scalar_54 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(mul_tensor_241, 1);  mul_tensor_241 = None
        mul_tensor_242 = torch.ops.aten.mul.Tensor(mul_tensor_240, add_tensor_189);  mul_tensor_240 = add_tensor_189 = None
        to_dtype_164 = torch.ops.aten.to.dtype(mul_tensor_242, torch.float32);  mul_tensor_242 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(to_dtype_164, mean_dim_9, primals_68, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_164 = mean_dim_9 = primals_68 = None
        getitem_534 = convolution_backward_default_68[0]
        getitem_535 = convolution_backward_default_68[1]
        getitem_536 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        expand_default_14 = torch.ops.aten.expand.default(getitem_534, [128, 188, 15, 15]);  getitem_534 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_14, 225);  expand_default_14 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(mul_tensor_236, div_scalar_14);  mul_tensor_236 = div_scalar_14 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_190, torch.float32);  add_tensor_190 = None
        to_dtype_166 = torch.ops.aten.to.dtype(clone_default_27, torch.float32);  clone_default_27 = None
        neg_default_41 = torch.ops.aten.neg.default(to_dtype_166)
        exp_default_41 = torch.ops.aten.exp.default(neg_default_41);  neg_default_41 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(exp_default_41, 1);  exp_default_41 = None
        reciprocal_default_41 = torch.ops.aten.reciprocal.default(add_tensor_191);  add_tensor_191 = None
        mul_tensor_243 = torch.ops.aten.mul.Tensor(reciprocal_default_41, 1);  reciprocal_default_41 = None
        mul_tensor_244 = torch.ops.aten.mul.Tensor(to_dtype_165, mul_tensor_243);  to_dtype_165 = None
        rsub_scalar_55 = torch.ops.aten.rsub.Scalar(mul_tensor_243, 1);  mul_tensor_243 = None
        mul_tensor_245 = torch.ops.aten.mul.Tensor(to_dtype_166, rsub_scalar_55);  to_dtype_166 = rsub_scalar_55 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(mul_tensor_245, 1);  mul_tensor_245 = None
        mul_tensor_246 = torch.ops.aten.mul.Tensor(mul_tensor_244, add_tensor_192);  mul_tensor_244 = add_tensor_192 = None
        to_dtype_167 = torch.ops.aten.to.dtype(mul_tensor_246, torch.float32);  mul_tensor_246 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_45, primals_303, primals_301, primals_302, getitem_82, getitem_83, True, 0.001, [True, True, True]);  to_dtype_167 = convolution_default_45 = primals_303 = primals_301 = primals_302 = getitem_82 = getitem_83 = None
        getitem_537 = native_batch_norm_backward_default_41[0]
        getitem_538 = native_batch_norm_backward_default_41[1]
        getitem_539 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_537, silu__default_26, primals_62, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 188, [True, True, False]);  getitem_537 = silu__default_26 = primals_62 = None
        getitem_540 = convolution_backward_default_69[0]
        getitem_541 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_540, torch.float32);  getitem_540 = None
        to_dtype_169 = torch.ops.aten.to.dtype(clone_default_26, torch.float32);  clone_default_26 = None
        neg_default_42 = torch.ops.aten.neg.default(to_dtype_169)
        exp_default_42 = torch.ops.aten.exp.default(neg_default_42);  neg_default_42 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(exp_default_42, 1);  exp_default_42 = None
        reciprocal_default_42 = torch.ops.aten.reciprocal.default(add_tensor_193);  add_tensor_193 = None
        mul_tensor_247 = torch.ops.aten.mul.Tensor(reciprocal_default_42, 1);  reciprocal_default_42 = None
        mul_tensor_248 = torch.ops.aten.mul.Tensor(to_dtype_168, mul_tensor_247);  to_dtype_168 = None
        rsub_scalar_56 = torch.ops.aten.rsub.Scalar(mul_tensor_247, 1);  mul_tensor_247 = None
        mul_tensor_249 = torch.ops.aten.mul.Tensor(to_dtype_169, rsub_scalar_56);  to_dtype_169 = rsub_scalar_56 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(mul_tensor_249, 1);  mul_tensor_249 = None
        mul_tensor_250 = torch.ops.aten.mul.Tensor(mul_tensor_248, add_tensor_194);  mul_tensor_248 = add_tensor_194 = None
        to_dtype_170 = torch.ops.aten.to.dtype(mul_tensor_250, torch.float32);  mul_tensor_250 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_44, primals_298, primals_296, primals_297, getitem_79, getitem_80, True, 0.001, [True, True, True]);  to_dtype_170 = convolution_default_44 = primals_298 = primals_296 = primals_297 = getitem_79 = getitem_80 = None
        getitem_543 = native_batch_norm_backward_default_42[0]
        getitem_544 = native_batch_norm_backward_default_42[1]
        getitem_545 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_543, getitem_75, primals_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_543 = getitem_75 = primals_63 = None
        getitem_546 = convolution_backward_default_70[0]
        getitem_547 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(add_tensor_187, getitem_546);  add_tensor_187 = getitem_546 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_195, convolution_default_43, primals_293, primals_291, primals_292, getitem_76, getitem_77, True, 0.001, [True, True, True]);  add_tensor_195 = convolution_default_43 = primals_293 = primals_291 = primals_292 = getitem_76 = getitem_77 = None
        getitem_549 = native_batch_norm_backward_default_43[0]
        getitem_550 = native_batch_norm_backward_default_43[1]
        getitem_551 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_549, mul_tensor_8, primals_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_549 = mul_tensor_8 = primals_57 = None
        getitem_552 = convolution_backward_default_71[0]
        getitem_553 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        mul_tensor_251 = torch.ops.aten.mul.Tensor(getitem_552, silu__default_24);  silu__default_24 = None
        mul_tensor_252 = torch.ops.aten.mul.Tensor(getitem_552, sigmoid_default_8);  getitem_552 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_251, [2, 3], True);  mul_tensor_251 = None
        to_dtype_171 = torch.ops.aten.to.dtype(sum_dim_int_list_15, torch.float32);  sum_dim_int_list_15 = None
        to_dtype_172 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_57 = torch.ops.aten.rsub.Scalar(to_dtype_172, 1)
        mul_tensor_253 = torch.ops.aten.mul.Tensor(to_dtype_172, rsub_scalar_57);  to_dtype_172 = rsub_scalar_57 = None
        conj_physical_default_14 = torch.ops.aten.conj_physical.default(mul_tensor_253);  mul_tensor_253 = None
        mul_tensor_254 = torch.ops.aten.mul.Tensor(to_dtype_171, conj_physical_default_14);  to_dtype_171 = conj_physical_default_14 = None
        to_dtype_173 = torch.ops.aten.to.dtype(mul_tensor_254, torch.float32);  mul_tensor_254 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(to_dtype_173, silu__default_25, primals_59, [175], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_173 = silu__default_25 = primals_59 = None
        getitem_555 = convolution_backward_default_72[0]
        getitem_556 = convolution_backward_default_72[1]
        getitem_557 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_555, torch.float32);  getitem_555 = None
        to_dtype_175 = torch.ops.aten.to.dtype(clone_default_25, torch.float32);  clone_default_25 = None
        neg_default_43 = torch.ops.aten.neg.default(to_dtype_175)
        exp_default_43 = torch.ops.aten.exp.default(neg_default_43);  neg_default_43 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(exp_default_43, 1);  exp_default_43 = None
        reciprocal_default_43 = torch.ops.aten.reciprocal.default(add_tensor_196);  add_tensor_196 = None
        mul_tensor_255 = torch.ops.aten.mul.Tensor(reciprocal_default_43, 1);  reciprocal_default_43 = None
        mul_tensor_256 = torch.ops.aten.mul.Tensor(to_dtype_174, mul_tensor_255);  to_dtype_174 = None
        rsub_scalar_58 = torch.ops.aten.rsub.Scalar(mul_tensor_255, 1);  mul_tensor_255 = None
        mul_tensor_257 = torch.ops.aten.mul.Tensor(to_dtype_175, rsub_scalar_58);  to_dtype_175 = rsub_scalar_58 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(mul_tensor_257, 1);  mul_tensor_257 = None
        mul_tensor_258 = torch.ops.aten.mul.Tensor(mul_tensor_256, add_tensor_197);  mul_tensor_256 = add_tensor_197 = None
        to_dtype_176 = torch.ops.aten.to.dtype(mul_tensor_258, torch.float32);  mul_tensor_258 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(to_dtype_176, mean_dim_8, primals_61, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_176 = mean_dim_8 = primals_61 = None
        getitem_558 = convolution_backward_default_73[0]
        getitem_559 = convolution_backward_default_73[1]
        getitem_560 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        expand_default_15 = torch.ops.aten.expand.default(getitem_558, [128, 175, 15, 15]);  getitem_558 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_15, 225);  expand_default_15 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(mul_tensor_252, div_scalar_15);  mul_tensor_252 = div_scalar_15 = None
        to_dtype_177 = torch.ops.aten.to.dtype(add_tensor_198, torch.float32);  add_tensor_198 = None
        to_dtype_178 = torch.ops.aten.to.dtype(clone_default_24, torch.float32);  clone_default_24 = None
        neg_default_44 = torch.ops.aten.neg.default(to_dtype_178)
        exp_default_44 = torch.ops.aten.exp.default(neg_default_44);  neg_default_44 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(exp_default_44, 1);  exp_default_44 = None
        reciprocal_default_44 = torch.ops.aten.reciprocal.default(add_tensor_199);  add_tensor_199 = None
        mul_tensor_259 = torch.ops.aten.mul.Tensor(reciprocal_default_44, 1);  reciprocal_default_44 = None
        mul_tensor_260 = torch.ops.aten.mul.Tensor(to_dtype_177, mul_tensor_259);  to_dtype_177 = None
        rsub_scalar_59 = torch.ops.aten.rsub.Scalar(mul_tensor_259, 1);  mul_tensor_259 = None
        mul_tensor_261 = torch.ops.aten.mul.Tensor(to_dtype_178, rsub_scalar_59);  to_dtype_178 = rsub_scalar_59 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(mul_tensor_261, 1);  mul_tensor_261 = None
        mul_tensor_262 = torch.ops.aten.mul.Tensor(mul_tensor_260, add_tensor_200);  mul_tensor_260 = add_tensor_200 = None
        to_dtype_179 = torch.ops.aten.to.dtype(mul_tensor_262, torch.float32);  mul_tensor_262 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_40, primals_288, primals_286, primals_287, getitem_73, getitem_74, True, 0.001, [True, True, True]);  to_dtype_179 = convolution_default_40 = primals_288 = primals_286 = primals_287 = getitem_73 = getitem_74 = None
        getitem_561 = native_batch_norm_backward_default_44[0]
        getitem_562 = native_batch_norm_backward_default_44[1]
        getitem_563 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_561, constant_pad_nd_default_3, primals_55, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 175, [True, True, False]);  getitem_561 = constant_pad_nd_default_3 = primals_55 = None
        getitem_564 = convolution_backward_default_74[0]
        getitem_565 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_564, [0, -1, 0, -1]);  getitem_564 = None
        to_dtype_180 = torch.ops.aten.to.dtype(constant_pad_nd_default_6, torch.float32);  constant_pad_nd_default_6 = None
        to_dtype_181 = torch.ops.aten.to.dtype(clone_default_23, torch.float32);  clone_default_23 = None
        neg_default_45 = torch.ops.aten.neg.default(to_dtype_181)
        exp_default_45 = torch.ops.aten.exp.default(neg_default_45);  neg_default_45 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(exp_default_45, 1);  exp_default_45 = None
        reciprocal_default_45 = torch.ops.aten.reciprocal.default(add_tensor_201);  add_tensor_201 = None
        mul_tensor_263 = torch.ops.aten.mul.Tensor(reciprocal_default_45, 1);  reciprocal_default_45 = None
        mul_tensor_264 = torch.ops.aten.mul.Tensor(to_dtype_180, mul_tensor_263);  to_dtype_180 = None
        rsub_scalar_60 = torch.ops.aten.rsub.Scalar(mul_tensor_263, 1);  mul_tensor_263 = None
        mul_tensor_265 = torch.ops.aten.mul.Tensor(to_dtype_181, rsub_scalar_60);  to_dtype_181 = rsub_scalar_60 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(mul_tensor_265, 1);  mul_tensor_265 = None
        mul_tensor_266 = torch.ops.aten.mul.Tensor(mul_tensor_264, add_tensor_202);  mul_tensor_264 = add_tensor_202 = None
        to_dtype_182 = torch.ops.aten.to.dtype(mul_tensor_266, torch.float32);  mul_tensor_266 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_39, primals_283, primals_281, primals_282, getitem_70, getitem_71, True, 0.001, [True, True, True]);  to_dtype_182 = convolution_default_39 = primals_283 = primals_281 = primals_282 = getitem_70 = getitem_71 = None
        getitem_567 = native_batch_norm_backward_default_45[0]
        getitem_568 = native_batch_norm_backward_default_45[1]
        getitem_569 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_567, add_tensor_27, primals_56, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_567 = add_tensor_27 = primals_56 = None
        getitem_570 = convolution_backward_default_75[0]
        getitem_571 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(getitem_570, convolution_default_38, primals_278, primals_276, primals_277, getitem_67, getitem_68, True, 0.001, [True, True, True]);  convolution_default_38 = primals_278 = primals_276 = primals_277 = getitem_67 = getitem_68 = None
        getitem_573 = native_batch_norm_backward_default_46[0]
        getitem_574 = native_batch_norm_backward_default_46[1]
        getitem_575 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_573, mul_tensor_7, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_573 = mul_tensor_7 = primals_50 = None
        getitem_576 = convolution_backward_default_76[0]
        getitem_577 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        mul_tensor_267 = torch.ops.aten.mul.Tensor(getitem_576, silu__default_21);  silu__default_21 = None
        mul_tensor_268 = torch.ops.aten.mul.Tensor(getitem_576, sigmoid_default_7);  getitem_576 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(mul_tensor_267, [2, 3], True);  mul_tensor_267 = None
        to_dtype_183 = torch.ops.aten.to.dtype(sum_dim_int_list_16, torch.float32);  sum_dim_int_list_16 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_61 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_269 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_61);  to_dtype_184 = rsub_scalar_61 = None
        conj_physical_default_15 = torch.ops.aten.conj_physical.default(mul_tensor_269);  mul_tensor_269 = None
        mul_tensor_270 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_15);  to_dtype_183 = conj_physical_default_15 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_270, torch.float32);  mul_tensor_270 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(to_dtype_185, silu__default_22, primals_52, [51], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_185 = silu__default_22 = primals_52 = None
        getitem_579 = convolution_backward_default_77[0]
        getitem_580 = convolution_backward_default_77[1]
        getitem_581 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_579, torch.float32);  getitem_579 = None
        to_dtype_187 = torch.ops.aten.to.dtype(clone_default_22, torch.float32);  clone_default_22 = None
        neg_default_46 = torch.ops.aten.neg.default(to_dtype_187)
        exp_default_46 = torch.ops.aten.exp.default(neg_default_46);  neg_default_46 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(exp_default_46, 1);  exp_default_46 = None
        reciprocal_default_46 = torch.ops.aten.reciprocal.default(add_tensor_203);  add_tensor_203 = None
        mul_tensor_271 = torch.ops.aten.mul.Tensor(reciprocal_default_46, 1);  reciprocal_default_46 = None
        mul_tensor_272 = torch.ops.aten.mul.Tensor(to_dtype_186, mul_tensor_271);  to_dtype_186 = None
        rsub_scalar_62 = torch.ops.aten.rsub.Scalar(mul_tensor_271, 1);  mul_tensor_271 = None
        mul_tensor_273 = torch.ops.aten.mul.Tensor(to_dtype_187, rsub_scalar_62);  to_dtype_187 = rsub_scalar_62 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(mul_tensor_273, 1);  mul_tensor_273 = None
        mul_tensor_274 = torch.ops.aten.mul.Tensor(mul_tensor_272, add_tensor_204);  mul_tensor_272 = add_tensor_204 = None
        to_dtype_188 = torch.ops.aten.to.dtype(mul_tensor_274, torch.float32);  mul_tensor_274 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(to_dtype_188, mean_dim_7, primals_54, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_188 = mean_dim_7 = primals_54 = None
        getitem_582 = convolution_backward_default_78[0]
        getitem_583 = convolution_backward_default_78[1]
        getitem_584 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        expand_default_16 = torch.ops.aten.expand.default(getitem_582, [128, 51, 30, 30]);  getitem_582 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_16, 900);  expand_default_16 = None
        add_tensor_205 = torch.ops.aten.add.Tensor(mul_tensor_268, div_scalar_16);  mul_tensor_268 = div_scalar_16 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_205, torch.float32);  add_tensor_205 = None
        to_dtype_190 = torch.ops.aten.to.dtype(clone_default_21, torch.float32);  clone_default_21 = None
        neg_default_47 = torch.ops.aten.neg.default(to_dtype_190)
        exp_default_47 = torch.ops.aten.exp.default(neg_default_47);  neg_default_47 = None
        add_tensor_206 = torch.ops.aten.add.Tensor(exp_default_47, 1);  exp_default_47 = None
        reciprocal_default_47 = torch.ops.aten.reciprocal.default(add_tensor_206);  add_tensor_206 = None
        mul_tensor_275 = torch.ops.aten.mul.Tensor(reciprocal_default_47, 1);  reciprocal_default_47 = None
        mul_tensor_276 = torch.ops.aten.mul.Tensor(to_dtype_189, mul_tensor_275);  to_dtype_189 = None
        rsub_scalar_63 = torch.ops.aten.rsub.Scalar(mul_tensor_275, 1);  mul_tensor_275 = None
        mul_tensor_277 = torch.ops.aten.mul.Tensor(to_dtype_190, rsub_scalar_63);  to_dtype_190 = rsub_scalar_63 = None
        add_tensor_207 = torch.ops.aten.add.Tensor(mul_tensor_277, 1);  mul_tensor_277 = None
        mul_tensor_278 = torch.ops.aten.mul.Tensor(mul_tensor_276, add_tensor_207);  mul_tensor_276 = add_tensor_207 = None
        to_dtype_191 = torch.ops.aten.to.dtype(mul_tensor_278, torch.float32);  mul_tensor_278 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_35, primals_273, primals_271, primals_272, getitem_64, getitem_65, True, 0.001, [True, True, True]);  to_dtype_191 = convolution_default_35 = primals_273 = primals_271 = primals_272 = getitem_64 = getitem_65 = None
        getitem_585 = native_batch_norm_backward_default_47[0]
        getitem_586 = native_batch_norm_backward_default_47[1]
        getitem_587 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_585, silu__default_20, primals_48, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 51, [True, True, False]);  getitem_585 = silu__default_20 = primals_48 = None
        getitem_588 = convolution_backward_default_79[0]
        getitem_589 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_588, torch.float32);  getitem_588 = None
        to_dtype_193 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        neg_default_48 = torch.ops.aten.neg.default(to_dtype_193)
        exp_default_48 = torch.ops.aten.exp.default(neg_default_48);  neg_default_48 = None
        add_tensor_208 = torch.ops.aten.add.Tensor(exp_default_48, 1);  exp_default_48 = None
        reciprocal_default_48 = torch.ops.aten.reciprocal.default(add_tensor_208);  add_tensor_208 = None
        mul_tensor_279 = torch.ops.aten.mul.Tensor(reciprocal_default_48, 1);  reciprocal_default_48 = None
        mul_tensor_280 = torch.ops.aten.mul.Tensor(to_dtype_192, mul_tensor_279);  to_dtype_192 = None
        rsub_scalar_64 = torch.ops.aten.rsub.Scalar(mul_tensor_279, 1);  mul_tensor_279 = None
        mul_tensor_281 = torch.ops.aten.mul.Tensor(to_dtype_193, rsub_scalar_64);  to_dtype_193 = rsub_scalar_64 = None
        add_tensor_209 = torch.ops.aten.add.Tensor(mul_tensor_281, 1);  mul_tensor_281 = None
        mul_tensor_282 = torch.ops.aten.mul.Tensor(mul_tensor_280, add_tensor_209);  mul_tensor_280 = add_tensor_209 = None
        to_dtype_194 = torch.ops.aten.to.dtype(mul_tensor_282, torch.float32);  mul_tensor_282 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_34, primals_268, primals_266, primals_267, getitem_61, getitem_62, True, 0.001, [True, True, True]);  to_dtype_194 = convolution_default_34 = primals_268 = primals_266 = primals_267 = getitem_61 = getitem_62 = None
        getitem_591 = native_batch_norm_backward_default_48[0]
        getitem_592 = native_batch_norm_backward_default_48[1]
        getitem_593 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_591, add_tensor_23, primals_49, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_591 = add_tensor_23 = primals_49 = None
        getitem_594 = convolution_backward_default_80[0]
        getitem_595 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        add_tensor_210 = torch.ops.aten.add.Tensor(getitem_570, getitem_594);  getitem_570 = getitem_594 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_210, convolution_default_33, primals_263, primals_261, primals_262, getitem_58, getitem_59, True, 0.001, [True, True, True]);  convolution_default_33 = primals_263 = primals_261 = primals_262 = getitem_58 = getitem_59 = None
        getitem_597 = native_batch_norm_backward_default_49[0]
        getitem_598 = native_batch_norm_backward_default_49[1]
        getitem_599 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_597, mul_tensor_6, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_597 = mul_tensor_6 = primals_43 = None
        getitem_600 = convolution_backward_default_81[0]
        getitem_601 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        mul_tensor_283 = torch.ops.aten.mul.Tensor(getitem_600, silu__default_18);  silu__default_18 = None
        mul_tensor_284 = torch.ops.aten.mul.Tensor(getitem_600, sigmoid_default_6);  getitem_600 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_283, [2, 3], True);  mul_tensor_283 = None
        to_dtype_195 = torch.ops.aten.to.dtype(sum_dim_int_list_17, torch.float32);  sum_dim_int_list_17 = None
        to_dtype_196 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_65 = torch.ops.aten.rsub.Scalar(to_dtype_196, 1)
        mul_tensor_285 = torch.ops.aten.mul.Tensor(to_dtype_196, rsub_scalar_65);  to_dtype_196 = rsub_scalar_65 = None
        conj_physical_default_16 = torch.ops.aten.conj_physical.default(mul_tensor_285);  mul_tensor_285 = None
        mul_tensor_286 = torch.ops.aten.mul.Tensor(to_dtype_195, conj_physical_default_16);  to_dtype_195 = conj_physical_default_16 = None
        to_dtype_197 = torch.ops.aten.to.dtype(mul_tensor_286, torch.float32);  mul_tensor_286 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(to_dtype_197, silu__default_19, primals_45, [61], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_197 = silu__default_19 = primals_45 = None
        getitem_603 = convolution_backward_default_82[0]
        getitem_604 = convolution_backward_default_82[1]
        getitem_605 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_603, torch.float32);  getitem_603 = None
        to_dtype_199 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        neg_default_49 = torch.ops.aten.neg.default(to_dtype_199)
        exp_default_49 = torch.ops.aten.exp.default(neg_default_49);  neg_default_49 = None
        add_tensor_211 = torch.ops.aten.add.Tensor(exp_default_49, 1);  exp_default_49 = None
        reciprocal_default_49 = torch.ops.aten.reciprocal.default(add_tensor_211);  add_tensor_211 = None
        mul_tensor_287 = torch.ops.aten.mul.Tensor(reciprocal_default_49, 1);  reciprocal_default_49 = None
        mul_tensor_288 = torch.ops.aten.mul.Tensor(to_dtype_198, mul_tensor_287);  to_dtype_198 = None
        rsub_scalar_66 = torch.ops.aten.rsub.Scalar(mul_tensor_287, 1);  mul_tensor_287 = None
        mul_tensor_289 = torch.ops.aten.mul.Tensor(to_dtype_199, rsub_scalar_66);  to_dtype_199 = rsub_scalar_66 = None
        add_tensor_212 = torch.ops.aten.add.Tensor(mul_tensor_289, 1);  mul_tensor_289 = None
        mul_tensor_290 = torch.ops.aten.mul.Tensor(mul_tensor_288, add_tensor_212);  mul_tensor_288 = add_tensor_212 = None
        to_dtype_200 = torch.ops.aten.to.dtype(mul_tensor_290, torch.float32);  mul_tensor_290 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(to_dtype_200, mean_dim_6, primals_47, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_200 = mean_dim_6 = primals_47 = None
        getitem_606 = convolution_backward_default_83[0]
        getitem_607 = convolution_backward_default_83[1]
        getitem_608 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        expand_default_17 = torch.ops.aten.expand.default(getitem_606, [128, 61, 30, 30]);  getitem_606 = None
        div_scalar_17 = torch.ops.aten.div.Scalar(expand_default_17, 900);  expand_default_17 = None
        add_tensor_213 = torch.ops.aten.add.Tensor(mul_tensor_284, div_scalar_17);  mul_tensor_284 = div_scalar_17 = None
        to_dtype_201 = torch.ops.aten.to.dtype(add_tensor_213, torch.float32);  add_tensor_213 = None
        to_dtype_202 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        neg_default_50 = torch.ops.aten.neg.default(to_dtype_202)
        exp_default_50 = torch.ops.aten.exp.default(neg_default_50);  neg_default_50 = None
        add_tensor_214 = torch.ops.aten.add.Tensor(exp_default_50, 1);  exp_default_50 = None
        reciprocal_default_50 = torch.ops.aten.reciprocal.default(add_tensor_214);  add_tensor_214 = None
        mul_tensor_291 = torch.ops.aten.mul.Tensor(reciprocal_default_50, 1);  reciprocal_default_50 = None
        mul_tensor_292 = torch.ops.aten.mul.Tensor(to_dtype_201, mul_tensor_291);  to_dtype_201 = None
        rsub_scalar_67 = torch.ops.aten.rsub.Scalar(mul_tensor_291, 1);  mul_tensor_291 = None
        mul_tensor_293 = torch.ops.aten.mul.Tensor(to_dtype_202, rsub_scalar_67);  to_dtype_202 = rsub_scalar_67 = None
        add_tensor_215 = torch.ops.aten.add.Tensor(mul_tensor_293, 1);  mul_tensor_293 = None
        mul_tensor_294 = torch.ops.aten.mul.Tensor(mul_tensor_292, add_tensor_215);  mul_tensor_292 = add_tensor_215 = None
        to_dtype_203 = torch.ops.aten.to.dtype(mul_tensor_294, torch.float32);  mul_tensor_294 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_30, primals_258, primals_256, primals_257, getitem_55, getitem_56, True, 0.001, [True, True, True]);  to_dtype_203 = convolution_default_30 = primals_258 = primals_256 = primals_257 = getitem_55 = getitem_56 = None
        getitem_609 = native_batch_norm_backward_default_50[0]
        getitem_610 = native_batch_norm_backward_default_50[1]
        getitem_611 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_609, silu__default_17, primals_41, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 61, [True, True, False]);  getitem_609 = silu__default_17 = primals_41 = None
        getitem_612 = convolution_backward_default_84[0]
        getitem_613 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_612, torch.float32);  getitem_612 = None
        to_dtype_205 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        neg_default_51 = torch.ops.aten.neg.default(to_dtype_205)
        exp_default_51 = torch.ops.aten.exp.default(neg_default_51);  neg_default_51 = None
        add_tensor_216 = torch.ops.aten.add.Tensor(exp_default_51, 1);  exp_default_51 = None
        reciprocal_default_51 = torch.ops.aten.reciprocal.default(add_tensor_216);  add_tensor_216 = None
        mul_tensor_295 = torch.ops.aten.mul.Tensor(reciprocal_default_51, 1);  reciprocal_default_51 = None
        mul_tensor_296 = torch.ops.aten.mul.Tensor(to_dtype_204, mul_tensor_295);  to_dtype_204 = None
        rsub_scalar_68 = torch.ops.aten.rsub.Scalar(mul_tensor_295, 1);  mul_tensor_295 = None
        mul_tensor_297 = torch.ops.aten.mul.Tensor(to_dtype_205, rsub_scalar_68);  to_dtype_205 = rsub_scalar_68 = None
        add_tensor_217 = torch.ops.aten.add.Tensor(mul_tensor_297, 1);  mul_tensor_297 = None
        mul_tensor_298 = torch.ops.aten.mul.Tensor(mul_tensor_296, add_tensor_217);  mul_tensor_296 = add_tensor_217 = None
        to_dtype_206 = torch.ops.aten.to.dtype(mul_tensor_298, torch.float32);  mul_tensor_298 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_29, primals_253, primals_251, primals_252, getitem_52, getitem_53, True, 0.001, [True, True, True]);  to_dtype_206 = convolution_default_29 = primals_253 = primals_251 = primals_252 = getitem_52 = getitem_53 = None
        getitem_615 = native_batch_norm_backward_default_51[0]
        getitem_616 = native_batch_norm_backward_default_51[1]
        getitem_617 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_615, getitem_48, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_615 = getitem_48 = primals_42 = None
        getitem_618 = convolution_backward_default_85[0]
        getitem_619 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        add_tensor_218 = torch.ops.aten.add.Tensor(add_tensor_210, getitem_618);  add_tensor_210 = getitem_618 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_218, convolution_default_28, primals_248, primals_246, primals_247, getitem_49, getitem_50, True, 0.001, [True, True, True]);  add_tensor_218 = convolution_default_28 = primals_248 = primals_246 = primals_247 = getitem_49 = getitem_50 = None
        getitem_621 = native_batch_norm_backward_default_52[0]
        getitem_622 = native_batch_norm_backward_default_52[1]
        getitem_623 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_621, mul_tensor_5, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_621 = mul_tensor_5 = primals_36 = None
        getitem_624 = convolution_backward_default_86[0]
        getitem_625 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        mul_tensor_299 = torch.ops.aten.mul.Tensor(getitem_624, silu__default_15);  silu__default_15 = None
        mul_tensor_300 = torch.ops.aten.mul.Tensor(getitem_624, sigmoid_default_5);  getitem_624 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(mul_tensor_299, [2, 3], True);  mul_tensor_299 = None
        to_dtype_207 = torch.ops.aten.to.dtype(sum_dim_int_list_18, torch.float32);  sum_dim_int_list_18 = None
        to_dtype_208 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_69 = torch.ops.aten.rsub.Scalar(to_dtype_208, 1)
        mul_tensor_301 = torch.ops.aten.mul.Tensor(to_dtype_208, rsub_scalar_69);  to_dtype_208 = rsub_scalar_69 = None
        conj_physical_default_17 = torch.ops.aten.conj_physical.default(mul_tensor_301);  mul_tensor_301 = None
        mul_tensor_302 = torch.ops.aten.mul.Tensor(to_dtype_207, conj_physical_default_17);  to_dtype_207 = conj_physical_default_17 = None
        to_dtype_209 = torch.ops.aten.to.dtype(mul_tensor_302, torch.float32);  mul_tensor_302 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(to_dtype_209, silu__default_16, primals_38, [70], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_209 = silu__default_16 = primals_38 = None
        getitem_627 = convolution_backward_default_87[0]
        getitem_628 = convolution_backward_default_87[1]
        getitem_629 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_627, torch.float32);  getitem_627 = None
        to_dtype_211 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        neg_default_52 = torch.ops.aten.neg.default(to_dtype_211)
        exp_default_52 = torch.ops.aten.exp.default(neg_default_52);  neg_default_52 = None
        add_tensor_219 = torch.ops.aten.add.Tensor(exp_default_52, 1);  exp_default_52 = None
        reciprocal_default_52 = torch.ops.aten.reciprocal.default(add_tensor_219);  add_tensor_219 = None
        mul_tensor_303 = torch.ops.aten.mul.Tensor(reciprocal_default_52, 1);  reciprocal_default_52 = None
        mul_tensor_304 = torch.ops.aten.mul.Tensor(to_dtype_210, mul_tensor_303);  to_dtype_210 = None
        rsub_scalar_70 = torch.ops.aten.rsub.Scalar(mul_tensor_303, 1);  mul_tensor_303 = None
        mul_tensor_305 = torch.ops.aten.mul.Tensor(to_dtype_211, rsub_scalar_70);  to_dtype_211 = rsub_scalar_70 = None
        add_tensor_220 = torch.ops.aten.add.Tensor(mul_tensor_305, 1);  mul_tensor_305 = None
        mul_tensor_306 = torch.ops.aten.mul.Tensor(mul_tensor_304, add_tensor_220);  mul_tensor_304 = add_tensor_220 = None
        to_dtype_212 = torch.ops.aten.to.dtype(mul_tensor_306, torch.float32);  mul_tensor_306 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(to_dtype_212, mean_dim_5, primals_40, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_212 = mean_dim_5 = primals_40 = None
        getitem_630 = convolution_backward_default_88[0]
        getitem_631 = convolution_backward_default_88[1]
        getitem_632 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        expand_default_18 = torch.ops.aten.expand.default(getitem_630, [128, 70, 30, 30]);  getitem_630 = None
        div_scalar_18 = torch.ops.aten.div.Scalar(expand_default_18, 900);  expand_default_18 = None
        add_tensor_221 = torch.ops.aten.add.Tensor(mul_tensor_300, div_scalar_18);  mul_tensor_300 = div_scalar_18 = None
        to_dtype_213 = torch.ops.aten.to.dtype(add_tensor_221, torch.float32);  add_tensor_221 = None
        to_dtype_214 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        neg_default_53 = torch.ops.aten.neg.default(to_dtype_214)
        exp_default_53 = torch.ops.aten.exp.default(neg_default_53);  neg_default_53 = None
        add_tensor_222 = torch.ops.aten.add.Tensor(exp_default_53, 1);  exp_default_53 = None
        reciprocal_default_53 = torch.ops.aten.reciprocal.default(add_tensor_222);  add_tensor_222 = None
        mul_tensor_307 = torch.ops.aten.mul.Tensor(reciprocal_default_53, 1);  reciprocal_default_53 = None
        mul_tensor_308 = torch.ops.aten.mul.Tensor(to_dtype_213, mul_tensor_307);  to_dtype_213 = None
        rsub_scalar_71 = torch.ops.aten.rsub.Scalar(mul_tensor_307, 1);  mul_tensor_307 = None
        mul_tensor_309 = torch.ops.aten.mul.Tensor(to_dtype_214, rsub_scalar_71);  to_dtype_214 = rsub_scalar_71 = None
        add_tensor_223 = torch.ops.aten.add.Tensor(mul_tensor_309, 1);  mul_tensor_309 = None
        mul_tensor_310 = torch.ops.aten.mul.Tensor(mul_tensor_308, add_tensor_223);  mul_tensor_308 = add_tensor_223 = None
        to_dtype_215 = torch.ops.aten.to.dtype(mul_tensor_310, torch.float32);  mul_tensor_310 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_25, primals_243, primals_241, primals_242, getitem_46, getitem_47, True, 0.001, [True, True, True]);  to_dtype_215 = convolution_default_25 = primals_243 = primals_241 = primals_242 = getitem_46 = getitem_47 = None
        getitem_633 = native_batch_norm_backward_default_53[0]
        getitem_634 = native_batch_norm_backward_default_53[1]
        getitem_635 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_633, constant_pad_nd_default_2, primals_34, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 70, [True, True, False]);  getitem_633 = constant_pad_nd_default_2 = primals_34 = None
        getitem_636 = convolution_backward_default_89[0]
        getitem_637 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(getitem_636, [-1, -2, -1, -2]);  getitem_636 = None
        to_dtype_216 = torch.ops.aten.to.dtype(constant_pad_nd_default_7, torch.float32);  constant_pad_nd_default_7 = None
        to_dtype_217 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        neg_default_54 = torch.ops.aten.neg.default(to_dtype_217)
        exp_default_54 = torch.ops.aten.exp.default(neg_default_54);  neg_default_54 = None
        add_tensor_224 = torch.ops.aten.add.Tensor(exp_default_54, 1);  exp_default_54 = None
        reciprocal_default_54 = torch.ops.aten.reciprocal.default(add_tensor_224);  add_tensor_224 = None
        mul_tensor_311 = torch.ops.aten.mul.Tensor(reciprocal_default_54, 1);  reciprocal_default_54 = None
        mul_tensor_312 = torch.ops.aten.mul.Tensor(to_dtype_216, mul_tensor_311);  to_dtype_216 = None
        rsub_scalar_72 = torch.ops.aten.rsub.Scalar(mul_tensor_311, 1);  mul_tensor_311 = None
        mul_tensor_313 = torch.ops.aten.mul.Tensor(to_dtype_217, rsub_scalar_72);  to_dtype_217 = rsub_scalar_72 = None
        add_tensor_225 = torch.ops.aten.add.Tensor(mul_tensor_313, 1);  mul_tensor_313 = None
        mul_tensor_314 = torch.ops.aten.mul.Tensor(mul_tensor_312, add_tensor_225);  mul_tensor_312 = add_tensor_225 = None
        to_dtype_218 = torch.ops.aten.to.dtype(mul_tensor_314, torch.float32);  mul_tensor_314 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_24, primals_238, primals_236, primals_237, getitem_43, getitem_44, True, 0.001, [True, True, True]);  to_dtype_218 = convolution_default_24 = primals_238 = primals_236 = primals_237 = getitem_43 = getitem_44 = None
        getitem_639 = native_batch_norm_backward_default_54[0]
        getitem_640 = native_batch_norm_backward_default_54[1]
        getitem_641 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_639, add_tensor_16, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_639 = add_tensor_16 = primals_35 = None
        getitem_642 = convolution_backward_default_90[0]
        getitem_643 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(getitem_642, convolution_default_23, primals_233, primals_231, primals_232, getitem_40, getitem_41, True, 0.001, [True, True, True]);  convolution_default_23 = primals_233 = primals_231 = primals_232 = getitem_40 = getitem_41 = None
        getitem_645 = native_batch_norm_backward_default_55[0]
        getitem_646 = native_batch_norm_backward_default_55[1]
        getitem_647 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_645, mul_tensor_4, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_645 = mul_tensor_4 = primals_29 = None
        getitem_648 = convolution_backward_default_91[0]
        getitem_649 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        mul_tensor_315 = torch.ops.aten.mul.Tensor(getitem_648, silu__default_12);  silu__default_12 = None
        mul_tensor_316 = torch.ops.aten.mul.Tensor(getitem_648, sigmoid_default_4);  getitem_648 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(mul_tensor_315, [2, 3], True);  mul_tensor_315 = None
        to_dtype_219 = torch.ops.aten.to.dtype(sum_dim_int_list_19, torch.float32);  sum_dim_int_list_19 = None
        to_dtype_220 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_73 = torch.ops.aten.rsub.Scalar(to_dtype_220, 1)
        mul_tensor_317 = torch.ops.aten.mul.Tensor(to_dtype_220, rsub_scalar_73);  to_dtype_220 = rsub_scalar_73 = None
        conj_physical_default_18 = torch.ops.aten.conj_physical.default(mul_tensor_317);  mul_tensor_317 = None
        mul_tensor_318 = torch.ops.aten.mul.Tensor(to_dtype_219, conj_physical_default_18);  to_dtype_219 = conj_physical_default_18 = None
        to_dtype_221 = torch.ops.aten.to.dtype(mul_tensor_318, torch.float32);  mul_tensor_318 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(to_dtype_221, silu__default_13, primals_31, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_221 = silu__default_13 = primals_31 = None
        getitem_651 = convolution_backward_default_92[0]
        getitem_652 = convolution_backward_default_92[1]
        getitem_653 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_651, torch.float32);  getitem_651 = None
        to_dtype_223 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        neg_default_55 = torch.ops.aten.neg.default(to_dtype_223)
        exp_default_55 = torch.ops.aten.exp.default(neg_default_55);  neg_default_55 = None
        add_tensor_226 = torch.ops.aten.add.Tensor(exp_default_55, 1);  exp_default_55 = None
        reciprocal_default_55 = torch.ops.aten.reciprocal.default(add_tensor_226);  add_tensor_226 = None
        mul_tensor_319 = torch.ops.aten.mul.Tensor(reciprocal_default_55, 1);  reciprocal_default_55 = None
        mul_tensor_320 = torch.ops.aten.mul.Tensor(to_dtype_222, mul_tensor_319);  to_dtype_222 = None
        rsub_scalar_74 = torch.ops.aten.rsub.Scalar(mul_tensor_319, 1);  mul_tensor_319 = None
        mul_tensor_321 = torch.ops.aten.mul.Tensor(to_dtype_223, rsub_scalar_74);  to_dtype_223 = rsub_scalar_74 = None
        add_tensor_227 = torch.ops.aten.add.Tensor(mul_tensor_321, 1);  mul_tensor_321 = None
        mul_tensor_322 = torch.ops.aten.mul.Tensor(mul_tensor_320, add_tensor_227);  mul_tensor_320 = add_tensor_227 = None
        to_dtype_224 = torch.ops.aten.to.dtype(mul_tensor_322, torch.float32);  mul_tensor_322 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(to_dtype_224, mean_dim_4, primals_33, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_224 = mean_dim_4 = primals_33 = None
        getitem_654 = convolution_backward_default_93[0]
        getitem_655 = convolution_backward_default_93[1]
        getitem_656 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        expand_default_19 = torch.ops.aten.expand.default(getitem_654, [128, 48, 60, 60]);  getitem_654 = None
        div_scalar_19 = torch.ops.aten.div.Scalar(expand_default_19, 3600);  expand_default_19 = None
        add_tensor_228 = torch.ops.aten.add.Tensor(mul_tensor_316, div_scalar_19);  mul_tensor_316 = div_scalar_19 = None
        to_dtype_225 = torch.ops.aten.to.dtype(add_tensor_228, torch.float32);  add_tensor_228 = None
        to_dtype_226 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        neg_default_56 = torch.ops.aten.neg.default(to_dtype_226)
        exp_default_56 = torch.ops.aten.exp.default(neg_default_56);  neg_default_56 = None
        add_tensor_229 = torch.ops.aten.add.Tensor(exp_default_56, 1);  exp_default_56 = None
        reciprocal_default_56 = torch.ops.aten.reciprocal.default(add_tensor_229);  add_tensor_229 = None
        mul_tensor_323 = torch.ops.aten.mul.Tensor(reciprocal_default_56, 1);  reciprocal_default_56 = None
        mul_tensor_324 = torch.ops.aten.mul.Tensor(to_dtype_225, mul_tensor_323);  to_dtype_225 = None
        rsub_scalar_75 = torch.ops.aten.rsub.Scalar(mul_tensor_323, 1);  mul_tensor_323 = None
        mul_tensor_325 = torch.ops.aten.mul.Tensor(to_dtype_226, rsub_scalar_75);  to_dtype_226 = rsub_scalar_75 = None
        add_tensor_230 = torch.ops.aten.add.Tensor(mul_tensor_325, 1);  mul_tensor_325 = None
        mul_tensor_326 = torch.ops.aten.mul.Tensor(mul_tensor_324, add_tensor_230);  mul_tensor_324 = add_tensor_230 = None
        to_dtype_227 = torch.ops.aten.to.dtype(mul_tensor_326, torch.float32);  mul_tensor_326 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_20, primals_228, primals_226, primals_227, getitem_37, getitem_38, True, 0.001, [True, True, True]);  to_dtype_227 = convolution_default_20 = primals_228 = primals_226 = primals_227 = getitem_37 = getitem_38 = None
        getitem_657 = native_batch_norm_backward_default_56[0]
        getitem_658 = native_batch_norm_backward_default_56[1]
        getitem_659 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_657, silu__default_11, primals_27, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 48, [True, True, False]);  getitem_657 = silu__default_11 = primals_27 = None
        getitem_660 = convolution_backward_default_94[0]
        getitem_661 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        to_dtype_228 = torch.ops.aten.to.dtype(getitem_660, torch.float32);  getitem_660 = None
        to_dtype_229 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        neg_default_57 = torch.ops.aten.neg.default(to_dtype_229)
        exp_default_57 = torch.ops.aten.exp.default(neg_default_57);  neg_default_57 = None
        add_tensor_231 = torch.ops.aten.add.Tensor(exp_default_57, 1);  exp_default_57 = None
        reciprocal_default_57 = torch.ops.aten.reciprocal.default(add_tensor_231);  add_tensor_231 = None
        mul_tensor_327 = torch.ops.aten.mul.Tensor(reciprocal_default_57, 1);  reciprocal_default_57 = None
        mul_tensor_328 = torch.ops.aten.mul.Tensor(to_dtype_228, mul_tensor_327);  to_dtype_228 = None
        rsub_scalar_76 = torch.ops.aten.rsub.Scalar(mul_tensor_327, 1);  mul_tensor_327 = None
        mul_tensor_329 = torch.ops.aten.mul.Tensor(to_dtype_229, rsub_scalar_76);  to_dtype_229 = rsub_scalar_76 = None
        add_tensor_232 = torch.ops.aten.add.Tensor(mul_tensor_329, 1);  mul_tensor_329 = None
        mul_tensor_330 = torch.ops.aten.mul.Tensor(mul_tensor_328, add_tensor_232);  mul_tensor_328 = add_tensor_232 = None
        to_dtype_230 = torch.ops.aten.to.dtype(mul_tensor_330, torch.float32);  mul_tensor_330 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_19, primals_223, primals_221, primals_222, getitem_34, getitem_35, True, 0.001, [True, True, True]);  to_dtype_230 = convolution_default_19 = primals_223 = primals_221 = primals_222 = getitem_34 = getitem_35 = None
        getitem_663 = native_batch_norm_backward_default_57[0]
        getitem_664 = native_batch_norm_backward_default_57[1]
        getitem_665 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_663, add_tensor_12, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_663 = add_tensor_12 = primals_28 = None
        getitem_666 = convolution_backward_default_95[0]
        getitem_667 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        add_tensor_233 = torch.ops.aten.add.Tensor(getitem_642, getitem_666);  getitem_642 = getitem_666 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_233, convolution_default_18, primals_218, primals_216, primals_217, getitem_31, getitem_32, True, 0.001, [True, True, True]);  convolution_default_18 = primals_218 = primals_216 = primals_217 = getitem_31 = getitem_32 = None
        getitem_669 = native_batch_norm_backward_default_58[0]
        getitem_670 = native_batch_norm_backward_default_58[1]
        getitem_671 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_669, mul_tensor_3, primals_22, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_669 = mul_tensor_3 = primals_22 = None
        getitem_672 = convolution_backward_default_96[0]
        getitem_673 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        mul_tensor_331 = torch.ops.aten.mul.Tensor(getitem_672, silu__default_9);  silu__default_9 = None
        mul_tensor_332 = torch.ops.aten.mul.Tensor(getitem_672, sigmoid_default_3);  getitem_672 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(mul_tensor_331, [2, 3], True);  mul_tensor_331 = None
        to_dtype_231 = torch.ops.aten.to.dtype(sum_dim_int_list_20, torch.float32);  sum_dim_int_list_20 = None
        to_dtype_232 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_77 = torch.ops.aten.rsub.Scalar(to_dtype_232, 1)
        mul_tensor_333 = torch.ops.aten.mul.Tensor(to_dtype_232, rsub_scalar_77);  to_dtype_232 = rsub_scalar_77 = None
        conj_physical_default_19 = torch.ops.aten.conj_physical.default(mul_tensor_333);  mul_tensor_333 = None
        mul_tensor_334 = torch.ops.aten.mul.Tensor(to_dtype_231, conj_physical_default_19);  to_dtype_231 = conj_physical_default_19 = None
        to_dtype_233 = torch.ops.aten.to.dtype(mul_tensor_334, torch.float32);  mul_tensor_334 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(to_dtype_233, silu__default_10, primals_24, [62], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_233 = silu__default_10 = primals_24 = None
        getitem_675 = convolution_backward_default_97[0]
        getitem_676 = convolution_backward_default_97[1]
        getitem_677 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_675, torch.float32);  getitem_675 = None
        to_dtype_235 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        neg_default_58 = torch.ops.aten.neg.default(to_dtype_235)
        exp_default_58 = torch.ops.aten.exp.default(neg_default_58);  neg_default_58 = None
        add_tensor_234 = torch.ops.aten.add.Tensor(exp_default_58, 1);  exp_default_58 = None
        reciprocal_default_58 = torch.ops.aten.reciprocal.default(add_tensor_234);  add_tensor_234 = None
        mul_tensor_335 = torch.ops.aten.mul.Tensor(reciprocal_default_58, 1);  reciprocal_default_58 = None
        mul_tensor_336 = torch.ops.aten.mul.Tensor(to_dtype_234, mul_tensor_335);  to_dtype_234 = None
        rsub_scalar_78 = torch.ops.aten.rsub.Scalar(mul_tensor_335, 1);  mul_tensor_335 = None
        mul_tensor_337 = torch.ops.aten.mul.Tensor(to_dtype_235, rsub_scalar_78);  to_dtype_235 = rsub_scalar_78 = None
        add_tensor_235 = torch.ops.aten.add.Tensor(mul_tensor_337, 1);  mul_tensor_337 = None
        mul_tensor_338 = torch.ops.aten.mul.Tensor(mul_tensor_336, add_tensor_235);  mul_tensor_336 = add_tensor_235 = None
        to_dtype_236 = torch.ops.aten.to.dtype(mul_tensor_338, torch.float32);  mul_tensor_338 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(to_dtype_236, mean_dim_3, primals_26, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_236 = mean_dim_3 = primals_26 = None
        getitem_678 = convolution_backward_default_98[0]
        getitem_679 = convolution_backward_default_98[1]
        getitem_680 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        expand_default_20 = torch.ops.aten.expand.default(getitem_678, [128, 62, 60, 60]);  getitem_678 = None
        div_scalar_20 = torch.ops.aten.div.Scalar(expand_default_20, 3600);  expand_default_20 = None
        add_tensor_236 = torch.ops.aten.add.Tensor(mul_tensor_332, div_scalar_20);  mul_tensor_332 = div_scalar_20 = None
        to_dtype_237 = torch.ops.aten.to.dtype(add_tensor_236, torch.float32);  add_tensor_236 = None
        to_dtype_238 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        neg_default_59 = torch.ops.aten.neg.default(to_dtype_238)
        exp_default_59 = torch.ops.aten.exp.default(neg_default_59);  neg_default_59 = None
        add_tensor_237 = torch.ops.aten.add.Tensor(exp_default_59, 1);  exp_default_59 = None
        reciprocal_default_59 = torch.ops.aten.reciprocal.default(add_tensor_237);  add_tensor_237 = None
        mul_tensor_339 = torch.ops.aten.mul.Tensor(reciprocal_default_59, 1);  reciprocal_default_59 = None
        mul_tensor_340 = torch.ops.aten.mul.Tensor(to_dtype_237, mul_tensor_339);  to_dtype_237 = None
        rsub_scalar_79 = torch.ops.aten.rsub.Scalar(mul_tensor_339, 1);  mul_tensor_339 = None
        mul_tensor_341 = torch.ops.aten.mul.Tensor(to_dtype_238, rsub_scalar_79);  to_dtype_238 = rsub_scalar_79 = None
        add_tensor_238 = torch.ops.aten.add.Tensor(mul_tensor_341, 1);  mul_tensor_341 = None
        mul_tensor_342 = torch.ops.aten.mul.Tensor(mul_tensor_340, add_tensor_238);  mul_tensor_340 = add_tensor_238 = None
        to_dtype_239 = torch.ops.aten.to.dtype(mul_tensor_342, torch.float32);  mul_tensor_342 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_15, primals_213, primals_211, primals_212, getitem_28, getitem_29, True, 0.001, [True, True, True]);  to_dtype_239 = convolution_default_15 = primals_213 = primals_211 = primals_212 = getitem_28 = getitem_29 = None
        getitem_681 = native_batch_norm_backward_default_59[0]
        getitem_682 = native_batch_norm_backward_default_59[1]
        getitem_683 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_681, silu__default_8, primals_20, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 62, [True, True, False]);  getitem_681 = silu__default_8 = primals_20 = None
        getitem_684 = convolution_backward_default_99[0]
        getitem_685 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        to_dtype_240 = torch.ops.aten.to.dtype(getitem_684, torch.float32);  getitem_684 = None
        to_dtype_241 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        neg_default_60 = torch.ops.aten.neg.default(to_dtype_241)
        exp_default_60 = torch.ops.aten.exp.default(neg_default_60);  neg_default_60 = None
        add_tensor_239 = torch.ops.aten.add.Tensor(exp_default_60, 1);  exp_default_60 = None
        reciprocal_default_60 = torch.ops.aten.reciprocal.default(add_tensor_239);  add_tensor_239 = None
        mul_tensor_343 = torch.ops.aten.mul.Tensor(reciprocal_default_60, 1);  reciprocal_default_60 = None
        mul_tensor_344 = torch.ops.aten.mul.Tensor(to_dtype_240, mul_tensor_343);  to_dtype_240 = None
        rsub_scalar_80 = torch.ops.aten.rsub.Scalar(mul_tensor_343, 1);  mul_tensor_343 = None
        mul_tensor_345 = torch.ops.aten.mul.Tensor(to_dtype_241, rsub_scalar_80);  to_dtype_241 = rsub_scalar_80 = None
        add_tensor_240 = torch.ops.aten.add.Tensor(mul_tensor_345, 1);  mul_tensor_345 = None
        mul_tensor_346 = torch.ops.aten.mul.Tensor(mul_tensor_344, add_tensor_240);  mul_tensor_344 = add_tensor_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(mul_tensor_346, torch.float32);  mul_tensor_346 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_14, primals_208, primals_206, primals_207, getitem_25, getitem_26, True, 0.001, [True, True, True]);  to_dtype_242 = convolution_default_14 = primals_208 = primals_206 = primals_207 = getitem_25 = getitem_26 = None
        getitem_687 = native_batch_norm_backward_default_60[0]
        getitem_688 = native_batch_norm_backward_default_60[1]
        getitem_689 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_687, getitem_21, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_687 = getitem_21 = primals_21 = None
        getitem_690 = convolution_backward_default_100[0]
        getitem_691 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        add_tensor_241 = torch.ops.aten.add.Tensor(add_tensor_233, getitem_690);  add_tensor_233 = getitem_690 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_241, convolution_default_13, primals_203, primals_201, primals_202, getitem_22, getitem_23, True, 0.001, [True, True, True]);  add_tensor_241 = convolution_default_13 = primals_203 = primals_201 = primals_202 = getitem_22 = getitem_23 = None
        getitem_693 = native_batch_norm_backward_default_61[0]
        getitem_694 = native_batch_norm_backward_default_61[1]
        getitem_695 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_693, mul_tensor_2, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_693 = mul_tensor_2 = primals_15 = None
        getitem_696 = convolution_backward_default_101[0]
        getitem_697 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        mul_tensor_347 = torch.ops.aten.mul.Tensor(getitem_696, silu__default_6);  silu__default_6 = None
        mul_tensor_348 = torch.ops.aten.mul.Tensor(getitem_696, sigmoid_default_2);  getitem_696 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(mul_tensor_347, [2, 3], True);  mul_tensor_347 = None
        to_dtype_243 = torch.ops.aten.to.dtype(sum_dim_int_list_21, torch.float32);  sum_dim_int_list_21 = None
        to_dtype_244 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_81 = torch.ops.aten.rsub.Scalar(to_dtype_244, 1)
        mul_tensor_349 = torch.ops.aten.mul.Tensor(to_dtype_244, rsub_scalar_81);  to_dtype_244 = rsub_scalar_81 = None
        conj_physical_default_20 = torch.ops.aten.conj_physical.default(mul_tensor_349);  mul_tensor_349 = None
        mul_tensor_350 = torch.ops.aten.mul.Tensor(to_dtype_243, conj_physical_default_20);  to_dtype_243 = conj_physical_default_20 = None
        to_dtype_245 = torch.ops.aten.to.dtype(mul_tensor_350, torch.float32);  mul_tensor_350 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(to_dtype_245, silu__default_7, primals_17, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_245 = silu__default_7 = primals_17 = None
        getitem_699 = convolution_backward_default_102[0]
        getitem_700 = convolution_backward_default_102[1]
        getitem_701 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_699, torch.float32);  getitem_699 = None
        to_dtype_247 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        neg_default_61 = torch.ops.aten.neg.default(to_dtype_247)
        exp_default_61 = torch.ops.aten.exp.default(neg_default_61);  neg_default_61 = None
        add_tensor_242 = torch.ops.aten.add.Tensor(exp_default_61, 1);  exp_default_61 = None
        reciprocal_default_61 = torch.ops.aten.reciprocal.default(add_tensor_242);  add_tensor_242 = None
        mul_tensor_351 = torch.ops.aten.mul.Tensor(reciprocal_default_61, 1);  reciprocal_default_61 = None
        mul_tensor_352 = torch.ops.aten.mul.Tensor(to_dtype_246, mul_tensor_351);  to_dtype_246 = None
        rsub_scalar_82 = torch.ops.aten.rsub.Scalar(mul_tensor_351, 1);  mul_tensor_351 = None
        mul_tensor_353 = torch.ops.aten.mul.Tensor(to_dtype_247, rsub_scalar_82);  to_dtype_247 = rsub_scalar_82 = None
        add_tensor_243 = torch.ops.aten.add.Tensor(mul_tensor_353, 1);  mul_tensor_353 = None
        mul_tensor_354 = torch.ops.aten.mul.Tensor(mul_tensor_352, add_tensor_243);  mul_tensor_352 = add_tensor_243 = None
        to_dtype_248 = torch.ops.aten.to.dtype(mul_tensor_354, torch.float32);  mul_tensor_354 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(to_dtype_248, mean_dim_2, primals_19, [4], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_248 = mean_dim_2 = primals_19 = None
        getitem_702 = convolution_backward_default_103[0]
        getitem_703 = convolution_backward_default_103[1]
        getitem_704 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        expand_default_21 = torch.ops.aten.expand.default(getitem_702, [128, 48, 60, 60]);  getitem_702 = None
        div_scalar_21 = torch.ops.aten.div.Scalar(expand_default_21, 3600);  expand_default_21 = None
        add_tensor_244 = torch.ops.aten.add.Tensor(mul_tensor_348, div_scalar_21);  mul_tensor_348 = div_scalar_21 = None
        to_dtype_249 = torch.ops.aten.to.dtype(add_tensor_244, torch.float32);  add_tensor_244 = None
        to_dtype_250 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        neg_default_62 = torch.ops.aten.neg.default(to_dtype_250)
        exp_default_62 = torch.ops.aten.exp.default(neg_default_62);  neg_default_62 = None
        add_tensor_245 = torch.ops.aten.add.Tensor(exp_default_62, 1);  exp_default_62 = None
        reciprocal_default_62 = torch.ops.aten.reciprocal.default(add_tensor_245);  add_tensor_245 = None
        mul_tensor_355 = torch.ops.aten.mul.Tensor(reciprocal_default_62, 1);  reciprocal_default_62 = None
        mul_tensor_356 = torch.ops.aten.mul.Tensor(to_dtype_249, mul_tensor_355);  to_dtype_249 = None
        rsub_scalar_83 = torch.ops.aten.rsub.Scalar(mul_tensor_355, 1);  mul_tensor_355 = None
        mul_tensor_357 = torch.ops.aten.mul.Tensor(to_dtype_250, rsub_scalar_83);  to_dtype_250 = rsub_scalar_83 = None
        add_tensor_246 = torch.ops.aten.add.Tensor(mul_tensor_357, 1);  mul_tensor_357 = None
        mul_tensor_358 = torch.ops.aten.mul.Tensor(mul_tensor_356, add_tensor_246);  mul_tensor_356 = add_tensor_246 = None
        to_dtype_251 = torch.ops.aten.to.dtype(mul_tensor_358, torch.float32);  mul_tensor_358 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_10, primals_198, primals_196, primals_197, getitem_19, getitem_20, True, 0.001, [True, True, True]);  to_dtype_251 = convolution_default_10 = primals_198 = primals_196 = primals_197 = getitem_19 = getitem_20 = None
        getitem_705 = native_batch_norm_backward_default_62[0]
        getitem_706 = native_batch_norm_backward_default_62[1]
        getitem_707 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_705, constant_pad_nd_default_1, primals_13, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 48, [True, True, False]);  getitem_705 = constant_pad_nd_default_1 = primals_13 = None
        getitem_708 = convolution_backward_default_104[0]
        getitem_709 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(getitem_708, [0, -1, 0, -1]);  getitem_708 = None
        to_dtype_252 = torch.ops.aten.to.dtype(constant_pad_nd_default_8, torch.float32);  constant_pad_nd_default_8 = None
        to_dtype_253 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        neg_default_63 = torch.ops.aten.neg.default(to_dtype_253)
        exp_default_63 = torch.ops.aten.exp.default(neg_default_63);  neg_default_63 = None
        add_tensor_247 = torch.ops.aten.add.Tensor(exp_default_63, 1);  exp_default_63 = None
        reciprocal_default_63 = torch.ops.aten.reciprocal.default(add_tensor_247);  add_tensor_247 = None
        mul_tensor_359 = torch.ops.aten.mul.Tensor(reciprocal_default_63, 1);  reciprocal_default_63 = None
        mul_tensor_360 = torch.ops.aten.mul.Tensor(to_dtype_252, mul_tensor_359);  to_dtype_252 = None
        rsub_scalar_84 = torch.ops.aten.rsub.Scalar(mul_tensor_359, 1);  mul_tensor_359 = None
        mul_tensor_361 = torch.ops.aten.mul.Tensor(to_dtype_253, rsub_scalar_84);  to_dtype_253 = rsub_scalar_84 = None
        add_tensor_248 = torch.ops.aten.add.Tensor(mul_tensor_361, 1);  mul_tensor_361 = None
        mul_tensor_362 = torch.ops.aten.mul.Tensor(mul_tensor_360, add_tensor_248);  mul_tensor_360 = add_tensor_248 = None
        to_dtype_254 = torch.ops.aten.to.dtype(mul_tensor_362, torch.float32);  mul_tensor_362 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_9, primals_193, primals_191, primals_192, getitem_16, getitem_17, True, 0.001, [True, True, True]);  to_dtype_254 = convolution_default_9 = primals_193 = primals_191 = primals_192 = getitem_16 = getitem_17 = None
        getitem_711 = native_batch_norm_backward_default_63[0]
        getitem_712 = native_batch_norm_backward_default_63[1]
        getitem_713 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_711, add_tensor_5, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_711 = add_tensor_5 = primals_14 = None
        getitem_714 = convolution_backward_default_105[0]
        getitem_715 = convolution_backward_default_105[1];  convolution_backward_default_105 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(getitem_714, convolution_default_8, primals_188, primals_186, primals_187, getitem_13, getitem_14, True, 0.001, [True, True, True]);  convolution_default_8 = primals_188 = primals_186 = primals_187 = getitem_13 = getitem_14 = None
        getitem_717 = native_batch_norm_backward_default_64[0]
        getitem_718 = native_batch_norm_backward_default_64[1]
        getitem_719 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_717, mul_tensor_1, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_717 = mul_tensor_1 = primals_8 = None
        getitem_720 = convolution_backward_default_106[0]
        getitem_721 = convolution_backward_default_106[1];  convolution_backward_default_106 = None
        mul_tensor_363 = torch.ops.aten.mul.Tensor(getitem_720, silu__default_3);  silu__default_3 = None
        mul_tensor_364 = torch.ops.aten.mul.Tensor(getitem_720, sigmoid_default_1);  getitem_720 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(mul_tensor_363, [2, 3], True);  mul_tensor_363 = None
        to_dtype_255 = torch.ops.aten.to.dtype(sum_dim_int_list_22, torch.float32);  sum_dim_int_list_22 = None
        to_dtype_256 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_85 = torch.ops.aten.rsub.Scalar(to_dtype_256, 1)
        mul_tensor_365 = torch.ops.aten.mul.Tensor(to_dtype_256, rsub_scalar_85);  to_dtype_256 = rsub_scalar_85 = None
        conj_physical_default_21 = torch.ops.aten.conj_physical.default(mul_tensor_365);  mul_tensor_365 = None
        mul_tensor_366 = torch.ops.aten.mul.Tensor(to_dtype_255, conj_physical_default_21);  to_dtype_255 = conj_physical_default_21 = None
        to_dtype_257 = torch.ops.aten.to.dtype(mul_tensor_366, torch.float32);  mul_tensor_366 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(to_dtype_257, silu__default_4, primals_10, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_257 = silu__default_4 = primals_10 = None
        getitem_723 = convolution_backward_default_107[0]
        getitem_724 = convolution_backward_default_107[1]
        getitem_725 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        to_dtype_258 = torch.ops.aten.to.dtype(getitem_723, torch.float32);  getitem_723 = None
        to_dtype_259 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        neg_default_64 = torch.ops.aten.neg.default(to_dtype_259)
        exp_default_64 = torch.ops.aten.exp.default(neg_default_64);  neg_default_64 = None
        add_tensor_249 = torch.ops.aten.add.Tensor(exp_default_64, 1);  exp_default_64 = None
        reciprocal_default_64 = torch.ops.aten.reciprocal.default(add_tensor_249);  add_tensor_249 = None
        mul_tensor_367 = torch.ops.aten.mul.Tensor(reciprocal_default_64, 1);  reciprocal_default_64 = None
        mul_tensor_368 = torch.ops.aten.mul.Tensor(to_dtype_258, mul_tensor_367);  to_dtype_258 = None
        rsub_scalar_86 = torch.ops.aten.rsub.Scalar(mul_tensor_367, 1);  mul_tensor_367 = None
        mul_tensor_369 = torch.ops.aten.mul.Tensor(to_dtype_259, rsub_scalar_86);  to_dtype_259 = rsub_scalar_86 = None
        add_tensor_250 = torch.ops.aten.add.Tensor(mul_tensor_369, 1);  mul_tensor_369 = None
        mul_tensor_370 = torch.ops.aten.mul.Tensor(mul_tensor_368, add_tensor_250);  mul_tensor_368 = add_tensor_250 = None
        to_dtype_260 = torch.ops.aten.to.dtype(mul_tensor_370, torch.float32);  mul_tensor_370 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(to_dtype_260, mean_dim_1, primals_12, [4], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_260 = mean_dim_1 = primals_12 = None
        getitem_726 = convolution_backward_default_108[0]
        getitem_727 = convolution_backward_default_108[1]
        getitem_728 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        expand_default_22 = torch.ops.aten.expand.default(getitem_726, [128, 16, 120, 120]);  getitem_726 = None
        div_scalar_22 = torch.ops.aten.div.Scalar(expand_default_22, 14400);  expand_default_22 = None
        add_tensor_251 = torch.ops.aten.add.Tensor(mul_tensor_364, div_scalar_22);  mul_tensor_364 = div_scalar_22 = None
        to_dtype_261 = torch.ops.aten.to.dtype(add_tensor_251, torch.float32);  add_tensor_251 = None
        to_dtype_262 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        neg_default_65 = torch.ops.aten.neg.default(to_dtype_262)
        exp_default_65 = torch.ops.aten.exp.default(neg_default_65);  neg_default_65 = None
        add_tensor_252 = torch.ops.aten.add.Tensor(exp_default_65, 1);  exp_default_65 = None
        reciprocal_default_65 = torch.ops.aten.reciprocal.default(add_tensor_252);  add_tensor_252 = None
        mul_tensor_371 = torch.ops.aten.mul.Tensor(reciprocal_default_65, 1);  reciprocal_default_65 = None
        mul_tensor_372 = torch.ops.aten.mul.Tensor(to_dtype_261, mul_tensor_371);  to_dtype_261 = None
        rsub_scalar_87 = torch.ops.aten.rsub.Scalar(mul_tensor_371, 1);  mul_tensor_371 = None
        mul_tensor_373 = torch.ops.aten.mul.Tensor(to_dtype_262, rsub_scalar_87);  to_dtype_262 = rsub_scalar_87 = None
        add_tensor_253 = torch.ops.aten.add.Tensor(mul_tensor_373, 1);  mul_tensor_373 = None
        mul_tensor_374 = torch.ops.aten.mul.Tensor(mul_tensor_372, add_tensor_253);  mul_tensor_372 = add_tensor_253 = None
        to_dtype_263 = torch.ops.aten.to.dtype(mul_tensor_374, torch.float32);  mul_tensor_374 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_5, primals_183, primals_181, primals_182, getitem_10, getitem_11, True, 0.001, [True, True, True]);  to_dtype_263 = convolution_default_5 = primals_183 = primals_181 = primals_182 = getitem_10 = getitem_11 = None
        getitem_729 = native_batch_norm_backward_default_65[0]
        getitem_730 = native_batch_norm_backward_default_65[1]
        getitem_731 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_729, getitem_6, primals_7, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 16, [True, True, False]);  getitem_729 = getitem_6 = primals_7 = None
        getitem_732 = convolution_backward_default_109[0]
        getitem_733 = convolution_backward_default_109[1];  convolution_backward_default_109 = None
        add_tensor_254 = torch.ops.aten.add.Tensor(getitem_714, getitem_732);  getitem_714 = getitem_732 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_254, convolution_default_4, primals_178, primals_176, primals_177, getitem_7, getitem_8, True, 0.001, [True, True, True]);  add_tensor_254 = convolution_default_4 = primals_178 = primals_176 = primals_177 = getitem_7 = getitem_8 = None
        getitem_735 = native_batch_norm_backward_default_66[0]
        getitem_736 = native_batch_norm_backward_default_66[1]
        getitem_737 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_735, mul_tensor, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_735 = mul_tensor = primals_2 = None
        getitem_738 = convolution_backward_default_110[0]
        getitem_739 = convolution_backward_default_110[1];  convolution_backward_default_110 = None
        mul_tensor_375 = torch.ops.aten.mul.Tensor(getitem_738, silu__default_1);  silu__default_1 = None
        mul_tensor_376 = torch.ops.aten.mul.Tensor(getitem_738, sigmoid_default);  getitem_738 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(mul_tensor_375, [2, 3], True);  mul_tensor_375 = None
        to_dtype_264 = torch.ops.aten.to.dtype(sum_dim_int_list_23, torch.float32);  sum_dim_int_list_23 = None
        to_dtype_265 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_88 = torch.ops.aten.rsub.Scalar(to_dtype_265, 1)
        mul_tensor_377 = torch.ops.aten.mul.Tensor(to_dtype_265, rsub_scalar_88);  to_dtype_265 = rsub_scalar_88 = None
        conj_physical_default_22 = torch.ops.aten.conj_physical.default(mul_tensor_377);  mul_tensor_377 = None
        mul_tensor_378 = torch.ops.aten.mul.Tensor(to_dtype_264, conj_physical_default_22);  to_dtype_264 = conj_physical_default_22 = None
        to_dtype_266 = torch.ops.aten.to.dtype(mul_tensor_378, torch.float32);  mul_tensor_378 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(to_dtype_266, silu__default_2, primals_4, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_266 = silu__default_2 = primals_4 = None
        getitem_741 = convolution_backward_default_111[0]
        getitem_742 = convolution_backward_default_111[1]
        getitem_743 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_741, torch.float32);  getitem_741 = None
        to_dtype_268 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        neg_default_66 = torch.ops.aten.neg.default(to_dtype_268)
        exp_default_66 = torch.ops.aten.exp.default(neg_default_66);  neg_default_66 = None
        add_tensor_255 = torch.ops.aten.add.Tensor(exp_default_66, 1);  exp_default_66 = None
        reciprocal_default_66 = torch.ops.aten.reciprocal.default(add_tensor_255);  add_tensor_255 = None
        mul_tensor_379 = torch.ops.aten.mul.Tensor(reciprocal_default_66, 1);  reciprocal_default_66 = None
        mul_tensor_380 = torch.ops.aten.mul.Tensor(to_dtype_267, mul_tensor_379);  to_dtype_267 = None
        rsub_scalar_89 = torch.ops.aten.rsub.Scalar(mul_tensor_379, 1);  mul_tensor_379 = None
        mul_tensor_381 = torch.ops.aten.mul.Tensor(to_dtype_268, rsub_scalar_89);  to_dtype_268 = rsub_scalar_89 = None
        add_tensor_256 = torch.ops.aten.add.Tensor(mul_tensor_381, 1);  mul_tensor_381 = None
        mul_tensor_382 = torch.ops.aten.mul.Tensor(mul_tensor_380, add_tensor_256);  mul_tensor_380 = add_tensor_256 = None
        to_dtype_269 = torch.ops.aten.to.dtype(mul_tensor_382, torch.float32);  mul_tensor_382 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(to_dtype_269, mean_dim, primals_6, [8], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_269 = mean_dim = primals_6 = None
        getitem_744 = convolution_backward_default_112[0]
        getitem_745 = convolution_backward_default_112[1]
        getitem_746 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        expand_default_23 = torch.ops.aten.expand.default(getitem_744, [128, 32, 120, 120]);  getitem_744 = None
        div_scalar_23 = torch.ops.aten.div.Scalar(expand_default_23, 14400);  expand_default_23 = None
        add_tensor_257 = torch.ops.aten.add.Tensor(mul_tensor_376, div_scalar_23);  mul_tensor_376 = div_scalar_23 = None
        to_dtype_270 = torch.ops.aten.to.dtype(add_tensor_257, torch.float32);  add_tensor_257 = None
        to_dtype_271 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        neg_default_67 = torch.ops.aten.neg.default(to_dtype_271)
        exp_default_67 = torch.ops.aten.exp.default(neg_default_67);  neg_default_67 = None
        add_tensor_258 = torch.ops.aten.add.Tensor(exp_default_67, 1);  exp_default_67 = None
        reciprocal_default_67 = torch.ops.aten.reciprocal.default(add_tensor_258);  add_tensor_258 = None
        mul_tensor_383 = torch.ops.aten.mul.Tensor(reciprocal_default_67, 1);  reciprocal_default_67 = None
        mul_tensor_384 = torch.ops.aten.mul.Tensor(to_dtype_270, mul_tensor_383);  to_dtype_270 = None
        rsub_scalar_90 = torch.ops.aten.rsub.Scalar(mul_tensor_383, 1);  mul_tensor_383 = None
        mul_tensor_385 = torch.ops.aten.mul.Tensor(to_dtype_271, rsub_scalar_90);  to_dtype_271 = rsub_scalar_90 = None
        add_tensor_259 = torch.ops.aten.add.Tensor(mul_tensor_385, 1);  mul_tensor_385 = None
        mul_tensor_386 = torch.ops.aten.mul.Tensor(mul_tensor_384, add_tensor_259);  mul_tensor_384 = add_tensor_259 = None
        to_dtype_272 = torch.ops.aten.to.dtype(mul_tensor_386, torch.float32);  mul_tensor_386 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_1, primals_173, primals_171, primals_172, getitem_4, getitem_5, True, 0.001, [True, True, True]);  to_dtype_272 = convolution_default_1 = primals_173 = primals_171 = primals_172 = getitem_4 = getitem_5 = None
        getitem_747 = native_batch_norm_backward_default_67[0]
        getitem_748 = native_batch_norm_backward_default_67[1]
        getitem_749 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_747, silu__default, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_747 = silu__default = primals_1 = None
        getitem_750 = convolution_backward_default_113[0]
        getitem_751 = convolution_backward_default_113[1];  convolution_backward_default_113 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_750, torch.float32);  getitem_750 = None
        to_dtype_274 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        neg_default_68 = torch.ops.aten.neg.default(to_dtype_274)
        exp_default_68 = torch.ops.aten.exp.default(neg_default_68);  neg_default_68 = None
        add_tensor_260 = torch.ops.aten.add.Tensor(exp_default_68, 1);  exp_default_68 = None
        reciprocal_default_68 = torch.ops.aten.reciprocal.default(add_tensor_260);  add_tensor_260 = None
        mul_tensor_387 = torch.ops.aten.mul.Tensor(reciprocal_default_68, 1);  reciprocal_default_68 = None
        mul_tensor_388 = torch.ops.aten.mul.Tensor(to_dtype_273, mul_tensor_387);  to_dtype_273 = None
        rsub_scalar_91 = torch.ops.aten.rsub.Scalar(mul_tensor_387, 1);  mul_tensor_387 = None
        mul_tensor_389 = torch.ops.aten.mul.Tensor(to_dtype_274, rsub_scalar_91);  to_dtype_274 = rsub_scalar_91 = None
        add_tensor_261 = torch.ops.aten.add.Tensor(mul_tensor_389, 1);  mul_tensor_389 = None
        mul_tensor_390 = torch.ops.aten.mul.Tensor(mul_tensor_388, add_tensor_261);  mul_tensor_388 = add_tensor_261 = None
        to_dtype_275 = torch.ops.aten.to.dtype(mul_tensor_390, torch.float32);  mul_tensor_390 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default, primals_168, primals_166, primals_167, getitem_1, getitem_2, True, 0.001, [True, True, True]);  to_dtype_275 = convolution_default = primals_168 = primals_166 = primals_167 = getitem_1 = getitem_2 = None
        getitem_753 = native_batch_norm_backward_default_68[0]
        getitem_754 = native_batch_norm_backward_default_68[1]
        getitem_755 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_753, constant_pad_nd_default, primals_163, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_753 = constant_pad_nd_default = primals_163 = None
        getitem_757 = convolution_backward_default_114[1];  convolution_backward_default_114 = None
        return [getitem_751, getitem_739, getitem_743, getitem_742, getitem_746, getitem_745, getitem_733, getitem_721, getitem_725, getitem_724, getitem_728, getitem_727, getitem_709, getitem_715, getitem_697, getitem_701, getitem_700, getitem_704, getitem_703, getitem_685, getitem_691, getitem_673, getitem_677, getitem_676, getitem_680, getitem_679, getitem_661, getitem_667, getitem_649, getitem_653, getitem_652, getitem_656, getitem_655, getitem_637, getitem_643, getitem_625, getitem_629, getitem_628, getitem_632, getitem_631, getitem_613, getitem_619, getitem_601, getitem_605, getitem_604, getitem_608, getitem_607, getitem_589, getitem_595, getitem_577, getitem_581, getitem_580, getitem_584, getitem_583, getitem_565, getitem_571, getitem_553, getitem_557, getitem_556, getitem_560, getitem_559, getitem_541, getitem_547, getitem_529, getitem_533, getitem_532, getitem_536, getitem_535, getitem_517, getitem_523, getitem_505, getitem_509, getitem_508, getitem_512, getitem_511, getitem_493, getitem_499, getitem_481, getitem_485, getitem_484, getitem_488, getitem_487, getitem_469, getitem_475, getitem_457, getitem_461, getitem_460, getitem_464, getitem_463, getitem_445, getitem_451, getitem_433, getitem_437, getitem_436, getitem_440, getitem_439, getitem_421, getitem_427, getitem_409, getitem_413, getitem_412, getitem_416, getitem_415, getitem_397, getitem_403, getitem_385, getitem_389, getitem_388, getitem_392, getitem_391, getitem_373, getitem_379, getitem_361, getitem_365, getitem_364, getitem_368, getitem_367, getitem_349, getitem_355, getitem_337, getitem_341, getitem_340, getitem_344, getitem_343, getitem_325, getitem_331, getitem_313, getitem_317, getitem_316, getitem_320, getitem_319, getitem_301, getitem_307, getitem_289, getitem_293, getitem_292, getitem_296, getitem_295, getitem_277, getitem_283, getitem_265, getitem_269, getitem_268, getitem_272, getitem_271, getitem_253, getitem_259, getitem_241, getitem_245, getitem_244, getitem_248, getitem_247, getitem_229, getitem_235, getitem_217, getitem_221, getitem_220, getitem_224, getitem_223, view_default_1, t_default_4, getitem_211, getitem_757, None, None, None, None, getitem_754, getitem_755, None, None, None, getitem_748, getitem_749, None, None, None, getitem_736, getitem_737, None, None, None, getitem_730, getitem_731, None, None, None, getitem_718, getitem_719, None, None, None, getitem_712, getitem_713, None, None, None, getitem_706, getitem_707, None, None, None, getitem_694, getitem_695, None, None, None, getitem_688, getitem_689, None, None, None, getitem_682, getitem_683, None, None, None, getitem_670, getitem_671, None, None, None, getitem_664, getitem_665, None, None, None, getitem_658, getitem_659, None, None, None, getitem_646, getitem_647, None, None, None, getitem_640, getitem_641, None, None, None, getitem_634, getitem_635, None, None, None, getitem_622, getitem_623, None, None, None, getitem_616, getitem_617, None, None, None, getitem_610, getitem_611, None, None, None, getitem_598, getitem_599, None, None, None, getitem_592, getitem_593, None, None, None, getitem_586, getitem_587, None, None, None, getitem_574, getitem_575, None, None, None, getitem_568, getitem_569, None, None, None, getitem_562, getitem_563, None, None, None, getitem_550, getitem_551, None, None, None, getitem_544, getitem_545, None, None, None, getitem_538, getitem_539, None, None, None, getitem_526, getitem_527, None, None, None, getitem_520, getitem_521, None, None, None, getitem_514, getitem_515, None, None, None, getitem_502, getitem_503, None, None, None, getitem_496, getitem_497, None, None, None, getitem_490, getitem_491, None, None, None, getitem_478, getitem_479, None, None, None, getitem_472, getitem_473, None, None, None, getitem_466, getitem_467, None, None, None, getitem_454, getitem_455, None, None, None, getitem_448, getitem_449, None, None, None, getitem_442, getitem_443, None, None, None, getitem_430, getitem_431, None, None, None, getitem_424, getitem_425, None, None, None, getitem_418, getitem_419, None, None, None, getitem_406, getitem_407, None, None, None, getitem_400, getitem_401, None, None, None, getitem_394, getitem_395, None, None, None, getitem_382, getitem_383, None, None, None, getitem_376, getitem_377, None, None, None, getitem_370, getitem_371, None, None, None, getitem_358, getitem_359, None, None, None, getitem_352, getitem_353, None, None, None, getitem_346, getitem_347, None, None, None, getitem_334, getitem_335, None, None, None, getitem_328, getitem_329, None, None, None, getitem_322, getitem_323, None, None, None, getitem_310, getitem_311, None, None, None, getitem_304, getitem_305, None, None, None, getitem_298, getitem_299, None, None, None, getitem_286, getitem_287, None, None, None, getitem_280, getitem_281, None, None, None, getitem_274, getitem_275, None, None, None, getitem_262, getitem_263, None, None, None, getitem_256, getitem_257, None, None, None, getitem_250, getitem_251, None, None, None, getitem_238, getitem_239, None, None, None, getitem_232, getitem_233, None, None, None, getitem_226, getitem_227, None, None, None, getitem_214, getitem_215, None, None, None, getitem_208, getitem_209]
        
