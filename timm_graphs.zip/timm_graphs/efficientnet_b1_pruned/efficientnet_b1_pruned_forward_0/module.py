
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/efficientnet_b1_pruned/efficientnet_b1_pruned_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509):
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(primals_164, [0, 1, 0, 1], 0.0);  primals_164 = None
        convolution_default = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_163, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_165, 1);  primals_165 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_168, primals_169, primals_166, primals_167, True, 0.1, 0.001);  primals_169 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        silu__default = torch.ops.aten.silu_.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(silu__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_170, 1);  primals_170 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_173, primals_174, primals_171, primals_172, True, 0.1, 0.001);  primals_174 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        silu__default_1 = torch.ops.aten.silu_.default(getitem_3)
        mean_dim = torch.ops.aten.mean.dim(silu__default_1, [2, 3], True)
        convolution_default_2 = torch.ops.aten.convolution.default(mean_dim, primals_6, primals_5, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_5 = None
        silu__default_2 = torch.ops.aten.silu_.default(convolution_default_2)
        convolution_default_3 = torch.ops.aten.convolution.default(silu__default_2, primals_4, primals_3, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_3 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_3);  convolution_default_3 = None
        mul_tensor = torch.ops.aten.mul.Tensor(silu__default_1, sigmoid_default)
        convolution_default_4 = torch.ops.aten.convolution.default(mul_tensor, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_175, 1);  primals_175 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_178, primals_179, primals_176, primals_177, True, 0.1, 0.001);  primals_179 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_6, primals_7, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 16)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_180, 1);  primals_180 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_183, primals_184, primals_181, primals_182, True, 0.1, 0.001);  primals_184 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        silu__default_3 = torch.ops.aten.silu_.default(getitem_9)
        mean_dim_1 = torch.ops.aten.mean.dim(silu__default_3, [2, 3], True)
        convolution_default_6 = torch.ops.aten.convolution.default(mean_dim_1, primals_12, primals_11, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_11 = None
        silu__default_4 = torch.ops.aten.silu_.default(convolution_default_6)
        convolution_default_7 = torch.ops.aten.convolution.default(silu__default_4, primals_10, primals_9, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_9 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_7);  convolution_default_7 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(silu__default_3, sigmoid_default_1)
        convolution_default_8 = torch.ops.aten.convolution.default(mul_tensor_1, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_185, 1);  primals_185 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_188, primals_189, primals_186, primals_187, True, 0.1, 0.001);  primals_189 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_12, getitem_6);  getitem_12 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor_5, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_190, 1);  primals_190 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_193, primals_194, primals_191, primals_192, True, 0.1, 0.001);  primals_194 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        silu__default_5 = torch.ops.aten.silu_.default(getitem_15)
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(silu__default_5, [0, 1, 0, 1], 0.0);  silu__default_5 = None
        convolution_default_10 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, primals_13, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 48)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_195, 1);  primals_195 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_198, primals_199, primals_196, primals_197, True, 0.1, 0.001);  primals_199 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        silu__default_6 = torch.ops.aten.silu_.default(getitem_18)
        mean_dim_2 = torch.ops.aten.mean.dim(silu__default_6, [2, 3], True)
        convolution_default_11 = torch.ops.aten.convolution.default(mean_dim_2, primals_19, primals_18, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_18 = None
        silu__default_7 = torch.ops.aten.silu_.default(convolution_default_11)
        convolution_default_12 = torch.ops.aten.convolution.default(silu__default_7, primals_17, primals_16, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_16 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_12);  convolution_default_12 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(silu__default_6, sigmoid_default_2)
        convolution_default_13 = torch.ops.aten.convolution.default(mul_tensor_2, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_200, 1);  primals_200 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_203, primals_204, primals_201, primals_202, True, 0.1, 0.001);  primals_204 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        convolution_default_14 = torch.ops.aten.convolution.default(getitem_21, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_205, 1);  primals_205 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_208, primals_209, primals_206, primals_207, True, 0.1, 0.001);  primals_209 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        silu__default_8 = torch.ops.aten.silu_.default(getitem_24)
        convolution_default_15 = torch.ops.aten.convolution.default(silu__default_8, primals_20, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 62)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_210, 1);  primals_210 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_213, primals_214, primals_211, primals_212, True, 0.1, 0.001);  primals_214 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        silu__default_9 = torch.ops.aten.silu_.default(getitem_27)
        mean_dim_3 = torch.ops.aten.mean.dim(silu__default_9, [2, 3], True)
        convolution_default_16 = torch.ops.aten.convolution.default(mean_dim_3, primals_26, primals_25, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_25 = None
        silu__default_10 = torch.ops.aten.silu_.default(convolution_default_16)
        convolution_default_17 = torch.ops.aten.convolution.default(silu__default_10, primals_24, primals_23, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_23 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_17);  convolution_default_17 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(silu__default_9, sigmoid_default_3)
        convolution_default_18 = torch.ops.aten.convolution.default(mul_tensor_3, primals_22, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_215, 1);  primals_215 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_218, primals_219, primals_216, primals_217, True, 0.1, 0.001);  primals_219 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_30, getitem_21);  getitem_30 = None
        convolution_default_19 = torch.ops.aten.convolution.default(add_tensor_12, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_220, 1);  primals_220 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_223, primals_224, primals_221, primals_222, True, 0.1, 0.001);  primals_224 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        silu__default_11 = torch.ops.aten.silu_.default(getitem_33)
        convolution_default_20 = torch.ops.aten.convolution.default(silu__default_11, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 48)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_225, 1);  primals_225 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_228, primals_229, primals_226, primals_227, True, 0.1, 0.001);  primals_229 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        silu__default_12 = torch.ops.aten.silu_.default(getitem_36)
        mean_dim_4 = torch.ops.aten.mean.dim(silu__default_12, [2, 3], True)
        convolution_default_21 = torch.ops.aten.convolution.default(mean_dim_4, primals_33, primals_32, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_32 = None
        silu__default_13 = torch.ops.aten.silu_.default(convolution_default_21)
        convolution_default_22 = torch.ops.aten.convolution.default(silu__default_13, primals_31, primals_30, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_30 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_22);  convolution_default_22 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(silu__default_12, sigmoid_default_4)
        convolution_default_23 = torch.ops.aten.convolution.default(mul_tensor_4, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_230, 1);  primals_230 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_233, primals_234, primals_231, primals_232, True, 0.1, 0.001);  primals_234 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_39, add_tensor_12);  getitem_39 = None
        convolution_default_24 = torch.ops.aten.convolution.default(add_tensor_16, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_235, 1);  primals_235 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_238, primals_239, primals_236, primals_237, True, 0.1, 0.001);  primals_239 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        silu__default_14 = torch.ops.aten.silu_.default(getitem_42)
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(silu__default_14, [1, 2, 1, 2], 0.0);  silu__default_14 = None
        convolution_default_25 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, primals_34, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 70)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_240, 1);  primals_240 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_243, primals_244, primals_241, primals_242, True, 0.1, 0.001);  primals_244 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        silu__default_15 = torch.ops.aten.silu_.default(getitem_45)
        mean_dim_5 = torch.ops.aten.mean.dim(silu__default_15, [2, 3], True)
        convolution_default_26 = torch.ops.aten.convolution.default(mean_dim_5, primals_40, primals_39, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_39 = None
        silu__default_16 = torch.ops.aten.silu_.default(convolution_default_26)
        convolution_default_27 = torch.ops.aten.convolution.default(silu__default_16, primals_38, primals_37, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_37 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_27);  convolution_default_27 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(silu__default_15, sigmoid_default_5)
        convolution_default_28 = torch.ops.aten.convolution.default(mul_tensor_5, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_245, 1);  primals_245 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_248, primals_249, primals_246, primals_247, True, 0.1, 0.001);  primals_249 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_48, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_250, 1);  primals_250 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_253, primals_254, primals_251, primals_252, True, 0.1, 0.001);  primals_254 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        silu__default_17 = torch.ops.aten.silu_.default(getitem_51)
        convolution_default_30 = torch.ops.aten.convolution.default(silu__default_17, primals_41, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 61)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_255, 1);  primals_255 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_258, primals_259, primals_256, primals_257, True, 0.1, 0.001);  primals_259 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        silu__default_18 = torch.ops.aten.silu_.default(getitem_54)
        mean_dim_6 = torch.ops.aten.mean.dim(silu__default_18, [2, 3], True)
        convolution_default_31 = torch.ops.aten.convolution.default(mean_dim_6, primals_47, primals_46, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_46 = None
        silu__default_19 = torch.ops.aten.silu_.default(convolution_default_31)
        convolution_default_32 = torch.ops.aten.convolution.default(silu__default_19, primals_45, primals_44, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_44 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_32);  convolution_default_32 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(silu__default_18, sigmoid_default_6)
        convolution_default_33 = torch.ops.aten.convolution.default(mul_tensor_6, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_260, 1);  primals_260 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_263, primals_264, primals_261, primals_262, True, 0.1, 0.001);  primals_264 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(getitem_57, getitem_48);  getitem_57 = None
        convolution_default_34 = torch.ops.aten.convolution.default(add_tensor_23, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_265, 1);  primals_265 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_268, primals_269, primals_266, primals_267, True, 0.1, 0.001);  primals_269 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        silu__default_20 = torch.ops.aten.silu_.default(getitem_60)
        convolution_default_35 = torch.ops.aten.convolution.default(silu__default_20, primals_48, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 51)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_270, 1);  primals_270 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_273, primals_274, primals_271, primals_272, True, 0.1, 0.001);  primals_274 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        silu__default_21 = torch.ops.aten.silu_.default(getitem_63)
        mean_dim_7 = torch.ops.aten.mean.dim(silu__default_21, [2, 3], True)
        convolution_default_36 = torch.ops.aten.convolution.default(mean_dim_7, primals_54, primals_53, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_53 = None
        silu__default_22 = torch.ops.aten.silu_.default(convolution_default_36)
        convolution_default_37 = torch.ops.aten.convolution.default(silu__default_22, primals_52, primals_51, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_51 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_37);  convolution_default_37 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(silu__default_21, sigmoid_default_7)
        convolution_default_38 = torch.ops.aten.convolution.default(mul_tensor_7, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_275, 1);  primals_275 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_278, primals_279, primals_276, primals_277, True, 0.1, 0.001);  primals_279 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_66, add_tensor_23);  getitem_66 = None
        convolution_default_39 = torch.ops.aten.convolution.default(add_tensor_27, primals_56, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_280, 1);  primals_280 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_283, primals_284, primals_281, primals_282, True, 0.1, 0.001);  primals_284 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        silu__default_23 = torch.ops.aten.silu_.default(getitem_69)
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(silu__default_23, [0, 1, 0, 1], 0.0);  silu__default_23 = None
        convolution_default_40 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, primals_55, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 175)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_285, 1);  primals_285 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_288, primals_289, primals_286, primals_287, True, 0.1, 0.001);  primals_289 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        silu__default_24 = torch.ops.aten.silu_.default(getitem_72)
        mean_dim_8 = torch.ops.aten.mean.dim(silu__default_24, [2, 3], True)
        convolution_default_41 = torch.ops.aten.convolution.default(mean_dim_8, primals_61, primals_60, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_60 = None
        silu__default_25 = torch.ops.aten.silu_.default(convolution_default_41)
        convolution_default_42 = torch.ops.aten.convolution.default(silu__default_25, primals_59, primals_58, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_58 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_42);  convolution_default_42 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(silu__default_24, sigmoid_default_8)
        convolution_default_43 = torch.ops.aten.convolution.default(mul_tensor_8, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_290, 1);  primals_290 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_293, primals_294, primals_291, primals_292, True, 0.1, 0.001);  primals_294 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        convolution_default_44 = torch.ops.aten.convolution.default(getitem_75, primals_63, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_295, 1);  primals_295 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_298, primals_299, primals_296, primals_297, True, 0.1, 0.001);  primals_299 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        silu__default_26 = torch.ops.aten.silu_.default(getitem_78)
        convolution_default_45 = torch.ops.aten.convolution.default(silu__default_26, primals_62, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 188)
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_300, 1);  primals_300 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_303, primals_304, primals_301, primals_302, True, 0.1, 0.001);  primals_304 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        silu__default_27 = torch.ops.aten.silu_.default(getitem_81)
        mean_dim_9 = torch.ops.aten.mean.dim(silu__default_27, [2, 3], True)
        convolution_default_46 = torch.ops.aten.convolution.default(mean_dim_9, primals_68, primals_67, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_67 = None
        silu__default_28 = torch.ops.aten.silu_.default(convolution_default_46)
        convolution_default_47 = torch.ops.aten.convolution.default(silu__default_28, primals_66, primals_65, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_65 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_47);  convolution_default_47 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(silu__default_27, sigmoid_default_9)
        convolution_default_48 = torch.ops.aten.convolution.default(mul_tensor_9, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_305, 1);  primals_305 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_308, primals_309, primals_306, primals_307, True, 0.1, 0.001);  primals_309 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(getitem_84, getitem_75);  getitem_84 = None
        convolution_default_49 = torch.ops.aten.convolution.default(add_tensor_34, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_310, 1);  primals_310 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_313, primals_314, primals_311, primals_312, True, 0.1, 0.001);  primals_314 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        silu__default_29 = torch.ops.aten.silu_.default(getitem_87)
        convolution_default_50 = torch.ops.aten.convolution.default(silu__default_29, primals_69, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 137)
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_315, 1);  primals_315 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_318, primals_319, primals_316, primals_317, True, 0.1, 0.001);  primals_319 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        silu__default_30 = torch.ops.aten.silu_.default(getitem_90)
        mean_dim_10 = torch.ops.aten.mean.dim(silu__default_30, [2, 3], True)
        convolution_default_51 = torch.ops.aten.convolution.default(mean_dim_10, primals_75, primals_74, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_74 = None
        silu__default_31 = torch.ops.aten.silu_.default(convolution_default_51)
        convolution_default_52 = torch.ops.aten.convolution.default(silu__default_31, primals_73, primals_72, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_72 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_52);  convolution_default_52 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(silu__default_30, sigmoid_default_10)
        convolution_default_53 = torch.ops.aten.convolution.default(mul_tensor_10, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_320, 1);  primals_320 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_323, primals_324, primals_321, primals_322, True, 0.1, 0.001);  primals_324 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_93, add_tensor_34);  getitem_93 = None
        convolution_default_54 = torch.ops.aten.convolution.default(add_tensor_38, primals_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_325, 1);  primals_325 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_328, primals_329, primals_326, primals_327, True, 0.1, 0.001);  primals_329 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        silu__default_32 = torch.ops.aten.silu_.default(getitem_96)
        convolution_default_55 = torch.ops.aten.convolution.default(silu__default_32, primals_76, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 164)
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_330, 1);  primals_330 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_333, primals_334, primals_331, primals_332, True, 0.1, 0.001);  primals_334 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        silu__default_33 = torch.ops.aten.silu_.default(getitem_99)
        mean_dim_11 = torch.ops.aten.mean.dim(silu__default_33, [2, 3], True)
        convolution_default_56 = torch.ops.aten.convolution.default(mean_dim_11, primals_82, primals_81, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_81 = None
        silu__default_34 = torch.ops.aten.silu_.default(convolution_default_56)
        convolution_default_57 = torch.ops.aten.convolution.default(silu__default_34, primals_80, primals_79, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_79 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_57);  convolution_default_57 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(silu__default_33, sigmoid_default_11)
        convolution_default_58 = torch.ops.aten.convolution.default(mul_tensor_11, primals_78, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_335, 1);  primals_335 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_338, primals_339, primals_336, primals_337, True, 0.1, 0.001);  primals_339 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(getitem_102, add_tensor_38);  getitem_102 = None
        convolution_default_59 = torch.ops.aten.convolution.default(add_tensor_42, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_340, 1);  primals_340 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_343, primals_344, primals_341, primals_342, True, 0.1, 0.001);  primals_344 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        silu__default_35 = torch.ops.aten.silu_.default(getitem_105)
        convolution_default_60 = torch.ops.aten.convolution.default(silu__default_35, primals_83, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 399)
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_345, 1);  primals_345 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_348, primals_349, primals_346, primals_347, True, 0.1, 0.001);  primals_349 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        silu__default_36 = torch.ops.aten.silu_.default(getitem_108)
        mean_dim_12 = torch.ops.aten.mean.dim(silu__default_36, [2, 3], True)
        convolution_default_61 = torch.ops.aten.convolution.default(mean_dim_12, primals_89, primals_88, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_88 = None
        silu__default_37 = torch.ops.aten.silu_.default(convolution_default_61)
        convolution_default_62 = torch.ops.aten.convolution.default(silu__default_37, primals_87, primals_86, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_86 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_62);  convolution_default_62 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(silu__default_36, sigmoid_default_12)
        convolution_default_63 = torch.ops.aten.convolution.default(mul_tensor_12, primals_85, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_45 = torch.ops.aten.add.Tensor(primals_350, 1);  primals_350 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_353, primals_354, primals_351, primals_352, True, 0.1, 0.001);  primals_354 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        convolution_default_64 = torch.ops.aten.convolution.default(getitem_111, primals_91, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_355, 1);  primals_355 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_358, primals_359, primals_356, primals_357, True, 0.1, 0.001);  primals_359 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        silu__default_38 = torch.ops.aten.silu_.default(getitem_114)
        convolution_default_65 = torch.ops.aten.convolution.default(silu__default_38, primals_90, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 201)
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_360, 1);  primals_360 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_363, primals_364, primals_361, primals_362, True, 0.1, 0.001);  primals_364 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        silu__default_39 = torch.ops.aten.silu_.default(getitem_117)
        mean_dim_13 = torch.ops.aten.mean.dim(silu__default_39, [2, 3], True)
        convolution_default_66 = torch.ops.aten.convolution.default(mean_dim_13, primals_96, primals_95, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_95 = None
        silu__default_40 = torch.ops.aten.silu_.default(convolution_default_66)
        convolution_default_67 = torch.ops.aten.convolution.default(silu__default_40, primals_94, primals_93, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_93 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_67);  convolution_default_67 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(silu__default_39, sigmoid_default_13)
        convolution_default_68 = torch.ops.aten.convolution.default(mul_tensor_13, primals_92, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_365, 1);  primals_365 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_368, primals_369, primals_366, primals_367, True, 0.1, 0.001);  primals_369 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(getitem_120, getitem_111);  getitem_120 = None
        convolution_default_69 = torch.ops.aten.convolution.default(add_tensor_49, primals_98, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_370, 1);  primals_370 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_373, primals_374, primals_371, primals_372, True, 0.1, 0.001);  primals_374 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        silu__default_41 = torch.ops.aten.silu_.default(getitem_123)
        convolution_default_70 = torch.ops.aten.convolution.default(silu__default_41, primals_97, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 160)
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_375, 1);  primals_375 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_378, primals_379, primals_376, primals_377, True, 0.1, 0.001);  primals_379 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        silu__default_42 = torch.ops.aten.silu_.default(getitem_126)
        mean_dim_14 = torch.ops.aten.mean.dim(silu__default_42, [2, 3], True)
        convolution_default_71 = torch.ops.aten.convolution.default(mean_dim_14, primals_103, primals_102, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_102 = None
        silu__default_43 = torch.ops.aten.silu_.default(convolution_default_71)
        convolution_default_72 = torch.ops.aten.convolution.default(silu__default_43, primals_101, primals_100, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_100 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_72);  convolution_default_72 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(silu__default_42, sigmoid_default_14)
        convolution_default_73 = torch.ops.aten.convolution.default(mul_tensor_14, primals_99, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_380, 1);  primals_380 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_383, primals_384, primals_381, primals_382, True, 0.1, 0.001);  primals_384 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_129, add_tensor_49);  getitem_129 = None
        convolution_default_74 = torch.ops.aten.convolution.default(add_tensor_53, primals_105, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_385, 1);  primals_385 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_388, primals_389, primals_386, primals_387, True, 0.1, 0.001);  primals_389 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        silu__default_44 = torch.ops.aten.silu_.default(getitem_132)
        convolution_default_75 = torch.ops.aten.convolution.default(silu__default_44, primals_104, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 213)
        add_tensor_55 = torch.ops.aten.add.Tensor(primals_390, 1);  primals_390 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_393, primals_394, primals_391, primals_392, True, 0.1, 0.001);  primals_394 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        silu__default_45 = torch.ops.aten.silu_.default(getitem_135)
        mean_dim_15 = torch.ops.aten.mean.dim(silu__default_45, [2, 3], True)
        convolution_default_76 = torch.ops.aten.convolution.default(mean_dim_15, primals_110, primals_109, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_109 = None
        silu__default_46 = torch.ops.aten.silu_.default(convolution_default_76)
        convolution_default_77 = torch.ops.aten.convolution.default(silu__default_46, primals_108, primals_107, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_107 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_77);  convolution_default_77 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(silu__default_45, sigmoid_default_15)
        convolution_default_78 = torch.ops.aten.convolution.default(mul_tensor_15, primals_106, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_395, 1);  primals_395 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_398, primals_399, primals_396, primals_397, True, 0.1, 0.001);  primals_399 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(getitem_138, add_tensor_53);  getitem_138 = None
        convolution_default_79 = torch.ops.aten.convolution.default(add_tensor_57, primals_112, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_58 = torch.ops.aten.add.Tensor(primals_400, 1);  primals_400 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_403, primals_404, primals_401, primals_402, True, 0.1, 0.001);  primals_404 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        silu__default_47 = torch.ops.aten.silu_.default(getitem_141)
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(silu__default_47, [2, 2, 2, 2], 0.0);  silu__default_47 = None
        convolution_default_80 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, primals_111, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 637)
        add_tensor_59 = torch.ops.aten.add.Tensor(primals_405, 1);  primals_405 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_408, primals_409, primals_406, primals_407, True, 0.1, 0.001);  primals_409 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        silu__default_48 = torch.ops.aten.silu_.default(getitem_144)
        mean_dim_16 = torch.ops.aten.mean.dim(silu__default_48, [2, 3], True)
        convolution_default_81 = torch.ops.aten.convolution.default(mean_dim_16, primals_117, primals_116, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_116 = None
        silu__default_49 = torch.ops.aten.silu_.default(convolution_default_81)
        convolution_default_82 = torch.ops.aten.convolution.default(silu__default_49, primals_115, primals_114, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_114 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(convolution_default_82);  convolution_default_82 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(silu__default_48, sigmoid_default_16)
        convolution_default_83 = torch.ops.aten.convolution.default(mul_tensor_16, primals_113, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_60 = torch.ops.aten.add.Tensor(primals_410, 1);  primals_410 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_413, primals_414, primals_411, primals_412, True, 0.1, 0.001);  primals_414 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        convolution_default_84 = torch.ops.aten.convolution.default(getitem_147, primals_119, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_415, 1);  primals_415 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_418, primals_419, primals_416, primals_417, True, 0.1, 0.001);  primals_419 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        silu__default_50 = torch.ops.aten.silu_.default(getitem_150)
        convolution_default_85 = torch.ops.aten.convolution.default(silu__default_50, primals_118, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 806)
        add_tensor_62 = torch.ops.aten.add.Tensor(primals_420, 1);  primals_420 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_423, primals_424, primals_421, primals_422, True, 0.1, 0.001);  primals_424 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        silu__default_51 = torch.ops.aten.silu_.default(getitem_153)
        mean_dim_17 = torch.ops.aten.mean.dim(silu__default_51, [2, 3], True)
        convolution_default_86 = torch.ops.aten.convolution.default(mean_dim_17, primals_124, primals_123, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_123 = None
        silu__default_52 = torch.ops.aten.silu_.default(convolution_default_86)
        convolution_default_87 = torch.ops.aten.convolution.default(silu__default_52, primals_122, primals_121, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_121 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_87);  convolution_default_87 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(silu__default_51, sigmoid_default_17)
        convolution_default_88 = torch.ops.aten.convolution.default(mul_tensor_17, primals_120, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_63 = torch.ops.aten.add.Tensor(primals_425, 1);  primals_425 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_428, primals_429, primals_426, primals_427, True, 0.1, 0.001);  primals_429 = None
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(getitem_156, getitem_147);  getitem_156 = None
        convolution_default_89 = torch.ops.aten.convolution.default(add_tensor_64, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_65 = torch.ops.aten.add.Tensor(primals_430, 1);  primals_430 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_433, primals_434, primals_431, primals_432, True, 0.1, 0.001);  primals_434 = None
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        silu__default_53 = torch.ops.aten.silu_.default(getitem_159)
        convolution_default_90 = torch.ops.aten.convolution.default(silu__default_53, primals_125, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 798)
        add_tensor_66 = torch.ops.aten.add.Tensor(primals_435, 1);  primals_435 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_438, primals_439, primals_436, primals_437, True, 0.1, 0.001);  primals_439 = None
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        silu__default_54 = torch.ops.aten.silu_.default(getitem_162)
        mean_dim_18 = torch.ops.aten.mean.dim(silu__default_54, [2, 3], True)
        convolution_default_91 = torch.ops.aten.convolution.default(mean_dim_18, primals_131, primals_130, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_130 = None
        silu__default_55 = torch.ops.aten.silu_.default(convolution_default_91)
        convolution_default_92 = torch.ops.aten.convolution.default(silu__default_55, primals_129, primals_128, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_128 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(convolution_default_92);  convolution_default_92 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(silu__default_54, sigmoid_default_18)
        convolution_default_93 = torch.ops.aten.convolution.default(mul_tensor_18, primals_127, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_67 = torch.ops.aten.add.Tensor(primals_440, 1);  primals_440 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_443, primals_444, primals_441, primals_442, True, 0.1, 0.001);  primals_444 = None
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_165, add_tensor_64);  getitem_165 = None
        convolution_default_94 = torch.ops.aten.convolution.default(add_tensor_68, primals_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_69 = torch.ops.aten.add.Tensor(primals_445, 1);  primals_445 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_448, primals_449, primals_446, primals_447, True, 0.1, 0.001);  primals_449 = None
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        silu__default_56 = torch.ops.aten.silu_.default(getitem_168)
        convolution_default_95 = torch.ops.aten.convolution.default(silu__default_56, primals_132, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 891)
        add_tensor_70 = torch.ops.aten.add.Tensor(primals_450, 1);  primals_450 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_453, primals_454, primals_451, primals_452, True, 0.1, 0.001);  primals_454 = None
        getitem_171 = native_batch_norm_default_57[0]
        getitem_172 = native_batch_norm_default_57[1]
        getitem_173 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        silu__default_57 = torch.ops.aten.silu_.default(getitem_171)
        mean_dim_19 = torch.ops.aten.mean.dim(silu__default_57, [2, 3], True)
        convolution_default_96 = torch.ops.aten.convolution.default(mean_dim_19, primals_138, primals_137, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_137 = None
        silu__default_58 = torch.ops.aten.silu_.default(convolution_default_96)
        convolution_default_97 = torch.ops.aten.convolution.default(silu__default_58, primals_136, primals_135, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_135 = None
        sigmoid_default_19 = torch.ops.aten.sigmoid.default(convolution_default_97);  convolution_default_97 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(silu__default_57, sigmoid_default_19)
        convolution_default_98 = torch.ops.aten.convolution.default(mul_tensor_19, primals_134, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_71 = torch.ops.aten.add.Tensor(primals_455, 1);  primals_455 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_458, primals_459, primals_456, primals_457, True, 0.1, 0.001);  primals_459 = None
        getitem_174 = native_batch_norm_default_58[0]
        getitem_175 = native_batch_norm_default_58[1]
        getitem_176 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(getitem_174, add_tensor_68);  getitem_174 = None
        convolution_default_99 = torch.ops.aten.convolution.default(add_tensor_72, primals_140, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_73 = torch.ops.aten.add.Tensor(primals_460, 1);  primals_460 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_463, primals_464, primals_461, primals_462, True, 0.1, 0.001);  primals_464 = None
        getitem_177 = native_batch_norm_default_59[0]
        getitem_178 = native_batch_norm_default_59[1]
        getitem_179 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        silu__default_59 = torch.ops.aten.silu_.default(getitem_177)
        convolution_default_100 = torch.ops.aten.convolution.default(silu__default_59, primals_139, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 990)
        add_tensor_74 = torch.ops.aten.add.Tensor(primals_465, 1);  primals_465 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_468, primals_469, primals_466, primals_467, True, 0.1, 0.001);  primals_469 = None
        getitem_180 = native_batch_norm_default_60[0]
        getitem_181 = native_batch_norm_default_60[1]
        getitem_182 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        silu__default_60 = torch.ops.aten.silu_.default(getitem_180)
        mean_dim_20 = torch.ops.aten.mean.dim(silu__default_60, [2, 3], True)
        convolution_default_101 = torch.ops.aten.convolution.default(mean_dim_20, primals_145, primals_144, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_144 = None
        silu__default_61 = torch.ops.aten.silu_.default(convolution_default_101)
        convolution_default_102 = torch.ops.aten.convolution.default(silu__default_61, primals_143, primals_142, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_142 = None
        sigmoid_default_20 = torch.ops.aten.sigmoid.default(convolution_default_102);  convolution_default_102 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(silu__default_60, sigmoid_default_20)
        convolution_default_103 = torch.ops.aten.convolution.default(mul_tensor_20, primals_141, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_75 = torch.ops.aten.add.Tensor(primals_470, 1);  primals_470 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_473, primals_474, primals_471, primals_472, True, 0.1, 0.001);  primals_474 = None
        getitem_183 = native_batch_norm_default_61[0]
        getitem_184 = native_batch_norm_default_61[1]
        getitem_185 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(getitem_183, add_tensor_72);  getitem_183 = None
        convolution_default_104 = torch.ops.aten.convolution.default(add_tensor_76, primals_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_77 = torch.ops.aten.add.Tensor(primals_475, 1);  primals_475 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_478, primals_479, primals_476, primals_477, True, 0.1, 0.001);  primals_479 = None
        getitem_186 = native_batch_norm_default_62[0]
        getitem_187 = native_batch_norm_default_62[1]
        getitem_188 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        silu__default_62 = torch.ops.aten.silu_.default(getitem_186)
        convolution_default_105 = torch.ops.aten.convolution.default(silu__default_62, primals_146, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1152)
        add_tensor_78 = torch.ops.aten.add.Tensor(primals_480, 1);  primals_480 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_483, primals_484, primals_481, primals_482, True, 0.1, 0.001);  primals_484 = None
        getitem_189 = native_batch_norm_default_63[0]
        getitem_190 = native_batch_norm_default_63[1]
        getitem_191 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        silu__default_63 = torch.ops.aten.silu_.default(getitem_189)
        mean_dim_21 = torch.ops.aten.mean.dim(silu__default_63, [2, 3], True)
        convolution_default_106 = torch.ops.aten.convolution.default(mean_dim_21, primals_152, primals_151, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_151 = None
        silu__default_64 = torch.ops.aten.silu_.default(convolution_default_106)
        convolution_default_107 = torch.ops.aten.convolution.default(silu__default_64, primals_150, primals_149, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_149 = None
        sigmoid_default_21 = torch.ops.aten.sigmoid.default(convolution_default_107);  convolution_default_107 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(silu__default_63, sigmoid_default_21)
        convolution_default_108 = torch.ops.aten.convolution.default(mul_tensor_21, primals_148, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_79 = torch.ops.aten.add.Tensor(primals_485, 1);  primals_485 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_488, primals_489, primals_486, primals_487, True, 0.1, 0.001);  primals_489 = None
        getitem_192 = native_batch_norm_default_64[0]
        getitem_193 = native_batch_norm_default_64[1]
        getitem_194 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        convolution_default_109 = torch.ops.aten.convolution.default(getitem_192, primals_154, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_80 = torch.ops.aten.add.Tensor(primals_490, 1);  primals_490 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_493, primals_494, primals_491, primals_492, True, 0.1, 0.001);  primals_494 = None
        getitem_195 = native_batch_norm_default_65[0]
        getitem_196 = native_batch_norm_default_65[1]
        getitem_197 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        silu__default_65 = torch.ops.aten.silu_.default(getitem_195)
        convolution_default_110 = torch.ops.aten.convolution.default(silu__default_65, primals_153, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1912)
        add_tensor_81 = torch.ops.aten.add.Tensor(primals_495, 1);  primals_495 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_498, primals_499, primals_496, primals_497, True, 0.1, 0.001);  primals_499 = None
        getitem_198 = native_batch_norm_default_66[0]
        getitem_199 = native_batch_norm_default_66[1]
        getitem_200 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        silu__default_66 = torch.ops.aten.silu_.default(getitem_198)
        mean_dim_22 = torch.ops.aten.mean.dim(silu__default_66, [2, 3], True)
        convolution_default_111 = torch.ops.aten.convolution.default(mean_dim_22, primals_159, primals_158, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_158 = None
        silu__default_67 = torch.ops.aten.silu_.default(convolution_default_111)
        convolution_default_112 = torch.ops.aten.convolution.default(silu__default_67, primals_157, primals_156, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_156 = None
        sigmoid_default_22 = torch.ops.aten.sigmoid.default(convolution_default_112);  convolution_default_112 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(silu__default_66, sigmoid_default_22)
        convolution_default_113 = torch.ops.aten.convolution.default(mul_tensor_22, primals_155, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_82 = torch.ops.aten.add.Tensor(primals_500, 1);  primals_500 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_503, primals_504, primals_501, primals_502, True, 0.1, 0.001);  primals_504 = None
        getitem_201 = native_batch_norm_default_67[0]
        getitem_202 = native_batch_norm_default_67[1]
        getitem_203 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(getitem_201, getitem_192);  getitem_201 = None
        convolution_default_114 = torch.ops.aten.convolution.default(add_tensor_83, primals_162, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_84 = torch.ops.aten.add.Tensor(primals_505, 1);  primals_505 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_508, primals_509, primals_506, primals_507, True, 0.1, 0.001);  primals_509 = None
        getitem_204 = native_batch_norm_default_68[0]
        getitem_205 = native_batch_norm_default_68[1]
        getitem_206 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        silu__default_68 = torch.ops.aten.silu_.default(getitem_204)
        mean_dim_23 = torch.ops.aten.mean.dim(silu__default_68, [-1, -2], True);  silu__default_68 = None
        view_default = torch.ops.aten.view.default(mean_dim_23, [128, 1280]);  mean_dim_23 = None
        t_default = torch.ops.aten.t.default(primals_161);  primals_161 = None
        addmm_default = torch.ops.aten.addmm.default(primals_160, view_default, t_default);  primals_160 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, add_tensor_11, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_24, add_tensor_25, add_tensor_26, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_35, add_tensor_36, add_tensor_37, add_tensor_39, add_tensor_40, add_tensor_41, add_tensor_43, add_tensor_44, add_tensor_45, add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_50, add_tensor_51, add_tensor_52, add_tensor_54, add_tensor_55, add_tensor_56, add_tensor_58, add_tensor_59, add_tensor_60, add_tensor_61, add_tensor_62, add_tensor_63, add_tensor_65, add_tensor_66, add_tensor_67, add_tensor_69, add_tensor_70, add_tensor_71, add_tensor_73, add_tensor_74, add_tensor_75, add_tensor_77, add_tensor_78, add_tensor_79, add_tensor_80, add_tensor_81, add_tensor_82, add_tensor_84, getitem_27, primals_38, getitem_25, silu__default_19, primals_457, getitem_26, silu__default_26, primals_34, mul_tensor_6, silu__default_10, convolution_default_30, silu__default_7, getitem_24, sigmoid_default_6, silu__default_17, convolution_default_33, mul_tensor_3, primals_461, getitem_21, getitem_54, getitem_83, primals_89, convolution_default_15, mean_dim_9, sigmoid_default_2, sigmoid_default_3, getitem_82, silu__default_8, convolution_default_18, convolution_default_13, getitem_56, primals_308, mean_dim_6, primals_306, primals_463, getitem_55, primals_427, getitem_58, getitem_59, getitem_61, primals_411, getitem_29, mean_dim_3, getitem_28, getitem_81, getitem_31, getitem_32, primals_90, primals_29, getitem_22, getitem_23, primals_443, silu__default_27, primals_36, mul_tensor_2, primals_326, convolution_default_34, add_tensor_23, convolution_default_46, silu__default_18, primals_87, primals_462, primals_35, convolution_default_19, add_tensor_12, primals_458, convolution_default_16, convolution_default_31, primals_322, silu__default_9, primals_33, primals_506, convolution_default_14, primals_327, getitem_60, primals_177, primals_307, primals_323, primals_448, primals_40, getitem_33, getitem_62, primals_426, silu__default_28, primals_91, primals_31, primals_139, primals_292, getitem_117, convolution_default_68, convolution_default_89, getitem_159, sigmoid_default_10, primals_20, silu__default_29, primals_278, getitem_158, primals_22, primals_134, primals_241, convolution_default_53, getitem_119, getitem_5, mean_dim, convolution_default_35, getitem_4, getitem_118, convolution_default_66, silu__default_20, mean_dim_13, convolution_default_69, convolution_default_2, primals_140, getitem_121, primals_138, getitem_122, primals_317, getitem_63, primals_238, getitem_92, mean_dim_10, primals_237, primals_366, getitem_91, add_tensor_64, primals_136, primals_236, primals_368, getitem_95, convolution_default_54, getitem_123, primals_481, primals_145, primals_286, getitem_65, primals_483, mean_dim_7, getitem_94, getitem_64, getitem_96, getitem_186, primals_28, primals_141, getitem_3, primals_21, primals_233, primals_281, primals_477, add_tensor_49, primals_473, getitem_162, primals_143, primals_318, primals_476, silu__default_39, silu__default_1, getitem_160, primals_412, getitem_90, primals_232, primals_147, getitem_97, primals_26, add_tensor_38, getitem_125, primals_282, primals_17, silu__default_30, getitem_124, primals_24, primals_478, mul_tensor_10, primals_243, primals_283, primals_242, convolution_default_51, primals_482, silu__default_21, primals_403, primals_291, getitem_98, silu__default_53, primals_287, convolution_default_36, primals_246, silu__default_40, silu__default_2, primals_247, primals_146, convolution_default_90, primals_19, primals_433, mul_tensor_13, primals_231, mul_tensor, silu__default_41, primals_248, convolution_default_55, sigmoid_default_13, primals_367, sigmoid_default, silu__default_31, primals_27, primals_321, primals_472, convolution_default_70, convolution_default_71, getitem_153, primals_4, convolution_default_86, convolution_default_104, silu__default_22, mean_dim_17, getitem_35, getitem_154, getitem_184, mean_dim_14, primals_491, getitem_128, getitem_185, getitem_155, primals_61, mul_tensor_7, getitem_127, primals_70, getitem_34, sigmoid_default_7, add_tensor_76, convolution_default_38, primals_77, primals_296, primals_417, primals_2, primals_69, primals_297, primals_6, convolution_default_20, silu__default_60, silu__default_11, primals_122, primals_62, getitem_188, mean_dim_21, primals_59, primals_303, getitem_36, primals_441, silu__default_51, getitem_187, convolution_default_101, primals_124, primals_487, primals_64, primals_125, getitem_67, primals_492, getitem_68, silu__default_42, getitem_126, getitem_38, mean_dim_4, primals_508, getitem_37, constant_pad_nd_default_3, primals_438, primals_507, silu__default_61, primals_73, primals_66, primals_496, primals_75, primals_227, primals_298, primals_63, primals_76, primals_228, primals_301, silu__default_52, primals_71, convolution_default_39, add_tensor_27, silu__default_62, primals_423, primals_486, primals_1, primals_302, primals_442, mul_tensor_20, convolution_default_105, primals_103, getitem_70, sigmoid_default_20, silu__default_43, getitem_189, silu__default_12, primals_488, getitem_69, primals_493, convolution_default_40, sigmoid_default_17, convolution_default_103, primals_416, primals_453, convolution_default_21, mul_tensor_17, getitem_190, mul_tensor_14, convolution_default_88, primals_226, getitem_71, primals_422, getitem_191, primals_68, sigmoid_default_14, primals_352, primals_362, primals_397, primals_104, primals_392, convolution_default_73, getitem_194, primals_106, primals_223, primals_391, convolution_default_58, primals_401, primals_503, silu__default_13, convolution_default_109, primals_213, getitem_131, getitem_195, convolution_default_74, primals_471, mul_tensor_4, getitem_130, primals_217, primals_373, getitem_132, getitem_104, getitem_157, sigmoid_default_4, convolution_default_59, getitem_197, convolution_default_23, getitem_196, getitem_103, primals_396, primals_222, primals_357, getitem_105, add_tensor_53, primals_216, getitem_40, add_tensor_42, getitem_134, getitem_41, primals_361, primals_468, constant_pad_nd_default_2, primals_407, getitem_133, primals_348, primals_353, getitem_42, silu__default_65, primals_176, primals_378, getitem_107, primals_402, getitem_106, primals_466, primals_356, convolution_default_110, mean_dim_22, primals_406, primals_388, convolution_default_24, primals_351, primals_363, add_tensor_16, getitem_199, primals_393, primals_108, primals_218, primals_467, primals_105, getitem_198, primals_173, primals_221, convolution_default_25, silu__default_44, primals_398, primals_358, primals_502, primals_376, convolution_default_60, getitem_200, primals_501, primals_377, getitem_43, convolution_default_75, silu__default_35, getitem_44, mean_dim_15, silu__default_32, primals_83, getitem_167, getitem_168, primals_14, getitem_137, getitem_135, getitem_166, getitem_136, constant_pad_nd_default_4, getitem_73, silu__default_63, getitem_101, primals_451, mean_dim_11, getitem_100, add_tensor_68, primals_49, mean_dim_8, getitem_46, primals_47, getitem_72, primals_10, convolution_default_106, primals_78, mean_dim_5, getitem_170, primals_126, getitem_74, convolution_default_94, getitem_45, silu__default_45, mean_dim_19, convolution_default_76, primals_8, getitem_169, primals_131, primals_13, getitem_99, primals_84, getitem_47, silu__default_64, primals_7, primals_48, silu__default_33, getitem_161, primals_132, primals_168, primals_12, sigmoid_default_11, convolution_default_56, primals_172, primals_418, mul_tensor_21, primals_15, silu__default_24, silu__default_46, primals_129, silu__default_56, sigmoid_default_21, primals_171, convolution_default_41, primals_80, primals_127, silu__default_15, getitem_192, convolution_default_95, convolution_default_108, getitem_171, primals_82, convolution_default_26, sigmoid_default_15, primals_45, primals_428, silu__default_34, primals_133, mul_tensor_11, mul_tensor_15, silu__default_25, getitem_172, getitem_193, convolution_default_78, mean_dim_18, getitem_163, primals_118, getitem_16, primals_202, getitem_6, convolution_default_63, primals_456, primals_212, getitem_164, primals_41, primals_452, getitem_111, primals_313, primals_191, getitem_15, getitem_140, primals_208, getitem_9, getitem_141, getitem_7, convolution_default_79, getitem_8, primals_193, silu__default_4, getitem_139, getitem_113, convolution_default_4, getitem_17, getitem_112, getitem_114, silu__default_54, primals_211, sigmoid_default_1, add_tensor_57, convolution_default_91, convolution_default_8, convolution_default_10, primals_112, primals_201, primals_113, convolution_default_5, primals_288, primals_196, primals_293, convolution_default, convolution_default_64, getitem_143, primals_42, primals_311, getitem, getitem_18, primals_383, getitem_142, primals_312, primals_387, primals_110, getitem_11, constant_pad_nd_default_1, getitem_1, getitem_19, getitem_10, getitem_20, getitem_116, silu__default_55, getitem_13, primals_197, getitem_14, getitem_115, primals_119, getitem_2, mul_tensor_1, primals_111, primals_316, sigmoid_default_18, convolution_default_11, primals_117, convolution_default_9, mul_tensor_18, add_tensor_5, mean_dim_1, silu__default_6, convolution_default_65, convolution_default_93, primals_192, primals_386, primals_43, convolution_default_1, silu__default_3, primals_120, silu__default_38, primals_198, silu__default, primals_115, convolution_default_6, mean_dim_2, convolution_default_80, primals_342, primals_206, primals_159, getitem_75, primals_381, silu__default_16, mul_tensor_8, primals_92, primals_181, primals_437, primals_271, add_tensor_83, primals_257, primals_162, mul_tensor_5, sigmoid_default_8, silu__default_66, getitem_110, primals_85, primals_178, primals_258, getitem_48, convolution_default_43, mean_dim_12, sigmoid_default_5, getitem_109, primals_341, getitem_206, convolution_default_28, getitem_205, convolution_default_111, view_default, primals_183, primals_272, primals_338, getitem_76, primals_273, getitem_77, primals_497, getitem_108, silu__default_67, primals_261, primals_347, primals_148, primals_203, getitem_79, primals_166, primals_421, getitem_49, primals_153, primals_262, getitem_50, silu__default_36, convolution_default_114, getitem_204, primals_346, primals_167, primals_182, sigmoid_default_22, primals_382, getitem_51, primals_413, constant_pad_nd_default, convolution_default_61, primals_267, convolution_default_44, primals_186, primals_163, primals_157, primals_150, primals_263, primals_187, primals_207, convolution_default_29, getitem_78, primals_154, convolution_default_113, primals_276, primals_498, t_default, primals_277, primals_436, primals_94, primals_268, convolution_default_45, getitem_80, getitem_202, silu__default_37, primals_152, mul_tensor_22, getitem_52, sigmoid_default_12, primals_188, primals_343, mul_tensor_12, primals_155, getitem_53, primals_266, getitem_203, getitem_147, primals_447, getitem_173, getitem_177, mul_tensor_9, mean_dim_16, getitem_145, getitem_175, convolution_default_99, primals_57, primals_96, getitem_144, primals_101, sigmoid_default_9, getitem_146, getitem_149, getitem_150, getitem_176, primals_431, convolution_default_48, getitem_148, primals_252, primals_56, primals_331, add_tensor_72, silu__default_57, primals_97, primals_432, convolution_default_84, getitem_85, primals_336, primals_408, getitem_86, convolution_default_49, convolution_default_81, getitem_179, mean_dim_20, primals_98, silu__default_48, getitem_178, convolution_default_96, primals_371, getitem_87, getitem_152, getitem_151, primals_333, silu__default_58, getitem_88, primals_50, add_tensor_34, primals_446, primals_328, convolution_default_83, primals_332, silu__default_49, silu__default_59, primals_99, primals_54, sigmoid_default_19, primals_372, primals_55, getitem_89, convolution_default_100, silu__default_50, getitem_180, primals_337, mul_tensor_19, primals_52, primals_253, sigmoid_default_16, convolution_default_98, primals_251, convolution_default_85, mul_tensor_16, getitem_181, primals_256, getitem_182, convolution_default_50]
        
