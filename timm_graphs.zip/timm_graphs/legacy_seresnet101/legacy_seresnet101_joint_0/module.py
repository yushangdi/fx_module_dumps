
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/legacy_seresnet101/legacy_seresnet101_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_759, primals_3, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_5, 1);  primals_5 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_8, primals_4, primals_6, primals_7, True, 0.1, 1e-05);  primals_4 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [0, 0], [1, 1], True)
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_1 = torch.ops.aten.convolution.default(getitem_3, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_10, 1);  primals_10 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_13, primals_9, primals_11, primals_12, True, 0.1, 1e-05);  primals_9 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_15, 1);  primals_15 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_18, primals_14, primals_16, primals_17, True, 0.1, 1e-05);  primals_14 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_20, 1);  primals_20 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_23, primals_19, primals_21, primals_22, True, 0.1, 1e-05);  primals_19 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_3, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_29, 1);  primals_29 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_32, primals_28, primals_30, primals_31, True, 0.1, 1e-05);  primals_28 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim = torch.ops.aten.mean.dim(getitem_11, [2, 3], True)
        convolution_default_5 = torch.ops.aten.convolution.default(mean_dim, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        relu__default_3 = torch.ops.aten.relu_.default(convolution_default_5);  convolution_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_3, primals_36, primals_35, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_35 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_6);  convolution_default_6 = None
        mul_tensor = torch.ops.aten.mul.Tensor(getitem_11, sigmoid_default)
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor, getitem_14);  mul_tensor = getitem_14 = None
        relu__default_4 = torch.ops.aten.relu_.default(add_tensor);  add_tensor = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_4, primals_52, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_38, 1);  primals_38 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_41, primals_37, primals_39, primals_40, True, 0.1, 1e-05);  primals_37 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_53, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_43, 1);  primals_43 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_46, primals_42, primals_44, primals_45, True, 0.1, 1e-05);  primals_42 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_54, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_7 = torch.ops.aten.add_.Tensor(primals_48, 1);  primals_48 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_51, primals_47, primals_49, primals_50, True, 0.1, 1e-05);  primals_47 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_1 = torch.ops.aten.mean.dim(getitem_23, [2, 3], True)
        convolution_default_10 = torch.ops.aten.convolution.default(mean_dim_1, primals_56, primals_55, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_55 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_10);  convolution_default_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_7, primals_58, primals_57, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_57 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_11);  convolution_default_11 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(getitem_23, sigmoid_default_1)
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_1, relu__default_4);  mul_tensor_1 = None
        relu__default_8 = torch.ops.aten.relu_.default(add_tensor_1);  add_tensor_1 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_8, primals_74, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_60, 1);  primals_60 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_63, primals_59, primals_61, primals_62, True, 0.1, 1e-05);  primals_59 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_9, primals_75, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_65, 1);  primals_65 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_68, primals_64, primals_66, primals_67, True, 0.1, 1e-05);  primals_64 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_10, primals_76, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_70, 1);  primals_70 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_73, primals_69, primals_71, primals_72, True, 0.1, 1e-05);  primals_69 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_2 = torch.ops.aten.mean.dim(getitem_32, [2, 3], True)
        convolution_default_15 = torch.ops.aten.convolution.default(mean_dim_2, primals_78, primals_77, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_77 = None
        relu__default_11 = torch.ops.aten.relu_.default(convolution_default_15);  convolution_default_15 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_11, primals_80, primals_79, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_79 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_16);  convolution_default_16 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(getitem_32, sigmoid_default_2)
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_2, relu__default_8);  mul_tensor_2 = None
        relu__default_12 = torch.ops.aten.relu_.default(add_tensor_2);  add_tensor_2 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_12, primals_96, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(primals_82, 1);  primals_82 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_13, primals_97, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_87, 1);  primals_87 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_90, primals_86, primals_88, primals_89, True, 0.1, 1e-05);  primals_86 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_14, primals_98, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_92, 1);  primals_92 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_95, primals_91, primals_93, primals_94, True, 0.1, 1e-05);  primals_91 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_12, primals_99, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_14 = torch.ops.aten.add_.Tensor(primals_101, 1);  primals_101 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_104, primals_100, primals_102, primals_103, True, 0.1, 1e-05);  primals_100 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_3 = torch.ops.aten.mean.dim(getitem_41, [2, 3], True)
        convolution_default_21 = torch.ops.aten.convolution.default(mean_dim_3, primals_106, primals_105, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_105 = None
        relu__default_15 = torch.ops.aten.relu_.default(convolution_default_21);  convolution_default_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_15, primals_108, primals_107, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_107 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_22);  convolution_default_22 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(getitem_41, sigmoid_default_3)
        add_tensor_3 = torch.ops.aten.add.Tensor(mul_tensor_3, getitem_44);  mul_tensor_3 = getitem_44 = None
        relu__default_16 = torch.ops.aten.relu_.default(add_tensor_3);  add_tensor_3 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_16, primals_124, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_110, 1);  primals_110 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_113, primals_109, primals_111, primals_112, True, 0.1, 1e-05);  primals_109 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_17, primals_125, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_115, 1);  primals_115 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_118, primals_114, primals_116, primals_117, True, 0.1, 1e-05);  primals_114 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_18, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_120, 1);  primals_120 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_123, primals_119, primals_121, primals_122, True, 0.1, 1e-05);  primals_119 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_4 = torch.ops.aten.mean.dim(getitem_53, [2, 3], True)
        convolution_default_26 = torch.ops.aten.convolution.default(mean_dim_4, primals_128, primals_127, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_127 = None
        relu__default_19 = torch.ops.aten.relu_.default(convolution_default_26);  convolution_default_26 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_19, primals_130, primals_129, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_129 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_27);  convolution_default_27 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(getitem_53, sigmoid_default_4)
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_4, relu__default_16);  mul_tensor_4 = None
        relu__default_20 = torch.ops.aten.relu_.default(add_tensor_4);  add_tensor_4 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_20, primals_146, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_132, 1);  primals_132 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_135, primals_131, primals_133, primals_134, True, 0.1, 1e-05);  primals_131 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_21, primals_147, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_19 = torch.ops.aten.add_.Tensor(primals_137, 1);  primals_137 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_140, primals_136, primals_138, primals_139, True, 0.1, 1e-05);  primals_136 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_22, primals_148, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_20 = torch.ops.aten.add_.Tensor(primals_142, 1);  primals_142 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_145, primals_141, primals_143, primals_144, True, 0.1, 1e-05);  primals_141 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_5 = torch.ops.aten.mean.dim(getitem_62, [2, 3], True)
        convolution_default_31 = torch.ops.aten.convolution.default(mean_dim_5, primals_150, primals_149, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_149 = None
        relu__default_23 = torch.ops.aten.relu_.default(convolution_default_31);  convolution_default_31 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_23, primals_152, primals_151, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_151 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_32);  convolution_default_32 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(getitem_62, sigmoid_default_5)
        add_tensor_5 = torch.ops.aten.add.Tensor(mul_tensor_5, relu__default_20);  mul_tensor_5 = None
        relu__default_24 = torch.ops.aten.relu_.default(add_tensor_5);  add_tensor_5 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_24, primals_168, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_154, 1);  primals_154 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_157, primals_153, primals_155, primals_156, True, 0.1, 1e-05);  primals_153 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_25, primals_169, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_159, 1);  primals_159 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_162, primals_158, primals_160, primals_161, True, 0.1, 1e-05);  primals_158 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_26, primals_170, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_23 = torch.ops.aten.add_.Tensor(primals_164, 1);  primals_164 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_167, primals_163, primals_165, primals_166, True, 0.1, 1e-05);  primals_163 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_6 = torch.ops.aten.mean.dim(getitem_71, [2, 3], True)
        convolution_default_36 = torch.ops.aten.convolution.default(mean_dim_6, primals_172, primals_171, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_171 = None
        relu__default_27 = torch.ops.aten.relu_.default(convolution_default_36);  convolution_default_36 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_27, primals_174, primals_173, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_173 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_37);  convolution_default_37 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(getitem_71, sigmoid_default_6)
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_6, relu__default_24);  mul_tensor_6 = None
        relu__default_28 = torch.ops.aten.relu_.default(add_tensor_6);  add_tensor_6 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_28, primals_190, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_24 = torch.ops.aten.add_.Tensor(primals_176, 1);  primals_176 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_179, primals_175, primals_177, primals_178, True, 0.1, 1e-05);  primals_175 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_29, primals_191, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_25 = torch.ops.aten.add_.Tensor(primals_181, 1);  primals_181 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_184, primals_180, primals_182, primals_183, True, 0.1, 1e-05);  primals_180 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_30, primals_192, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_26 = torch.ops.aten.add_.Tensor(primals_186, 1);  primals_186 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_189, primals_185, primals_187, primals_188, True, 0.1, 1e-05);  primals_185 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_28, primals_193, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_195, 1);  primals_195 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_198, primals_194, primals_196, primals_197, True, 0.1, 1e-05);  primals_194 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_7 = torch.ops.aten.mean.dim(getitem_80, [2, 3], True)
        convolution_default_42 = torch.ops.aten.convolution.default(mean_dim_7, primals_200, primals_199, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_199 = None
        relu__default_31 = torch.ops.aten.relu_.default(convolution_default_42);  convolution_default_42 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_31, primals_202, primals_201, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_201 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_43);  convolution_default_43 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(getitem_80, sigmoid_default_7)
        add_tensor_7 = torch.ops.aten.add.Tensor(mul_tensor_7, getitem_83);  mul_tensor_7 = getitem_83 = None
        relu__default_32 = torch.ops.aten.relu_.default(add_tensor_7);  add_tensor_7 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_32, primals_438, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_28 = torch.ops.aten.add_.Tensor(primals_424, 1);  primals_424 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_427, primals_423, primals_425, primals_426, True, 0.1, 1e-05);  primals_423 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_33 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_33, primals_439, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_29 = torch.ops.aten.add_.Tensor(primals_429, 1);  primals_429 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_432, primals_428, primals_430, primals_431, True, 0.1, 1e-05);  primals_428 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_34 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_34, primals_440, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_434, 1);  primals_434 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_437, primals_433, primals_435, primals_436, True, 0.1, 1e-05);  primals_433 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_8 = torch.ops.aten.mean.dim(getitem_92, [2, 3], True)
        convolution_default_47 = torch.ops.aten.convolution.default(mean_dim_8, primals_442, primals_441, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_441 = None
        relu__default_35 = torch.ops.aten.relu_.default(convolution_default_47);  convolution_default_47 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_35, primals_444, primals_443, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_443 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_48);  convolution_default_48 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(getitem_92, sigmoid_default_8)
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_8, relu__default_32);  mul_tensor_8 = None
        relu__default_36 = torch.ops.aten.relu_.default(add_tensor_8);  add_tensor_8 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_36, primals_526, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_512, 1);  primals_512 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_515, primals_511, primals_513, primals_514, True, 0.1, 1e-05);  primals_511 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_37, primals_527, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_32 = torch.ops.aten.add_.Tensor(primals_517, 1);  primals_517 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_520, primals_516, primals_518, primals_519, True, 0.1, 1e-05);  primals_516 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_38 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_38, primals_528, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_522, 1);  primals_522 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_525, primals_521, primals_523, primals_524, True, 0.1, 1e-05);  primals_521 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_9 = torch.ops.aten.mean.dim(getitem_101, [2, 3], True)
        convolution_default_52 = torch.ops.aten.convolution.default(mean_dim_9, primals_530, primals_529, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_529 = None
        relu__default_39 = torch.ops.aten.relu_.default(convolution_default_52);  convolution_default_52 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_39, primals_532, primals_531, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_531 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_53);  convolution_default_53 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(getitem_101, sigmoid_default_9)
        add_tensor_9 = torch.ops.aten.add.Tensor(mul_tensor_9, relu__default_36);  mul_tensor_9 = None
        relu__default_40 = torch.ops.aten.relu_.default(add_tensor_9);  add_tensor_9 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_40, primals_548, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_34 = torch.ops.aten.add_.Tensor(primals_534, 1);  primals_534 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_537, primals_533, primals_535, primals_536, True, 0.1, 1e-05);  primals_533 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_41 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_41, primals_549, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_35 = torch.ops.aten.add_.Tensor(primals_539, 1);  primals_539 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_542, primals_538, primals_540, primals_541, True, 0.1, 1e-05);  primals_538 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_42 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_42, primals_550, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_36 = torch.ops.aten.add_.Tensor(primals_544, 1);  primals_544 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_547, primals_543, primals_545, primals_546, True, 0.1, 1e-05);  primals_543 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_10 = torch.ops.aten.mean.dim(getitem_110, [2, 3], True)
        convolution_default_57 = torch.ops.aten.convolution.default(mean_dim_10, primals_552, primals_551, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_551 = None
        relu__default_43 = torch.ops.aten.relu_.default(convolution_default_57);  convolution_default_57 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_43, primals_554, primals_553, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_553 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_58);  convolution_default_58 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(getitem_110, sigmoid_default_10)
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_10, relu__default_40);  mul_tensor_10 = None
        relu__default_44 = torch.ops.aten.relu_.default(add_tensor_10);  add_tensor_10 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_44, primals_570, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_556, 1);  primals_556 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_559, primals_555, primals_557, primals_558, True, 0.1, 1e-05);  primals_555 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_45 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_45, primals_571, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_38 = torch.ops.aten.add_.Tensor(primals_561, 1);  primals_561 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_564, primals_560, primals_562, primals_563, True, 0.1, 1e-05);  primals_560 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_46 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_46, primals_572, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_39 = torch.ops.aten.add_.Tensor(primals_566, 1);  primals_566 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_569, primals_565, primals_567, primals_568, True, 0.1, 1e-05);  primals_565 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_11 = torch.ops.aten.mean.dim(getitem_119, [2, 3], True)
        convolution_default_62 = torch.ops.aten.convolution.default(mean_dim_11, primals_574, primals_573, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_573 = None
        relu__default_47 = torch.ops.aten.relu_.default(convolution_default_62);  convolution_default_62 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_47, primals_576, primals_575, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_575 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_63);  convolution_default_63 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(getitem_119, sigmoid_default_11)
        add_tensor_11 = torch.ops.aten.add.Tensor(mul_tensor_11, relu__default_44);  mul_tensor_11 = None
        relu__default_48 = torch.ops.aten.relu_.default(add_tensor_11);  add_tensor_11 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_48, primals_592, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_40 = torch.ops.aten.add_.Tensor(primals_578, 1);  primals_578 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_49 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_49, primals_593, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_41 = torch.ops.aten.add_.Tensor(primals_583, 1);  primals_583 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_586, primals_582, primals_584, primals_585, True, 0.1, 1e-05);  primals_582 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_50 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_50, primals_594, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_42 = torch.ops.aten.add_.Tensor(primals_588, 1);  primals_588 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_591, primals_587, primals_589, primals_590, True, 0.1, 1e-05);  primals_587 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_12 = torch.ops.aten.mean.dim(getitem_128, [2, 3], True)
        convolution_default_67 = torch.ops.aten.convolution.default(mean_dim_12, primals_596, primals_595, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_595 = None
        relu__default_51 = torch.ops.aten.relu_.default(convolution_default_67);  convolution_default_67 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_51, primals_598, primals_597, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_597 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_68);  convolution_default_68 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(getitem_128, sigmoid_default_12)
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_12, relu__default_48);  mul_tensor_12 = None
        relu__default_52 = torch.ops.aten.relu_.default(add_tensor_12);  add_tensor_12 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_52, primals_614, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_43 = torch.ops.aten.add_.Tensor(primals_600, 1);  primals_600 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_603, primals_599, primals_601, primals_602, True, 0.1, 1e-05);  primals_599 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_53 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_53, primals_615, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_44 = torch.ops.aten.add_.Tensor(primals_605, 1);  primals_605 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_608, primals_604, primals_606, primals_607, True, 0.1, 1e-05);  primals_604 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_54 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_54, primals_616, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_45 = torch.ops.aten.add_.Tensor(primals_610, 1);  primals_610 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_613, primals_609, primals_611, primals_612, True, 0.1, 1e-05);  primals_609 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_71, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_13 = torch.ops.aten.mean.dim(getitem_137, [2, 3], True)
        convolution_default_72 = torch.ops.aten.convolution.default(mean_dim_13, primals_618, primals_617, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_617 = None
        relu__default_55 = torch.ops.aten.relu_.default(convolution_default_72);  convolution_default_72 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_55, primals_620, primals_619, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_619 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_73);  convolution_default_73 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(getitem_137, sigmoid_default_13)
        add_tensor_13 = torch.ops.aten.add.Tensor(mul_tensor_13, relu__default_52);  mul_tensor_13 = None
        relu__default_56 = torch.ops.aten.relu_.default(add_tensor_13);  add_tensor_13 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_56, primals_636, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_46 = torch.ops.aten.add_.Tensor(primals_622, 1);  primals_622 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_625, primals_621, primals_623, primals_624, True, 0.1, 1e-05);  primals_621 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_57 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_57, primals_637, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_47 = torch.ops.aten.add_.Tensor(primals_627, 1);  primals_627 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_630, primals_626, primals_628, primals_629, True, 0.1, 1e-05);  primals_626 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_58 = torch.ops.aten.relu_.default(getitem_143);  getitem_143 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_58, primals_638, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_48 = torch.ops.aten.add_.Tensor(primals_632, 1);  primals_632 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_635, primals_631, primals_633, primals_634, True, 0.1, 1e-05);  primals_631 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_14 = torch.ops.aten.mean.dim(getitem_146, [2, 3], True)
        convolution_default_77 = torch.ops.aten.convolution.default(mean_dim_14, primals_640, primals_639, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_639 = None
        relu__default_59 = torch.ops.aten.relu_.default(convolution_default_77);  convolution_default_77 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_59, primals_642, primals_641, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_641 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_78);  convolution_default_78 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(getitem_146, sigmoid_default_14)
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_14, relu__default_56);  mul_tensor_14 = None
        relu__default_60 = torch.ops.aten.relu_.default(add_tensor_14);  add_tensor_14 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_60, primals_658, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_49 = torch.ops.aten.add_.Tensor(primals_644, 1);  primals_644 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_647, primals_643, primals_645, primals_646, True, 0.1, 1e-05);  primals_643 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_61 = torch.ops.aten.relu_.default(getitem_149);  getitem_149 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_61, primals_659, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_50 = torch.ops.aten.add_.Tensor(primals_649, 1);  primals_649 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_652, primals_648, primals_650, primals_651, True, 0.1, 1e-05);  primals_648 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_62 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_62, primals_660, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_51 = torch.ops.aten.add_.Tensor(primals_654, 1);  primals_654 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_657, primals_653, primals_655, primals_656, True, 0.1, 1e-05);  primals_653 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_81, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_15 = torch.ops.aten.mean.dim(getitem_155, [2, 3], True)
        convolution_default_82 = torch.ops.aten.convolution.default(mean_dim_15, primals_662, primals_661, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_661 = None
        relu__default_63 = torch.ops.aten.relu_.default(convolution_default_82);  convolution_default_82 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_63, primals_664, primals_663, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_663 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_83);  convolution_default_83 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(getitem_155, sigmoid_default_15)
        add_tensor_15 = torch.ops.aten.add.Tensor(mul_tensor_15, relu__default_60);  mul_tensor_15 = None
        relu__default_64 = torch.ops.aten.relu_.default(add_tensor_15);  add_tensor_15 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_64, primals_680, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_52 = torch.ops.aten.add_.Tensor(primals_666, 1);  primals_666 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_669, primals_665, primals_667, primals_668, True, 0.1, 1e-05);  primals_665 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_65 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_65, primals_681, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_53 = torch.ops.aten.add_.Tensor(primals_671, 1);  primals_671 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_674, primals_670, primals_672, primals_673, True, 0.1, 1e-05);  primals_670 = None
        getitem_161 = native_batch_norm_default_53[0]
        getitem_162 = native_batch_norm_default_53[1]
        getitem_163 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_66 = torch.ops.aten.relu_.default(getitem_161);  getitem_161 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_66, primals_682, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_54 = torch.ops.aten.add_.Tensor(primals_676, 1);  primals_676 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_679, primals_675, primals_677, primals_678, True, 0.1, 1e-05);  primals_675 = None
        getitem_164 = native_batch_norm_default_54[0]
        getitem_165 = native_batch_norm_default_54[1]
        getitem_166 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_86, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_16 = torch.ops.aten.mean.dim(getitem_164, [2, 3], True)
        convolution_default_87 = torch.ops.aten.convolution.default(mean_dim_16, primals_684, primals_683, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_683 = None
        relu__default_67 = torch.ops.aten.relu_.default(convolution_default_87);  convolution_default_87 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_67, primals_686, primals_685, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_685 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(convolution_default_88);  convolution_default_88 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(getitem_164, sigmoid_default_16)
        add_tensor_16 = torch.ops.aten.add.Tensor(mul_tensor_16, relu__default_64);  mul_tensor_16 = None
        relu__default_68 = torch.ops.aten.relu_.default(add_tensor_16);  add_tensor_16 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_68, primals_218, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_55 = torch.ops.aten.add_.Tensor(primals_204, 1);  primals_204 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_207, primals_203, primals_205, primals_206, True, 0.1, 1e-05);  primals_203 = None
        getitem_167 = native_batch_norm_default_55[0]
        getitem_168 = native_batch_norm_default_55[1]
        getitem_169 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_69 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_69, primals_219, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_56 = torch.ops.aten.add_.Tensor(primals_209, 1);  primals_209 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_212, primals_208, primals_210, primals_211, True, 0.1, 1e-05);  primals_208 = None
        getitem_170 = native_batch_norm_default_56[0]
        getitem_171 = native_batch_norm_default_56[1]
        getitem_172 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_70 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_70, primals_220, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_57 = torch.ops.aten.add_.Tensor(primals_214, 1);  primals_214 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_217, primals_213, primals_215, primals_216, True, 0.1, 1e-05);  primals_213 = None
        getitem_173 = native_batch_norm_default_57[0]
        getitem_174 = native_batch_norm_default_57[1]
        getitem_175 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_91, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_17 = torch.ops.aten.mean.dim(getitem_173, [2, 3], True)
        convolution_default_92 = torch.ops.aten.convolution.default(mean_dim_17, primals_222, primals_221, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_221 = None
        relu__default_71 = torch.ops.aten.relu_.default(convolution_default_92);  convolution_default_92 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_71, primals_224, primals_223, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_223 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_93);  convolution_default_93 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(getitem_173, sigmoid_default_17)
        add_tensor_17 = torch.ops.aten.add.Tensor(mul_tensor_17, relu__default_68);  mul_tensor_17 = None
        relu__default_72 = torch.ops.aten.relu_.default(add_tensor_17);  add_tensor_17 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_72, primals_240, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_58 = torch.ops.aten.add_.Tensor(primals_226, 1);  primals_226 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_229, primals_225, primals_227, primals_228, True, 0.1, 1e-05);  primals_225 = None
        getitem_176 = native_batch_norm_default_58[0]
        getitem_177 = native_batch_norm_default_58[1]
        getitem_178 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_73 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_73, primals_241, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_59 = torch.ops.aten.add_.Tensor(primals_231, 1);  primals_231 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_234, primals_230, primals_232, primals_233, True, 0.1, 1e-05);  primals_230 = None
        getitem_179 = native_batch_norm_default_59[0]
        getitem_180 = native_batch_norm_default_59[1]
        getitem_181 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_95, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_74 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_74, primals_242, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_60 = torch.ops.aten.add_.Tensor(primals_236, 1);  primals_236 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_239, primals_235, primals_237, primals_238, True, 0.1, 1e-05);  primals_235 = None
        getitem_182 = native_batch_norm_default_60[0]
        getitem_183 = native_batch_norm_default_60[1]
        getitem_184 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_96, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_18 = torch.ops.aten.mean.dim(getitem_182, [2, 3], True)
        convolution_default_97 = torch.ops.aten.convolution.default(mean_dim_18, primals_244, primals_243, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_243 = None
        relu__default_75 = torch.ops.aten.relu_.default(convolution_default_97);  convolution_default_97 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_75, primals_246, primals_245, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_245 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(convolution_default_98);  convolution_default_98 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(getitem_182, sigmoid_default_18)
        add_tensor_18 = torch.ops.aten.add.Tensor(mul_tensor_18, relu__default_72);  mul_tensor_18 = None
        relu__default_76 = torch.ops.aten.relu_.default(add_tensor_18);  add_tensor_18 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_76, primals_262, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_61 = torch.ops.aten.add_.Tensor(primals_248, 1);  primals_248 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_251, primals_247, primals_249, primals_250, True, 0.1, 1e-05);  primals_247 = None
        getitem_185 = native_batch_norm_default_61[0]
        getitem_186 = native_batch_norm_default_61[1]
        getitem_187 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_99, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_77 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_77, primals_263, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_62 = torch.ops.aten.add_.Tensor(primals_253, 1);  primals_253 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_256, primals_252, primals_254, primals_255, True, 0.1, 1e-05);  primals_252 = None
        getitem_188 = native_batch_norm_default_62[0]
        getitem_189 = native_batch_norm_default_62[1]
        getitem_190 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_78 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_78, primals_264, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_63 = torch.ops.aten.add_.Tensor(primals_258, 1);  primals_258 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_261, primals_257, primals_259, primals_260, True, 0.1, 1e-05);  primals_257 = None
        getitem_191 = native_batch_norm_default_63[0]
        getitem_192 = native_batch_norm_default_63[1]
        getitem_193 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_101, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_19 = torch.ops.aten.mean.dim(getitem_191, [2, 3], True)
        convolution_default_102 = torch.ops.aten.convolution.default(mean_dim_19, primals_266, primals_265, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_265 = None
        relu__default_79 = torch.ops.aten.relu_.default(convolution_default_102);  convolution_default_102 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_79, primals_268, primals_267, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_267 = None
        sigmoid_default_19 = torch.ops.aten.sigmoid.default(convolution_default_103);  convolution_default_103 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(getitem_191, sigmoid_default_19)
        add_tensor_19 = torch.ops.aten.add.Tensor(mul_tensor_19, relu__default_76);  mul_tensor_19 = None
        relu__default_80 = torch.ops.aten.relu_.default(add_tensor_19);  add_tensor_19 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_80, primals_284, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_64 = torch.ops.aten.add_.Tensor(primals_270, 1);  primals_270 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_273, primals_269, primals_271, primals_272, True, 0.1, 1e-05);  primals_269 = None
        getitem_194 = native_batch_norm_default_64[0]
        getitem_195 = native_batch_norm_default_64[1]
        getitem_196 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_81 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_81, primals_285, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_65 = torch.ops.aten.add_.Tensor(primals_275, 1);  primals_275 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_278, primals_274, primals_276, primals_277, True, 0.1, 1e-05);  primals_274 = None
        getitem_197 = native_batch_norm_default_65[0]
        getitem_198 = native_batch_norm_default_65[1]
        getitem_199 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_105, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_82 = torch.ops.aten.relu_.default(getitem_197);  getitem_197 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_82, primals_286, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_66 = torch.ops.aten.add_.Tensor(primals_280, 1);  primals_280 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_283, primals_279, primals_281, primals_282, True, 0.1, 1e-05);  primals_279 = None
        getitem_200 = native_batch_norm_default_66[0]
        getitem_201 = native_batch_norm_default_66[1]
        getitem_202 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_106, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_20 = torch.ops.aten.mean.dim(getitem_200, [2, 3], True)
        convolution_default_107 = torch.ops.aten.convolution.default(mean_dim_20, primals_288, primals_287, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_287 = None
        relu__default_83 = torch.ops.aten.relu_.default(convolution_default_107);  convolution_default_107 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_83, primals_290, primals_289, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_289 = None
        sigmoid_default_20 = torch.ops.aten.sigmoid.default(convolution_default_108);  convolution_default_108 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(getitem_200, sigmoid_default_20)
        add_tensor_20 = torch.ops.aten.add.Tensor(mul_tensor_20, relu__default_80);  mul_tensor_20 = None
        relu__default_84 = torch.ops.aten.relu_.default(add_tensor_20);  add_tensor_20 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_84, primals_306, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_67 = torch.ops.aten.add_.Tensor(primals_292, 1);  primals_292 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_295, primals_291, primals_293, primals_294, True, 0.1, 1e-05);  primals_291 = None
        getitem_203 = native_batch_norm_default_67[0]
        getitem_204 = native_batch_norm_default_67[1]
        getitem_205 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_85 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_85, primals_307, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_68 = torch.ops.aten.add_.Tensor(primals_297, 1);  primals_297 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_300, primals_296, primals_298, primals_299, True, 0.1, 1e-05);  primals_296 = None
        getitem_206 = native_batch_norm_default_68[0]
        getitem_207 = native_batch_norm_default_68[1]
        getitem_208 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_86 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_86, primals_308, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_69 = torch.ops.aten.add_.Tensor(primals_302, 1);  primals_302 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_305, primals_301, primals_303, primals_304, True, 0.1, 1e-05);  primals_301 = None
        getitem_209 = native_batch_norm_default_69[0]
        getitem_210 = native_batch_norm_default_69[1]
        getitem_211 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_111, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_21 = torch.ops.aten.mean.dim(getitem_209, [2, 3], True)
        convolution_default_112 = torch.ops.aten.convolution.default(mean_dim_21, primals_310, primals_309, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_309 = None
        relu__default_87 = torch.ops.aten.relu_.default(convolution_default_112);  convolution_default_112 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu__default_87, primals_312, primals_311, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_311 = None
        sigmoid_default_21 = torch.ops.aten.sigmoid.default(convolution_default_113);  convolution_default_113 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(getitem_209, sigmoid_default_21)
        add_tensor_21 = torch.ops.aten.add.Tensor(mul_tensor_21, relu__default_84);  mul_tensor_21 = None
        relu__default_88 = torch.ops.aten.relu_.default(add_tensor_21);  add_tensor_21 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu__default_88, primals_328, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_70 = torch.ops.aten.add_.Tensor(primals_314, 1);  primals_314 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_317, primals_313, primals_315, primals_316, True, 0.1, 1e-05);  primals_313 = None
        getitem_212 = native_batch_norm_default_70[0]
        getitem_213 = native_batch_norm_default_70[1]
        getitem_214 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_89 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_89, primals_329, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_71 = torch.ops.aten.add_.Tensor(primals_319, 1);  primals_319 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_322, primals_318, primals_320, primals_321, True, 0.1, 1e-05);  primals_318 = None
        getitem_215 = native_batch_norm_default_71[0]
        getitem_216 = native_batch_norm_default_71[1]
        getitem_217 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_115, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_90 = torch.ops.aten.relu_.default(getitem_215);  getitem_215 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_90, primals_330, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_72 = torch.ops.aten.add_.Tensor(primals_324, 1);  primals_324 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_327, primals_323, primals_325, primals_326, True, 0.1, 1e-05);  primals_323 = None
        getitem_218 = native_batch_norm_default_72[0]
        getitem_219 = native_batch_norm_default_72[1]
        getitem_220 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_22 = torch.ops.aten.mean.dim(getitem_218, [2, 3], True)
        convolution_default_117 = torch.ops.aten.convolution.default(mean_dim_22, primals_332, primals_331, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_331 = None
        relu__default_91 = torch.ops.aten.relu_.default(convolution_default_117);  convolution_default_117 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_91, primals_334, primals_333, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_333 = None
        sigmoid_default_22 = torch.ops.aten.sigmoid.default(convolution_default_118);  convolution_default_118 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(getitem_218, sigmoid_default_22)
        add_tensor_22 = torch.ops.aten.add.Tensor(mul_tensor_22, relu__default_88);  mul_tensor_22 = None
        relu__default_92 = torch.ops.aten.relu_.default(add_tensor_22);  add_tensor_22 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu__default_92, primals_350, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_73 = torch.ops.aten.add_.Tensor(primals_336, 1);  primals_336 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_339, primals_335, primals_337, primals_338, True, 0.1, 1e-05);  primals_335 = None
        getitem_221 = native_batch_norm_default_73[0]
        getitem_222 = native_batch_norm_default_73[1]
        getitem_223 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_93 = torch.ops.aten.relu_.default(getitem_221);  getitem_221 = None
        convolution_default_120 = torch.ops.aten.convolution.default(relu__default_93, primals_351, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_74 = torch.ops.aten.add_.Tensor(primals_341, 1);  primals_341 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_344, primals_340, primals_342, primals_343, True, 0.1, 1e-05);  primals_340 = None
        getitem_224 = native_batch_norm_default_74[0]
        getitem_225 = native_batch_norm_default_74[1]
        getitem_226 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_94 = torch.ops.aten.relu_.default(getitem_224);  getitem_224 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_94, primals_352, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_75 = torch.ops.aten.add_.Tensor(primals_346, 1);  primals_346 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_349, primals_345, primals_347, primals_348, True, 0.1, 1e-05);  primals_345 = None
        getitem_227 = native_batch_norm_default_75[0]
        getitem_228 = native_batch_norm_default_75[1]
        getitem_229 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_121, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_23 = torch.ops.aten.mean.dim(getitem_227, [2, 3], True)
        convolution_default_122 = torch.ops.aten.convolution.default(mean_dim_23, primals_354, primals_353, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_353 = None
        relu__default_95 = torch.ops.aten.relu_.default(convolution_default_122);  convolution_default_122 = None
        convolution_default_123 = torch.ops.aten.convolution.default(relu__default_95, primals_356, primals_355, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_355 = None
        sigmoid_default_23 = torch.ops.aten.sigmoid.default(convolution_default_123);  convolution_default_123 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(getitem_227, sigmoid_default_23)
        add_tensor_23 = torch.ops.aten.add.Tensor(mul_tensor_23, relu__default_92);  mul_tensor_23 = None
        relu__default_96 = torch.ops.aten.relu_.default(add_tensor_23);  add_tensor_23 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_96, primals_372, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_76 = torch.ops.aten.add_.Tensor(primals_358, 1);  primals_358 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_361, primals_357, primals_359, primals_360, True, 0.1, 1e-05);  primals_357 = None
        getitem_230 = native_batch_norm_default_76[0]
        getitem_231 = native_batch_norm_default_76[1]
        getitem_232 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_124, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_97 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu__default_97, primals_373, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_77 = torch.ops.aten.add_.Tensor(primals_363, 1);  primals_363 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_366, primals_362, primals_364, primals_365, True, 0.1, 1e-05);  primals_362 = None
        getitem_233 = native_batch_norm_default_77[0]
        getitem_234 = native_batch_norm_default_77[1]
        getitem_235 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_125, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_98 = torch.ops.aten.relu_.default(getitem_233);  getitem_233 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_98, primals_374, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_78 = torch.ops.aten.add_.Tensor(primals_368, 1);  primals_368 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_371, primals_367, primals_369, primals_370, True, 0.1, 1e-05);  primals_367 = None
        getitem_236 = native_batch_norm_default_78[0]
        getitem_237 = native_batch_norm_default_78[1]
        getitem_238 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_24 = torch.ops.aten.mean.dim(getitem_236, [2, 3], True)
        convolution_default_127 = torch.ops.aten.convolution.default(mean_dim_24, primals_376, primals_375, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_375 = None
        relu__default_99 = torch.ops.aten.relu_.default(convolution_default_127);  convolution_default_127 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_99, primals_378, primals_377, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_377 = None
        sigmoid_default_24 = torch.ops.aten.sigmoid.default(convolution_default_128);  convolution_default_128 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(getitem_236, sigmoid_default_24)
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_24, relu__default_96);  mul_tensor_24 = None
        relu__default_100 = torch.ops.aten.relu_.default(add_tensor_24);  add_tensor_24 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu__default_100, primals_394, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_79 = torch.ops.aten.add_.Tensor(primals_380, 1);  primals_380 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_383, primals_379, primals_381, primals_382, True, 0.1, 1e-05);  primals_379 = None
        getitem_239 = native_batch_norm_default_79[0]
        getitem_240 = native_batch_norm_default_79[1]
        getitem_241 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_129, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_101 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_130 = torch.ops.aten.convolution.default(relu__default_101, primals_395, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_80 = torch.ops.aten.add_.Tensor(primals_385, 1);  primals_385 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_388, primals_384, primals_386, primals_387, True, 0.1, 1e-05);  primals_384 = None
        getitem_242 = native_batch_norm_default_80[0]
        getitem_243 = native_batch_norm_default_80[1]
        getitem_244 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_130, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_102 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_102, primals_396, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_81 = torch.ops.aten.add_.Tensor(primals_390, 1);  primals_390 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_393, primals_389, primals_391, primals_392, True, 0.1, 1e-05);  primals_389 = None
        getitem_245 = native_batch_norm_default_81[0]
        getitem_246 = native_batch_norm_default_81[1]
        getitem_247 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_25 = torch.ops.aten.mean.dim(getitem_245, [2, 3], True)
        convolution_default_132 = torch.ops.aten.convolution.default(mean_dim_25, primals_398, primals_397, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_397 = None
        relu__default_103 = torch.ops.aten.relu_.default(convolution_default_132);  convolution_default_132 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu__default_103, primals_400, primals_399, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_399 = None
        sigmoid_default_25 = torch.ops.aten.sigmoid.default(convolution_default_133);  convolution_default_133 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(getitem_245, sigmoid_default_25)
        add_tensor_25 = torch.ops.aten.add.Tensor(mul_tensor_25, relu__default_100);  mul_tensor_25 = None
        relu__default_104 = torch.ops.aten.relu_.default(add_tensor_25);  add_tensor_25 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_104, primals_416, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_82 = torch.ops.aten.add_.Tensor(primals_402, 1);  primals_402 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_405, primals_401, primals_403, primals_404, True, 0.1, 1e-05);  primals_401 = None
        getitem_248 = native_batch_norm_default_82[0]
        getitem_249 = native_batch_norm_default_82[1]
        getitem_250 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_134, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_105 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu__default_105, primals_417, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_83 = torch.ops.aten.add_.Tensor(primals_407, 1);  primals_407 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_410, primals_406, primals_408, primals_409, True, 0.1, 1e-05);  primals_406 = None
        getitem_251 = native_batch_norm_default_83[0]
        getitem_252 = native_batch_norm_default_83[1]
        getitem_253 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_135, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_106 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_106, primals_418, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_84 = torch.ops.aten.add_.Tensor(primals_412, 1);  primals_412 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_415, primals_411, primals_413, primals_414, True, 0.1, 1e-05);  primals_411 = None
        getitem_254 = native_batch_norm_default_84[0]
        getitem_255 = native_batch_norm_default_84[1]
        getitem_256 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_136, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_26 = torch.ops.aten.mean.dim(getitem_254, [2, 3], True)
        convolution_default_137 = torch.ops.aten.convolution.default(mean_dim_26, primals_420, primals_419, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_419 = None
        relu__default_107 = torch.ops.aten.relu_.default(convolution_default_137);  convolution_default_137 = None
        convolution_default_138 = torch.ops.aten.convolution.default(relu__default_107, primals_422, primals_421, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_421 = None
        sigmoid_default_26 = torch.ops.aten.sigmoid.default(convolution_default_138);  convolution_default_138 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(getitem_254, sigmoid_default_26)
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_26, relu__default_104);  mul_tensor_26 = None
        relu__default_108 = torch.ops.aten.relu_.default(add_tensor_26);  add_tensor_26 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu__default_108, primals_460, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_85 = torch.ops.aten.add_.Tensor(primals_446, 1);  primals_446 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_449, primals_445, primals_447, primals_448, True, 0.1, 1e-05);  primals_445 = None
        getitem_257 = native_batch_norm_default_85[0]
        getitem_258 = native_batch_norm_default_85[1]
        getitem_259 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_139, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_109 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        convolution_default_140 = torch.ops.aten.convolution.default(relu__default_109, primals_461, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_86 = torch.ops.aten.add_.Tensor(primals_451, 1);  primals_451 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_454, primals_450, primals_452, primals_453, True, 0.1, 1e-05);  primals_450 = None
        getitem_260 = native_batch_norm_default_86[0]
        getitem_261 = native_batch_norm_default_86[1]
        getitem_262 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_140, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_110 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_110, primals_462, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_87 = torch.ops.aten.add_.Tensor(primals_456, 1);  primals_456 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_459, primals_455, primals_457, primals_458, True, 0.1, 1e-05);  primals_455 = None
        getitem_263 = native_batch_norm_default_87[0]
        getitem_264 = native_batch_norm_default_87[1]
        getitem_265 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_141, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_27 = torch.ops.aten.mean.dim(getitem_263, [2, 3], True)
        convolution_default_142 = torch.ops.aten.convolution.default(mean_dim_27, primals_464, primals_463, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_463 = None
        relu__default_111 = torch.ops.aten.relu_.default(convolution_default_142);  convolution_default_142 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu__default_111, primals_466, primals_465, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_465 = None
        sigmoid_default_27 = torch.ops.aten.sigmoid.default(convolution_default_143);  convolution_default_143 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(getitem_263, sigmoid_default_27)
        add_tensor_27 = torch.ops.aten.add.Tensor(mul_tensor_27, relu__default_108);  mul_tensor_27 = None
        relu__default_112 = torch.ops.aten.relu_.default(add_tensor_27);  add_tensor_27 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_112, primals_482, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_88 = torch.ops.aten.add_.Tensor(primals_468, 1);  primals_468 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_471, primals_467, primals_469, primals_470, True, 0.1, 1e-05);  primals_467 = None
        getitem_266 = native_batch_norm_default_88[0]
        getitem_267 = native_batch_norm_default_88[1]
        getitem_268 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_144, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_113 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_145 = torch.ops.aten.convolution.default(relu__default_113, primals_483, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_89 = torch.ops.aten.add_.Tensor(primals_473, 1);  primals_473 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_476, primals_472, primals_474, primals_475, True, 0.1, 1e-05);  primals_472 = None
        getitem_269 = native_batch_norm_default_89[0]
        getitem_270 = native_batch_norm_default_89[1]
        getitem_271 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_145, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_114 = torch.ops.aten.relu_.default(getitem_269);  getitem_269 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_114, primals_484, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_90 = torch.ops.aten.add_.Tensor(primals_478, 1);  primals_478 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_481, primals_477, primals_479, primals_480, True, 0.1, 1e-05);  primals_477 = None
        getitem_272 = native_batch_norm_default_90[0]
        getitem_273 = native_batch_norm_default_90[1]
        getitem_274 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_146, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_28 = torch.ops.aten.mean.dim(getitem_272, [2, 3], True)
        convolution_default_147 = torch.ops.aten.convolution.default(mean_dim_28, primals_486, primals_485, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_485 = None
        relu__default_115 = torch.ops.aten.relu_.default(convolution_default_147);  convolution_default_147 = None
        convolution_default_148 = torch.ops.aten.convolution.default(relu__default_115, primals_488, primals_487, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_487 = None
        sigmoid_default_28 = torch.ops.aten.sigmoid.default(convolution_default_148);  convolution_default_148 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(getitem_272, sigmoid_default_28)
        add_tensor_28 = torch.ops.aten.add.Tensor(mul_tensor_28, relu__default_112);  mul_tensor_28 = None
        relu__default_116 = torch.ops.aten.relu_.default(add_tensor_28);  add_tensor_28 = None
        convolution_default_149 = torch.ops.aten.convolution.default(relu__default_116, primals_504, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_91 = torch.ops.aten.add_.Tensor(primals_490, 1);  primals_490 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_493, primals_489, primals_491, primals_492, True, 0.1, 1e-05);  primals_489 = None
        getitem_275 = native_batch_norm_default_91[0]
        getitem_276 = native_batch_norm_default_91[1]
        getitem_277 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_149, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_117 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_150 = torch.ops.aten.convolution.default(relu__default_117, primals_505, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_92 = torch.ops.aten.add_.Tensor(primals_495, 1);  primals_495 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_150, primals_498, primals_494, primals_496, primals_497, True, 0.1, 1e-05);  primals_494 = None
        getitem_278 = native_batch_norm_default_92[0]
        getitem_279 = native_batch_norm_default_92[1]
        getitem_280 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_150, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_118 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu__default_118, primals_506, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_93 = torch.ops.aten.add_.Tensor(primals_500, 1);  primals_500 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_503, primals_499, primals_501, primals_502, True, 0.1, 1e-05);  primals_499 = None
        getitem_281 = native_batch_norm_default_93[0]
        getitem_282 = native_batch_norm_default_93[1]
        getitem_283 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_151, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_29 = torch.ops.aten.mean.dim(getitem_281, [2, 3], True)
        convolution_default_152 = torch.ops.aten.convolution.default(mean_dim_29, primals_508, primals_507, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_507 = None
        relu__default_119 = torch.ops.aten.relu_.default(convolution_default_152);  convolution_default_152 = None
        convolution_default_153 = torch.ops.aten.convolution.default(relu__default_119, primals_510, primals_509, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_509 = None
        sigmoid_default_29 = torch.ops.aten.sigmoid.default(convolution_default_153);  convolution_default_153 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(getitem_281, sigmoid_default_29)
        add_tensor_29 = torch.ops.aten.add.Tensor(mul_tensor_29, relu__default_116);  mul_tensor_29 = None
        relu__default_120 = torch.ops.aten.relu_.default(add_tensor_29);  add_tensor_29 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu__default_120, primals_702, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_94 = torch.ops.aten.add_.Tensor(primals_688, 1);  primals_688 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_284 = native_batch_norm_default_94[0]
        getitem_285 = native_batch_norm_default_94[1]
        getitem_286 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_154, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_121 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_155 = torch.ops.aten.convolution.default(relu__default_121, primals_703, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_95 = torch.ops.aten.add_.Tensor(primals_693, 1);  primals_693 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_696, primals_692, primals_694, primals_695, True, 0.1, 1e-05);  primals_692 = None
        getitem_287 = native_batch_norm_default_95[0]
        getitem_288 = native_batch_norm_default_95[1]
        getitem_289 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_155, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_122 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu__default_122, primals_704, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_96 = torch.ops.aten.add_.Tensor(primals_698, 1);  primals_698 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_701, primals_697, primals_699, primals_700, True, 0.1, 1e-05);  primals_697 = None
        getitem_290 = native_batch_norm_default_96[0]
        getitem_291 = native_batch_norm_default_96[1]
        getitem_292 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_156, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_157 = torch.ops.aten.convolution.default(relu__default_120, primals_705, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_97 = torch.ops.aten.add_.Tensor(primals_707, 1);  primals_707 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_710, primals_706, primals_708, primals_709, True, 0.1, 1e-05);  primals_706 = None
        getitem_293 = native_batch_norm_default_97[0]
        getitem_294 = native_batch_norm_default_97[1]
        getitem_295 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_157, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_30 = torch.ops.aten.mean.dim(getitem_290, [2, 3], True)
        convolution_default_158 = torch.ops.aten.convolution.default(mean_dim_30, primals_712, primals_711, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_711 = None
        relu__default_123 = torch.ops.aten.relu_.default(convolution_default_158);  convolution_default_158 = None
        convolution_default_159 = torch.ops.aten.convolution.default(relu__default_123, primals_714, primals_713, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_713 = None
        sigmoid_default_30 = torch.ops.aten.sigmoid.default(convolution_default_159);  convolution_default_159 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(getitem_290, sigmoid_default_30)
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_30, getitem_293);  mul_tensor_30 = getitem_293 = None
        relu__default_124 = torch.ops.aten.relu_.default(add_tensor_30);  add_tensor_30 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu__default_124, primals_730, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_98 = torch.ops.aten.add_.Tensor(primals_716, 1);  primals_716 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_160, primals_719, primals_715, primals_717, primals_718, True, 0.1, 1e-05);  primals_715 = None
        getitem_296 = native_batch_norm_default_98[0]
        getitem_297 = native_batch_norm_default_98[1]
        getitem_298 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_160, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_125 = torch.ops.aten.relu_.default(getitem_296);  getitem_296 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu__default_125, primals_731, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_99 = torch.ops.aten.add_.Tensor(primals_721, 1);  primals_721 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_724, primals_720, primals_722, primals_723, True, 0.1, 1e-05);  primals_720 = None
        getitem_299 = native_batch_norm_default_99[0]
        getitem_300 = native_batch_norm_default_99[1]
        getitem_301 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_161, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_126 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        convolution_default_162 = torch.ops.aten.convolution.default(relu__default_126, primals_732, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_100 = torch.ops.aten.add_.Tensor(primals_726, 1);  primals_726 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_729, primals_725, primals_727, primals_728, True, 0.1, 1e-05);  primals_725 = None
        getitem_302 = native_batch_norm_default_100[0]
        getitem_303 = native_batch_norm_default_100[1]
        getitem_304 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_162, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_31 = torch.ops.aten.mean.dim(getitem_302, [2, 3], True)
        convolution_default_163 = torch.ops.aten.convolution.default(mean_dim_31, primals_734, primals_733, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_733 = None
        relu__default_127 = torch.ops.aten.relu_.default(convolution_default_163);  convolution_default_163 = None
        convolution_default_164 = torch.ops.aten.convolution.default(relu__default_127, primals_736, primals_735, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_735 = None
        sigmoid_default_31 = torch.ops.aten.sigmoid.default(convolution_default_164);  convolution_default_164 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(getitem_302, sigmoid_default_31)
        add_tensor_31 = torch.ops.aten.add.Tensor(mul_tensor_31, relu__default_124);  mul_tensor_31 = None
        relu__default_128 = torch.ops.aten.relu_.default(add_tensor_31);  add_tensor_31 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_128, primals_752, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_101 = torch.ops.aten.add_.Tensor(primals_738, 1);  primals_738 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_165, primals_741, primals_737, primals_739, primals_740, True, 0.1, 1e-05);  primals_737 = None
        getitem_305 = native_batch_norm_default_101[0]
        getitem_306 = native_batch_norm_default_101[1]
        getitem_307 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_165, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_129 = torch.ops.aten.relu_.default(getitem_305);  getitem_305 = None
        convolution_default_166 = torch.ops.aten.convolution.default(relu__default_129, primals_753, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_102 = torch.ops.aten.add_.Tensor(primals_743, 1);  primals_743 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_746, primals_742, primals_744, primals_745, True, 0.1, 1e-05);  primals_742 = None
        getitem_308 = native_batch_norm_default_102[0]
        getitem_309 = native_batch_norm_default_102[1]
        getitem_310 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_166, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_130 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_167 = torch.ops.aten.convolution.default(relu__default_130, primals_754, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_103 = torch.ops.aten.add_.Tensor(primals_748, 1);  primals_748 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_751, primals_747, primals_749, primals_750, True, 0.1, 1e-05);  primals_747 = None
        getitem_311 = native_batch_norm_default_103[0]
        getitem_312 = native_batch_norm_default_103[1]
        getitem_313 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_167, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_32 = torch.ops.aten.mean.dim(getitem_311, [2, 3], True)
        convolution_default_168 = torch.ops.aten.convolution.default(mean_dim_32, primals_756, primals_755, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_755 = None
        relu__default_131 = torch.ops.aten.relu_.default(convolution_default_168);  convolution_default_168 = None
        convolution_default_169 = torch.ops.aten.convolution.default(relu__default_131, primals_758, primals_757, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_757 = None
        sigmoid_default_32 = torch.ops.aten.sigmoid.default(convolution_default_169);  convolution_default_169 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(getitem_311, sigmoid_default_32)
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_32, relu__default_128);  mul_tensor_32 = None
        relu__default_132 = torch.ops.aten.relu_.default(add_tensor_32);  add_tensor_32 = None
        mean_dim_33 = torch.ops.aten.mean.dim(relu__default_132, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_33, [128, 2048]);  mean_dim_33 = None
        t_default = torch.ops.aten.t.default(primals_2);  primals_2 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1, view_default, t_default);  primals_1 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 2048, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_132, torch.float32);  relu__default_132 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_104, to_dtype);  le_scalar = new_zeros_default_104 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_2, getitem_311);  getitem_311 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_2, sigmoid_default_32)
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_33, [2, 3], True);  mul_tensor_33 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_32, torch.float32);  sigmoid_default_32 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar);  to_dtype_4 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_35);  mul_tensor_35 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_36, torch.float32);  mul_tensor_36 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_5, relu__default_131, primals_758, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = primals_758 = None
        getitem_314 = convolution_backward_default[0]
        getitem_315 = convolution_backward_default[1]
        getitem_316 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_314, torch.float32);  getitem_314 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_131, torch.float32);  relu__default_131 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_105, to_dtype_6);  le_scalar_1 = new_zeros_default_105 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_32, primals_756, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_32 = primals_756 = None
        getitem_317 = convolution_backward_default_1[0]
        getitem_318 = convolution_backward_default_1[1]
        getitem_319 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_317, [128, 2048, 7, 7]);  getitem_317 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(mul_tensor_34, div_scalar_1);  mul_tensor_34 = div_scalar_1 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(add_tensor_33, convolution_default_167, primals_751, primals_749, primals_750, getitem_312, getitem_313, True, 1e-05, [True, True, True]);  add_tensor_33 = convolution_default_167 = primals_751 = primals_749 = primals_750 = getitem_312 = getitem_313 = None
        getitem_320 = native_batch_norm_backward_default[0]
        getitem_321 = native_batch_norm_backward_default[1]
        getitem_322 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_320, relu__default_130, primals_754, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_320 = primals_754 = None
        getitem_323 = convolution_backward_default_2[0]
        getitem_324 = convolution_backward_default_2[1]
        getitem_325 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_323, torch.float32);  getitem_323 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_130, torch.float32);  relu__default_130 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_106, to_dtype_9);  le_scalar_2 = new_zeros_default_106 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_166, primals_746, primals_744, primals_745, getitem_309, getitem_310, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_166 = primals_746 = primals_744 = primals_745 = getitem_309 = getitem_310 = None
        getitem_326 = native_batch_norm_backward_default_1[0]
        getitem_327 = native_batch_norm_backward_default_1[1]
        getitem_328 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_326, relu__default_129, primals_753, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_326 = primals_753 = None
        getitem_329 = convolution_backward_default_3[0]
        getitem_330 = convolution_backward_default_3[1]
        getitem_331 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_329, torch.float32);  getitem_329 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_129, torch.float32);  relu__default_129 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_107, to_dtype_12);  le_scalar_3 = new_zeros_default_107 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_165, primals_741, primals_739, primals_740, getitem_306, getitem_307, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_165 = primals_741 = primals_739 = primals_740 = getitem_306 = getitem_307 = None
        getitem_332 = native_batch_norm_backward_default_2[0]
        getitem_333 = native_batch_norm_backward_default_2[1]
        getitem_334 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_332, relu__default_128, primals_752, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_332 = primals_752 = None
        getitem_335 = convolution_backward_default_4[0]
        getitem_336 = convolution_backward_default_4[1]
        getitem_337 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_335);  to_dtype_2 = getitem_335 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_34, torch.float32);  add_tensor_34 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_128, torch.float32);  relu__default_128 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_108, to_dtype_15);  le_scalar_4 = new_zeros_default_108 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_17, getitem_302);  getitem_302 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_17, sigmoid_default_31)
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_37, [2, 3], True);  mul_tensor_37 = None
        to_dtype_18 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_19 = torch.ops.aten.to.dtype(sigmoid_default_31, torch.float32);  sigmoid_default_31 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_19, 1)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_1);  to_dtype_19 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_39);  mul_tensor_39 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_18, conj_physical_default_1);  to_dtype_18 = conj_physical_default_1 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_40, torch.float32);  mul_tensor_40 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(to_dtype_20, relu__default_127, primals_736, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = primals_736 = None
        getitem_338 = convolution_backward_default_5[0]
        getitem_339 = convolution_backward_default_5[1]
        getitem_340 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_338, torch.float32);  getitem_338 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_127, torch.float32);  relu__default_127 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_109, to_dtype_21);  le_scalar_5 = new_zeros_default_109 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(to_dtype_23, mean_dim_31, primals_734, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_23 = mean_dim_31 = primals_734 = None
        getitem_341 = convolution_backward_default_6[0]
        getitem_342 = convolution_backward_default_6[1]
        getitem_343 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_341, [128, 2048, 7, 7]);  getitem_341 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(mul_tensor_38, div_scalar_2);  mul_tensor_38 = div_scalar_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_35, convolution_default_162, primals_729, primals_727, primals_728, getitem_303, getitem_304, True, 1e-05, [True, True, True]);  add_tensor_35 = convolution_default_162 = primals_729 = primals_727 = primals_728 = getitem_303 = getitem_304 = None
        getitem_344 = native_batch_norm_backward_default_3[0]
        getitem_345 = native_batch_norm_backward_default_3[1]
        getitem_346 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_344, relu__default_126, primals_732, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_344 = primals_732 = None
        getitem_347 = convolution_backward_default_7[0]
        getitem_348 = convolution_backward_default_7[1]
        getitem_349 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_347, torch.float32);  getitem_347 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_126, torch.float32);  relu__default_126 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_110, to_dtype_24);  le_scalar_6 = new_zeros_default_110 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_161, primals_724, primals_722, primals_723, getitem_300, getitem_301, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_161 = primals_724 = primals_722 = primals_723 = getitem_300 = getitem_301 = None
        getitem_350 = native_batch_norm_backward_default_4[0]
        getitem_351 = native_batch_norm_backward_default_4[1]
        getitem_352 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_350, relu__default_125, primals_731, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_350 = primals_731 = None
        getitem_353 = convolution_backward_default_8[0]
        getitem_354 = convolution_backward_default_8[1]
        getitem_355 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_353, torch.float32);  getitem_353 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_125, torch.float32);  relu__default_125 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_111, to_dtype_27);  le_scalar_7 = new_zeros_default_111 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_160, primals_719, primals_717, primals_718, getitem_297, getitem_298, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_160 = primals_719 = primals_717 = primals_718 = getitem_297 = getitem_298 = None
        getitem_356 = native_batch_norm_backward_default_5[0]
        getitem_357 = native_batch_norm_backward_default_5[1]
        getitem_358 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_356, relu__default_124, primals_730, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_356 = primals_730 = None
        getitem_359 = convolution_backward_default_9[0]
        getitem_360 = convolution_backward_default_9[1]
        getitem_361 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(to_dtype_17, getitem_359);  to_dtype_17 = getitem_359 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_36, torch.float32);  add_tensor_36 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_124, torch.float32);  relu__default_124 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_112, to_dtype_30);  le_scalar_8 = new_zeros_default_112 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_32, getitem_290);  getitem_290 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_32, sigmoid_default_30)
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_41, [2, 3], True);  mul_tensor_41 = None
        to_dtype_33 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_34 = torch.ops.aten.to.dtype(sigmoid_default_30, torch.float32);  sigmoid_default_30 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(to_dtype_34, 1)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_2);  to_dtype_34 = rsub_scalar_2 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_43);  mul_tensor_43 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_33, conj_physical_default_2);  to_dtype_33 = conj_physical_default_2 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_44, torch.float32);  mul_tensor_44 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(to_dtype_35, relu__default_123, primals_714, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = primals_714 = None
        getitem_362 = convolution_backward_default_10[0]
        getitem_363 = convolution_backward_default_10[1]
        getitem_364 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_362, torch.float32);  getitem_362 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_123, torch.float32);  relu__default_123 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_113, to_dtype_36);  le_scalar_9 = new_zeros_default_113 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(to_dtype_38, mean_dim_30, primals_712, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_38 = mean_dim_30 = primals_712 = None
        getitem_365 = convolution_backward_default_11[0]
        getitem_366 = convolution_backward_default_11[1]
        getitem_367 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_365, [128, 2048, 7, 7]);  getitem_365 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 49);  expand_default_3 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(mul_tensor_42, div_scalar_3);  mul_tensor_42 = div_scalar_3 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_157, primals_710, primals_708, primals_709, getitem_294, getitem_295, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_157 = primals_710 = primals_708 = primals_709 = getitem_294 = getitem_295 = None
        getitem_368 = native_batch_norm_backward_default_6[0]
        getitem_369 = native_batch_norm_backward_default_6[1]
        getitem_370 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_368, relu__default_120, primals_705, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_368 = primals_705 = None
        getitem_371 = convolution_backward_default_12[0]
        getitem_372 = convolution_backward_default_12[1]
        getitem_373 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_37, convolution_default_156, primals_701, primals_699, primals_700, getitem_291, getitem_292, True, 1e-05, [True, True, True]);  add_tensor_37 = convolution_default_156 = primals_701 = primals_699 = primals_700 = getitem_291 = getitem_292 = None
        getitem_374 = native_batch_norm_backward_default_7[0]
        getitem_375 = native_batch_norm_backward_default_7[1]
        getitem_376 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_374, relu__default_122, primals_704, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_374 = primals_704 = None
        getitem_377 = convolution_backward_default_13[0]
        getitem_378 = convolution_backward_default_13[1]
        getitem_379 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_377, torch.float32);  getitem_377 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_122, torch.float32);  relu__default_122 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_114, to_dtype_39);  le_scalar_10 = new_zeros_default_114 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_155, primals_696, primals_694, primals_695, getitem_288, getitem_289, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_155 = primals_696 = primals_694 = primals_695 = getitem_288 = getitem_289 = None
        getitem_380 = native_batch_norm_backward_default_8[0]
        getitem_381 = native_batch_norm_backward_default_8[1]
        getitem_382 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_380, relu__default_121, primals_703, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_380 = primals_703 = None
        getitem_383 = convolution_backward_default_14[0]
        getitem_384 = convolution_backward_default_14[1]
        getitem_385 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_383, torch.float32);  getitem_383 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_121, torch.float32);  relu__default_121 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_115, to_dtype_42);  le_scalar_11 = new_zeros_default_115 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_154, primals_691, primals_689, primals_690, getitem_285, getitem_286, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_154 = primals_691 = primals_689 = primals_690 = getitem_285 = getitem_286 = None
        getitem_386 = native_batch_norm_backward_default_9[0]
        getitem_387 = native_batch_norm_backward_default_9[1]
        getitem_388 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_386, relu__default_120, primals_702, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_386 = primals_702 = None
        getitem_389 = convolution_backward_default_15[0]
        getitem_390 = convolution_backward_default_15[1]
        getitem_391 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_371, getitem_389);  getitem_371 = getitem_389 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_38, torch.float32);  add_tensor_38 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_120, torch.float32);  relu__default_120 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_116, to_dtype_45);  le_scalar_12 = new_zeros_default_116 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_47, getitem_281);  getitem_281 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_47, sigmoid_default_29)
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_45, [2, 3], True);  mul_tensor_45 = None
        to_dtype_48 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_49 = torch.ops.aten.to.dtype(sigmoid_default_29, torch.float32);  sigmoid_default_29 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(to_dtype_49, 1)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_3);  to_dtype_49 = rsub_scalar_3 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_47);  mul_tensor_47 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_48, conj_physical_default_3);  to_dtype_48 = conj_physical_default_3 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_48, torch.float32);  mul_tensor_48 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(to_dtype_50, relu__default_119, primals_510, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_50 = primals_510 = None
        getitem_392 = convolution_backward_default_16[0]
        getitem_393 = convolution_backward_default_16[1]
        getitem_394 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_392, torch.float32);  getitem_392 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_119, torch.float32);  relu__default_119 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_117, to_dtype_51);  le_scalar_13 = new_zeros_default_117 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_53, mean_dim_29, primals_508, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = mean_dim_29 = primals_508 = None
        getitem_395 = convolution_backward_default_17[0]
        getitem_396 = convolution_backward_default_17[1]
        getitem_397 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_395, [128, 1024, 14, 14]);  getitem_395 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 196);  expand_default_4 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(mul_tensor_46, div_scalar_4);  mul_tensor_46 = div_scalar_4 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_39, convolution_default_151, primals_503, primals_501, primals_502, getitem_282, getitem_283, True, 1e-05, [True, True, True]);  add_tensor_39 = convolution_default_151 = primals_503 = primals_501 = primals_502 = getitem_282 = getitem_283 = None
        getitem_398 = native_batch_norm_backward_default_10[0]
        getitem_399 = native_batch_norm_backward_default_10[1]
        getitem_400 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_398, relu__default_118, primals_506, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_398 = primals_506 = None
        getitem_401 = convolution_backward_default_18[0]
        getitem_402 = convolution_backward_default_18[1]
        getitem_403 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_401, torch.float32);  getitem_401 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_118, torch.float32);  relu__default_118 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_118, to_dtype_54);  le_scalar_14 = new_zeros_default_118 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_150, primals_498, primals_496, primals_497, getitem_279, getitem_280, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_150 = primals_498 = primals_496 = primals_497 = getitem_279 = getitem_280 = None
        getitem_404 = native_batch_norm_backward_default_11[0]
        getitem_405 = native_batch_norm_backward_default_11[1]
        getitem_406 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_404, relu__default_117, primals_505, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_404 = primals_505 = None
        getitem_407 = convolution_backward_default_19[0]
        getitem_408 = convolution_backward_default_19[1]
        getitem_409 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_407, torch.float32);  getitem_407 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_117, torch.float32);  relu__default_117 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_119, to_dtype_57);  le_scalar_15 = new_zeros_default_119 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_149, primals_493, primals_491, primals_492, getitem_276, getitem_277, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_149 = primals_493 = primals_491 = primals_492 = getitem_276 = getitem_277 = None
        getitem_410 = native_batch_norm_backward_default_12[0]
        getitem_411 = native_batch_norm_backward_default_12[1]
        getitem_412 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_410, relu__default_116, primals_504, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_410 = primals_504 = None
        getitem_413 = convolution_backward_default_20[0]
        getitem_414 = convolution_backward_default_20[1]
        getitem_415 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(to_dtype_47, getitem_413);  to_dtype_47 = getitem_413 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_40, torch.float32);  add_tensor_40 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_116, torch.float32);  relu__default_116 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_120, to_dtype_60);  le_scalar_16 = new_zeros_default_120 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_62, getitem_272);  getitem_272 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(to_dtype_62, sigmoid_default_28)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_49, [2, 3], True);  mul_tensor_49 = None
        to_dtype_63 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_28, torch.float32);  sigmoid_default_28 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_4);  to_dtype_64 = rsub_scalar_4 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_51);  mul_tensor_51 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_4);  to_dtype_63 = conj_physical_default_4 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_52, torch.float32);  mul_tensor_52 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(to_dtype_65, relu__default_115, primals_488, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = primals_488 = None
        getitem_416 = convolution_backward_default_21[0]
        getitem_417 = convolution_backward_default_21[1]
        getitem_418 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_416, torch.float32);  getitem_416 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_115, torch.float32);  relu__default_115 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_121, to_dtype_66);  le_scalar_17 = new_zeros_default_121 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_68, mean_dim_28, primals_486, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = mean_dim_28 = primals_486 = None
        getitem_419 = convolution_backward_default_22[0]
        getitem_420 = convolution_backward_default_22[1]
        getitem_421 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_419, [128, 1024, 14, 14]);  getitem_419 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 196);  expand_default_5 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(mul_tensor_50, div_scalar_5);  mul_tensor_50 = div_scalar_5 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_41, convolution_default_146, primals_481, primals_479, primals_480, getitem_273, getitem_274, True, 1e-05, [True, True, True]);  add_tensor_41 = convolution_default_146 = primals_481 = primals_479 = primals_480 = getitem_273 = getitem_274 = None
        getitem_422 = native_batch_norm_backward_default_13[0]
        getitem_423 = native_batch_norm_backward_default_13[1]
        getitem_424 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_422, relu__default_114, primals_484, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_422 = primals_484 = None
        getitem_425 = convolution_backward_default_23[0]
        getitem_426 = convolution_backward_default_23[1]
        getitem_427 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_425, torch.float32);  getitem_425 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_114, torch.float32);  relu__default_114 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_122, to_dtype_69);  le_scalar_18 = new_zeros_default_122 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_145, primals_476, primals_474, primals_475, getitem_270, getitem_271, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_145 = primals_476 = primals_474 = primals_475 = getitem_270 = getitem_271 = None
        getitem_428 = native_batch_norm_backward_default_14[0]
        getitem_429 = native_batch_norm_backward_default_14[1]
        getitem_430 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_428, relu__default_113, primals_483, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_428 = primals_483 = None
        getitem_431 = convolution_backward_default_24[0]
        getitem_432 = convolution_backward_default_24[1]
        getitem_433 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_431, torch.float32);  getitem_431 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_113, torch.float32);  relu__default_113 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_123, to_dtype_72);  le_scalar_19 = new_zeros_default_123 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_144, primals_471, primals_469, primals_470, getitem_267, getitem_268, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_144 = primals_471 = primals_469 = primals_470 = getitem_267 = getitem_268 = None
        getitem_434 = native_batch_norm_backward_default_15[0]
        getitem_435 = native_batch_norm_backward_default_15[1]
        getitem_436 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_434, relu__default_112, primals_482, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_434 = primals_482 = None
        getitem_437 = convolution_backward_default_25[0]
        getitem_438 = convolution_backward_default_25[1]
        getitem_439 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_437);  to_dtype_62 = getitem_437 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_42, torch.float32);  add_tensor_42 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_112, torch.float32);  relu__default_112 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_124, to_dtype_75);  le_scalar_20 = new_zeros_default_124 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_77, getitem_263);  getitem_263 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_77, sigmoid_default_27)
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_53, [2, 3], True);  mul_tensor_53 = None
        to_dtype_78 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_79 = torch.ops.aten.to.dtype(sigmoid_default_27, torch.float32);  sigmoid_default_27 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_79, 1)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_5);  to_dtype_79 = rsub_scalar_5 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_55);  mul_tensor_55 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_78, conj_physical_default_5);  to_dtype_78 = conj_physical_default_5 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_56, torch.float32);  mul_tensor_56 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(to_dtype_80, relu__default_111, primals_466, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = primals_466 = None
        getitem_440 = convolution_backward_default_26[0]
        getitem_441 = convolution_backward_default_26[1]
        getitem_442 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_440, torch.float32);  getitem_440 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_111, torch.float32);  relu__default_111 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_125, to_dtype_81);  le_scalar_21 = new_zeros_default_125 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_83, mean_dim_27, primals_464, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_83 = mean_dim_27 = primals_464 = None
        getitem_443 = convolution_backward_default_27[0]
        getitem_444 = convolution_backward_default_27[1]
        getitem_445 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_443, [128, 1024, 14, 14]);  getitem_443 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 196);  expand_default_6 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(mul_tensor_54, div_scalar_6);  mul_tensor_54 = div_scalar_6 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_43, convolution_default_141, primals_459, primals_457, primals_458, getitem_264, getitem_265, True, 1e-05, [True, True, True]);  add_tensor_43 = convolution_default_141 = primals_459 = primals_457 = primals_458 = getitem_264 = getitem_265 = None
        getitem_446 = native_batch_norm_backward_default_16[0]
        getitem_447 = native_batch_norm_backward_default_16[1]
        getitem_448 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_446, relu__default_110, primals_462, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_446 = primals_462 = None
        getitem_449 = convolution_backward_default_28[0]
        getitem_450 = convolution_backward_default_28[1]
        getitem_451 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_449, torch.float32);  getitem_449 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_110, torch.float32);  relu__default_110 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_126, to_dtype_84);  le_scalar_22 = new_zeros_default_126 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_140, primals_454, primals_452, primals_453, getitem_261, getitem_262, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_140 = primals_454 = primals_452 = primals_453 = getitem_261 = getitem_262 = None
        getitem_452 = native_batch_norm_backward_default_17[0]
        getitem_453 = native_batch_norm_backward_default_17[1]
        getitem_454 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_452, relu__default_109, primals_461, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_452 = primals_461 = None
        getitem_455 = convolution_backward_default_29[0]
        getitem_456 = convolution_backward_default_29[1]
        getitem_457 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_455, torch.float32);  getitem_455 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_127, to_dtype_87);  le_scalar_23 = new_zeros_default_127 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_139, primals_449, primals_447, primals_448, getitem_258, getitem_259, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_139 = primals_449 = primals_447 = primals_448 = getitem_258 = getitem_259 = None
        getitem_458 = native_batch_norm_backward_default_18[0]
        getitem_459 = native_batch_norm_backward_default_18[1]
        getitem_460 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_458, relu__default_108, primals_460, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_458 = primals_460 = None
        getitem_461 = convolution_backward_default_30[0]
        getitem_462 = convolution_backward_default_30[1]
        getitem_463 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(to_dtype_77, getitem_461);  to_dtype_77 = getitem_461 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_44, torch.float32);  add_tensor_44 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_128, to_dtype_90);  le_scalar_24 = new_zeros_default_128 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_92, getitem_254);  getitem_254 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_92, sigmoid_default_26)
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_57, [2, 3], True);  mul_tensor_57 = None
        to_dtype_93 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_94 = torch.ops.aten.to.dtype(sigmoid_default_26, torch.float32);  sigmoid_default_26 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(to_dtype_94, 1)
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_6);  to_dtype_94 = rsub_scalar_6 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_59);  mul_tensor_59 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_93, conj_physical_default_6);  to_dtype_93 = conj_physical_default_6 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_60, torch.float32);  mul_tensor_60 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(to_dtype_95, relu__default_107, primals_422, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_95 = primals_422 = None
        getitem_464 = convolution_backward_default_31[0]
        getitem_465 = convolution_backward_default_31[1]
        getitem_466 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_464, torch.float32);  getitem_464 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_129, to_dtype_96);  le_scalar_25 = new_zeros_default_129 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(to_dtype_98, mean_dim_26, primals_420, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_98 = mean_dim_26 = primals_420 = None
        getitem_467 = convolution_backward_default_32[0]
        getitem_468 = convolution_backward_default_32[1]
        getitem_469 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_467, [128, 1024, 14, 14]);  getitem_467 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 196);  expand_default_7 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(mul_tensor_58, div_scalar_7);  mul_tensor_58 = div_scalar_7 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_45, convolution_default_136, primals_415, primals_413, primals_414, getitem_255, getitem_256, True, 1e-05, [True, True, True]);  add_tensor_45 = convolution_default_136 = primals_415 = primals_413 = primals_414 = getitem_255 = getitem_256 = None
        getitem_470 = native_batch_norm_backward_default_19[0]
        getitem_471 = native_batch_norm_backward_default_19[1]
        getitem_472 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_470, relu__default_106, primals_418, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_470 = primals_418 = None
        getitem_473 = convolution_backward_default_33[0]
        getitem_474 = convolution_backward_default_33[1]
        getitem_475 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_473, torch.float32);  getitem_473 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_130, to_dtype_99);  le_scalar_26 = new_zeros_default_130 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_135, primals_410, primals_408, primals_409, getitem_252, getitem_253, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_135 = primals_410 = primals_408 = primals_409 = getitem_252 = getitem_253 = None
        getitem_476 = native_batch_norm_backward_default_20[0]
        getitem_477 = native_batch_norm_backward_default_20[1]
        getitem_478 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_476, relu__default_105, primals_417, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_476 = primals_417 = None
        getitem_479 = convolution_backward_default_34[0]
        getitem_480 = convolution_backward_default_34[1]
        getitem_481 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_479, torch.float32);  getitem_479 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_131, to_dtype_102);  le_scalar_27 = new_zeros_default_131 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_134, primals_405, primals_403, primals_404, getitem_249, getitem_250, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_134 = primals_405 = primals_403 = primals_404 = getitem_249 = getitem_250 = None
        getitem_482 = native_batch_norm_backward_default_21[0]
        getitem_483 = native_batch_norm_backward_default_21[1]
        getitem_484 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_482, relu__default_104, primals_416, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_482 = primals_416 = None
        getitem_485 = convolution_backward_default_35[0]
        getitem_486 = convolution_backward_default_35[1]
        getitem_487 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(to_dtype_92, getitem_485);  to_dtype_92 = getitem_485 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_46, torch.float32);  add_tensor_46 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_132, to_dtype_105);  le_scalar_28 = new_zeros_default_132 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_107, getitem_245);  getitem_245 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_107, sigmoid_default_25)
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_61, [2, 3], True);  mul_tensor_61 = None
        to_dtype_108 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_109 = torch.ops.aten.to.dtype(sigmoid_default_25, torch.float32);  sigmoid_default_25 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(to_dtype_109, 1)
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_7);  to_dtype_109 = rsub_scalar_7 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_63);  mul_tensor_63 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(to_dtype_108, conj_physical_default_7);  to_dtype_108 = conj_physical_default_7 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_64, torch.float32);  mul_tensor_64 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(to_dtype_110, relu__default_103, primals_400, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_110 = primals_400 = None
        getitem_488 = convolution_backward_default_36[0]
        getitem_489 = convolution_backward_default_36[1]
        getitem_490 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_488, torch.float32);  getitem_488 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_133, to_dtype_111);  le_scalar_29 = new_zeros_default_133 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_113, mean_dim_25, primals_398, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = mean_dim_25 = primals_398 = None
        getitem_491 = convolution_backward_default_37[0]
        getitem_492 = convolution_backward_default_37[1]
        getitem_493 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_491, [128, 1024, 14, 14]);  getitem_491 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 196);  expand_default_8 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(mul_tensor_62, div_scalar_8);  mul_tensor_62 = div_scalar_8 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_47, convolution_default_131, primals_393, primals_391, primals_392, getitem_246, getitem_247, True, 1e-05, [True, True, True]);  add_tensor_47 = convolution_default_131 = primals_393 = primals_391 = primals_392 = getitem_246 = getitem_247 = None
        getitem_494 = native_batch_norm_backward_default_22[0]
        getitem_495 = native_batch_norm_backward_default_22[1]
        getitem_496 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_494, relu__default_102, primals_396, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_494 = primals_396 = None
        getitem_497 = convolution_backward_default_38[0]
        getitem_498 = convolution_backward_default_38[1]
        getitem_499 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_497, torch.float32);  getitem_497 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_134, to_dtype_114);  le_scalar_30 = new_zeros_default_134 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_130, primals_388, primals_386, primals_387, getitem_243, getitem_244, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_130 = primals_388 = primals_386 = primals_387 = getitem_243 = getitem_244 = None
        getitem_500 = native_batch_norm_backward_default_23[0]
        getitem_501 = native_batch_norm_backward_default_23[1]
        getitem_502 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_500, relu__default_101, primals_395, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_500 = primals_395 = None
        getitem_503 = convolution_backward_default_39[0]
        getitem_504 = convolution_backward_default_39[1]
        getitem_505 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_503, torch.float32);  getitem_503 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_135, to_dtype_117);  le_scalar_31 = new_zeros_default_135 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_129, primals_383, primals_381, primals_382, getitem_240, getitem_241, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_129 = primals_383 = primals_381 = primals_382 = getitem_240 = getitem_241 = None
        getitem_506 = native_batch_norm_backward_default_24[0]
        getitem_507 = native_batch_norm_backward_default_24[1]
        getitem_508 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_506, relu__default_100, primals_394, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_506 = primals_394 = None
        getitem_509 = convolution_backward_default_40[0]
        getitem_510 = convolution_backward_default_40[1]
        getitem_511 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(to_dtype_107, getitem_509);  to_dtype_107 = getitem_509 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_48, torch.float32);  add_tensor_48 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_136, to_dtype_120);  le_scalar_32 = new_zeros_default_136 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_122, getitem_236);  getitem_236 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_122, sigmoid_default_24)
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_65, [2, 3], True);  mul_tensor_65 = None
        to_dtype_123 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_124 = torch.ops.aten.to.dtype(sigmoid_default_24, torch.float32);  sigmoid_default_24 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(to_dtype_124, 1)
        mul_tensor_67 = torch.ops.aten.mul.Tensor(to_dtype_124, rsub_scalar_8);  to_dtype_124 = rsub_scalar_8 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_67);  mul_tensor_67 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_123, conj_physical_default_8);  to_dtype_123 = conj_physical_default_8 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_68, torch.float32);  mul_tensor_68 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(to_dtype_125, relu__default_99, primals_378, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = primals_378 = None
        getitem_512 = convolution_backward_default_41[0]
        getitem_513 = convolution_backward_default_41[1]
        getitem_514 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_512, torch.float32);  getitem_512 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_137, to_dtype_126);  le_scalar_33 = new_zeros_default_137 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(to_dtype_128, mean_dim_24, primals_376, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_128 = mean_dim_24 = primals_376 = None
        getitem_515 = convolution_backward_default_42[0]
        getitem_516 = convolution_backward_default_42[1]
        getitem_517 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        expand_default_9 = torch.ops.aten.expand.default(getitem_515, [128, 1024, 14, 14]);  getitem_515 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_9, 196);  expand_default_9 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(mul_tensor_66, div_scalar_9);  mul_tensor_66 = div_scalar_9 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_49, convolution_default_126, primals_371, primals_369, primals_370, getitem_237, getitem_238, True, 1e-05, [True, True, True]);  add_tensor_49 = convolution_default_126 = primals_371 = primals_369 = primals_370 = getitem_237 = getitem_238 = None
        getitem_518 = native_batch_norm_backward_default_25[0]
        getitem_519 = native_batch_norm_backward_default_25[1]
        getitem_520 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_518, relu__default_98, primals_374, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_518 = primals_374 = None
        getitem_521 = convolution_backward_default_43[0]
        getitem_522 = convolution_backward_default_43[1]
        getitem_523 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_521, torch.float32);  getitem_521 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_138, to_dtype_129);  le_scalar_34 = new_zeros_default_138 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_125, primals_366, primals_364, primals_365, getitem_234, getitem_235, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_125 = primals_366 = primals_364 = primals_365 = getitem_234 = getitem_235 = None
        getitem_524 = native_batch_norm_backward_default_26[0]
        getitem_525 = native_batch_norm_backward_default_26[1]
        getitem_526 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_524, relu__default_97, primals_373, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_524 = primals_373 = None
        getitem_527 = convolution_backward_default_44[0]
        getitem_528 = convolution_backward_default_44[1]
        getitem_529 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_527, torch.float32);  getitem_527 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_139, to_dtype_132);  le_scalar_35 = new_zeros_default_139 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_124, primals_361, primals_359, primals_360, getitem_231, getitem_232, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_124 = primals_361 = primals_359 = primals_360 = getitem_231 = getitem_232 = None
        getitem_530 = native_batch_norm_backward_default_27[0]
        getitem_531 = native_batch_norm_backward_default_27[1]
        getitem_532 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_530, relu__default_96, primals_372, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_530 = primals_372 = None
        getitem_533 = convolution_backward_default_45[0]
        getitem_534 = convolution_backward_default_45[1]
        getitem_535 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(to_dtype_122, getitem_533);  to_dtype_122 = getitem_533 = None
        to_dtype_135 = torch.ops.aten.to.dtype(add_tensor_50, torch.float32);  add_tensor_50 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_140, to_dtype_135);  le_scalar_36 = new_zeros_default_140 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_137, getitem_227);  getitem_227 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_137, sigmoid_default_23)
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_69, [2, 3], True);  mul_tensor_69 = None
        to_dtype_138 = torch.ops.aten.to.dtype(sum_dim_int_list_10, torch.float32);  sum_dim_int_list_10 = None
        to_dtype_139 = torch.ops.aten.to.dtype(sigmoid_default_23, torch.float32);  sigmoid_default_23 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(to_dtype_139, 1)
        mul_tensor_71 = torch.ops.aten.mul.Tensor(to_dtype_139, rsub_scalar_9);  to_dtype_139 = rsub_scalar_9 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_71);  mul_tensor_71 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(to_dtype_138, conj_physical_default_9);  to_dtype_138 = conj_physical_default_9 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_72, torch.float32);  mul_tensor_72 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(to_dtype_140, relu__default_95, primals_356, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_140 = primals_356 = None
        getitem_536 = convolution_backward_default_46[0]
        getitem_537 = convolution_backward_default_46[1]
        getitem_538 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_536, torch.float32);  getitem_536 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_141, to_dtype_141);  le_scalar_37 = new_zeros_default_141 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(to_dtype_143, mean_dim_23, primals_354, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_143 = mean_dim_23 = primals_354 = None
        getitem_539 = convolution_backward_default_47[0]
        getitem_540 = convolution_backward_default_47[1]
        getitem_541 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        expand_default_10 = torch.ops.aten.expand.default(getitem_539, [128, 1024, 14, 14]);  getitem_539 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_10, 196);  expand_default_10 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(mul_tensor_70, div_scalar_10);  mul_tensor_70 = div_scalar_10 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_51, convolution_default_121, primals_349, primals_347, primals_348, getitem_228, getitem_229, True, 1e-05, [True, True, True]);  add_tensor_51 = convolution_default_121 = primals_349 = primals_347 = primals_348 = getitem_228 = getitem_229 = None
        getitem_542 = native_batch_norm_backward_default_28[0]
        getitem_543 = native_batch_norm_backward_default_28[1]
        getitem_544 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_542, relu__default_94, primals_352, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_542 = primals_352 = None
        getitem_545 = convolution_backward_default_48[0]
        getitem_546 = convolution_backward_default_48[1]
        getitem_547 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_545, torch.float32);  getitem_545 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_142, to_dtype_144);  le_scalar_38 = new_zeros_default_142 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_120, primals_344, primals_342, primals_343, getitem_225, getitem_226, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_120 = primals_344 = primals_342 = primals_343 = getitem_225 = getitem_226 = None
        getitem_548 = native_batch_norm_backward_default_29[0]
        getitem_549 = native_batch_norm_backward_default_29[1]
        getitem_550 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_548, relu__default_93, primals_351, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_548 = primals_351 = None
        getitem_551 = convolution_backward_default_49[0]
        getitem_552 = convolution_backward_default_49[1]
        getitem_553 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_551, torch.float32);  getitem_551 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_143, to_dtype_147);  le_scalar_39 = new_zeros_default_143 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_119, primals_339, primals_337, primals_338, getitem_222, getitem_223, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_119 = primals_339 = primals_337 = primals_338 = getitem_222 = getitem_223 = None
        getitem_554 = native_batch_norm_backward_default_30[0]
        getitem_555 = native_batch_norm_backward_default_30[1]
        getitem_556 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_554, relu__default_92, primals_350, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_554 = primals_350 = None
        getitem_557 = convolution_backward_default_50[0]
        getitem_558 = convolution_backward_default_50[1]
        getitem_559 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(to_dtype_137, getitem_557);  to_dtype_137 = getitem_557 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_52, torch.float32);  add_tensor_52 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_144, to_dtype_150);  le_scalar_40 = new_zeros_default_144 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_152, getitem_218);  getitem_218 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_152, sigmoid_default_22)
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_73, [2, 3], True);  mul_tensor_73 = None
        to_dtype_153 = torch.ops.aten.to.dtype(sum_dim_int_list_11, torch.float32);  sum_dim_int_list_11 = None
        to_dtype_154 = torch.ops.aten.to.dtype(sigmoid_default_22, torch.float32);  sigmoid_default_22 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(to_dtype_154, 1)
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_154, rsub_scalar_10);  to_dtype_154 = rsub_scalar_10 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_75);  mul_tensor_75 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_153, conj_physical_default_10);  to_dtype_153 = conj_physical_default_10 = None
        to_dtype_155 = torch.ops.aten.to.dtype(mul_tensor_76, torch.float32);  mul_tensor_76 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(to_dtype_155, relu__default_91, primals_334, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_155 = primals_334 = None
        getitem_560 = convolution_backward_default_51[0]
        getitem_561 = convolution_backward_default_51[1]
        getitem_562 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_560, torch.float32);  getitem_560 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_145, to_dtype_156);  le_scalar_41 = new_zeros_default_145 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(to_dtype_158, mean_dim_22, primals_332, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_158 = mean_dim_22 = primals_332 = None
        getitem_563 = convolution_backward_default_52[0]
        getitem_564 = convolution_backward_default_52[1]
        getitem_565 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_563, [128, 1024, 14, 14]);  getitem_563 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_11, 196);  expand_default_11 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(mul_tensor_74, div_scalar_11);  mul_tensor_74 = div_scalar_11 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_53, convolution_default_116, primals_327, primals_325, primals_326, getitem_219, getitem_220, True, 1e-05, [True, True, True]);  add_tensor_53 = convolution_default_116 = primals_327 = primals_325 = primals_326 = getitem_219 = getitem_220 = None
        getitem_566 = native_batch_norm_backward_default_31[0]
        getitem_567 = native_batch_norm_backward_default_31[1]
        getitem_568 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_566, relu__default_90, primals_330, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_566 = primals_330 = None
        getitem_569 = convolution_backward_default_53[0]
        getitem_570 = convolution_backward_default_53[1]
        getitem_571 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_569, torch.float32);  getitem_569 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_146, to_dtype_159);  le_scalar_42 = new_zeros_default_146 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_115, primals_322, primals_320, primals_321, getitem_216, getitem_217, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_115 = primals_322 = primals_320 = primals_321 = getitem_216 = getitem_217 = None
        getitem_572 = native_batch_norm_backward_default_32[0]
        getitem_573 = native_batch_norm_backward_default_32[1]
        getitem_574 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_572, relu__default_89, primals_329, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_572 = primals_329 = None
        getitem_575 = convolution_backward_default_54[0]
        getitem_576 = convolution_backward_default_54[1]
        getitem_577 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_575, torch.float32);  getitem_575 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_147, to_dtype_162);  le_scalar_43 = new_zeros_default_147 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_114, primals_317, primals_315, primals_316, getitem_213, getitem_214, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_114 = primals_317 = primals_315 = primals_316 = getitem_213 = getitem_214 = None
        getitem_578 = native_batch_norm_backward_default_33[0]
        getitem_579 = native_batch_norm_backward_default_33[1]
        getitem_580 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_578, relu__default_88, primals_328, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_578 = primals_328 = None
        getitem_581 = convolution_backward_default_55[0]
        getitem_582 = convolution_backward_default_55[1]
        getitem_583 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(to_dtype_152, getitem_581);  to_dtype_152 = getitem_581 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_54, torch.float32);  add_tensor_54 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_148, to_dtype_165);  le_scalar_44 = new_zeros_default_148 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_167, getitem_209);  getitem_209 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(to_dtype_167, sigmoid_default_21)
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_77, [2, 3], True);  mul_tensor_77 = None
        to_dtype_168 = torch.ops.aten.to.dtype(sum_dim_int_list_12, torch.float32);  sum_dim_int_list_12 = None
        to_dtype_169 = torch.ops.aten.to.dtype(sigmoid_default_21, torch.float32);  sigmoid_default_21 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(to_dtype_169, 1)
        mul_tensor_79 = torch.ops.aten.mul.Tensor(to_dtype_169, rsub_scalar_11);  to_dtype_169 = rsub_scalar_11 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_79);  mul_tensor_79 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(to_dtype_168, conj_physical_default_11);  to_dtype_168 = conj_physical_default_11 = None
        to_dtype_170 = torch.ops.aten.to.dtype(mul_tensor_80, torch.float32);  mul_tensor_80 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(to_dtype_170, relu__default_87, primals_312, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_170 = primals_312 = None
        getitem_584 = convolution_backward_default_56[0]
        getitem_585 = convolution_backward_default_56[1]
        getitem_586 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_584, torch.float32);  getitem_584 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_149, to_dtype_171);  le_scalar_45 = new_zeros_default_149 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(to_dtype_173, mean_dim_21, primals_310, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_173 = mean_dim_21 = primals_310 = None
        getitem_587 = convolution_backward_default_57[0]
        getitem_588 = convolution_backward_default_57[1]
        getitem_589 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        expand_default_12 = torch.ops.aten.expand.default(getitem_587, [128, 1024, 14, 14]);  getitem_587 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_12, 196);  expand_default_12 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(mul_tensor_78, div_scalar_12);  mul_tensor_78 = div_scalar_12 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_55, convolution_default_111, primals_305, primals_303, primals_304, getitem_210, getitem_211, True, 1e-05, [True, True, True]);  add_tensor_55 = convolution_default_111 = primals_305 = primals_303 = primals_304 = getitem_210 = getitem_211 = None
        getitem_590 = native_batch_norm_backward_default_34[0]
        getitem_591 = native_batch_norm_backward_default_34[1]
        getitem_592 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_590, relu__default_86, primals_308, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_590 = primals_308 = None
        getitem_593 = convolution_backward_default_58[0]
        getitem_594 = convolution_backward_default_58[1]
        getitem_595 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_593, torch.float32);  getitem_593 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_150, to_dtype_174);  le_scalar_46 = new_zeros_default_150 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_110, primals_300, primals_298, primals_299, getitem_207, getitem_208, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_110 = primals_300 = primals_298 = primals_299 = getitem_207 = getitem_208 = None
        getitem_596 = native_batch_norm_backward_default_35[0]
        getitem_597 = native_batch_norm_backward_default_35[1]
        getitem_598 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_596, relu__default_85, primals_307, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_596 = primals_307 = None
        getitem_599 = convolution_backward_default_59[0]
        getitem_600 = convolution_backward_default_59[1]
        getitem_601 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_599, torch.float32);  getitem_599 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_151, to_dtype_177);  le_scalar_47 = new_zeros_default_151 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_109, primals_295, primals_293, primals_294, getitem_204, getitem_205, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_109 = primals_295 = primals_293 = primals_294 = getitem_204 = getitem_205 = None
        getitem_602 = native_batch_norm_backward_default_36[0]
        getitem_603 = native_batch_norm_backward_default_36[1]
        getitem_604 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_602, relu__default_84, primals_306, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_602 = primals_306 = None
        getitem_605 = convolution_backward_default_60[0]
        getitem_606 = convolution_backward_default_60[1]
        getitem_607 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(to_dtype_167, getitem_605);  to_dtype_167 = getitem_605 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_56, torch.float32);  add_tensor_56 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_152, to_dtype_180);  le_scalar_48 = new_zeros_default_152 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_182, getitem_200);  getitem_200 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_182, sigmoid_default_20)
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_81, [2, 3], True);  mul_tensor_81 = None
        to_dtype_183 = torch.ops.aten.to.dtype(sum_dim_int_list_13, torch.float32);  sum_dim_int_list_13 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default_20, torch.float32);  sigmoid_default_20 = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_83 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_12);  to_dtype_184 = rsub_scalar_12 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_83);  mul_tensor_83 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_12);  to_dtype_183 = conj_physical_default_12 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_84, torch.float32);  mul_tensor_84 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(to_dtype_185, relu__default_83, primals_290, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_185 = primals_290 = None
        getitem_608 = convolution_backward_default_61[0]
        getitem_609 = convolution_backward_default_61[1]
        getitem_610 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_608, torch.float32);  getitem_608 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_153, to_dtype_186);  le_scalar_49 = new_zeros_default_153 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(to_dtype_188, mean_dim_20, primals_288, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_188 = mean_dim_20 = primals_288 = None
        getitem_611 = convolution_backward_default_62[0]
        getitem_612 = convolution_backward_default_62[1]
        getitem_613 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        expand_default_13 = torch.ops.aten.expand.default(getitem_611, [128, 1024, 14, 14]);  getitem_611 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_13, 196);  expand_default_13 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(mul_tensor_82, div_scalar_13);  mul_tensor_82 = div_scalar_13 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_57, convolution_default_106, primals_283, primals_281, primals_282, getitem_201, getitem_202, True, 1e-05, [True, True, True]);  add_tensor_57 = convolution_default_106 = primals_283 = primals_281 = primals_282 = getitem_201 = getitem_202 = None
        getitem_614 = native_batch_norm_backward_default_37[0]
        getitem_615 = native_batch_norm_backward_default_37[1]
        getitem_616 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_614, relu__default_82, primals_286, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_614 = primals_286 = None
        getitem_617 = convolution_backward_default_63[0]
        getitem_618 = convolution_backward_default_63[1]
        getitem_619 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_617, torch.float32);  getitem_617 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_154, to_dtype_189);  le_scalar_50 = new_zeros_default_154 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_105, primals_278, primals_276, primals_277, getitem_198, getitem_199, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_105 = primals_278 = primals_276 = primals_277 = getitem_198 = getitem_199 = None
        getitem_620 = native_batch_norm_backward_default_38[0]
        getitem_621 = native_batch_norm_backward_default_38[1]
        getitem_622 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_620, relu__default_81, primals_285, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_620 = primals_285 = None
        getitem_623 = convolution_backward_default_64[0]
        getitem_624 = convolution_backward_default_64[1]
        getitem_625 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_623, torch.float32);  getitem_623 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_155, to_dtype_192);  le_scalar_51 = new_zeros_default_155 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_104, primals_273, primals_271, primals_272, getitem_195, getitem_196, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default_104 = primals_273 = primals_271 = primals_272 = getitem_195 = getitem_196 = None
        getitem_626 = native_batch_norm_backward_default_39[0]
        getitem_627 = native_batch_norm_backward_default_39[1]
        getitem_628 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_626, relu__default_80, primals_284, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_626 = primals_284 = None
        getitem_629 = convolution_backward_default_65[0]
        getitem_630 = convolution_backward_default_65[1]
        getitem_631 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(to_dtype_182, getitem_629);  to_dtype_182 = getitem_629 = None
        to_dtype_195 = torch.ops.aten.to.dtype(add_tensor_58, torch.float32);  add_tensor_58 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_156, to_dtype_195);  le_scalar_52 = new_zeros_default_156 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(to_dtype_197, getitem_191);  getitem_191 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_197, sigmoid_default_19)
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(mul_tensor_85, [2, 3], True);  mul_tensor_85 = None
        to_dtype_198 = torch.ops.aten.to.dtype(sum_dim_int_list_14, torch.float32);  sum_dim_int_list_14 = None
        to_dtype_199 = torch.ops.aten.to.dtype(sigmoid_default_19, torch.float32);  sigmoid_default_19 = None
        rsub_scalar_13 = torch.ops.aten.rsub.Scalar(to_dtype_199, 1)
        mul_tensor_87 = torch.ops.aten.mul.Tensor(to_dtype_199, rsub_scalar_13);  to_dtype_199 = rsub_scalar_13 = None
        conj_physical_default_13 = torch.ops.aten.conj_physical.default(mul_tensor_87);  mul_tensor_87 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(to_dtype_198, conj_physical_default_13);  to_dtype_198 = conj_physical_default_13 = None
        to_dtype_200 = torch.ops.aten.to.dtype(mul_tensor_88, torch.float32);  mul_tensor_88 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(to_dtype_200, relu__default_79, primals_268, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_200 = primals_268 = None
        getitem_632 = convolution_backward_default_66[0]
        getitem_633 = convolution_backward_default_66[1]
        getitem_634 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_632, torch.float32);  getitem_632 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_157, to_dtype_201);  le_scalar_53 = new_zeros_default_157 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(to_dtype_203, mean_dim_19, primals_266, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_203 = mean_dim_19 = primals_266 = None
        getitem_635 = convolution_backward_default_67[0]
        getitem_636 = convolution_backward_default_67[1]
        getitem_637 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        expand_default_14 = torch.ops.aten.expand.default(getitem_635, [128, 1024, 14, 14]);  getitem_635 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_14, 196);  expand_default_14 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(mul_tensor_86, div_scalar_14);  mul_tensor_86 = div_scalar_14 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_59, convolution_default_101, primals_261, primals_259, primals_260, getitem_192, getitem_193, True, 1e-05, [True, True, True]);  add_tensor_59 = convolution_default_101 = primals_261 = primals_259 = primals_260 = getitem_192 = getitem_193 = None
        getitem_638 = native_batch_norm_backward_default_40[0]
        getitem_639 = native_batch_norm_backward_default_40[1]
        getitem_640 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_638, relu__default_78, primals_264, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_638 = primals_264 = None
        getitem_641 = convolution_backward_default_68[0]
        getitem_642 = convolution_backward_default_68[1]
        getitem_643 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_641, torch.float32);  getitem_641 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_158, to_dtype_204);  le_scalar_54 = new_zeros_default_158 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_100, primals_256, primals_254, primals_255, getitem_189, getitem_190, True, 1e-05, [True, True, True]);  to_dtype_206 = convolution_default_100 = primals_256 = primals_254 = primals_255 = getitem_189 = getitem_190 = None
        getitem_644 = native_batch_norm_backward_default_41[0]
        getitem_645 = native_batch_norm_backward_default_41[1]
        getitem_646 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_644, relu__default_77, primals_263, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_644 = primals_263 = None
        getitem_647 = convolution_backward_default_69[0]
        getitem_648 = convolution_backward_default_69[1]
        getitem_649 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_647, torch.float32);  getitem_647 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_159, to_dtype_207);  le_scalar_55 = new_zeros_default_159 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_99, primals_251, primals_249, primals_250, getitem_186, getitem_187, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_99 = primals_251 = primals_249 = primals_250 = getitem_186 = getitem_187 = None
        getitem_650 = native_batch_norm_backward_default_42[0]
        getitem_651 = native_batch_norm_backward_default_42[1]
        getitem_652 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_650, relu__default_76, primals_262, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_650 = primals_262 = None
        getitem_653 = convolution_backward_default_70[0]
        getitem_654 = convolution_backward_default_70[1]
        getitem_655 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(to_dtype_197, getitem_653);  to_dtype_197 = getitem_653 = None
        to_dtype_210 = torch.ops.aten.to.dtype(add_tensor_60, torch.float32);  add_tensor_60 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_160, to_dtype_210);  le_scalar_56 = new_zeros_default_160 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_212, getitem_182);  getitem_182 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_212, sigmoid_default_18)
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_89, [2, 3], True);  mul_tensor_89 = None
        to_dtype_213 = torch.ops.aten.to.dtype(sum_dim_int_list_15, torch.float32);  sum_dim_int_list_15 = None
        to_dtype_214 = torch.ops.aten.to.dtype(sigmoid_default_18, torch.float32);  sigmoid_default_18 = None
        rsub_scalar_14 = torch.ops.aten.rsub.Scalar(to_dtype_214, 1)
        mul_tensor_91 = torch.ops.aten.mul.Tensor(to_dtype_214, rsub_scalar_14);  to_dtype_214 = rsub_scalar_14 = None
        conj_physical_default_14 = torch.ops.aten.conj_physical.default(mul_tensor_91);  mul_tensor_91 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(to_dtype_213, conj_physical_default_14);  to_dtype_213 = conj_physical_default_14 = None
        to_dtype_215 = torch.ops.aten.to.dtype(mul_tensor_92, torch.float32);  mul_tensor_92 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(to_dtype_215, relu__default_75, primals_246, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_215 = primals_246 = None
        getitem_656 = convolution_backward_default_71[0]
        getitem_657 = convolution_backward_default_71[1]
        getitem_658 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_656, torch.float32);  getitem_656 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_161, to_dtype_216);  le_scalar_57 = new_zeros_default_161 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(to_dtype_218, mean_dim_18, primals_244, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_218 = mean_dim_18 = primals_244 = None
        getitem_659 = convolution_backward_default_72[0]
        getitem_660 = convolution_backward_default_72[1]
        getitem_661 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        expand_default_15 = torch.ops.aten.expand.default(getitem_659, [128, 1024, 14, 14]);  getitem_659 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_15, 196);  expand_default_15 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(mul_tensor_90, div_scalar_15);  mul_tensor_90 = div_scalar_15 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_61, convolution_default_96, primals_239, primals_237, primals_238, getitem_183, getitem_184, True, 1e-05, [True, True, True]);  add_tensor_61 = convolution_default_96 = primals_239 = primals_237 = primals_238 = getitem_183 = getitem_184 = None
        getitem_662 = native_batch_norm_backward_default_43[0]
        getitem_663 = native_batch_norm_backward_default_43[1]
        getitem_664 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_662, relu__default_74, primals_242, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_662 = primals_242 = None
        getitem_665 = convolution_backward_default_73[0]
        getitem_666 = convolution_backward_default_73[1]
        getitem_667 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_665, torch.float32);  getitem_665 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_162, to_dtype_219);  le_scalar_58 = new_zeros_default_162 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_95, primals_234, primals_232, primals_233, getitem_180, getitem_181, True, 1e-05, [True, True, True]);  to_dtype_221 = convolution_default_95 = primals_234 = primals_232 = primals_233 = getitem_180 = getitem_181 = None
        getitem_668 = native_batch_norm_backward_default_44[0]
        getitem_669 = native_batch_norm_backward_default_44[1]
        getitem_670 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_668, relu__default_73, primals_241, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_668 = primals_241 = None
        getitem_671 = convolution_backward_default_74[0]
        getitem_672 = convolution_backward_default_74[1]
        getitem_673 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_671, torch.float32);  getitem_671 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_163, to_dtype_222);  le_scalar_59 = new_zeros_default_163 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_94, primals_229, primals_227, primals_228, getitem_177, getitem_178, True, 1e-05, [True, True, True]);  to_dtype_224 = convolution_default_94 = primals_229 = primals_227 = primals_228 = getitem_177 = getitem_178 = None
        getitem_674 = native_batch_norm_backward_default_45[0]
        getitem_675 = native_batch_norm_backward_default_45[1]
        getitem_676 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_674, relu__default_72, primals_240, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_674 = primals_240 = None
        getitem_677 = convolution_backward_default_75[0]
        getitem_678 = convolution_backward_default_75[1]
        getitem_679 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(to_dtype_212, getitem_677);  to_dtype_212 = getitem_677 = None
        to_dtype_225 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_164, to_dtype_225);  le_scalar_60 = new_zeros_default_164 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_227, getitem_173);  getitem_173 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_227, sigmoid_default_17)
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(mul_tensor_93, [2, 3], True);  mul_tensor_93 = None
        to_dtype_228 = torch.ops.aten.to.dtype(sum_dim_int_list_16, torch.float32);  sum_dim_int_list_16 = None
        to_dtype_229 = torch.ops.aten.to.dtype(sigmoid_default_17, torch.float32);  sigmoid_default_17 = None
        rsub_scalar_15 = torch.ops.aten.rsub.Scalar(to_dtype_229, 1)
        mul_tensor_95 = torch.ops.aten.mul.Tensor(to_dtype_229, rsub_scalar_15);  to_dtype_229 = rsub_scalar_15 = None
        conj_physical_default_15 = torch.ops.aten.conj_physical.default(mul_tensor_95);  mul_tensor_95 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(to_dtype_228, conj_physical_default_15);  to_dtype_228 = conj_physical_default_15 = None
        to_dtype_230 = torch.ops.aten.to.dtype(mul_tensor_96, torch.float32);  mul_tensor_96 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(to_dtype_230, relu__default_71, primals_224, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_230 = primals_224 = None
        getitem_680 = convolution_backward_default_76[0]
        getitem_681 = convolution_backward_default_76[1]
        getitem_682 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_680, torch.float32);  getitem_680 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_165, to_dtype_231);  le_scalar_61 = new_zeros_default_165 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(to_dtype_233, mean_dim_17, primals_222, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_233 = mean_dim_17 = primals_222 = None
        getitem_683 = convolution_backward_default_77[0]
        getitem_684 = convolution_backward_default_77[1]
        getitem_685 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        expand_default_16 = torch.ops.aten.expand.default(getitem_683, [128, 1024, 14, 14]);  getitem_683 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_16, 196);  expand_default_16 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(mul_tensor_94, div_scalar_16);  mul_tensor_94 = div_scalar_16 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_63, convolution_default_91, primals_217, primals_215, primals_216, getitem_174, getitem_175, True, 1e-05, [True, True, True]);  add_tensor_63 = convolution_default_91 = primals_217 = primals_215 = primals_216 = getitem_174 = getitem_175 = None
        getitem_686 = native_batch_norm_backward_default_46[0]
        getitem_687 = native_batch_norm_backward_default_46[1]
        getitem_688 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_686, relu__default_70, primals_220, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_686 = primals_220 = None
        getitem_689 = convolution_backward_default_78[0]
        getitem_690 = convolution_backward_default_78[1]
        getitem_691 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_689, torch.float32);  getitem_689 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_166, to_dtype_234);  le_scalar_62 = new_zeros_default_166 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_90, primals_212, primals_210, primals_211, getitem_171, getitem_172, True, 1e-05, [True, True, True]);  to_dtype_236 = convolution_default_90 = primals_212 = primals_210 = primals_211 = getitem_171 = getitem_172 = None
        getitem_692 = native_batch_norm_backward_default_47[0]
        getitem_693 = native_batch_norm_backward_default_47[1]
        getitem_694 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_692, relu__default_69, primals_219, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_692 = primals_219 = None
        getitem_695 = convolution_backward_default_79[0]
        getitem_696 = convolution_backward_default_79[1]
        getitem_697 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_695, torch.float32);  getitem_695 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_167, to_dtype_237);  le_scalar_63 = new_zeros_default_167 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_89, primals_207, primals_205, primals_206, getitem_168, getitem_169, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_89 = primals_207 = primals_205 = primals_206 = getitem_168 = getitem_169 = None
        getitem_698 = native_batch_norm_backward_default_48[0]
        getitem_699 = native_batch_norm_backward_default_48[1]
        getitem_700 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_698, relu__default_68, primals_218, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_698 = primals_218 = None
        getitem_701 = convolution_backward_default_80[0]
        getitem_702 = convolution_backward_default_80[1]
        getitem_703 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(to_dtype_227, getitem_701);  to_dtype_227 = getitem_701 = None
        to_dtype_240 = torch.ops.aten.to.dtype(add_tensor_64, torch.float32);  add_tensor_64 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_168, to_dtype_240);  le_scalar_64 = new_zeros_default_168 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_242, getitem_164);  getitem_164 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_242, sigmoid_default_16)
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_97, [2, 3], True);  mul_tensor_97 = None
        to_dtype_243 = torch.ops.aten.to.dtype(sum_dim_int_list_17, torch.float32);  sum_dim_int_list_17 = None
        to_dtype_244 = torch.ops.aten.to.dtype(sigmoid_default_16, torch.float32);  sigmoid_default_16 = None
        rsub_scalar_16 = torch.ops.aten.rsub.Scalar(to_dtype_244, 1)
        mul_tensor_99 = torch.ops.aten.mul.Tensor(to_dtype_244, rsub_scalar_16);  to_dtype_244 = rsub_scalar_16 = None
        conj_physical_default_16 = torch.ops.aten.conj_physical.default(mul_tensor_99);  mul_tensor_99 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(to_dtype_243, conj_physical_default_16);  to_dtype_243 = conj_physical_default_16 = None
        to_dtype_245 = torch.ops.aten.to.dtype(mul_tensor_100, torch.float32);  mul_tensor_100 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(to_dtype_245, relu__default_67, primals_686, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_245 = primals_686 = None
        getitem_704 = convolution_backward_default_81[0]
        getitem_705 = convolution_backward_default_81[1]
        getitem_706 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_704, torch.float32);  getitem_704 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_169, to_dtype_246);  le_scalar_65 = new_zeros_default_169 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(to_dtype_248, mean_dim_16, primals_684, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_248 = mean_dim_16 = primals_684 = None
        getitem_707 = convolution_backward_default_82[0]
        getitem_708 = convolution_backward_default_82[1]
        getitem_709 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        expand_default_17 = torch.ops.aten.expand.default(getitem_707, [128, 1024, 14, 14]);  getitem_707 = None
        div_scalar_17 = torch.ops.aten.div.Scalar(expand_default_17, 196);  expand_default_17 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(mul_tensor_98, div_scalar_17);  mul_tensor_98 = div_scalar_17 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_65, convolution_default_86, primals_679, primals_677, primals_678, getitem_165, getitem_166, True, 1e-05, [True, True, True]);  add_tensor_65 = convolution_default_86 = primals_679 = primals_677 = primals_678 = getitem_165 = getitem_166 = None
        getitem_710 = native_batch_norm_backward_default_49[0]
        getitem_711 = native_batch_norm_backward_default_49[1]
        getitem_712 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_710, relu__default_66, primals_682, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_710 = primals_682 = None
        getitem_713 = convolution_backward_default_83[0]
        getitem_714 = convolution_backward_default_83[1]
        getitem_715 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_713, torch.float32);  getitem_713 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_170, to_dtype_249);  le_scalar_66 = new_zeros_default_170 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_85, primals_674, primals_672, primals_673, getitem_162, getitem_163, True, 1e-05, [True, True, True]);  to_dtype_251 = convolution_default_85 = primals_674 = primals_672 = primals_673 = getitem_162 = getitem_163 = None
        getitem_716 = native_batch_norm_backward_default_50[0]
        getitem_717 = native_batch_norm_backward_default_50[1]
        getitem_718 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_716, relu__default_65, primals_681, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_716 = primals_681 = None
        getitem_719 = convolution_backward_default_84[0]
        getitem_720 = convolution_backward_default_84[1]
        getitem_721 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_719, torch.float32);  getitem_719 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_171, to_dtype_252);  le_scalar_67 = new_zeros_default_171 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_84, primals_669, primals_667, primals_668, getitem_159, getitem_160, True, 1e-05, [True, True, True]);  to_dtype_254 = convolution_default_84 = primals_669 = primals_667 = primals_668 = getitem_159 = getitem_160 = None
        getitem_722 = native_batch_norm_backward_default_51[0]
        getitem_723 = native_batch_norm_backward_default_51[1]
        getitem_724 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_722, relu__default_64, primals_680, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_722 = primals_680 = None
        getitem_725 = convolution_backward_default_85[0]
        getitem_726 = convolution_backward_default_85[1]
        getitem_727 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(to_dtype_242, getitem_725);  to_dtype_242 = getitem_725 = None
        to_dtype_255 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_172, to_dtype_255);  le_scalar_68 = new_zeros_default_172 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_257, getitem_155);  getitem_155 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_257, sigmoid_default_15)
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(mul_tensor_101, [2, 3], True);  mul_tensor_101 = None
        to_dtype_258 = torch.ops.aten.to.dtype(sum_dim_int_list_18, torch.float32);  sum_dim_int_list_18 = None
        to_dtype_259 = torch.ops.aten.to.dtype(sigmoid_default_15, torch.float32);  sigmoid_default_15 = None
        rsub_scalar_17 = torch.ops.aten.rsub.Scalar(to_dtype_259, 1)
        mul_tensor_103 = torch.ops.aten.mul.Tensor(to_dtype_259, rsub_scalar_17);  to_dtype_259 = rsub_scalar_17 = None
        conj_physical_default_17 = torch.ops.aten.conj_physical.default(mul_tensor_103);  mul_tensor_103 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(to_dtype_258, conj_physical_default_17);  to_dtype_258 = conj_physical_default_17 = None
        to_dtype_260 = torch.ops.aten.to.dtype(mul_tensor_104, torch.float32);  mul_tensor_104 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(to_dtype_260, relu__default_63, primals_664, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_260 = primals_664 = None
        getitem_728 = convolution_backward_default_86[0]
        getitem_729 = convolution_backward_default_86[1]
        getitem_730 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_728, torch.float32);  getitem_728 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_173, to_dtype_261);  le_scalar_69 = new_zeros_default_173 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(to_dtype_263, mean_dim_15, primals_662, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_263 = mean_dim_15 = primals_662 = None
        getitem_731 = convolution_backward_default_87[0]
        getitem_732 = convolution_backward_default_87[1]
        getitem_733 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        expand_default_18 = torch.ops.aten.expand.default(getitem_731, [128, 1024, 14, 14]);  getitem_731 = None
        div_scalar_18 = torch.ops.aten.div.Scalar(expand_default_18, 196);  expand_default_18 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(mul_tensor_102, div_scalar_18);  mul_tensor_102 = div_scalar_18 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_67, convolution_default_81, primals_657, primals_655, primals_656, getitem_156, getitem_157, True, 1e-05, [True, True, True]);  add_tensor_67 = convolution_default_81 = primals_657 = primals_655 = primals_656 = getitem_156 = getitem_157 = None
        getitem_734 = native_batch_norm_backward_default_52[0]
        getitem_735 = native_batch_norm_backward_default_52[1]
        getitem_736 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_734, relu__default_62, primals_660, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_734 = primals_660 = None
        getitem_737 = convolution_backward_default_88[0]
        getitem_738 = convolution_backward_default_88[1]
        getitem_739 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        to_dtype_264 = torch.ops.aten.to.dtype(getitem_737, torch.float32);  getitem_737 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_174, to_dtype_264);  le_scalar_70 = new_zeros_default_174 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_80, primals_652, primals_650, primals_651, getitem_153, getitem_154, True, 1e-05, [True, True, True]);  to_dtype_266 = convolution_default_80 = primals_652 = primals_650 = primals_651 = getitem_153 = getitem_154 = None
        getitem_740 = native_batch_norm_backward_default_53[0]
        getitem_741 = native_batch_norm_backward_default_53[1]
        getitem_742 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_740, relu__default_61, primals_659, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_740 = primals_659 = None
        getitem_743 = convolution_backward_default_89[0]
        getitem_744 = convolution_backward_default_89[1]
        getitem_745 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_743, torch.float32);  getitem_743 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_175, to_dtype_267);  le_scalar_71 = new_zeros_default_175 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_79, primals_647, primals_645, primals_646, getitem_150, getitem_151, True, 1e-05, [True, True, True]);  to_dtype_269 = convolution_default_79 = primals_647 = primals_645 = primals_646 = getitem_150 = getitem_151 = None
        getitem_746 = native_batch_norm_backward_default_54[0]
        getitem_747 = native_batch_norm_backward_default_54[1]
        getitem_748 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_746, relu__default_60, primals_658, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_746 = primals_658 = None
        getitem_749 = convolution_backward_default_90[0]
        getitem_750 = convolution_backward_default_90[1]
        getitem_751 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(to_dtype_257, getitem_749);  to_dtype_257 = getitem_749 = None
        to_dtype_270 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_176, to_dtype_270);  le_scalar_72 = new_zeros_default_176 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_272, getitem_146);  getitem_146 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_272, sigmoid_default_14)
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(mul_tensor_105, [2, 3], True);  mul_tensor_105 = None
        to_dtype_273 = torch.ops.aten.to.dtype(sum_dim_int_list_19, torch.float32);  sum_dim_int_list_19 = None
        to_dtype_274 = torch.ops.aten.to.dtype(sigmoid_default_14, torch.float32);  sigmoid_default_14 = None
        rsub_scalar_18 = torch.ops.aten.rsub.Scalar(to_dtype_274, 1)
        mul_tensor_107 = torch.ops.aten.mul.Tensor(to_dtype_274, rsub_scalar_18);  to_dtype_274 = rsub_scalar_18 = None
        conj_physical_default_18 = torch.ops.aten.conj_physical.default(mul_tensor_107);  mul_tensor_107 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(to_dtype_273, conj_physical_default_18);  to_dtype_273 = conj_physical_default_18 = None
        to_dtype_275 = torch.ops.aten.to.dtype(mul_tensor_108, torch.float32);  mul_tensor_108 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(to_dtype_275, relu__default_59, primals_642, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_275 = primals_642 = None
        getitem_752 = convolution_backward_default_91[0]
        getitem_753 = convolution_backward_default_91[1]
        getitem_754 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        to_dtype_276 = torch.ops.aten.to.dtype(getitem_752, torch.float32);  getitem_752 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_177, to_dtype_276);  le_scalar_73 = new_zeros_default_177 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(to_dtype_278, mean_dim_14, primals_640, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_278 = mean_dim_14 = primals_640 = None
        getitem_755 = convolution_backward_default_92[0]
        getitem_756 = convolution_backward_default_92[1]
        getitem_757 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        expand_default_19 = torch.ops.aten.expand.default(getitem_755, [128, 1024, 14, 14]);  getitem_755 = None
        div_scalar_19 = torch.ops.aten.div.Scalar(expand_default_19, 196);  expand_default_19 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(mul_tensor_106, div_scalar_19);  mul_tensor_106 = div_scalar_19 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_69, convolution_default_76, primals_635, primals_633, primals_634, getitem_147, getitem_148, True, 1e-05, [True, True, True]);  add_tensor_69 = convolution_default_76 = primals_635 = primals_633 = primals_634 = getitem_147 = getitem_148 = None
        getitem_758 = native_batch_norm_backward_default_55[0]
        getitem_759 = native_batch_norm_backward_default_55[1]
        getitem_760 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_758, relu__default_58, primals_638, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_758 = primals_638 = None
        getitem_761 = convolution_backward_default_93[0]
        getitem_762 = convolution_backward_default_93[1]
        getitem_763 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_761, torch.float32);  getitem_761 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_178, to_dtype_279);  le_scalar_74 = new_zeros_default_178 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_75, primals_630, primals_628, primals_629, getitem_144, getitem_145, True, 1e-05, [True, True, True]);  to_dtype_281 = convolution_default_75 = primals_630 = primals_628 = primals_629 = getitem_144 = getitem_145 = None
        getitem_764 = native_batch_norm_backward_default_56[0]
        getitem_765 = native_batch_norm_backward_default_56[1]
        getitem_766 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_764, relu__default_57, primals_637, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_764 = primals_637 = None
        getitem_767 = convolution_backward_default_94[0]
        getitem_768 = convolution_backward_default_94[1]
        getitem_769 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_767, torch.float32);  getitem_767 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_179, to_dtype_282);  le_scalar_75 = new_zeros_default_179 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_74, primals_625, primals_623, primals_624, getitem_141, getitem_142, True, 1e-05, [True, True, True]);  to_dtype_284 = convolution_default_74 = primals_625 = primals_623 = primals_624 = getitem_141 = getitem_142 = None
        getitem_770 = native_batch_norm_backward_default_57[0]
        getitem_771 = native_batch_norm_backward_default_57[1]
        getitem_772 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_770, relu__default_56, primals_636, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_770 = primals_636 = None
        getitem_773 = convolution_backward_default_95[0]
        getitem_774 = convolution_backward_default_95[1]
        getitem_775 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(to_dtype_272, getitem_773);  to_dtype_272 = getitem_773 = None
        to_dtype_285 = torch.ops.aten.to.dtype(add_tensor_70, torch.float32);  add_tensor_70 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_180, to_dtype_285);  le_scalar_76 = new_zeros_default_180 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_287, getitem_137);  getitem_137 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(to_dtype_287, sigmoid_default_13)
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(mul_tensor_109, [2, 3], True);  mul_tensor_109 = None
        to_dtype_288 = torch.ops.aten.to.dtype(sum_dim_int_list_20, torch.float32);  sum_dim_int_list_20 = None
        to_dtype_289 = torch.ops.aten.to.dtype(sigmoid_default_13, torch.float32);  sigmoid_default_13 = None
        rsub_scalar_19 = torch.ops.aten.rsub.Scalar(to_dtype_289, 1)
        mul_tensor_111 = torch.ops.aten.mul.Tensor(to_dtype_289, rsub_scalar_19);  to_dtype_289 = rsub_scalar_19 = None
        conj_physical_default_19 = torch.ops.aten.conj_physical.default(mul_tensor_111);  mul_tensor_111 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_288, conj_physical_default_19);  to_dtype_288 = conj_physical_default_19 = None
        to_dtype_290 = torch.ops.aten.to.dtype(mul_tensor_112, torch.float32);  mul_tensor_112 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(to_dtype_290, relu__default_55, primals_620, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_290 = primals_620 = None
        getitem_776 = convolution_backward_default_96[0]
        getitem_777 = convolution_backward_default_96[1]
        getitem_778 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_776, torch.float32);  getitem_776 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_181, to_dtype_291);  le_scalar_77 = new_zeros_default_181 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(to_dtype_293, mean_dim_13, primals_618, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_293 = mean_dim_13 = primals_618 = None
        getitem_779 = convolution_backward_default_97[0]
        getitem_780 = convolution_backward_default_97[1]
        getitem_781 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        expand_default_20 = torch.ops.aten.expand.default(getitem_779, [128, 1024, 14, 14]);  getitem_779 = None
        div_scalar_20 = torch.ops.aten.div.Scalar(expand_default_20, 196);  expand_default_20 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(mul_tensor_110, div_scalar_20);  mul_tensor_110 = div_scalar_20 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_71, convolution_default_71, primals_613, primals_611, primals_612, getitem_138, getitem_139, True, 1e-05, [True, True, True]);  add_tensor_71 = convolution_default_71 = primals_613 = primals_611 = primals_612 = getitem_138 = getitem_139 = None
        getitem_782 = native_batch_norm_backward_default_58[0]
        getitem_783 = native_batch_norm_backward_default_58[1]
        getitem_784 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_782, relu__default_54, primals_616, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_782 = primals_616 = None
        getitem_785 = convolution_backward_default_98[0]
        getitem_786 = convolution_backward_default_98[1]
        getitem_787 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_785, torch.float32);  getitem_785 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_182, to_dtype_294);  le_scalar_78 = new_zeros_default_182 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_70, primals_608, primals_606, primals_607, getitem_135, getitem_136, True, 1e-05, [True, True, True]);  to_dtype_296 = convolution_default_70 = primals_608 = primals_606 = primals_607 = getitem_135 = getitem_136 = None
        getitem_788 = native_batch_norm_backward_default_59[0]
        getitem_789 = native_batch_norm_backward_default_59[1]
        getitem_790 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_788, relu__default_53, primals_615, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_788 = primals_615 = None
        getitem_791 = convolution_backward_default_99[0]
        getitem_792 = convolution_backward_default_99[1]
        getitem_793 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_791, torch.float32);  getitem_791 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_183, to_dtype_297);  le_scalar_79 = new_zeros_default_183 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_69, primals_603, primals_601, primals_602, getitem_132, getitem_133, True, 1e-05, [True, True, True]);  to_dtype_299 = convolution_default_69 = primals_603 = primals_601 = primals_602 = getitem_132 = getitem_133 = None
        getitem_794 = native_batch_norm_backward_default_60[0]
        getitem_795 = native_batch_norm_backward_default_60[1]
        getitem_796 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_794, relu__default_52, primals_614, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_794 = primals_614 = None
        getitem_797 = convolution_backward_default_100[0]
        getitem_798 = convolution_backward_default_100[1]
        getitem_799 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(to_dtype_287, getitem_797);  to_dtype_287 = getitem_797 = None
        to_dtype_300 = torch.ops.aten.to.dtype(add_tensor_72, torch.float32);  add_tensor_72 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_184, to_dtype_300);  le_scalar_80 = new_zeros_default_184 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(to_dtype_302, getitem_128);  getitem_128 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(to_dtype_302, sigmoid_default_12)
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(mul_tensor_113, [2, 3], True);  mul_tensor_113 = None
        to_dtype_303 = torch.ops.aten.to.dtype(sum_dim_int_list_21, torch.float32);  sum_dim_int_list_21 = None
        to_dtype_304 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar_20 = torch.ops.aten.rsub.Scalar(to_dtype_304, 1)
        mul_tensor_115 = torch.ops.aten.mul.Tensor(to_dtype_304, rsub_scalar_20);  to_dtype_304 = rsub_scalar_20 = None
        conj_physical_default_20 = torch.ops.aten.conj_physical.default(mul_tensor_115);  mul_tensor_115 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(to_dtype_303, conj_physical_default_20);  to_dtype_303 = conj_physical_default_20 = None
        to_dtype_305 = torch.ops.aten.to.dtype(mul_tensor_116, torch.float32);  mul_tensor_116 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(to_dtype_305, relu__default_51, primals_598, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_305 = primals_598 = None
        getitem_800 = convolution_backward_default_101[0]
        getitem_801 = convolution_backward_default_101[1]
        getitem_802 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        to_dtype_306 = torch.ops.aten.to.dtype(getitem_800, torch.float32);  getitem_800 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_185, to_dtype_306);  le_scalar_81 = new_zeros_default_185 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(to_dtype_308, mean_dim_12, primals_596, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_308 = mean_dim_12 = primals_596 = None
        getitem_803 = convolution_backward_default_102[0]
        getitem_804 = convolution_backward_default_102[1]
        getitem_805 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        expand_default_21 = torch.ops.aten.expand.default(getitem_803, [128, 1024, 14, 14]);  getitem_803 = None
        div_scalar_21 = torch.ops.aten.div.Scalar(expand_default_21, 196);  expand_default_21 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_114, div_scalar_21);  mul_tensor_114 = div_scalar_21 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_73, convolution_default_66, primals_591, primals_589, primals_590, getitem_129, getitem_130, True, 1e-05, [True, True, True]);  add_tensor_73 = convolution_default_66 = primals_591 = primals_589 = primals_590 = getitem_129 = getitem_130 = None
        getitem_806 = native_batch_norm_backward_default_61[0]
        getitem_807 = native_batch_norm_backward_default_61[1]
        getitem_808 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_806, relu__default_50, primals_594, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_806 = primals_594 = None
        getitem_809 = convolution_backward_default_103[0]
        getitem_810 = convolution_backward_default_103[1]
        getitem_811 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        to_dtype_309 = torch.ops.aten.to.dtype(getitem_809, torch.float32);  getitem_809 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_186, to_dtype_309);  le_scalar_82 = new_zeros_default_186 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_65, primals_586, primals_584, primals_585, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  to_dtype_311 = convolution_default_65 = primals_586 = primals_584 = primals_585 = getitem_126 = getitem_127 = None
        getitem_812 = native_batch_norm_backward_default_62[0]
        getitem_813 = native_batch_norm_backward_default_62[1]
        getitem_814 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_812, relu__default_49, primals_593, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_812 = primals_593 = None
        getitem_815 = convolution_backward_default_104[0]
        getitem_816 = convolution_backward_default_104[1]
        getitem_817 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        to_dtype_312 = torch.ops.aten.to.dtype(getitem_815, torch.float32);  getitem_815 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_187, to_dtype_312);  le_scalar_83 = new_zeros_default_187 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_314, convolution_default_64, primals_581, primals_579, primals_580, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  to_dtype_314 = convolution_default_64 = primals_581 = primals_579 = primals_580 = getitem_123 = getitem_124 = None
        getitem_818 = native_batch_norm_backward_default_63[0]
        getitem_819 = native_batch_norm_backward_default_63[1]
        getitem_820 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_818, relu__default_48, primals_592, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_818 = primals_592 = None
        getitem_821 = convolution_backward_default_105[0]
        getitem_822 = convolution_backward_default_105[1]
        getitem_823 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(to_dtype_302, getitem_821);  to_dtype_302 = getitem_821 = None
        to_dtype_315 = torch.ops.aten.to.dtype(add_tensor_74, torch.float32);  add_tensor_74 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_188, to_dtype_315);  le_scalar_84 = new_zeros_default_188 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_317, getitem_119);  getitem_119 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(to_dtype_317, sigmoid_default_11)
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(mul_tensor_117, [2, 3], True);  mul_tensor_117 = None
        to_dtype_318 = torch.ops.aten.to.dtype(sum_dim_int_list_22, torch.float32);  sum_dim_int_list_22 = None
        to_dtype_319 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_21 = torch.ops.aten.rsub.Scalar(to_dtype_319, 1)
        mul_tensor_119 = torch.ops.aten.mul.Tensor(to_dtype_319, rsub_scalar_21);  to_dtype_319 = rsub_scalar_21 = None
        conj_physical_default_21 = torch.ops.aten.conj_physical.default(mul_tensor_119);  mul_tensor_119 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_318, conj_physical_default_21);  to_dtype_318 = conj_physical_default_21 = None
        to_dtype_320 = torch.ops.aten.to.dtype(mul_tensor_120, torch.float32);  mul_tensor_120 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(to_dtype_320, relu__default_47, primals_576, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_320 = primals_576 = None
        getitem_824 = convolution_backward_default_106[0]
        getitem_825 = convolution_backward_default_106[1]
        getitem_826 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_824, torch.float32);  getitem_824 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_189, to_dtype_321);  le_scalar_85 = new_zeros_default_189 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(to_dtype_323, mean_dim_11, primals_574, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_323 = mean_dim_11 = primals_574 = None
        getitem_827 = convolution_backward_default_107[0]
        getitem_828 = convolution_backward_default_107[1]
        getitem_829 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        expand_default_22 = torch.ops.aten.expand.default(getitem_827, [128, 1024, 14, 14]);  getitem_827 = None
        div_scalar_22 = torch.ops.aten.div.Scalar(expand_default_22, 196);  expand_default_22 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(mul_tensor_118, div_scalar_22);  mul_tensor_118 = div_scalar_22 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_75, convolution_default_61, primals_569, primals_567, primals_568, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  add_tensor_75 = convolution_default_61 = primals_569 = primals_567 = primals_568 = getitem_120 = getitem_121 = None
        getitem_830 = native_batch_norm_backward_default_64[0]
        getitem_831 = native_batch_norm_backward_default_64[1]
        getitem_832 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_830, relu__default_46, primals_572, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_830 = primals_572 = None
        getitem_833 = convolution_backward_default_108[0]
        getitem_834 = convolution_backward_default_108[1]
        getitem_835 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        to_dtype_324 = torch.ops.aten.to.dtype(getitem_833, torch.float32);  getitem_833 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_190, to_dtype_324);  le_scalar_86 = new_zeros_default_190 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_326, convolution_default_60, primals_564, primals_562, primals_563, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  to_dtype_326 = convolution_default_60 = primals_564 = primals_562 = primals_563 = getitem_117 = getitem_118 = None
        getitem_836 = native_batch_norm_backward_default_65[0]
        getitem_837 = native_batch_norm_backward_default_65[1]
        getitem_838 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_836, relu__default_45, primals_571, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_836 = primals_571 = None
        getitem_839 = convolution_backward_default_109[0]
        getitem_840 = convolution_backward_default_109[1]
        getitem_841 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        to_dtype_327 = torch.ops.aten.to.dtype(getitem_839, torch.float32);  getitem_839 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_191, to_dtype_327);  le_scalar_87 = new_zeros_default_191 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_59, primals_559, primals_557, primals_558, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  to_dtype_329 = convolution_default_59 = primals_559 = primals_557 = primals_558 = getitem_114 = getitem_115 = None
        getitem_842 = native_batch_norm_backward_default_66[0]
        getitem_843 = native_batch_norm_backward_default_66[1]
        getitem_844 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_842, relu__default_44, primals_570, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_842 = primals_570 = None
        getitem_845 = convolution_backward_default_110[0]
        getitem_846 = convolution_backward_default_110[1]
        getitem_847 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(to_dtype_317, getitem_845);  to_dtype_317 = getitem_845 = None
        to_dtype_330 = torch.ops.aten.to.dtype(add_tensor_76, torch.float32);  add_tensor_76 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_192, to_dtype_330);  le_scalar_88 = new_zeros_default_192 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_332, getitem_110);  getitem_110 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(to_dtype_332, sigmoid_default_10)
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(mul_tensor_121, [2, 3], True);  mul_tensor_121 = None
        to_dtype_333 = torch.ops.aten.to.dtype(sum_dim_int_list_23, torch.float32);  sum_dim_int_list_23 = None
        to_dtype_334 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_22 = torch.ops.aten.rsub.Scalar(to_dtype_334, 1)
        mul_tensor_123 = torch.ops.aten.mul.Tensor(to_dtype_334, rsub_scalar_22);  to_dtype_334 = rsub_scalar_22 = None
        conj_physical_default_22 = torch.ops.aten.conj_physical.default(mul_tensor_123);  mul_tensor_123 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_333, conj_physical_default_22);  to_dtype_333 = conj_physical_default_22 = None
        to_dtype_335 = torch.ops.aten.to.dtype(mul_tensor_124, torch.float32);  mul_tensor_124 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(to_dtype_335, relu__default_43, primals_554, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_335 = primals_554 = None
        getitem_848 = convolution_backward_default_111[0]
        getitem_849 = convolution_backward_default_111[1]
        getitem_850 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        to_dtype_336 = torch.ops.aten.to.dtype(getitem_848, torch.float32);  getitem_848 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_193, to_dtype_336);  le_scalar_89 = new_zeros_default_193 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(to_dtype_338, mean_dim_10, primals_552, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_338 = mean_dim_10 = primals_552 = None
        getitem_851 = convolution_backward_default_112[0]
        getitem_852 = convolution_backward_default_112[1]
        getitem_853 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        expand_default_23 = torch.ops.aten.expand.default(getitem_851, [128, 1024, 14, 14]);  getitem_851 = None
        div_scalar_23 = torch.ops.aten.div.Scalar(expand_default_23, 196);  expand_default_23 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(mul_tensor_122, div_scalar_23);  mul_tensor_122 = div_scalar_23 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_77, convolution_default_56, primals_547, primals_545, primals_546, getitem_111, getitem_112, True, 1e-05, [True, True, True]);  add_tensor_77 = convolution_default_56 = primals_547 = primals_545 = primals_546 = getitem_111 = getitem_112 = None
        getitem_854 = native_batch_norm_backward_default_67[0]
        getitem_855 = native_batch_norm_backward_default_67[1]
        getitem_856 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_854, relu__default_42, primals_550, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_854 = primals_550 = None
        getitem_857 = convolution_backward_default_113[0]
        getitem_858 = convolution_backward_default_113[1]
        getitem_859 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        to_dtype_339 = torch.ops.aten.to.dtype(getitem_857, torch.float32);  getitem_857 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_194, to_dtype_339);  le_scalar_90 = new_zeros_default_194 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_55, primals_542, primals_540, primals_541, getitem_108, getitem_109, True, 1e-05, [True, True, True]);  to_dtype_341 = convolution_default_55 = primals_542 = primals_540 = primals_541 = getitem_108 = getitem_109 = None
        getitem_860 = native_batch_norm_backward_default_68[0]
        getitem_861 = native_batch_norm_backward_default_68[1]
        getitem_862 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_860, relu__default_41, primals_549, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_860 = primals_549 = None
        getitem_863 = convolution_backward_default_114[0]
        getitem_864 = convolution_backward_default_114[1]
        getitem_865 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        to_dtype_342 = torch.ops.aten.to.dtype(getitem_863, torch.float32);  getitem_863 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_195, to_dtype_342);  le_scalar_91 = new_zeros_default_195 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_344, convolution_default_54, primals_537, primals_535, primals_536, getitem_105, getitem_106, True, 1e-05, [True, True, True]);  to_dtype_344 = convolution_default_54 = primals_537 = primals_535 = primals_536 = getitem_105 = getitem_106 = None
        getitem_866 = native_batch_norm_backward_default_69[0]
        getitem_867 = native_batch_norm_backward_default_69[1]
        getitem_868 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_866, relu__default_40, primals_548, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_866 = primals_548 = None
        getitem_869 = convolution_backward_default_115[0]
        getitem_870 = convolution_backward_default_115[1]
        getitem_871 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(to_dtype_332, getitem_869);  to_dtype_332 = getitem_869 = None
        to_dtype_345 = torch.ops.aten.to.dtype(add_tensor_78, torch.float32);  add_tensor_78 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_196, to_dtype_345);  le_scalar_92 = new_zeros_default_196 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_347, getitem_101);  getitem_101 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_347, sigmoid_default_9)
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(mul_tensor_125, [2, 3], True);  mul_tensor_125 = None
        to_dtype_348 = torch.ops.aten.to.dtype(sum_dim_int_list_24, torch.float32);  sum_dim_int_list_24 = None
        to_dtype_349 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_23 = torch.ops.aten.rsub.Scalar(to_dtype_349, 1)
        mul_tensor_127 = torch.ops.aten.mul.Tensor(to_dtype_349, rsub_scalar_23);  to_dtype_349 = rsub_scalar_23 = None
        conj_physical_default_23 = torch.ops.aten.conj_physical.default(mul_tensor_127);  mul_tensor_127 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(to_dtype_348, conj_physical_default_23);  to_dtype_348 = conj_physical_default_23 = None
        to_dtype_350 = torch.ops.aten.to.dtype(mul_tensor_128, torch.float32);  mul_tensor_128 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(to_dtype_350, relu__default_39, primals_532, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_350 = primals_532 = None
        getitem_872 = convolution_backward_default_116[0]
        getitem_873 = convolution_backward_default_116[1]
        getitem_874 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        to_dtype_351 = torch.ops.aten.to.dtype(getitem_872, torch.float32);  getitem_872 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_197, to_dtype_351);  le_scalar_93 = new_zeros_default_197 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(to_dtype_353, mean_dim_9, primals_530, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_353 = mean_dim_9 = primals_530 = None
        getitem_875 = convolution_backward_default_117[0]
        getitem_876 = convolution_backward_default_117[1]
        getitem_877 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        expand_default_24 = torch.ops.aten.expand.default(getitem_875, [128, 1024, 14, 14]);  getitem_875 = None
        div_scalar_24 = torch.ops.aten.div.Scalar(expand_default_24, 196);  expand_default_24 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(mul_tensor_126, div_scalar_24);  mul_tensor_126 = div_scalar_24 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_79, convolution_default_51, primals_525, primals_523, primals_524, getitem_102, getitem_103, True, 1e-05, [True, True, True]);  add_tensor_79 = convolution_default_51 = primals_525 = primals_523 = primals_524 = getitem_102 = getitem_103 = None
        getitem_878 = native_batch_norm_backward_default_70[0]
        getitem_879 = native_batch_norm_backward_default_70[1]
        getitem_880 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_878, relu__default_38, primals_528, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_878 = primals_528 = None
        getitem_881 = convolution_backward_default_118[0]
        getitem_882 = convolution_backward_default_118[1]
        getitem_883 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        to_dtype_354 = torch.ops.aten.to.dtype(getitem_881, torch.float32);  getitem_881 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_198, to_dtype_354);  le_scalar_94 = new_zeros_default_198 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_356, convolution_default_50, primals_520, primals_518, primals_519, getitem_99, getitem_100, True, 1e-05, [True, True, True]);  to_dtype_356 = convolution_default_50 = primals_520 = primals_518 = primals_519 = getitem_99 = getitem_100 = None
        getitem_884 = native_batch_norm_backward_default_71[0]
        getitem_885 = native_batch_norm_backward_default_71[1]
        getitem_886 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_884, relu__default_37, primals_527, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_884 = primals_527 = None
        getitem_887 = convolution_backward_default_119[0]
        getitem_888 = convolution_backward_default_119[1]
        getitem_889 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_887, torch.float32);  getitem_887 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_199, to_dtype_357);  le_scalar_95 = new_zeros_default_199 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_49, primals_515, primals_513, primals_514, getitem_96, getitem_97, True, 1e-05, [True, True, True]);  to_dtype_359 = convolution_default_49 = primals_515 = primals_513 = primals_514 = getitem_96 = getitem_97 = None
        getitem_890 = native_batch_norm_backward_default_72[0]
        getitem_891 = native_batch_norm_backward_default_72[1]
        getitem_892 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_890, relu__default_36, primals_526, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_890 = primals_526 = None
        getitem_893 = convolution_backward_default_120[0]
        getitem_894 = convolution_backward_default_120[1]
        getitem_895 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(to_dtype_347, getitem_893);  to_dtype_347 = getitem_893 = None
        to_dtype_360 = torch.ops.aten.to.dtype(add_tensor_80, torch.float32);  add_tensor_80 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_200, to_dtype_360);  le_scalar_96 = new_zeros_default_200 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_362, getitem_92);  getitem_92 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(to_dtype_362, sigmoid_default_8)
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(mul_tensor_129, [2, 3], True);  mul_tensor_129 = None
        to_dtype_363 = torch.ops.aten.to.dtype(sum_dim_int_list_25, torch.float32);  sum_dim_int_list_25 = None
        to_dtype_364 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_24 = torch.ops.aten.rsub.Scalar(to_dtype_364, 1)
        mul_tensor_131 = torch.ops.aten.mul.Tensor(to_dtype_364, rsub_scalar_24);  to_dtype_364 = rsub_scalar_24 = None
        conj_physical_default_24 = torch.ops.aten.conj_physical.default(mul_tensor_131);  mul_tensor_131 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(to_dtype_363, conj_physical_default_24);  to_dtype_363 = conj_physical_default_24 = None
        to_dtype_365 = torch.ops.aten.to.dtype(mul_tensor_132, torch.float32);  mul_tensor_132 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(to_dtype_365, relu__default_35, primals_444, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_365 = primals_444 = None
        getitem_896 = convolution_backward_default_121[0]
        getitem_897 = convolution_backward_default_121[1]
        getitem_898 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        to_dtype_366 = torch.ops.aten.to.dtype(getitem_896, torch.float32);  getitem_896 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_201, to_dtype_366);  le_scalar_97 = new_zeros_default_201 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(to_dtype_368, mean_dim_8, primals_442, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_368 = mean_dim_8 = primals_442 = None
        getitem_899 = convolution_backward_default_122[0]
        getitem_900 = convolution_backward_default_122[1]
        getitem_901 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        expand_default_25 = torch.ops.aten.expand.default(getitem_899, [128, 1024, 14, 14]);  getitem_899 = None
        div_scalar_25 = torch.ops.aten.div.Scalar(expand_default_25, 196);  expand_default_25 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(mul_tensor_130, div_scalar_25);  mul_tensor_130 = div_scalar_25 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_81, convolution_default_46, primals_437, primals_435, primals_436, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  add_tensor_81 = convolution_default_46 = primals_437 = primals_435 = primals_436 = getitem_93 = getitem_94 = None
        getitem_902 = native_batch_norm_backward_default_73[0]
        getitem_903 = native_batch_norm_backward_default_73[1]
        getitem_904 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_902, relu__default_34, primals_440, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_902 = primals_440 = None
        getitem_905 = convolution_backward_default_123[0]
        getitem_906 = convolution_backward_default_123[1]
        getitem_907 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        to_dtype_369 = torch.ops.aten.to.dtype(getitem_905, torch.float32);  getitem_905 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_202, to_dtype_369);  le_scalar_98 = new_zeros_default_202 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_45, primals_432, primals_430, primals_431, getitem_90, getitem_91, True, 1e-05, [True, True, True]);  to_dtype_371 = convolution_default_45 = primals_432 = primals_430 = primals_431 = getitem_90 = getitem_91 = None
        getitem_908 = native_batch_norm_backward_default_74[0]
        getitem_909 = native_batch_norm_backward_default_74[1]
        getitem_910 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_908, relu__default_33, primals_439, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_908 = primals_439 = None
        getitem_911 = convolution_backward_default_124[0]
        getitem_912 = convolution_backward_default_124[1]
        getitem_913 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        to_dtype_372 = torch.ops.aten.to.dtype(getitem_911, torch.float32);  getitem_911 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_203, to_dtype_372);  le_scalar_99 = new_zeros_default_203 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_374, convolution_default_44, primals_427, primals_425, primals_426, getitem_87, getitem_88, True, 1e-05, [True, True, True]);  to_dtype_374 = convolution_default_44 = primals_427 = primals_425 = primals_426 = getitem_87 = getitem_88 = None
        getitem_914 = native_batch_norm_backward_default_75[0]
        getitem_915 = native_batch_norm_backward_default_75[1]
        getitem_916 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_914, relu__default_32, primals_438, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_914 = primals_438 = None
        getitem_917 = convolution_backward_default_125[0]
        getitem_918 = convolution_backward_default_125[1]
        getitem_919 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(to_dtype_362, getitem_917);  to_dtype_362 = getitem_917 = None
        to_dtype_375 = torch.ops.aten.to.dtype(add_tensor_82, torch.float32);  add_tensor_82 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_204, to_dtype_375);  le_scalar_100 = new_zeros_default_204 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_377, getitem_80);  getitem_80 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(to_dtype_377, sigmoid_default_7)
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(mul_tensor_133, [2, 3], True);  mul_tensor_133 = None
        to_dtype_378 = torch.ops.aten.to.dtype(sum_dim_int_list_26, torch.float32);  sum_dim_int_list_26 = None
        to_dtype_379 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_25 = torch.ops.aten.rsub.Scalar(to_dtype_379, 1)
        mul_tensor_135 = torch.ops.aten.mul.Tensor(to_dtype_379, rsub_scalar_25);  to_dtype_379 = rsub_scalar_25 = None
        conj_physical_default_25 = torch.ops.aten.conj_physical.default(mul_tensor_135);  mul_tensor_135 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(to_dtype_378, conj_physical_default_25);  to_dtype_378 = conj_physical_default_25 = None
        to_dtype_380 = torch.ops.aten.to.dtype(mul_tensor_136, torch.float32);  mul_tensor_136 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(to_dtype_380, relu__default_31, primals_202, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_380 = primals_202 = None
        getitem_920 = convolution_backward_default_126[0]
        getitem_921 = convolution_backward_default_126[1]
        getitem_922 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_920, torch.float32);  getitem_920 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_205, to_dtype_381);  le_scalar_101 = new_zeros_default_205 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(to_dtype_383, mean_dim_7, primals_200, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_383 = mean_dim_7 = primals_200 = None
        getitem_923 = convolution_backward_default_127[0]
        getitem_924 = convolution_backward_default_127[1]
        getitem_925 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        expand_default_26 = torch.ops.aten.expand.default(getitem_923, [128, 1024, 14, 14]);  getitem_923 = None
        div_scalar_26 = torch.ops.aten.div.Scalar(expand_default_26, 196);  expand_default_26 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(mul_tensor_134, div_scalar_26);  mul_tensor_134 = div_scalar_26 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_41, primals_198, primals_196, primals_197, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  to_dtype_377 = convolution_default_41 = primals_198 = primals_196 = primals_197 = getitem_84 = getitem_85 = None
        getitem_926 = native_batch_norm_backward_default_76[0]
        getitem_927 = native_batch_norm_backward_default_76[1]
        getitem_928 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_926, relu__default_28, primals_193, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_926 = primals_193 = None
        getitem_929 = convolution_backward_default_128[0]
        getitem_930 = convolution_backward_default_128[1]
        getitem_931 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_83, convolution_default_40, primals_189, primals_187, primals_188, getitem_81, getitem_82, True, 1e-05, [True, True, True]);  add_tensor_83 = convolution_default_40 = primals_189 = primals_187 = primals_188 = getitem_81 = getitem_82 = None
        getitem_932 = native_batch_norm_backward_default_77[0]
        getitem_933 = native_batch_norm_backward_default_77[1]
        getitem_934 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_932, relu__default_30, primals_192, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_932 = primals_192 = None
        getitem_935 = convolution_backward_default_129[0]
        getitem_936 = convolution_backward_default_129[1]
        getitem_937 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        to_dtype_384 = torch.ops.aten.to.dtype(getitem_935, torch.float32);  getitem_935 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_206, to_dtype_384);  le_scalar_102 = new_zeros_default_206 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_39, primals_184, primals_182, primals_183, getitem_78, getitem_79, True, 1e-05, [True, True, True]);  to_dtype_386 = convolution_default_39 = primals_184 = primals_182 = primals_183 = getitem_78 = getitem_79 = None
        getitem_938 = native_batch_norm_backward_default_78[0]
        getitem_939 = native_batch_norm_backward_default_78[1]
        getitem_940 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_938, relu__default_29, primals_191, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_938 = primals_191 = None
        getitem_941 = convolution_backward_default_130[0]
        getitem_942 = convolution_backward_default_130[1]
        getitem_943 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        to_dtype_387 = torch.ops.aten.to.dtype(getitem_941, torch.float32);  getitem_941 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_207, to_dtype_387);  le_scalar_103 = new_zeros_default_207 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_38, primals_179, primals_177, primals_178, getitem_75, getitem_76, True, 1e-05, [True, True, True]);  to_dtype_389 = convolution_default_38 = primals_179 = primals_177 = primals_178 = getitem_75 = getitem_76 = None
        getitem_944 = native_batch_norm_backward_default_79[0]
        getitem_945 = native_batch_norm_backward_default_79[1]
        getitem_946 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_944, relu__default_28, primals_190, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_944 = primals_190 = None
        getitem_947 = convolution_backward_default_131[0]
        getitem_948 = convolution_backward_default_131[1]
        getitem_949 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(getitem_929, getitem_947);  getitem_929 = getitem_947 = None
        to_dtype_390 = torch.ops.aten.to.dtype(add_tensor_84, torch.float32);  add_tensor_84 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_208, to_dtype_390);  le_scalar_104 = new_zeros_default_208 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_392, getitem_71);  getitem_71 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_392, sigmoid_default_6)
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(mul_tensor_137, [2, 3], True);  mul_tensor_137 = None
        to_dtype_393 = torch.ops.aten.to.dtype(sum_dim_int_list_27, torch.float32);  sum_dim_int_list_27 = None
        to_dtype_394 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_26 = torch.ops.aten.rsub.Scalar(to_dtype_394, 1)
        mul_tensor_139 = torch.ops.aten.mul.Tensor(to_dtype_394, rsub_scalar_26);  to_dtype_394 = rsub_scalar_26 = None
        conj_physical_default_26 = torch.ops.aten.conj_physical.default(mul_tensor_139);  mul_tensor_139 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(to_dtype_393, conj_physical_default_26);  to_dtype_393 = conj_physical_default_26 = None
        to_dtype_395 = torch.ops.aten.to.dtype(mul_tensor_140, torch.float32);  mul_tensor_140 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(to_dtype_395, relu__default_27, primals_174, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_395 = primals_174 = None
        getitem_950 = convolution_backward_default_132[0]
        getitem_951 = convolution_backward_default_132[1]
        getitem_952 = convolution_backward_default_132[2];  convolution_backward_default_132 = None
        to_dtype_396 = torch.ops.aten.to.dtype(getitem_950, torch.float32);  getitem_950 = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_209, to_dtype_396);  le_scalar_105 = new_zeros_default_209 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(to_dtype_398, mean_dim_6, primals_172, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_398 = mean_dim_6 = primals_172 = None
        getitem_953 = convolution_backward_default_133[0]
        getitem_954 = convolution_backward_default_133[1]
        getitem_955 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        expand_default_27 = torch.ops.aten.expand.default(getitem_953, [128, 512, 28, 28]);  getitem_953 = None
        div_scalar_27 = torch.ops.aten.div.Scalar(expand_default_27, 784);  expand_default_27 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(mul_tensor_138, div_scalar_27);  mul_tensor_138 = div_scalar_27 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_85, convolution_default_35, primals_167, primals_165, primals_166, getitem_72, getitem_73, True, 1e-05, [True, True, True]);  add_tensor_85 = convolution_default_35 = primals_167 = primals_165 = primals_166 = getitem_72 = getitem_73 = None
        getitem_956 = native_batch_norm_backward_default_80[0]
        getitem_957 = native_batch_norm_backward_default_80[1]
        getitem_958 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_956, relu__default_26, primals_170, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_956 = primals_170 = None
        getitem_959 = convolution_backward_default_134[0]
        getitem_960 = convolution_backward_default_134[1]
        getitem_961 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_959, torch.float32);  getitem_959 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_210, to_dtype_399);  le_scalar_106 = new_zeros_default_210 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_34, primals_162, primals_160, primals_161, getitem_69, getitem_70, True, 1e-05, [True, True, True]);  to_dtype_401 = convolution_default_34 = primals_162 = primals_160 = primals_161 = getitem_69 = getitem_70 = None
        getitem_962 = native_batch_norm_backward_default_81[0]
        getitem_963 = native_batch_norm_backward_default_81[1]
        getitem_964 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_962, relu__default_25, primals_169, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_962 = primals_169 = None
        getitem_965 = convolution_backward_default_135[0]
        getitem_966 = convolution_backward_default_135[1]
        getitem_967 = convolution_backward_default_135[2];  convolution_backward_default_135 = None
        to_dtype_402 = torch.ops.aten.to.dtype(getitem_965, torch.float32);  getitem_965 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_211, to_dtype_402);  le_scalar_107 = new_zeros_default_211 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_404, convolution_default_33, primals_157, primals_155, primals_156, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_404 = convolution_default_33 = primals_157 = primals_155 = primals_156 = getitem_66 = getitem_67 = None
        getitem_968 = native_batch_norm_backward_default_82[0]
        getitem_969 = native_batch_norm_backward_default_82[1]
        getitem_970 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_968, relu__default_24, primals_168, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_968 = primals_168 = None
        getitem_971 = convolution_backward_default_136[0]
        getitem_972 = convolution_backward_default_136[1]
        getitem_973 = convolution_backward_default_136[2];  convolution_backward_default_136 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(to_dtype_392, getitem_971);  to_dtype_392 = getitem_971 = None
        to_dtype_405 = torch.ops.aten.to.dtype(add_tensor_86, torch.float32);  add_tensor_86 = None
        to_dtype_406 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_406, 0);  to_dtype_406 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(to_dtype_405, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_212, to_dtype_405);  le_scalar_108 = new_zeros_default_212 = to_dtype_405 = None
        to_dtype_407 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_407, getitem_62);  getitem_62 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_407, sigmoid_default_5)
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(mul_tensor_141, [2, 3], True);  mul_tensor_141 = None
        to_dtype_408 = torch.ops.aten.to.dtype(sum_dim_int_list_28, torch.float32);  sum_dim_int_list_28 = None
        to_dtype_409 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_27 = torch.ops.aten.rsub.Scalar(to_dtype_409, 1)
        mul_tensor_143 = torch.ops.aten.mul.Tensor(to_dtype_409, rsub_scalar_27);  to_dtype_409 = rsub_scalar_27 = None
        conj_physical_default_27 = torch.ops.aten.conj_physical.default(mul_tensor_143);  mul_tensor_143 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_408, conj_physical_default_27);  to_dtype_408 = conj_physical_default_27 = None
        to_dtype_410 = torch.ops.aten.to.dtype(mul_tensor_144, torch.float32);  mul_tensor_144 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(to_dtype_410, relu__default_23, primals_152, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_410 = primals_152 = None
        getitem_974 = convolution_backward_default_137[0]
        getitem_975 = convolution_backward_default_137[1]
        getitem_976 = convolution_backward_default_137[2];  convolution_backward_default_137 = None
        to_dtype_411 = torch.ops.aten.to.dtype(getitem_974, torch.float32);  getitem_974 = None
        to_dtype_412 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_412, 0);  to_dtype_412 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(to_dtype_411, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_213, to_dtype_411);  le_scalar_109 = new_zeros_default_213 = to_dtype_411 = None
        to_dtype_413 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(to_dtype_413, mean_dim_5, primals_150, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_413 = mean_dim_5 = primals_150 = None
        getitem_977 = convolution_backward_default_138[0]
        getitem_978 = convolution_backward_default_138[1]
        getitem_979 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        expand_default_28 = torch.ops.aten.expand.default(getitem_977, [128, 512, 28, 28]);  getitem_977 = None
        div_scalar_28 = torch.ops.aten.div.Scalar(expand_default_28, 784);  expand_default_28 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(mul_tensor_142, div_scalar_28);  mul_tensor_142 = div_scalar_28 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_87, convolution_default_30, primals_145, primals_143, primals_144, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  add_tensor_87 = convolution_default_30 = primals_145 = primals_143 = primals_144 = getitem_63 = getitem_64 = None
        getitem_980 = native_batch_norm_backward_default_83[0]
        getitem_981 = native_batch_norm_backward_default_83[1]
        getitem_982 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_980, relu__default_22, primals_148, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_980 = primals_148 = None
        getitem_983 = convolution_backward_default_139[0]
        getitem_984 = convolution_backward_default_139[1]
        getitem_985 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        to_dtype_414 = torch.ops.aten.to.dtype(getitem_983, torch.float32);  getitem_983 = None
        to_dtype_415 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_415, 0);  to_dtype_415 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(to_dtype_414, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_214, to_dtype_414);  le_scalar_110 = new_zeros_default_214 = to_dtype_414 = None
        to_dtype_416 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_416, convolution_default_29, primals_140, primals_138, primals_139, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  to_dtype_416 = convolution_default_29 = primals_140 = primals_138 = primals_139 = getitem_60 = getitem_61 = None
        getitem_986 = native_batch_norm_backward_default_84[0]
        getitem_987 = native_batch_norm_backward_default_84[1]
        getitem_988 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_986, relu__default_21, primals_147, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_986 = primals_147 = None
        getitem_989 = convolution_backward_default_140[0]
        getitem_990 = convolution_backward_default_140[1]
        getitem_991 = convolution_backward_default_140[2];  convolution_backward_default_140 = None
        to_dtype_417 = torch.ops.aten.to.dtype(getitem_989, torch.float32);  getitem_989 = None
        to_dtype_418 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_418, 0);  to_dtype_418 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(to_dtype_417, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_215, to_dtype_417);  le_scalar_111 = new_zeros_default_215 = to_dtype_417 = None
        to_dtype_419 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_419, convolution_default_28, primals_135, primals_133, primals_134, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_419 = convolution_default_28 = primals_135 = primals_133 = primals_134 = getitem_57 = getitem_58 = None
        getitem_992 = native_batch_norm_backward_default_85[0]
        getitem_993 = native_batch_norm_backward_default_85[1]
        getitem_994 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_992, relu__default_20, primals_146, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_992 = primals_146 = None
        getitem_995 = convolution_backward_default_141[0]
        getitem_996 = convolution_backward_default_141[1]
        getitem_997 = convolution_backward_default_141[2];  convolution_backward_default_141 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(to_dtype_407, getitem_995);  to_dtype_407 = getitem_995 = None
        to_dtype_420 = torch.ops.aten.to.dtype(add_tensor_88, torch.float32);  add_tensor_88 = None
        to_dtype_421 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_421, 0);  to_dtype_421 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(to_dtype_420, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_216, to_dtype_420);  le_scalar_112 = new_zeros_default_216 = to_dtype_420 = None
        to_dtype_422 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_422, getitem_53);  getitem_53 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(to_dtype_422, sigmoid_default_4)
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(mul_tensor_145, [2, 3], True);  mul_tensor_145 = None
        to_dtype_423 = torch.ops.aten.to.dtype(sum_dim_int_list_29, torch.float32);  sum_dim_int_list_29 = None
        to_dtype_424 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_28 = torch.ops.aten.rsub.Scalar(to_dtype_424, 1)
        mul_tensor_147 = torch.ops.aten.mul.Tensor(to_dtype_424, rsub_scalar_28);  to_dtype_424 = rsub_scalar_28 = None
        conj_physical_default_28 = torch.ops.aten.conj_physical.default(mul_tensor_147);  mul_tensor_147 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(to_dtype_423, conj_physical_default_28);  to_dtype_423 = conj_physical_default_28 = None
        to_dtype_425 = torch.ops.aten.to.dtype(mul_tensor_148, torch.float32);  mul_tensor_148 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(to_dtype_425, relu__default_19, primals_130, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_425 = primals_130 = None
        getitem_998 = convolution_backward_default_142[0]
        getitem_999 = convolution_backward_default_142[1]
        getitem_1000 = convolution_backward_default_142[2];  convolution_backward_default_142 = None
        to_dtype_426 = torch.ops.aten.to.dtype(getitem_998, torch.float32);  getitem_998 = None
        to_dtype_427 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_427, 0);  to_dtype_427 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(to_dtype_426, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_217, to_dtype_426);  le_scalar_113 = new_zeros_default_217 = to_dtype_426 = None
        to_dtype_428 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(to_dtype_428, mean_dim_4, primals_128, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_428 = mean_dim_4 = primals_128 = None
        getitem_1001 = convolution_backward_default_143[0]
        getitem_1002 = convolution_backward_default_143[1]
        getitem_1003 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        expand_default_29 = torch.ops.aten.expand.default(getitem_1001, [128, 512, 28, 28]);  getitem_1001 = None
        div_scalar_29 = torch.ops.aten.div.Scalar(expand_default_29, 784);  expand_default_29 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(mul_tensor_146, div_scalar_29);  mul_tensor_146 = div_scalar_29 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_89, convolution_default_25, primals_123, primals_121, primals_122, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  add_tensor_89 = convolution_default_25 = primals_123 = primals_121 = primals_122 = getitem_54 = getitem_55 = None
        getitem_1004 = native_batch_norm_backward_default_86[0]
        getitem_1005 = native_batch_norm_backward_default_86[1]
        getitem_1006 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1004, relu__default_18, primals_126, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1004 = primals_126 = None
        getitem_1007 = convolution_backward_default_144[0]
        getitem_1008 = convolution_backward_default_144[1]
        getitem_1009 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        to_dtype_429 = torch.ops.aten.to.dtype(getitem_1007, torch.float32);  getitem_1007 = None
        to_dtype_430 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_430, 0);  to_dtype_430 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(to_dtype_429, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_218, to_dtype_429);  le_scalar_114 = new_zeros_default_218 = to_dtype_429 = None
        to_dtype_431 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_431, convolution_default_24, primals_118, primals_116, primals_117, getitem_51, getitem_52, True, 1e-05, [True, True, True]);  to_dtype_431 = convolution_default_24 = primals_118 = primals_116 = primals_117 = getitem_51 = getitem_52 = None
        getitem_1010 = native_batch_norm_backward_default_87[0]
        getitem_1011 = native_batch_norm_backward_default_87[1]
        getitem_1012 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1010, relu__default_17, primals_125, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1010 = primals_125 = None
        getitem_1013 = convolution_backward_default_145[0]
        getitem_1014 = convolution_backward_default_145[1]
        getitem_1015 = convolution_backward_default_145[2];  convolution_backward_default_145 = None
        to_dtype_432 = torch.ops.aten.to.dtype(getitem_1013, torch.float32);  getitem_1013 = None
        to_dtype_433 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_433, 0);  to_dtype_433 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(to_dtype_432, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_219, to_dtype_432);  le_scalar_115 = new_zeros_default_219 = to_dtype_432 = None
        to_dtype_434 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_434, convolution_default_23, primals_113, primals_111, primals_112, getitem_48, getitem_49, True, 1e-05, [True, True, True]);  to_dtype_434 = convolution_default_23 = primals_113 = primals_111 = primals_112 = getitem_48 = getitem_49 = None
        getitem_1016 = native_batch_norm_backward_default_88[0]
        getitem_1017 = native_batch_norm_backward_default_88[1]
        getitem_1018 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1016, relu__default_16, primals_124, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1016 = primals_124 = None
        getitem_1019 = convolution_backward_default_146[0]
        getitem_1020 = convolution_backward_default_146[1]
        getitem_1021 = convolution_backward_default_146[2];  convolution_backward_default_146 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(to_dtype_422, getitem_1019);  to_dtype_422 = getitem_1019 = None
        to_dtype_435 = torch.ops.aten.to.dtype(add_tensor_90, torch.float32);  add_tensor_90 = None
        to_dtype_436 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_436, 0);  to_dtype_436 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(to_dtype_435, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_220, to_dtype_435);  le_scalar_116 = new_zeros_default_220 = to_dtype_435 = None
        to_dtype_437 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_437, getitem_41);  getitem_41 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(to_dtype_437, sigmoid_default_3)
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(mul_tensor_149, [2, 3], True);  mul_tensor_149 = None
        to_dtype_438 = torch.ops.aten.to.dtype(sum_dim_int_list_30, torch.float32);  sum_dim_int_list_30 = None
        to_dtype_439 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_29 = torch.ops.aten.rsub.Scalar(to_dtype_439, 1)
        mul_tensor_151 = torch.ops.aten.mul.Tensor(to_dtype_439, rsub_scalar_29);  to_dtype_439 = rsub_scalar_29 = None
        conj_physical_default_29 = torch.ops.aten.conj_physical.default(mul_tensor_151);  mul_tensor_151 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_438, conj_physical_default_29);  to_dtype_438 = conj_physical_default_29 = None
        to_dtype_440 = torch.ops.aten.to.dtype(mul_tensor_152, torch.float32);  mul_tensor_152 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(to_dtype_440, relu__default_15, primals_108, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_440 = primals_108 = None
        getitem_1022 = convolution_backward_default_147[0]
        getitem_1023 = convolution_backward_default_147[1]
        getitem_1024 = convolution_backward_default_147[2];  convolution_backward_default_147 = None
        to_dtype_441 = torch.ops.aten.to.dtype(getitem_1022, torch.float32);  getitem_1022 = None
        to_dtype_442 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_442, 0);  to_dtype_442 = None
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(to_dtype_441, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_221, to_dtype_441);  le_scalar_117 = new_zeros_default_221 = to_dtype_441 = None
        to_dtype_443 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(to_dtype_443, mean_dim_3, primals_106, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_443 = mean_dim_3 = primals_106 = None
        getitem_1025 = convolution_backward_default_148[0]
        getitem_1026 = convolution_backward_default_148[1]
        getitem_1027 = convolution_backward_default_148[2];  convolution_backward_default_148 = None
        expand_default_30 = torch.ops.aten.expand.default(getitem_1025, [128, 512, 28, 28]);  getitem_1025 = None
        div_scalar_30 = torch.ops.aten.div.Scalar(expand_default_30, 784);  expand_default_30 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(mul_tensor_150, div_scalar_30);  mul_tensor_150 = div_scalar_30 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_20, primals_104, primals_102, primals_103, getitem_45, getitem_46, True, 1e-05, [True, True, True]);  to_dtype_437 = convolution_default_20 = primals_104 = primals_102 = primals_103 = getitem_45 = getitem_46 = None
        getitem_1028 = native_batch_norm_backward_default_89[0]
        getitem_1029 = native_batch_norm_backward_default_89[1]
        getitem_1030 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(getitem_1028, relu__default_12, primals_99, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1028 = primals_99 = None
        getitem_1031 = convolution_backward_default_149[0]
        getitem_1032 = convolution_backward_default_149[1]
        getitem_1033 = convolution_backward_default_149[2];  convolution_backward_default_149 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_91, convolution_default_19, primals_95, primals_93, primals_94, getitem_42, getitem_43, True, 1e-05, [True, True, True]);  add_tensor_91 = convolution_default_19 = primals_95 = primals_93 = primals_94 = getitem_42 = getitem_43 = None
        getitem_1034 = native_batch_norm_backward_default_90[0]
        getitem_1035 = native_batch_norm_backward_default_90[1]
        getitem_1036 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1034, relu__default_14, primals_98, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1034 = primals_98 = None
        getitem_1037 = convolution_backward_default_150[0]
        getitem_1038 = convolution_backward_default_150[1]
        getitem_1039 = convolution_backward_default_150[2];  convolution_backward_default_150 = None
        to_dtype_444 = torch.ops.aten.to.dtype(getitem_1037, torch.float32);  getitem_1037 = None
        to_dtype_445 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_445, 0);  to_dtype_445 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(to_dtype_444, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_222, to_dtype_444);  le_scalar_118 = new_zeros_default_222 = to_dtype_444 = None
        to_dtype_446 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_446, convolution_default_18, primals_90, primals_88, primals_89, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  to_dtype_446 = convolution_default_18 = primals_90 = primals_88 = primals_89 = getitem_39 = getitem_40 = None
        getitem_1040 = native_batch_norm_backward_default_91[0]
        getitem_1041 = native_batch_norm_backward_default_91[1]
        getitem_1042 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(getitem_1040, relu__default_13, primals_97, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1040 = primals_97 = None
        getitem_1043 = convolution_backward_default_151[0]
        getitem_1044 = convolution_backward_default_151[1]
        getitem_1045 = convolution_backward_default_151[2];  convolution_backward_default_151 = None
        to_dtype_447 = torch.ops.aten.to.dtype(getitem_1043, torch.float32);  getitem_1043 = None
        to_dtype_448 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_448, 0);  to_dtype_448 = None
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(to_dtype_447, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_223, to_dtype_447);  le_scalar_119 = new_zeros_default_223 = to_dtype_447 = None
        to_dtype_449 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_449, convolution_default_17, primals_85, primals_83, primals_84, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  to_dtype_449 = convolution_default_17 = primals_85 = primals_83 = primals_84 = getitem_36 = getitem_37 = None
        getitem_1046 = native_batch_norm_backward_default_92[0]
        getitem_1047 = native_batch_norm_backward_default_92[1]
        getitem_1048 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(getitem_1046, relu__default_12, primals_96, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1046 = primals_96 = None
        getitem_1049 = convolution_backward_default_152[0]
        getitem_1050 = convolution_backward_default_152[1]
        getitem_1051 = convolution_backward_default_152[2];  convolution_backward_default_152 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_1031, getitem_1049);  getitem_1031 = getitem_1049 = None
        to_dtype_450 = torch.ops.aten.to.dtype(add_tensor_92, torch.float32);  add_tensor_92 = None
        to_dtype_451 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_451, 0);  to_dtype_451 = None
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(to_dtype_450, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_224, to_dtype_450);  le_scalar_120 = new_zeros_default_224 = to_dtype_450 = None
        to_dtype_452 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_452, getitem_32);  getitem_32 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(to_dtype_452, sigmoid_default_2)
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(mul_tensor_153, [2, 3], True);  mul_tensor_153 = None
        to_dtype_453 = torch.ops.aten.to.dtype(sum_dim_int_list_31, torch.float32);  sum_dim_int_list_31 = None
        to_dtype_454 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_30 = torch.ops.aten.rsub.Scalar(to_dtype_454, 1)
        mul_tensor_155 = torch.ops.aten.mul.Tensor(to_dtype_454, rsub_scalar_30);  to_dtype_454 = rsub_scalar_30 = None
        conj_physical_default_30 = torch.ops.aten.conj_physical.default(mul_tensor_155);  mul_tensor_155 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(to_dtype_453, conj_physical_default_30);  to_dtype_453 = conj_physical_default_30 = None
        to_dtype_455 = torch.ops.aten.to.dtype(mul_tensor_156, torch.float32);  mul_tensor_156 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(to_dtype_455, relu__default_11, primals_80, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_455 = primals_80 = None
        getitem_1052 = convolution_backward_default_153[0]
        getitem_1053 = convolution_backward_default_153[1]
        getitem_1054 = convolution_backward_default_153[2];  convolution_backward_default_153 = None
        to_dtype_456 = torch.ops.aten.to.dtype(getitem_1052, torch.float32);  getitem_1052 = None
        to_dtype_457 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_457, 0);  to_dtype_457 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(to_dtype_456, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_225, to_dtype_456);  le_scalar_121 = new_zeros_default_225 = to_dtype_456 = None
        to_dtype_458 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(to_dtype_458, mean_dim_2, primals_78, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_458 = mean_dim_2 = primals_78 = None
        getitem_1055 = convolution_backward_default_154[0]
        getitem_1056 = convolution_backward_default_154[1]
        getitem_1057 = convolution_backward_default_154[2];  convolution_backward_default_154 = None
        expand_default_31 = torch.ops.aten.expand.default(getitem_1055, [128, 256, 56, 56]);  getitem_1055 = None
        div_scalar_31 = torch.ops.aten.div.Scalar(expand_default_31, 3136);  expand_default_31 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(mul_tensor_154, div_scalar_31);  mul_tensor_154 = div_scalar_31 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_93, convolution_default_14, primals_73, primals_71, primals_72, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  add_tensor_93 = convolution_default_14 = primals_73 = primals_71 = primals_72 = getitem_33 = getitem_34 = None
        getitem_1058 = native_batch_norm_backward_default_93[0]
        getitem_1059 = native_batch_norm_backward_default_93[1]
        getitem_1060 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1058, relu__default_10, primals_76, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1058 = primals_76 = None
        getitem_1061 = convolution_backward_default_155[0]
        getitem_1062 = convolution_backward_default_155[1]
        getitem_1063 = convolution_backward_default_155[2];  convolution_backward_default_155 = None
        to_dtype_459 = torch.ops.aten.to.dtype(getitem_1061, torch.float32);  getitem_1061 = None
        to_dtype_460 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_460, 0);  to_dtype_460 = None
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(to_dtype_459, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_226, to_dtype_459);  le_scalar_122 = new_zeros_default_226 = to_dtype_459 = None
        to_dtype_461 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_461, convolution_default_13, primals_68, primals_66, primals_67, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  to_dtype_461 = convolution_default_13 = primals_68 = primals_66 = primals_67 = getitem_30 = getitem_31 = None
        getitem_1064 = native_batch_norm_backward_default_94[0]
        getitem_1065 = native_batch_norm_backward_default_94[1]
        getitem_1066 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(getitem_1064, relu__default_9, primals_75, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1064 = primals_75 = None
        getitem_1067 = convolution_backward_default_156[0]
        getitem_1068 = convolution_backward_default_156[1]
        getitem_1069 = convolution_backward_default_156[2];  convolution_backward_default_156 = None
        to_dtype_462 = torch.ops.aten.to.dtype(getitem_1067, torch.float32);  getitem_1067 = None
        to_dtype_463 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_463, 0);  to_dtype_463 = None
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(to_dtype_462, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_227, to_dtype_462);  le_scalar_123 = new_zeros_default_227 = to_dtype_462 = None
        to_dtype_464 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_464, convolution_default_12, primals_63, primals_61, primals_62, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_464 = convolution_default_12 = primals_63 = primals_61 = primals_62 = getitem_27 = getitem_28 = None
        getitem_1070 = native_batch_norm_backward_default_95[0]
        getitem_1071 = native_batch_norm_backward_default_95[1]
        getitem_1072 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(getitem_1070, relu__default_8, primals_74, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1070 = primals_74 = None
        getitem_1073 = convolution_backward_default_157[0]
        getitem_1074 = convolution_backward_default_157[1]
        getitem_1075 = convolution_backward_default_157[2];  convolution_backward_default_157 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(to_dtype_452, getitem_1073);  to_dtype_452 = getitem_1073 = None
        to_dtype_465 = torch.ops.aten.to.dtype(add_tensor_94, torch.float32);  add_tensor_94 = None
        to_dtype_466 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_466, 0);  to_dtype_466 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(to_dtype_465, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_228, to_dtype_465);  le_scalar_124 = new_zeros_default_228 = to_dtype_465 = None
        to_dtype_467 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_467, getitem_23);  getitem_23 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(to_dtype_467, sigmoid_default_1)
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(mul_tensor_157, [2, 3], True);  mul_tensor_157 = None
        to_dtype_468 = torch.ops.aten.to.dtype(sum_dim_int_list_32, torch.float32);  sum_dim_int_list_32 = None
        to_dtype_469 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_31 = torch.ops.aten.rsub.Scalar(to_dtype_469, 1)
        mul_tensor_159 = torch.ops.aten.mul.Tensor(to_dtype_469, rsub_scalar_31);  to_dtype_469 = rsub_scalar_31 = None
        conj_physical_default_31 = torch.ops.aten.conj_physical.default(mul_tensor_159);  mul_tensor_159 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(to_dtype_468, conj_physical_default_31);  to_dtype_468 = conj_physical_default_31 = None
        to_dtype_470 = torch.ops.aten.to.dtype(mul_tensor_160, torch.float32);  mul_tensor_160 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(to_dtype_470, relu__default_7, primals_58, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_470 = primals_58 = None
        getitem_1076 = convolution_backward_default_158[0]
        getitem_1077 = convolution_backward_default_158[1]
        getitem_1078 = convolution_backward_default_158[2];  convolution_backward_default_158 = None
        to_dtype_471 = torch.ops.aten.to.dtype(getitem_1076, torch.float32);  getitem_1076 = None
        to_dtype_472 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_472, 0);  to_dtype_472 = None
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(to_dtype_471, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_229, to_dtype_471);  le_scalar_125 = new_zeros_default_229 = to_dtype_471 = None
        to_dtype_473 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(to_dtype_473, mean_dim_1, primals_56, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_473 = mean_dim_1 = primals_56 = None
        getitem_1079 = convolution_backward_default_159[0]
        getitem_1080 = convolution_backward_default_159[1]
        getitem_1081 = convolution_backward_default_159[2];  convolution_backward_default_159 = None
        expand_default_32 = torch.ops.aten.expand.default(getitem_1079, [128, 256, 56, 56]);  getitem_1079 = None
        div_scalar_32 = torch.ops.aten.div.Scalar(expand_default_32, 3136);  expand_default_32 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(mul_tensor_158, div_scalar_32);  mul_tensor_158 = div_scalar_32 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_95, convolution_default_9, primals_51, primals_49, primals_50, getitem_24, getitem_25, True, 1e-05, [True, True, True]);  add_tensor_95 = convolution_default_9 = primals_51 = primals_49 = primals_50 = getitem_24 = getitem_25 = None
        getitem_1082 = native_batch_norm_backward_default_96[0]
        getitem_1083 = native_batch_norm_backward_default_96[1]
        getitem_1084 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1082, relu__default_6, primals_54, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1082 = primals_54 = None
        getitem_1085 = convolution_backward_default_160[0]
        getitem_1086 = convolution_backward_default_160[1]
        getitem_1087 = convolution_backward_default_160[2];  convolution_backward_default_160 = None
        to_dtype_474 = torch.ops.aten.to.dtype(getitem_1085, torch.float32);  getitem_1085 = None
        to_dtype_475 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_475, 0);  to_dtype_475 = None
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(to_dtype_474, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_230, to_dtype_474);  le_scalar_126 = new_zeros_default_230 = to_dtype_474 = None
        to_dtype_476 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_476, convolution_default_8, primals_46, primals_44, primals_45, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  to_dtype_476 = convolution_default_8 = primals_46 = primals_44 = primals_45 = getitem_21 = getitem_22 = None
        getitem_1088 = native_batch_norm_backward_default_97[0]
        getitem_1089 = native_batch_norm_backward_default_97[1]
        getitem_1090 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(getitem_1088, relu__default_5, primals_53, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1088 = primals_53 = None
        getitem_1091 = convolution_backward_default_161[0]
        getitem_1092 = convolution_backward_default_161[1]
        getitem_1093 = convolution_backward_default_161[2];  convolution_backward_default_161 = None
        to_dtype_477 = torch.ops.aten.to.dtype(getitem_1091, torch.float32);  getitem_1091 = None
        to_dtype_478 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_478, 0);  to_dtype_478 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(to_dtype_477, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_231, to_dtype_477);  le_scalar_127 = new_zeros_default_231 = to_dtype_477 = None
        to_dtype_479 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_479, convolution_default_7, primals_41, primals_39, primals_40, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  to_dtype_479 = convolution_default_7 = primals_41 = primals_39 = primals_40 = getitem_18 = getitem_19 = None
        getitem_1094 = native_batch_norm_backward_default_98[0]
        getitem_1095 = native_batch_norm_backward_default_98[1]
        getitem_1096 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(getitem_1094, relu__default_4, primals_52, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1094 = primals_52 = None
        getitem_1097 = convolution_backward_default_162[0]
        getitem_1098 = convolution_backward_default_162[1]
        getitem_1099 = convolution_backward_default_162[2];  convolution_backward_default_162 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(to_dtype_467, getitem_1097);  to_dtype_467 = getitem_1097 = None
        to_dtype_480 = torch.ops.aten.to.dtype(add_tensor_96, torch.float32);  add_tensor_96 = None
        to_dtype_481 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_481, 0);  to_dtype_481 = None
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(to_dtype_480, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_232, to_dtype_480);  le_scalar_128 = new_zeros_default_232 = to_dtype_480 = None
        to_dtype_482 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(to_dtype_482, getitem_11);  getitem_11 = None
        mul_tensor_162 = torch.ops.aten.mul.Tensor(to_dtype_482, sigmoid_default)
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(mul_tensor_161, [2, 3], True);  mul_tensor_161 = None
        to_dtype_483 = torch.ops.aten.to.dtype(sum_dim_int_list_33, torch.float32);  sum_dim_int_list_33 = None
        to_dtype_484 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_32 = torch.ops.aten.rsub.Scalar(to_dtype_484, 1)
        mul_tensor_163 = torch.ops.aten.mul.Tensor(to_dtype_484, rsub_scalar_32);  to_dtype_484 = rsub_scalar_32 = None
        conj_physical_default_32 = torch.ops.aten.conj_physical.default(mul_tensor_163);  mul_tensor_163 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(to_dtype_483, conj_physical_default_32);  to_dtype_483 = conj_physical_default_32 = None
        to_dtype_485 = torch.ops.aten.to.dtype(mul_tensor_164, torch.float32);  mul_tensor_164 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(to_dtype_485, relu__default_3, primals_36, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_485 = primals_36 = None
        getitem_1100 = convolution_backward_default_163[0]
        getitem_1101 = convolution_backward_default_163[1]
        getitem_1102 = convolution_backward_default_163[2];  convolution_backward_default_163 = None
        to_dtype_486 = torch.ops.aten.to.dtype(getitem_1100, torch.float32);  getitem_1100 = None
        to_dtype_487 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_487, 0);  to_dtype_487 = None
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(to_dtype_486, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_233, to_dtype_486);  le_scalar_129 = new_zeros_default_233 = to_dtype_486 = None
        to_dtype_488 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(to_dtype_488, mean_dim, primals_34, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_488 = mean_dim = primals_34 = None
        getitem_1103 = convolution_backward_default_164[0]
        getitem_1104 = convolution_backward_default_164[1]
        getitem_1105 = convolution_backward_default_164[2];  convolution_backward_default_164 = None
        expand_default_33 = torch.ops.aten.expand.default(getitem_1103, [128, 256, 56, 56]);  getitem_1103 = None
        div_scalar_33 = torch.ops.aten.div.Scalar(expand_default_33, 3136);  expand_default_33 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mul_tensor_162, div_scalar_33);  mul_tensor_162 = div_scalar_33 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_482, convolution_default_4, primals_32, primals_30, primals_31, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  to_dtype_482 = convolution_default_4 = primals_32 = primals_30 = primals_31 = getitem_15 = getitem_16 = None
        getitem_1106 = native_batch_norm_backward_default_99[0]
        getitem_1107 = native_batch_norm_backward_default_99[1]
        getitem_1108 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(getitem_1106, getitem_3, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1106 = primals_27 = None
        getitem_1109 = convolution_backward_default_165[0]
        getitem_1110 = convolution_backward_default_165[1]
        getitem_1111 = convolution_backward_default_165[2];  convolution_backward_default_165 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_97, convolution_default_3, primals_23, primals_21, primals_22, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  add_tensor_97 = convolution_default_3 = primals_23 = primals_21 = primals_22 = getitem_12 = getitem_13 = None
        getitem_1112 = native_batch_norm_backward_default_100[0]
        getitem_1113 = native_batch_norm_backward_default_100[1]
        getitem_1114 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(getitem_1112, relu__default_2, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1112 = primals_26 = None
        getitem_1115 = convolution_backward_default_166[0]
        getitem_1116 = convolution_backward_default_166[1]
        getitem_1117 = convolution_backward_default_166[2];  convolution_backward_default_166 = None
        to_dtype_489 = torch.ops.aten.to.dtype(getitem_1115, torch.float32);  getitem_1115 = None
        to_dtype_490 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_490, 0);  to_dtype_490 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(to_dtype_489, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_234, to_dtype_489);  le_scalar_130 = new_zeros_default_234 = to_dtype_489 = None
        to_dtype_491 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_491, convolution_default_2, primals_18, primals_16, primals_17, getitem_9, getitem_10, True, 1e-05, [True, True, True]);  to_dtype_491 = convolution_default_2 = primals_18 = primals_16 = primals_17 = getitem_9 = getitem_10 = None
        getitem_1118 = native_batch_norm_backward_default_101[0]
        getitem_1119 = native_batch_norm_backward_default_101[1]
        getitem_1120 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(getitem_1118, relu__default_1, primals_25, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1118 = primals_25 = None
        getitem_1121 = convolution_backward_default_167[0]
        getitem_1122 = convolution_backward_default_167[1]
        getitem_1123 = convolution_backward_default_167[2];  convolution_backward_default_167 = None
        to_dtype_492 = torch.ops.aten.to.dtype(getitem_1121, torch.float32);  getitem_1121 = None
        to_dtype_493 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_493, 0);  to_dtype_493 = None
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(to_dtype_492, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_235, to_dtype_492);  le_scalar_131 = new_zeros_default_235 = to_dtype_492 = None
        to_dtype_494 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_494, convolution_default_1, primals_13, primals_11, primals_12, getitem_6, getitem_7, True, 1e-05, [True, True, True]);  to_dtype_494 = convolution_default_1 = primals_13 = primals_11 = primals_12 = getitem_6 = getitem_7 = None
        getitem_1124 = native_batch_norm_backward_default_102[0]
        getitem_1125 = native_batch_norm_backward_default_102[1]
        getitem_1126 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1124, getitem_3, primals_24, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1124 = getitem_3 = primals_24 = None
        getitem_1127 = convolution_backward_default_168[0]
        getitem_1128 = convolution_backward_default_168[1]
        getitem_1129 = convolution_backward_default_168[2];  convolution_backward_default_168 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(getitem_1109, getitem_1127);  getitem_1109 = getitem_1127 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_98, relu__default, [3, 3], [2, 2], [0, 0], [1, 1], True, getitem_4);  add_tensor_98 = getitem_4 = None
        to_dtype_495 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_496 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_496, 0);  to_dtype_496 = None
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(to_dtype_495, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_236, to_dtype_495);  le_scalar_132 = new_zeros_default_236 = to_dtype_495 = None
        to_dtype_497 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_497, convolution_default, primals_8, primals_6, primals_7, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_497 = convolution_default = primals_8 = primals_6 = primals_7 = getitem_1 = getitem_2 = None
        getitem_1130 = native_batch_norm_backward_default_103[0]
        getitem_1131 = native_batch_norm_backward_default_103[1]
        getitem_1132 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1130, primals_759, primals_3, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1130 = primals_759 = primals_3 = None
        getitem_1133 = convolution_backward_default_169[0]
        getitem_1134 = convolution_backward_default_169[1]
        getitem_1135 = convolution_backward_default_169[2];  convolution_backward_default_169 = None
        return [addmm_default, view_default_1, t_default_4, getitem_1134, getitem_1132, None, None, None, getitem_1131, getitem_1126, None, None, None, getitem_1125, getitem_1120, None, None, None, getitem_1119, getitem_1114, None, None, None, getitem_1113, getitem_1128, getitem_1122, getitem_1116, getitem_1110, getitem_1108, None, None, None, getitem_1107, getitem_1105, getitem_1104, getitem_1102, getitem_1101, getitem_1096, None, None, None, getitem_1095, getitem_1090, None, None, None, getitem_1089, getitem_1084, None, None, None, getitem_1083, getitem_1098, getitem_1092, getitem_1086, getitem_1081, getitem_1080, getitem_1078, getitem_1077, getitem_1072, None, None, None, getitem_1071, getitem_1066, None, None, None, getitem_1065, getitem_1060, None, None, None, getitem_1059, getitem_1074, getitem_1068, getitem_1062, getitem_1057, getitem_1056, getitem_1054, getitem_1053, getitem_1048, None, None, None, getitem_1047, getitem_1042, None, None, None, getitem_1041, getitem_1036, None, None, None, getitem_1035, getitem_1050, getitem_1044, getitem_1038, getitem_1032, getitem_1030, None, None, None, getitem_1029, getitem_1027, getitem_1026, getitem_1024, getitem_1023, getitem_1018, None, None, None, getitem_1017, getitem_1012, None, None, None, getitem_1011, getitem_1006, None, None, None, getitem_1005, getitem_1020, getitem_1014, getitem_1008, getitem_1003, getitem_1002, getitem_1000, getitem_999, getitem_994, None, None, None, getitem_993, getitem_988, None, None, None, getitem_987, getitem_982, None, None, None, getitem_981, getitem_996, getitem_990, getitem_984, getitem_979, getitem_978, getitem_976, getitem_975, getitem_970, None, None, None, getitem_969, getitem_964, None, None, None, getitem_963, getitem_958, None, None, None, getitem_957, getitem_972, getitem_966, getitem_960, getitem_955, getitem_954, getitem_952, getitem_951, getitem_946, None, None, None, getitem_945, getitem_940, None, None, None, getitem_939, getitem_934, None, None, None, getitem_933, getitem_948, getitem_942, getitem_936, getitem_930, getitem_928, None, None, None, getitem_927, getitem_925, getitem_924, getitem_922, getitem_921, getitem_700, None, None, None, getitem_699, getitem_694, None, None, None, getitem_693, getitem_688, None, None, None, getitem_687, getitem_702, getitem_696, getitem_690, getitem_685, getitem_684, getitem_682, getitem_681, getitem_676, None, None, None, getitem_675, getitem_670, None, None, None, getitem_669, getitem_664, None, None, None, getitem_663, getitem_678, getitem_672, getitem_666, getitem_661, getitem_660, getitem_658, getitem_657, getitem_652, None, None, None, getitem_651, getitem_646, None, None, None, getitem_645, getitem_640, None, None, None, getitem_639, getitem_654, getitem_648, getitem_642, getitem_637, getitem_636, getitem_634, getitem_633, getitem_628, None, None, None, getitem_627, getitem_622, None, None, None, getitem_621, getitem_616, None, None, None, getitem_615, getitem_630, getitem_624, getitem_618, getitem_613, getitem_612, getitem_610, getitem_609, getitem_604, None, None, None, getitem_603, getitem_598, None, None, None, getitem_597, getitem_592, None, None, None, getitem_591, getitem_606, getitem_600, getitem_594, getitem_589, getitem_588, getitem_586, getitem_585, getitem_580, None, None, None, getitem_579, getitem_574, None, None, None, getitem_573, getitem_568, None, None, None, getitem_567, getitem_582, getitem_576, getitem_570, getitem_565, getitem_564, getitem_562, getitem_561, getitem_556, None, None, None, getitem_555, getitem_550, None, None, None, getitem_549, getitem_544, None, None, None, getitem_543, getitem_558, getitem_552, getitem_546, getitem_541, getitem_540, getitem_538, getitem_537, getitem_532, None, None, None, getitem_531, getitem_526, None, None, None, getitem_525, getitem_520, None, None, None, getitem_519, getitem_534, getitem_528, getitem_522, getitem_517, getitem_516, getitem_514, getitem_513, getitem_508, None, None, None, getitem_507, getitem_502, None, None, None, getitem_501, getitem_496, None, None, None, getitem_495, getitem_510, getitem_504, getitem_498, getitem_493, getitem_492, getitem_490, getitem_489, getitem_484, None, None, None, getitem_483, getitem_478, None, None, None, getitem_477, getitem_472, None, None, None, getitem_471, getitem_486, getitem_480, getitem_474, getitem_469, getitem_468, getitem_466, getitem_465, getitem_916, None, None, None, getitem_915, getitem_910, None, None, None, getitem_909, getitem_904, None, None, None, getitem_903, getitem_918, getitem_912, getitem_906, getitem_901, getitem_900, getitem_898, getitem_897, getitem_460, None, None, None, getitem_459, getitem_454, None, None, None, getitem_453, getitem_448, None, None, None, getitem_447, getitem_462, getitem_456, getitem_450, getitem_445, getitem_444, getitem_442, getitem_441, getitem_436, None, None, None, getitem_435, getitem_430, None, None, None, getitem_429, getitem_424, None, None, None, getitem_423, getitem_438, getitem_432, getitem_426, getitem_421, getitem_420, getitem_418, getitem_417, getitem_412, None, None, None, getitem_411, getitem_406, None, None, None, getitem_405, getitem_400, None, None, None, getitem_399, getitem_414, getitem_408, getitem_402, getitem_397, getitem_396, getitem_394, getitem_393, getitem_892, None, None, None, getitem_891, getitem_886, None, None, None, getitem_885, getitem_880, None, None, None, getitem_879, getitem_894, getitem_888, getitem_882, getitem_877, getitem_876, getitem_874, getitem_873, getitem_868, None, None, None, getitem_867, getitem_862, None, None, None, getitem_861, getitem_856, None, None, None, getitem_855, getitem_870, getitem_864, getitem_858, getitem_853, getitem_852, getitem_850, getitem_849, getitem_844, None, None, None, getitem_843, getitem_838, None, None, None, getitem_837, getitem_832, None, None, None, getitem_831, getitem_846, getitem_840, getitem_834, getitem_829, getitem_828, getitem_826, getitem_825, getitem_820, None, None, None, getitem_819, getitem_814, None, None, None, getitem_813, getitem_808, None, None, None, getitem_807, getitem_822, getitem_816, getitem_810, getitem_805, getitem_804, getitem_802, getitem_801, getitem_796, None, None, None, getitem_795, getitem_790, None, None, None, getitem_789, getitem_784, None, None, None, getitem_783, getitem_798, getitem_792, getitem_786, getitem_781, getitem_780, getitem_778, getitem_777, getitem_772, None, None, None, getitem_771, getitem_766, None, None, None, getitem_765, getitem_760, None, None, None, getitem_759, getitem_774, getitem_768, getitem_762, getitem_757, getitem_756, getitem_754, getitem_753, getitem_748, None, None, None, getitem_747, getitem_742, None, None, None, getitem_741, getitem_736, None, None, None, getitem_735, getitem_750, getitem_744, getitem_738, getitem_733, getitem_732, getitem_730, getitem_729, getitem_724, None, None, None, getitem_723, getitem_718, None, None, None, getitem_717, getitem_712, None, None, None, getitem_711, getitem_726, getitem_720, getitem_714, getitem_709, getitem_708, getitem_706, getitem_705, getitem_388, None, None, None, getitem_387, getitem_382, None, None, None, getitem_381, getitem_376, None, None, None, getitem_375, getitem_390, getitem_384, getitem_378, getitem_372, getitem_370, None, None, None, getitem_369, getitem_367, getitem_366, getitem_364, getitem_363, getitem_358, None, None, None, getitem_357, getitem_352, None, None, None, getitem_351, getitem_346, None, None, None, getitem_345, getitem_360, getitem_354, getitem_348, getitem_343, getitem_342, getitem_340, getitem_339, getitem_334, None, None, None, getitem_333, getitem_328, None, None, None, getitem_327, getitem_322, None, None, None, getitem_321, getitem_336, getitem_330, getitem_324, getitem_319, getitem_318, getitem_316, getitem_315, None]
        
