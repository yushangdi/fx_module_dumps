
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/ens_adv_inception_resnet_v2/ens_adv_inception_resnet_v2_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, primals_1024, primals_1025, primals_1026, primals_1027, primals_1028, primals_1029, primals_1030, primals_1031, primals_1032, primals_1033, primals_1034, primals_1035, primals_1036, primals_1037, primals_1038, primals_1039, primals_1040, primals_1041, primals_1042, primals_1043, primals_1044, primals_1045, primals_1046, primals_1047, primals_1048, primals_1049, primals_1050, primals_1051, primals_1052, primals_1053, primals_1054, primals_1055, primals_1056, primals_1057, primals_1058, primals_1059, primals_1060, primals_1061, primals_1062, primals_1063, primals_1064, primals_1065, primals_1066, primals_1067, primals_1068, primals_1069, primals_1070, primals_1071, primals_1072, primals_1073, primals_1074, primals_1075, primals_1076, primals_1077, primals_1078, primals_1079, primals_1080, primals_1081, primals_1082, primals_1083, primals_1084, primals_1085, primals_1086, primals_1087, primals_1088, primals_1089, primals_1090, primals_1091, primals_1092, primals_1093, primals_1094, primals_1095, primals_1096, primals_1097, primals_1098, primals_1099, primals_1100, primals_1101, primals_1102, primals_1103, primals_1104, primals_1105, primals_1106, primals_1107, primals_1108, primals_1109, primals_1110, primals_1111, primals_1112, primals_1113, primals_1114, primals_1115, primals_1116, primals_1117, primals_1118, primals_1119, primals_1120, primals_1121, primals_1122, primals_1123, primals_1124, primals_1125, primals_1126, primals_1127, primals_1128, primals_1129, primals_1130, primals_1131, primals_1132, primals_1133, primals_1134, primals_1135, primals_1136, primals_1137, primals_1138, primals_1139, primals_1140, primals_1141, primals_1142, primals_1143, primals_1144, primals_1145, primals_1146, primals_1147, primals_1148, primals_1149, primals_1150, primals_1151, primals_1152, primals_1153, primals_1154, primals_1155, primals_1156, primals_1157, primals_1158, primals_1159, primals_1160, primals_1161, primals_1162, primals_1163, primals_1164, primals_1165, primals_1166, primals_1167, primals_1168, primals_1169, primals_1170, primals_1171, primals_1172, primals_1173, primals_1174, primals_1175, primals_1176, primals_1177, primals_1178, primals_1179, primals_1180, primals_1181, primals_1182, primals_1183, primals_1184, primals_1185, primals_1186, primals_1187, primals_1188, primals_1189, primals_1190, primals_1191, primals_1192, primals_1193, primals_1194, primals_1195, primals_1196, primals_1197, primals_1198, primals_1199, primals_1200, primals_1201, primals_1202, primals_1203, primals_1204, primals_1205, primals_1206, primals_1207, primals_1208, primals_1209, primals_1210, primals_1211, primals_1212, primals_1213, primals_1214, primals_1215, primals_1216, primals_1217, primals_1218, primals_1219, primals_1220, primals_1221, primals_1222, primals_1223, primals_1224, primals_1225, primals_1226, primals_1227, primals_1228, primals_1229, primals_1230, primals_1231, primals_1232, primals_1233, primals_1234, primals_1235, primals_1236, primals_1237, primals_1238, primals_1239, primals_1240, primals_1241, primals_1242, primals_1243, primals_1244, primals_1245, primals_1246, primals_1247, primals_1248, primals_1249, primals_1250, primals_1251, primals_1252, primals_1253, primals_1254, primals_1255, primals_1256, primals_1257, primals_1258, primals_1259, primals_1260, primals_1261, primals_1262, primals_1263, primals_1264, primals_1265, primals_1266, primals_1267, primals_1268, primals_1269, primals_1270, primals_1271, primals_1272, primals_1273, primals_1274, primals_1275, primals_1276, primals_1277, primals_1278, primals_1279, primals_1280, primals_1281, primals_1282, primals_1283, primals_1284, primals_1285, primals_1286, primals_1287, primals_1288, primals_1289, primals_1290, primals_1291, primals_1292, primals_1293, primals_1294, primals_1295, primals_1296, primals_1297, primals_1298, primals_1299, primals_1300, primals_1301, primals_1302, primals_1303, primals_1304, primals_1305, primals_1306, primals_1307):
        convolution_default = torch.ops.aten.convolution.default(primals_1307, primals_34, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_33, primals_29, primals_31, primals_32, True, 0.1, 0.001);  primals_29 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu_default = torch.ops.aten.relu.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu_default, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_39, primals_35, primals_37, primals_38, True, 0.1, 0.001);  primals_35 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu_default_1 = torch.ops.aten.relu.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu_default_1, primals_46, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_45, primals_41, primals_43, primals_44, True, 0.1, 0.001);  primals_41 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu_default_2 = torch.ops.aten.relu.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu_default_2, [3, 3], [2, 2])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_52, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_51, primals_47, primals_49, primals_50, True, 0.1, 0.001);  primals_47 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu_default_3 = torch.ops.aten.relu.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu_default_3, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_57, primals_53, primals_55, primals_56, True, 0.1, 0.001);  primals_53 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu_default_4 = torch.ops.aten.relu.default(getitem_14);  getitem_14 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(relu_default_4, [3, 3], [2, 2])
        getitem_17 = max_pool2d_with_indices_default_1[0]
        getitem_18 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_17, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_69, primals_65, primals_67, primals_68, True, 0.1, 0.001);  primals_65 = None
        getitem_19 = native_batch_norm_default_5[0]
        getitem_20 = native_batch_norm_default_5[1]
        getitem_21 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu_default_5 = torch.ops.aten.relu.default(getitem_19);  getitem_19 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_17, primals_76, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_75, primals_71, primals_73, primals_74, True, 0.1, 0.001);  primals_71 = None
        getitem_22 = native_batch_norm_default_6[0]
        getitem_23 = native_batch_norm_default_6[1]
        getitem_24 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu_default_6 = torch.ops.aten.relu.default(getitem_22);  getitem_22 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu_default_6, primals_82, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_81, primals_77, primals_79, primals_80, True, 0.1, 0.001);  primals_77 = None
        getitem_25 = native_batch_norm_default_7[0]
        getitem_26 = native_batch_norm_default_7[1]
        getitem_27 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu_default_7 = torch.ops.aten.relu.default(getitem_25);  getitem_25 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_17, primals_88, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_87, primals_83, primals_85, primals_86, True, 0.1, 0.001);  primals_83 = None
        getitem_28 = native_batch_norm_default_8[0]
        getitem_29 = native_batch_norm_default_8[1]
        getitem_30 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu_default_8 = torch.ops.aten.relu.default(getitem_28);  getitem_28 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu_default_8, primals_94, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_93, primals_89, primals_91, primals_92, True, 0.1, 0.001);  primals_89 = None
        getitem_31 = native_batch_norm_default_9[0]
        getitem_32 = native_batch_norm_default_9[1]
        getitem_33 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu_default_9 = torch.ops.aten.relu.default(getitem_31);  getitem_31 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu_default_9, primals_100, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_99, primals_95, primals_97, primals_98, True, 0.1, 0.001);  primals_95 = None
        getitem_34 = native_batch_norm_default_10[0]
        getitem_35 = native_batch_norm_default_10[1]
        getitem_36 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu_default_10 = torch.ops.aten.relu.default(getitem_34);  getitem_34 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(getitem_17, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_11 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_106, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_105, primals_101, primals_103, primals_104, True, 0.1, 0.001);  primals_101 = None
        getitem_37 = native_batch_norm_default_11[0]
        getitem_38 = native_batch_norm_default_11[1]
        getitem_39 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu_default_11 = torch.ops.aten.relu.default(getitem_37);  getitem_37 = None
        cat_default = torch.ops.aten.cat.default([relu_default_5, relu_default_7, relu_default_10, relu_default_11], 1)
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default, primals_178, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_177, primals_173, primals_175, primals_176, True, 0.1, 0.001);  primals_173 = None
        getitem_40 = native_batch_norm_default_12[0]
        getitem_41 = native_batch_norm_default_12[1]
        getitem_42 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu_default_12 = torch.ops.aten.relu.default(getitem_40);  getitem_40 = None
        convolution_default_13 = torch.ops.aten.convolution.default(cat_default, primals_184, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_183, primals_179, primals_181, primals_182, True, 0.1, 0.001);  primals_179 = None
        getitem_43 = native_batch_norm_default_13[0]
        getitem_44 = native_batch_norm_default_13[1]
        getitem_45 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu_default_13 = torch.ops.aten.relu.default(getitem_43);  getitem_43 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu_default_13, primals_190, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_189, primals_185, primals_187, primals_188, True, 0.1, 0.001);  primals_185 = None
        getitem_46 = native_batch_norm_default_14[0]
        getitem_47 = native_batch_norm_default_14[1]
        getitem_48 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu_default_14 = torch.ops.aten.relu.default(getitem_46);  getitem_46 = None
        convolution_default_15 = torch.ops.aten.convolution.default(cat_default, primals_196, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_195, primals_191, primals_193, primals_194, True, 0.1, 0.001);  primals_191 = None
        getitem_49 = native_batch_norm_default_15[0]
        getitem_50 = native_batch_norm_default_15[1]
        getitem_51 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu_default_15 = torch.ops.aten.relu.default(getitem_49);  getitem_49 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu_default_15, primals_202, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_201, primals_197, primals_199, primals_200, True, 0.1, 0.001);  primals_197 = None
        getitem_52 = native_batch_norm_default_16[0]
        getitem_53 = native_batch_norm_default_16[1]
        getitem_54 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu_default_16 = torch.ops.aten.relu.default(getitem_52);  getitem_52 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu_default_16, primals_208, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_207, primals_203, primals_205, primals_206, True, 0.1, 0.001);  primals_203 = None
        getitem_55 = native_batch_norm_default_17[0]
        getitem_56 = native_batch_norm_default_17[1]
        getitem_57 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu_default_17 = torch.ops.aten.relu.default(getitem_55);  getitem_55 = None
        cat_default_1 = torch.ops.aten.cat.default([relu_default_12, relu_default_14, relu_default_17], 1)
        convolution_default_18 = torch.ops.aten.convolution.default(cat_default_1, primals_210, primals_209, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_209 = None
        mul_tensor = torch.ops.aten.mul.Tensor(convolution_default_18, 0.17);  convolution_default_18 = None
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor, cat_default);  mul_tensor = None
        relu_default_18 = torch.ops.aten.relu.default(add_tensor);  add_tensor = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu_default_18, primals_736, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_735, primals_731, primals_733, primals_734, True, 0.1, 0.001);  primals_731 = None
        getitem_58 = native_batch_norm_default_18[0]
        getitem_59 = native_batch_norm_default_18[1]
        getitem_60 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu_default_19 = torch.ops.aten.relu.default(getitem_58);  getitem_58 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu_default_18, primals_742, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_741, primals_737, primals_739, primals_740, True, 0.1, 0.001);  primals_737 = None
        getitem_61 = native_batch_norm_default_19[0]
        getitem_62 = native_batch_norm_default_19[1]
        getitem_63 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu_default_20 = torch.ops.aten.relu.default(getitem_61);  getitem_61 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu_default_20, primals_748, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_747, primals_743, primals_745, primals_746, True, 0.1, 0.001);  primals_743 = None
        getitem_64 = native_batch_norm_default_20[0]
        getitem_65 = native_batch_norm_default_20[1]
        getitem_66 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu_default_21 = torch.ops.aten.relu.default(getitem_64);  getitem_64 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu_default_18, primals_754, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_753, primals_749, primals_751, primals_752, True, 0.1, 0.001);  primals_749 = None
        getitem_67 = native_batch_norm_default_21[0]
        getitem_68 = native_batch_norm_default_21[1]
        getitem_69 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu_default_22 = torch.ops.aten.relu.default(getitem_67);  getitem_67 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu_default_22, primals_760, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_759, primals_755, primals_757, primals_758, True, 0.1, 0.001);  primals_755 = None
        getitem_70 = native_batch_norm_default_22[0]
        getitem_71 = native_batch_norm_default_22[1]
        getitem_72 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu_default_23 = torch.ops.aten.relu.default(getitem_70);  getitem_70 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu_default_23, primals_766, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_765, primals_761, primals_763, primals_764, True, 0.1, 0.001);  primals_761 = None
        getitem_73 = native_batch_norm_default_23[0]
        getitem_74 = native_batch_norm_default_23[1]
        getitem_75 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu_default_24 = torch.ops.aten.relu.default(getitem_73);  getitem_73 = None
        cat_default_2 = torch.ops.aten.cat.default([relu_default_19, relu_default_21, relu_default_24], 1)
        convolution_default_25 = torch.ops.aten.convolution.default(cat_default_2, primals_768, primals_767, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_767 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(convolution_default_25, 0.17);  convolution_default_25 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(mul_tensor_1, relu_default_18);  mul_tensor_1 = None
        relu_default_25 = torch.ops.aten.relu.default(add_tensor_1);  add_tensor_1 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu_default_25, primals_1008, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_1007, primals_1003, primals_1005, primals_1006, True, 0.1, 0.001);  primals_1003 = None
        getitem_76 = native_batch_norm_default_24[0]
        getitem_77 = native_batch_norm_default_24[1]
        getitem_78 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu_default_26 = torch.ops.aten.relu.default(getitem_76);  getitem_76 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu_default_25, primals_1014, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_1013, primals_1009, primals_1011, primals_1012, True, 0.1, 0.001);  primals_1009 = None
        getitem_79 = native_batch_norm_default_25[0]
        getitem_80 = native_batch_norm_default_25[1]
        getitem_81 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu_default_27 = torch.ops.aten.relu.default(getitem_79);  getitem_79 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu_default_27, primals_1020, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_1019, primals_1015, primals_1017, primals_1018, True, 0.1, 0.001);  primals_1015 = None
        getitem_82 = native_batch_norm_default_26[0]
        getitem_83 = native_batch_norm_default_26[1]
        getitem_84 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu_default_28 = torch.ops.aten.relu.default(getitem_82);  getitem_82 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu_default_25, primals_1026, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_1025, primals_1021, primals_1023, primals_1024, True, 0.1, 0.001);  primals_1021 = None
        getitem_85 = native_batch_norm_default_27[0]
        getitem_86 = native_batch_norm_default_27[1]
        getitem_87 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu_default_29 = torch.ops.aten.relu.default(getitem_85);  getitem_85 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu_default_29, primals_1032, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_1031, primals_1027, primals_1029, primals_1030, True, 0.1, 0.001);  primals_1027 = None
        getitem_88 = native_batch_norm_default_28[0]
        getitem_89 = native_batch_norm_default_28[1]
        getitem_90 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu_default_30 = torch.ops.aten.relu.default(getitem_88);  getitem_88 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu_default_30, primals_1038, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_1037, primals_1033, primals_1035, primals_1036, True, 0.1, 0.001);  primals_1033 = None
        getitem_91 = native_batch_norm_default_29[0]
        getitem_92 = native_batch_norm_default_29[1]
        getitem_93 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu_default_31 = torch.ops.aten.relu.default(getitem_91);  getitem_91 = None
        cat_default_3 = torch.ops.aten.cat.default([relu_default_26, relu_default_28, relu_default_31], 1)
        convolution_default_32 = torch.ops.aten.convolution.default(cat_default_3, primals_1040, primals_1039, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1039 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(convolution_default_32, 0.17);  convolution_default_32 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_2, relu_default_25);  mul_tensor_2 = None
        relu_default_32 = torch.ops.aten.relu.default(add_tensor_2);  add_tensor_2 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu_default_32, primals_1046, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_1045, primals_1041, primals_1043, primals_1044, True, 0.1, 0.001);  primals_1041 = None
        getitem_94 = native_batch_norm_default_30[0]
        getitem_95 = native_batch_norm_default_30[1]
        getitem_96 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu_default_33 = torch.ops.aten.relu.default(getitem_94);  getitem_94 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu_default_32, primals_1052, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_1051, primals_1047, primals_1049, primals_1050, True, 0.1, 0.001);  primals_1047 = None
        getitem_97 = native_batch_norm_default_31[0]
        getitem_98 = native_batch_norm_default_31[1]
        getitem_99 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu_default_34 = torch.ops.aten.relu.default(getitem_97);  getitem_97 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu_default_34, primals_1058, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_1057, primals_1053, primals_1055, primals_1056, True, 0.1, 0.001);  primals_1053 = None
        getitem_100 = native_batch_norm_default_32[0]
        getitem_101 = native_batch_norm_default_32[1]
        getitem_102 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu_default_35 = torch.ops.aten.relu.default(getitem_100);  getitem_100 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu_default_32, primals_1064, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_1063, primals_1059, primals_1061, primals_1062, True, 0.1, 0.001);  primals_1059 = None
        getitem_103 = native_batch_norm_default_33[0]
        getitem_104 = native_batch_norm_default_33[1]
        getitem_105 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu_default_36 = torch.ops.aten.relu.default(getitem_103);  getitem_103 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu_default_36, primals_1070, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_1069, primals_1065, primals_1067, primals_1068, True, 0.1, 0.001);  primals_1065 = None
        getitem_106 = native_batch_norm_default_34[0]
        getitem_107 = native_batch_norm_default_34[1]
        getitem_108 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu_default_37 = torch.ops.aten.relu.default(getitem_106);  getitem_106 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu_default_37, primals_1076, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_1075, primals_1071, primals_1073, primals_1074, True, 0.1, 0.001);  primals_1071 = None
        getitem_109 = native_batch_norm_default_35[0]
        getitem_110 = native_batch_norm_default_35[1]
        getitem_111 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu_default_38 = torch.ops.aten.relu.default(getitem_109);  getitem_109 = None
        cat_default_4 = torch.ops.aten.cat.default([relu_default_33, relu_default_35, relu_default_38], 1)
        convolution_default_39 = torch.ops.aten.convolution.default(cat_default_4, primals_1078, primals_1077, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1077 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(convolution_default_39, 0.17);  convolution_default_39 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(mul_tensor_3, relu_default_32);  mul_tensor_3 = None
        relu_default_39 = torch.ops.aten.relu.default(add_tensor_3);  add_tensor_3 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu_default_39, primals_1084, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_1083, primals_1079, primals_1081, primals_1082, True, 0.1, 0.001);  primals_1079 = None
        getitem_112 = native_batch_norm_default_36[0]
        getitem_113 = native_batch_norm_default_36[1]
        getitem_114 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu_default_40 = torch.ops.aten.relu.default(getitem_112);  getitem_112 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu_default_39, primals_1090, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_1089, primals_1085, primals_1087, primals_1088, True, 0.1, 0.001);  primals_1085 = None
        getitem_115 = native_batch_norm_default_37[0]
        getitem_116 = native_batch_norm_default_37[1]
        getitem_117 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu_default_41 = torch.ops.aten.relu.default(getitem_115);  getitem_115 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu_default_41, primals_1096, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_1095, primals_1091, primals_1093, primals_1094, True, 0.1, 0.001);  primals_1091 = None
        getitem_118 = native_batch_norm_default_38[0]
        getitem_119 = native_batch_norm_default_38[1]
        getitem_120 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu_default_42 = torch.ops.aten.relu.default(getitem_118);  getitem_118 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu_default_39, primals_1102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_1101, primals_1097, primals_1099, primals_1100, True, 0.1, 0.001);  primals_1097 = None
        getitem_121 = native_batch_norm_default_39[0]
        getitem_122 = native_batch_norm_default_39[1]
        getitem_123 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu_default_43 = torch.ops.aten.relu.default(getitem_121);  getitem_121 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu_default_43, primals_1108, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_1107, primals_1103, primals_1105, primals_1106, True, 0.1, 0.001);  primals_1103 = None
        getitem_124 = native_batch_norm_default_40[0]
        getitem_125 = native_batch_norm_default_40[1]
        getitem_126 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu_default_44 = torch.ops.aten.relu.default(getitem_124);  getitem_124 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu_default_44, primals_1114, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_1113, primals_1109, primals_1111, primals_1112, True, 0.1, 0.001);  primals_1109 = None
        getitem_127 = native_batch_norm_default_41[0]
        getitem_128 = native_batch_norm_default_41[1]
        getitem_129 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu_default_45 = torch.ops.aten.relu.default(getitem_127);  getitem_127 = None
        cat_default_5 = torch.ops.aten.cat.default([relu_default_40, relu_default_42, relu_default_45], 1)
        convolution_default_46 = torch.ops.aten.convolution.default(cat_default_5, primals_1116, primals_1115, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1115 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(convolution_default_46, 0.17);  convolution_default_46 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_4, relu_default_39);  mul_tensor_4 = None
        relu_default_46 = torch.ops.aten.relu.default(add_tensor_4);  add_tensor_4 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu_default_46, primals_1122, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_1121, primals_1117, primals_1119, primals_1120, True, 0.1, 0.001);  primals_1117 = None
        getitem_130 = native_batch_norm_default_42[0]
        getitem_131 = native_batch_norm_default_42[1]
        getitem_132 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu_default_47 = torch.ops.aten.relu.default(getitem_130);  getitem_130 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu_default_46, primals_1128, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_1127, primals_1123, primals_1125, primals_1126, True, 0.1, 0.001);  primals_1123 = None
        getitem_133 = native_batch_norm_default_43[0]
        getitem_134 = native_batch_norm_default_43[1]
        getitem_135 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu_default_48 = torch.ops.aten.relu.default(getitem_133);  getitem_133 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu_default_48, primals_1134, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_1133, primals_1129, primals_1131, primals_1132, True, 0.1, 0.001);  primals_1129 = None
        getitem_136 = native_batch_norm_default_44[0]
        getitem_137 = native_batch_norm_default_44[1]
        getitem_138 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu_default_49 = torch.ops.aten.relu.default(getitem_136);  getitem_136 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu_default_46, primals_1140, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_1139, primals_1135, primals_1137, primals_1138, True, 0.1, 0.001);  primals_1135 = None
        getitem_139 = native_batch_norm_default_45[0]
        getitem_140 = native_batch_norm_default_45[1]
        getitem_141 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu_default_50 = torch.ops.aten.relu.default(getitem_139);  getitem_139 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu_default_50, primals_1146, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_1145, primals_1141, primals_1143, primals_1144, True, 0.1, 0.001);  primals_1141 = None
        getitem_142 = native_batch_norm_default_46[0]
        getitem_143 = native_batch_norm_default_46[1]
        getitem_144 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu_default_51 = torch.ops.aten.relu.default(getitem_142);  getitem_142 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu_default_51, primals_1152, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_1151, primals_1147, primals_1149, primals_1150, True, 0.1, 0.001);  primals_1147 = None
        getitem_145 = native_batch_norm_default_47[0]
        getitem_146 = native_batch_norm_default_47[1]
        getitem_147 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu_default_52 = torch.ops.aten.relu.default(getitem_145);  getitem_145 = None
        cat_default_6 = torch.ops.aten.cat.default([relu_default_47, relu_default_49, relu_default_52], 1)
        convolution_default_53 = torch.ops.aten.convolution.default(cat_default_6, primals_1154, primals_1153, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1153 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(convolution_default_53, 0.17);  convolution_default_53 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(mul_tensor_5, relu_default_46);  mul_tensor_5 = None
        relu_default_53 = torch.ops.aten.relu.default(add_tensor_5);  add_tensor_5 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu_default_53, primals_1160, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_1159, primals_1155, primals_1157, primals_1158, True, 0.1, 0.001);  primals_1155 = None
        getitem_148 = native_batch_norm_default_48[0]
        getitem_149 = native_batch_norm_default_48[1]
        getitem_150 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu_default_54 = torch.ops.aten.relu.default(getitem_148);  getitem_148 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu_default_53, primals_1166, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_1165, primals_1161, primals_1163, primals_1164, True, 0.1, 0.001);  primals_1161 = None
        getitem_151 = native_batch_norm_default_49[0]
        getitem_152 = native_batch_norm_default_49[1]
        getitem_153 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu_default_55 = torch.ops.aten.relu.default(getitem_151);  getitem_151 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu_default_55, primals_1172, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_1171, primals_1167, primals_1169, primals_1170, True, 0.1, 0.001);  primals_1167 = None
        getitem_154 = native_batch_norm_default_50[0]
        getitem_155 = native_batch_norm_default_50[1]
        getitem_156 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu_default_56 = torch.ops.aten.relu.default(getitem_154);  getitem_154 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu_default_53, primals_1178, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_1177, primals_1173, primals_1175, primals_1176, True, 0.1, 0.001);  primals_1173 = None
        getitem_157 = native_batch_norm_default_51[0]
        getitem_158 = native_batch_norm_default_51[1]
        getitem_159 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu_default_57 = torch.ops.aten.relu.default(getitem_157);  getitem_157 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu_default_57, primals_1184, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_1183, primals_1179, primals_1181, primals_1182, True, 0.1, 0.001);  primals_1179 = None
        getitem_160 = native_batch_norm_default_52[0]
        getitem_161 = native_batch_norm_default_52[1]
        getitem_162 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu_default_58 = torch.ops.aten.relu.default(getitem_160);  getitem_160 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu_default_58, primals_1190, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_1189, primals_1185, primals_1187, primals_1188, True, 0.1, 0.001);  primals_1185 = None
        getitem_163 = native_batch_norm_default_53[0]
        getitem_164 = native_batch_norm_default_53[1]
        getitem_165 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        relu_default_59 = torch.ops.aten.relu.default(getitem_163);  getitem_163 = None
        cat_default_7 = torch.ops.aten.cat.default([relu_default_54, relu_default_56, relu_default_59], 1)
        convolution_default_60 = torch.ops.aten.convolution.default(cat_default_7, primals_1192, primals_1191, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1191 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(convolution_default_60, 0.17);  convolution_default_60 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_6, relu_default_53);  mul_tensor_6 = None
        relu_default_60 = torch.ops.aten.relu.default(add_tensor_6);  add_tensor_6 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu_default_60, primals_1198, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_1197, primals_1193, primals_1195, primals_1196, True, 0.1, 0.001);  primals_1193 = None
        getitem_166 = native_batch_norm_default_54[0]
        getitem_167 = native_batch_norm_default_54[1]
        getitem_168 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu_default_61 = torch.ops.aten.relu.default(getitem_166);  getitem_166 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu_default_60, primals_1204, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_1203, primals_1199, primals_1201, primals_1202, True, 0.1, 0.001);  primals_1199 = None
        getitem_169 = native_batch_norm_default_55[0]
        getitem_170 = native_batch_norm_default_55[1]
        getitem_171 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu_default_62 = torch.ops.aten.relu.default(getitem_169);  getitem_169 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu_default_62, primals_1210, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_1209, primals_1205, primals_1207, primals_1208, True, 0.1, 0.001);  primals_1205 = None
        getitem_172 = native_batch_norm_default_56[0]
        getitem_173 = native_batch_norm_default_56[1]
        getitem_174 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu_default_63 = torch.ops.aten.relu.default(getitem_172);  getitem_172 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu_default_60, primals_1216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_1215, primals_1211, primals_1213, primals_1214, True, 0.1, 0.001);  primals_1211 = None
        getitem_175 = native_batch_norm_default_57[0]
        getitem_176 = native_batch_norm_default_57[1]
        getitem_177 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu_default_64 = torch.ops.aten.relu.default(getitem_175);  getitem_175 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu_default_64, primals_1222, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_1221, primals_1217, primals_1219, primals_1220, True, 0.1, 0.001);  primals_1217 = None
        getitem_178 = native_batch_norm_default_58[0]
        getitem_179 = native_batch_norm_default_58[1]
        getitem_180 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu_default_65 = torch.ops.aten.relu.default(getitem_178);  getitem_178 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu_default_65, primals_1228, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_1227, primals_1223, primals_1225, primals_1226, True, 0.1, 0.001);  primals_1223 = None
        getitem_181 = native_batch_norm_default_59[0]
        getitem_182 = native_batch_norm_default_59[1]
        getitem_183 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu_default_66 = torch.ops.aten.relu.default(getitem_181);  getitem_181 = None
        cat_default_8 = torch.ops.aten.cat.default([relu_default_61, relu_default_63, relu_default_66], 1)
        convolution_default_67 = torch.ops.aten.convolution.default(cat_default_8, primals_1230, primals_1229, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1229 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(convolution_default_67, 0.17);  convolution_default_67 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(mul_tensor_7, relu_default_60);  mul_tensor_7 = None
        relu_default_67 = torch.ops.aten.relu.default(add_tensor_7);  add_tensor_7 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu_default_67, primals_1236, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_1235, primals_1231, primals_1233, primals_1234, True, 0.1, 0.001);  primals_1231 = None
        getitem_184 = native_batch_norm_default_60[0]
        getitem_185 = native_batch_norm_default_60[1]
        getitem_186 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu_default_68 = torch.ops.aten.relu.default(getitem_184);  getitem_184 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu_default_67, primals_1242, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_1241, primals_1237, primals_1239, primals_1240, True, 0.1, 0.001);  primals_1237 = None
        getitem_187 = native_batch_norm_default_61[0]
        getitem_188 = native_batch_norm_default_61[1]
        getitem_189 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu_default_69 = torch.ops.aten.relu.default(getitem_187);  getitem_187 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu_default_69, primals_1248, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_1247, primals_1243, primals_1245, primals_1246, True, 0.1, 0.001);  primals_1243 = None
        getitem_190 = native_batch_norm_default_62[0]
        getitem_191 = native_batch_norm_default_62[1]
        getitem_192 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu_default_70 = torch.ops.aten.relu.default(getitem_190);  getitem_190 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu_default_67, primals_1254, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_1253, primals_1249, primals_1251, primals_1252, True, 0.1, 0.001);  primals_1249 = None
        getitem_193 = native_batch_norm_default_63[0]
        getitem_194 = native_batch_norm_default_63[1]
        getitem_195 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu_default_71 = torch.ops.aten.relu.default(getitem_193);  getitem_193 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu_default_71, primals_1260, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_1259, primals_1255, primals_1257, primals_1258, True, 0.1, 0.001);  primals_1255 = None
        getitem_196 = native_batch_norm_default_64[0]
        getitem_197 = native_batch_norm_default_64[1]
        getitem_198 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu_default_72 = torch.ops.aten.relu.default(getitem_196);  getitem_196 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu_default_72, primals_1266, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_1265, primals_1261, primals_1263, primals_1264, True, 0.1, 0.001);  primals_1261 = None
        getitem_199 = native_batch_norm_default_65[0]
        getitem_200 = native_batch_norm_default_65[1]
        getitem_201 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu_default_73 = torch.ops.aten.relu.default(getitem_199);  getitem_199 = None
        cat_default_9 = torch.ops.aten.cat.default([relu_default_68, relu_default_70, relu_default_73], 1)
        convolution_default_74 = torch.ops.aten.convolution.default(cat_default_9, primals_1268, primals_1267, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1267 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(convolution_default_74, 0.17);  convolution_default_74 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_8, relu_default_67);  mul_tensor_8 = None
        relu_default_74 = torch.ops.aten.relu.default(add_tensor_8);  add_tensor_8 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu_default_74, primals_1274, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_1273, primals_1269, primals_1271, primals_1272, True, 0.1, 0.001);  primals_1269 = None
        getitem_202 = native_batch_norm_default_66[0]
        getitem_203 = native_batch_norm_default_66[1]
        getitem_204 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu_default_75 = torch.ops.aten.relu.default(getitem_202);  getitem_202 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu_default_74, primals_1280, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_1279, primals_1275, primals_1277, primals_1278, True, 0.1, 0.001);  primals_1275 = None
        getitem_205 = native_batch_norm_default_67[0]
        getitem_206 = native_batch_norm_default_67[1]
        getitem_207 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu_default_76 = torch.ops.aten.relu.default(getitem_205);  getitem_205 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu_default_76, primals_1286, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_1285, primals_1281, primals_1283, primals_1284, True, 0.1, 0.001);  primals_1281 = None
        getitem_208 = native_batch_norm_default_68[0]
        getitem_209 = native_batch_norm_default_68[1]
        getitem_210 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu_default_77 = torch.ops.aten.relu.default(getitem_208);  getitem_208 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu_default_74, primals_1292, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_1291, primals_1287, primals_1289, primals_1290, True, 0.1, 0.001);  primals_1287 = None
        getitem_211 = native_batch_norm_default_69[0]
        getitem_212 = native_batch_norm_default_69[1]
        getitem_213 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu_default_78 = torch.ops.aten.relu.default(getitem_211);  getitem_211 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu_default_78, primals_1298, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_1297, primals_1293, primals_1295, primals_1296, True, 0.1, 0.001);  primals_1293 = None
        getitem_214 = native_batch_norm_default_70[0]
        getitem_215 = native_batch_norm_default_70[1]
        getitem_216 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu_default_79 = torch.ops.aten.relu.default(getitem_214);  getitem_214 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu_default_79, primals_1304, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_1303, primals_1299, primals_1301, primals_1302, True, 0.1, 0.001);  primals_1299 = None
        getitem_217 = native_batch_norm_default_71[0]
        getitem_218 = native_batch_norm_default_71[1]
        getitem_219 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu_default_80 = torch.ops.aten.relu.default(getitem_217);  getitem_217 = None
        cat_default_10 = torch.ops.aten.cat.default([relu_default_75, relu_default_77, relu_default_80], 1)
        convolution_default_81 = torch.ops.aten.convolution.default(cat_default_10, primals_1306, primals_1305, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1305 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(convolution_default_81, 0.17);  convolution_default_81 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(mul_tensor_9, relu_default_74);  mul_tensor_9 = None
        relu_default_81 = torch.ops.aten.relu.default(add_tensor_9);  add_tensor_9 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu_default_81, primals_112, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_111, primals_107, primals_109, primals_110, True, 0.1, 0.001);  primals_107 = None
        getitem_220 = native_batch_norm_default_72[0]
        getitem_221 = native_batch_norm_default_72[1]
        getitem_222 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu_default_82 = torch.ops.aten.relu.default(getitem_220);  getitem_220 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu_default_81, primals_118, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_117, primals_113, primals_115, primals_116, True, 0.1, 0.001);  primals_113 = None
        getitem_223 = native_batch_norm_default_73[0]
        getitem_224 = native_batch_norm_default_73[1]
        getitem_225 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu_default_83 = torch.ops.aten.relu.default(getitem_223);  getitem_223 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu_default_83, primals_124, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_123, primals_119, primals_121, primals_122, True, 0.1, 0.001);  primals_119 = None
        getitem_226 = native_batch_norm_default_74[0]
        getitem_227 = native_batch_norm_default_74[1]
        getitem_228 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu_default_84 = torch.ops.aten.relu.default(getitem_226);  getitem_226 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu_default_84, primals_130, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_129, primals_125, primals_127, primals_128, True, 0.1, 0.001);  primals_125 = None
        getitem_229 = native_batch_norm_default_75[0]
        getitem_230 = native_batch_norm_default_75[1]
        getitem_231 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu_default_85 = torch.ops.aten.relu.default(getitem_229);  getitem_229 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(relu_default_81, [3, 3], [2, 2])
        getitem_232 = max_pool2d_with_indices_default_2[0]
        getitem_233 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        cat_default_11 = torch.ops.aten.cat.default([relu_default_82, relu_default_85, getitem_232], 1);  getitem_232 = None
        convolution_default_86 = torch.ops.aten.convolution.default(cat_default_11, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_215, primals_211, primals_213, primals_214, True, 0.1, 0.001);  primals_211 = None
        getitem_234 = native_batch_norm_default_76[0]
        getitem_235 = native_batch_norm_default_76[1]
        getitem_236 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu_default_86 = torch.ops.aten.relu.default(getitem_234);  getitem_234 = None
        convolution_default_87 = torch.ops.aten.convolution.default(cat_default_11, primals_222, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_221, primals_217, primals_219, primals_220, True, 0.1, 0.001);  primals_217 = None
        getitem_237 = native_batch_norm_default_77[0]
        getitem_238 = native_batch_norm_default_77[1]
        getitem_239 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu_default_87 = torch.ops.aten.relu.default(getitem_237);  getitem_237 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu_default_87, primals_228, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_227, primals_223, primals_225, primals_226, True, 0.1, 0.001);  primals_223 = None
        getitem_240 = native_batch_norm_default_78[0]
        getitem_241 = native_batch_norm_default_78[1]
        getitem_242 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu_default_88 = torch.ops.aten.relu.default(getitem_240);  getitem_240 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu_default_88, primals_234, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_233, primals_229, primals_231, primals_232, True, 0.1, 0.001);  primals_229 = None
        getitem_243 = native_batch_norm_default_79[0]
        getitem_244 = native_batch_norm_default_79[1]
        getitem_245 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu_default_89 = torch.ops.aten.relu.default(getitem_243);  getitem_243 = None
        cat_default_12 = torch.ops.aten.cat.default([relu_default_86, relu_default_89], 1)
        convolution_default_90 = torch.ops.aten.convolution.default(cat_default_12, primals_236, primals_235, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_235 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(convolution_default_90, 0.1);  convolution_default_90 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_10, cat_default_11);  mul_tensor_10 = None
        relu_default_90 = torch.ops.aten.relu.default(add_tensor_10);  add_tensor_10 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu_default_90, primals_502, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_501, primals_497, primals_499, primals_500, True, 0.1, 0.001);  primals_497 = None
        getitem_246 = native_batch_norm_default_80[0]
        getitem_247 = native_batch_norm_default_80[1]
        getitem_248 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu_default_91 = torch.ops.aten.relu.default(getitem_246);  getitem_246 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu_default_90, primals_508, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_507, primals_503, primals_505, primals_506, True, 0.1, 0.001);  primals_503 = None
        getitem_249 = native_batch_norm_default_81[0]
        getitem_250 = native_batch_norm_default_81[1]
        getitem_251 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu_default_92 = torch.ops.aten.relu.default(getitem_249);  getitem_249 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu_default_92, primals_514, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_513, primals_509, primals_511, primals_512, True, 0.1, 0.001);  primals_509 = None
        getitem_252 = native_batch_norm_default_82[0]
        getitem_253 = native_batch_norm_default_82[1]
        getitem_254 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu_default_93 = torch.ops.aten.relu.default(getitem_252);  getitem_252 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu_default_93, primals_520, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_519, primals_515, primals_517, primals_518, True, 0.1, 0.001);  primals_515 = None
        getitem_255 = native_batch_norm_default_83[0]
        getitem_256 = native_batch_norm_default_83[1]
        getitem_257 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu_default_94 = torch.ops.aten.relu.default(getitem_255);  getitem_255 = None
        cat_default_13 = torch.ops.aten.cat.default([relu_default_91, relu_default_94], 1)
        convolution_default_95 = torch.ops.aten.convolution.default(cat_default_13, primals_522, primals_521, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_521 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(convolution_default_95, 0.1);  convolution_default_95 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(mul_tensor_11, relu_default_90);  mul_tensor_11 = None
        relu_default_95 = torch.ops.aten.relu.default(add_tensor_11);  add_tensor_11 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu_default_95, primals_528, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_527, primals_523, primals_525, primals_526, True, 0.1, 0.001);  primals_523 = None
        getitem_258 = native_batch_norm_default_84[0]
        getitem_259 = native_batch_norm_default_84[1]
        getitem_260 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu_default_96 = torch.ops.aten.relu.default(getitem_258);  getitem_258 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu_default_95, primals_534, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_533, primals_529, primals_531, primals_532, True, 0.1, 0.001);  primals_529 = None
        getitem_261 = native_batch_norm_default_85[0]
        getitem_262 = native_batch_norm_default_85[1]
        getitem_263 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu_default_97 = torch.ops.aten.relu.default(getitem_261);  getitem_261 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu_default_97, primals_540, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_539, primals_535, primals_537, primals_538, True, 0.1, 0.001);  primals_535 = None
        getitem_264 = native_batch_norm_default_86[0]
        getitem_265 = native_batch_norm_default_86[1]
        getitem_266 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu_default_98 = torch.ops.aten.relu.default(getitem_264);  getitem_264 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu_default_98, primals_546, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_545, primals_541, primals_543, primals_544, True, 0.1, 0.001);  primals_541 = None
        getitem_267 = native_batch_norm_default_87[0]
        getitem_268 = native_batch_norm_default_87[1]
        getitem_269 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu_default_99 = torch.ops.aten.relu.default(getitem_267);  getitem_267 = None
        cat_default_14 = torch.ops.aten.cat.default([relu_default_96, relu_default_99], 1)
        convolution_default_100 = torch.ops.aten.convolution.default(cat_default_14, primals_548, primals_547, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_547 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(convolution_default_100, 0.1);  convolution_default_100 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_12, relu_default_95);  mul_tensor_12 = None
        relu_default_100 = torch.ops.aten.relu.default(add_tensor_12);  add_tensor_12 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu_default_100, primals_554, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_553, primals_549, primals_551, primals_552, True, 0.1, 0.001);  primals_549 = None
        getitem_270 = native_batch_norm_default_88[0]
        getitem_271 = native_batch_norm_default_88[1]
        getitem_272 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu_default_101 = torch.ops.aten.relu.default(getitem_270);  getitem_270 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu_default_100, primals_560, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_559, primals_555, primals_557, primals_558, True, 0.1, 0.001);  primals_555 = None
        getitem_273 = native_batch_norm_default_89[0]
        getitem_274 = native_batch_norm_default_89[1]
        getitem_275 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu_default_102 = torch.ops.aten.relu.default(getitem_273);  getitem_273 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu_default_102, primals_566, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_565, primals_561, primals_563, primals_564, True, 0.1, 0.001);  primals_561 = None
        getitem_276 = native_batch_norm_default_90[0]
        getitem_277 = native_batch_norm_default_90[1]
        getitem_278 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu_default_103 = torch.ops.aten.relu.default(getitem_276);  getitem_276 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu_default_103, primals_572, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_571, primals_567, primals_569, primals_570, True, 0.1, 0.001);  primals_567 = None
        getitem_279 = native_batch_norm_default_91[0]
        getitem_280 = native_batch_norm_default_91[1]
        getitem_281 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu_default_104 = torch.ops.aten.relu.default(getitem_279);  getitem_279 = None
        cat_default_15 = torch.ops.aten.cat.default([relu_default_101, relu_default_104], 1)
        convolution_default_105 = torch.ops.aten.convolution.default(cat_default_15, primals_574, primals_573, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_573 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(convolution_default_105, 0.1);  convolution_default_105 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(mul_tensor_13, relu_default_100);  mul_tensor_13 = None
        relu_default_105 = torch.ops.aten.relu.default(add_tensor_13);  add_tensor_13 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu_default_105, primals_580, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_579, primals_575, primals_577, primals_578, True, 0.1, 0.001);  primals_575 = None
        getitem_282 = native_batch_norm_default_92[0]
        getitem_283 = native_batch_norm_default_92[1]
        getitem_284 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu_default_106 = torch.ops.aten.relu.default(getitem_282);  getitem_282 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu_default_105, primals_586, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_585, primals_581, primals_583, primals_584, True, 0.1, 0.001);  primals_581 = None
        getitem_285 = native_batch_norm_default_93[0]
        getitem_286 = native_batch_norm_default_93[1]
        getitem_287 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        relu_default_107 = torch.ops.aten.relu.default(getitem_285);  getitem_285 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu_default_107, primals_592, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_591, primals_587, primals_589, primals_590, True, 0.1, 0.001);  primals_587 = None
        getitem_288 = native_batch_norm_default_94[0]
        getitem_289 = native_batch_norm_default_94[1]
        getitem_290 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu_default_108 = torch.ops.aten.relu.default(getitem_288);  getitem_288 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu_default_108, primals_598, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_597, primals_593, primals_595, primals_596, True, 0.1, 0.001);  primals_593 = None
        getitem_291 = native_batch_norm_default_95[0]
        getitem_292 = native_batch_norm_default_95[1]
        getitem_293 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu_default_109 = torch.ops.aten.relu.default(getitem_291);  getitem_291 = None
        cat_default_16 = torch.ops.aten.cat.default([relu_default_106, relu_default_109], 1)
        convolution_default_110 = torch.ops.aten.convolution.default(cat_default_16, primals_600, primals_599, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_599 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(convolution_default_110, 0.1);  convolution_default_110 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_14, relu_default_105);  mul_tensor_14 = None
        relu_default_110 = torch.ops.aten.relu.default(add_tensor_14);  add_tensor_14 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu_default_110, primals_606, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_605, primals_601, primals_603, primals_604, True, 0.1, 0.001);  primals_601 = None
        getitem_294 = native_batch_norm_default_96[0]
        getitem_295 = native_batch_norm_default_96[1]
        getitem_296 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        relu_default_111 = torch.ops.aten.relu.default(getitem_294);  getitem_294 = None
        convolution_default_112 = torch.ops.aten.convolution.default(relu_default_110, primals_612, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_611, primals_607, primals_609, primals_610, True, 0.1, 0.001);  primals_607 = None
        getitem_297 = native_batch_norm_default_97[0]
        getitem_298 = native_batch_norm_default_97[1]
        getitem_299 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        relu_default_112 = torch.ops.aten.relu.default(getitem_297);  getitem_297 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu_default_112, primals_618, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_617, primals_613, primals_615, primals_616, True, 0.1, 0.001);  primals_613 = None
        getitem_300 = native_batch_norm_default_98[0]
        getitem_301 = native_batch_norm_default_98[1]
        getitem_302 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu_default_113 = torch.ops.aten.relu.default(getitem_300);  getitem_300 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu_default_113, primals_624, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_623, primals_619, primals_621, primals_622, True, 0.1, 0.001);  primals_619 = None
        getitem_303 = native_batch_norm_default_99[0]
        getitem_304 = native_batch_norm_default_99[1]
        getitem_305 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu_default_114 = torch.ops.aten.relu.default(getitem_303);  getitem_303 = None
        cat_default_17 = torch.ops.aten.cat.default([relu_default_111, relu_default_114], 1)
        convolution_default_115 = torch.ops.aten.convolution.default(cat_default_17, primals_626, primals_625, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_625 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(convolution_default_115, 0.1);  convolution_default_115 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(mul_tensor_15, relu_default_110);  mul_tensor_15 = None
        relu_default_115 = torch.ops.aten.relu.default(add_tensor_15);  add_tensor_15 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu_default_115, primals_632, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_631, primals_627, primals_629, primals_630, True, 0.1, 0.001);  primals_627 = None
        getitem_306 = native_batch_norm_default_100[0]
        getitem_307 = native_batch_norm_default_100[1]
        getitem_308 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu_default_116 = torch.ops.aten.relu.default(getitem_306);  getitem_306 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu_default_115, primals_638, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_637, primals_633, primals_635, primals_636, True, 0.1, 0.001);  primals_633 = None
        getitem_309 = native_batch_norm_default_101[0]
        getitem_310 = native_batch_norm_default_101[1]
        getitem_311 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        relu_default_117 = torch.ops.aten.relu.default(getitem_309);  getitem_309 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu_default_117, primals_644, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_643, primals_639, primals_641, primals_642, True, 0.1, 0.001);  primals_639 = None
        getitem_312 = native_batch_norm_default_102[0]
        getitem_313 = native_batch_norm_default_102[1]
        getitem_314 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu_default_118 = torch.ops.aten.relu.default(getitem_312);  getitem_312 = None
        convolution_default_119 = torch.ops.aten.convolution.default(relu_default_118, primals_650, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_649, primals_645, primals_647, primals_648, True, 0.1, 0.001);  primals_645 = None
        getitem_315 = native_batch_norm_default_103[0]
        getitem_316 = native_batch_norm_default_103[1]
        getitem_317 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        relu_default_119 = torch.ops.aten.relu.default(getitem_315);  getitem_315 = None
        cat_default_18 = torch.ops.aten.cat.default([relu_default_116, relu_default_119], 1)
        convolution_default_120 = torch.ops.aten.convolution.default(cat_default_18, primals_652, primals_651, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_651 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(convolution_default_120, 0.1);  convolution_default_120 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(mul_tensor_16, relu_default_115);  mul_tensor_16 = None
        relu_default_120 = torch.ops.aten.relu.default(add_tensor_16);  add_tensor_16 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu_default_120, primals_658, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_657, primals_653, primals_655, primals_656, True, 0.1, 0.001);  primals_653 = None
        getitem_318 = native_batch_norm_default_104[0]
        getitem_319 = native_batch_norm_default_104[1]
        getitem_320 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu_default_121 = torch.ops.aten.relu.default(getitem_318);  getitem_318 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu_default_120, primals_664, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_663, primals_659, primals_661, primals_662, True, 0.1, 0.001);  primals_659 = None
        getitem_321 = native_batch_norm_default_105[0]
        getitem_322 = native_batch_norm_default_105[1]
        getitem_323 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        relu_default_122 = torch.ops.aten.relu.default(getitem_321);  getitem_321 = None
        convolution_default_123 = torch.ops.aten.convolution.default(relu_default_122, primals_670, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_669, primals_665, primals_667, primals_668, True, 0.1, 0.001);  primals_665 = None
        getitem_324 = native_batch_norm_default_106[0]
        getitem_325 = native_batch_norm_default_106[1]
        getitem_326 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu_default_123 = torch.ops.aten.relu.default(getitem_324);  getitem_324 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu_default_123, primals_676, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_675, primals_671, primals_673, primals_674, True, 0.1, 0.001);  primals_671 = None
        getitem_327 = native_batch_norm_default_107[0]
        getitem_328 = native_batch_norm_default_107[1]
        getitem_329 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        relu_default_124 = torch.ops.aten.relu.default(getitem_327);  getitem_327 = None
        cat_default_19 = torch.ops.aten.cat.default([relu_default_121, relu_default_124], 1)
        convolution_default_125 = torch.ops.aten.convolution.default(cat_default_19, primals_678, primals_677, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_677 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(convolution_default_125, 0.1);  convolution_default_125 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(mul_tensor_17, relu_default_120);  mul_tensor_17 = None
        relu_default_125 = torch.ops.aten.relu.default(add_tensor_17);  add_tensor_17 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu_default_125, primals_684, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_683, primals_679, primals_681, primals_682, True, 0.1, 0.001);  primals_679 = None
        getitem_330 = native_batch_norm_default_108[0]
        getitem_331 = native_batch_norm_default_108[1]
        getitem_332 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu_default_126 = torch.ops.aten.relu.default(getitem_330);  getitem_330 = None
        convolution_default_127 = torch.ops.aten.convolution.default(relu_default_125, primals_690, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_689, primals_685, primals_687, primals_688, True, 0.1, 0.001);  primals_685 = None
        getitem_333 = native_batch_norm_default_109[0]
        getitem_334 = native_batch_norm_default_109[1]
        getitem_335 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        relu_default_127 = torch.ops.aten.relu.default(getitem_333);  getitem_333 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu_default_127, primals_696, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_695, primals_691, primals_693, primals_694, True, 0.1, 0.001);  primals_691 = None
        getitem_336 = native_batch_norm_default_110[0]
        getitem_337 = native_batch_norm_default_110[1]
        getitem_338 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        relu_default_128 = torch.ops.aten.relu.default(getitem_336);  getitem_336 = None
        convolution_default_129 = torch.ops.aten.convolution.default(relu_default_128, primals_702, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_701, primals_697, primals_699, primals_700, True, 0.1, 0.001);  primals_697 = None
        getitem_339 = native_batch_norm_default_111[0]
        getitem_340 = native_batch_norm_default_111[1]
        getitem_341 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        relu_default_129 = torch.ops.aten.relu.default(getitem_339);  getitem_339 = None
        cat_default_20 = torch.ops.aten.cat.default([relu_default_126, relu_default_129], 1)
        convolution_default_130 = torch.ops.aten.convolution.default(cat_default_20, primals_704, primals_703, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_703 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(convolution_default_130, 0.1);  convolution_default_130 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(mul_tensor_18, relu_default_125);  mul_tensor_18 = None
        relu_default_130 = torch.ops.aten.relu.default(add_tensor_18);  add_tensor_18 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu_default_130, primals_710, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_709, primals_705, primals_707, primals_708, True, 0.1, 0.001);  primals_705 = None
        getitem_342 = native_batch_norm_default_112[0]
        getitem_343 = native_batch_norm_default_112[1]
        getitem_344 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        relu_default_131 = torch.ops.aten.relu.default(getitem_342);  getitem_342 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu_default_130, primals_716, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_715, primals_711, primals_713, primals_714, True, 0.1, 0.001);  primals_711 = None
        getitem_345 = native_batch_norm_default_113[0]
        getitem_346 = native_batch_norm_default_113[1]
        getitem_347 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        relu_default_132 = torch.ops.aten.relu.default(getitem_345);  getitem_345 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu_default_132, primals_722, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_721, primals_717, primals_719, primals_720, True, 0.1, 0.001);  primals_717 = None
        getitem_348 = native_batch_norm_default_114[0]
        getitem_349 = native_batch_norm_default_114[1]
        getitem_350 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu_default_133 = torch.ops.aten.relu.default(getitem_348);  getitem_348 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu_default_133, primals_728, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_727, primals_723, primals_725, primals_726, True, 0.1, 0.001);  primals_723 = None
        getitem_351 = native_batch_norm_default_115[0]
        getitem_352 = native_batch_norm_default_115[1]
        getitem_353 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        relu_default_134 = torch.ops.aten.relu.default(getitem_351);  getitem_351 = None
        cat_default_21 = torch.ops.aten.cat.default([relu_default_131, relu_default_134], 1)
        convolution_default_135 = torch.ops.aten.convolution.default(cat_default_21, primals_730, primals_729, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_729 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(convolution_default_135, 0.1);  convolution_default_135 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(mul_tensor_19, relu_default_130);  mul_tensor_19 = None
        relu_default_135 = torch.ops.aten.relu.default(add_tensor_19);  add_tensor_19 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu_default_135, primals_242, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_241, primals_237, primals_239, primals_240, True, 0.1, 0.001);  primals_237 = None
        getitem_354 = native_batch_norm_default_116[0]
        getitem_355 = native_batch_norm_default_116[1]
        getitem_356 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        relu_default_136 = torch.ops.aten.relu.default(getitem_354);  getitem_354 = None
        convolution_default_137 = torch.ops.aten.convolution.default(relu_default_135, primals_248, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_247, primals_243, primals_245, primals_246, True, 0.1, 0.001);  primals_243 = None
        getitem_357 = native_batch_norm_default_117[0]
        getitem_358 = native_batch_norm_default_117[1]
        getitem_359 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        relu_default_137 = torch.ops.aten.relu.default(getitem_357);  getitem_357 = None
        convolution_default_138 = torch.ops.aten.convolution.default(relu_default_137, primals_254, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_253, primals_249, primals_251, primals_252, True, 0.1, 0.001);  primals_249 = None
        getitem_360 = native_batch_norm_default_118[0]
        getitem_361 = native_batch_norm_default_118[1]
        getitem_362 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        relu_default_138 = torch.ops.aten.relu.default(getitem_360);  getitem_360 = None
        convolution_default_139 = torch.ops.aten.convolution.default(relu_default_138, primals_260, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_259, primals_255, primals_257, primals_258, True, 0.1, 0.001);  primals_255 = None
        getitem_363 = native_batch_norm_default_119[0]
        getitem_364 = native_batch_norm_default_119[1]
        getitem_365 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        relu_default_139 = torch.ops.aten.relu.default(getitem_363);  getitem_363 = None
        cat_default_22 = torch.ops.aten.cat.default([relu_default_136, relu_default_139], 1)
        convolution_default_140 = torch.ops.aten.convolution.default(cat_default_22, primals_262, primals_261, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_261 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(convolution_default_140, 0.1);  convolution_default_140 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(mul_tensor_20, relu_default_135);  mul_tensor_20 = None
        relu_default_140 = torch.ops.aten.relu.default(add_tensor_20);  add_tensor_20 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu_default_140, primals_268, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_267, primals_263, primals_265, primals_266, True, 0.1, 0.001);  primals_263 = None
        getitem_366 = native_batch_norm_default_120[0]
        getitem_367 = native_batch_norm_default_120[1]
        getitem_368 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        relu_default_141 = torch.ops.aten.relu.default(getitem_366);  getitem_366 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu_default_140, primals_274, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_273, primals_269, primals_271, primals_272, True, 0.1, 0.001);  primals_269 = None
        getitem_369 = native_batch_norm_default_121[0]
        getitem_370 = native_batch_norm_default_121[1]
        getitem_371 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        relu_default_142 = torch.ops.aten.relu.default(getitem_369);  getitem_369 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu_default_142, primals_280, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_279, primals_275, primals_277, primals_278, True, 0.1, 0.001);  primals_275 = None
        getitem_372 = native_batch_norm_default_122[0]
        getitem_373 = native_batch_norm_default_122[1]
        getitem_374 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        relu_default_143 = torch.ops.aten.relu.default(getitem_372);  getitem_372 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu_default_143, primals_286, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_285, primals_281, primals_283, primals_284, True, 0.1, 0.001);  primals_281 = None
        getitem_375 = native_batch_norm_default_123[0]
        getitem_376 = native_batch_norm_default_123[1]
        getitem_377 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        relu_default_144 = torch.ops.aten.relu.default(getitem_375);  getitem_375 = None
        cat_default_23 = torch.ops.aten.cat.default([relu_default_141, relu_default_144], 1)
        convolution_default_145 = torch.ops.aten.convolution.default(cat_default_23, primals_288, primals_287, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_287 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(convolution_default_145, 0.1);  convolution_default_145 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(mul_tensor_21, relu_default_140);  mul_tensor_21 = None
        relu_default_145 = torch.ops.aten.relu.default(add_tensor_21);  add_tensor_21 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu_default_145, primals_294, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_293, primals_289, primals_291, primals_292, True, 0.1, 0.001);  primals_289 = None
        getitem_378 = native_batch_norm_default_124[0]
        getitem_379 = native_batch_norm_default_124[1]
        getitem_380 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        relu_default_146 = torch.ops.aten.relu.default(getitem_378);  getitem_378 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu_default_145, primals_300, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_299, primals_295, primals_297, primals_298, True, 0.1, 0.001);  primals_295 = None
        getitem_381 = native_batch_norm_default_125[0]
        getitem_382 = native_batch_norm_default_125[1]
        getitem_383 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        relu_default_147 = torch.ops.aten.relu.default(getitem_381);  getitem_381 = None
        convolution_default_148 = torch.ops.aten.convolution.default(relu_default_147, primals_306, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_305, primals_301, primals_303, primals_304, True, 0.1, 0.001);  primals_301 = None
        getitem_384 = native_batch_norm_default_126[0]
        getitem_385 = native_batch_norm_default_126[1]
        getitem_386 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        relu_default_148 = torch.ops.aten.relu.default(getitem_384);  getitem_384 = None
        convolution_default_149 = torch.ops.aten.convolution.default(relu_default_148, primals_312, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_311, primals_307, primals_309, primals_310, True, 0.1, 0.001);  primals_307 = None
        getitem_387 = native_batch_norm_default_127[0]
        getitem_388 = native_batch_norm_default_127[1]
        getitem_389 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        relu_default_149 = torch.ops.aten.relu.default(getitem_387);  getitem_387 = None
        cat_default_24 = torch.ops.aten.cat.default([relu_default_146, relu_default_149], 1)
        convolution_default_150 = torch.ops.aten.convolution.default(cat_default_24, primals_314, primals_313, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_313 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(convolution_default_150, 0.1);  convolution_default_150 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(mul_tensor_22, relu_default_145);  mul_tensor_22 = None
        relu_default_150 = torch.ops.aten.relu.default(add_tensor_22);  add_tensor_22 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu_default_150, primals_320, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_319, primals_315, primals_317, primals_318, True, 0.1, 0.001);  primals_315 = None
        getitem_390 = native_batch_norm_default_128[0]
        getitem_391 = native_batch_norm_default_128[1]
        getitem_392 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        relu_default_151 = torch.ops.aten.relu.default(getitem_390);  getitem_390 = None
        convolution_default_152 = torch.ops.aten.convolution.default(relu_default_150, primals_326, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_325, primals_321, primals_323, primals_324, True, 0.1, 0.001);  primals_321 = None
        getitem_393 = native_batch_norm_default_129[0]
        getitem_394 = native_batch_norm_default_129[1]
        getitem_395 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        relu_default_152 = torch.ops.aten.relu.default(getitem_393);  getitem_393 = None
        convolution_default_153 = torch.ops.aten.convolution.default(relu_default_152, primals_332, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_331, primals_327, primals_329, primals_330, True, 0.1, 0.001);  primals_327 = None
        getitem_396 = native_batch_norm_default_130[0]
        getitem_397 = native_batch_norm_default_130[1]
        getitem_398 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        relu_default_153 = torch.ops.aten.relu.default(getitem_396);  getitem_396 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu_default_153, primals_338, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_337, primals_333, primals_335, primals_336, True, 0.1, 0.001);  primals_333 = None
        getitem_399 = native_batch_norm_default_131[0]
        getitem_400 = native_batch_norm_default_131[1]
        getitem_401 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        relu_default_154 = torch.ops.aten.relu.default(getitem_399);  getitem_399 = None
        cat_default_25 = torch.ops.aten.cat.default([relu_default_151, relu_default_154], 1)
        convolution_default_155 = torch.ops.aten.convolution.default(cat_default_25, primals_340, primals_339, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_339 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(convolution_default_155, 0.1);  convolution_default_155 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(mul_tensor_23, relu_default_150);  mul_tensor_23 = None
        relu_default_155 = torch.ops.aten.relu.default(add_tensor_23);  add_tensor_23 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu_default_155, primals_346, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_345, primals_341, primals_343, primals_344, True, 0.1, 0.001);  primals_341 = None
        getitem_402 = native_batch_norm_default_132[0]
        getitem_403 = native_batch_norm_default_132[1]
        getitem_404 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        relu_default_156 = torch.ops.aten.relu.default(getitem_402);  getitem_402 = None
        convolution_default_157 = torch.ops.aten.convolution.default(relu_default_155, primals_352, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_351, primals_347, primals_349, primals_350, True, 0.1, 0.001);  primals_347 = None
        getitem_405 = native_batch_norm_default_133[0]
        getitem_406 = native_batch_norm_default_133[1]
        getitem_407 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        relu_default_157 = torch.ops.aten.relu.default(getitem_405);  getitem_405 = None
        convolution_default_158 = torch.ops.aten.convolution.default(relu_default_157, primals_358, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_357, primals_353, primals_355, primals_356, True, 0.1, 0.001);  primals_353 = None
        getitem_408 = native_batch_norm_default_134[0]
        getitem_409 = native_batch_norm_default_134[1]
        getitem_410 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        relu_default_158 = torch.ops.aten.relu.default(getitem_408);  getitem_408 = None
        convolution_default_159 = torch.ops.aten.convolution.default(relu_default_158, primals_364, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_159, primals_363, primals_359, primals_361, primals_362, True, 0.1, 0.001);  primals_359 = None
        getitem_411 = native_batch_norm_default_135[0]
        getitem_412 = native_batch_norm_default_135[1]
        getitem_413 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        relu_default_159 = torch.ops.aten.relu.default(getitem_411);  getitem_411 = None
        cat_default_26 = torch.ops.aten.cat.default([relu_default_156, relu_default_159], 1)
        convolution_default_160 = torch.ops.aten.convolution.default(cat_default_26, primals_366, primals_365, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_365 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(convolution_default_160, 0.1);  convolution_default_160 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_24, relu_default_155);  mul_tensor_24 = None
        relu_default_160 = torch.ops.aten.relu.default(add_tensor_24);  add_tensor_24 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu_default_160, primals_372, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_371, primals_367, primals_369, primals_370, True, 0.1, 0.001);  primals_367 = None
        getitem_414 = native_batch_norm_default_136[0]
        getitem_415 = native_batch_norm_default_136[1]
        getitem_416 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        relu_default_161 = torch.ops.aten.relu.default(getitem_414);  getitem_414 = None
        convolution_default_162 = torch.ops.aten.convolution.default(relu_default_160, primals_378, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_377, primals_373, primals_375, primals_376, True, 0.1, 0.001);  primals_373 = None
        getitem_417 = native_batch_norm_default_137[0]
        getitem_418 = native_batch_norm_default_137[1]
        getitem_419 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        relu_default_162 = torch.ops.aten.relu.default(getitem_417);  getitem_417 = None
        convolution_default_163 = torch.ops.aten.convolution.default(relu_default_162, primals_384, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_383, primals_379, primals_381, primals_382, True, 0.1, 0.001);  primals_379 = None
        getitem_420 = native_batch_norm_default_138[0]
        getitem_421 = native_batch_norm_default_138[1]
        getitem_422 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        relu_default_163 = torch.ops.aten.relu.default(getitem_420);  getitem_420 = None
        convolution_default_164 = torch.ops.aten.convolution.default(relu_default_163, primals_390, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_164, primals_389, primals_385, primals_387, primals_388, True, 0.1, 0.001);  primals_385 = None
        getitem_423 = native_batch_norm_default_139[0]
        getitem_424 = native_batch_norm_default_139[1]
        getitem_425 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        relu_default_164 = torch.ops.aten.relu.default(getitem_423);  getitem_423 = None
        cat_default_27 = torch.ops.aten.cat.default([relu_default_161, relu_default_164], 1)
        convolution_default_165 = torch.ops.aten.convolution.default(cat_default_27, primals_392, primals_391, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_391 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(convolution_default_165, 0.1);  convolution_default_165 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(mul_tensor_25, relu_default_160);  mul_tensor_25 = None
        relu_default_165 = torch.ops.aten.relu.default(add_tensor_25);  add_tensor_25 = None
        convolution_default_166 = torch.ops.aten.convolution.default(relu_default_165, primals_398, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_397, primals_393, primals_395, primals_396, True, 0.1, 0.001);  primals_393 = None
        getitem_426 = native_batch_norm_default_140[0]
        getitem_427 = native_batch_norm_default_140[1]
        getitem_428 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        relu_default_166 = torch.ops.aten.relu.default(getitem_426);  getitem_426 = None
        convolution_default_167 = torch.ops.aten.convolution.default(relu_default_165, primals_404, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_403, primals_399, primals_401, primals_402, True, 0.1, 0.001);  primals_399 = None
        getitem_429 = native_batch_norm_default_141[0]
        getitem_430 = native_batch_norm_default_141[1]
        getitem_431 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        relu_default_167 = torch.ops.aten.relu.default(getitem_429);  getitem_429 = None
        convolution_default_168 = torch.ops.aten.convolution.default(relu_default_167, primals_410, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_409, primals_405, primals_407, primals_408, True, 0.1, 0.001);  primals_405 = None
        getitem_432 = native_batch_norm_default_142[0]
        getitem_433 = native_batch_norm_default_142[1]
        getitem_434 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        relu_default_168 = torch.ops.aten.relu.default(getitem_432);  getitem_432 = None
        convolution_default_169 = torch.ops.aten.convolution.default(relu_default_168, primals_416, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_169, primals_415, primals_411, primals_413, primals_414, True, 0.1, 0.001);  primals_411 = None
        getitem_435 = native_batch_norm_default_143[0]
        getitem_436 = native_batch_norm_default_143[1]
        getitem_437 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        relu_default_169 = torch.ops.aten.relu.default(getitem_435);  getitem_435 = None
        cat_default_28 = torch.ops.aten.cat.default([relu_default_166, relu_default_169], 1)
        convolution_default_170 = torch.ops.aten.convolution.default(cat_default_28, primals_418, primals_417, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_417 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(convolution_default_170, 0.1);  convolution_default_170 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_26, relu_default_165);  mul_tensor_26 = None
        relu_default_170 = torch.ops.aten.relu.default(add_tensor_26);  add_tensor_26 = None
        convolution_default_171 = torch.ops.aten.convolution.default(relu_default_170, primals_424, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_171, primals_423, primals_419, primals_421, primals_422, True, 0.1, 0.001);  primals_419 = None
        getitem_438 = native_batch_norm_default_144[0]
        getitem_439 = native_batch_norm_default_144[1]
        getitem_440 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        relu_default_171 = torch.ops.aten.relu.default(getitem_438);  getitem_438 = None
        convolution_default_172 = torch.ops.aten.convolution.default(relu_default_170, primals_430, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_172, primals_429, primals_425, primals_427, primals_428, True, 0.1, 0.001);  primals_425 = None
        getitem_441 = native_batch_norm_default_145[0]
        getitem_442 = native_batch_norm_default_145[1]
        getitem_443 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        relu_default_172 = torch.ops.aten.relu.default(getitem_441);  getitem_441 = None
        convolution_default_173 = torch.ops.aten.convolution.default(relu_default_172, primals_436, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_173, primals_435, primals_431, primals_433, primals_434, True, 0.1, 0.001);  primals_431 = None
        getitem_444 = native_batch_norm_default_146[0]
        getitem_445 = native_batch_norm_default_146[1]
        getitem_446 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        relu_default_173 = torch.ops.aten.relu.default(getitem_444);  getitem_444 = None
        convolution_default_174 = torch.ops.aten.convolution.default(relu_default_173, primals_442, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_174, primals_441, primals_437, primals_439, primals_440, True, 0.1, 0.001);  primals_437 = None
        getitem_447 = native_batch_norm_default_147[0]
        getitem_448 = native_batch_norm_default_147[1]
        getitem_449 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        relu_default_174 = torch.ops.aten.relu.default(getitem_447);  getitem_447 = None
        cat_default_29 = torch.ops.aten.cat.default([relu_default_171, relu_default_174], 1)
        convolution_default_175 = torch.ops.aten.convolution.default(cat_default_29, primals_444, primals_443, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_443 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(convolution_default_175, 0.1);  convolution_default_175 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(mul_tensor_27, relu_default_170);  mul_tensor_27 = None
        relu_default_175 = torch.ops.aten.relu.default(add_tensor_27);  add_tensor_27 = None
        convolution_default_176 = torch.ops.aten.convolution.default(relu_default_175, primals_450, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_176, primals_449, primals_445, primals_447, primals_448, True, 0.1, 0.001);  primals_445 = None
        getitem_450 = native_batch_norm_default_148[0]
        getitem_451 = native_batch_norm_default_148[1]
        getitem_452 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        relu_default_176 = torch.ops.aten.relu.default(getitem_450);  getitem_450 = None
        convolution_default_177 = torch.ops.aten.convolution.default(relu_default_175, primals_456, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_177, primals_455, primals_451, primals_453, primals_454, True, 0.1, 0.001);  primals_451 = None
        getitem_453 = native_batch_norm_default_149[0]
        getitem_454 = native_batch_norm_default_149[1]
        getitem_455 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        relu_default_177 = torch.ops.aten.relu.default(getitem_453);  getitem_453 = None
        convolution_default_178 = torch.ops.aten.convolution.default(relu_default_177, primals_462, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_178, primals_461, primals_457, primals_459, primals_460, True, 0.1, 0.001);  primals_457 = None
        getitem_456 = native_batch_norm_default_150[0]
        getitem_457 = native_batch_norm_default_150[1]
        getitem_458 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        relu_default_178 = torch.ops.aten.relu.default(getitem_456);  getitem_456 = None
        convolution_default_179 = torch.ops.aten.convolution.default(relu_default_178, primals_468, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_179, primals_467, primals_463, primals_465, primals_466, True, 0.1, 0.001);  primals_463 = None
        getitem_459 = native_batch_norm_default_151[0]
        getitem_460 = native_batch_norm_default_151[1]
        getitem_461 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        relu_default_179 = torch.ops.aten.relu.default(getitem_459);  getitem_459 = None
        cat_default_30 = torch.ops.aten.cat.default([relu_default_176, relu_default_179], 1)
        convolution_default_180 = torch.ops.aten.convolution.default(cat_default_30, primals_470, primals_469, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_469 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(convolution_default_180, 0.1);  convolution_default_180 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(mul_tensor_28, relu_default_175);  mul_tensor_28 = None
        relu_default_180 = torch.ops.aten.relu.default(add_tensor_28);  add_tensor_28 = None
        convolution_default_181 = torch.ops.aten.convolution.default(relu_default_180, primals_476, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_181, primals_475, primals_471, primals_473, primals_474, True, 0.1, 0.001);  primals_471 = None
        getitem_462 = native_batch_norm_default_152[0]
        getitem_463 = native_batch_norm_default_152[1]
        getitem_464 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        relu_default_181 = torch.ops.aten.relu.default(getitem_462);  getitem_462 = None
        convolution_default_182 = torch.ops.aten.convolution.default(relu_default_180, primals_482, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_182, primals_481, primals_477, primals_479, primals_480, True, 0.1, 0.001);  primals_477 = None
        getitem_465 = native_batch_norm_default_153[0]
        getitem_466 = native_batch_norm_default_153[1]
        getitem_467 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        relu_default_182 = torch.ops.aten.relu.default(getitem_465);  getitem_465 = None
        convolution_default_183 = torch.ops.aten.convolution.default(relu_default_182, primals_488, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_183, primals_487, primals_483, primals_485, primals_486, True, 0.1, 0.001);  primals_483 = None
        getitem_468 = native_batch_norm_default_154[0]
        getitem_469 = native_batch_norm_default_154[1]
        getitem_470 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        relu_default_183 = torch.ops.aten.relu.default(getitem_468);  getitem_468 = None
        convolution_default_184 = torch.ops.aten.convolution.default(relu_default_183, primals_494, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_184, primals_493, primals_489, primals_491, primals_492, True, 0.1, 0.001);  primals_489 = None
        getitem_471 = native_batch_norm_default_155[0]
        getitem_472 = native_batch_norm_default_155[1]
        getitem_473 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        relu_default_184 = torch.ops.aten.relu.default(getitem_471);  getitem_471 = None
        cat_default_31 = torch.ops.aten.cat.default([relu_default_181, relu_default_184], 1)
        convolution_default_185 = torch.ops.aten.convolution.default(cat_default_31, primals_496, primals_495, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_495 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(convolution_default_185, 0.1);  convolution_default_185 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(mul_tensor_29, relu_default_180);  mul_tensor_29 = None
        relu_default_185 = torch.ops.aten.relu.default(add_tensor_29);  add_tensor_29 = None
        convolution_default_186 = torch.ops.aten.convolution.default(relu_default_185, primals_136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_186, primals_135, primals_131, primals_133, primals_134, True, 0.1, 0.001);  primals_131 = None
        getitem_474 = native_batch_norm_default_156[0]
        getitem_475 = native_batch_norm_default_156[1]
        getitem_476 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        relu_default_186 = torch.ops.aten.relu.default(getitem_474);  getitem_474 = None
        convolution_default_187 = torch.ops.aten.convolution.default(relu_default_186, primals_142, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_157 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_141, primals_137, primals_139, primals_140, True, 0.1, 0.001);  primals_137 = None
        getitem_477 = native_batch_norm_default_157[0]
        getitem_478 = native_batch_norm_default_157[1]
        getitem_479 = native_batch_norm_default_157[2];  native_batch_norm_default_157 = None
        relu_default_187 = torch.ops.aten.relu.default(getitem_477);  getitem_477 = None
        convolution_default_188 = torch.ops.aten.convolution.default(relu_default_185, primals_148, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_158 = torch.ops.aten.native_batch_norm.default(convolution_default_188, primals_147, primals_143, primals_145, primals_146, True, 0.1, 0.001);  primals_143 = None
        getitem_480 = native_batch_norm_default_158[0]
        getitem_481 = native_batch_norm_default_158[1]
        getitem_482 = native_batch_norm_default_158[2];  native_batch_norm_default_158 = None
        relu_default_188 = torch.ops.aten.relu.default(getitem_480);  getitem_480 = None
        convolution_default_189 = torch.ops.aten.convolution.default(relu_default_188, primals_154, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_159 = torch.ops.aten.native_batch_norm.default(convolution_default_189, primals_153, primals_149, primals_151, primals_152, True, 0.1, 0.001);  primals_149 = None
        getitem_483 = native_batch_norm_default_159[0]
        getitem_484 = native_batch_norm_default_159[1]
        getitem_485 = native_batch_norm_default_159[2];  native_batch_norm_default_159 = None
        relu_default_189 = torch.ops.aten.relu.default(getitem_483);  getitem_483 = None
        convolution_default_190 = torch.ops.aten.convolution.default(relu_default_185, primals_160, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_160 = torch.ops.aten.native_batch_norm.default(convolution_default_190, primals_159, primals_155, primals_157, primals_158, True, 0.1, 0.001);  primals_155 = None
        getitem_486 = native_batch_norm_default_160[0]
        getitem_487 = native_batch_norm_default_160[1]
        getitem_488 = native_batch_norm_default_160[2];  native_batch_norm_default_160 = None
        relu_default_190 = torch.ops.aten.relu.default(getitem_486);  getitem_486 = None
        convolution_default_191 = torch.ops.aten.convolution.default(relu_default_190, primals_166, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_161 = torch.ops.aten.native_batch_norm.default(convolution_default_191, primals_165, primals_161, primals_163, primals_164, True, 0.1, 0.001);  primals_161 = None
        getitem_489 = native_batch_norm_default_161[0]
        getitem_490 = native_batch_norm_default_161[1]
        getitem_491 = native_batch_norm_default_161[2];  native_batch_norm_default_161 = None
        relu_default_191 = torch.ops.aten.relu.default(getitem_489);  getitem_489 = None
        convolution_default_192 = torch.ops.aten.convolution.default(relu_default_191, primals_172, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_162 = torch.ops.aten.native_batch_norm.default(convolution_default_192, primals_171, primals_167, primals_169, primals_170, True, 0.1, 0.001);  primals_167 = None
        getitem_492 = native_batch_norm_default_162[0]
        getitem_493 = native_batch_norm_default_162[1]
        getitem_494 = native_batch_norm_default_162[2];  native_batch_norm_default_162 = None
        relu_default_192 = torch.ops.aten.relu.default(getitem_492);  getitem_492 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(relu_default_185, [3, 3], [2, 2])
        getitem_495 = max_pool2d_with_indices_default_3[0]
        getitem_496 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        cat_default_32 = torch.ops.aten.cat.default([relu_default_187, relu_default_189, relu_default_192, getitem_495], 1);  getitem_495 = None
        convolution_default_193 = torch.ops.aten.convolution.default(cat_default_32, primals_774, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_163 = torch.ops.aten.native_batch_norm.default(convolution_default_193, primals_773, primals_769, primals_771, primals_772, True, 0.1, 0.001);  primals_769 = None
        getitem_497 = native_batch_norm_default_163[0]
        getitem_498 = native_batch_norm_default_163[1]
        getitem_499 = native_batch_norm_default_163[2];  native_batch_norm_default_163 = None
        relu_default_193 = torch.ops.aten.relu.default(getitem_497);  getitem_497 = None
        convolution_default_194 = torch.ops.aten.convolution.default(cat_default_32, primals_780, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_164 = torch.ops.aten.native_batch_norm.default(convolution_default_194, primals_779, primals_775, primals_777, primals_778, True, 0.1, 0.001);  primals_775 = None
        getitem_500 = native_batch_norm_default_164[0]
        getitem_501 = native_batch_norm_default_164[1]
        getitem_502 = native_batch_norm_default_164[2];  native_batch_norm_default_164 = None
        relu_default_194 = torch.ops.aten.relu.default(getitem_500);  getitem_500 = None
        convolution_default_195 = torch.ops.aten.convolution.default(relu_default_194, primals_786, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_165 = torch.ops.aten.native_batch_norm.default(convolution_default_195, primals_785, primals_781, primals_783, primals_784, True, 0.1, 0.001);  primals_781 = None
        getitem_503 = native_batch_norm_default_165[0]
        getitem_504 = native_batch_norm_default_165[1]
        getitem_505 = native_batch_norm_default_165[2];  native_batch_norm_default_165 = None
        relu_default_195 = torch.ops.aten.relu.default(getitem_503);  getitem_503 = None
        convolution_default_196 = torch.ops.aten.convolution.default(relu_default_195, primals_792, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_166 = torch.ops.aten.native_batch_norm.default(convolution_default_196, primals_791, primals_787, primals_789, primals_790, True, 0.1, 0.001);  primals_787 = None
        getitem_506 = native_batch_norm_default_166[0]
        getitem_507 = native_batch_norm_default_166[1]
        getitem_508 = native_batch_norm_default_166[2];  native_batch_norm_default_166 = None
        relu_default_196 = torch.ops.aten.relu.default(getitem_506);  getitem_506 = None
        cat_default_33 = torch.ops.aten.cat.default([relu_default_193, relu_default_196], 1)
        convolution_default_197 = torch.ops.aten.convolution.default(cat_default_33, primals_794, primals_793, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_793 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(convolution_default_197, 0.2);  convolution_default_197 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_30, cat_default_32);  mul_tensor_30 = None
        relu_default_197 = torch.ops.aten.relu.default(add_tensor_30);  add_tensor_30 = None
        convolution_default_198 = torch.ops.aten.convolution.default(relu_default_197, primals_800, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_167 = torch.ops.aten.native_batch_norm.default(convolution_default_198, primals_799, primals_795, primals_797, primals_798, True, 0.1, 0.001);  primals_795 = None
        getitem_509 = native_batch_norm_default_167[0]
        getitem_510 = native_batch_norm_default_167[1]
        getitem_511 = native_batch_norm_default_167[2];  native_batch_norm_default_167 = None
        relu_default_198 = torch.ops.aten.relu.default(getitem_509);  getitem_509 = None
        convolution_default_199 = torch.ops.aten.convolution.default(relu_default_197, primals_806, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_168 = torch.ops.aten.native_batch_norm.default(convolution_default_199, primals_805, primals_801, primals_803, primals_804, True, 0.1, 0.001);  primals_801 = None
        getitem_512 = native_batch_norm_default_168[0]
        getitem_513 = native_batch_norm_default_168[1]
        getitem_514 = native_batch_norm_default_168[2];  native_batch_norm_default_168 = None
        relu_default_199 = torch.ops.aten.relu.default(getitem_512);  getitem_512 = None
        convolution_default_200 = torch.ops.aten.convolution.default(relu_default_199, primals_812, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_169 = torch.ops.aten.native_batch_norm.default(convolution_default_200, primals_811, primals_807, primals_809, primals_810, True, 0.1, 0.001);  primals_807 = None
        getitem_515 = native_batch_norm_default_169[0]
        getitem_516 = native_batch_norm_default_169[1]
        getitem_517 = native_batch_norm_default_169[2];  native_batch_norm_default_169 = None
        relu_default_200 = torch.ops.aten.relu.default(getitem_515);  getitem_515 = None
        convolution_default_201 = torch.ops.aten.convolution.default(relu_default_200, primals_818, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_170 = torch.ops.aten.native_batch_norm.default(convolution_default_201, primals_817, primals_813, primals_815, primals_816, True, 0.1, 0.001);  primals_813 = None
        getitem_518 = native_batch_norm_default_170[0]
        getitem_519 = native_batch_norm_default_170[1]
        getitem_520 = native_batch_norm_default_170[2];  native_batch_norm_default_170 = None
        relu_default_201 = torch.ops.aten.relu.default(getitem_518);  getitem_518 = None
        cat_default_34 = torch.ops.aten.cat.default([relu_default_198, relu_default_201], 1)
        convolution_default_202 = torch.ops.aten.convolution.default(cat_default_34, primals_820, primals_819, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_819 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(convolution_default_202, 0.2);  convolution_default_202 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(mul_tensor_31, relu_default_197);  mul_tensor_31 = None
        relu_default_202 = torch.ops.aten.relu.default(add_tensor_31);  add_tensor_31 = None
        convolution_default_203 = torch.ops.aten.convolution.default(relu_default_202, primals_826, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_171 = torch.ops.aten.native_batch_norm.default(convolution_default_203, primals_825, primals_821, primals_823, primals_824, True, 0.1, 0.001);  primals_821 = None
        getitem_521 = native_batch_norm_default_171[0]
        getitem_522 = native_batch_norm_default_171[1]
        getitem_523 = native_batch_norm_default_171[2];  native_batch_norm_default_171 = None
        relu_default_203 = torch.ops.aten.relu.default(getitem_521);  getitem_521 = None
        convolution_default_204 = torch.ops.aten.convolution.default(relu_default_202, primals_832, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_172 = torch.ops.aten.native_batch_norm.default(convolution_default_204, primals_831, primals_827, primals_829, primals_830, True, 0.1, 0.001);  primals_827 = None
        getitem_524 = native_batch_norm_default_172[0]
        getitem_525 = native_batch_norm_default_172[1]
        getitem_526 = native_batch_norm_default_172[2];  native_batch_norm_default_172 = None
        relu_default_204 = torch.ops.aten.relu.default(getitem_524);  getitem_524 = None
        convolution_default_205 = torch.ops.aten.convolution.default(relu_default_204, primals_838, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_173 = torch.ops.aten.native_batch_norm.default(convolution_default_205, primals_837, primals_833, primals_835, primals_836, True, 0.1, 0.001);  primals_833 = None
        getitem_527 = native_batch_norm_default_173[0]
        getitem_528 = native_batch_norm_default_173[1]
        getitem_529 = native_batch_norm_default_173[2];  native_batch_norm_default_173 = None
        relu_default_205 = torch.ops.aten.relu.default(getitem_527);  getitem_527 = None
        convolution_default_206 = torch.ops.aten.convolution.default(relu_default_205, primals_844, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_174 = torch.ops.aten.native_batch_norm.default(convolution_default_206, primals_843, primals_839, primals_841, primals_842, True, 0.1, 0.001);  primals_839 = None
        getitem_530 = native_batch_norm_default_174[0]
        getitem_531 = native_batch_norm_default_174[1]
        getitem_532 = native_batch_norm_default_174[2];  native_batch_norm_default_174 = None
        relu_default_206 = torch.ops.aten.relu.default(getitem_530);  getitem_530 = None
        cat_default_35 = torch.ops.aten.cat.default([relu_default_203, relu_default_206], 1)
        convolution_default_207 = torch.ops.aten.convolution.default(cat_default_35, primals_846, primals_845, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_845 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(convolution_default_207, 0.2);  convolution_default_207 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_32, relu_default_202);  mul_tensor_32 = None
        relu_default_207 = torch.ops.aten.relu.default(add_tensor_32);  add_tensor_32 = None
        convolution_default_208 = torch.ops.aten.convolution.default(relu_default_207, primals_852, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_175 = torch.ops.aten.native_batch_norm.default(convolution_default_208, primals_851, primals_847, primals_849, primals_850, True, 0.1, 0.001);  primals_847 = None
        getitem_533 = native_batch_norm_default_175[0]
        getitem_534 = native_batch_norm_default_175[1]
        getitem_535 = native_batch_norm_default_175[2];  native_batch_norm_default_175 = None
        relu_default_208 = torch.ops.aten.relu.default(getitem_533);  getitem_533 = None
        convolution_default_209 = torch.ops.aten.convolution.default(relu_default_207, primals_858, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_176 = torch.ops.aten.native_batch_norm.default(convolution_default_209, primals_857, primals_853, primals_855, primals_856, True, 0.1, 0.001);  primals_853 = None
        getitem_536 = native_batch_norm_default_176[0]
        getitem_537 = native_batch_norm_default_176[1]
        getitem_538 = native_batch_norm_default_176[2];  native_batch_norm_default_176 = None
        relu_default_209 = torch.ops.aten.relu.default(getitem_536);  getitem_536 = None
        convolution_default_210 = torch.ops.aten.convolution.default(relu_default_209, primals_864, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_177 = torch.ops.aten.native_batch_norm.default(convolution_default_210, primals_863, primals_859, primals_861, primals_862, True, 0.1, 0.001);  primals_859 = None
        getitem_539 = native_batch_norm_default_177[0]
        getitem_540 = native_batch_norm_default_177[1]
        getitem_541 = native_batch_norm_default_177[2];  native_batch_norm_default_177 = None
        relu_default_210 = torch.ops.aten.relu.default(getitem_539);  getitem_539 = None
        convolution_default_211 = torch.ops.aten.convolution.default(relu_default_210, primals_870, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_178 = torch.ops.aten.native_batch_norm.default(convolution_default_211, primals_869, primals_865, primals_867, primals_868, True, 0.1, 0.001);  primals_865 = None
        getitem_542 = native_batch_norm_default_178[0]
        getitem_543 = native_batch_norm_default_178[1]
        getitem_544 = native_batch_norm_default_178[2];  native_batch_norm_default_178 = None
        relu_default_211 = torch.ops.aten.relu.default(getitem_542);  getitem_542 = None
        cat_default_36 = torch.ops.aten.cat.default([relu_default_208, relu_default_211], 1)
        convolution_default_212 = torch.ops.aten.convolution.default(cat_default_36, primals_872, primals_871, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_871 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(convolution_default_212, 0.2);  convolution_default_212 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(mul_tensor_33, relu_default_207);  mul_tensor_33 = None
        relu_default_212 = torch.ops.aten.relu.default(add_tensor_33);  add_tensor_33 = None
        convolution_default_213 = torch.ops.aten.convolution.default(relu_default_212, primals_878, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_179 = torch.ops.aten.native_batch_norm.default(convolution_default_213, primals_877, primals_873, primals_875, primals_876, True, 0.1, 0.001);  primals_873 = None
        getitem_545 = native_batch_norm_default_179[0]
        getitem_546 = native_batch_norm_default_179[1]
        getitem_547 = native_batch_norm_default_179[2];  native_batch_norm_default_179 = None
        relu_default_213 = torch.ops.aten.relu.default(getitem_545);  getitem_545 = None
        convolution_default_214 = torch.ops.aten.convolution.default(relu_default_212, primals_884, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_180 = torch.ops.aten.native_batch_norm.default(convolution_default_214, primals_883, primals_879, primals_881, primals_882, True, 0.1, 0.001);  primals_879 = None
        getitem_548 = native_batch_norm_default_180[0]
        getitem_549 = native_batch_norm_default_180[1]
        getitem_550 = native_batch_norm_default_180[2];  native_batch_norm_default_180 = None
        relu_default_214 = torch.ops.aten.relu.default(getitem_548);  getitem_548 = None
        convolution_default_215 = torch.ops.aten.convolution.default(relu_default_214, primals_890, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_181 = torch.ops.aten.native_batch_norm.default(convolution_default_215, primals_889, primals_885, primals_887, primals_888, True, 0.1, 0.001);  primals_885 = None
        getitem_551 = native_batch_norm_default_181[0]
        getitem_552 = native_batch_norm_default_181[1]
        getitem_553 = native_batch_norm_default_181[2];  native_batch_norm_default_181 = None
        relu_default_215 = torch.ops.aten.relu.default(getitem_551);  getitem_551 = None
        convolution_default_216 = torch.ops.aten.convolution.default(relu_default_215, primals_896, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_182 = torch.ops.aten.native_batch_norm.default(convolution_default_216, primals_895, primals_891, primals_893, primals_894, True, 0.1, 0.001);  primals_891 = None
        getitem_554 = native_batch_norm_default_182[0]
        getitem_555 = native_batch_norm_default_182[1]
        getitem_556 = native_batch_norm_default_182[2];  native_batch_norm_default_182 = None
        relu_default_216 = torch.ops.aten.relu.default(getitem_554);  getitem_554 = None
        cat_default_37 = torch.ops.aten.cat.default([relu_default_213, relu_default_216], 1)
        convolution_default_217 = torch.ops.aten.convolution.default(cat_default_37, primals_898, primals_897, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_897 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(convolution_default_217, 0.2);  convolution_default_217 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(mul_tensor_34, relu_default_212);  mul_tensor_34 = None
        relu_default_217 = torch.ops.aten.relu.default(add_tensor_34);  add_tensor_34 = None
        convolution_default_218 = torch.ops.aten.convolution.default(relu_default_217, primals_904, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_183 = torch.ops.aten.native_batch_norm.default(convolution_default_218, primals_903, primals_899, primals_901, primals_902, True, 0.1, 0.001);  primals_899 = None
        getitem_557 = native_batch_norm_default_183[0]
        getitem_558 = native_batch_norm_default_183[1]
        getitem_559 = native_batch_norm_default_183[2];  native_batch_norm_default_183 = None
        relu_default_218 = torch.ops.aten.relu.default(getitem_557);  getitem_557 = None
        convolution_default_219 = torch.ops.aten.convolution.default(relu_default_217, primals_910, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_184 = torch.ops.aten.native_batch_norm.default(convolution_default_219, primals_909, primals_905, primals_907, primals_908, True, 0.1, 0.001);  primals_905 = None
        getitem_560 = native_batch_norm_default_184[0]
        getitem_561 = native_batch_norm_default_184[1]
        getitem_562 = native_batch_norm_default_184[2];  native_batch_norm_default_184 = None
        relu_default_219 = torch.ops.aten.relu.default(getitem_560);  getitem_560 = None
        convolution_default_220 = torch.ops.aten.convolution.default(relu_default_219, primals_916, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_185 = torch.ops.aten.native_batch_norm.default(convolution_default_220, primals_915, primals_911, primals_913, primals_914, True, 0.1, 0.001);  primals_911 = None
        getitem_563 = native_batch_norm_default_185[0]
        getitem_564 = native_batch_norm_default_185[1]
        getitem_565 = native_batch_norm_default_185[2];  native_batch_norm_default_185 = None
        relu_default_220 = torch.ops.aten.relu.default(getitem_563);  getitem_563 = None
        convolution_default_221 = torch.ops.aten.convolution.default(relu_default_220, primals_922, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_186 = torch.ops.aten.native_batch_norm.default(convolution_default_221, primals_921, primals_917, primals_919, primals_920, True, 0.1, 0.001);  primals_917 = None
        getitem_566 = native_batch_norm_default_186[0]
        getitem_567 = native_batch_norm_default_186[1]
        getitem_568 = native_batch_norm_default_186[2];  native_batch_norm_default_186 = None
        relu_default_221 = torch.ops.aten.relu.default(getitem_566);  getitem_566 = None
        cat_default_38 = torch.ops.aten.cat.default([relu_default_218, relu_default_221], 1)
        convolution_default_222 = torch.ops.aten.convolution.default(cat_default_38, primals_924, primals_923, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_923 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(convolution_default_222, 0.2);  convolution_default_222 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(mul_tensor_35, relu_default_217);  mul_tensor_35 = None
        relu_default_222 = torch.ops.aten.relu.default(add_tensor_35);  add_tensor_35 = None
        convolution_default_223 = torch.ops.aten.convolution.default(relu_default_222, primals_930, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_187 = torch.ops.aten.native_batch_norm.default(convolution_default_223, primals_929, primals_925, primals_927, primals_928, True, 0.1, 0.001);  primals_925 = None
        getitem_569 = native_batch_norm_default_187[0]
        getitem_570 = native_batch_norm_default_187[1]
        getitem_571 = native_batch_norm_default_187[2];  native_batch_norm_default_187 = None
        relu_default_223 = torch.ops.aten.relu.default(getitem_569);  getitem_569 = None
        convolution_default_224 = torch.ops.aten.convolution.default(relu_default_222, primals_936, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_188 = torch.ops.aten.native_batch_norm.default(convolution_default_224, primals_935, primals_931, primals_933, primals_934, True, 0.1, 0.001);  primals_931 = None
        getitem_572 = native_batch_norm_default_188[0]
        getitem_573 = native_batch_norm_default_188[1]
        getitem_574 = native_batch_norm_default_188[2];  native_batch_norm_default_188 = None
        relu_default_224 = torch.ops.aten.relu.default(getitem_572);  getitem_572 = None
        convolution_default_225 = torch.ops.aten.convolution.default(relu_default_224, primals_942, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_189 = torch.ops.aten.native_batch_norm.default(convolution_default_225, primals_941, primals_937, primals_939, primals_940, True, 0.1, 0.001);  primals_937 = None
        getitem_575 = native_batch_norm_default_189[0]
        getitem_576 = native_batch_norm_default_189[1]
        getitem_577 = native_batch_norm_default_189[2];  native_batch_norm_default_189 = None
        relu_default_225 = torch.ops.aten.relu.default(getitem_575);  getitem_575 = None
        convolution_default_226 = torch.ops.aten.convolution.default(relu_default_225, primals_948, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_190 = torch.ops.aten.native_batch_norm.default(convolution_default_226, primals_947, primals_943, primals_945, primals_946, True, 0.1, 0.001);  primals_943 = None
        getitem_578 = native_batch_norm_default_190[0]
        getitem_579 = native_batch_norm_default_190[1]
        getitem_580 = native_batch_norm_default_190[2];  native_batch_norm_default_190 = None
        relu_default_226 = torch.ops.aten.relu.default(getitem_578);  getitem_578 = None
        cat_default_39 = torch.ops.aten.cat.default([relu_default_223, relu_default_226], 1)
        convolution_default_227 = torch.ops.aten.convolution.default(cat_default_39, primals_950, primals_949, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_949 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(convolution_default_227, 0.2);  convolution_default_227 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(mul_tensor_36, relu_default_222);  mul_tensor_36 = None
        relu_default_227 = torch.ops.aten.relu.default(add_tensor_36);  add_tensor_36 = None
        convolution_default_228 = torch.ops.aten.convolution.default(relu_default_227, primals_956, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_191 = torch.ops.aten.native_batch_norm.default(convolution_default_228, primals_955, primals_951, primals_953, primals_954, True, 0.1, 0.001);  primals_951 = None
        getitem_581 = native_batch_norm_default_191[0]
        getitem_582 = native_batch_norm_default_191[1]
        getitem_583 = native_batch_norm_default_191[2];  native_batch_norm_default_191 = None
        relu_default_228 = torch.ops.aten.relu.default(getitem_581);  getitem_581 = None
        convolution_default_229 = torch.ops.aten.convolution.default(relu_default_227, primals_962, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_192 = torch.ops.aten.native_batch_norm.default(convolution_default_229, primals_961, primals_957, primals_959, primals_960, True, 0.1, 0.001);  primals_957 = None
        getitem_584 = native_batch_norm_default_192[0]
        getitem_585 = native_batch_norm_default_192[1]
        getitem_586 = native_batch_norm_default_192[2];  native_batch_norm_default_192 = None
        relu_default_229 = torch.ops.aten.relu.default(getitem_584);  getitem_584 = None
        convolution_default_230 = torch.ops.aten.convolution.default(relu_default_229, primals_968, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_193 = torch.ops.aten.native_batch_norm.default(convolution_default_230, primals_967, primals_963, primals_965, primals_966, True, 0.1, 0.001);  primals_963 = None
        getitem_587 = native_batch_norm_default_193[0]
        getitem_588 = native_batch_norm_default_193[1]
        getitem_589 = native_batch_norm_default_193[2];  native_batch_norm_default_193 = None
        relu_default_230 = torch.ops.aten.relu.default(getitem_587);  getitem_587 = None
        convolution_default_231 = torch.ops.aten.convolution.default(relu_default_230, primals_974, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_194 = torch.ops.aten.native_batch_norm.default(convolution_default_231, primals_973, primals_969, primals_971, primals_972, True, 0.1, 0.001);  primals_969 = None
        getitem_590 = native_batch_norm_default_194[0]
        getitem_591 = native_batch_norm_default_194[1]
        getitem_592 = native_batch_norm_default_194[2];  native_batch_norm_default_194 = None
        relu_default_231 = torch.ops.aten.relu.default(getitem_590);  getitem_590 = None
        cat_default_40 = torch.ops.aten.cat.default([relu_default_228, relu_default_231], 1)
        convolution_default_232 = torch.ops.aten.convolution.default(cat_default_40, primals_976, primals_975, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_975 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(convolution_default_232, 0.2);  convolution_default_232 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(mul_tensor_37, relu_default_227);  mul_tensor_37 = None
        relu_default_232 = torch.ops.aten.relu.default(add_tensor_37);  add_tensor_37 = None
        convolution_default_233 = torch.ops.aten.convolution.default(relu_default_232, primals_982, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_195 = torch.ops.aten.native_batch_norm.default(convolution_default_233, primals_981, primals_977, primals_979, primals_980, True, 0.1, 0.001);  primals_977 = None
        getitem_593 = native_batch_norm_default_195[0]
        getitem_594 = native_batch_norm_default_195[1]
        getitem_595 = native_batch_norm_default_195[2];  native_batch_norm_default_195 = None
        relu_default_233 = torch.ops.aten.relu.default(getitem_593);  getitem_593 = None
        convolution_default_234 = torch.ops.aten.convolution.default(relu_default_232, primals_988, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_196 = torch.ops.aten.native_batch_norm.default(convolution_default_234, primals_987, primals_983, primals_985, primals_986, True, 0.1, 0.001);  primals_983 = None
        getitem_596 = native_batch_norm_default_196[0]
        getitem_597 = native_batch_norm_default_196[1]
        getitem_598 = native_batch_norm_default_196[2];  native_batch_norm_default_196 = None
        relu_default_234 = torch.ops.aten.relu.default(getitem_596);  getitem_596 = None
        convolution_default_235 = torch.ops.aten.convolution.default(relu_default_234, primals_994, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_197 = torch.ops.aten.native_batch_norm.default(convolution_default_235, primals_993, primals_989, primals_991, primals_992, True, 0.1, 0.001);  primals_989 = None
        getitem_599 = native_batch_norm_default_197[0]
        getitem_600 = native_batch_norm_default_197[1]
        getitem_601 = native_batch_norm_default_197[2];  native_batch_norm_default_197 = None
        relu_default_235 = torch.ops.aten.relu.default(getitem_599);  getitem_599 = None
        convolution_default_236 = torch.ops.aten.convolution.default(relu_default_235, primals_1000, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_198 = torch.ops.aten.native_batch_norm.default(convolution_default_236, primals_999, primals_995, primals_997, primals_998, True, 0.1, 0.001);  primals_995 = None
        getitem_602 = native_batch_norm_default_198[0]
        getitem_603 = native_batch_norm_default_198[1]
        getitem_604 = native_batch_norm_default_198[2];  native_batch_norm_default_198 = None
        relu_default_236 = torch.ops.aten.relu.default(getitem_602);  getitem_602 = None
        cat_default_41 = torch.ops.aten.cat.default([relu_default_233, relu_default_236], 1)
        convolution_default_237 = torch.ops.aten.convolution.default(cat_default_41, primals_1002, primals_1001, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1001 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(convolution_default_237, 0.2);  convolution_default_237 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_38, relu_default_232);  mul_tensor_38 = None
        relu_default_237 = torch.ops.aten.relu.default(add_tensor_38);  add_tensor_38 = None
        convolution_default_238 = torch.ops.aten.convolution.default(relu_default_237, primals_6, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_199 = torch.ops.aten.native_batch_norm.default(convolution_default_238, primals_5, primals_1, primals_3, primals_4, True, 0.1, 0.001);  primals_1 = None
        getitem_605 = native_batch_norm_default_199[0]
        getitem_606 = native_batch_norm_default_199[1]
        getitem_607 = native_batch_norm_default_199[2];  native_batch_norm_default_199 = None
        relu_default_238 = torch.ops.aten.relu.default(getitem_605);  getitem_605 = None
        convolution_default_239 = torch.ops.aten.convolution.default(relu_default_237, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_200 = torch.ops.aten.native_batch_norm.default(convolution_default_239, primals_11, primals_7, primals_9, primals_10, True, 0.1, 0.001);  primals_7 = None
        getitem_608 = native_batch_norm_default_200[0]
        getitem_609 = native_batch_norm_default_200[1]
        getitem_610 = native_batch_norm_default_200[2];  native_batch_norm_default_200 = None
        relu_default_239 = torch.ops.aten.relu.default(getitem_608);  getitem_608 = None
        convolution_default_240 = torch.ops.aten.convolution.default(relu_default_239, primals_18, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_201 = torch.ops.aten.native_batch_norm.default(convolution_default_240, primals_17, primals_13, primals_15, primals_16, True, 0.1, 0.001);  primals_13 = None
        getitem_611 = native_batch_norm_default_201[0]
        getitem_612 = native_batch_norm_default_201[1]
        getitem_613 = native_batch_norm_default_201[2];  native_batch_norm_default_201 = None
        relu_default_240 = torch.ops.aten.relu.default(getitem_611);  getitem_611 = None
        convolution_default_241 = torch.ops.aten.convolution.default(relu_default_240, primals_24, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_202 = torch.ops.aten.native_batch_norm.default(convolution_default_241, primals_23, primals_19, primals_21, primals_22, True, 0.1, 0.001);  primals_19 = None
        getitem_614 = native_batch_norm_default_202[0]
        getitem_615 = native_batch_norm_default_202[1]
        getitem_616 = native_batch_norm_default_202[2];  native_batch_norm_default_202 = None
        relu_default_241 = torch.ops.aten.relu.default(getitem_614);  getitem_614 = None
        cat_default_42 = torch.ops.aten.cat.default([relu_default_238, relu_default_241], 1)
        convolution_default_242 = torch.ops.aten.convolution.default(cat_default_42, primals_26, primals_25, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_25 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(convolution_default_242, 1.0);  convolution_default_242 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(mul_tensor_39, relu_default_237);  mul_tensor_39 = None
        convolution_default_243 = torch.ops.aten.convolution.default(add_tensor_39, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_203 = torch.ops.aten.native_batch_norm.default(convolution_default_243, primals_63, primals_59, primals_61, primals_62, True, 0.1, 0.001);  primals_59 = None
        getitem_617 = native_batch_norm_default_203[0]
        getitem_618 = native_batch_norm_default_203[1]
        getitem_619 = native_batch_norm_default_203[2];  native_batch_norm_default_203 = None
        relu_default_242 = torch.ops.aten.relu.default(getitem_617);  getitem_617 = None
        mean_dim = torch.ops.aten.mean.dim(relu_default_242, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 1536]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_28);  primals_28 = None
        addmm_default = torch.ops.aten.addmm.default(primals_27, view_default, t_default);  primals_27 = None
        return [addmm_default, primals_1254, getitem_93, primals_987, relu_default_13, getitem_92, primals_991, cat_default_3, relu_default_156, primals_1159, getitem_559, getitem_558, primals_1257, primals_998, relu_default_31, getitem_326, getitem_325, primals_1258, primals_418, getitem_48, primals_404, primals_1259, getitem_47, getitem_407, primals_1000, relu_default_218, primals_1172, getitem_406, primals_1260, primals_1171, relu_default_123, primals_994, primals_1170, relu_default_32, relu_default_14, convolution_default_219, relu_default_157, primals_415, primals_1263, primals_992, convolution_default_124, cat_default_19, primals_1157, primals_1264, convolution_default_33, convolution_default_15, primals_1265, primals_409, primals_1160, convolution_default_158, getitem_561, primals_1266, primals_408, getitem_329, primals_1158, primals_407, getitem_328, primals_413, primals_1002, primals_1268, getitem_50, relu_default_219, convolution_default_34, getitem_95, getitem_409, primals_1163, getitem_51, primals_414, primals_999, getitem_96, primals_1169, relu_default_124, getitem_410, primals_993, primals_416, primals_1154, primals_997, primals_1165, primals_1271, relu_default_15, convolution_default_220, relu_default_158, primals_1164, relu_default_33, primals_1272, primals_1166, primals_1273, primals_410, primals_986, primals_985, primals_988, primals_1274, convolution_default_16, convolution_default_126, convolution_default_159, primals_403, primals_1013, primals_1017, getitem_604, getitem_603, primals_1014, relu_default_236, cat_default_41, primals_1020, primals_1023, relu_default_237, primals_1012, convolution_default_238, primals_1008, primals_1007, primals_1011, getitem_606, getitem_607, primals_1006, primals_1005, primals_1019, primals_1018, primals_165, primals_719, primals_159, getitem_494, primals_534, relu_default_148, primals_532, primals_721, primals_806, primals_153, primals_720, primals_804, primals_154, relu_default_192, primals_726, primals_548, primals_799, getitem_27, getitem_26, getitem_389, getitem_388, primals_151, primals_152, getitem_496, primals_812, primals_803, relu_default_7, convolution_default_193, primals_163, relu_default_149, getitem_499, primals_727, primals_736, primals_735, primals_805, convolution_default_8, getitem_498, cat_default_24, primals_540, primals_538, primals_725, primals_533, convolution_default, getitem_30, primals_809, primals_164, getitem_29, relu_default_193, primals_722, primals_798, primals_531, relu_default_150, primals_797, primals_157, primals_537, primals_810, relu_default_8, primals_733, convolution_default_194, primals_539, primals_730, primals_811, primals_544, primals_800, primals_545, primals_734, convolution_default_151, primals_543, primals_728, primals_546, convolution_default_9, getitem_391, getitem_501, primals_160, convolution_default_234, primals_158, getitem_222, primals_254, getitem_221, getitem_245, cat_default_12, getitem_541, getitem_540, getitem_244, relu_default_82, primals_260, relu_default_89, primals_262, relu_default_210, convolution_default_83, convolution_default_211, cat_default_36, getitem_225, getitem_224, relu_default_90, getitem_544, primals_272, getitem_543, primals_266, relu_default_83, primals_257, primals_265, convolution_default_91, relu_default_211, primals_273, primals_366, primals_258, convolution_default_84, primals_271, convolution_default_92, primals_369, primals_363, convolution_default_213, getitem_247, primals_268, primals_364, getitem_248, primals_361, getitem_227, relu_default_212, primals_267, getitem_228, relu_default_91, primals_259, primals_362, relu_default_56, getitem_431, getitem_430, convolution_default_116, getitem_159, getitem_158, relu_default_115, relu_default_167, getitem_308, relu_default_57, convolution_default_168, getitem_307, convolution_default_58, getitem_434, relu_default_116, getitem_433, getitem_162, getitem_161, relu_default_168, convolution_default_117, relu_default_58, convolution_default_169, getitem_310, getitem_311, convolution_default_59, getitem_583, primals_43, primals_966, getitem_368, primals_1112, primals_971, primals_1105, getitem_367, relu_default_228, primals_974, primals_1102, relu_default_141, primals_1096, convolution_default_229, primals_979, primals_1101, primals_1113, primals_1095, primals_45, getitem_582, convolution_default_142, primals_56, getitem_586, primals_981, primals_1106, getitem_585, primals_49, getitem_371, getitem_370, primals_976, primals_980, relu_default_229, primals_1114, relu_default_142, primals_1111, primals_44, convolution_default_230, primals_968, primals_57, primals_1108, primals_50, primals_58, primals_967, primals_1099, convolution_default_143, primals_1100, getitem_588, primals_51, primals_972, primals_973, convolution_default_157, primals_1107, primals_52, primals_55, convolution_default_231, primals_982, getitem_373, getitem_589, primals_46, primals_965, primals_387, primals_384, relu_default_23, getitem_138, cat_default_2, primals_1277, getitem_137, primals_378, primals_1278, primals_1279, relu_default_49, convolution_default_186, primals_376, primals_1280, getitem_75, relu_default_185, getitem_74, primals_370, primals_1286, convolution_default_50, primals_383, getitem_476, convolution_default_195, primals_1283, relu_default_24, getitem_475, primals_1284, primals_372, getitem_141, primals_1285, getitem_140, relu_default_186, primals_377, relu_default_50, primals_388, primals_1289, relu_default_25, primals_1290, convolution_default_187, convolution_default_51, primals_1291, primals_1292, convolution_default_26, primals_375, primals_381, primals_382, getitem_478, getitem_479, getitem_143, primals_1295, primals_371, primals_1044, getitem_286, getitem_54, getitem_287, primals_740, getitem_53, convolution_default_203, primals_1050, primals_753, relu_default_107, relu_default_202, relu_default_16, getitem_204, primals_1049, primals_739, primals_1056, convolution_default_108, getitem_523, getitem_203, getitem_522, convolution_default_17, primals_742, cat_default_1, primals_1057, getitem_290, relu_default_75, primals_1046, getitem_289, relu_default_203, primals_746, getitem_57, getitem_56, convolution_default_76, relu_default_108, primals_745, primals_752, primals_1051, convolution_default_204, relu_default_17, primals_1055, primals_1052, convolution_default_109, getitem_206, getitem_207, primals_754, primals_748, convolution_default_19, primals_747, getitem_292, convolution_default_205, primals_1045, primals_741, relu_default_76, cat_default_16, relu_default_204, getitem_525, primals_1043, getitem_526, primals_751, relu_default_18, getitem_293, convolution_default_77, primals_606, getitem_350, primals_615, getitem_349, relu_default_133, primals_618, primals_623, convolution_default_134, cat_default_21, primals_611, primals_621, getitem_353, getitem_352, primals_610, primals_624, primals_622, convolution_default_209, primals_609, relu_default_134, convolution_default_136, primals_616, primals_612, relu_default_135, primals_605, primals_617, getitem_564, getitem_268, getitem_392, cat_default_14, getitem_454, primals_673, getitem_565, primals_678, getitem_269, getitem_413, getitem_455, primals_110, cat_default_26, primals_111, relu_default_125, relu_default_151, getitem_412, relu_default_220, primals_112, primals_1131, relu_default_99, relu_default_177, primals_1132, primals_106, primals_103, getitem_332, convolution_default_152, primals_109, primals_1133, relu_default_159, convolution_default_221, primals_676, cat_default_38, primals_670, getitem_331, convolution_default_178, primals_681, primals_98, primals_1128, getitem_395, primals_664, primals_1126, primals_662, relu_default_100, getitem_394, getitem_568, getitem_458, getitem_567, relu_default_126, getitem_457, convolution_default_101, primals_1127, primals_100, relu_default_152, relu_default_160, relu_default_221, relu_default_178, convolution_default_127, getitem_272, convolution_default_153, getitem_271, convolution_default_161, primals_1125, primals_104, primals_105, primals_675, convolution_default_179, primals_99, primals_663, primals_1121, primals_1120, getitem_334, convolution_default_128, primals_97, primals_667, primals_1122, getitem_335, convolution_default_162, primals_668, relu_default_101, relu_default_222, primals_1119, convolution_default_154, getitem_460, relu_default_127, relu_default_153, cat_default_30, getitem_397, getitem_415, getitem_398, getitem_416, primals_669, convolution_default_102, primals_1116, getitem_461, relu_default_161, primals_674, convolution_default_223, primals_349, primals_867, relu_default_66, primals_3, relu_default_41, primals_857, primals_358, primals_858, primals_869, primals_344, getitem_120, convolution_default_68, primals_351, getitem_119, relu_default_67, primals_357, primals_868, relu_default_42, getitem_186, convolution_default_85, primals_861, primals_862, getitem_185, primals_870, convolution_default_43, primals_345, primals_4, relu_default_68, primals_856, convolution_default_44, primals_863, getitem_122, getitem_123, convolution_default_69, primals_864, primals_343, primals_355, primals_356, relu_default_43, primals_350, primals_346, primals_855, primals_340, primals_352, getitem_188, primals_24, primals_1296, getitem_2, primals_1297, getitem_33, relu_default_238, getitem_32, primals_950, primals_1298, relu_default, getitem_99, getitem_98, primals_39, relu_default_9, primals_1301, getitem_610, primals_955, relu_default_34, getitem_609, primals_1306, primals_1302, primals_37, convolution_default_1, convolution_default_10, getitem_1, primals_956, primals_1303, primals_959, primals_38, primals_1304, convolution_default_35, relu_default_239, primals_948, getitem_5, getitem_36, getitem_4, getitem_35, primals_962, primals_954, primals_1307, getitem_102, primals_32, convolution_default_240, getitem_101, primals_31, relu_default_1, relu_default_10, primals_947, relu_default_35, getitem_612, convolution_default_2, getitem_613, primals_26, primals_960, convolution_default_36, primals_34, convolution_default_24, relu_default_240, avg_pool2d_default, convolution_default_11, getitem_7, getitem_8, primals_40, convolution_default_52, primals_33, primals_953, primals_961, convolution_default_241, getitem_502, primals_286, primals_577, relu_default_194, primals_274, primals_584, primals_283, getitem_251, getitem_250, primals_579, getitem_505, primals_280, getitem_504, primals_570, relu_default_92, primals_278, primals_578, primals_279, primals_284, relu_default_195, convolution_default_93, primals_569, primals_572, primals_580, convolution_default_196, getitem_254, getitem_253, primals_285, cat_default_33, primals_277, primals_585, primals_571, relu_default_93, getitem_507, getitem_508, primals_574, primals_583, convolution_default_94, relu_default_196, primals_1195, getitem_374, primals_910, getitem_437, primals_915, relu_default_117, primals_1208, primals_924, getitem_165, primals_916, relu_default_143, primals_1198, getitem_164, cat_default_7, getitem_436, primals_1201, relu_default_169, cat_default_23, primals_1203, primals_919, relu_default_59, primals_922, getitem_314, primals_1207, getitem_313, getitem_377, cat_default_28, getitem_376, relu_default_170, primals_1209, primals_921, convolution_default_61, relu_default_118, relu_default_60, convolution_default_171, relu_default_144, primals_1204, primals_927, convolution_default_119, primals_913, getitem_440, cat_default_18, getitem_439, primals_1210, primals_1202, getitem_316, relu_default_145, getitem_317, primals_1197, convolution_default_62, getitem_167, relu_default_171, primals_914, getitem_168, relu_default_119, primals_1196, convolution_default_172, relu_default_61, convolution_default_146, primals_920, primals_1063, primals_1067, primals_91, primals_760, primals_1068, primals_1062, primals_1070, primals_757, primals_1061, primals_80, primals_82, primals_764, primals_1069, primals_86, primals_79, primals_1064, primals_766, primals_765, primals_763, primals_93, primals_771, primals_772, primals_88, primals_1058, primals_774, primals_759, primals_768, primals_94, primals_85, primals_87, primals_758, primals_92, primals_773, primals_1073, primals_81, getitem_78, relu_default_187, relu_default_84, relu_default_26, getitem_77, getitem_547, getitem_546, convolution_default_27, getitem_482, getitem_231, getitem_481, getitem_230, getitem_81, relu_default_213, getitem_80, relu_default_188, relu_default_85, convolution_default_214, relu_default_27, convolution_default_189, cat_default_11, getitem_550, getitem_549, convolution_default_28, getitem_233, getitem_484, getitem_485, relu_default_214, convolution_default_86, convolution_default_29, cat_default_15, relu_default_189, getitem_83, getitem_84, convolution_default_215, getitem_235, getitem_236, relu_default_28, convolution_default_190, convolution_default_113, relu_default_230, relu_default_109, primals_303, primals_292, getitem_60, getitem_59, getitem_592, getitem_591, primals_300, primals_299, convolution_default_111, relu_default_19, primals_298, relu_default_110, primals_293, relu_default_231, primals_288, primals_297, getitem_296, convolution_default_20, primals_304, cat_default_40, getitem_295, getitem_63, getitem_62, relu_default_111, relu_default_232, relu_default_20, primals_291, convolution_default_112, convolution_default_233, convolution_default_21, primals_294, getitem_594, primals_305, getitem_298, convolution_default_144, relu_default_2, relu_default_51, getitem_144, getitem_356, getitem_355, cat_default_6, getitem_529, getitem_528, primals_831, getitem_9, primals_816, primals_219, primals_826, getitem_10, convolution_default_3, primals_824, relu_default_136, getitem_147, primals_222, getitem_146, relu_default_205, getitem_13, primals_220, primals_829, getitem_12, primals_228, convolution_default_137, primals_226, relu_default_52, convolution_default_206, cat_default_35, primals_817, relu_default_3, getitem_359, primals_227, primals_820, getitem_358, getitem_532, getitem_531, primals_231, primals_234, relu_default_53, convolution_default_4, primals_825, relu_default_137, primals_221, primals_830, relu_default_206, primals_815, primals_832, getitem_15, primals_818, convolution_default_138, convolution_default_5, convolution_default_208, primals_823, convolution_default_54, primals_233, primals_225, getitem_16, primals_232, relu_default_207, primals_650, primals_707, relu_default_179, primals_648, getitem_571, primals_713, getitem_210, getitem_570, primals_689, getitem_125, getitem_126, getitem_209, primals_716, getitem_419, primals_708, relu_default_223, primals_690, primals_699, getitem_418, primals_695, relu_default_77, primals_647, relu_default_44, convolution_default_181, relu_default_180, convolution_default_224, primals_658, relu_default_162, convolution_default_78, convolution_default_45, primals_683, cat_default_5, primals_657, primals_687, getitem_464, getitem_574, convolution_default_163, getitem_573, primals_715, getitem_463, primals_696, primals_714, getitem_213, primals_661, convolution_default_87, primals_655, primals_693, primals_709, getitem_129, getitem_212, getitem_128, primals_682, primals_704, getitem_422, primals_649, relu_default_224, primals_700, getitem_421, relu_default_181, primals_684, relu_default_78, primals_702, primals_694, relu_default_45, primals_688, primals_652, primals_644, primals_710, relu_default_163, convolution_default_225, convolution_default_182, convolution_default_79, convolution_default_47, primals_656, convolution_default_164, getitem_576, primals_701, getitem_466, convolution_default_239, relu_default_46, cat_default_32, primals_502, primals_194, getitem_275, primals_514, primals_195, getitem_274, primals_508, primals_512, primals_507, relu_default_102, primals_513, primals_183, convolution_default_103, primals_199, primals_189, primals_184, primals_187, primals_511, getitem_278, getitem_277, primals_496, primals_499, relu_default_103, primals_506, primals_190, primals_193, primals_501, convolution_default_104, primals_196, primals_505, primals_500, getitem_280, convolution_default_118, primals_188, primals_1221, getitem_38, primals_1214, convolution_default_12, getitem_39, primals_241, primals_240, primals_402, relu_default_11, primals_1220, primals_1225, primals_1219, primals_1222, primals_252, primals_1216, cat_default, primals_1213, primals_1226, getitem_42, getitem_44, getitem_41, primals_1215, primals_242, primals_395, primals_253, primals_246, relu_default_12, primals_1227, primals_251, primals_1228, primals_236, primals_239, primals_397, primals_396, convolution_default_13, primals_392, primals_245, convolution_default_14, primals_398, primals_1230, getitem_45, primals_247, primals_401, primals_390, primals_1233, primals_248, primals_389, primals_909, getitem_105, getitem_257, getitem_189, getitem_256, getitem_443, cat_default_13, getitem_442, relu_default_36, relu_default_69, getitem_338, primals_904, primals_215, getitem_104, primals_208, relu_default_94, getitem_337, primals_214, convolution_default_37, convolution_default_70, relu_default_172, relu_default_128, getitem_192, convolution_default_173, primals_207, getitem_108, getitem_191, getitem_107, convolution_default_129, cat_default_20, primals_901, relu_default_95, primals_206, getitem_446, relu_default_70, getitem_445, convolution_default_96, relu_default_37, getitem_341, getitem_340, primals_210, relu_default_173, primals_902, convolution_default_71, primals_202, convolution_default_38, relu_default_129, cat_default_4, convolution_default_97, primals_200, getitem_259, getitem_260, primals_895, convolution_default_174, primals_896, primals_216, primals_213, convolution_default_72, primals_907, primals_894, relu_default_71, convolution_default_131, relu_default_96, getitem_194, primals_898, getitem_195, primals_893, getitem_110, getitem_111, relu_default_130, getitem_448, primals_201, relu_default_38, convolution_default_188, primals_903, primals_205, primals_908, getitem_616, getitem_615, cat_default_42, convolution_default_121, getitem_171, getitem_401, getitem_170, primals_877, relu_default_120, getitem_400, convolution_default_198, relu_default_197, relu_default_241, primals_878, getitem_320, relu_default_62, relu_default_154, getitem_319, getitem_511, getitem_513, primals_890, getitem_510, cat_default_25, convolution_default_63, add_tensor_39, primals_884, relu_default_121, primals_887, primals_875, relu_default_198, getitem_174, relu_default_155, convolution_default_243, getitem_173, convolution_default_122, getitem_618, primals_881, primals_889, convolution_default_199, convolution_default_156, primals_876, relu_default_63, primals_882, getitem_619, primals_883, convolution_default_123, convolution_default_200, cat_default_29, convolution_default_64, getitem_403, relu_default_242, getitem_322, getitem_404, primals_888, getitem_323, getitem_514, primals_872, relu_default_122, convolution_default_183, primals_444, relu_default_86, getitem_553, getitem_552, primals_456, getitem_488, getitem_487, relu_default_215, relu_default_190, getitem_239, getitem_238, convolution_default_216, cat_default_37, convolution_default_191, primals_439, relu_default_87, getitem_556, primals_454, getitem_555, primals_455, primals_449, getitem_491, getitem_490, convolution_default_88, primals_450, relu_default_216, primals_448, relu_default_191, primals_447, getitem_241, getitem_242, convolution_default_218, primals_441, convolution_default_192, relu_default_88, relu_default_217, primals_453, primals_440, convolution_default_226, primals_442, convolution_default_89, getitem_493, getitem_595, relu_default_4, primals_1037, primals_1031, relu_default_233, primals_336, primals_637, getitem_17, getitem_18, primals_631, primals_1038, primals_335, primals_1024, getitem_598, getitem_597, getitem_21, primals_626, getitem_20, primals_629, primals_331, primals_643, relu_default_234, primals_632, primals_329, primals_1030, primals_638, relu_default_5, primals_641, primals_1025, primals_1036, primals_330, convolution_default_235, primals_326, primals_1035, convolution_default_6, primals_325, primals_635, primals_1029, primals_332, primals_630, convolution_default_236, getitem_600, convolution_default_7, primals_636, primals_1032, getitem_601, getitem_23, getitem_24, primals_1026, primals_337, relu_default_235, relu_default_6, primals_338, primals_642, primals_1040, primals_603, getitem_425, primals_121, getitem_379, getitem_424, primals_118, cat_default_27, primals_115, primals_595, getitem_380, primals_127, getitem_87, relu_default_146, getitem_86, relu_default_164, primals_591, convolution_default_147, relu_default_29, primals_586, primals_122, getitem_383, getitem_385, primals_590, getitem_382, relu_default_165, convolution_default_30, primals_123, convolution_default_166, primals_592, primals_129, relu_default_147, primals_589, getitem_90, getitem_89, primals_604, primals_598, primals_130, convolution_default_148, primals_128, convolution_default_167, primals_116, getitem_427, getitem_428, primals_596, relu_default_30, primals_600, convolution_default_149, primals_117, relu_default_166, convolution_default_31, getitem_386, primals_124, primals_597, primals_558, primals_1139, getitem_299, primals_520, primals_1140, primals_780, primals_1152, primals_1143, primals_778, relu_default_112, primals_794, primals_846, primals_519, primals_563, primals_784, primals_835, primals_790, primals_1144, primals_1134, primals_528, primals_844, primals_552, primals_1150, getitem_302, primals_1149, primals_522, primals_779, primals_843, primals_1151, getitem_301, primals_557, primals_842, primals_564, primals_559, primals_565, primals_841, relu_default_113, primals_525, primals_785, primals_1146, primals_518, primals_838, primals_1145, convolution_default_114, primals_1137, primals_777, primals_527, primals_554, primals_837, primals_786, primals_836, primals_1138, primals_551, primals_849, primals_783, cat_default_17, primals_553, primals_526, primals_560, primals_851, getitem_304, primals_852, getitem_305, primals_850, primals_517, primals_791, primals_792, primals_566, relu_default_114, primals_789, getitem_216, primals_75, primals_169, getitem_65, getitem_66, primals_466, getitem_149, primals_176, primals_1087, primals_181, getitem_150, relu_default_79, getitem_215, primals_473, primals_1093, primals_1089, relu_default_21, relu_default_54, primals_61, primals_467, convolution_default_80, primals_1090, cat_default_10, getitem_535, primals_166, getitem_534, primals_468, convolution_default_22, convolution_default_55, primals_1094, getitem_219, getitem_218, primals_460, getitem_153, relu_default_208, primals_1078, getitem_69, getitem_152, getitem_68, primals_63, primals_1075, primals_62, relu_default_80, primals_64, primals_1076, primals_461, primals_1088, primals_462, relu_default_22, relu_default_55, primals_67, primals_69, primals_1083, primals_1081, primals_177, primals_474, convolution_default_56, primals_1082, primals_68, convolution_default_23, primals_170, relu_default_81, getitem_537, primals_76, primals_1084, getitem_538, primals_459, getitem_155, primals_172, primals_178, primals_475, primals_70, primals_73, relu_default_209, primals_182, primals_470, primals_465, getitem_71, getitem_72, primals_171, primals_1074, convolution_default_57, primals_74, primals_175, convolution_default_42, getitem_156, convolution_default_82, convolution_default_210, primals_1183, getitem_361, getitem_467, getitem_362, primals_1182, relu_default_182, relu_default_138, getitem_132, primals_1187, getitem_131, convolution_default_139, cat_default_22, getitem_470, getitem_469, primals_1177, relu_default_47, getitem_365, getitem_364, primals_1176, relu_default_183, primals_1192, convolution_default_48, relu_default_139, primals_1184, convolution_default_184, primals_1178, getitem_135, getitem_134, cat_default_31, relu_default_48, primals_1190, relu_default_140, primals_1181, getitem_472, primals_1188, primals_1189, getitem_473, convolution_default_49, convolution_default_141, relu_default_184, primals_1175, primals_427, primals_421, primals_934, primals_5, relu_default_104, relu_default_225, primals_429, primals_23, getitem_281, getitem_577, primals_21, cat_default_39, primals_434, primals_933, primals_945, primals_935, primals_928, primals_929, primals_17, getitem_580, getitem_579, primals_12, primals_940, convolution_default_106, primals_11, primals_941, relu_default_105, primals_6, primals_433, primals_436, relu_default_226, primals_16, primals_428, getitem_284, primals_9, getitem_283, primals_930, primals_435, primals_422, primals_18, primals_430, relu_default_106, relu_default_227, primals_424, primals_10, primals_22, convolution_default_107, primals_946, primals_15, primals_936, convolution_default_228, primals_423, primals_942, primals_939, primals_1242, primals_491, relu_default_199, primals_1241, primals_492, primals_1240, primals_493, primals_1239, getitem_198, getitem_344, primals_485, getitem_197, getitem_343, primals_488, getitem_517, getitem_516, relu_default_72, primals_1236, primals_1248, relu_default_131, primals_1235, relu_default_200, convolution_default_73, primals_1234, cat_default_9, convolution_default_132, primals_487, primals_1245, convolution_default_201, primals_482, primals_1246, primals_494, getitem_201, getitem_200, primals_486, getitem_347, cat_default_34, getitem_346, getitem_562, getitem_519, primals_1247, getitem_520, relu_default_73, primals_479, relu_default_132, primals_480, relu_default_201, primals_481, primals_1251, convolution_default_75, convolution_default_133, primals_1252, primals_476, primals_1253, relu_default_74, getitem_449, getitem_176, view_default, primals_133, relu_default_174, primals_135, getitem_263, getitem_262, relu_default_64, primals_140, primals_309, t_default, primals_311, convolution_default_40, getitem_177, primals_323, convolution_default_65, relu_default_97, relu_default_39, primals_312, primals_139, convolution_default_176, primals_319, primals_306, getitem_114, getitem_180, getitem_182, convolution_default_98, relu_default_175, primals_324, getitem_179, primals_136, primals_320, getitem_113, getitem_452, getitem_266, primals_147, relu_default_65, getitem_265, primals_142, getitem_451, primals_317, relu_default_40, primals_145, primals_134, primals_310, primals_148, relu_default_98, convolution_default_66, relu_default_176, convolution_default_41, primals_314, convolution_default_99, convolution_default_177, getitem_183, primals_146, primals_141, getitem_116, cat_default_8, primals_318, getitem_117]
        
