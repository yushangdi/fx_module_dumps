
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/nasnetalarge/nasnetalarge_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_713, primals_708, primals_705, getitem_253, primals_1395, getitem_28, getitem_326, getitem_27, getitem_714, getitem_461, getitem_713, getitem_252, primals_1400, getitem_327, primals_718, convolution_default_431, primals_283, primals_711, relu__default_3, convolution_default_241, getitem_460, cat_default_11, relu_default_61, relu__default_96, relu_default_75, convolution_default_430, primals_1397, primals_1402, primals_898, convolution_default_197, primals_1396, relu_default_139, primals_709, primals_895, convolution_default_17, convolution_default_196, getitem_404, convolution_default_278, convolution_default_242, primals_285, relu_default_48, convolution_default_277, convolution_default_16, convolution_default_152, primals_280, getitem_717, primals_714, getitem_330, primals_897, getitem_31, constant_pad_nd_default_22, primals_717, relu_default_47, getitem_403, relu_default_136, getitem_716, primals_712, convolution_default_280, getitem_30, getitem_329, relu__default_54, primals_279, primals_892, getitem_464, primals_896, relu__default_44, getitem_463, convolution_default_154, convolution_default_153, relu__default_62, getitem_255, convolution_default_243, primals_1401, convolution_default_432, relu_default_5, convolution_default_198, primals_710, getitem_256, avg_pool2d_default_2, primals_284, convolution_default_244, primals_278, primals_891, convolution_default_279, convolution_default_433, convolution_default_199, getitem_51, primals_941, primals_944, constant_pad_nd_default_10, getitem_500, getitem_50, primals_969, relu__default_45, relu__default_14, relu_default_116, convolution_default_205, convolution_default_66, convolution_default_206, relu__default_67, primals_971, convolution_default_67, primals_773, primals_951, convolution_default_301, relu_default_9, getitem_675, convolution_default_302, convolution_default_371, convolution_default_370, primals_964, relu_default_129, convolution_default_41, getitem_347, getitem_674, getitem_115, primals_943, primals_772, getitem_503, getitem_618, relu_default_66, relu_default_128, convolution_default_30, primals_950, primals_973, getitem_346, getitem_114, getitem_2, primals_776, convolution_default_405, getitem_502, getitem_617, primals_771, primals_1369, convolution_default_29, constant_pad_nd_default_13, relu_default_65, primals_970, getitem_117, getitem_1, constant_pad_nd_default_9, getitem_118, relu_default_95, relu__default_83, add_tensor_6, primals_1678, primals_779, primals_1367, convolution_default_406, primals_945, relu_default, getitem_54, primals_965, getitem_53, primals_778, primals_777, primals_1680, convolution_default_207, convolution_default_372, relu__default_6, getitem_677, primals_949, primals_1677, primals_972, convolution_default_303, convolution_default_407, getitem_116, primals_1681, primals_1370, primals_942, convolution_default_1, relu_default_21, convolution_default_408, convolution_default_208, primals_1674, convolution_default_373, primals_1366, primals_946, primals_968, convolution_default_304, convolution_default_31, getitem_678, primals_1365, primals_1679, convolution_default_32, getitem_4, getitem_349, convolution_default_69, primals_1368, primals_204, primals_1496, primals_1132, primals_1530, primals_1543, primals_1127, primals_1415, getitem_74, convolution_default_44, primals_207, primals_1129, primals_206, getitem_443, primals_1134, primals_1246, primals_1592, getitem_73, primals_1241, primals_1242, getitem_442, primals_1501, primals_1237, relu__default_9, primals_1545, getitem_444, primals_205, primals_1502, primals_1531, primals_1503, primals_1133, primals_211, primals_1497, convolution_default_43, convolution_default_266, primals_1238, primals_1565, getitem_445, primals_1244, primals_1135, primals_1504, primals_212, primals_1128, primals_1394, primals_203, primals_1243, getitem_446, relu_default_84, constant_pad_nd_default_14, getitem_77, primals_210, getitem_76, primals_1236, primals_1137, primals_1505, primals_1529, primals_1532, primals_1566, primals_1136, primals_1498, convolution_default_268, primals_1245, primals_1544, primals_1138, getitem_310, getitem_386, convolution_default_326, getitem_309, convolution_default_455, primals_1491, getitem_657, convolution_default_454, convolution_default_187, getitem_385, getitem_542, convolution_default_328, primals_700, relu_default_76, relu__default_41, getitem_756, getitem_656, getitem_758, relu__default_51, primals_695, convolution_default_186, getitem_541, getitem_755, primals_699, relu__default_73, convolution_default_231, convolution_default_232, relu__default_102, primals_1493, getitem_313, convolution_default_327, primals_704, relu_default_125, primals_696, getitem_312, convolution_default_456, getitem_315, add_tensor_41, relu_default_124, getitem_389, convolution_default_396, primals_1492, relu_default_73, primals_1490, getitem_388, getitem_545, getitem_544, convolution_default_457, relu__default_57, primals_703, convolution_default_397, constant_pad_nd_default_21, getitem_759, primals_697, primals_698, constant_pad_nd_default_19, convolution_default_234, primals_1802, relu_default_59, convolution_default_233, relu_default_104, primals_985, convolution_default_116, convolution_default_117, primals_102, getitem_292, primals_1022, getitem_154, primals_676, getitem_794, getitem_196, getitem_291, convolution_default_336, primals_111, primals_363, primals_115, primals_983, primals_1797, primals_101, relu_default_28, getitem_195, convolution_default_335, relu_default_151, primals_1791, primals_1792, primals_114, relu__default_39, constant_pad_nd_default_24, getitem_795, primals_690, primals_1327, primals_1790, convolution_default_91, constant_pad_nd_default_29, primals_116, primals_1032, relu__default_25, getitem_560, primals_681, convolution_default_176, convolution_default_481, primals_1025, getitem_559, convolution_default_480, primals_980, getitem_157, getitem_156, primals_105, getitem_155, convolution_default_177, primals_974, primals_1028, primals_689, relu__default_75, convolution_default_178, primals_685, getitem_295, primals_106, primals_979, getitem_798, primals_1789, primals_686, primals_1027, relu_default_29, primals_1024, primals_691, constant_pad_nd_default_18, primals_108, primals_1793, primals_1810, primals_361, getitem_294, primals_107, getitem_797, primals_677, convolution_default_337, primals_1026, primals_682, primals_683, primals_984, primals_986, getitem_199, convolution_default_134, relu__default_108, getitem_198, primals_1031, primals_1764, convolution_default_92, primals_366, primals_684, relu_default_37, convolution_default_338, convolution_default_93, convolution_default_482, primals_1796, primals_977, primals_100, getitem_297, getitem_562, primals_1023, primals_358, primals_680, primals_109, primals_978, primals_110, primals_362, convolution_default_118, primals_694, getitem_159, getitem_563, convolution_default_483, primals_450, primals_458, primals_1264, primals_1178, primals_224, convolution_default_421, primals_286, primals_451, getitem_696, primals_1183, primals_457, primals_221, getitem_695, primals_1153, primals_218, primals_225, primals_1578, primals_231, relu__default_94, primals_1147, primals_449, primals_1155, primals_1182, primals_1158, primals_215, primals_1259, primals_294, primals_1142, primals_1672, convolution_default_420, primals_1673, primals_459, primals_1150, primals_292, primals_1177, primals_1579, primals_1141, primals_1159, primals_288, primals_1149, primals_1668, primals_1260, primals_445, primals_1669, primals_1181, primals_287, primals_1154, primals_229, getitem_698, getitem_699, primals_1162, primals_1563, primals_219, primals_1144, primals_452, primals_289, primals_216, primals_1176, primals_226, primals_1265, primals_448, primals_1161, primals_453, primals_217, primals_1143, primals_293, primals_1160, primals_1360, primals_220, primals_1258, primals_1261, primals_230, primals_1488, primals_454, primals_1148, getitem_235, relu_default_91, primals_1619, convolution_default, primals_1621, getitem_5, getitem_638, getitem_639, primals_1110, getitem_425, primals_1104, primals_1594, relu_default_1, relu_default_44, convolution_default_267, convolution_default_290, primals_482, primals_1564, primals_497, primals_1616, getitem_96, primals_1333, primals_1709, primals_1706, convolution_default_256, primals_1710, convolution_default_255, relu_default_121, primals_1624, convolution_default_141, primals_1620, convolution_default_140, convolution_default_3, convolution_default_57, getitem_485, getitem_97, primals_498, primals_1337, getitem_484, primals_486, primals_1338, primals_1629, primals_485, primals_1708, convolution_default_56, convolution_default_2, getitem_483, convolution_default_384, primals_487, getitem_428, convolution_default_385, primals_1329, primals_1105, getitem_238, relu_default_122, primals_1596, constant_pad_nd_default, primals_1328, primals_903, relu_default_92, getitem_100, getitem_427, primals_904, getitem_8, getitem_237, primals_902, getitem_642, getitem_7, primals_907, primals_1628, primals_488, primals_1109, primals_1623, primals_1107, primals_1615, getitem_99, relu__default_31, primals_1625, convolution_default_291, getitem_641, primals_1614, primals_481, relu__default, relu__default_12, primals_1622, relu__default_86, primals_1332, primals_1595, primals_1707, primals_1705, convolution_default_257, getitem_487, convolution_default_142, primals_480, primals_909, convolution_default_292, convolution_default_4, primals_494, primals_492, primals_1711, convolution_default_58, primals_1106, primals_1334, convolution_default_293, primals_901, convolution_default_386, convolution_default_258, convolution_default_143, primals_479, getitem_488, primals_1597, convolution_default_5, primals_491, primals_1108, primals_493, convolution_default_387, primals_908, convolution_default_59, convolution_default_359, getitem_735, convolution_default_358, primals_1760, primals_1762, relu__default_78, primals_861, getitem_580, getitem_736, primals_60, convolution_default_349, primals_1714, primals_1067, convolution_default_350, getitem_600, getitem_737, getitem_139, primals_53, primals_45, primals_1060, primals_864, getitem_599, primals_1763, getitem_738, getitem_138, getitem_583, relu_default_140, primals_47, primals_869, primals_867, relu__default_80, relu_default_25, primals_50, getitem_582, primals_59, primals_1065, convolution_default_81, primals_862, primals_1414, primals_46, primals_1761, primals_1072, primals_1068, convolution_default_360, convolution_default_445, getitem_739, primals_51, primals_1061, relu_default_110, primals_1609, avg_pool2d_default_51, convolution_default_82, primals_1073, primals_1798, getitem_740, convolution_default_351, convolution_default_361, getitem_741, convolution_default_83, primals_55, primals_868, primals_1759, primals_1071, primals_56, relu_default_141, primals_863, primals_52, primals_1059, cat_default_19, getitem_603, primals_1066, getitem_141, primals_54, getitem_142, getitem_602, convolution_default_352, primals_1062, relu_default_114, convolution_default_446, convolution_default_106, primals_1540, convolution_default_165, relu_default_34, convolution_default_220, getitem_57, convolution_default_219, primals_738, getitem_467, getitem_178, getitem_177, getitem_277, getitem_56, getitem_368, getitem_466, primals_1697, convolution_default_130, getitem_276, primals_740, relu__default_23, getitem_59, primals_743, relu_default_88, getitem_367, primals_1694, relu__default_49, primals_1696, constant_pad_nd_default_12, convolution_default_107, getitem_220, convolution_default_167, primals_744, relu_default_40, convolution_default_131, convolution_default_282, getitem_181, convolution_default_166, convolution_default_281, primals_1695, convolution_default_221, relu_default_10, getitem_180, getitem_219, primals_1692, primals_745, primals_1693, primals_748, relu__default_29, getitem_370, getitem_280, getitem_470, convolution_default_33, primals_739, getitem_279, convolution_default_222, constant_pad_nd_default_11, getitem_469, convolution_default_34, convolution_default_132, getitem_371, convolution_default_168, convolution_default_283, primals_1691, relu__default_37, relu__default_63, primals_1539, getitem_61, convolution_default_133, relu__default_91, primals_613, primals_1437, getitem_333, getitem_350, getitem_720, getitem_524, getitem_523, primals_618, primals_1650, getitem_719, relu__default_46, getitem_620, getitem_332, convolution_default_209, primals_750, relu__default_97, convolution_default_210, convolution_default_315, relu__default_70, getitem_621, getitem_681, primals_614, primals_1651, primals_1649, primals_609, getitem_335, convolution_default_374, primals_1655, getitem_353, primals_749, getitem_680, primals_616, convolution_default_434, primals_753, convolution_default_316, getitem_352, convolution_default_435, primals_757, getitem_527, primals_600, relu_default_117, primals_1653, avg_pool2d_default_29, convolution_default_409, primals_604, getitem_723, primals_754, primals_612, primals_601, getitem_526, convolution_default_375, getitem_722, primals_1439, convolution_default_410, primals_1654, primals_617, relu_default_100, primals_751, relu_default_137, getitem_624, convolution_default_376, primals_1652, getitem_623, convolution_default_211, primals_759, constant_pad_nd_default_23, primals_603, convolution_default_411, primals_615, primals_1438, relu__default_84, primals_758, primals_602, primals_608, getitem_382, getitem_336, convolution_default_212, getitem_683, convolution_default_317, getitem_684, getitem_337, convolution_default_436, getitem_338, primals_752, convolution_default_437, primals_607, convolution_default_318, convolution_default_306, getitem_777, constant_pad_nd_default_2, getitem_505, primals_1086, relu__default_34, convolution_default_19, getitem_506, relu_default_148, primals_1783, relu_default_2, getitem_34, primals_1085, relu__default_68, getitem_10, convolution_default_21, primals_1076, convolution_default_469, convolution_default_305, convolution_default_468, primals_1087, getitem_259, getitem_11, getitem_33, primals_1081, primals_1078, getitem_780, convolution_default_7, getitem_258, relu__default_4, getitem_509, getitem_260, primals_1082, convolution_default_6, getitem_779, convolution_default_20, constant_pad_nd_default_1, getitem_508, primals_1077, convolution_default_155, add_tensor_1, relu__default_105, getitem_261, getitem_14, primals_1079, getitem_13, convolution_default_311, relu__default_1, getitem_262, constant_pad_nd_default_6, relu_default_49, getitem_37, convolution_default_470, getitem_36, relu_default_97, convolution_default_471, relu_default_96, convolution_default_8, convolution_default_9, convolution_default_157, primals_1080, primals_170, primals_553, primals_169, primals_656, getitem_406, getitem_407, primals_444, primals_439, relu__default_20, primals_174, primals_1273, primals_1271, getitem_121, primals_422, primals_1435, getitem_120, convolution_default_94, primals_675, primals_1272, primals_1436, primals_424, getitem_119, convolution_default_95, getitem_408, primals_1279, getitem_409, primals_661, primals_1270, primals_1423, getitem_160, relu_default_22, primals_429, primals_435, primals_550, primals_1269, getitem_163, primals_430, primals_657, primals_1433, primals_1453, primals_1419, getitem_410, primals_666, primals_1434, relu_default_77, primals_1379, convolution_default_71, primals_438, convolution_default_70, getitem_162, primals_669, primals_1266, primals_1572, primals_555, primals_1380, primals_1430, primals_426, primals_1425, primals_431, primals_668, primals_1274, primals_1577, relu_default_30, primals_165, primals_421, primals_436, primals_662, primals_1285, primals_1428, primals_173, primals_423, primals_672, primals_1421, primals_667, primals_417, primals_1275, convolution_default_246, primals_420, primals_658, getitem_124, getitem_123, getitem_411, primals_1284, primals_425, primals_1429, primals_168, primals_437, primals_1280, primals_559, convolution_default_96, relu__default_15, primals_1452, primals_1422, primals_176, primals_443, primals_1420, primals_1573, primals_1424, primals_175, primals_670, primals_1574, primals_1283, primals_663, convolution_default_97, getitem_412, primals_440, getitem_413, primals_554, primals_1278, primals_434, primals_558, primals_671, convolution_default_72, relu_default_78, convolution_default_73, primals_1339, getitem_79, primals_1009, relu_default_144, convolution_default_188, relu_default_107, primals_1355, convolution_default_189, convolution_default_459, avg_pool2d_default_7, convolution_default_458, getitem_80, convolution_default_340, convolution_default_190, getitem_318, convolution_default_339, primals_1004, getitem_762, getitem_81, getitem_317, primals_1351, constant_pad_nd_default_25, constant_pad_nd_default_15, primals_1005, primals_1340, relu__default_42, getitem_761, primals_999, getitem_566, primals_1346, primals_1353, primals_1343, getitem_565, relu__default_103, primals_1356, primals_1003, relu__default_76, primals_1008, relu_default_14, primals_1000, convolution_default_460, getitem_320, primals_1352, getitem_82, convolution_default_341, convolution_default_191, primals_1357, convolution_default_47, primals_1348, convolution_default_461, primals_1341, convolution_default_342, getitem_321, avg_pool2d_default_28, primals_1342, primals_1010, getitem_764, getitem_84, primals_1347, getitem_83, add_tensor_76, primals_1354, primals_1033, getitem_659, primals_1408, primals_1163, primals_1037, convolution_default_236, getitem_660, primals_1168, relu_default_133, getitem_392, primals_1113, primals_1644, getitem_202, getitem_700, primals_1645, convolution_default_121, relu__default_89, getitem_702, getitem_800, primals_1038, convolution_default_398, getitem_391, primals_1039, primals_1124, primals_1538, convolution_default_399, getitem_201, primals_1411, primals_1164, getitem_801, primals_1114, relu__default_52, convolution_default_423, primals_1118, relu__default_26, getitem_701, getitem_663, primals_1122, primals_1040, convolution_default_119, primals_1533, primals_1740, getitem_664, convolution_default_235, getitem_705, primals_1172, getitem_662, getitem_704, primals_1409, getitem_703, convolution_default_120, primals_1173, primals_1742, relu__default_110, primals_1169, primals_1042, getitem_665, relu_default_152, primals_1174, relu_default_134, convolution_default_484, primals_1407, primals_1121, primals_1123, primals_1041, primals_1119, primals_1167, getitem_395, getitem_394, primals_1639, getitem_205, relu_default_38, getitem_666, primals_1416, getitem_204, primals_1120, convolution_default_424, convolution_default_485, primals_1410, relu_default_74, primals_1175, primals_1115, primals_1534, primals_1036, primals_1741, primals_1535, convolution_default_425, relu_default_126, getitem_803, relu_default_45, getitem_804, primals_1294, getitem_240, primals_416, getitem_449, getitem_448, getitem_103, getitem_102, getitem_241, getitem_298, primals_1292, getitem_645, relu_default_56, getitem_644, convolution_default_329, primals_767, primals_412, primals_765, getitem_447, relu_default_103, primals_762, relu_default_85, relu_default_18, primals_763, convolution_default_145, primals_1288, convolution_default_144, primals_411, getitem_301, convolution_default_270, getitem_548, relu_default_62, convolution_default_269, primals_1601, convolution_default_61, getitem_300, convolution_default_60, convolution_default_330, convolution_default_388, primals_405, primals_1784, getitem_244, primals_406, relu_default_57, getitem_452, primals_1286, getitem_547, primals_1287, getitem_106, getitem_243, getitem_648, primals_409, relu__default_74, relu__default_32, getitem_451, getitem_105, getitem_647, primals_1787, primals_768, relu__default_60, relu__default_13, relu__default_87, primals_1289, primals_1788, primals_766, convolution_default_331, convolution_default_146, convolution_default_180, constant_pad_nd_default_16, primals_764, convolution_default_181, convolution_default_271, convolution_default_62, convolution_default_390, primals_410, primals_1293, convolution_default_332, convolution_default_147, primals_415, primals_1600, convolution_default_272, getitem_303, convolution_default_333, convolution_default_63, convolution_default_391, primals_258, primals_1470, relu__default_18, convolution_default_84, primals_1754, primals_251, convolution_default_85, primals_1219, primals_256, primals_1220, primals_1768, primals_1568, getitem_145, primals_1770, primals_255, primals_1218, getitem_144, primals_1471, primals_1476, primals_257, primals_1756, primals_1569, primals_1473, primals_1755, primals_1216, relu_default_27, primals_1211, relu_default_26, primals_252, convolution_default_90, primals_259, convolution_default_86, primals_1214, primals_1217, primals_1769, primals_135, primals_1472, primals_250, primals_1215, convolution_default_87, primals_626, convolution_default_112, getitem_372, getitem_17, getitem_430, relu__default_65, relu__default_7, primals_623, getitem_373, getitem_431, getitem_62, convolution_default_363, primals_622, convolution_default_109, convolution_default_362, convolution_default_35, convolution_default_108, getitem_744, convolution_default_449, getitem_16, convolution_default_36, relu_default_81, primals_630, relu_default_70, getitem_374, getitem_19, getitem_184, getitem_491, getitem_606, getitem_743, convolution_default_260, primals_636, convolution_default_259, getitem_65, relu_default_94, relu_default_115, relu__default_100, getitem_490, getitem_605, primals_628, getitem_183, convolution_default_224, getitem_434, getitem_64, convolution_default_447, constant_pad_nd_default_4, relu_default_93, relu__default_81, relu__default_24, convolution_default_448, avg_pool2d_default_6, convolution_default_294, convolution_default_22, getitem_433, getitem_377, relu_default_3, getitem_376, primals_629, getitem_375, relu__default_58, convolution_default_364, convolution_default_110, primals_621, convolution_default_295, relu_default_71, primals_631, primals_1702, relu_default_13, convolution_default_10, relu_default_11, getitem_747, primals_1451, convolution_default_466, constant_pad_nd_default_3, convolution_default_365, getitem_746, primals_1450, convolution_default_38, primals_1463, convolution_default_261, convolution_default_111, primals_627, convolution_default_11, convolution_default_296, primals_635, primals_637, convolution_default_37, convolution_default_225, getitem_608, getitem_609, getitem_186, convolution_default_262, primals_1701, getitem_493, primals_632, getitem_22, getitem_21, getitem_494, relu_default_142, convolution_default_226, getitem_187, primals_1307, getitem_530, primals_847, primals_1306, getitem_529, getitem_39, getitem_42, primals_1302, getitem_41, relu__default_71, primals_849, primals_844, primals_1303, primals_1301, primals_1300, relu_default_7, primals_850, primals_1299, primals_1750, convolution_default_320, primals_1751, constant_pad_nd_default_26, primals_1313, convolution_default_319, primals_1506, primals_853, primals_1749, primals_854, getitem_533, primals_858, primals_1314, primals_1582, primals_855, relu_default_101, primals_1315, cat_default_1, getitem_532, primals_1583, primals_846, avg_pool2d_default_3, primals_1308, primals_859, primals_1309, primals_845, constant_pad_nd_default_7, primals_860, primals_1312, convolution_default_322, convolution_default_321, primals_848, primals_1298, primals_1297, getitem_44, getitem_223, getitem_783, primals_1746, getitem_586, primals_333, primals_825, getitem_585, relu__default_92, primals_1587, convolution_default_412, primals_338, getitem_222, convolution_default_354, convolution_default_413, relu_default_149, primals_1591, getitem_283, getitem_473, relu_default_150, getitem_782, relu__default_79, getitem_224, convolution_default_175, primals_330, primals_832, convolution_default_353, convolution_default_473, primals_826, getitem_282, getitem_472, getitem_687, convolution_default_472, primals_831, getitem_225, primals_833, relu_default_53, getitem_686, getitem_786, primals_1250, convolution_default_169, convolution_default_284, getitem_554, getitem_589, relu_default_130, getitem_226, relu_default_42, avg_pool2d_default_50, getitem_785, primals_1247, primals_334, getitem_588, convolution_default_170, relu_default_90, primals_335, relu__default_106, primals_821, primals_834, primals_1747, getitem_285, convolution_default_414, relu_default_89, convolution_default_289, getitem_591, convolution_default_285, convolution_default_135, constant_pad_nd_default_31, convolution_default_171, convolution_default_474, primals_1588, convolution_default_415, constant_pad_nd_default_30, primals_830, getitem_286, getitem_228, convolution_default_286, convolution_default_400, convolution_default_475, primals_822, primals_1745, primals_827, getitem_229, getitem_689, primals_1251, getitem_227, convolution_default_172, relu__default_38, getitem_355, getitem_765, getitem_356, primals_640, primals_649, relu__default_47, primals_1443, primals_650, convolution_default_213, primals_1799, convolution_default_214, relu_default_146, primals_651, convolution_default_462, primals_644, getitem_359, convolution_default_465, primals_642, getitem_358, primals_655, getitem_768, primals_643, relu_default_145, convolution_default_463, relu_default_67, primals_652, getitem_767, primals_641, relu__default_104, convolution_default_215, primals_645, convolution_default_216, convolution_default_464, primals_646, primals_505, convolution_default_377, primals_5, primals_31, primals_532, primals_507, getitem_726, primals_41, primals_536, getitem_127, getitem_265, getitem_627, getitem_264, getitem_725, primals_511, relu_default_24, getitem_263, primals_520, getitem_126, getitem_626, primals_519, primals_38, primals_517, relu_default_50, primals_508, relu__default_98, relu_default_23, getitem_628, primals_40, primals_531, primals_4, primals_36, primals_1663, convolution_default_159, primals_37, primals_516, convolution_default_158, getitem_629, convolution_default_439, primals_522, primals_513, primals_521, primals_518, convolution_default_438, convolution_default_74, primals_530, getitem_268, getitem_729, primals_526, primals_26, primals_512, convolution_default_75, getitem_630, primals_28, primals_1442, relu_default_119, primals_32, convolution_default_161, primals_535, getitem_267, getitem_728, primals_39, primals_533, primals_33, primals_1381, primals_1382, relu__default_35, getitem_129, relu_default_138, primals_1748, primals_527, getitem_631, getitem_130, convolution_default_379, convolution_default_76, primals_27, primals_504, relu__default_16, primals_42, primals_503, primals_506, primals_534, convolution_default_160, primals_8, primals_499, primals_3, primals_525, primals_9, primals_502, primals_316, primals_804, getitem_166, getitem_569, primals_732, primals_801, primals_807, primals_1205, primals_315, convolution_default_248, convolution_default_247, getitem_512, primals_1715, getitem_571, convolution_default_307, getitem_568, primals_311, primals_1200, convolution_default_99, relu__default_21, primals_1776, convolution_default_98, primals_1203, primals_149, primals_734, convolution_default_308, primals_722, getitem_416, primals_733, getitem_511, constant_pad_nd_default_28, primals_719, primals_1362, primals_150, primals_1716, getitem_165, getitem_415, relu__default_69, primals_724, primals_1774, primals_1717, relu_default_108, primals_163, primals_1202, getitem_169, primals_1507, primals_1631, primals_1634, relu__default_55, primals_1209, primals_726, primals_1201, primals_1636, primals_151, convolution_default_344, primals_725, primals_1778, primals_313, primals_731, primals_317, primals_808, getitem_168, convolution_default_309, primals_312, convolution_default_343, primals_1773, primals_806, constant_pad_nd_default_27, primals_737, primals_158, primals_805, primals_1204, primals_1630, primals_314, convolution_default_249, primals_1206, convolution_default_310, primals_1210, getitem_573, primals_164, getitem_574, primals_1775, convolution_default_250, primals_1637, primals_800, convolution_default_100, primals_156, primals_727, primals_1638, relu__default_77, primals_159, primals_1777, getitem_515, primals_152, primals_1635, getitem_514, getitem_418, getitem_419, primals_1765, convolution_default_345, convolution_default_101, primals_162, primals_728, primals_153, primals_723, primals_157, primals_809, primals_595, primals_787, primals_1804, primals_1808, getitem_85, getitem_109, convolution_default_237, convolution_default_238, primals_1191, relu_default_63, primals_137, primals_790, primals_1546, primals_791, relu_default_15, primals_275, primals_796, getitem_108, primals_598, primals_1646, primals_1700, relu_default_60, getitem_398, primals_786, convolution_default_202, primals_599, convolution_default_49, convolution_default_245, primals_1187, convolution_default_48, primals_269, primals_594, primals_580, getitem_397, primals_785, primals_1192, primals_1196, getitem_341, primals_1186, convolution_default_193, convolution_default_192, getitem_340, getitem_339, relu__default_53, getitem_88, primals_1195, primals_148, getitem_324, primals_1803, primals_260, getitem_87, primals_264, primals_1805, relu_default_20, getitem_323, convolution_default_239, primals_138, relu__default_10, primals_588, primals_795, primals_147, relu__default_43, primals_142, relu_default_19, primals_782, primals_579, convolution_default_64, primals_143, primals_265, primals_1548, primals_1809, primals_587, convolution_default_203, primals_585, primals_1547, primals_586, primals_793, primals_794, convolution_default_240, convolution_default_50, primals_781, primals_270, primals_274, convolution_default_194, primals_584, convolution_default_204, convolution_default_65, primals_271, primals_792, primals_1197, getitem_401, primals_1189, primals_273, convolution_default_51, getitem_400, primals_581, primals_144, convolution_default_195, getitem_343, primals_593, primals_799, primals_139, primals_589, getitem_111, primals_780, primals_1806, primals_261, primals_590, primals_1188, getitem_112, primals_266, relu_default_64, primals_272, primals_1190, primals_1549, convolution_default_123, getitem_247, getitem_436, primals_922, convolution_default_122, getitem_246, relu_default_87, primals_921, convolution_default_401, relu__default_109, primals_1046, getitem_455, convolution_default_486, getitem_454, primals_916, convolution_default_487, getitem_208, primals_1045, relu_default_46, getitem_669, primals_1054, getitem_668, primals_1053, getitem_667, primals_1375, getitem_437, getitem_207, relu_default_86, primals_913, getitem_807, primals_1047, convolution_default_149, convolution_default_148, relu__default_27, relu_default_127, relu_default_83, convolution_default_263, convolution_default_274, getitem_806, convolution_default_273, primals_1374, getitem_250, relu_default_82, view_default, convolution_default_402, convolution_default_124, primals_1376, getitem_458, primals_1056, primals_915, getitem_249, convolution_default_403, convolution_default_276, relu__default_33, getitem_457, t_default, primals_914, primals_918, convolution_default_264, primals_1050, convolution_default_125, relu__default_61, getitem_671, getitem_672, convolution_default_150, convolution_default_265, primals_912, getitem_211, getitem_440, primals_917, convolution_default_151, convolution_default_404, primals_1447, getitem_210, getitem_439, relu__default_90, convolution_default_275, relu_default_39, relu__default_59, primals_1052, primals_1055, primals_1051, getitem_551, getitem_550, primals_574, primals_1090, primals_344, primals_573, getitem_148, primals_1092, primals_1094, primals_564, primals_67, primals_1586, getitem_147, primals_466, primals_64, primals_1665, primals_80, primals_355, relu__default_19, getitem_553, primals_1101, primals_342, primals_357, primals_349, primals_1361, primals_1096, primals_463, primals_563, primals_562, primals_341, primals_356, primals_464, convolution_default_89, primals_1383, primals_1449, primals_69, primals_339, primals_73, primals_1100, primals_354, convolution_default_88, relu_default_105, primals_353, primals_1093, primals_70, primals_569, getitem_151, primals_74, primals_1666, primals_76, primals_561, primals_1667, primals_478, primals_560, primals_1091, convolution_default_334, primals_347, primals_575, getitem_150, primals_61, primals_352, primals_476, primals_66, primals_348, primals_477, primals_1664, primals_68, primals_65, primals_462, primals_472, primals_468, primals_576, primals_1095, primals_79, getitem_556, primals_467, primals_570, getitem_557, primals_471, primals_567, primals_75, primals_340, primals_473, primals_1099, relu_default_106, getitem_153, getitem_152, primals_568, primals_465, primals_343, primals_322, convolution_default_39, convolution_default_427, primals_545, getitem_304, getitem_707, convolution_default_378, primals_188, primals_1319, relu__default_2, primals_546, getitem_67, getitem_68, relu__default_66, getitem_708, convolution_default_12, convolution_default_297, relu__default_40, convolution_default_367, convolution_default_13, convolution_default_298, convolution_default_366, convolution_default_182, relu__default_95, convolution_default_183, convolution_default_426, primals_182, relu__default_8, primals_320, getitem_612, primals_544, primals_327, getitem_25, getitem_497, getitem_307, getitem_611, getitem_24, getitem_496, getitem_711, constant_pad_nd_default_20, primals_541, convolution_default_40, primals_323, getitem_306, convolution_default_42, relu__default_82, primals_549, primals_179, getitem_71, primals_191, primals_1325, getitem_710, primals_329, primals_183, relu_default_58, getitem_344, primals_328, getitem_70, relu_default_135, primals_190, primals_547, primals_539, relu_default_118, primals_192, convolution_default_368, primals_1320, primals_1610, convolution_default_299, relu_default_6, relu_default_4, primals_184, primals_189, primals_321, primals_1611, primals_177, convolution_default_369, primals_1326, primals_1581, convolution_default_300, convolution_default_428, primals_1580, relu_default_12, convolution_default_184, primals_1323, primals_178, primals_326, primals_1318, cat_default_3, constant_pad_nd_default_17, primals_187, convolution_default_14, getitem_614, constant_pad_nd_default_5, convolution_default_185, primals_548, convolution_default_68, getitem_615, primals_540, primals_1324, getitem_499, convolution_default_429, convolution_default_15, getitem_45, convolution_default_228, getitem_651, getitem_536, convolution_default_451, getitem_188, convolution_default_450, primals_1231, primals_196, primals_1512, getitem_189, getitem_380, primals_197, relu_default_8, getitem_379, getitem_535, getitem_650, getitem_750, primals_1384, getitem_289, primals_1224, primals_1515, relu_default_123, primals_1516, relu_default_35, relu__default_72, primals_1256, convolution_default_26, getitem_190, primals_201, primals_1517, relu__default_50, primals_1518, getitem_749, getitem_288, primals_202, primals_1257, convolution_default_25, primals_1520, relu__default_101, primals_1225, primals_1233, constant_pad_nd_default_8, convolution_default_323, convolution_default_324, convolution_default_393, primals_1510, convolution_default_392, convolution_default_227, primals_1232, convolution_default_113, convolution_default_173, getitem_48, primals_1519, getitem_383, getitem_47, convolution_default_452, primals_1511, primals_1223, primals_1465, relu__default_5, getitem_193, primals_198, primals_1521, relu_default_55, getitem_192, primals_1230, getitem_191, relu_default_54, getitem_539, primals_1252, getitem_654, getitem_538, getitem_653, relu_default_72, getitem_752, convolution_default_174, convolution_default_453, relu_default_36, relu_default_102, relu__default_88, convolution_default_179, primals_1464, primals_1255, convolution_default_27, primals_193, primals_1525, primals_1226, primals_1526, convolution_default_230, getitem_753, primals_1466, convolution_default_115, relu_default_143, primals_1229, convolution_default_229, primals_1524, convolution_default_28, convolution_default_114, convolution_default_325, convolution_default_394, convolution_default_395, primals_960, getitem_362, getitem_476, primals_1477, getitem_361, getitem_475, primals_957, getitem_690, primals_301, primals_308, primals_303, primals_956, convolution_default_218, convolution_default_288, primals_963, relu__default_93, convolution_default_416, primals_298, primals_297, primals_1018, relu__default_48, relu__default_64, convolution_default_417, convolution_default_217, convolution_default_287, primals_955, primals_1019, primals_1013, getitem_693, primals_1484, primals_1478, primals_1479, getitem_480, primals_1012, getitem_365, getitem_479, primals_1017, getitem_692, primals_1011, primals_959, primals_1014, primals_1391, primals_958, primals_1388, primals_1482, getitem_364, getitem_478, primals_954, primals_302, primals_1385, primals_307, convolution_default_223, relu_default_68, relu_default_132, primals_300, primals_299, primals_1390, relu_default_69, getitem_481, primals_1389, relu_default_131, convolution_default_422, primals_1483, primals_306, getitem_482, convolution_default_418, convolution_default_419, primals_1462, getitem_789, getitem_788, primals_1734, primals_990, primals_813, getitem_516, getitem_593, primals_382, primals_390, getitem_517, primals_816, relu_default_98, getitem_592, primals_384, primals_996, primals_381, getitem_518, primals_1457, primals_1731, primals_239, primals_1458, primals_234, primals_386, primals_391, convolution_default_477, primals_991, convolution_default_476, primals_1733, primals_385, convolution_default_312, primals_1461, primals_1721, primals_814, primals_1732, getitem_792, relu_default_112, primals_815, primals_819, getitem_521, getitem_520, getitem_519, getitem_791, primals_380, primals_994, getitem_594, primals_235, convolution_default_357, primals_995, primals_1658, primals_233, primals_394, getitem_595, relu__default_107, primals_998, primals_1737, primals_383, primals_1735, primals_1736, relu_default_99, primals_232, primals_1660, primals_989, primals_238, getitem_596, primals_1720, getitem_597, primals_810, primals_1489, primals_377, primals_1723, convolution_default_478, primals_389, convolution_default_313, relu_default_113, primals_1726, primals_997, primals_1456, primals_1728, primals_1659, primals_1722, convolution_default_479, primals_820, primals_1727, relu_default_31, convolution_default_314, relu_default_43, convolution_default_444, primals_241, convolution_default_440, primals_926, getitem_133, convolution_default_137, primals_935, convolution_default_136, primals_1552, primals_940, primals_246, primals_1558, getitem_732, getitem_132, primals_1687, primals_1688, getitem_232, convolution_default_441, primals_240, primals_888, primals_1686, getitem_231, convolution_default_77, getitem_731, primals_883, primals_927, primals_1683, relu__default_30, relu__default_99, primals_931, convolution_default_78, primals_1593, primals_887, primals_937, primals_930, primals_1553, primals_1560, primals_247, primals_929, primals_889, primals_244, convolution_default_138, primals_1444, convolution_default_442, primals_923, convolution_default_79, primals_1555, primals_936, primals_928, primals_1559, convolution_default_18, primals_1682, convolution_default_80, convolution_default_139, convolution_default_443, getitem_136, primals_890, getitem_135, primals_245, primals_886, relu__default_17, primals_1554, getitem_234, primals_932, getitem_734, convolution_default_156, primals_404, getitem_632, primals_398, relu_default_79, getitem_633, convolution_default_127, convolution_default_126, getitem_577, convolution_default_252, relu_default_120, convolution_default_251, convolution_default_389, getitem_770, primals_395, getitem_771, getitem_214, getitem_216, getitem_576, convolution_default_381, getitem_772, getitem_422, convolution_default_380, relu_default_111, getitem_213, primals_1567, getitem_773, getitem_421, convolution_default_346, relu__default_28, getitem_636, relu__default_56, getitem_635, getitem_774, primals_397, primals_1448, relu_default_109, relu_default_147, convolution_default_128, relu__default_85, primals_403, convolution_default_253, primals_399, convolution_default_347, convolution_default_467, convolution_default_129, convolution_default_382, convolution_default_348, convolution_default_254, primals_396, getitem_217, relu_default_80, convolution_default_383, getitem_776, relu_default_41, getitem_775, primals_400, getitem_424, getitem_579, primals_1602, relu_default_17, primals_878, getitem_90, getitem_172, getitem_171, primals_136, primals_10, primals_81, getitem_271, getitem_91, primals_376, convolution_default_103, primals_835, primals_121, relu_default_52, getitem_270, primals_368, relu_default_16, primals_92, primals_119, relu__default_22, primals_123, primals_19, primals_1782, convolution_default_102, primals_367, relu_default_51, primals_14, primals_134, primals_874, primals_877, convolution_default_52, convolution_default_53, primals_17, primals_875, primals_1607, primals_87, primals_839, primals_1605, primals_97, primals_133, primals_881, primals_22, primals_86, primals_128, getitem_94, primals_371, relu_default_33, primals_96, getitem_175, convolution_default_163, convolution_default_162, primals_1467, primals_873, primals_1371, primals_876, getitem_93, getitem_174, primals_840, primals_370, primals_24, primals_130, relu__default_11, primals_12, primals_375, relu_default_32, primals_88, primals_23, primals_122, primals_94, getitem_274, primals_1405, convolution_default_164, getitem_273, primals_1608, primals_95, primals_841, primals_124, primals_836, primals_13, primals_129, primals_82, primals_1406, primals_1779, convolution_default_54, relu__default_36, primals_83, primals_125, primals_872, primals_1487, convolution_default_104, primals_18, primals_11, primals_25, primals_91, primals_120, primals_369, primals_93, convolution_default_55, primals_882, convolution_default_105, primals_1606, primals_372, tangents_1, tangents_2):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [32, 4032, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [32, 4032, 11, 11]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 121);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_110, torch.float32);  relu__default_110 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_264, to_dtype);  le_scalar = new_zeros_default_264 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        slice_tensor = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 0, 672)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 672, 1344)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 1344, 2016)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 2016, 2688)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 2688, 3360)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(to_dtype_2, 1, 3360, 4032);  to_dtype_2 = None
        clone_default = torch.ops.aten.clone.default(slice_tensor_5, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(clone_default, convolution_default_487, primals_724, primals_722, primals_723, getitem_806, getitem_807, True, 0.001, [True, True, True]);  clone_default = convolution_default_487 = primals_724 = primals_722 = primals_723 = getitem_806 = getitem_807 = None
        getitem_808 = native_batch_norm_backward_default[0]
        getitem_809 = native_batch_norm_backward_default[1]
        getitem_810 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_808, convolution_default_486, primals_728, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_808 = convolution_default_486 = primals_728 = None
        getitem_811 = convolution_backward_default[0]
        getitem_812 = convolution_backward_default[1];  convolution_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_811, relu__default_109, primals_727, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_811 = primals_727 = None
        getitem_814 = convolution_backward_default_1[0]
        getitem_815 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_814, torch.float32);  getitem_814 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_265, to_dtype_3);  le_scalar_1 = new_zeros_default_265 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_485, primals_719, primals_717, primals_718, getitem_803, getitem_804, True, 0.001, [True, True, True]);  to_dtype_5 = convolution_default_485 = primals_719 = primals_717 = primals_718 = getitem_803 = getitem_804 = None
        getitem_817 = native_batch_norm_backward_default_1[0]
        getitem_818 = native_batch_norm_backward_default_1[1]
        getitem_819 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_817, convolution_default_484, primals_726, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_817 = convolution_default_484 = primals_726 = None
        getitem_820 = convolution_backward_default_2[0]
        getitem_821 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_820, relu_default_152, primals_725, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_820 = primals_725 = None
        getitem_823 = convolution_backward_default_3[0]
        getitem_824 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_823, torch.float32);  getitem_823 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu_default_152, torch.float32);  relu_default_152 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_266, to_dtype_6);  le_scalar_2 = new_zeros_default_266 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(slice_tensor_5, to_dtype_8);  slice_tensor_5 = to_dtype_8 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_4, getitem_772, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_112 = torch.ops.aten.add.Tensor(slice_tensor, avg_pool2d_backward_default);  slice_tensor = avg_pool2d_backward_default = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_4, getitem_772, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_4 = getitem_772 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(add_tensor_112, avg_pool2d_backward_default_1);  add_tensor_112 = avg_pool2d_backward_default_1 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(add_tensor_113, slice_tensor_3);  add_tensor_113 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_3, getitem_775, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_3 = getitem_775 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(add_tensor_111, avg_pool2d_backward_default_2);  add_tensor_111 = avg_pool2d_backward_default_2 = None
        clone_default_1 = torch.ops.aten.clone.default(slice_tensor_2, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(clone_default_1, convolution_default_483, primals_710, primals_708, primals_709, getitem_800, getitem_801, True, 0.001, [True, True, True]);  clone_default_1 = convolution_default_483 = primals_710 = primals_708 = primals_709 = getitem_800 = getitem_801 = None
        getitem_826 = native_batch_norm_backward_default_2[0]
        getitem_827 = native_batch_norm_backward_default_2[1]
        getitem_828 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_826, convolution_default_482, primals_714, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_826 = convolution_default_482 = primals_714 = None
        getitem_829 = convolution_backward_default_4[0]
        getitem_830 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_829, relu__default_108, primals_713, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_829 = primals_713 = None
        getitem_832 = convolution_backward_default_5[0]
        getitem_833 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_832, torch.float32);  getitem_832 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_267, to_dtype_9);  le_scalar_3 = new_zeros_default_267 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_481, primals_705, primals_703, primals_704, getitem_797, getitem_798, True, 0.001, [True, True, True]);  to_dtype_11 = convolution_default_481 = primals_705 = primals_703 = primals_704 = getitem_797 = getitem_798 = None
        getitem_835 = native_batch_norm_backward_default_3[0]
        getitem_836 = native_batch_norm_backward_default_3[1]
        getitem_837 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_835, convolution_default_480, primals_712, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_835 = convolution_default_480 = primals_712 = None
        getitem_838 = convolution_backward_default_6[0]
        getitem_839 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_838, relu_default_151, primals_711, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_838 = primals_711 = None
        getitem_841 = convolution_backward_default_7[0]
        getitem_842 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_841, torch.float32);  getitem_841 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu_default_151, torch.float32);  relu_default_151 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_268, to_dtype_12);  le_scalar_4 = new_zeros_default_268 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(add_tensor_114, to_dtype_14);  add_tensor_114 = to_dtype_14 = None
        clone_default_2 = torch.ops.aten.clone.default(slice_tensor_2, memory_format = torch.contiguous_format);  slice_tensor_2 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(clone_default_2, convolution_default_479, primals_696, primals_694, primals_695, getitem_794, getitem_795, True, 0.001, [True, True, True]);  clone_default_2 = convolution_default_479 = primals_696 = primals_694 = primals_695 = getitem_794 = getitem_795 = None
        getitem_844 = native_batch_norm_backward_default_4[0]
        getitem_845 = native_batch_norm_backward_default_4[1]
        getitem_846 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_844, convolution_default_478, primals_700, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_844 = convolution_default_478 = primals_700 = None
        getitem_847 = convolution_backward_default_8[0]
        getitem_848 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_847, relu__default_107, primals_699, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_847 = primals_699 = None
        getitem_850 = convolution_backward_default_9[0]
        getitem_851 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_850, torch.float32);  getitem_850 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_269, to_dtype_15);  le_scalar_5 = new_zeros_default_269 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_477, primals_691, primals_689, primals_690, getitem_791, getitem_792, True, 0.001, [True, True, True]);  to_dtype_17 = convolution_default_477 = primals_691 = primals_689 = primals_690 = getitem_791 = getitem_792 = None
        getitem_853 = native_batch_norm_backward_default_5[0]
        getitem_854 = native_batch_norm_backward_default_5[1]
        getitem_855 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_853, convolution_default_476, primals_698, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_853 = convolution_default_476 = primals_698 = None
        getitem_856 = convolution_backward_default_10[0]
        getitem_857 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_856, relu_default_150, primals_697, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_856 = primals_697 = None
        getitem_859 = convolution_backward_default_11[0]
        getitem_860 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_859, torch.float32);  getitem_859 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_150, torch.float32);  relu_default_150 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_270, to_dtype_18);  le_scalar_6 = new_zeros_default_270 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(add_tensor_116, to_dtype_20);  add_tensor_116 = to_dtype_20 = None
        clone_default_3 = torch.ops.aten.clone.default(slice_tensor_1, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(clone_default_3, convolution_default_475, primals_682, primals_680, primals_681, getitem_788, getitem_789, True, 0.001, [True, True, True]);  clone_default_3 = convolution_default_475 = primals_682 = primals_680 = primals_681 = getitem_788 = getitem_789 = None
        getitem_862 = native_batch_norm_backward_default_6[0]
        getitem_863 = native_batch_norm_backward_default_6[1]
        getitem_864 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_862, convolution_default_474, primals_686, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_862 = convolution_default_474 = primals_686 = None
        getitem_865 = convolution_backward_default_12[0]
        getitem_866 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_865, relu__default_106, primals_685, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_865 = primals_685 = None
        getitem_868 = convolution_backward_default_13[0]
        getitem_869 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_868, torch.float32);  getitem_868 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_271, to_dtype_21);  le_scalar_7 = new_zeros_default_271 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_473, primals_677, primals_675, primals_676, getitem_785, getitem_786, True, 0.001, [True, True, True]);  to_dtype_23 = convolution_default_473 = primals_677 = primals_675 = primals_676 = getitem_785 = getitem_786 = None
        getitem_871 = native_batch_norm_backward_default_7[0]
        getitem_872 = native_batch_norm_backward_default_7[1]
        getitem_873 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_871, convolution_default_472, primals_684, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_871 = convolution_default_472 = primals_684 = None
        getitem_874 = convolution_backward_default_14[0]
        getitem_875 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_874, relu_default_149, primals_683, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_874 = primals_683 = None
        getitem_877 = convolution_backward_default_15[0]
        getitem_878 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_877, torch.float32);  getitem_877 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu_default_149, torch.float32);  relu_default_149 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_272, to_dtype_24);  le_scalar_8 = new_zeros_default_272 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(add_tensor_117, to_dtype_26);  add_tensor_117 = to_dtype_26 = None
        clone_default_4 = torch.ops.aten.clone.default(slice_tensor_1, memory_format = torch.contiguous_format);  slice_tensor_1 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(clone_default_4, convolution_default_471, primals_668, primals_666, primals_667, getitem_782, getitem_783, True, 0.001, [True, True, True]);  clone_default_4 = convolution_default_471 = primals_668 = primals_666 = primals_667 = getitem_782 = getitem_783 = None
        getitem_880 = native_batch_norm_backward_default_8[0]
        getitem_881 = native_batch_norm_backward_default_8[1]
        getitem_882 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_880, convolution_default_470, primals_672, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_880 = convolution_default_470 = primals_672 = None
        getitem_883 = convolution_backward_default_16[0]
        getitem_884 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_883, relu__default_105, primals_671, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_883 = primals_671 = None
        getitem_886 = convolution_backward_default_17[0]
        getitem_887 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_886, torch.float32);  getitem_886 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_273, to_dtype_27);  le_scalar_9 = new_zeros_default_273 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_469, primals_663, primals_661, primals_662, getitem_779, getitem_780, True, 0.001, [True, True, True]);  to_dtype_29 = convolution_default_469 = primals_663 = primals_661 = primals_662 = getitem_779 = getitem_780 = None
        getitem_889 = native_batch_norm_backward_default_9[0]
        getitem_890 = native_batch_norm_backward_default_9[1]
        getitem_891 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_889, convolution_default_468, primals_670, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_889 = convolution_default_468 = primals_670 = None
        getitem_892 = convolution_backward_default_18[0]
        getitem_893 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_892, relu_default_148, primals_669, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_892 = primals_669 = None
        getitem_895 = convolution_backward_default_19[0]
        getitem_896 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_895, torch.float32);  getitem_895 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu_default_148, torch.float32);  relu_default_148 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_274 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_274, to_dtype_30);  le_scalar_10 = new_zeros_default_274 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(add_tensor_115, to_dtype_32);  add_tensor_115 = to_dtype_32 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_119, convolution_default_467, primals_733, primals_731, primals_732, getitem_776, getitem_777, True, 0.001, [True, True, True]);  add_tensor_119 = convolution_default_467 = primals_733 = primals_731 = primals_732 = getitem_776 = getitem_777 = None
        getitem_898 = native_batch_norm_backward_default_10[0]
        getitem_899 = native_batch_norm_backward_default_10[1]
        getitem_900 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_898, relu_default_147, primals_734, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_898 = primals_734 = None
        getitem_901 = convolution_backward_default_20[0]
        getitem_902 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_901, torch.float32);  getitem_901 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu_default_147, torch.float32);  relu_default_147 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_275 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_275, to_dtype_33);  le_scalar_11 = new_zeros_default_275 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_118, convolution_default_466, primals_739, primals_737, primals_738, getitem_773, getitem_774, True, 0.001, [True, True, True]);  add_tensor_118 = convolution_default_466 = primals_739 = primals_737 = primals_738 = getitem_773 = getitem_774 = None
        getitem_904 = native_batch_norm_backward_default_11[0]
        getitem_905 = native_batch_norm_backward_default_11[1]
        getitem_906 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_904, relu_default_146, primals_740, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_904 = primals_740 = None
        getitem_907 = convolution_backward_default_21[0]
        getitem_908 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_907, torch.float32);  getitem_907 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu_default_146, torch.float32);  relu_default_146 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_276 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_276, to_dtype_36);  le_scalar_12 = new_zeros_default_276 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(to_dtype_35, 1, 0, 672)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(to_dtype_35, 1, 672, 1344)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(to_dtype_35, 1, 1344, 2016)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(to_dtype_35, 1, 2016, 2688)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(to_dtype_35, 1, 2688, 3360)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(to_dtype_35, 1, 3360, 4032);  to_dtype_35 = None
        clone_default_5 = torch.ops.aten.clone.default(slice_tensor_11, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(clone_default_5, convolution_default_465, primals_642, primals_640, primals_641, getitem_770, getitem_771, True, 0.001, [True, True, True]);  clone_default_5 = convolution_default_465 = primals_642 = primals_640 = primals_641 = getitem_770 = getitem_771 = None
        getitem_910 = native_batch_norm_backward_default_12[0]
        getitem_911 = native_batch_norm_backward_default_12[1]
        getitem_912 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_910, convolution_default_464, primals_646, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_910 = convolution_default_464 = primals_646 = None
        getitem_913 = convolution_backward_default_22[0]
        getitem_914 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_913, relu__default_104, primals_645, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_913 = primals_645 = None
        getitem_916 = convolution_backward_default_23[0]
        getitem_917 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_916, torch.float32);  getitem_916 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_277 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_277, to_dtype_39);  le_scalar_13 = new_zeros_default_277 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_463, primals_637, primals_635, primals_636, getitem_767, getitem_768, True, 0.001, [True, True, True]);  to_dtype_41 = convolution_default_463 = primals_637 = primals_635 = primals_636 = getitem_767 = getitem_768 = None
        getitem_919 = native_batch_norm_backward_default_13[0]
        getitem_920 = native_batch_norm_backward_default_13[1]
        getitem_921 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_919, convolution_default_462, primals_644, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_919 = convolution_default_462 = primals_644 = None
        getitem_922 = convolution_backward_default_24[0]
        getitem_923 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_922, relu_default_145, primals_643, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_922 = primals_643 = None
        getitem_925 = convolution_backward_default_25[0]
        getitem_926 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_925, torch.float32);  getitem_925 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu_default_145, torch.float32);  relu_default_145 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_278 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_278, to_dtype_42);  le_scalar_14 = new_zeros_default_278 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(slice_tensor_11, to_dtype_44);  slice_tensor_11 = to_dtype_44 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_10, getitem_736, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_121 = torch.ops.aten.add.Tensor(slice_tensor_6, avg_pool2d_backward_default_3);  slice_tensor_6 = avg_pool2d_backward_default_3 = None
        avg_pool2d_backward_default_4 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_10, getitem_736, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_10 = getitem_736 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(add_tensor_121, avg_pool2d_backward_default_4);  add_tensor_121 = avg_pool2d_backward_default_4 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(add_tensor_122, slice_tensor_9);  add_tensor_122 = None
        avg_pool2d_backward_default_5 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_9, getitem_739, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_9 = getitem_739 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(add_tensor_120, avg_pool2d_backward_default_5);  add_tensor_120 = avg_pool2d_backward_default_5 = None
        clone_default_6 = torch.ops.aten.clone.default(slice_tensor_8, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(clone_default_6, convolution_default_461, primals_628, primals_626, primals_627, getitem_764, getitem_765, True, 0.001, [True, True, True]);  clone_default_6 = convolution_default_461 = primals_628 = primals_626 = primals_627 = getitem_764 = getitem_765 = None
        getitem_928 = native_batch_norm_backward_default_14[0]
        getitem_929 = native_batch_norm_backward_default_14[1]
        getitem_930 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_928, convolution_default_460, primals_632, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_928 = convolution_default_460 = primals_632 = None
        getitem_931 = convolution_backward_default_26[0]
        getitem_932 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_931, relu__default_103, primals_631, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_931 = primals_631 = None
        getitem_934 = convolution_backward_default_27[0]
        getitem_935 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_934, torch.float32);  getitem_934 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_279 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_279, to_dtype_45);  le_scalar_15 = new_zeros_default_279 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_459, primals_623, primals_621, primals_622, getitem_761, getitem_762, True, 0.001, [True, True, True]);  to_dtype_47 = convolution_default_459 = primals_623 = primals_621 = primals_622 = getitem_761 = getitem_762 = None
        getitem_937 = native_batch_norm_backward_default_15[0]
        getitem_938 = native_batch_norm_backward_default_15[1]
        getitem_939 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_937, convolution_default_458, primals_630, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_937 = convolution_default_458 = primals_630 = None
        getitem_940 = convolution_backward_default_28[0]
        getitem_941 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_940, relu_default_144, primals_629, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_940 = primals_629 = None
        getitem_943 = convolution_backward_default_29[0]
        getitem_944 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_943, torch.float32);  getitem_943 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu_default_144, torch.float32);  relu_default_144 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_280 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_280, to_dtype_48);  le_scalar_16 = new_zeros_default_280 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(add_tensor_123, to_dtype_50);  add_tensor_123 = to_dtype_50 = None
        clone_default_7 = torch.ops.aten.clone.default(slice_tensor_8, memory_format = torch.contiguous_format);  slice_tensor_8 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(clone_default_7, convolution_default_457, primals_614, primals_612, primals_613, getitem_758, getitem_759, True, 0.001, [True, True, True]);  clone_default_7 = convolution_default_457 = primals_614 = primals_612 = primals_613 = getitem_758 = getitem_759 = None
        getitem_946 = native_batch_norm_backward_default_16[0]
        getitem_947 = native_batch_norm_backward_default_16[1]
        getitem_948 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_946, convolution_default_456, primals_618, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_946 = convolution_default_456 = primals_618 = None
        getitem_949 = convolution_backward_default_30[0]
        getitem_950 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_949, relu__default_102, primals_617, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_949 = primals_617 = None
        getitem_952 = convolution_backward_default_31[0]
        getitem_953 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_952, torch.float32);  getitem_952 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_281 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_281, to_dtype_51);  le_scalar_17 = new_zeros_default_281 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_455, primals_609, primals_607, primals_608, getitem_755, getitem_756, True, 0.001, [True, True, True]);  to_dtype_53 = convolution_default_455 = primals_609 = primals_607 = primals_608 = getitem_755 = getitem_756 = None
        getitem_955 = native_batch_norm_backward_default_17[0]
        getitem_956 = native_batch_norm_backward_default_17[1]
        getitem_957 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_955, convolution_default_454, primals_616, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_955 = convolution_default_454 = primals_616 = None
        getitem_958 = convolution_backward_default_32[0]
        getitem_959 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_958, relu_default_143, primals_615, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_958 = primals_615 = None
        getitem_961 = convolution_backward_default_33[0]
        getitem_962 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_961, torch.float32);  getitem_961 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu_default_143, torch.float32);  relu_default_143 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_282 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_282, to_dtype_54);  le_scalar_18 = new_zeros_default_282 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(add_tensor_125, to_dtype_56);  add_tensor_125 = to_dtype_56 = None
        clone_default_8 = torch.ops.aten.clone.default(slice_tensor_7, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(clone_default_8, convolution_default_453, primals_600, primals_598, primals_599, getitem_752, getitem_753, True, 0.001, [True, True, True]);  clone_default_8 = convolution_default_453 = primals_600 = primals_598 = primals_599 = getitem_752 = getitem_753 = None
        getitem_964 = native_batch_norm_backward_default_18[0]
        getitem_965 = native_batch_norm_backward_default_18[1]
        getitem_966 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_964, convolution_default_452, primals_604, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_964 = convolution_default_452 = primals_604 = None
        getitem_967 = convolution_backward_default_34[0]
        getitem_968 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_967, relu__default_101, primals_603, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_967 = primals_603 = None
        getitem_970 = convolution_backward_default_35[0]
        getitem_971 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_970, torch.float32);  getitem_970 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_283 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_283, to_dtype_57);  le_scalar_19 = new_zeros_default_283 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_451, primals_595, primals_593, primals_594, getitem_749, getitem_750, True, 0.001, [True, True, True]);  to_dtype_59 = convolution_default_451 = primals_595 = primals_593 = primals_594 = getitem_749 = getitem_750 = None
        getitem_973 = native_batch_norm_backward_default_19[0]
        getitem_974 = native_batch_norm_backward_default_19[1]
        getitem_975 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_973, convolution_default_450, primals_602, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_973 = convolution_default_450 = primals_602 = None
        getitem_976 = convolution_backward_default_36[0]
        getitem_977 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_976, relu_default_142, primals_601, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_976 = primals_601 = None
        getitem_979 = convolution_backward_default_37[0]
        getitem_980 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_979, torch.float32);  getitem_979 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu_default_142, torch.float32);  relu_default_142 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_284 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_284, to_dtype_60);  le_scalar_20 = new_zeros_default_284 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(add_tensor_126, to_dtype_62);  add_tensor_126 = to_dtype_62 = None
        clone_default_9 = torch.ops.aten.clone.default(slice_tensor_7, memory_format = torch.contiguous_format);  slice_tensor_7 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(clone_default_9, convolution_default_449, primals_586, primals_584, primals_585, getitem_746, getitem_747, True, 0.001, [True, True, True]);  clone_default_9 = convolution_default_449 = primals_586 = primals_584 = primals_585 = getitem_746 = getitem_747 = None
        getitem_982 = native_batch_norm_backward_default_20[0]
        getitem_983 = native_batch_norm_backward_default_20[1]
        getitem_984 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_982, convolution_default_448, primals_590, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_982 = convolution_default_448 = primals_590 = None
        getitem_985 = convolution_backward_default_38[0]
        getitem_986 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_985, relu__default_100, primals_589, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_985 = primals_589 = None
        getitem_988 = convolution_backward_default_39[0]
        getitem_989 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_988, torch.float32);  getitem_988 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_285 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_285, to_dtype_63);  le_scalar_21 = new_zeros_default_285 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_447, primals_581, primals_579, primals_580, getitem_743, getitem_744, True, 0.001, [True, True, True]);  to_dtype_65 = convolution_default_447 = primals_581 = primals_579 = primals_580 = getitem_743 = getitem_744 = None
        getitem_991 = native_batch_norm_backward_default_21[0]
        getitem_992 = native_batch_norm_backward_default_21[1]
        getitem_993 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_991, convolution_default_446, primals_588, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_991 = convolution_default_446 = primals_588 = None
        getitem_994 = convolution_backward_default_40[0]
        getitem_995 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_994, relu_default_141, primals_587, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_994 = primals_587 = None
        getitem_997 = convolution_backward_default_41[0]
        getitem_998 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_997, torch.float32);  getitem_997 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu_default_141, torch.float32);  relu_default_141 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_286 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_286, to_dtype_66);  le_scalar_22 = new_zeros_default_286 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(add_tensor_124, to_dtype_68);  add_tensor_124 = to_dtype_68 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_128, convolution_default_445, primals_651, primals_649, primals_650, getitem_740, getitem_741, True, 0.001, [True, True, True]);  add_tensor_128 = convolution_default_445 = primals_651 = primals_649 = primals_650 = getitem_740 = getitem_741 = None
        getitem_1000 = native_batch_norm_backward_default_22[0]
        getitem_1001 = native_batch_norm_backward_default_22[1]
        getitem_1002 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_1000, relu_default_140, primals_652, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1000 = primals_652 = None
        getitem_1003 = convolution_backward_default_42[0]
        getitem_1004 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_1003, torch.float32);  getitem_1003 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu_default_140, torch.float32);  relu_default_140 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_287 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_287, to_dtype_69);  le_scalar_23 = new_zeros_default_287 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(to_dtype_38, to_dtype_71);  to_dtype_38 = to_dtype_71 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_127, convolution_default_444, primals_657, primals_655, primals_656, getitem_737, getitem_738, True, 0.001, [True, True, True]);  add_tensor_127 = convolution_default_444 = primals_657 = primals_655 = primals_656 = getitem_737 = getitem_738 = None
        getitem_1006 = native_batch_norm_backward_default_23[0]
        getitem_1007 = native_batch_norm_backward_default_23[1]
        getitem_1008 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_1006, relu_default_139, primals_658, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1006 = primals_658 = None
        getitem_1009 = convolution_backward_default_43[0]
        getitem_1010 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_1009, torch.float32);  getitem_1009 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu_default_139, torch.float32);  relu_default_139 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_288 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_288, to_dtype_72);  le_scalar_24 = new_zeros_default_288 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(add_tensor_129, 1, 0, 672)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(add_tensor_129, 1, 672, 1344)
        slice_tensor_14 = torch.ops.aten.slice.Tensor(add_tensor_129, 1, 1344, 2016)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(add_tensor_129, 1, 2016, 2688)
        slice_tensor_16 = torch.ops.aten.slice.Tensor(add_tensor_129, 1, 2688, 3360)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(add_tensor_129, 1, 3360, 4032);  add_tensor_129 = None
        clone_default_10 = torch.ops.aten.clone.default(slice_tensor_17, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(clone_default_10, convolution_default_443, primals_560, primals_558, primals_559, getitem_734, getitem_735, True, 0.001, [True, True, True]);  clone_default_10 = convolution_default_443 = primals_560 = primals_558 = primals_559 = getitem_734 = getitem_735 = None
        getitem_1012 = native_batch_norm_backward_default_24[0]
        getitem_1013 = native_batch_norm_backward_default_24[1]
        getitem_1014 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_1012, convolution_default_442, primals_564, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1012 = convolution_default_442 = primals_564 = None
        getitem_1015 = convolution_backward_default_44[0]
        getitem_1016 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_1015, relu__default_99, primals_563, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1015 = primals_563 = None
        getitem_1018 = convolution_backward_default_45[0]
        getitem_1019 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_1018, torch.float32);  getitem_1018 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_289 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_289, to_dtype_75);  le_scalar_25 = new_zeros_default_289 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_441, primals_555, primals_553, primals_554, getitem_731, getitem_732, True, 0.001, [True, True, True]);  to_dtype_77 = convolution_default_441 = primals_555 = primals_553 = primals_554 = getitem_731 = getitem_732 = None
        getitem_1021 = native_batch_norm_backward_default_25[0]
        getitem_1022 = native_batch_norm_backward_default_25[1]
        getitem_1023 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_1021, convolution_default_440, primals_562, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1021 = convolution_default_440 = primals_562 = None
        getitem_1024 = convolution_backward_default_46[0]
        getitem_1025 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_1024, relu_default_138, primals_561, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1024 = primals_561 = None
        getitem_1027 = convolution_backward_default_47[0]
        getitem_1028 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_1027, torch.float32);  getitem_1027 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu_default_138, torch.float32);  relu_default_138 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_290 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_290, to_dtype_78);  le_scalar_26 = new_zeros_default_290 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(slice_tensor_17, to_dtype_80);  slice_tensor_17 = to_dtype_80 = None
        avg_pool2d_backward_default_6 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_16, getitem_700, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_131 = torch.ops.aten.add.Tensor(slice_tensor_12, avg_pool2d_backward_default_6);  slice_tensor_12 = avg_pool2d_backward_default_6 = None
        avg_pool2d_backward_default_7 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_16, getitem_700, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_16 = getitem_700 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(add_tensor_131, avg_pool2d_backward_default_7);  add_tensor_131 = avg_pool2d_backward_default_7 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_132, slice_tensor_15);  add_tensor_132 = None
        avg_pool2d_backward_default_8 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_15, getitem_703, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_15 = getitem_703 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(add_tensor_130, avg_pool2d_backward_default_8);  add_tensor_130 = avg_pool2d_backward_default_8 = None
        clone_default_11 = torch.ops.aten.clone.default(slice_tensor_14, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(clone_default_11, convolution_default_439, primals_546, primals_544, primals_545, getitem_728, getitem_729, True, 0.001, [True, True, True]);  clone_default_11 = convolution_default_439 = primals_546 = primals_544 = primals_545 = getitem_728 = getitem_729 = None
        getitem_1030 = native_batch_norm_backward_default_26[0]
        getitem_1031 = native_batch_norm_backward_default_26[1]
        getitem_1032 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_1030, convolution_default_438, primals_550, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1030 = convolution_default_438 = primals_550 = None
        getitem_1033 = convolution_backward_default_48[0]
        getitem_1034 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_1033, relu__default_98, primals_549, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1033 = primals_549 = None
        getitem_1036 = convolution_backward_default_49[0]
        getitem_1037 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_1036, torch.float32);  getitem_1036 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_291 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_291, to_dtype_81);  le_scalar_27 = new_zeros_default_291 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_437, primals_541, primals_539, primals_540, getitem_725, getitem_726, True, 0.001, [True, True, True]);  to_dtype_83 = convolution_default_437 = primals_541 = primals_539 = primals_540 = getitem_725 = getitem_726 = None
        getitem_1039 = native_batch_norm_backward_default_27[0]
        getitem_1040 = native_batch_norm_backward_default_27[1]
        getitem_1041 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_1039, convolution_default_436, primals_548, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1039 = convolution_default_436 = primals_548 = None
        getitem_1042 = convolution_backward_default_50[0]
        getitem_1043 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_1042, relu_default_137, primals_547, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1042 = primals_547 = None
        getitem_1045 = convolution_backward_default_51[0]
        getitem_1046 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_1045, torch.float32);  getitem_1045 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu_default_137, torch.float32);  relu_default_137 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_292 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_292, to_dtype_84);  le_scalar_28 = new_zeros_default_292 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(add_tensor_133, to_dtype_86);  add_tensor_133 = to_dtype_86 = None
        clone_default_12 = torch.ops.aten.clone.default(slice_tensor_14, memory_format = torch.contiguous_format);  slice_tensor_14 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(clone_default_12, convolution_default_435, primals_532, primals_530, primals_531, getitem_722, getitem_723, True, 0.001, [True, True, True]);  clone_default_12 = convolution_default_435 = primals_532 = primals_530 = primals_531 = getitem_722 = getitem_723 = None
        getitem_1048 = native_batch_norm_backward_default_28[0]
        getitem_1049 = native_batch_norm_backward_default_28[1]
        getitem_1050 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_1048, convolution_default_434, primals_536, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1048 = convolution_default_434 = primals_536 = None
        getitem_1051 = convolution_backward_default_52[0]
        getitem_1052 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_1051, relu__default_97, primals_535, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1051 = primals_535 = None
        getitem_1054 = convolution_backward_default_53[0]
        getitem_1055 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_1054, torch.float32);  getitem_1054 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_293 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_293, to_dtype_87);  le_scalar_29 = new_zeros_default_293 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_433, primals_527, primals_525, primals_526, getitem_719, getitem_720, True, 0.001, [True, True, True]);  to_dtype_89 = convolution_default_433 = primals_527 = primals_525 = primals_526 = getitem_719 = getitem_720 = None
        getitem_1057 = native_batch_norm_backward_default_29[0]
        getitem_1058 = native_batch_norm_backward_default_29[1]
        getitem_1059 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_1057, convolution_default_432, primals_534, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1057 = convolution_default_432 = primals_534 = None
        getitem_1060 = convolution_backward_default_54[0]
        getitem_1061 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_1060, relu_default_136, primals_533, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1060 = primals_533 = None
        getitem_1063 = convolution_backward_default_55[0]
        getitem_1064 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_1063, torch.float32);  getitem_1063 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu_default_136, torch.float32);  relu_default_136 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_294 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_294, to_dtype_90);  le_scalar_30 = new_zeros_default_294 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(add_tensor_135, to_dtype_92);  add_tensor_135 = to_dtype_92 = None
        clone_default_13 = torch.ops.aten.clone.default(slice_tensor_13, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(clone_default_13, convolution_default_431, primals_518, primals_516, primals_517, getitem_716, getitem_717, True, 0.001, [True, True, True]);  clone_default_13 = convolution_default_431 = primals_518 = primals_516 = primals_517 = getitem_716 = getitem_717 = None
        getitem_1066 = native_batch_norm_backward_default_30[0]
        getitem_1067 = native_batch_norm_backward_default_30[1]
        getitem_1068 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_1066, convolution_default_430, primals_522, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1066 = convolution_default_430 = primals_522 = None
        getitem_1069 = convolution_backward_default_56[0]
        getitem_1070 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_1069, relu__default_96, primals_521, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1069 = primals_521 = None
        getitem_1072 = convolution_backward_default_57[0]
        getitem_1073 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_1072, torch.float32);  getitem_1072 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_295 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_295, to_dtype_93);  le_scalar_31 = new_zeros_default_295 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_429, primals_513, primals_511, primals_512, getitem_713, getitem_714, True, 0.001, [True, True, True]);  to_dtype_95 = convolution_default_429 = primals_513 = primals_511 = primals_512 = getitem_713 = getitem_714 = None
        getitem_1075 = native_batch_norm_backward_default_31[0]
        getitem_1076 = native_batch_norm_backward_default_31[1]
        getitem_1077 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_1075, convolution_default_428, primals_520, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1075 = convolution_default_428 = primals_520 = None
        getitem_1078 = convolution_backward_default_58[0]
        getitem_1079 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_1078, relu_default_135, primals_519, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1078 = primals_519 = None
        getitem_1081 = convolution_backward_default_59[0]
        getitem_1082 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_1081, torch.float32);  getitem_1081 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu_default_135, torch.float32);  relu_default_135 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_296 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_296, to_dtype_96);  le_scalar_32 = new_zeros_default_296 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(add_tensor_136, to_dtype_98);  add_tensor_136 = to_dtype_98 = None
        clone_default_14 = torch.ops.aten.clone.default(slice_tensor_13, memory_format = torch.contiguous_format);  slice_tensor_13 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(clone_default_14, convolution_default_427, primals_504, primals_502, primals_503, getitem_710, getitem_711, True, 0.001, [True, True, True]);  clone_default_14 = convolution_default_427 = primals_504 = primals_502 = primals_503 = getitem_710 = getitem_711 = None
        getitem_1084 = native_batch_norm_backward_default_32[0]
        getitem_1085 = native_batch_norm_backward_default_32[1]
        getitem_1086 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_1084, convolution_default_426, primals_508, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1084 = convolution_default_426 = primals_508 = None
        getitem_1087 = convolution_backward_default_60[0]
        getitem_1088 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_1087, relu__default_95, primals_507, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1087 = primals_507 = None
        getitem_1090 = convolution_backward_default_61[0]
        getitem_1091 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_1090, torch.float32);  getitem_1090 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_297 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_297, to_dtype_99);  le_scalar_33 = new_zeros_default_297 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_425, primals_499, primals_497, primals_498, getitem_707, getitem_708, True, 0.001, [True, True, True]);  to_dtype_101 = convolution_default_425 = primals_499 = primals_497 = primals_498 = getitem_707 = getitem_708 = None
        getitem_1093 = native_batch_norm_backward_default_33[0]
        getitem_1094 = native_batch_norm_backward_default_33[1]
        getitem_1095 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_1093, convolution_default_424, primals_506, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1093 = convolution_default_424 = primals_506 = None
        getitem_1096 = convolution_backward_default_62[0]
        getitem_1097 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_1096, relu_default_134, primals_505, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1096 = primals_505 = None
        getitem_1099 = convolution_backward_default_63[0]
        getitem_1100 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_1099, torch.float32);  getitem_1099 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu_default_134, torch.float32);  relu_default_134 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_298 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_298, to_dtype_102);  le_scalar_34 = new_zeros_default_298 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(add_tensor_134, to_dtype_104);  add_tensor_134 = to_dtype_104 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_138, convolution_default_423, primals_569, primals_567, primals_568, getitem_704, getitem_705, True, 0.001, [True, True, True]);  add_tensor_138 = convolution_default_423 = primals_569 = primals_567 = primals_568 = getitem_704 = getitem_705 = None
        getitem_1102 = native_batch_norm_backward_default_34[0]
        getitem_1103 = native_batch_norm_backward_default_34[1]
        getitem_1104 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_1102, relu_default_133, primals_570, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1102 = primals_570 = None
        getitem_1105 = convolution_backward_default_64[0]
        getitem_1106 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_1105, torch.float32);  getitem_1105 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu_default_133, torch.float32);  relu_default_133 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_299 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_299, to_dtype_105);  le_scalar_35 = new_zeros_default_299 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(to_dtype_74, to_dtype_107);  to_dtype_74 = to_dtype_107 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_137, convolution_default_422, primals_575, primals_573, primals_574, getitem_701, getitem_702, True, 0.001, [True, True, True]);  add_tensor_137 = convolution_default_422 = primals_575 = primals_573 = primals_574 = getitem_701 = getitem_702 = None
        getitem_1108 = native_batch_norm_backward_default_35[0]
        getitem_1109 = native_batch_norm_backward_default_35[1]
        getitem_1110 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_1108, relu_default_132, primals_576, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1108 = primals_576 = None
        getitem_1111 = convolution_backward_default_65[0]
        getitem_1112 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_1111, torch.float32);  getitem_1111 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu_default_132, torch.float32);  relu_default_132 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_300 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_300, to_dtype_108);  le_scalar_36 = new_zeros_default_300 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        slice_tensor_18 = torch.ops.aten.slice.Tensor(add_tensor_139, 1, 0, 672)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(add_tensor_139, 1, 672, 1344)
        slice_tensor_20 = torch.ops.aten.slice.Tensor(add_tensor_139, 1, 1344, 2016)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(add_tensor_139, 1, 2016, 2688)
        slice_tensor_22 = torch.ops.aten.slice.Tensor(add_tensor_139, 1, 2688, 3360)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(add_tensor_139, 1, 3360, 4032);  add_tensor_139 = None
        clone_default_15 = torch.ops.aten.clone.default(slice_tensor_23, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(clone_default_15, convolution_default_421, primals_478, primals_476, primals_477, getitem_698, getitem_699, True, 0.001, [True, True, True]);  clone_default_15 = convolution_default_421 = primals_478 = primals_476 = primals_477 = getitem_698 = getitem_699 = None
        getitem_1114 = native_batch_norm_backward_default_36[0]
        getitem_1115 = native_batch_norm_backward_default_36[1]
        getitem_1116 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_1114, convolution_default_420, primals_482, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1114 = convolution_default_420 = primals_482 = None
        getitem_1117 = convolution_backward_default_66[0]
        getitem_1118 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_1117, relu__default_94, primals_481, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1117 = primals_481 = None
        getitem_1120 = convolution_backward_default_67[0]
        getitem_1121 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_1120, torch.float32);  getitem_1120 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_301 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_301, to_dtype_111);  le_scalar_37 = new_zeros_default_301 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_419, primals_473, primals_471, primals_472, getitem_695, getitem_696, True, 0.001, [True, True, True]);  to_dtype_113 = convolution_default_419 = primals_473 = primals_471 = primals_472 = getitem_695 = getitem_696 = None
        getitem_1123 = native_batch_norm_backward_default_37[0]
        getitem_1124 = native_batch_norm_backward_default_37[1]
        getitem_1125 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_1123, convolution_default_418, primals_480, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1123 = convolution_default_418 = primals_480 = None
        getitem_1126 = convolution_backward_default_68[0]
        getitem_1127 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_1126, relu_default_131, primals_479, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1126 = primals_479 = None
        getitem_1129 = convolution_backward_default_69[0]
        getitem_1130 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_1129, torch.float32);  getitem_1129 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu_default_131, torch.float32);  relu_default_131 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_302 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_302, to_dtype_114);  le_scalar_38 = new_zeros_default_302 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(slice_tensor_23, to_dtype_116);  slice_tensor_23 = to_dtype_116 = None
        avg_pool2d_backward_default_9 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_22, getitem_664, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_141 = torch.ops.aten.add.Tensor(slice_tensor_18, avg_pool2d_backward_default_9);  slice_tensor_18 = avg_pool2d_backward_default_9 = None
        avg_pool2d_backward_default_10 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_22, getitem_664, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_22 = getitem_664 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(add_tensor_141, avg_pool2d_backward_default_10);  add_tensor_141 = avg_pool2d_backward_default_10 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(add_tensor_142, slice_tensor_21);  add_tensor_142 = None
        avg_pool2d_backward_default_11 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_21, getitem_667, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_21 = getitem_667 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(add_tensor_140, avg_pool2d_backward_default_11);  add_tensor_140 = avg_pool2d_backward_default_11 = None
        clone_default_16 = torch.ops.aten.clone.default(slice_tensor_20, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(clone_default_16, convolution_default_417, primals_464, primals_462, primals_463, getitem_692, getitem_693, True, 0.001, [True, True, True]);  clone_default_16 = convolution_default_417 = primals_464 = primals_462 = primals_463 = getitem_692 = getitem_693 = None
        getitem_1132 = native_batch_norm_backward_default_38[0]
        getitem_1133 = native_batch_norm_backward_default_38[1]
        getitem_1134 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_1132, convolution_default_416, primals_468, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1132 = convolution_default_416 = primals_468 = None
        getitem_1135 = convolution_backward_default_70[0]
        getitem_1136 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_1135, relu__default_93, primals_467, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1135 = primals_467 = None
        getitem_1138 = convolution_backward_default_71[0]
        getitem_1139 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_1138, torch.float32);  getitem_1138 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_303 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_303, to_dtype_117);  le_scalar_39 = new_zeros_default_303 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_415, primals_459, primals_457, primals_458, getitem_689, getitem_690, True, 0.001, [True, True, True]);  to_dtype_119 = convolution_default_415 = primals_459 = primals_457 = primals_458 = getitem_689 = getitem_690 = None
        getitem_1141 = native_batch_norm_backward_default_39[0]
        getitem_1142 = native_batch_norm_backward_default_39[1]
        getitem_1143 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_1141, convolution_default_414, primals_466, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1141 = convolution_default_414 = primals_466 = None
        getitem_1144 = convolution_backward_default_72[0]
        getitem_1145 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_1144, relu_default_130, primals_465, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1144 = primals_465 = None
        getitem_1147 = convolution_backward_default_73[0]
        getitem_1148 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_1147, torch.float32);  getitem_1147 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu_default_130, torch.float32);  relu_default_130 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_304 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_304, to_dtype_120);  le_scalar_40 = new_zeros_default_304 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(add_tensor_143, to_dtype_122);  add_tensor_143 = to_dtype_122 = None
        clone_default_17 = torch.ops.aten.clone.default(slice_tensor_20, memory_format = torch.contiguous_format);  slice_tensor_20 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(clone_default_17, convolution_default_413, primals_450, primals_448, primals_449, getitem_686, getitem_687, True, 0.001, [True, True, True]);  clone_default_17 = convolution_default_413 = primals_450 = primals_448 = primals_449 = getitem_686 = getitem_687 = None
        getitem_1150 = native_batch_norm_backward_default_40[0]
        getitem_1151 = native_batch_norm_backward_default_40[1]
        getitem_1152 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_1150, convolution_default_412, primals_454, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1150 = convolution_default_412 = primals_454 = None
        getitem_1153 = convolution_backward_default_74[0]
        getitem_1154 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_1153, relu__default_92, primals_453, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1153 = primals_453 = None
        getitem_1156 = convolution_backward_default_75[0]
        getitem_1157 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_1156, torch.float32);  getitem_1156 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_305 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_305, to_dtype_123);  le_scalar_41 = new_zeros_default_305 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_411, primals_445, primals_443, primals_444, getitem_683, getitem_684, True, 0.001, [True, True, True]);  to_dtype_125 = convolution_default_411 = primals_445 = primals_443 = primals_444 = getitem_683 = getitem_684 = None
        getitem_1159 = native_batch_norm_backward_default_41[0]
        getitem_1160 = native_batch_norm_backward_default_41[1]
        getitem_1161 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_1159, convolution_default_410, primals_452, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1159 = convolution_default_410 = primals_452 = None
        getitem_1162 = convolution_backward_default_76[0]
        getitem_1163 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_1162, relu_default_129, primals_451, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1162 = primals_451 = None
        getitem_1165 = convolution_backward_default_77[0]
        getitem_1166 = convolution_backward_default_77[1];  convolution_backward_default_77 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_1165, torch.float32);  getitem_1165 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu_default_129, torch.float32);  relu_default_129 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_306 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_306, to_dtype_126);  le_scalar_42 = new_zeros_default_306 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(add_tensor_145, to_dtype_128);  add_tensor_145 = to_dtype_128 = None
        clone_default_18 = torch.ops.aten.clone.default(slice_tensor_19, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(clone_default_18, convolution_default_409, primals_436, primals_434, primals_435, getitem_680, getitem_681, True, 0.001, [True, True, True]);  clone_default_18 = convolution_default_409 = primals_436 = primals_434 = primals_435 = getitem_680 = getitem_681 = None
        getitem_1168 = native_batch_norm_backward_default_42[0]
        getitem_1169 = native_batch_norm_backward_default_42[1]
        getitem_1170 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_1168, convolution_default_408, primals_440, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1168 = convolution_default_408 = primals_440 = None
        getitem_1171 = convolution_backward_default_78[0]
        getitem_1172 = convolution_backward_default_78[1];  convolution_backward_default_78 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_1171, relu__default_91, primals_439, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1171 = primals_439 = None
        getitem_1174 = convolution_backward_default_79[0]
        getitem_1175 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_1174, torch.float32);  getitem_1174 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_307 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_307, to_dtype_129);  le_scalar_43 = new_zeros_default_307 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_407, primals_431, primals_429, primals_430, getitem_677, getitem_678, True, 0.001, [True, True, True]);  to_dtype_131 = convolution_default_407 = primals_431 = primals_429 = primals_430 = getitem_677 = getitem_678 = None
        getitem_1177 = native_batch_norm_backward_default_43[0]
        getitem_1178 = native_batch_norm_backward_default_43[1]
        getitem_1179 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_1177, convolution_default_406, primals_438, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1177 = convolution_default_406 = primals_438 = None
        getitem_1180 = convolution_backward_default_80[0]
        getitem_1181 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_1180, relu_default_128, primals_437, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1180 = primals_437 = None
        getitem_1183 = convolution_backward_default_81[0]
        getitem_1184 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_1183, torch.float32);  getitem_1183 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu_default_128, torch.float32);  relu_default_128 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_308 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_308, to_dtype_132);  le_scalar_44 = new_zeros_default_308 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(add_tensor_146, to_dtype_134);  add_tensor_146 = to_dtype_134 = None
        clone_default_19 = torch.ops.aten.clone.default(slice_tensor_19, memory_format = torch.contiguous_format);  slice_tensor_19 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(clone_default_19, convolution_default_405, primals_422, primals_420, primals_421, getitem_674, getitem_675, True, 0.001, [True, True, True]);  clone_default_19 = convolution_default_405 = primals_422 = primals_420 = primals_421 = getitem_674 = getitem_675 = None
        getitem_1186 = native_batch_norm_backward_default_44[0]
        getitem_1187 = native_batch_norm_backward_default_44[1]
        getitem_1188 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_1186, convolution_default_404, primals_426, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1186 = convolution_default_404 = primals_426 = None
        getitem_1189 = convolution_backward_default_82[0]
        getitem_1190 = convolution_backward_default_82[1];  convolution_backward_default_82 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_1189, relu__default_90, primals_425, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1189 = primals_425 = None
        getitem_1192 = convolution_backward_default_83[0]
        getitem_1193 = convolution_backward_default_83[1];  convolution_backward_default_83 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_1192, torch.float32);  getitem_1192 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_309 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_309, to_dtype_135);  le_scalar_45 = new_zeros_default_309 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_403, primals_417, primals_415, primals_416, getitem_671, getitem_672, True, 0.001, [True, True, True]);  to_dtype_137 = convolution_default_403 = primals_417 = primals_415 = primals_416 = getitem_671 = getitem_672 = None
        getitem_1195 = native_batch_norm_backward_default_45[0]
        getitem_1196 = native_batch_norm_backward_default_45[1]
        getitem_1197 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_1195, convolution_default_402, primals_424, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1195 = convolution_default_402 = primals_424 = None
        getitem_1198 = convolution_backward_default_84[0]
        getitem_1199 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_1198, relu_default_127, primals_423, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1198 = primals_423 = None
        getitem_1201 = convolution_backward_default_85[0]
        getitem_1202 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_1201, torch.float32);  getitem_1201 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu_default_127, torch.float32);  relu_default_127 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_310 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_310, to_dtype_138);  le_scalar_46 = new_zeros_default_310 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(add_tensor_144, to_dtype_140);  add_tensor_144 = to_dtype_140 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_148, convolution_default_401, primals_487, primals_485, primals_486, getitem_668, getitem_669, True, 0.001, [True, True, True]);  add_tensor_148 = convolution_default_401 = primals_487 = primals_485 = primals_486 = getitem_668 = getitem_669 = None
        getitem_1204 = native_batch_norm_backward_default_46[0]
        getitem_1205 = native_batch_norm_backward_default_46[1]
        getitem_1206 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_1204, relu_default_126, primals_488, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1204 = primals_488 = None
        getitem_1207 = convolution_backward_default_86[0]
        getitem_1208 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_1207, torch.float32);  getitem_1207 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu_default_126, torch.float32);  relu_default_126 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_311 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_311, to_dtype_141);  le_scalar_47 = new_zeros_default_311 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(to_dtype_110, to_dtype_143);  to_dtype_110 = to_dtype_143 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_147, convolution_default_400, primals_493, primals_491, primals_492, getitem_665, getitem_666, True, 0.001, [True, True, True]);  add_tensor_147 = convolution_default_400 = primals_493 = primals_491 = primals_492 = getitem_665 = getitem_666 = None
        getitem_1210 = native_batch_norm_backward_default_47[0]
        getitem_1211 = native_batch_norm_backward_default_47[1]
        getitem_1212 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_1210, relu_default_125, primals_494, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1210 = primals_494 = None
        getitem_1213 = convolution_backward_default_87[0]
        getitem_1214 = convolution_backward_default_87[1];  convolution_backward_default_87 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_1213, torch.float32);  getitem_1213 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu_default_125, torch.float32);  relu_default_125 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_312 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_312, to_dtype_144);  le_scalar_48 = new_zeros_default_312 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(add_tensor_149, 1, 0, 672)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(add_tensor_149, 1, 672, 1344)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(add_tensor_149, 1, 1344, 2016)
        slice_tensor_27 = torch.ops.aten.slice.Tensor(add_tensor_149, 1, 2016, 2688)
        slice_tensor_28 = torch.ops.aten.slice.Tensor(add_tensor_149, 1, 2688, 3360)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(add_tensor_149, 1, 3360, 4032);  add_tensor_149 = None
        clone_default_20 = torch.ops.aten.clone.default(slice_tensor_29, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(clone_default_20, convolution_default_399, primals_396, primals_394, primals_395, getitem_662, getitem_663, True, 0.001, [True, True, True]);  clone_default_20 = convolution_default_399 = primals_396 = primals_394 = primals_395 = getitem_662 = getitem_663 = None
        getitem_1216 = native_batch_norm_backward_default_48[0]
        getitem_1217 = native_batch_norm_backward_default_48[1]
        getitem_1218 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_1216, convolution_default_398, primals_400, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1216 = convolution_default_398 = primals_400 = None
        getitem_1219 = convolution_backward_default_88[0]
        getitem_1220 = convolution_backward_default_88[1];  convolution_backward_default_88 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_1219, relu__default_89, primals_399, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1219 = primals_399 = None
        getitem_1222 = convolution_backward_default_89[0]
        getitem_1223 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_1222, torch.float32);  getitem_1222 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_313 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_313, to_dtype_147);  le_scalar_49 = new_zeros_default_313 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_397, primals_391, primals_389, primals_390, getitem_659, getitem_660, True, 0.001, [True, True, True]);  to_dtype_149 = convolution_default_397 = primals_391 = primals_389 = primals_390 = getitem_659 = getitem_660 = None
        getitem_1225 = native_batch_norm_backward_default_49[0]
        getitem_1226 = native_batch_norm_backward_default_49[1]
        getitem_1227 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_1225, convolution_default_396, primals_398, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1225 = convolution_default_396 = primals_398 = None
        getitem_1228 = convolution_backward_default_90[0]
        getitem_1229 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_1228, relu_default_124, primals_397, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1228 = primals_397 = None
        getitem_1231 = convolution_backward_default_91[0]
        getitem_1232 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_1231, torch.float32);  getitem_1231 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu_default_124, torch.float32);  relu_default_124 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_314 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_314, to_dtype_150);  le_scalar_50 = new_zeros_default_314 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(slice_tensor_29, to_dtype_152);  slice_tensor_29 = to_dtype_152 = None
        avg_pool2d_backward_default_12 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_28, getitem_628, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_151 = torch.ops.aten.add.Tensor(slice_tensor_24, avg_pool2d_backward_default_12);  slice_tensor_24 = avg_pool2d_backward_default_12 = None
        avg_pool2d_backward_default_13 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_28, getitem_628, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_28 = getitem_628 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(add_tensor_151, avg_pool2d_backward_default_13);  add_tensor_151 = avg_pool2d_backward_default_13 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(add_tensor_152, slice_tensor_27);  add_tensor_152 = None
        avg_pool2d_backward_default_14 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_27, getitem_631, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_27 = getitem_631 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(add_tensor_150, avg_pool2d_backward_default_14);  add_tensor_150 = avg_pool2d_backward_default_14 = None
        clone_default_21 = torch.ops.aten.clone.default(slice_tensor_26, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(clone_default_21, convolution_default_395, primals_382, primals_380, primals_381, getitem_656, getitem_657, True, 0.001, [True, True, True]);  clone_default_21 = convolution_default_395 = primals_382 = primals_380 = primals_381 = getitem_656 = getitem_657 = None
        getitem_1234 = native_batch_norm_backward_default_50[0]
        getitem_1235 = native_batch_norm_backward_default_50[1]
        getitem_1236 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_1234, convolution_default_394, primals_386, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1234 = convolution_default_394 = primals_386 = None
        getitem_1237 = convolution_backward_default_92[0]
        getitem_1238 = convolution_backward_default_92[1];  convolution_backward_default_92 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_1237, relu__default_88, primals_385, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1237 = primals_385 = None
        getitem_1240 = convolution_backward_default_93[0]
        getitem_1241 = convolution_backward_default_93[1];  convolution_backward_default_93 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_1240, torch.float32);  getitem_1240 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_315 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_315, to_dtype_153);  le_scalar_51 = new_zeros_default_315 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_393, primals_377, primals_375, primals_376, getitem_653, getitem_654, True, 0.001, [True, True, True]);  to_dtype_155 = convolution_default_393 = primals_377 = primals_375 = primals_376 = getitem_653 = getitem_654 = None
        getitem_1243 = native_batch_norm_backward_default_51[0]
        getitem_1244 = native_batch_norm_backward_default_51[1]
        getitem_1245 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_1243, convolution_default_392, primals_384, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1243 = convolution_default_392 = primals_384 = None
        getitem_1246 = convolution_backward_default_94[0]
        getitem_1247 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_1246, relu_default_123, primals_383, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1246 = primals_383 = None
        getitem_1249 = convolution_backward_default_95[0]
        getitem_1250 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_1249, torch.float32);  getitem_1249 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu_default_123, torch.float32);  relu_default_123 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_316 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_316, to_dtype_156);  le_scalar_52 = new_zeros_default_316 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(add_tensor_153, to_dtype_158);  add_tensor_153 = to_dtype_158 = None
        clone_default_22 = torch.ops.aten.clone.default(slice_tensor_26, memory_format = torch.contiguous_format);  slice_tensor_26 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(clone_default_22, convolution_default_391, primals_368, primals_366, primals_367, getitem_650, getitem_651, True, 0.001, [True, True, True]);  clone_default_22 = convolution_default_391 = primals_368 = primals_366 = primals_367 = getitem_650 = getitem_651 = None
        getitem_1252 = native_batch_norm_backward_default_52[0]
        getitem_1253 = native_batch_norm_backward_default_52[1]
        getitem_1254 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_1252, convolution_default_390, primals_372, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1252 = convolution_default_390 = primals_372 = None
        getitem_1255 = convolution_backward_default_96[0]
        getitem_1256 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_1255, relu__default_87, primals_371, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1255 = primals_371 = None
        getitem_1258 = convolution_backward_default_97[0]
        getitem_1259 = convolution_backward_default_97[1];  convolution_backward_default_97 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_1258, torch.float32);  getitem_1258 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_317 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_317, to_dtype_159);  le_scalar_53 = new_zeros_default_317 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_389, primals_363, primals_361, primals_362, getitem_647, getitem_648, True, 0.001, [True, True, True]);  to_dtype_161 = convolution_default_389 = primals_363 = primals_361 = primals_362 = getitem_647 = getitem_648 = None
        getitem_1261 = native_batch_norm_backward_default_53[0]
        getitem_1262 = native_batch_norm_backward_default_53[1]
        getitem_1263 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_1261, convolution_default_388, primals_370, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1261 = convolution_default_388 = primals_370 = None
        getitem_1264 = convolution_backward_default_98[0]
        getitem_1265 = convolution_backward_default_98[1];  convolution_backward_default_98 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_1264, relu_default_122, primals_369, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1264 = primals_369 = None
        getitem_1267 = convolution_backward_default_99[0]
        getitem_1268 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_1267, torch.float32);  getitem_1267 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu_default_122, torch.float32);  relu_default_122 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_318 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_318, to_dtype_162);  le_scalar_54 = new_zeros_default_318 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(add_tensor_155, to_dtype_164);  add_tensor_155 = to_dtype_164 = None
        clone_default_23 = torch.ops.aten.clone.default(slice_tensor_25, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(clone_default_23, convolution_default_387, primals_354, primals_352, primals_353, getitem_644, getitem_645, True, 0.001, [True, True, True]);  clone_default_23 = convolution_default_387 = primals_354 = primals_352 = primals_353 = getitem_644 = getitem_645 = None
        getitem_1270 = native_batch_norm_backward_default_54[0]
        getitem_1271 = native_batch_norm_backward_default_54[1]
        getitem_1272 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_1270, convolution_default_386, primals_358, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1270 = convolution_default_386 = primals_358 = None
        getitem_1273 = convolution_backward_default_100[0]
        getitem_1274 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1273, relu__default_86, primals_357, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1273 = primals_357 = None
        getitem_1276 = convolution_backward_default_101[0]
        getitem_1277 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_1276, torch.float32);  getitem_1276 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_319 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_319, to_dtype_165);  le_scalar_55 = new_zeros_default_319 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_385, primals_349, primals_347, primals_348, getitem_641, getitem_642, True, 0.001, [True, True, True]);  to_dtype_167 = convolution_default_385 = primals_349 = primals_347 = primals_348 = getitem_641 = getitem_642 = None
        getitem_1279 = native_batch_norm_backward_default_55[0]
        getitem_1280 = native_batch_norm_backward_default_55[1]
        getitem_1281 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1279, convolution_default_384, primals_356, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1279 = convolution_default_384 = primals_356 = None
        getitem_1282 = convolution_backward_default_102[0]
        getitem_1283 = convolution_backward_default_102[1];  convolution_backward_default_102 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_1282, relu_default_121, primals_355, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1282 = primals_355 = None
        getitem_1285 = convolution_backward_default_103[0]
        getitem_1286 = convolution_backward_default_103[1];  convolution_backward_default_103 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_1285, torch.float32);  getitem_1285 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu_default_121, torch.float32);  relu_default_121 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_320 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_320, to_dtype_168);  le_scalar_56 = new_zeros_default_320 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(add_tensor_156, to_dtype_170);  add_tensor_156 = to_dtype_170 = None
        clone_default_24 = torch.ops.aten.clone.default(slice_tensor_25, memory_format = torch.contiguous_format);  slice_tensor_25 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(clone_default_24, convolution_default_383, primals_340, primals_338, primals_339, getitem_638, getitem_639, True, 0.001, [True, True, True]);  clone_default_24 = convolution_default_383 = primals_340 = primals_338 = primals_339 = getitem_638 = getitem_639 = None
        getitem_1288 = native_batch_norm_backward_default_56[0]
        getitem_1289 = native_batch_norm_backward_default_56[1]
        getitem_1290 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_1288, convolution_default_382, primals_344, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1288 = convolution_default_382 = primals_344 = None
        getitem_1291 = convolution_backward_default_104[0]
        getitem_1292 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_1291, relu__default_85, primals_343, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1291 = primals_343 = None
        getitem_1294 = convolution_backward_default_105[0]
        getitem_1295 = convolution_backward_default_105[1];  convolution_backward_default_105 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_1294, torch.float32);  getitem_1294 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_321 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_321, to_dtype_171);  le_scalar_57 = new_zeros_default_321 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_381, primals_335, primals_333, primals_334, getitem_635, getitem_636, True, 0.001, [True, True, True]);  to_dtype_173 = convolution_default_381 = primals_335 = primals_333 = primals_334 = getitem_635 = getitem_636 = None
        getitem_1297 = native_batch_norm_backward_default_57[0]
        getitem_1298 = native_batch_norm_backward_default_57[1]
        getitem_1299 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_1297, convolution_default_380, primals_342, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1297 = convolution_default_380 = primals_342 = None
        getitem_1300 = convolution_backward_default_106[0]
        getitem_1301 = convolution_backward_default_106[1];  convolution_backward_default_106 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_1300, relu_default_120, primals_341, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1300 = primals_341 = None
        getitem_1303 = convolution_backward_default_107[0]
        getitem_1304 = convolution_backward_default_107[1];  convolution_backward_default_107 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_1303, torch.float32);  getitem_1303 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu_default_120, torch.float32);  relu_default_120 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_322 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_322, to_dtype_174);  le_scalar_58 = new_zeros_default_322 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(add_tensor_154, to_dtype_176);  add_tensor_154 = to_dtype_176 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_158, convolution_default_379, primals_405, primals_403, primals_404, getitem_632, getitem_633, True, 0.001, [True, True, True]);  add_tensor_158 = convolution_default_379 = primals_405 = primals_403 = primals_404 = getitem_632 = getitem_633 = None
        getitem_1306 = native_batch_norm_backward_default_58[0]
        getitem_1307 = native_batch_norm_backward_default_58[1]
        getitem_1308 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1306, relu_default_119, primals_406, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1306 = primals_406 = None
        getitem_1309 = convolution_backward_default_108[0]
        getitem_1310 = convolution_backward_default_108[1];  convolution_backward_default_108 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_1309, torch.float32);  getitem_1309 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu_default_119, torch.float32);  relu_default_119 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_323 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_323, to_dtype_177);  le_scalar_59 = new_zeros_default_323 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(to_dtype_146, to_dtype_179);  to_dtype_146 = to_dtype_179 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_157, convolution_default_378, primals_411, primals_409, primals_410, getitem_629, getitem_630, True, 0.001, [True, True, True]);  add_tensor_157 = convolution_default_378 = primals_411 = primals_409 = primals_410 = getitem_629 = getitem_630 = None
        getitem_1312 = native_batch_norm_backward_default_59[0]
        getitem_1313 = native_batch_norm_backward_default_59[1]
        getitem_1314 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1312, relu_default_118, primals_412, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1312 = primals_412 = None
        getitem_1315 = convolution_backward_default_109[0]
        getitem_1316 = convolution_backward_default_109[1];  convolution_backward_default_109 = None
        to_dtype_180 = torch.ops.aten.to.dtype(getitem_1315, torch.float32);  getitem_1315 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu_default_118, torch.float32);  relu_default_118 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_324 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_324, to_dtype_180);  le_scalar_60 = new_zeros_default_324 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        slice_tensor_30 = torch.ops.aten.slice.Tensor(add_tensor_159, 1, 0, 672)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(add_tensor_159, 1, 672, 1344)
        slice_tensor_32 = torch.ops.aten.slice.Tensor(add_tensor_159, 1, 1344, 2016)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(add_tensor_159, 1, 2016, 2688)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(add_tensor_159, 1, 2688, 3360)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(add_tensor_159, 1, 3360, 4032);  add_tensor_159 = None
        clone_default_25 = torch.ops.aten.clone.default(slice_tensor_35, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(clone_default_25, convolution_default_377, primals_313, primals_311, primals_312, getitem_626, getitem_627, True, 0.001, [True, True, True]);  clone_default_25 = convolution_default_377 = primals_313 = primals_311 = primals_312 = getitem_626 = getitem_627 = None
        getitem_1318 = native_batch_norm_backward_default_60[0]
        getitem_1319 = native_batch_norm_backward_default_60[1]
        getitem_1320 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1318, convolution_default_376, primals_317, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1318 = convolution_default_376 = primals_317 = None
        getitem_1321 = convolution_backward_default_110[0]
        getitem_1322 = convolution_backward_default_110[1];  convolution_backward_default_110 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1321, relu__default_84, primals_316, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1321 = primals_316 = None
        getitem_1324 = convolution_backward_default_111[0]
        getitem_1325 = convolution_backward_default_111[1];  convolution_backward_default_111 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_1324, torch.float32);  getitem_1324 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_325 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_325, to_dtype_183);  le_scalar_61 = new_zeros_default_325 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_375, primals_308, primals_306, primals_307, getitem_623, getitem_624, True, 0.001, [True, True, True]);  to_dtype_185 = convolution_default_375 = primals_308 = primals_306 = primals_307 = getitem_623 = getitem_624 = None
        getitem_1327 = native_batch_norm_backward_default_61[0]
        getitem_1328 = native_batch_norm_backward_default_61[1]
        getitem_1329 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_1327, convolution_default_374, primals_315, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1327 = convolution_default_374 = primals_315 = None
        getitem_1330 = convolution_backward_default_112[0]
        getitem_1331 = convolution_backward_default_112[1];  convolution_backward_default_112 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1330, relu_default_117, primals_314, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1330 = primals_314 = None
        getitem_1333 = convolution_backward_default_113[0]
        getitem_1334 = convolution_backward_default_113[1];  convolution_backward_default_113 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_1333, torch.float32);  getitem_1333 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu_default_117, torch.float32);  relu_default_117 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_326 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_326, to_dtype_186);  le_scalar_62 = new_zeros_default_326 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(slice_tensor_35, to_dtype_188);  slice_tensor_35 = to_dtype_188 = None
        avg_pool2d_backward_default_15 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_34, getitem_592, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_161 = torch.ops.aten.add.Tensor(slice_tensor_30, avg_pool2d_backward_default_15);  slice_tensor_30 = avg_pool2d_backward_default_15 = None
        avg_pool2d_backward_default_16 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_34, getitem_592, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_34 = getitem_592 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(add_tensor_161, avg_pool2d_backward_default_16);  add_tensor_161 = avg_pool2d_backward_default_16 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(add_tensor_162, slice_tensor_33);  add_tensor_162 = None
        avg_pool2d_backward_default_17 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_33, getitem_595, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_33 = getitem_595 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(add_tensor_160, avg_pool2d_backward_default_17);  add_tensor_160 = avg_pool2d_backward_default_17 = None
        clone_default_26 = torch.ops.aten.clone.default(slice_tensor_32, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(clone_default_26, convolution_default_373, primals_299, primals_297, primals_298, getitem_620, getitem_621, True, 0.001, [True, True, True]);  clone_default_26 = convolution_default_373 = primals_299 = primals_297 = primals_298 = getitem_620 = getitem_621 = None
        getitem_1336 = native_batch_norm_backward_default_62[0]
        getitem_1337 = native_batch_norm_backward_default_62[1]
        getitem_1338 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1336, convolution_default_372, primals_303, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1336 = convolution_default_372 = primals_303 = None
        getitem_1339 = convolution_backward_default_114[0]
        getitem_1340 = convolution_backward_default_114[1];  convolution_backward_default_114 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1339, relu__default_83, primals_302, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1339 = primals_302 = None
        getitem_1342 = convolution_backward_default_115[0]
        getitem_1343 = convolution_backward_default_115[1];  convolution_backward_default_115 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_1342, torch.float32);  getitem_1342 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_327 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_327, to_dtype_189);  le_scalar_63 = new_zeros_default_327 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_371, primals_294, primals_292, primals_293, getitem_617, getitem_618, True, 0.001, [True, True, True]);  to_dtype_191 = convolution_default_371 = primals_294 = primals_292 = primals_293 = getitem_617 = getitem_618 = None
        getitem_1345 = native_batch_norm_backward_default_63[0]
        getitem_1346 = native_batch_norm_backward_default_63[1]
        getitem_1347 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1345, convolution_default_370, primals_301, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1345 = convolution_default_370 = primals_301 = None
        getitem_1348 = convolution_backward_default_116[0]
        getitem_1349 = convolution_backward_default_116[1];  convolution_backward_default_116 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_1348, relu_default_116, primals_300, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1348 = primals_300 = None
        getitem_1351 = convolution_backward_default_117[0]
        getitem_1352 = convolution_backward_default_117[1];  convolution_backward_default_117 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_1351, torch.float32);  getitem_1351 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu_default_116, torch.float32);  relu_default_116 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_328 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_328, to_dtype_192);  le_scalar_64 = new_zeros_default_328 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(add_tensor_163, to_dtype_194);  add_tensor_163 = to_dtype_194 = None
        clone_default_27 = torch.ops.aten.clone.default(slice_tensor_32, memory_format = torch.contiguous_format);  slice_tensor_32 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(clone_default_27, convolution_default_369, primals_285, primals_283, primals_284, getitem_614, getitem_615, True, 0.001, [True, True, True]);  clone_default_27 = convolution_default_369 = primals_285 = primals_283 = primals_284 = getitem_614 = getitem_615 = None
        getitem_1354 = native_batch_norm_backward_default_64[0]
        getitem_1355 = native_batch_norm_backward_default_64[1]
        getitem_1356 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1354, convolution_default_368, primals_289, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1354 = convolution_default_368 = primals_289 = None
        getitem_1357 = convolution_backward_default_118[0]
        getitem_1358 = convolution_backward_default_118[1];  convolution_backward_default_118 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1357, relu__default_82, primals_288, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1357 = primals_288 = None
        getitem_1360 = convolution_backward_default_119[0]
        getitem_1361 = convolution_backward_default_119[1];  convolution_backward_default_119 = None
        to_dtype_195 = torch.ops.aten.to.dtype(getitem_1360, torch.float32);  getitem_1360 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_329 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_329, to_dtype_195);  le_scalar_65 = new_zeros_default_329 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_367, primals_280, primals_278, primals_279, getitem_611, getitem_612, True, 0.001, [True, True, True]);  to_dtype_197 = convolution_default_367 = primals_280 = primals_278 = primals_279 = getitem_611 = getitem_612 = None
        getitem_1363 = native_batch_norm_backward_default_65[0]
        getitem_1364 = native_batch_norm_backward_default_65[1]
        getitem_1365 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1363, convolution_default_366, primals_287, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1363 = convolution_default_366 = primals_287 = None
        getitem_1366 = convolution_backward_default_120[0]
        getitem_1367 = convolution_backward_default_120[1];  convolution_backward_default_120 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1366, relu_default_115, primals_286, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1366 = primals_286 = None
        getitem_1369 = convolution_backward_default_121[0]
        getitem_1370 = convolution_backward_default_121[1];  convolution_backward_default_121 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_1369, torch.float32);  getitem_1369 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu_default_115, torch.float32);  relu_default_115 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_330 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_330, to_dtype_198);  le_scalar_66 = new_zeros_default_330 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(add_tensor_165, to_dtype_200);  add_tensor_165 = to_dtype_200 = None
        clone_default_28 = torch.ops.aten.clone.default(slice_tensor_31, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(clone_default_28, convolution_default_365, primals_271, primals_269, primals_270, getitem_608, getitem_609, True, 0.001, [True, True, True]);  clone_default_28 = convolution_default_365 = primals_271 = primals_269 = primals_270 = getitem_608 = getitem_609 = None
        getitem_1372 = native_batch_norm_backward_default_66[0]
        getitem_1373 = native_batch_norm_backward_default_66[1]
        getitem_1374 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1372, convolution_default_364, primals_275, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1372 = convolution_default_364 = primals_275 = None
        getitem_1375 = convolution_backward_default_122[0]
        getitem_1376 = convolution_backward_default_122[1];  convolution_backward_default_122 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1375, relu__default_81, primals_274, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1375 = primals_274 = None
        getitem_1378 = convolution_backward_default_123[0]
        getitem_1379 = convolution_backward_default_123[1];  convolution_backward_default_123 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_1378, torch.float32);  getitem_1378 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_331 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_331, to_dtype_201);  le_scalar_67 = new_zeros_default_331 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_363, primals_266, primals_264, primals_265, getitem_605, getitem_606, True, 0.001, [True, True, True]);  to_dtype_203 = convolution_default_363 = primals_266 = primals_264 = primals_265 = getitem_605 = getitem_606 = None
        getitem_1381 = native_batch_norm_backward_default_67[0]
        getitem_1382 = native_batch_norm_backward_default_67[1]
        getitem_1383 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1381, convolution_default_362, primals_273, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1381 = convolution_default_362 = primals_273 = None
        getitem_1384 = convolution_backward_default_124[0]
        getitem_1385 = convolution_backward_default_124[1];  convolution_backward_default_124 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1384, relu_default_114, primals_272, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1384 = primals_272 = None
        getitem_1387 = convolution_backward_default_125[0]
        getitem_1388 = convolution_backward_default_125[1];  convolution_backward_default_125 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_1387, torch.float32);  getitem_1387 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu_default_114, torch.float32);  relu_default_114 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_332 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_332, to_dtype_204);  le_scalar_68 = new_zeros_default_332 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(add_tensor_166, to_dtype_206);  add_tensor_166 = to_dtype_206 = None
        clone_default_29 = torch.ops.aten.clone.default(slice_tensor_31, memory_format = torch.contiguous_format);  slice_tensor_31 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(clone_default_29, convolution_default_361, primals_257, primals_255, primals_256, getitem_602, getitem_603, True, 0.001, [True, True, True]);  clone_default_29 = convolution_default_361 = primals_257 = primals_255 = primals_256 = getitem_602 = getitem_603 = None
        getitem_1390 = native_batch_norm_backward_default_68[0]
        getitem_1391 = native_batch_norm_backward_default_68[1]
        getitem_1392 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1390, convolution_default_360, primals_261, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1390 = convolution_default_360 = primals_261 = None
        getitem_1393 = convolution_backward_default_126[0]
        getitem_1394 = convolution_backward_default_126[1];  convolution_backward_default_126 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1393, relu__default_80, primals_260, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1393 = primals_260 = None
        getitem_1396 = convolution_backward_default_127[0]
        getitem_1397 = convolution_backward_default_127[1];  convolution_backward_default_127 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_1396, torch.float32);  getitem_1396 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_333 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_333, to_dtype_207);  le_scalar_69 = new_zeros_default_333 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_359, primals_252, primals_250, primals_251, getitem_599, getitem_600, True, 0.001, [True, True, True]);  to_dtype_209 = convolution_default_359 = primals_252 = primals_250 = primals_251 = getitem_599 = getitem_600 = None
        getitem_1399 = native_batch_norm_backward_default_69[0]
        getitem_1400 = native_batch_norm_backward_default_69[1]
        getitem_1401 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1399, convolution_default_358, primals_259, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1399 = convolution_default_358 = primals_259 = None
        getitem_1402 = convolution_backward_default_128[0]
        getitem_1403 = convolution_backward_default_128[1];  convolution_backward_default_128 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1402, relu_default_113, primals_258, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1402 = primals_258 = None
        getitem_1405 = convolution_backward_default_129[0]
        getitem_1406 = convolution_backward_default_129[1];  convolution_backward_default_129 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_1405, torch.float32);  getitem_1405 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu_default_113, torch.float32);  relu_default_113 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_334 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_334, to_dtype_210);  le_scalar_70 = new_zeros_default_334 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(add_tensor_164, to_dtype_212);  add_tensor_164 = to_dtype_212 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_168, convolution_default_357, primals_322, primals_320, primals_321, getitem_596, getitem_597, True, 0.001, [True, True, True]);  add_tensor_168 = convolution_default_357 = primals_322 = primals_320 = primals_321 = getitem_596 = getitem_597 = None
        getitem_1408 = native_batch_norm_backward_default_70[0]
        getitem_1409 = native_batch_norm_backward_default_70[1]
        getitem_1410 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1408, relu_default_112, primals_323, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1408 = primals_323 = None
        getitem_1411 = convolution_backward_default_130[0]
        getitem_1412 = convolution_backward_default_130[1];  convolution_backward_default_130 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_1411, torch.float32);  getitem_1411 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu_default_112, torch.float32);  relu_default_112 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_335 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_335, to_dtype_213);  le_scalar_71 = new_zeros_default_335 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(to_dtype_182, to_dtype_215);  to_dtype_182 = to_dtype_215 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_167, cat_default_19, primals_328, primals_326, primals_327, getitem_593, getitem_594, True, 0.001, [True, True, True]);  add_tensor_167 = cat_default_19 = primals_328 = primals_326 = primals_327 = getitem_593 = getitem_594 = None
        getitem_1414 = native_batch_norm_backward_default_71[0]
        getitem_1415 = native_batch_norm_backward_default_71[1]
        getitem_1416 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        slice_tensor_36 = torch.ops.aten.slice.Tensor(getitem_1414, 1, 0, 336)
        slice_tensor_37 = torch.ops.aten.slice.Tensor(getitem_1414, 1, 336, 672);  getitem_1414 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(slice_tensor_37, avg_pool2d_default_51, primals_330, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_37 = avg_pool2d_default_51 = primals_330 = None
        getitem_1417 = convolution_backward_default_131[0]
        getitem_1418 = convolution_backward_default_131[1];  convolution_backward_default_131 = None
        avg_pool2d_backward_default_18 = torch.ops.aten.avg_pool2d_backward.default(getitem_1417, constant_pad_nd_default_31, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_1417 = constant_pad_nd_default_31 = None
        constant_pad_nd_default_32 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_18, [1, -1, 1, -1]);  avg_pool2d_backward_default_18 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(slice_tensor_36, avg_pool2d_default_50, primals_329, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_36 = avg_pool2d_default_50 = primals_329 = None
        getitem_1420 = convolution_backward_default_132[0]
        getitem_1421 = convolution_backward_default_132[1];  convolution_backward_default_132 = None
        avg_pool2d_backward_default_19 = torch.ops.aten.avg_pool2d_backward.default(getitem_1420, relu_default_111, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_1420 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(constant_pad_nd_default_32, avg_pool2d_backward_default_19);  constant_pad_nd_default_32 = avg_pool2d_backward_default_19 = None
        to_dtype_216 = torch.ops.aten.to.dtype(add_tensor_170, torch.float32);  add_tensor_170 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu_default_111, torch.float32);  relu_default_111 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_336 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_336, to_dtype_216);  le_scalar_72 = new_zeros_default_336 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        slice_tensor_38 = torch.ops.aten.slice.Tensor(add_tensor_169, 1, 0, 672)
        slice_tensor_39 = torch.ops.aten.slice.Tensor(add_tensor_169, 1, 672, 1344)
        slice_tensor_40 = torch.ops.aten.slice.Tensor(add_tensor_169, 1, 1344, 2016)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(add_tensor_169, 1, 2016, 2688);  add_tensor_169 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_41, constant_pad_nd_default_30, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_591);  constant_pad_nd_default_30 = getitem_591 = None
        constant_pad_nd_default_33 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default = None
        clone_default_30 = torch.ops.aten.clone.default(slice_tensor_41, memory_format = torch.contiguous_format);  slice_tensor_41 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(clone_default_30, convolution_default_354, primals_1789, primals_1787, primals_1788, getitem_588, getitem_589, True, 0.001, [True, True, True]);  clone_default_30 = convolution_default_354 = primals_1789 = primals_1787 = primals_1788 = getitem_588 = getitem_589 = None
        getitem_1423 = native_batch_norm_backward_default_72[0]
        getitem_1424 = native_batch_norm_backward_default_72[1]
        getitem_1425 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1423, convolution_default_353, primals_1793, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1423 = convolution_default_353 = primals_1793 = None
        getitem_1426 = convolution_backward_default_133[0]
        getitem_1427 = convolution_backward_default_133[1];  convolution_backward_default_133 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1426, relu__default_79, primals_1792, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1426 = primals_1792 = None
        getitem_1429 = convolution_backward_default_134[0]
        getitem_1430 = convolution_backward_default_134[1];  convolution_backward_default_134 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_1429, torch.float32);  getitem_1429 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_337 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_337, to_dtype_219);  le_scalar_73 = new_zeros_default_337 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_352, primals_1784, primals_1782, primals_1783, getitem_585, getitem_586, True, 0.001, [True, True, True]);  to_dtype_221 = convolution_default_352 = primals_1784 = primals_1782 = primals_1783 = getitem_585 = getitem_586 = None
        getitem_1432 = native_batch_norm_backward_default_73[0]
        getitem_1433 = native_batch_norm_backward_default_73[1]
        getitem_1434 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1432, convolution_default_351, primals_1791, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1432 = convolution_default_351 = primals_1791 = None
        getitem_1435 = convolution_backward_default_135[0]
        getitem_1436 = convolution_backward_default_135[1];  convolution_backward_default_135 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1435, relu_default_110, primals_1790, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1435 = primals_1790 = None
        getitem_1438 = convolution_backward_default_136[0]
        getitem_1439 = convolution_backward_default_136[1];  convolution_backward_default_136 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_1438, torch.float32);  getitem_1438 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu_default_110, torch.float32);  relu_default_110 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_338 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_338, to_dtype_222);  le_scalar_74 = new_zeros_default_338 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(slice_tensor_38, slice_tensor_40);  slice_tensor_38 = None
        avg_pool2d_backward_default_20 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_40, add_tensor_76, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_40 = add_tensor_76 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(to_dtype_224, avg_pool2d_backward_default_20);  to_dtype_224 = avg_pool2d_backward_default_20 = None
        clone_default_31 = torch.ops.aten.clone.default(slice_tensor_39, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(clone_default_31, convolution_default_350, primals_1775, primals_1773, primals_1774, getitem_582, getitem_583, True, 0.001, [True, True, True]);  clone_default_31 = convolution_default_350 = primals_1775 = primals_1773 = primals_1774 = getitem_582 = getitem_583 = None
        getitem_1441 = native_batch_norm_backward_default_74[0]
        getitem_1442 = native_batch_norm_backward_default_74[1]
        getitem_1443 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1441, convolution_default_349, primals_1779, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1441 = convolution_default_349 = primals_1779 = None
        getitem_1444 = convolution_backward_default_137[0]
        getitem_1445 = convolution_backward_default_137[1];  convolution_backward_default_137 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1444, relu__default_78, primals_1778, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1444 = primals_1778 = None
        getitem_1447 = convolution_backward_default_138[0]
        getitem_1448 = convolution_backward_default_138[1];  convolution_backward_default_138 = None
        to_dtype_225 = torch.ops.aten.to.dtype(getitem_1447, torch.float32);  getitem_1447 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_339 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_339, to_dtype_225);  le_scalar_75 = new_zeros_default_339 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_348, primals_1770, primals_1768, primals_1769, getitem_579, getitem_580, True, 0.001, [True, True, True]);  to_dtype_227 = convolution_default_348 = primals_1770 = primals_1768 = primals_1769 = getitem_579 = getitem_580 = None
        getitem_1450 = native_batch_norm_backward_default_75[0]
        getitem_1451 = native_batch_norm_backward_default_75[1]
        getitem_1452 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1450, convolution_default_347, primals_1777, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1450 = convolution_default_347 = primals_1777 = None
        getitem_1453 = convolution_backward_default_139[0]
        getitem_1454 = convolution_backward_default_139[1];  convolution_backward_default_139 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1453, constant_pad_nd_default_29, primals_1776, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1453 = constant_pad_nd_default_29 = primals_1776 = None
        getitem_1456 = convolution_backward_default_140[0]
        getitem_1457 = convolution_backward_default_140[1];  convolution_backward_default_140 = None
        constant_pad_nd_default_34 = torch.ops.aten.constant_pad_nd.default(getitem_1456, [-2, -2, -2, -2]);  getitem_1456 = None
        to_dtype_228 = torch.ops.aten.to.dtype(constant_pad_nd_default_34, torch.float32);  constant_pad_nd_default_34 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu_default_109, torch.float32);  relu_default_109 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_340 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_340, to_dtype_228);  le_scalar_76 = new_zeros_default_340 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        avg_pool2d_backward_default_21 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_39, constant_pad_nd_default_28, [3, 3], [2, 2], [0, 0], False, False, None);  slice_tensor_39 = constant_pad_nd_default_28 = None
        constant_pad_nd_default_35 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_21, [-1, -1, -1, -1]);  avg_pool2d_backward_default_21 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(constant_pad_nd_default_33, constant_pad_nd_default_35);  constant_pad_nd_default_33 = constant_pad_nd_default_35 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_171, convolution_default_346, primals_1761, primals_1759, primals_1760, getitem_576, getitem_577, True, 0.001, [True, True, True]);  convolution_default_346 = primals_1761 = primals_1759 = primals_1760 = getitem_576 = getitem_577 = None
        getitem_1459 = native_batch_norm_backward_default_76[0]
        getitem_1460 = native_batch_norm_backward_default_76[1]
        getitem_1461 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_1459, convolution_default_345, primals_1765, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1459 = convolution_default_345 = primals_1765 = None
        getitem_1462 = convolution_backward_default_141[0]
        getitem_1463 = convolution_backward_default_141[1];  convolution_backward_default_141 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_1462, relu__default_77, primals_1764, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1462 = primals_1764 = None
        getitem_1465 = convolution_backward_default_142[0]
        getitem_1466 = convolution_backward_default_142[1];  convolution_backward_default_142 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_1465, torch.float32);  getitem_1465 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_341 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_341, to_dtype_231);  le_scalar_77 = new_zeros_default_341 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_344, primals_1756, primals_1754, primals_1755, getitem_573, getitem_574, True, 0.001, [True, True, True]);  to_dtype_233 = convolution_default_344 = primals_1756 = primals_1754 = primals_1755 = getitem_573 = getitem_574 = None
        getitem_1468 = native_batch_norm_backward_default_77[0]
        getitem_1469 = native_batch_norm_backward_default_77[1]
        getitem_1470 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(getitem_1468, convolution_default_343, primals_1763, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1468 = convolution_default_343 = primals_1763 = None
        getitem_1471 = convolution_backward_default_143[0]
        getitem_1472 = convolution_backward_default_143[1];  convolution_backward_default_143 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1471, constant_pad_nd_default_27, primals_1762, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1471 = constant_pad_nd_default_27 = primals_1762 = None
        getitem_1474 = convolution_backward_default_144[0]
        getitem_1475 = convolution_backward_default_144[1];  convolution_backward_default_144 = None
        constant_pad_nd_default_36 = torch.ops.aten.constant_pad_nd.default(getitem_1474, [-3, -3, -3, -3]);  getitem_1474 = None
        to_dtype_234 = torch.ops.aten.to.dtype(constant_pad_nd_default_36, torch.float32);  constant_pad_nd_default_36 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu_default_108, torch.float32);  relu_default_108 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_342 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_342, to_dtype_234);  le_scalar_78 = new_zeros_default_342 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(to_dtype_230, to_dtype_236);  to_dtype_230 = to_dtype_236 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_171, constant_pad_nd_default_26, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_571);  add_tensor_171 = constant_pad_nd_default_26 = getitem_571 = None
        constant_pad_nd_default_37 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_1, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_1 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(add_tensor_173, constant_pad_nd_default_37);  add_tensor_173 = constant_pad_nd_default_37 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_172, convolution_default_342, primals_1747, primals_1745, primals_1746, getitem_568, getitem_569, True, 0.001, [True, True, True]);  convolution_default_342 = primals_1747 = primals_1745 = primals_1746 = getitem_568 = getitem_569 = None
        getitem_1477 = native_batch_norm_backward_default_78[0]
        getitem_1478 = native_batch_norm_backward_default_78[1]
        getitem_1479 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1477, convolution_default_341, primals_1751, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1477 = convolution_default_341 = primals_1751 = None
        getitem_1480 = convolution_backward_default_145[0]
        getitem_1481 = convolution_backward_default_145[1];  convolution_backward_default_145 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1480, relu__default_76, primals_1750, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1480 = primals_1750 = None
        getitem_1483 = convolution_backward_default_146[0]
        getitem_1484 = convolution_backward_default_146[1];  convolution_backward_default_146 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_1483, torch.float32);  getitem_1483 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_343 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_343, to_dtype_237);  le_scalar_79 = new_zeros_default_343 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_340, primals_1742, primals_1740, primals_1741, getitem_565, getitem_566, True, 0.001, [True, True, True]);  to_dtype_239 = convolution_default_340 = primals_1742 = primals_1740 = primals_1741 = getitem_565 = getitem_566 = None
        getitem_1486 = native_batch_norm_backward_default_79[0]
        getitem_1487 = native_batch_norm_backward_default_79[1]
        getitem_1488 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(getitem_1486, convolution_default_339, primals_1749, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1486 = convolution_default_339 = primals_1749 = None
        getitem_1489 = convolution_backward_default_147[0]
        getitem_1490 = convolution_backward_default_147[1];  convolution_backward_default_147 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1489, constant_pad_nd_default_25, primals_1748, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1489 = constant_pad_nd_default_25 = primals_1748 = None
        getitem_1492 = convolution_backward_default_148[0]
        getitem_1493 = convolution_backward_default_148[1];  convolution_backward_default_148 = None
        constant_pad_nd_default_38 = torch.ops.aten.constant_pad_nd.default(getitem_1492, [-3, -3, -3, -3]);  getitem_1492 = None
        to_dtype_240 = torch.ops.aten.to.dtype(constant_pad_nd_default_38, torch.float32);  constant_pad_nd_default_38 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu_default_107, torch.float32);  relu_default_107 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_344 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_344, to_dtype_240);  le_scalar_80 = new_zeros_default_344 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(add_tensor_174, to_dtype_242);  add_tensor_174 = to_dtype_242 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_172, convolution_default_338, primals_1733, primals_1731, primals_1732, getitem_562, getitem_563, True, 0.001, [True, True, True]);  add_tensor_172 = convolution_default_338 = primals_1733 = primals_1731 = primals_1732 = getitem_562 = getitem_563 = None
        getitem_1495 = native_batch_norm_backward_default_80[0]
        getitem_1496 = native_batch_norm_backward_default_80[1]
        getitem_1497 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(getitem_1495, convolution_default_337, primals_1737, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1495 = convolution_default_337 = primals_1737 = None
        getitem_1498 = convolution_backward_default_149[0]
        getitem_1499 = convolution_backward_default_149[1];  convolution_backward_default_149 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1498, relu__default_75, primals_1736, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1498 = primals_1736 = None
        getitem_1501 = convolution_backward_default_150[0]
        getitem_1502 = convolution_backward_default_150[1];  convolution_backward_default_150 = None
        to_dtype_243 = torch.ops.aten.to.dtype(getitem_1501, torch.float32);  getitem_1501 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_345 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_345, to_dtype_243);  le_scalar_81 = new_zeros_default_345 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_245, convolution_default_336, primals_1728, primals_1726, primals_1727, getitem_559, getitem_560, True, 0.001, [True, True, True]);  to_dtype_245 = convolution_default_336 = primals_1728 = primals_1726 = primals_1727 = getitem_559 = getitem_560 = None
        getitem_1504 = native_batch_norm_backward_default_81[0]
        getitem_1505 = native_batch_norm_backward_default_81[1]
        getitem_1506 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(getitem_1504, convolution_default_335, primals_1735, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1504 = convolution_default_335 = primals_1735 = None
        getitem_1507 = convolution_backward_default_151[0]
        getitem_1508 = convolution_backward_default_151[1];  convolution_backward_default_151 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(getitem_1507, constant_pad_nd_default_24, primals_1734, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_1507 = constant_pad_nd_default_24 = primals_1734 = None
        getitem_1510 = convolution_backward_default_152[0]
        getitem_1511 = convolution_backward_default_152[1];  convolution_backward_default_152 = None
        constant_pad_nd_default_39 = torch.ops.aten.constant_pad_nd.default(getitem_1510, [-2, -2, -2, -2]);  getitem_1510 = None
        to_dtype_246 = torch.ops.aten.to.dtype(constant_pad_nd_default_39, torch.float32);  constant_pad_nd_default_39 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu_default_106, torch.float32);  relu_default_106 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_346 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_346, to_dtype_246);  le_scalar_82 = new_zeros_default_346 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(add_tensor_175, to_dtype_248);  add_tensor_175 = to_dtype_248 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_177, convolution_default_334, primals_1798, primals_1796, primals_1797, getitem_556, getitem_557, True, 0.001, [True, True, True]);  add_tensor_177 = convolution_default_334 = primals_1798 = primals_1796 = primals_1797 = getitem_556 = getitem_557 = None
        getitem_1513 = native_batch_norm_backward_default_82[0]
        getitem_1514 = native_batch_norm_backward_default_82[1]
        getitem_1515 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_1513, relu_default_105, primals_1799, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1513 = primals_1799 = None
        getitem_1516 = convolution_backward_default_153[0]
        getitem_1517 = convolution_backward_default_153[1];  convolution_backward_default_153 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_1516, torch.float32);  getitem_1516 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu_default_105, torch.float32);  relu_default_105 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_347 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_347, to_dtype_249);  le_scalar_83 = new_zeros_default_347 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_176, convolution_default_333, primals_1804, primals_1802, primals_1803, getitem_553, getitem_554, True, 0.001, [True, True, True]);  add_tensor_176 = convolution_default_333 = primals_1804 = primals_1802 = primals_1803 = getitem_553 = getitem_554 = None
        getitem_1519 = native_batch_norm_backward_default_83[0]
        getitem_1520 = native_batch_norm_backward_default_83[1]
        getitem_1521 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(getitem_1519, relu_default_104, primals_1805, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1519 = primals_1805 = None
        getitem_1522 = convolution_backward_default_154[0]
        getitem_1523 = convolution_backward_default_154[1];  convolution_backward_default_154 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_1522, torch.float32);  getitem_1522 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu_default_104, torch.float32);  relu_default_104 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_348 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_348, to_dtype_252);  le_scalar_84 = new_zeros_default_348 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(to_dtype_218, to_dtype_254);  to_dtype_218 = to_dtype_254 = None
        slice_tensor_42 = torch.ops.aten.slice.Tensor(to_dtype_251, 1, 0, 336)
        slice_tensor_43 = torch.ops.aten.slice.Tensor(to_dtype_251, 1, 336, 672)
        slice_tensor_44 = torch.ops.aten.slice.Tensor(to_dtype_251, 1, 672, 1008)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(to_dtype_251, 1, 1008, 1344)
        slice_tensor_46 = torch.ops.aten.slice.Tensor(to_dtype_251, 1, 1344, 1680)
        slice_tensor_47 = torch.ops.aten.slice.Tensor(to_dtype_251, 1, 1680, 2016);  to_dtype_251 = None
        clone_default_32 = torch.ops.aten.clone.default(slice_tensor_47, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(clone_default_32, convolution_default_332, primals_231, primals_229, primals_230, getitem_550, getitem_551, True, 0.001, [True, True, True]);  clone_default_32 = convolution_default_332 = primals_231 = primals_229 = primals_230 = getitem_550 = getitem_551 = None
        getitem_1525 = native_batch_norm_backward_default_84[0]
        getitem_1526 = native_batch_norm_backward_default_84[1]
        getitem_1527 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1525, convolution_default_331, primals_235, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1525 = convolution_default_331 = primals_235 = None
        getitem_1528 = convolution_backward_default_155[0]
        getitem_1529 = convolution_backward_default_155[1];  convolution_backward_default_155 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(getitem_1528, relu__default_74, primals_234, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1528 = primals_234 = None
        getitem_1531 = convolution_backward_default_156[0]
        getitem_1532 = convolution_backward_default_156[1];  convolution_backward_default_156 = None
        to_dtype_255 = torch.ops.aten.to.dtype(getitem_1531, torch.float32);  getitem_1531 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_349 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_349, to_dtype_255);  le_scalar_85 = new_zeros_default_349 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_257, convolution_default_330, primals_226, primals_224, primals_225, getitem_547, getitem_548, True, 0.001, [True, True, True]);  to_dtype_257 = convolution_default_330 = primals_226 = primals_224 = primals_225 = getitem_547 = getitem_548 = None
        getitem_1534 = native_batch_norm_backward_default_85[0]
        getitem_1535 = native_batch_norm_backward_default_85[1]
        getitem_1536 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(getitem_1534, convolution_default_329, primals_233, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1534 = convolution_default_329 = primals_233 = None
        getitem_1537 = convolution_backward_default_157[0]
        getitem_1538 = convolution_backward_default_157[1];  convolution_backward_default_157 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(getitem_1537, relu_default_103, primals_232, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1537 = primals_232 = None
        getitem_1540 = convolution_backward_default_158[0]
        getitem_1541 = convolution_backward_default_158[1];  convolution_backward_default_158 = None
        to_dtype_258 = torch.ops.aten.to.dtype(getitem_1540, torch.float32);  getitem_1540 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu_default_103, torch.float32);  relu_default_103 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_350 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_350, to_dtype_258);  le_scalar_86 = new_zeros_default_350 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(slice_tensor_47, to_dtype_260);  slice_tensor_47 = to_dtype_260 = None
        avg_pool2d_backward_default_22 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_46, getitem_516, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_180 = torch.ops.aten.add.Tensor(slice_tensor_42, avg_pool2d_backward_default_22);  slice_tensor_42 = avg_pool2d_backward_default_22 = None
        avg_pool2d_backward_default_23 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_46, getitem_516, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_46 = getitem_516 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(add_tensor_180, avg_pool2d_backward_default_23);  add_tensor_180 = avg_pool2d_backward_default_23 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(add_tensor_181, slice_tensor_45);  add_tensor_181 = None
        avg_pool2d_backward_default_24 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_45, getitem_519, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_45 = getitem_519 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(add_tensor_179, avg_pool2d_backward_default_24);  add_tensor_179 = avg_pool2d_backward_default_24 = None
        clone_default_33 = torch.ops.aten.clone.default(slice_tensor_44, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(clone_default_33, convolution_default_328, primals_217, primals_215, primals_216, getitem_544, getitem_545, True, 0.001, [True, True, True]);  clone_default_33 = convolution_default_328 = primals_217 = primals_215 = primals_216 = getitem_544 = getitem_545 = None
        getitem_1543 = native_batch_norm_backward_default_86[0]
        getitem_1544 = native_batch_norm_backward_default_86[1]
        getitem_1545 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(getitem_1543, convolution_default_327, primals_221, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1543 = convolution_default_327 = primals_221 = None
        getitem_1546 = convolution_backward_default_159[0]
        getitem_1547 = convolution_backward_default_159[1];  convolution_backward_default_159 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1546, relu__default_73, primals_220, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1546 = primals_220 = None
        getitem_1549 = convolution_backward_default_160[0]
        getitem_1550 = convolution_backward_default_160[1];  convolution_backward_default_160 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_1549, torch.float32);  getitem_1549 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_351 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_351, to_dtype_261);  le_scalar_87 = new_zeros_default_351 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_326, primals_212, primals_210, primals_211, getitem_541, getitem_542, True, 0.001, [True, True, True]);  to_dtype_263 = convolution_default_326 = primals_212 = primals_210 = primals_211 = getitem_541 = getitem_542 = None
        getitem_1552 = native_batch_norm_backward_default_87[0]
        getitem_1553 = native_batch_norm_backward_default_87[1]
        getitem_1554 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(getitem_1552, convolution_default_325, primals_219, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1552 = convolution_default_325 = primals_219 = None
        getitem_1555 = convolution_backward_default_161[0]
        getitem_1556 = convolution_backward_default_161[1];  convolution_backward_default_161 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(getitem_1555, relu_default_102, primals_218, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1555 = primals_218 = None
        getitem_1558 = convolution_backward_default_162[0]
        getitem_1559 = convolution_backward_default_162[1];  convolution_backward_default_162 = None
        to_dtype_264 = torch.ops.aten.to.dtype(getitem_1558, torch.float32);  getitem_1558 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu_default_102, torch.float32);  relu_default_102 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_352 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_352, to_dtype_264);  le_scalar_88 = new_zeros_default_352 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(add_tensor_182, to_dtype_266);  add_tensor_182 = to_dtype_266 = None
        clone_default_34 = torch.ops.aten.clone.default(slice_tensor_44, memory_format = torch.contiguous_format);  slice_tensor_44 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(clone_default_34, convolution_default_324, primals_203, primals_201, primals_202, getitem_538, getitem_539, True, 0.001, [True, True, True]);  clone_default_34 = convolution_default_324 = primals_203 = primals_201 = primals_202 = getitem_538 = getitem_539 = None
        getitem_1561 = native_batch_norm_backward_default_88[0]
        getitem_1562 = native_batch_norm_backward_default_88[1]
        getitem_1563 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(getitem_1561, convolution_default_323, primals_207, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1561 = convolution_default_323 = primals_207 = None
        getitem_1564 = convolution_backward_default_163[0]
        getitem_1565 = convolution_backward_default_163[1];  convolution_backward_default_163 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(getitem_1564, relu__default_72, primals_206, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1564 = primals_206 = None
        getitem_1567 = convolution_backward_default_164[0]
        getitem_1568 = convolution_backward_default_164[1];  convolution_backward_default_164 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_1567, torch.float32);  getitem_1567 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_353 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_353, to_dtype_267);  le_scalar_89 = new_zeros_default_353 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_322, primals_198, primals_196, primals_197, getitem_535, getitem_536, True, 0.001, [True, True, True]);  to_dtype_269 = convolution_default_322 = primals_198 = primals_196 = primals_197 = getitem_535 = getitem_536 = None
        getitem_1570 = native_batch_norm_backward_default_89[0]
        getitem_1571 = native_batch_norm_backward_default_89[1]
        getitem_1572 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(getitem_1570, convolution_default_321, primals_205, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1570 = convolution_default_321 = primals_205 = None
        getitem_1573 = convolution_backward_default_165[0]
        getitem_1574 = convolution_backward_default_165[1];  convolution_backward_default_165 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(getitem_1573, relu_default_101, primals_204, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1573 = primals_204 = None
        getitem_1576 = convolution_backward_default_166[0]
        getitem_1577 = convolution_backward_default_166[1];  convolution_backward_default_166 = None
        to_dtype_270 = torch.ops.aten.to.dtype(getitem_1576, torch.float32);  getitem_1576 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu_default_101, torch.float32);  relu_default_101 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_354 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_354, to_dtype_270);  le_scalar_90 = new_zeros_default_354 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(add_tensor_184, to_dtype_272);  add_tensor_184 = to_dtype_272 = None
        clone_default_35 = torch.ops.aten.clone.default(slice_tensor_43, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(clone_default_35, convolution_default_320, primals_189, primals_187, primals_188, getitem_532, getitem_533, True, 0.001, [True, True, True]);  clone_default_35 = convolution_default_320 = primals_189 = primals_187 = primals_188 = getitem_532 = getitem_533 = None
        getitem_1579 = native_batch_norm_backward_default_90[0]
        getitem_1580 = native_batch_norm_backward_default_90[1]
        getitem_1581 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(getitem_1579, convolution_default_319, primals_193, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1579 = convolution_default_319 = primals_193 = None
        getitem_1582 = convolution_backward_default_167[0]
        getitem_1583 = convolution_backward_default_167[1];  convolution_backward_default_167 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1582, relu__default_71, primals_192, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1582 = primals_192 = None
        getitem_1585 = convolution_backward_default_168[0]
        getitem_1586 = convolution_backward_default_168[1];  convolution_backward_default_168 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_1585, torch.float32);  getitem_1585 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_355 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_355, to_dtype_273);  le_scalar_91 = new_zeros_default_355 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_318, primals_184, primals_182, primals_183, getitem_529, getitem_530, True, 0.001, [True, True, True]);  to_dtype_275 = convolution_default_318 = primals_184 = primals_182 = primals_183 = getitem_529 = getitem_530 = None
        getitem_1588 = native_batch_norm_backward_default_91[0]
        getitem_1589 = native_batch_norm_backward_default_91[1]
        getitem_1590 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1588, convolution_default_317, primals_191, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1588 = convolution_default_317 = primals_191 = None
        getitem_1591 = convolution_backward_default_169[0]
        getitem_1592 = convolution_backward_default_169[1];  convolution_backward_default_169 = None
        convolution_backward_default_170 = torch.ops.aten.convolution_backward.default(getitem_1591, relu_default_100, primals_190, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1591 = primals_190 = None
        getitem_1594 = convolution_backward_default_170[0]
        getitem_1595 = convolution_backward_default_170[1];  convolution_backward_default_170 = None
        to_dtype_276 = torch.ops.aten.to.dtype(getitem_1594, torch.float32);  getitem_1594 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu_default_100, torch.float32);  relu_default_100 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_356 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_356, to_dtype_276);  le_scalar_92 = new_zeros_default_356 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(add_tensor_185, to_dtype_278);  add_tensor_185 = to_dtype_278 = None
        clone_default_36 = torch.ops.aten.clone.default(slice_tensor_43, memory_format = torch.contiguous_format);  slice_tensor_43 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(clone_default_36, convolution_default_316, primals_175, primals_173, primals_174, getitem_526, getitem_527, True, 0.001, [True, True, True]);  clone_default_36 = convolution_default_316 = primals_175 = primals_173 = primals_174 = getitem_526 = getitem_527 = None
        getitem_1597 = native_batch_norm_backward_default_92[0]
        getitem_1598 = native_batch_norm_backward_default_92[1]
        getitem_1599 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_171 = torch.ops.aten.convolution_backward.default(getitem_1597, convolution_default_315, primals_179, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1597 = convolution_default_315 = primals_179 = None
        getitem_1600 = convolution_backward_default_171[0]
        getitem_1601 = convolution_backward_default_171[1];  convolution_backward_default_171 = None
        convolution_backward_default_172 = torch.ops.aten.convolution_backward.default(getitem_1600, relu__default_70, primals_178, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1600 = primals_178 = None
        getitem_1603 = convolution_backward_default_172[0]
        getitem_1604 = convolution_backward_default_172[1];  convolution_backward_default_172 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_1603, torch.float32);  getitem_1603 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_357 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_357, to_dtype_279);  le_scalar_93 = new_zeros_default_357 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_314, primals_170, primals_168, primals_169, getitem_523, getitem_524, True, 0.001, [True, True, True]);  to_dtype_281 = convolution_default_314 = primals_170 = primals_168 = primals_169 = getitem_523 = getitem_524 = None
        getitem_1606 = native_batch_norm_backward_default_93[0]
        getitem_1607 = native_batch_norm_backward_default_93[1]
        getitem_1608 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_173 = torch.ops.aten.convolution_backward.default(getitem_1606, convolution_default_313, primals_177, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1606 = convolution_default_313 = primals_177 = None
        getitem_1609 = convolution_backward_default_173[0]
        getitem_1610 = convolution_backward_default_173[1];  convolution_backward_default_173 = None
        convolution_backward_default_174 = torch.ops.aten.convolution_backward.default(getitem_1609, relu_default_99, primals_176, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1609 = primals_176 = None
        getitem_1612 = convolution_backward_default_174[0]
        getitem_1613 = convolution_backward_default_174[1];  convolution_backward_default_174 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_1612, torch.float32);  getitem_1612 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu_default_99, torch.float32);  relu_default_99 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_358 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_358, to_dtype_282);  le_scalar_94 = new_zeros_default_358 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(add_tensor_183, to_dtype_284);  add_tensor_183 = to_dtype_284 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_187, convolution_default_312, primals_240, primals_238, primals_239, getitem_520, getitem_521, True, 0.001, [True, True, True]);  add_tensor_187 = convolution_default_312 = primals_240 = primals_238 = primals_239 = getitem_520 = getitem_521 = None
        getitem_1615 = native_batch_norm_backward_default_94[0]
        getitem_1616 = native_batch_norm_backward_default_94[1]
        getitem_1617 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_175 = torch.ops.aten.convolution_backward.default(getitem_1615, relu_default_98, primals_241, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1615 = primals_241 = None
        getitem_1618 = convolution_backward_default_175[0]
        getitem_1619 = convolution_backward_default_175[1];  convolution_backward_default_175 = None
        to_dtype_285 = torch.ops.aten.to.dtype(getitem_1618, torch.float32);  getitem_1618 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu_default_98, torch.float32);  relu_default_98 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_359 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_359, to_dtype_285);  le_scalar_95 = new_zeros_default_359 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(add_tensor_178, to_dtype_287);  add_tensor_178 = to_dtype_287 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_186, convolution_default_311, primals_246, primals_244, primals_245, getitem_517, getitem_518, True, 0.001, [True, True, True]);  add_tensor_186 = convolution_default_311 = primals_246 = primals_244 = primals_245 = getitem_517 = getitem_518 = None
        getitem_1621 = native_batch_norm_backward_default_95[0]
        getitem_1622 = native_batch_norm_backward_default_95[1]
        getitem_1623 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_176 = torch.ops.aten.convolution_backward.default(getitem_1621, relu_default_97, primals_247, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1621 = primals_247 = None
        getitem_1624 = convolution_backward_default_176[0]
        getitem_1625 = convolution_backward_default_176[1];  convolution_backward_default_176 = None
        to_dtype_288 = torch.ops.aten.to.dtype(getitem_1624, torch.float32);  getitem_1624 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu_default_97, torch.float32);  relu_default_97 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_360 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_360, to_dtype_288);  le_scalar_96 = new_zeros_default_360 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        slice_tensor_48 = torch.ops.aten.slice.Tensor(add_tensor_188, 1, 0, 336)
        slice_tensor_49 = torch.ops.aten.slice.Tensor(add_tensor_188, 1, 336, 672)
        slice_tensor_50 = torch.ops.aten.slice.Tensor(add_tensor_188, 1, 672, 1008)
        slice_tensor_51 = torch.ops.aten.slice.Tensor(add_tensor_188, 1, 1008, 1344)
        slice_tensor_52 = torch.ops.aten.slice.Tensor(add_tensor_188, 1, 1344, 1680)
        slice_tensor_53 = torch.ops.aten.slice.Tensor(add_tensor_188, 1, 1680, 2016);  add_tensor_188 = None
        clone_default_37 = torch.ops.aten.clone.default(slice_tensor_53, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(clone_default_37, convolution_default_310, primals_149, primals_147, primals_148, getitem_514, getitem_515, True, 0.001, [True, True, True]);  clone_default_37 = convolution_default_310 = primals_149 = primals_147 = primals_148 = getitem_514 = getitem_515 = None
        getitem_1627 = native_batch_norm_backward_default_96[0]
        getitem_1628 = native_batch_norm_backward_default_96[1]
        getitem_1629 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_177 = torch.ops.aten.convolution_backward.default(getitem_1627, convolution_default_309, primals_153, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1627 = convolution_default_309 = primals_153 = None
        getitem_1630 = convolution_backward_default_177[0]
        getitem_1631 = convolution_backward_default_177[1];  convolution_backward_default_177 = None
        convolution_backward_default_178 = torch.ops.aten.convolution_backward.default(getitem_1630, relu__default_69, primals_152, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1630 = primals_152 = None
        getitem_1633 = convolution_backward_default_178[0]
        getitem_1634 = convolution_backward_default_178[1];  convolution_backward_default_178 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_1633, torch.float32);  getitem_1633 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_361 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_361, to_dtype_291);  le_scalar_97 = new_zeros_default_361 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_293, convolution_default_308, primals_144, primals_142, primals_143, getitem_511, getitem_512, True, 0.001, [True, True, True]);  to_dtype_293 = convolution_default_308 = primals_144 = primals_142 = primals_143 = getitem_511 = getitem_512 = None
        getitem_1636 = native_batch_norm_backward_default_97[0]
        getitem_1637 = native_batch_norm_backward_default_97[1]
        getitem_1638 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_179 = torch.ops.aten.convolution_backward.default(getitem_1636, convolution_default_307, primals_151, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1636 = convolution_default_307 = primals_151 = None
        getitem_1639 = convolution_backward_default_179[0]
        getitem_1640 = convolution_backward_default_179[1];  convolution_backward_default_179 = None
        convolution_backward_default_180 = torch.ops.aten.convolution_backward.default(getitem_1639, relu_default_96, primals_150, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1639 = primals_150 = None
        getitem_1642 = convolution_backward_default_180[0]
        getitem_1643 = convolution_backward_default_180[1];  convolution_backward_default_180 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_1642, torch.float32);  getitem_1642 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu_default_96, torch.float32);  relu_default_96 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_362 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_362, to_dtype_294);  le_scalar_98 = new_zeros_default_362 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(slice_tensor_53, to_dtype_296);  slice_tensor_53 = to_dtype_296 = None
        avg_pool2d_backward_default_25 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_52, getitem_480, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_190 = torch.ops.aten.add.Tensor(slice_tensor_48, avg_pool2d_backward_default_25);  slice_tensor_48 = avg_pool2d_backward_default_25 = None
        avg_pool2d_backward_default_26 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_52, getitem_480, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_52 = getitem_480 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(add_tensor_190, avg_pool2d_backward_default_26);  add_tensor_190 = avg_pool2d_backward_default_26 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(add_tensor_191, slice_tensor_51);  add_tensor_191 = None
        avg_pool2d_backward_default_27 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_51, getitem_483, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_51 = getitem_483 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(add_tensor_189, avg_pool2d_backward_default_27);  add_tensor_189 = avg_pool2d_backward_default_27 = None
        clone_default_38 = torch.ops.aten.clone.default(slice_tensor_50, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(clone_default_38, convolution_default_306, primals_135, primals_133, primals_134, getitem_508, getitem_509, True, 0.001, [True, True, True]);  clone_default_38 = convolution_default_306 = primals_135 = primals_133 = primals_134 = getitem_508 = getitem_509 = None
        getitem_1645 = native_batch_norm_backward_default_98[0]
        getitem_1646 = native_batch_norm_backward_default_98[1]
        getitem_1647 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_181 = torch.ops.aten.convolution_backward.default(getitem_1645, convolution_default_305, primals_139, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1645 = convolution_default_305 = primals_139 = None
        getitem_1648 = convolution_backward_default_181[0]
        getitem_1649 = convolution_backward_default_181[1];  convolution_backward_default_181 = None
        convolution_backward_default_182 = torch.ops.aten.convolution_backward.default(getitem_1648, relu__default_68, primals_138, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1648 = primals_138 = None
        getitem_1651 = convolution_backward_default_182[0]
        getitem_1652 = convolution_backward_default_182[1];  convolution_backward_default_182 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_1651, torch.float32);  getitem_1651 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_363 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_363, to_dtype_297);  le_scalar_99 = new_zeros_default_363 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_304, primals_130, primals_128, primals_129, getitem_505, getitem_506, True, 0.001, [True, True, True]);  to_dtype_299 = convolution_default_304 = primals_130 = primals_128 = primals_129 = getitem_505 = getitem_506 = None
        getitem_1654 = native_batch_norm_backward_default_99[0]
        getitem_1655 = native_batch_norm_backward_default_99[1]
        getitem_1656 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_183 = torch.ops.aten.convolution_backward.default(getitem_1654, convolution_default_303, primals_137, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1654 = convolution_default_303 = primals_137 = None
        getitem_1657 = convolution_backward_default_183[0]
        getitem_1658 = convolution_backward_default_183[1];  convolution_backward_default_183 = None
        convolution_backward_default_184 = torch.ops.aten.convolution_backward.default(getitem_1657, relu_default_95, primals_136, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1657 = primals_136 = None
        getitem_1660 = convolution_backward_default_184[0]
        getitem_1661 = convolution_backward_default_184[1];  convolution_backward_default_184 = None
        to_dtype_300 = torch.ops.aten.to.dtype(getitem_1660, torch.float32);  getitem_1660 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu_default_95, torch.float32);  relu_default_95 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_364 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_364, to_dtype_300);  le_scalar_100 = new_zeros_default_364 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(add_tensor_192, to_dtype_302);  add_tensor_192 = to_dtype_302 = None
        clone_default_39 = torch.ops.aten.clone.default(slice_tensor_50, memory_format = torch.contiguous_format);  slice_tensor_50 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(clone_default_39, convolution_default_302, primals_121, primals_119, primals_120, getitem_502, getitem_503, True, 0.001, [True, True, True]);  clone_default_39 = convolution_default_302 = primals_121 = primals_119 = primals_120 = getitem_502 = getitem_503 = None
        getitem_1663 = native_batch_norm_backward_default_100[0]
        getitem_1664 = native_batch_norm_backward_default_100[1]
        getitem_1665 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_185 = torch.ops.aten.convolution_backward.default(getitem_1663, convolution_default_301, primals_125, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1663 = convolution_default_301 = primals_125 = None
        getitem_1666 = convolution_backward_default_185[0]
        getitem_1667 = convolution_backward_default_185[1];  convolution_backward_default_185 = None
        convolution_backward_default_186 = torch.ops.aten.convolution_backward.default(getitem_1666, relu__default_67, primals_124, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1666 = primals_124 = None
        getitem_1669 = convolution_backward_default_186[0]
        getitem_1670 = convolution_backward_default_186[1];  convolution_backward_default_186 = None
        to_dtype_303 = torch.ops.aten.to.dtype(getitem_1669, torch.float32);  getitem_1669 = None
        to_dtype_304 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_304, 0);  to_dtype_304 = None
        new_zeros_default_365 = torch.ops.aten.new_zeros.default(to_dtype_303, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_365, to_dtype_303);  le_scalar_101 = new_zeros_default_365 = to_dtype_303 = None
        to_dtype_305 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_305, convolution_default_300, primals_116, primals_114, primals_115, getitem_499, getitem_500, True, 0.001, [True, True, True]);  to_dtype_305 = convolution_default_300 = primals_116 = primals_114 = primals_115 = getitem_499 = getitem_500 = None
        getitem_1672 = native_batch_norm_backward_default_101[0]
        getitem_1673 = native_batch_norm_backward_default_101[1]
        getitem_1674 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_187 = torch.ops.aten.convolution_backward.default(getitem_1672, convolution_default_299, primals_123, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1672 = convolution_default_299 = primals_123 = None
        getitem_1675 = convolution_backward_default_187[0]
        getitem_1676 = convolution_backward_default_187[1];  convolution_backward_default_187 = None
        convolution_backward_default_188 = torch.ops.aten.convolution_backward.default(getitem_1675, relu_default_94, primals_122, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1675 = primals_122 = None
        getitem_1678 = convolution_backward_default_188[0]
        getitem_1679 = convolution_backward_default_188[1];  convolution_backward_default_188 = None
        to_dtype_306 = torch.ops.aten.to.dtype(getitem_1678, torch.float32);  getitem_1678 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu_default_94, torch.float32);  relu_default_94 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_366 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_366, to_dtype_306);  le_scalar_102 = new_zeros_default_366 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(add_tensor_194, to_dtype_308);  add_tensor_194 = to_dtype_308 = None
        clone_default_40 = torch.ops.aten.clone.default(slice_tensor_49, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(clone_default_40, convolution_default_298, primals_107, primals_105, primals_106, getitem_496, getitem_497, True, 0.001, [True, True, True]);  clone_default_40 = convolution_default_298 = primals_107 = primals_105 = primals_106 = getitem_496 = getitem_497 = None
        getitem_1681 = native_batch_norm_backward_default_102[0]
        getitem_1682 = native_batch_norm_backward_default_102[1]
        getitem_1683 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_189 = torch.ops.aten.convolution_backward.default(getitem_1681, convolution_default_297, primals_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1681 = convolution_default_297 = primals_111 = None
        getitem_1684 = convolution_backward_default_189[0]
        getitem_1685 = convolution_backward_default_189[1];  convolution_backward_default_189 = None
        convolution_backward_default_190 = torch.ops.aten.convolution_backward.default(getitem_1684, relu__default_66, primals_110, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1684 = primals_110 = None
        getitem_1687 = convolution_backward_default_190[0]
        getitem_1688 = convolution_backward_default_190[1];  convolution_backward_default_190 = None
        to_dtype_309 = torch.ops.aten.to.dtype(getitem_1687, torch.float32);  getitem_1687 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_367 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_367, to_dtype_309);  le_scalar_103 = new_zeros_default_367 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_296, primals_102, primals_100, primals_101, getitem_493, getitem_494, True, 0.001, [True, True, True]);  to_dtype_311 = convolution_default_296 = primals_102 = primals_100 = primals_101 = getitem_493 = getitem_494 = None
        getitem_1690 = native_batch_norm_backward_default_103[0]
        getitem_1691 = native_batch_norm_backward_default_103[1]
        getitem_1692 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_191 = torch.ops.aten.convolution_backward.default(getitem_1690, convolution_default_295, primals_109, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1690 = convolution_default_295 = primals_109 = None
        getitem_1693 = convolution_backward_default_191[0]
        getitem_1694 = convolution_backward_default_191[1];  convolution_backward_default_191 = None
        convolution_backward_default_192 = torch.ops.aten.convolution_backward.default(getitem_1693, relu_default_93, primals_108, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1693 = primals_108 = None
        getitem_1696 = convolution_backward_default_192[0]
        getitem_1697 = convolution_backward_default_192[1];  convolution_backward_default_192 = None
        to_dtype_312 = torch.ops.aten.to.dtype(getitem_1696, torch.float32);  getitem_1696 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu_default_93, torch.float32);  relu_default_93 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_368 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_368, to_dtype_312);  le_scalar_104 = new_zeros_default_368 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(add_tensor_195, to_dtype_314);  add_tensor_195 = to_dtype_314 = None
        clone_default_41 = torch.ops.aten.clone.default(slice_tensor_49, memory_format = torch.contiguous_format);  slice_tensor_49 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(clone_default_41, convolution_default_294, primals_93, primals_91, primals_92, getitem_490, getitem_491, True, 0.001, [True, True, True]);  clone_default_41 = convolution_default_294 = primals_93 = primals_91 = primals_92 = getitem_490 = getitem_491 = None
        getitem_1699 = native_batch_norm_backward_default_104[0]
        getitem_1700 = native_batch_norm_backward_default_104[1]
        getitem_1701 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_193 = torch.ops.aten.convolution_backward.default(getitem_1699, convolution_default_293, primals_97, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1699 = convolution_default_293 = primals_97 = None
        getitem_1702 = convolution_backward_default_193[0]
        getitem_1703 = convolution_backward_default_193[1];  convolution_backward_default_193 = None
        convolution_backward_default_194 = torch.ops.aten.convolution_backward.default(getitem_1702, relu__default_65, primals_96, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1702 = primals_96 = None
        getitem_1705 = convolution_backward_default_194[0]
        getitem_1706 = convolution_backward_default_194[1];  convolution_backward_default_194 = None
        to_dtype_315 = torch.ops.aten.to.dtype(getitem_1705, torch.float32);  getitem_1705 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_369 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_369, to_dtype_315);  le_scalar_105 = new_zeros_default_369 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_317, convolution_default_292, primals_88, primals_86, primals_87, getitem_487, getitem_488, True, 0.001, [True, True, True]);  to_dtype_317 = convolution_default_292 = primals_88 = primals_86 = primals_87 = getitem_487 = getitem_488 = None
        getitem_1708 = native_batch_norm_backward_default_105[0]
        getitem_1709 = native_batch_norm_backward_default_105[1]
        getitem_1710 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_195 = torch.ops.aten.convolution_backward.default(getitem_1708, convolution_default_291, primals_95, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1708 = convolution_default_291 = primals_95 = None
        getitem_1711 = convolution_backward_default_195[0]
        getitem_1712 = convolution_backward_default_195[1];  convolution_backward_default_195 = None
        convolution_backward_default_196 = torch.ops.aten.convolution_backward.default(getitem_1711, relu_default_92, primals_94, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1711 = primals_94 = None
        getitem_1714 = convolution_backward_default_196[0]
        getitem_1715 = convolution_backward_default_196[1];  convolution_backward_default_196 = None
        to_dtype_318 = torch.ops.aten.to.dtype(getitem_1714, torch.float32);  getitem_1714 = None
        to_dtype_319 = torch.ops.aten.to.dtype(relu_default_92, torch.float32);  relu_default_92 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_319, 0);  to_dtype_319 = None
        new_zeros_default_370 = torch.ops.aten.new_zeros.default(to_dtype_318, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_370, to_dtype_318);  le_scalar_106 = new_zeros_default_370 = to_dtype_318 = None
        to_dtype_320 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(add_tensor_193, to_dtype_320);  add_tensor_193 = to_dtype_320 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_197, convolution_default_290, primals_158, primals_156, primals_157, getitem_484, getitem_485, True, 0.001, [True, True, True]);  add_tensor_197 = convolution_default_290 = primals_158 = primals_156 = primals_157 = getitem_484 = getitem_485 = None
        getitem_1717 = native_batch_norm_backward_default_106[0]
        getitem_1718 = native_batch_norm_backward_default_106[1]
        getitem_1719 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_197 = torch.ops.aten.convolution_backward.default(getitem_1717, relu_default_91, primals_159, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1717 = primals_159 = None
        getitem_1720 = convolution_backward_default_197[0]
        getitem_1721 = convolution_backward_default_197[1];  convolution_backward_default_197 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_1720, torch.float32);  getitem_1720 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu_default_91, torch.float32);  relu_default_91 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_371 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_371, to_dtype_321);  le_scalar_107 = new_zeros_default_371 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(to_dtype_290, to_dtype_323);  to_dtype_290 = to_dtype_323 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_196, convolution_default_289, primals_164, primals_162, primals_163, getitem_481, getitem_482, True, 0.001, [True, True, True]);  add_tensor_196 = convolution_default_289 = primals_164 = primals_162 = primals_163 = getitem_481 = getitem_482 = None
        getitem_1723 = native_batch_norm_backward_default_107[0]
        getitem_1724 = native_batch_norm_backward_default_107[1]
        getitem_1725 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_198 = torch.ops.aten.convolution_backward.default(getitem_1723, relu_default_90, primals_165, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1723 = primals_165 = None
        getitem_1726 = convolution_backward_default_198[0]
        getitem_1727 = convolution_backward_default_198[1];  convolution_backward_default_198 = None
        to_dtype_324 = torch.ops.aten.to.dtype(getitem_1726, torch.float32);  getitem_1726 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu_default_90, torch.float32);  relu_default_90 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_372 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_372, to_dtype_324);  le_scalar_108 = new_zeros_default_372 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        slice_tensor_54 = torch.ops.aten.slice.Tensor(add_tensor_198, 1, 0, 336)
        slice_tensor_55 = torch.ops.aten.slice.Tensor(add_tensor_198, 1, 336, 672)
        slice_tensor_56 = torch.ops.aten.slice.Tensor(add_tensor_198, 1, 672, 1008)
        slice_tensor_57 = torch.ops.aten.slice.Tensor(add_tensor_198, 1, 1008, 1344)
        slice_tensor_58 = torch.ops.aten.slice.Tensor(add_tensor_198, 1, 1344, 1680)
        slice_tensor_59 = torch.ops.aten.slice.Tensor(add_tensor_198, 1, 1680, 2016);  add_tensor_198 = None
        clone_default_42 = torch.ops.aten.clone.default(slice_tensor_59, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(clone_default_42, convolution_default_288, primals_1463, primals_1461, primals_1462, getitem_478, getitem_479, True, 0.001, [True, True, True]);  clone_default_42 = convolution_default_288 = primals_1463 = primals_1461 = primals_1462 = getitem_478 = getitem_479 = None
        getitem_1729 = native_batch_norm_backward_default_108[0]
        getitem_1730 = native_batch_norm_backward_default_108[1]
        getitem_1731 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_199 = torch.ops.aten.convolution_backward.default(getitem_1729, convolution_default_287, primals_1467, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1729 = convolution_default_287 = primals_1467 = None
        getitem_1732 = convolution_backward_default_199[0]
        getitem_1733 = convolution_backward_default_199[1];  convolution_backward_default_199 = None
        convolution_backward_default_200 = torch.ops.aten.convolution_backward.default(getitem_1732, relu__default_64, primals_1466, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1732 = primals_1466 = None
        getitem_1735 = convolution_backward_default_200[0]
        getitem_1736 = convolution_backward_default_200[1];  convolution_backward_default_200 = None
        to_dtype_327 = torch.ops.aten.to.dtype(getitem_1735, torch.float32);  getitem_1735 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_373 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_373, to_dtype_327);  le_scalar_109 = new_zeros_default_373 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_286, primals_1458, primals_1456, primals_1457, getitem_475, getitem_476, True, 0.001, [True, True, True]);  to_dtype_329 = convolution_default_286 = primals_1458 = primals_1456 = primals_1457 = getitem_475 = getitem_476 = None
        getitem_1738 = native_batch_norm_backward_default_109[0]
        getitem_1739 = native_batch_norm_backward_default_109[1]
        getitem_1740 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_201 = torch.ops.aten.convolution_backward.default(getitem_1738, convolution_default_285, primals_1465, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1738 = convolution_default_285 = primals_1465 = None
        getitem_1741 = convolution_backward_default_201[0]
        getitem_1742 = convolution_backward_default_201[1];  convolution_backward_default_201 = None
        convolution_backward_default_202 = torch.ops.aten.convolution_backward.default(getitem_1741, relu_default_89, primals_1464, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1741 = primals_1464 = None
        getitem_1744 = convolution_backward_default_202[0]
        getitem_1745 = convolution_backward_default_202[1];  convolution_backward_default_202 = None
        to_dtype_330 = torch.ops.aten.to.dtype(getitem_1744, torch.float32);  getitem_1744 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu_default_89, torch.float32);  relu_default_89 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_374 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_374, to_dtype_330);  le_scalar_110 = new_zeros_default_374 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(slice_tensor_59, to_dtype_332);  slice_tensor_59 = to_dtype_332 = None
        avg_pool2d_backward_default_28 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_58, getitem_444, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_200 = torch.ops.aten.add.Tensor(slice_tensor_54, avg_pool2d_backward_default_28);  slice_tensor_54 = avg_pool2d_backward_default_28 = None
        avg_pool2d_backward_default_29 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_58, getitem_444, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_58 = getitem_444 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(add_tensor_200, avg_pool2d_backward_default_29);  add_tensor_200 = avg_pool2d_backward_default_29 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(add_tensor_201, slice_tensor_57);  add_tensor_201 = None
        avg_pool2d_backward_default_30 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_57, getitem_447, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_57 = getitem_447 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(add_tensor_199, avg_pool2d_backward_default_30);  add_tensor_199 = avg_pool2d_backward_default_30 = None
        clone_default_43 = torch.ops.aten.clone.default(slice_tensor_56, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(clone_default_43, convolution_default_284, primals_1449, primals_1447, primals_1448, getitem_472, getitem_473, True, 0.001, [True, True, True]);  clone_default_43 = convolution_default_284 = primals_1449 = primals_1447 = primals_1448 = getitem_472 = getitem_473 = None
        getitem_1747 = native_batch_norm_backward_default_110[0]
        getitem_1748 = native_batch_norm_backward_default_110[1]
        getitem_1749 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_203 = torch.ops.aten.convolution_backward.default(getitem_1747, convolution_default_283, primals_1453, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1747 = convolution_default_283 = primals_1453 = None
        getitem_1750 = convolution_backward_default_203[0]
        getitem_1751 = convolution_backward_default_203[1];  convolution_backward_default_203 = None
        convolution_backward_default_204 = torch.ops.aten.convolution_backward.default(getitem_1750, relu__default_63, primals_1452, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1750 = primals_1452 = None
        getitem_1753 = convolution_backward_default_204[0]
        getitem_1754 = convolution_backward_default_204[1];  convolution_backward_default_204 = None
        to_dtype_333 = torch.ops.aten.to.dtype(getitem_1753, torch.float32);  getitem_1753 = None
        to_dtype_334 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_334, 0);  to_dtype_334 = None
        new_zeros_default_375 = torch.ops.aten.new_zeros.default(to_dtype_333, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_375, to_dtype_333);  le_scalar_111 = new_zeros_default_375 = to_dtype_333 = None
        to_dtype_335 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_335, convolution_default_282, primals_1444, primals_1442, primals_1443, getitem_469, getitem_470, True, 0.001, [True, True, True]);  to_dtype_335 = convolution_default_282 = primals_1444 = primals_1442 = primals_1443 = getitem_469 = getitem_470 = None
        getitem_1756 = native_batch_norm_backward_default_111[0]
        getitem_1757 = native_batch_norm_backward_default_111[1]
        getitem_1758 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_205 = torch.ops.aten.convolution_backward.default(getitem_1756, convolution_default_281, primals_1451, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1756 = convolution_default_281 = primals_1451 = None
        getitem_1759 = convolution_backward_default_205[0]
        getitem_1760 = convolution_backward_default_205[1];  convolution_backward_default_205 = None
        convolution_backward_default_206 = torch.ops.aten.convolution_backward.default(getitem_1759, relu_default_88, primals_1450, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1759 = primals_1450 = None
        getitem_1762 = convolution_backward_default_206[0]
        getitem_1763 = convolution_backward_default_206[1];  convolution_backward_default_206 = None
        to_dtype_336 = torch.ops.aten.to.dtype(getitem_1762, torch.float32);  getitem_1762 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu_default_88, torch.float32);  relu_default_88 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_376 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_376, to_dtype_336);  le_scalar_112 = new_zeros_default_376 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(add_tensor_202, to_dtype_338);  add_tensor_202 = to_dtype_338 = None
        clone_default_44 = torch.ops.aten.clone.default(slice_tensor_56, memory_format = torch.contiguous_format);  slice_tensor_56 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(clone_default_44, convolution_default_280, primals_1435, primals_1433, primals_1434, getitem_466, getitem_467, True, 0.001, [True, True, True]);  clone_default_44 = convolution_default_280 = primals_1435 = primals_1433 = primals_1434 = getitem_466 = getitem_467 = None
        getitem_1765 = native_batch_norm_backward_default_112[0]
        getitem_1766 = native_batch_norm_backward_default_112[1]
        getitem_1767 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_207 = torch.ops.aten.convolution_backward.default(getitem_1765, convolution_default_279, primals_1439, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1765 = convolution_default_279 = primals_1439 = None
        getitem_1768 = convolution_backward_default_207[0]
        getitem_1769 = convolution_backward_default_207[1];  convolution_backward_default_207 = None
        convolution_backward_default_208 = torch.ops.aten.convolution_backward.default(getitem_1768, relu__default_62, primals_1438, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1768 = primals_1438 = None
        getitem_1771 = convolution_backward_default_208[0]
        getitem_1772 = convolution_backward_default_208[1];  convolution_backward_default_208 = None
        to_dtype_339 = torch.ops.aten.to.dtype(getitem_1771, torch.float32);  getitem_1771 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_377 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_377, to_dtype_339);  le_scalar_113 = new_zeros_default_377 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_278, primals_1430, primals_1428, primals_1429, getitem_463, getitem_464, True, 0.001, [True, True, True]);  to_dtype_341 = convolution_default_278 = primals_1430 = primals_1428 = primals_1429 = getitem_463 = getitem_464 = None
        getitem_1774 = native_batch_norm_backward_default_113[0]
        getitem_1775 = native_batch_norm_backward_default_113[1]
        getitem_1776 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_209 = torch.ops.aten.convolution_backward.default(getitem_1774, convolution_default_277, primals_1437, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1774 = convolution_default_277 = primals_1437 = None
        getitem_1777 = convolution_backward_default_209[0]
        getitem_1778 = convolution_backward_default_209[1];  convolution_backward_default_209 = None
        convolution_backward_default_210 = torch.ops.aten.convolution_backward.default(getitem_1777, relu_default_87, primals_1436, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1777 = primals_1436 = None
        getitem_1780 = convolution_backward_default_210[0]
        getitem_1781 = convolution_backward_default_210[1];  convolution_backward_default_210 = None
        to_dtype_342 = torch.ops.aten.to.dtype(getitem_1780, torch.float32);  getitem_1780 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu_default_87, torch.float32);  relu_default_87 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_378 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_378, to_dtype_342);  le_scalar_114 = new_zeros_default_378 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        add_tensor_205 = torch.ops.aten.add.Tensor(add_tensor_204, to_dtype_344);  add_tensor_204 = to_dtype_344 = None
        clone_default_45 = torch.ops.aten.clone.default(slice_tensor_55, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(clone_default_45, convolution_default_276, primals_1421, primals_1419, primals_1420, getitem_460, getitem_461, True, 0.001, [True, True, True]);  clone_default_45 = convolution_default_276 = primals_1421 = primals_1419 = primals_1420 = getitem_460 = getitem_461 = None
        getitem_1783 = native_batch_norm_backward_default_114[0]
        getitem_1784 = native_batch_norm_backward_default_114[1]
        getitem_1785 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_211 = torch.ops.aten.convolution_backward.default(getitem_1783, convolution_default_275, primals_1425, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1783 = convolution_default_275 = primals_1425 = None
        getitem_1786 = convolution_backward_default_211[0]
        getitem_1787 = convolution_backward_default_211[1];  convolution_backward_default_211 = None
        convolution_backward_default_212 = torch.ops.aten.convolution_backward.default(getitem_1786, relu__default_61, primals_1424, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1786 = primals_1424 = None
        getitem_1789 = convolution_backward_default_212[0]
        getitem_1790 = convolution_backward_default_212[1];  convolution_backward_default_212 = None
        to_dtype_345 = torch.ops.aten.to.dtype(getitem_1789, torch.float32);  getitem_1789 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_379 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_379, to_dtype_345);  le_scalar_115 = new_zeros_default_379 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_347, convolution_default_274, primals_1416, primals_1414, primals_1415, getitem_457, getitem_458, True, 0.001, [True, True, True]);  to_dtype_347 = convolution_default_274 = primals_1416 = primals_1414 = primals_1415 = getitem_457 = getitem_458 = None
        getitem_1792 = native_batch_norm_backward_default_115[0]
        getitem_1793 = native_batch_norm_backward_default_115[1]
        getitem_1794 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_213 = torch.ops.aten.convolution_backward.default(getitem_1792, convolution_default_273, primals_1423, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1792 = convolution_default_273 = primals_1423 = None
        getitem_1795 = convolution_backward_default_213[0]
        getitem_1796 = convolution_backward_default_213[1];  convolution_backward_default_213 = None
        convolution_backward_default_214 = torch.ops.aten.convolution_backward.default(getitem_1795, relu_default_86, primals_1422, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1795 = primals_1422 = None
        getitem_1798 = convolution_backward_default_214[0]
        getitem_1799 = convolution_backward_default_214[1];  convolution_backward_default_214 = None
        to_dtype_348 = torch.ops.aten.to.dtype(getitem_1798, torch.float32);  getitem_1798 = None
        to_dtype_349 = torch.ops.aten.to.dtype(relu_default_86, torch.float32);  relu_default_86 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_349, 0);  to_dtype_349 = None
        new_zeros_default_380 = torch.ops.aten.new_zeros.default(to_dtype_348, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_380, to_dtype_348);  le_scalar_116 = new_zeros_default_380 = to_dtype_348 = None
        to_dtype_350 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        add_tensor_206 = torch.ops.aten.add.Tensor(add_tensor_205, to_dtype_350);  add_tensor_205 = to_dtype_350 = None
        clone_default_46 = torch.ops.aten.clone.default(slice_tensor_55, memory_format = torch.contiguous_format);  slice_tensor_55 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(clone_default_46, convolution_default_272, primals_1407, primals_1405, primals_1406, getitem_454, getitem_455, True, 0.001, [True, True, True]);  clone_default_46 = convolution_default_272 = primals_1407 = primals_1405 = primals_1406 = getitem_454 = getitem_455 = None
        getitem_1801 = native_batch_norm_backward_default_116[0]
        getitem_1802 = native_batch_norm_backward_default_116[1]
        getitem_1803 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_215 = torch.ops.aten.convolution_backward.default(getitem_1801, convolution_default_271, primals_1411, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1801 = convolution_default_271 = primals_1411 = None
        getitem_1804 = convolution_backward_default_215[0]
        getitem_1805 = convolution_backward_default_215[1];  convolution_backward_default_215 = None
        convolution_backward_default_216 = torch.ops.aten.convolution_backward.default(getitem_1804, relu__default_60, primals_1410, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1804 = primals_1410 = None
        getitem_1807 = convolution_backward_default_216[0]
        getitem_1808 = convolution_backward_default_216[1];  convolution_backward_default_216 = None
        to_dtype_351 = torch.ops.aten.to.dtype(getitem_1807, torch.float32);  getitem_1807 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_381 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_381, to_dtype_351);  le_scalar_117 = new_zeros_default_381 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_353, convolution_default_270, primals_1402, primals_1400, primals_1401, getitem_451, getitem_452, True, 0.001, [True, True, True]);  to_dtype_353 = convolution_default_270 = primals_1402 = primals_1400 = primals_1401 = getitem_451 = getitem_452 = None
        getitem_1810 = native_batch_norm_backward_default_117[0]
        getitem_1811 = native_batch_norm_backward_default_117[1]
        getitem_1812 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_217 = torch.ops.aten.convolution_backward.default(getitem_1810, convolution_default_269, primals_1409, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1810 = convolution_default_269 = primals_1409 = None
        getitem_1813 = convolution_backward_default_217[0]
        getitem_1814 = convolution_backward_default_217[1];  convolution_backward_default_217 = None
        convolution_backward_default_218 = torch.ops.aten.convolution_backward.default(getitem_1813, relu_default_85, primals_1408, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1813 = primals_1408 = None
        getitem_1816 = convolution_backward_default_218[0]
        getitem_1817 = convolution_backward_default_218[1];  convolution_backward_default_218 = None
        to_dtype_354 = torch.ops.aten.to.dtype(getitem_1816, torch.float32);  getitem_1816 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu_default_85, torch.float32);  relu_default_85 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_382 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_382, to_dtype_354);  le_scalar_118 = new_zeros_default_382 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        add_tensor_207 = torch.ops.aten.add.Tensor(add_tensor_203, to_dtype_356);  add_tensor_203 = to_dtype_356 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_207, convolution_default_268, primals_1472, primals_1470, primals_1471, getitem_448, getitem_449, True, 0.001, [True, True, True]);  add_tensor_207 = convolution_default_268 = primals_1472 = primals_1470 = primals_1471 = getitem_448 = getitem_449 = None
        getitem_1819 = native_batch_norm_backward_default_118[0]
        getitem_1820 = native_batch_norm_backward_default_118[1]
        getitem_1821 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_219 = torch.ops.aten.convolution_backward.default(getitem_1819, relu_default_84, primals_1473, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1819 = primals_1473 = None
        getitem_1822 = convolution_backward_default_219[0]
        getitem_1823 = convolution_backward_default_219[1];  convolution_backward_default_219 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_1822, torch.float32);  getitem_1822 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu_default_84, torch.float32);  relu_default_84 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_383 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_383, to_dtype_357);  le_scalar_119 = new_zeros_default_383 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        add_tensor_208 = torch.ops.aten.add.Tensor(to_dtype_326, to_dtype_359);  to_dtype_326 = to_dtype_359 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_206, convolution_default_267, primals_1478, primals_1476, primals_1477, getitem_445, getitem_446, True, 0.001, [True, True, True]);  add_tensor_206 = convolution_default_267 = primals_1478 = primals_1476 = primals_1477 = getitem_445 = getitem_446 = None
        getitem_1825 = native_batch_norm_backward_default_119[0]
        getitem_1826 = native_batch_norm_backward_default_119[1]
        getitem_1827 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_220 = torch.ops.aten.convolution_backward.default(getitem_1825, relu_default_83, primals_1479, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1825 = primals_1479 = None
        getitem_1828 = convolution_backward_default_220[0]
        getitem_1829 = convolution_backward_default_220[1];  convolution_backward_default_220 = None
        to_dtype_360 = torch.ops.aten.to.dtype(getitem_1828, torch.float32);  getitem_1828 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu_default_83, torch.float32);  relu_default_83 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_384 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_384, to_dtype_360);  le_scalar_120 = new_zeros_default_384 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        slice_tensor_60 = torch.ops.aten.slice.Tensor(add_tensor_208, 1, 0, 336)
        slice_tensor_61 = torch.ops.aten.slice.Tensor(add_tensor_208, 1, 336, 672)
        slice_tensor_62 = torch.ops.aten.slice.Tensor(add_tensor_208, 1, 672, 1008)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(add_tensor_208, 1, 1008, 1344)
        slice_tensor_64 = torch.ops.aten.slice.Tensor(add_tensor_208, 1, 1344, 1680)
        slice_tensor_65 = torch.ops.aten.slice.Tensor(add_tensor_208, 1, 1680, 2016);  add_tensor_208 = None
        clone_default_47 = torch.ops.aten.clone.default(slice_tensor_65, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(clone_default_47, convolution_default_266, primals_1381, primals_1379, primals_1380, getitem_442, getitem_443, True, 0.001, [True, True, True]);  clone_default_47 = convolution_default_266 = primals_1381 = primals_1379 = primals_1380 = getitem_442 = getitem_443 = None
        getitem_1831 = native_batch_norm_backward_default_120[0]
        getitem_1832 = native_batch_norm_backward_default_120[1]
        getitem_1833 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_221 = torch.ops.aten.convolution_backward.default(getitem_1831, convolution_default_265, primals_1385, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1831 = convolution_default_265 = primals_1385 = None
        getitem_1834 = convolution_backward_default_221[0]
        getitem_1835 = convolution_backward_default_221[1];  convolution_backward_default_221 = None
        convolution_backward_default_222 = torch.ops.aten.convolution_backward.default(getitem_1834, relu__default_59, primals_1384, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1834 = primals_1384 = None
        getitem_1837 = convolution_backward_default_222[0]
        getitem_1838 = convolution_backward_default_222[1];  convolution_backward_default_222 = None
        to_dtype_363 = torch.ops.aten.to.dtype(getitem_1837, torch.float32);  getitem_1837 = None
        to_dtype_364 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_364, 0);  to_dtype_364 = None
        new_zeros_default_385 = torch.ops.aten.new_zeros.default(to_dtype_363, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_385, to_dtype_363);  le_scalar_121 = new_zeros_default_385 = to_dtype_363 = None
        to_dtype_365 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_365, convolution_default_264, primals_1376, primals_1374, primals_1375, getitem_439, getitem_440, True, 0.001, [True, True, True]);  to_dtype_365 = convolution_default_264 = primals_1376 = primals_1374 = primals_1375 = getitem_439 = getitem_440 = None
        getitem_1840 = native_batch_norm_backward_default_121[0]
        getitem_1841 = native_batch_norm_backward_default_121[1]
        getitem_1842 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_223 = torch.ops.aten.convolution_backward.default(getitem_1840, convolution_default_263, primals_1383, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1840 = convolution_default_263 = primals_1383 = None
        getitem_1843 = convolution_backward_default_223[0]
        getitem_1844 = convolution_backward_default_223[1];  convolution_backward_default_223 = None
        convolution_backward_default_224 = torch.ops.aten.convolution_backward.default(getitem_1843, relu_default_82, primals_1382, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1843 = primals_1382 = None
        getitem_1846 = convolution_backward_default_224[0]
        getitem_1847 = convolution_backward_default_224[1];  convolution_backward_default_224 = None
        to_dtype_366 = torch.ops.aten.to.dtype(getitem_1846, torch.float32);  getitem_1846 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu_default_82, torch.float32);  relu_default_82 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_386 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_386, to_dtype_366);  le_scalar_122 = new_zeros_default_386 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        add_tensor_209 = torch.ops.aten.add.Tensor(slice_tensor_65, to_dtype_368);  slice_tensor_65 = to_dtype_368 = None
        avg_pool2d_backward_default_31 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_64, getitem_408, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_210 = torch.ops.aten.add.Tensor(slice_tensor_60, avg_pool2d_backward_default_31);  slice_tensor_60 = avg_pool2d_backward_default_31 = None
        avg_pool2d_backward_default_32 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_64, getitem_408, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_64 = getitem_408 = None
        add_tensor_211 = torch.ops.aten.add.Tensor(add_tensor_210, avg_pool2d_backward_default_32);  add_tensor_210 = avg_pool2d_backward_default_32 = None
        add_tensor_212 = torch.ops.aten.add.Tensor(add_tensor_211, slice_tensor_63);  add_tensor_211 = None
        avg_pool2d_backward_default_33 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_63, getitem_411, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_63 = getitem_411 = None
        add_tensor_213 = torch.ops.aten.add.Tensor(add_tensor_209, avg_pool2d_backward_default_33);  add_tensor_209 = avg_pool2d_backward_default_33 = None
        clone_default_48 = torch.ops.aten.clone.default(slice_tensor_62, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(clone_default_48, convolution_default_262, primals_1367, primals_1365, primals_1366, getitem_436, getitem_437, True, 0.001, [True, True, True]);  clone_default_48 = convolution_default_262 = primals_1367 = primals_1365 = primals_1366 = getitem_436 = getitem_437 = None
        getitem_1849 = native_batch_norm_backward_default_122[0]
        getitem_1850 = native_batch_norm_backward_default_122[1]
        getitem_1851 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_225 = torch.ops.aten.convolution_backward.default(getitem_1849, convolution_default_261, primals_1371, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1849 = convolution_default_261 = primals_1371 = None
        getitem_1852 = convolution_backward_default_225[0]
        getitem_1853 = convolution_backward_default_225[1];  convolution_backward_default_225 = None
        convolution_backward_default_226 = torch.ops.aten.convolution_backward.default(getitem_1852, relu__default_58, primals_1370, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1852 = primals_1370 = None
        getitem_1855 = convolution_backward_default_226[0]
        getitem_1856 = convolution_backward_default_226[1];  convolution_backward_default_226 = None
        to_dtype_369 = torch.ops.aten.to.dtype(getitem_1855, torch.float32);  getitem_1855 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_387 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_387, to_dtype_369);  le_scalar_123 = new_zeros_default_387 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_260, primals_1362, primals_1360, primals_1361, getitem_433, getitem_434, True, 0.001, [True, True, True]);  to_dtype_371 = convolution_default_260 = primals_1362 = primals_1360 = primals_1361 = getitem_433 = getitem_434 = None
        getitem_1858 = native_batch_norm_backward_default_123[0]
        getitem_1859 = native_batch_norm_backward_default_123[1]
        getitem_1860 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_227 = torch.ops.aten.convolution_backward.default(getitem_1858, convolution_default_259, primals_1369, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1858 = convolution_default_259 = primals_1369 = None
        getitem_1861 = convolution_backward_default_227[0]
        getitem_1862 = convolution_backward_default_227[1];  convolution_backward_default_227 = None
        convolution_backward_default_228 = torch.ops.aten.convolution_backward.default(getitem_1861, relu_default_81, primals_1368, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1861 = primals_1368 = None
        getitem_1864 = convolution_backward_default_228[0]
        getitem_1865 = convolution_backward_default_228[1];  convolution_backward_default_228 = None
        to_dtype_372 = torch.ops.aten.to.dtype(getitem_1864, torch.float32);  getitem_1864 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu_default_81, torch.float32);  relu_default_81 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_388 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_388, to_dtype_372);  le_scalar_124 = new_zeros_default_388 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        add_tensor_214 = torch.ops.aten.add.Tensor(add_tensor_212, to_dtype_374);  add_tensor_212 = to_dtype_374 = None
        clone_default_49 = torch.ops.aten.clone.default(slice_tensor_62, memory_format = torch.contiguous_format);  slice_tensor_62 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(clone_default_49, convolution_default_258, primals_1353, primals_1351, primals_1352, getitem_430, getitem_431, True, 0.001, [True, True, True]);  clone_default_49 = convolution_default_258 = primals_1353 = primals_1351 = primals_1352 = getitem_430 = getitem_431 = None
        getitem_1867 = native_batch_norm_backward_default_124[0]
        getitem_1868 = native_batch_norm_backward_default_124[1]
        getitem_1869 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_229 = torch.ops.aten.convolution_backward.default(getitem_1867, convolution_default_257, primals_1357, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1867 = convolution_default_257 = primals_1357 = None
        getitem_1870 = convolution_backward_default_229[0]
        getitem_1871 = convolution_backward_default_229[1];  convolution_backward_default_229 = None
        convolution_backward_default_230 = torch.ops.aten.convolution_backward.default(getitem_1870, relu__default_57, primals_1356, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1870 = primals_1356 = None
        getitem_1873 = convolution_backward_default_230[0]
        getitem_1874 = convolution_backward_default_230[1];  convolution_backward_default_230 = None
        to_dtype_375 = torch.ops.aten.to.dtype(getitem_1873, torch.float32);  getitem_1873 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_389 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_389, to_dtype_375);  le_scalar_125 = new_zeros_default_389 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_256, primals_1348, primals_1346, primals_1347, getitem_427, getitem_428, True, 0.001, [True, True, True]);  to_dtype_377 = convolution_default_256 = primals_1348 = primals_1346 = primals_1347 = getitem_427 = getitem_428 = None
        getitem_1876 = native_batch_norm_backward_default_125[0]
        getitem_1877 = native_batch_norm_backward_default_125[1]
        getitem_1878 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_231 = torch.ops.aten.convolution_backward.default(getitem_1876, convolution_default_255, primals_1355, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1876 = convolution_default_255 = primals_1355 = None
        getitem_1879 = convolution_backward_default_231[0]
        getitem_1880 = convolution_backward_default_231[1];  convolution_backward_default_231 = None
        convolution_backward_default_232 = torch.ops.aten.convolution_backward.default(getitem_1879, relu_default_80, primals_1354, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1879 = primals_1354 = None
        getitem_1882 = convolution_backward_default_232[0]
        getitem_1883 = convolution_backward_default_232[1];  convolution_backward_default_232 = None
        to_dtype_378 = torch.ops.aten.to.dtype(getitem_1882, torch.float32);  getitem_1882 = None
        to_dtype_379 = torch.ops.aten.to.dtype(relu_default_80, torch.float32);  relu_default_80 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_379, 0);  to_dtype_379 = None
        new_zeros_default_390 = torch.ops.aten.new_zeros.default(to_dtype_378, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_390, to_dtype_378);  le_scalar_126 = new_zeros_default_390 = to_dtype_378 = None
        to_dtype_380 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        add_tensor_215 = torch.ops.aten.add.Tensor(add_tensor_214, to_dtype_380);  add_tensor_214 = to_dtype_380 = None
        clone_default_50 = torch.ops.aten.clone.default(slice_tensor_61, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(clone_default_50, convolution_default_254, primals_1339, primals_1337, primals_1338, getitem_424, getitem_425, True, 0.001, [True, True, True]);  clone_default_50 = convolution_default_254 = primals_1339 = primals_1337 = primals_1338 = getitem_424 = getitem_425 = None
        getitem_1885 = native_batch_norm_backward_default_126[0]
        getitem_1886 = native_batch_norm_backward_default_126[1]
        getitem_1887 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_233 = torch.ops.aten.convolution_backward.default(getitem_1885, convolution_default_253, primals_1343, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1885 = convolution_default_253 = primals_1343 = None
        getitem_1888 = convolution_backward_default_233[0]
        getitem_1889 = convolution_backward_default_233[1];  convolution_backward_default_233 = None
        convolution_backward_default_234 = torch.ops.aten.convolution_backward.default(getitem_1888, relu__default_56, primals_1342, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1888 = primals_1342 = None
        getitem_1891 = convolution_backward_default_234[0]
        getitem_1892 = convolution_backward_default_234[1];  convolution_backward_default_234 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_1891, torch.float32);  getitem_1891 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_391 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_391, to_dtype_381);  le_scalar_127 = new_zeros_default_391 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_383, convolution_default_252, primals_1334, primals_1332, primals_1333, getitem_421, getitem_422, True, 0.001, [True, True, True]);  to_dtype_383 = convolution_default_252 = primals_1334 = primals_1332 = primals_1333 = getitem_421 = getitem_422 = None
        getitem_1894 = native_batch_norm_backward_default_127[0]
        getitem_1895 = native_batch_norm_backward_default_127[1]
        getitem_1896 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_235 = torch.ops.aten.convolution_backward.default(getitem_1894, convolution_default_251, primals_1341, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1894 = convolution_default_251 = primals_1341 = None
        getitem_1897 = convolution_backward_default_235[0]
        getitem_1898 = convolution_backward_default_235[1];  convolution_backward_default_235 = None
        convolution_backward_default_236 = torch.ops.aten.convolution_backward.default(getitem_1897, relu_default_79, primals_1340, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1897 = primals_1340 = None
        getitem_1900 = convolution_backward_default_236[0]
        getitem_1901 = convolution_backward_default_236[1];  convolution_backward_default_236 = None
        to_dtype_384 = torch.ops.aten.to.dtype(getitem_1900, torch.float32);  getitem_1900 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu_default_79, torch.float32);  relu_default_79 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_392 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_392, to_dtype_384);  le_scalar_128 = new_zeros_default_392 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        add_tensor_216 = torch.ops.aten.add.Tensor(add_tensor_215, to_dtype_386);  add_tensor_215 = to_dtype_386 = None
        clone_default_51 = torch.ops.aten.clone.default(slice_tensor_61, memory_format = torch.contiguous_format);  slice_tensor_61 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(clone_default_51, convolution_default_250, primals_1325, primals_1323, primals_1324, getitem_418, getitem_419, True, 0.001, [True, True, True]);  clone_default_51 = convolution_default_250 = primals_1325 = primals_1323 = primals_1324 = getitem_418 = getitem_419 = None
        getitem_1903 = native_batch_norm_backward_default_128[0]
        getitem_1904 = native_batch_norm_backward_default_128[1]
        getitem_1905 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_237 = torch.ops.aten.convolution_backward.default(getitem_1903, convolution_default_249, primals_1329, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1903 = convolution_default_249 = primals_1329 = None
        getitem_1906 = convolution_backward_default_237[0]
        getitem_1907 = convolution_backward_default_237[1];  convolution_backward_default_237 = None
        convolution_backward_default_238 = torch.ops.aten.convolution_backward.default(getitem_1906, relu__default_55, primals_1328, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1906 = primals_1328 = None
        getitem_1909 = convolution_backward_default_238[0]
        getitem_1910 = convolution_backward_default_238[1];  convolution_backward_default_238 = None
        to_dtype_387 = torch.ops.aten.to.dtype(getitem_1909, torch.float32);  getitem_1909 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_393 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_393, to_dtype_387);  le_scalar_129 = new_zeros_default_393 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_248, primals_1320, primals_1318, primals_1319, getitem_415, getitem_416, True, 0.001, [True, True, True]);  to_dtype_389 = convolution_default_248 = primals_1320 = primals_1318 = primals_1319 = getitem_415 = getitem_416 = None
        getitem_1912 = native_batch_norm_backward_default_129[0]
        getitem_1913 = native_batch_norm_backward_default_129[1]
        getitem_1914 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_239 = torch.ops.aten.convolution_backward.default(getitem_1912, convolution_default_247, primals_1327, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1912 = convolution_default_247 = primals_1327 = None
        getitem_1915 = convolution_backward_default_239[0]
        getitem_1916 = convolution_backward_default_239[1];  convolution_backward_default_239 = None
        convolution_backward_default_240 = torch.ops.aten.convolution_backward.default(getitem_1915, relu_default_78, primals_1326, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1915 = primals_1326 = None
        getitem_1918 = convolution_backward_default_240[0]
        getitem_1919 = convolution_backward_default_240[1];  convolution_backward_default_240 = None
        to_dtype_390 = torch.ops.aten.to.dtype(getitem_1918, torch.float32);  getitem_1918 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu_default_78, torch.float32);  relu_default_78 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_394 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_394, to_dtype_390);  le_scalar_130 = new_zeros_default_394 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        add_tensor_217 = torch.ops.aten.add.Tensor(add_tensor_213, to_dtype_392);  add_tensor_213 = to_dtype_392 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_217, convolution_default_246, primals_1390, primals_1388, primals_1389, getitem_412, getitem_413, True, 0.001, [True, True, True]);  add_tensor_217 = convolution_default_246 = primals_1390 = primals_1388 = primals_1389 = getitem_412 = getitem_413 = None
        getitem_1921 = native_batch_norm_backward_default_130[0]
        getitem_1922 = native_batch_norm_backward_default_130[1]
        getitem_1923 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_241 = torch.ops.aten.convolution_backward.default(getitem_1921, relu_default_77, primals_1391, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1921 = primals_1391 = None
        getitem_1924 = convolution_backward_default_241[0]
        getitem_1925 = convolution_backward_default_241[1];  convolution_backward_default_241 = None
        to_dtype_393 = torch.ops.aten.to.dtype(getitem_1924, torch.float32);  getitem_1924 = None
        to_dtype_394 = torch.ops.aten.to.dtype(relu_default_77, torch.float32);  relu_default_77 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_394, 0);  to_dtype_394 = None
        new_zeros_default_395 = torch.ops.aten.new_zeros.default(to_dtype_393, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_395, to_dtype_393);  le_scalar_131 = new_zeros_default_395 = to_dtype_393 = None
        to_dtype_395 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        add_tensor_218 = torch.ops.aten.add.Tensor(to_dtype_362, to_dtype_395);  to_dtype_362 = to_dtype_395 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_216, convolution_default_245, primals_1396, primals_1394, primals_1395, getitem_409, getitem_410, True, 0.001, [True, True, True]);  add_tensor_216 = convolution_default_245 = primals_1396 = primals_1394 = primals_1395 = getitem_409 = getitem_410 = None
        getitem_1927 = native_batch_norm_backward_default_131[0]
        getitem_1928 = native_batch_norm_backward_default_131[1]
        getitem_1929 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_242 = torch.ops.aten.convolution_backward.default(getitem_1927, relu_default_76, primals_1397, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1927 = primals_1397 = None
        getitem_1930 = convolution_backward_default_242[0]
        getitem_1931 = convolution_backward_default_242[1];  convolution_backward_default_242 = None
        to_dtype_396 = torch.ops.aten.to.dtype(getitem_1930, torch.float32);  getitem_1930 = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu_default_76, torch.float32);  relu_default_76 = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_396 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_396, to_dtype_396);  le_scalar_132 = new_zeros_default_396 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        slice_tensor_66 = torch.ops.aten.slice.Tensor(add_tensor_218, 1, 0, 336)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(add_tensor_218, 1, 336, 672)
        slice_tensor_68 = torch.ops.aten.slice.Tensor(add_tensor_218, 1, 672, 1008)
        slice_tensor_69 = torch.ops.aten.slice.Tensor(add_tensor_218, 1, 1008, 1344)
        slice_tensor_70 = torch.ops.aten.slice.Tensor(add_tensor_218, 1, 1344, 1680)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(add_tensor_218, 1, 1680, 2016);  add_tensor_218 = None
        clone_default_52 = torch.ops.aten.clone.default(slice_tensor_71, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(clone_default_52, convolution_default_244, primals_1299, primals_1297, primals_1298, getitem_406, getitem_407, True, 0.001, [True, True, True]);  clone_default_52 = convolution_default_244 = primals_1299 = primals_1297 = primals_1298 = getitem_406 = getitem_407 = None
        getitem_1933 = native_batch_norm_backward_default_132[0]
        getitem_1934 = native_batch_norm_backward_default_132[1]
        getitem_1935 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_243 = torch.ops.aten.convolution_backward.default(getitem_1933, convolution_default_243, primals_1303, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1933 = convolution_default_243 = primals_1303 = None
        getitem_1936 = convolution_backward_default_243[0]
        getitem_1937 = convolution_backward_default_243[1];  convolution_backward_default_243 = None
        convolution_backward_default_244 = torch.ops.aten.convolution_backward.default(getitem_1936, relu__default_54, primals_1302, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1936 = primals_1302 = None
        getitem_1939 = convolution_backward_default_244[0]
        getitem_1940 = convolution_backward_default_244[1];  convolution_backward_default_244 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_1939, torch.float32);  getitem_1939 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_133 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_397 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_133 = torch.ops.aten.where.self(le_scalar_133, new_zeros_default_397, to_dtype_399);  le_scalar_133 = new_zeros_default_397 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_133, torch.float32);  where_self_133 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_242, primals_1294, primals_1292, primals_1293, getitem_403, getitem_404, True, 0.001, [True, True, True]);  to_dtype_401 = convolution_default_242 = primals_1294 = primals_1292 = primals_1293 = getitem_403 = getitem_404 = None
        getitem_1942 = native_batch_norm_backward_default_133[0]
        getitem_1943 = native_batch_norm_backward_default_133[1]
        getitem_1944 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_245 = torch.ops.aten.convolution_backward.default(getitem_1942, convolution_default_241, primals_1301, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1942 = convolution_default_241 = primals_1301 = None
        getitem_1945 = convolution_backward_default_245[0]
        getitem_1946 = convolution_backward_default_245[1];  convolution_backward_default_245 = None
        convolution_backward_default_246 = torch.ops.aten.convolution_backward.default(getitem_1945, relu_default_75, primals_1300, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1945 = primals_1300 = None
        getitem_1948 = convolution_backward_default_246[0]
        getitem_1949 = convolution_backward_default_246[1];  convolution_backward_default_246 = None
        to_dtype_402 = torch.ops.aten.to.dtype(getitem_1948, torch.float32);  getitem_1948 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu_default_75, torch.float32);  relu_default_75 = None
        le_scalar_134 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_398 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_134 = torch.ops.aten.where.self(le_scalar_134, new_zeros_default_398, to_dtype_402);  le_scalar_134 = new_zeros_default_398 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_134, torch.float32);  where_self_134 = None
        add_tensor_219 = torch.ops.aten.add.Tensor(slice_tensor_71, to_dtype_404);  slice_tensor_71 = to_dtype_404 = None
        avg_pool2d_backward_default_34 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_70, getitem_372, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_220 = torch.ops.aten.add.Tensor(slice_tensor_66, avg_pool2d_backward_default_34);  slice_tensor_66 = avg_pool2d_backward_default_34 = None
        avg_pool2d_backward_default_35 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_70, getitem_372, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_70 = getitem_372 = None
        add_tensor_221 = torch.ops.aten.add.Tensor(add_tensor_220, avg_pool2d_backward_default_35);  add_tensor_220 = avg_pool2d_backward_default_35 = None
        add_tensor_222 = torch.ops.aten.add.Tensor(add_tensor_221, slice_tensor_69);  add_tensor_221 = None
        avg_pool2d_backward_default_36 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_69, getitem_375, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_69 = getitem_375 = None
        add_tensor_223 = torch.ops.aten.add.Tensor(add_tensor_219, avg_pool2d_backward_default_36);  add_tensor_219 = avg_pool2d_backward_default_36 = None
        clone_default_53 = torch.ops.aten.clone.default(slice_tensor_68, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(clone_default_53, convolution_default_240, primals_1285, primals_1283, primals_1284, getitem_400, getitem_401, True, 0.001, [True, True, True]);  clone_default_53 = convolution_default_240 = primals_1285 = primals_1283 = primals_1284 = getitem_400 = getitem_401 = None
        getitem_1951 = native_batch_norm_backward_default_134[0]
        getitem_1952 = native_batch_norm_backward_default_134[1]
        getitem_1953 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_247 = torch.ops.aten.convolution_backward.default(getitem_1951, convolution_default_239, primals_1289, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1951 = convolution_default_239 = primals_1289 = None
        getitem_1954 = convolution_backward_default_247[0]
        getitem_1955 = convolution_backward_default_247[1];  convolution_backward_default_247 = None
        convolution_backward_default_248 = torch.ops.aten.convolution_backward.default(getitem_1954, relu__default_53, primals_1288, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1954 = primals_1288 = None
        getitem_1957 = convolution_backward_default_248[0]
        getitem_1958 = convolution_backward_default_248[1];  convolution_backward_default_248 = None
        to_dtype_405 = torch.ops.aten.to.dtype(getitem_1957, torch.float32);  getitem_1957 = None
        to_dtype_406 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_135 = torch.ops.aten.le.Scalar(to_dtype_406, 0);  to_dtype_406 = None
        new_zeros_default_399 = torch.ops.aten.new_zeros.default(to_dtype_405, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_135 = torch.ops.aten.where.self(le_scalar_135, new_zeros_default_399, to_dtype_405);  le_scalar_135 = new_zeros_default_399 = to_dtype_405 = None
        to_dtype_407 = torch.ops.aten.to.dtype(where_self_135, torch.float32);  where_self_135 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_407, convolution_default_238, primals_1280, primals_1278, primals_1279, getitem_397, getitem_398, True, 0.001, [True, True, True]);  to_dtype_407 = convolution_default_238 = primals_1280 = primals_1278 = primals_1279 = getitem_397 = getitem_398 = None
        getitem_1960 = native_batch_norm_backward_default_135[0]
        getitem_1961 = native_batch_norm_backward_default_135[1]
        getitem_1962 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_249 = torch.ops.aten.convolution_backward.default(getitem_1960, convolution_default_237, primals_1287, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1960 = convolution_default_237 = primals_1287 = None
        getitem_1963 = convolution_backward_default_249[0]
        getitem_1964 = convolution_backward_default_249[1];  convolution_backward_default_249 = None
        convolution_backward_default_250 = torch.ops.aten.convolution_backward.default(getitem_1963, relu_default_74, primals_1286, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1963 = primals_1286 = None
        getitem_1966 = convolution_backward_default_250[0]
        getitem_1967 = convolution_backward_default_250[1];  convolution_backward_default_250 = None
        to_dtype_408 = torch.ops.aten.to.dtype(getitem_1966, torch.float32);  getitem_1966 = None
        to_dtype_409 = torch.ops.aten.to.dtype(relu_default_74, torch.float32);  relu_default_74 = None
        le_scalar_136 = torch.ops.aten.le.Scalar(to_dtype_409, 0);  to_dtype_409 = None
        new_zeros_default_400 = torch.ops.aten.new_zeros.default(to_dtype_408, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_136 = torch.ops.aten.where.self(le_scalar_136, new_zeros_default_400, to_dtype_408);  le_scalar_136 = new_zeros_default_400 = to_dtype_408 = None
        to_dtype_410 = torch.ops.aten.to.dtype(where_self_136, torch.float32);  where_self_136 = None
        add_tensor_224 = torch.ops.aten.add.Tensor(add_tensor_222, to_dtype_410);  add_tensor_222 = to_dtype_410 = None
        clone_default_54 = torch.ops.aten.clone.default(slice_tensor_68, memory_format = torch.contiguous_format);  slice_tensor_68 = None
        native_batch_norm_backward_default_136 = torch.ops.aten.native_batch_norm_backward.default(clone_default_54, convolution_default_236, primals_1271, primals_1269, primals_1270, getitem_394, getitem_395, True, 0.001, [True, True, True]);  clone_default_54 = convolution_default_236 = primals_1271 = primals_1269 = primals_1270 = getitem_394 = getitem_395 = None
        getitem_1969 = native_batch_norm_backward_default_136[0]
        getitem_1970 = native_batch_norm_backward_default_136[1]
        getitem_1971 = native_batch_norm_backward_default_136[2];  native_batch_norm_backward_default_136 = None
        convolution_backward_default_251 = torch.ops.aten.convolution_backward.default(getitem_1969, convolution_default_235, primals_1275, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1969 = convolution_default_235 = primals_1275 = None
        getitem_1972 = convolution_backward_default_251[0]
        getitem_1973 = convolution_backward_default_251[1];  convolution_backward_default_251 = None
        convolution_backward_default_252 = torch.ops.aten.convolution_backward.default(getitem_1972, relu__default_52, primals_1274, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1972 = primals_1274 = None
        getitem_1975 = convolution_backward_default_252[0]
        getitem_1976 = convolution_backward_default_252[1];  convolution_backward_default_252 = None
        to_dtype_411 = torch.ops.aten.to.dtype(getitem_1975, torch.float32);  getitem_1975 = None
        to_dtype_412 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_137 = torch.ops.aten.le.Scalar(to_dtype_412, 0);  to_dtype_412 = None
        new_zeros_default_401 = torch.ops.aten.new_zeros.default(to_dtype_411, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_137 = torch.ops.aten.where.self(le_scalar_137, new_zeros_default_401, to_dtype_411);  le_scalar_137 = new_zeros_default_401 = to_dtype_411 = None
        to_dtype_413 = torch.ops.aten.to.dtype(where_self_137, torch.float32);  where_self_137 = None
        native_batch_norm_backward_default_137 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_413, convolution_default_234, primals_1266, primals_1264, primals_1265, getitem_391, getitem_392, True, 0.001, [True, True, True]);  to_dtype_413 = convolution_default_234 = primals_1266 = primals_1264 = primals_1265 = getitem_391 = getitem_392 = None
        getitem_1978 = native_batch_norm_backward_default_137[0]
        getitem_1979 = native_batch_norm_backward_default_137[1]
        getitem_1980 = native_batch_norm_backward_default_137[2];  native_batch_norm_backward_default_137 = None
        convolution_backward_default_253 = torch.ops.aten.convolution_backward.default(getitem_1978, convolution_default_233, primals_1273, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1978 = convolution_default_233 = primals_1273 = None
        getitem_1981 = convolution_backward_default_253[0]
        getitem_1982 = convolution_backward_default_253[1];  convolution_backward_default_253 = None
        convolution_backward_default_254 = torch.ops.aten.convolution_backward.default(getitem_1981, relu_default_73, primals_1272, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1981 = primals_1272 = None
        getitem_1984 = convolution_backward_default_254[0]
        getitem_1985 = convolution_backward_default_254[1];  convolution_backward_default_254 = None
        to_dtype_414 = torch.ops.aten.to.dtype(getitem_1984, torch.float32);  getitem_1984 = None
        to_dtype_415 = torch.ops.aten.to.dtype(relu_default_73, torch.float32);  relu_default_73 = None
        le_scalar_138 = torch.ops.aten.le.Scalar(to_dtype_415, 0);  to_dtype_415 = None
        new_zeros_default_402 = torch.ops.aten.new_zeros.default(to_dtype_414, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_138 = torch.ops.aten.where.self(le_scalar_138, new_zeros_default_402, to_dtype_414);  le_scalar_138 = new_zeros_default_402 = to_dtype_414 = None
        to_dtype_416 = torch.ops.aten.to.dtype(where_self_138, torch.float32);  where_self_138 = None
        add_tensor_225 = torch.ops.aten.add.Tensor(add_tensor_224, to_dtype_416);  add_tensor_224 = to_dtype_416 = None
        clone_default_55 = torch.ops.aten.clone.default(slice_tensor_67, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_138 = torch.ops.aten.native_batch_norm_backward.default(clone_default_55, convolution_default_232, primals_1257, primals_1255, primals_1256, getitem_388, getitem_389, True, 0.001, [True, True, True]);  clone_default_55 = convolution_default_232 = primals_1257 = primals_1255 = primals_1256 = getitem_388 = getitem_389 = None
        getitem_1987 = native_batch_norm_backward_default_138[0]
        getitem_1988 = native_batch_norm_backward_default_138[1]
        getitem_1989 = native_batch_norm_backward_default_138[2];  native_batch_norm_backward_default_138 = None
        convolution_backward_default_255 = torch.ops.aten.convolution_backward.default(getitem_1987, convolution_default_231, primals_1261, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1987 = convolution_default_231 = primals_1261 = None
        getitem_1990 = convolution_backward_default_255[0]
        getitem_1991 = convolution_backward_default_255[1];  convolution_backward_default_255 = None
        convolution_backward_default_256 = torch.ops.aten.convolution_backward.default(getitem_1990, relu__default_51, primals_1260, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1990 = primals_1260 = None
        getitem_1993 = convolution_backward_default_256[0]
        getitem_1994 = convolution_backward_default_256[1];  convolution_backward_default_256 = None
        to_dtype_417 = torch.ops.aten.to.dtype(getitem_1993, torch.float32);  getitem_1993 = None
        to_dtype_418 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_139 = torch.ops.aten.le.Scalar(to_dtype_418, 0);  to_dtype_418 = None
        new_zeros_default_403 = torch.ops.aten.new_zeros.default(to_dtype_417, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_139 = torch.ops.aten.where.self(le_scalar_139, new_zeros_default_403, to_dtype_417);  le_scalar_139 = new_zeros_default_403 = to_dtype_417 = None
        to_dtype_419 = torch.ops.aten.to.dtype(where_self_139, torch.float32);  where_self_139 = None
        native_batch_norm_backward_default_139 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_419, convolution_default_230, primals_1252, primals_1250, primals_1251, getitem_385, getitem_386, True, 0.001, [True, True, True]);  to_dtype_419 = convolution_default_230 = primals_1252 = primals_1250 = primals_1251 = getitem_385 = getitem_386 = None
        getitem_1996 = native_batch_norm_backward_default_139[0]
        getitem_1997 = native_batch_norm_backward_default_139[1]
        getitem_1998 = native_batch_norm_backward_default_139[2];  native_batch_norm_backward_default_139 = None
        convolution_backward_default_257 = torch.ops.aten.convolution_backward.default(getitem_1996, convolution_default_229, primals_1259, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1996 = convolution_default_229 = primals_1259 = None
        getitem_1999 = convolution_backward_default_257[0]
        getitem_2000 = convolution_backward_default_257[1];  convolution_backward_default_257 = None
        convolution_backward_default_258 = torch.ops.aten.convolution_backward.default(getitem_1999, relu_default_72, primals_1258, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_1999 = primals_1258 = None
        getitem_2002 = convolution_backward_default_258[0]
        getitem_2003 = convolution_backward_default_258[1];  convolution_backward_default_258 = None
        to_dtype_420 = torch.ops.aten.to.dtype(getitem_2002, torch.float32);  getitem_2002 = None
        to_dtype_421 = torch.ops.aten.to.dtype(relu_default_72, torch.float32);  relu_default_72 = None
        le_scalar_140 = torch.ops.aten.le.Scalar(to_dtype_421, 0);  to_dtype_421 = None
        new_zeros_default_404 = torch.ops.aten.new_zeros.default(to_dtype_420, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_140 = torch.ops.aten.where.self(le_scalar_140, new_zeros_default_404, to_dtype_420);  le_scalar_140 = new_zeros_default_404 = to_dtype_420 = None
        to_dtype_422 = torch.ops.aten.to.dtype(where_self_140, torch.float32);  where_self_140 = None
        add_tensor_226 = torch.ops.aten.add.Tensor(add_tensor_225, to_dtype_422);  add_tensor_225 = to_dtype_422 = None
        clone_default_56 = torch.ops.aten.clone.default(slice_tensor_67, memory_format = torch.contiguous_format);  slice_tensor_67 = None
        native_batch_norm_backward_default_140 = torch.ops.aten.native_batch_norm_backward.default(clone_default_56, convolution_default_228, primals_1243, primals_1241, primals_1242, getitem_382, getitem_383, True, 0.001, [True, True, True]);  clone_default_56 = convolution_default_228 = primals_1243 = primals_1241 = primals_1242 = getitem_382 = getitem_383 = None
        getitem_2005 = native_batch_norm_backward_default_140[0]
        getitem_2006 = native_batch_norm_backward_default_140[1]
        getitem_2007 = native_batch_norm_backward_default_140[2];  native_batch_norm_backward_default_140 = None
        convolution_backward_default_259 = torch.ops.aten.convolution_backward.default(getitem_2005, convolution_default_227, primals_1247, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2005 = convolution_default_227 = primals_1247 = None
        getitem_2008 = convolution_backward_default_259[0]
        getitem_2009 = convolution_backward_default_259[1];  convolution_backward_default_259 = None
        convolution_backward_default_260 = torch.ops.aten.convolution_backward.default(getitem_2008, relu__default_50, primals_1246, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2008 = primals_1246 = None
        getitem_2011 = convolution_backward_default_260[0]
        getitem_2012 = convolution_backward_default_260[1];  convolution_backward_default_260 = None
        to_dtype_423 = torch.ops.aten.to.dtype(getitem_2011, torch.float32);  getitem_2011 = None
        to_dtype_424 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_141 = torch.ops.aten.le.Scalar(to_dtype_424, 0);  to_dtype_424 = None
        new_zeros_default_405 = torch.ops.aten.new_zeros.default(to_dtype_423, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_141 = torch.ops.aten.where.self(le_scalar_141, new_zeros_default_405, to_dtype_423);  le_scalar_141 = new_zeros_default_405 = to_dtype_423 = None
        to_dtype_425 = torch.ops.aten.to.dtype(where_self_141, torch.float32);  where_self_141 = None
        native_batch_norm_backward_default_141 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_425, convolution_default_226, primals_1238, primals_1236, primals_1237, getitem_379, getitem_380, True, 0.001, [True, True, True]);  to_dtype_425 = convolution_default_226 = primals_1238 = primals_1236 = primals_1237 = getitem_379 = getitem_380 = None
        getitem_2014 = native_batch_norm_backward_default_141[0]
        getitem_2015 = native_batch_norm_backward_default_141[1]
        getitem_2016 = native_batch_norm_backward_default_141[2];  native_batch_norm_backward_default_141 = None
        convolution_backward_default_261 = torch.ops.aten.convolution_backward.default(getitem_2014, convolution_default_225, primals_1245, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2014 = convolution_default_225 = primals_1245 = None
        getitem_2017 = convolution_backward_default_261[0]
        getitem_2018 = convolution_backward_default_261[1];  convolution_backward_default_261 = None
        convolution_backward_default_262 = torch.ops.aten.convolution_backward.default(getitem_2017, relu_default_71, primals_1244, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2017 = primals_1244 = None
        getitem_2020 = convolution_backward_default_262[0]
        getitem_2021 = convolution_backward_default_262[1];  convolution_backward_default_262 = None
        to_dtype_426 = torch.ops.aten.to.dtype(getitem_2020, torch.float32);  getitem_2020 = None
        to_dtype_427 = torch.ops.aten.to.dtype(relu_default_71, torch.float32);  relu_default_71 = None
        le_scalar_142 = torch.ops.aten.le.Scalar(to_dtype_427, 0);  to_dtype_427 = None
        new_zeros_default_406 = torch.ops.aten.new_zeros.default(to_dtype_426, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_142 = torch.ops.aten.where.self(le_scalar_142, new_zeros_default_406, to_dtype_426);  le_scalar_142 = new_zeros_default_406 = to_dtype_426 = None
        to_dtype_428 = torch.ops.aten.to.dtype(where_self_142, torch.float32);  where_self_142 = None
        add_tensor_227 = torch.ops.aten.add.Tensor(add_tensor_223, to_dtype_428);  add_tensor_223 = to_dtype_428 = None
        native_batch_norm_backward_default_142 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_227, convolution_default_224, primals_1308, primals_1306, primals_1307, getitem_376, getitem_377, True, 0.001, [True, True, True]);  add_tensor_227 = convolution_default_224 = primals_1308 = primals_1306 = primals_1307 = getitem_376 = getitem_377 = None
        getitem_2023 = native_batch_norm_backward_default_142[0]
        getitem_2024 = native_batch_norm_backward_default_142[1]
        getitem_2025 = native_batch_norm_backward_default_142[2];  native_batch_norm_backward_default_142 = None
        convolution_backward_default_263 = torch.ops.aten.convolution_backward.default(getitem_2023, relu_default_70, primals_1309, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2023 = primals_1309 = None
        getitem_2026 = convolution_backward_default_263[0]
        getitem_2027 = convolution_backward_default_263[1];  convolution_backward_default_263 = None
        to_dtype_429 = torch.ops.aten.to.dtype(getitem_2026, torch.float32);  getitem_2026 = None
        to_dtype_430 = torch.ops.aten.to.dtype(relu_default_70, torch.float32);  relu_default_70 = None
        le_scalar_143 = torch.ops.aten.le.Scalar(to_dtype_430, 0);  to_dtype_430 = None
        new_zeros_default_407 = torch.ops.aten.new_zeros.default(to_dtype_429, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_143 = torch.ops.aten.where.self(le_scalar_143, new_zeros_default_407, to_dtype_429);  le_scalar_143 = new_zeros_default_407 = to_dtype_429 = None
        to_dtype_431 = torch.ops.aten.to.dtype(where_self_143, torch.float32);  where_self_143 = None
        add_tensor_228 = torch.ops.aten.add.Tensor(to_dtype_398, to_dtype_431);  to_dtype_398 = to_dtype_431 = None
        native_batch_norm_backward_default_143 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_226, convolution_default_223, primals_1314, primals_1312, primals_1313, getitem_373, getitem_374, True, 0.001, [True, True, True]);  add_tensor_226 = convolution_default_223 = primals_1314 = primals_1312 = primals_1313 = getitem_373 = getitem_374 = None
        getitem_2029 = native_batch_norm_backward_default_143[0]
        getitem_2030 = native_batch_norm_backward_default_143[1]
        getitem_2031 = native_batch_norm_backward_default_143[2];  native_batch_norm_backward_default_143 = None
        convolution_backward_default_264 = torch.ops.aten.convolution_backward.default(getitem_2029, relu_default_69, primals_1315, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2029 = primals_1315 = None
        getitem_2032 = convolution_backward_default_264[0]
        getitem_2033 = convolution_backward_default_264[1];  convolution_backward_default_264 = None
        to_dtype_432 = torch.ops.aten.to.dtype(getitem_2032, torch.float32);  getitem_2032 = None
        to_dtype_433 = torch.ops.aten.to.dtype(relu_default_69, torch.float32);  relu_default_69 = None
        le_scalar_144 = torch.ops.aten.le.Scalar(to_dtype_433, 0);  to_dtype_433 = None
        new_zeros_default_408 = torch.ops.aten.new_zeros.default(to_dtype_432, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_144 = torch.ops.aten.where.self(le_scalar_144, new_zeros_default_408, to_dtype_432);  le_scalar_144 = new_zeros_default_408 = to_dtype_432 = None
        to_dtype_434 = torch.ops.aten.to.dtype(where_self_144, torch.float32);  where_self_144 = None
        slice_tensor_72 = torch.ops.aten.slice.Tensor(add_tensor_228, 1, 0, 336)
        slice_tensor_73 = torch.ops.aten.slice.Tensor(add_tensor_228, 1, 336, 672)
        slice_tensor_74 = torch.ops.aten.slice.Tensor(add_tensor_228, 1, 672, 1008)
        slice_tensor_75 = torch.ops.aten.slice.Tensor(add_tensor_228, 1, 1008, 1344)
        slice_tensor_76 = torch.ops.aten.slice.Tensor(add_tensor_228, 1, 1344, 1680)
        slice_tensor_77 = torch.ops.aten.slice.Tensor(add_tensor_228, 1, 1680, 2016);  add_tensor_228 = None
        clone_default_57 = torch.ops.aten.clone.default(slice_tensor_77, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_144 = torch.ops.aten.native_batch_norm_backward.default(clone_default_57, convolution_default_222, primals_1216, primals_1214, primals_1215, getitem_370, getitem_371, True, 0.001, [True, True, True]);  clone_default_57 = convolution_default_222 = primals_1216 = primals_1214 = primals_1215 = getitem_370 = getitem_371 = None
        getitem_2035 = native_batch_norm_backward_default_144[0]
        getitem_2036 = native_batch_norm_backward_default_144[1]
        getitem_2037 = native_batch_norm_backward_default_144[2];  native_batch_norm_backward_default_144 = None
        convolution_backward_default_265 = torch.ops.aten.convolution_backward.default(getitem_2035, convolution_default_221, primals_1220, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2035 = convolution_default_221 = primals_1220 = None
        getitem_2038 = convolution_backward_default_265[0]
        getitem_2039 = convolution_backward_default_265[1];  convolution_backward_default_265 = None
        convolution_backward_default_266 = torch.ops.aten.convolution_backward.default(getitem_2038, relu__default_49, primals_1219, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2038 = primals_1219 = None
        getitem_2041 = convolution_backward_default_266[0]
        getitem_2042 = convolution_backward_default_266[1];  convolution_backward_default_266 = None
        to_dtype_435 = torch.ops.aten.to.dtype(getitem_2041, torch.float32);  getitem_2041 = None
        to_dtype_436 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_145 = torch.ops.aten.le.Scalar(to_dtype_436, 0);  to_dtype_436 = None
        new_zeros_default_409 = torch.ops.aten.new_zeros.default(to_dtype_435, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_145 = torch.ops.aten.where.self(le_scalar_145, new_zeros_default_409, to_dtype_435);  le_scalar_145 = new_zeros_default_409 = to_dtype_435 = None
        to_dtype_437 = torch.ops.aten.to.dtype(where_self_145, torch.float32);  where_self_145 = None
        native_batch_norm_backward_default_145 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_220, primals_1211, primals_1209, primals_1210, getitem_367, getitem_368, True, 0.001, [True, True, True]);  to_dtype_437 = convolution_default_220 = primals_1211 = primals_1209 = primals_1210 = getitem_367 = getitem_368 = None
        getitem_2044 = native_batch_norm_backward_default_145[0]
        getitem_2045 = native_batch_norm_backward_default_145[1]
        getitem_2046 = native_batch_norm_backward_default_145[2];  native_batch_norm_backward_default_145 = None
        convolution_backward_default_267 = torch.ops.aten.convolution_backward.default(getitem_2044, convolution_default_219, primals_1218, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2044 = convolution_default_219 = primals_1218 = None
        getitem_2047 = convolution_backward_default_267[0]
        getitem_2048 = convolution_backward_default_267[1];  convolution_backward_default_267 = None
        convolution_backward_default_268 = torch.ops.aten.convolution_backward.default(getitem_2047, relu_default_68, primals_1217, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2047 = primals_1217 = None
        getitem_2050 = convolution_backward_default_268[0]
        getitem_2051 = convolution_backward_default_268[1];  convolution_backward_default_268 = None
        to_dtype_438 = torch.ops.aten.to.dtype(getitem_2050, torch.float32);  getitem_2050 = None
        to_dtype_439 = torch.ops.aten.to.dtype(relu_default_68, torch.float32);  relu_default_68 = None
        le_scalar_146 = torch.ops.aten.le.Scalar(to_dtype_439, 0);  to_dtype_439 = None
        new_zeros_default_410 = torch.ops.aten.new_zeros.default(to_dtype_438, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_146 = torch.ops.aten.where.self(le_scalar_146, new_zeros_default_410, to_dtype_438);  le_scalar_146 = new_zeros_default_410 = to_dtype_438 = None
        to_dtype_440 = torch.ops.aten.to.dtype(where_self_146, torch.float32);  where_self_146 = None
        add_tensor_229 = torch.ops.aten.add.Tensor(slice_tensor_77, to_dtype_440);  slice_tensor_77 = to_dtype_440 = None
        avg_pool2d_backward_default_37 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_76, getitem_336, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_230 = torch.ops.aten.add.Tensor(slice_tensor_72, avg_pool2d_backward_default_37);  slice_tensor_72 = avg_pool2d_backward_default_37 = None
        avg_pool2d_backward_default_38 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_76, getitem_336, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_76 = getitem_336 = None
        add_tensor_231 = torch.ops.aten.add.Tensor(add_tensor_230, avg_pool2d_backward_default_38);  add_tensor_230 = avg_pool2d_backward_default_38 = None
        add_tensor_232 = torch.ops.aten.add.Tensor(add_tensor_231, slice_tensor_75);  add_tensor_231 = None
        avg_pool2d_backward_default_39 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_75, getitem_339, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_75 = getitem_339 = None
        add_tensor_233 = torch.ops.aten.add.Tensor(add_tensor_229, avg_pool2d_backward_default_39);  add_tensor_229 = avg_pool2d_backward_default_39 = None
        clone_default_58 = torch.ops.aten.clone.default(slice_tensor_74, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_146 = torch.ops.aten.native_batch_norm_backward.default(clone_default_58, convolution_default_218, primals_1202, primals_1200, primals_1201, getitem_364, getitem_365, True, 0.001, [True, True, True]);  clone_default_58 = convolution_default_218 = primals_1202 = primals_1200 = primals_1201 = getitem_364 = getitem_365 = None
        getitem_2053 = native_batch_norm_backward_default_146[0]
        getitem_2054 = native_batch_norm_backward_default_146[1]
        getitem_2055 = native_batch_norm_backward_default_146[2];  native_batch_norm_backward_default_146 = None
        convolution_backward_default_269 = torch.ops.aten.convolution_backward.default(getitem_2053, convolution_default_217, primals_1206, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2053 = convolution_default_217 = primals_1206 = None
        getitem_2056 = convolution_backward_default_269[0]
        getitem_2057 = convolution_backward_default_269[1];  convolution_backward_default_269 = None
        convolution_backward_default_270 = torch.ops.aten.convolution_backward.default(getitem_2056, relu__default_48, primals_1205, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2056 = primals_1205 = None
        getitem_2059 = convolution_backward_default_270[0]
        getitem_2060 = convolution_backward_default_270[1];  convolution_backward_default_270 = None
        to_dtype_441 = torch.ops.aten.to.dtype(getitem_2059, torch.float32);  getitem_2059 = None
        to_dtype_442 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_147 = torch.ops.aten.le.Scalar(to_dtype_442, 0);  to_dtype_442 = None
        new_zeros_default_411 = torch.ops.aten.new_zeros.default(to_dtype_441, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_147 = torch.ops.aten.where.self(le_scalar_147, new_zeros_default_411, to_dtype_441);  le_scalar_147 = new_zeros_default_411 = to_dtype_441 = None
        to_dtype_443 = torch.ops.aten.to.dtype(where_self_147, torch.float32);  where_self_147 = None
        native_batch_norm_backward_default_147 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_443, convolution_default_216, primals_1197, primals_1195, primals_1196, getitem_361, getitem_362, True, 0.001, [True, True, True]);  to_dtype_443 = convolution_default_216 = primals_1197 = primals_1195 = primals_1196 = getitem_361 = getitem_362 = None
        getitem_2062 = native_batch_norm_backward_default_147[0]
        getitem_2063 = native_batch_norm_backward_default_147[1]
        getitem_2064 = native_batch_norm_backward_default_147[2];  native_batch_norm_backward_default_147 = None
        convolution_backward_default_271 = torch.ops.aten.convolution_backward.default(getitem_2062, convolution_default_215, primals_1204, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2062 = convolution_default_215 = primals_1204 = None
        getitem_2065 = convolution_backward_default_271[0]
        getitem_2066 = convolution_backward_default_271[1];  convolution_backward_default_271 = None
        convolution_backward_default_272 = torch.ops.aten.convolution_backward.default(getitem_2065, relu_default_67, primals_1203, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2065 = primals_1203 = None
        getitem_2068 = convolution_backward_default_272[0]
        getitem_2069 = convolution_backward_default_272[1];  convolution_backward_default_272 = None
        to_dtype_444 = torch.ops.aten.to.dtype(getitem_2068, torch.float32);  getitem_2068 = None
        to_dtype_445 = torch.ops.aten.to.dtype(relu_default_67, torch.float32);  relu_default_67 = None
        le_scalar_148 = torch.ops.aten.le.Scalar(to_dtype_445, 0);  to_dtype_445 = None
        new_zeros_default_412 = torch.ops.aten.new_zeros.default(to_dtype_444, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_148 = torch.ops.aten.where.self(le_scalar_148, new_zeros_default_412, to_dtype_444);  le_scalar_148 = new_zeros_default_412 = to_dtype_444 = None
        to_dtype_446 = torch.ops.aten.to.dtype(where_self_148, torch.float32);  where_self_148 = None
        add_tensor_234 = torch.ops.aten.add.Tensor(add_tensor_232, to_dtype_446);  add_tensor_232 = to_dtype_446 = None
        clone_default_59 = torch.ops.aten.clone.default(slice_tensor_74, memory_format = torch.contiguous_format);  slice_tensor_74 = None
        native_batch_norm_backward_default_148 = torch.ops.aten.native_batch_norm_backward.default(clone_default_59, convolution_default_214, primals_1188, primals_1186, primals_1187, getitem_358, getitem_359, True, 0.001, [True, True, True]);  clone_default_59 = convolution_default_214 = primals_1188 = primals_1186 = primals_1187 = getitem_358 = getitem_359 = None
        getitem_2071 = native_batch_norm_backward_default_148[0]
        getitem_2072 = native_batch_norm_backward_default_148[1]
        getitem_2073 = native_batch_norm_backward_default_148[2];  native_batch_norm_backward_default_148 = None
        convolution_backward_default_273 = torch.ops.aten.convolution_backward.default(getitem_2071, convolution_default_213, primals_1192, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2071 = convolution_default_213 = primals_1192 = None
        getitem_2074 = convolution_backward_default_273[0]
        getitem_2075 = convolution_backward_default_273[1];  convolution_backward_default_273 = None
        convolution_backward_default_274 = torch.ops.aten.convolution_backward.default(getitem_2074, relu__default_47, primals_1191, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2074 = primals_1191 = None
        getitem_2077 = convolution_backward_default_274[0]
        getitem_2078 = convolution_backward_default_274[1];  convolution_backward_default_274 = None
        to_dtype_447 = torch.ops.aten.to.dtype(getitem_2077, torch.float32);  getitem_2077 = None
        to_dtype_448 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_149 = torch.ops.aten.le.Scalar(to_dtype_448, 0);  to_dtype_448 = None
        new_zeros_default_413 = torch.ops.aten.new_zeros.default(to_dtype_447, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_149 = torch.ops.aten.where.self(le_scalar_149, new_zeros_default_413, to_dtype_447);  le_scalar_149 = new_zeros_default_413 = to_dtype_447 = None
        to_dtype_449 = torch.ops.aten.to.dtype(where_self_149, torch.float32);  where_self_149 = None
        native_batch_norm_backward_default_149 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_449, convolution_default_212, primals_1183, primals_1181, primals_1182, getitem_355, getitem_356, True, 0.001, [True, True, True]);  to_dtype_449 = convolution_default_212 = primals_1183 = primals_1181 = primals_1182 = getitem_355 = getitem_356 = None
        getitem_2080 = native_batch_norm_backward_default_149[0]
        getitem_2081 = native_batch_norm_backward_default_149[1]
        getitem_2082 = native_batch_norm_backward_default_149[2];  native_batch_norm_backward_default_149 = None
        convolution_backward_default_275 = torch.ops.aten.convolution_backward.default(getitem_2080, convolution_default_211, primals_1190, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2080 = convolution_default_211 = primals_1190 = None
        getitem_2083 = convolution_backward_default_275[0]
        getitem_2084 = convolution_backward_default_275[1];  convolution_backward_default_275 = None
        convolution_backward_default_276 = torch.ops.aten.convolution_backward.default(getitem_2083, relu_default_66, primals_1189, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2083 = primals_1189 = None
        getitem_2086 = convolution_backward_default_276[0]
        getitem_2087 = convolution_backward_default_276[1];  convolution_backward_default_276 = None
        to_dtype_450 = torch.ops.aten.to.dtype(getitem_2086, torch.float32);  getitem_2086 = None
        to_dtype_451 = torch.ops.aten.to.dtype(relu_default_66, torch.float32);  relu_default_66 = None
        le_scalar_150 = torch.ops.aten.le.Scalar(to_dtype_451, 0);  to_dtype_451 = None
        new_zeros_default_414 = torch.ops.aten.new_zeros.default(to_dtype_450, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_150 = torch.ops.aten.where.self(le_scalar_150, new_zeros_default_414, to_dtype_450);  le_scalar_150 = new_zeros_default_414 = to_dtype_450 = None
        to_dtype_452 = torch.ops.aten.to.dtype(where_self_150, torch.float32);  where_self_150 = None
        add_tensor_235 = torch.ops.aten.add.Tensor(add_tensor_234, to_dtype_452);  add_tensor_234 = to_dtype_452 = None
        clone_default_60 = torch.ops.aten.clone.default(slice_tensor_73, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_150 = torch.ops.aten.native_batch_norm_backward.default(clone_default_60, convolution_default_210, primals_1174, primals_1172, primals_1173, getitem_352, getitem_353, True, 0.001, [True, True, True]);  clone_default_60 = convolution_default_210 = primals_1174 = primals_1172 = primals_1173 = getitem_352 = getitem_353 = None
        getitem_2089 = native_batch_norm_backward_default_150[0]
        getitem_2090 = native_batch_norm_backward_default_150[1]
        getitem_2091 = native_batch_norm_backward_default_150[2];  native_batch_norm_backward_default_150 = None
        convolution_backward_default_277 = torch.ops.aten.convolution_backward.default(getitem_2089, convolution_default_209, primals_1178, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2089 = convolution_default_209 = primals_1178 = None
        getitem_2092 = convolution_backward_default_277[0]
        getitem_2093 = convolution_backward_default_277[1];  convolution_backward_default_277 = None
        convolution_backward_default_278 = torch.ops.aten.convolution_backward.default(getitem_2092, relu__default_46, primals_1177, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2092 = primals_1177 = None
        getitem_2095 = convolution_backward_default_278[0]
        getitem_2096 = convolution_backward_default_278[1];  convolution_backward_default_278 = None
        to_dtype_453 = torch.ops.aten.to.dtype(getitem_2095, torch.float32);  getitem_2095 = None
        to_dtype_454 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_151 = torch.ops.aten.le.Scalar(to_dtype_454, 0);  to_dtype_454 = None
        new_zeros_default_415 = torch.ops.aten.new_zeros.default(to_dtype_453, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_151 = torch.ops.aten.where.self(le_scalar_151, new_zeros_default_415, to_dtype_453);  le_scalar_151 = new_zeros_default_415 = to_dtype_453 = None
        to_dtype_455 = torch.ops.aten.to.dtype(where_self_151, torch.float32);  where_self_151 = None
        native_batch_norm_backward_default_151 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_455, convolution_default_208, primals_1169, primals_1167, primals_1168, getitem_349, getitem_350, True, 0.001, [True, True, True]);  to_dtype_455 = convolution_default_208 = primals_1169 = primals_1167 = primals_1168 = getitem_349 = getitem_350 = None
        getitem_2098 = native_batch_norm_backward_default_151[0]
        getitem_2099 = native_batch_norm_backward_default_151[1]
        getitem_2100 = native_batch_norm_backward_default_151[2];  native_batch_norm_backward_default_151 = None
        convolution_backward_default_279 = torch.ops.aten.convolution_backward.default(getitem_2098, convolution_default_207, primals_1176, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2098 = convolution_default_207 = primals_1176 = None
        getitem_2101 = convolution_backward_default_279[0]
        getitem_2102 = convolution_backward_default_279[1];  convolution_backward_default_279 = None
        convolution_backward_default_280 = torch.ops.aten.convolution_backward.default(getitem_2101, relu_default_65, primals_1175, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2101 = primals_1175 = None
        getitem_2104 = convolution_backward_default_280[0]
        getitem_2105 = convolution_backward_default_280[1];  convolution_backward_default_280 = None
        to_dtype_456 = torch.ops.aten.to.dtype(getitem_2104, torch.float32);  getitem_2104 = None
        to_dtype_457 = torch.ops.aten.to.dtype(relu_default_65, torch.float32);  relu_default_65 = None
        le_scalar_152 = torch.ops.aten.le.Scalar(to_dtype_457, 0);  to_dtype_457 = None
        new_zeros_default_416 = torch.ops.aten.new_zeros.default(to_dtype_456, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_152 = torch.ops.aten.where.self(le_scalar_152, new_zeros_default_416, to_dtype_456);  le_scalar_152 = new_zeros_default_416 = to_dtype_456 = None
        to_dtype_458 = torch.ops.aten.to.dtype(where_self_152, torch.float32);  where_self_152 = None
        add_tensor_236 = torch.ops.aten.add.Tensor(add_tensor_235, to_dtype_458);  add_tensor_235 = to_dtype_458 = None
        clone_default_61 = torch.ops.aten.clone.default(slice_tensor_73, memory_format = torch.contiguous_format);  slice_tensor_73 = None
        native_batch_norm_backward_default_152 = torch.ops.aten.native_batch_norm_backward.default(clone_default_61, convolution_default_206, primals_1160, primals_1158, primals_1159, getitem_346, getitem_347, True, 0.001, [True, True, True]);  clone_default_61 = convolution_default_206 = primals_1160 = primals_1158 = primals_1159 = getitem_346 = getitem_347 = None
        getitem_2107 = native_batch_norm_backward_default_152[0]
        getitem_2108 = native_batch_norm_backward_default_152[1]
        getitem_2109 = native_batch_norm_backward_default_152[2];  native_batch_norm_backward_default_152 = None
        convolution_backward_default_281 = torch.ops.aten.convolution_backward.default(getitem_2107, convolution_default_205, primals_1164, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2107 = convolution_default_205 = primals_1164 = None
        getitem_2110 = convolution_backward_default_281[0]
        getitem_2111 = convolution_backward_default_281[1];  convolution_backward_default_281 = None
        convolution_backward_default_282 = torch.ops.aten.convolution_backward.default(getitem_2110, relu__default_45, primals_1163, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2110 = primals_1163 = None
        getitem_2113 = convolution_backward_default_282[0]
        getitem_2114 = convolution_backward_default_282[1];  convolution_backward_default_282 = None
        to_dtype_459 = torch.ops.aten.to.dtype(getitem_2113, torch.float32);  getitem_2113 = None
        to_dtype_460 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_153 = torch.ops.aten.le.Scalar(to_dtype_460, 0);  to_dtype_460 = None
        new_zeros_default_417 = torch.ops.aten.new_zeros.default(to_dtype_459, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_153 = torch.ops.aten.where.self(le_scalar_153, new_zeros_default_417, to_dtype_459);  le_scalar_153 = new_zeros_default_417 = to_dtype_459 = None
        to_dtype_461 = torch.ops.aten.to.dtype(where_self_153, torch.float32);  where_self_153 = None
        native_batch_norm_backward_default_153 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_461, convolution_default_204, primals_1155, primals_1153, primals_1154, getitem_343, getitem_344, True, 0.001, [True, True, True]);  to_dtype_461 = convolution_default_204 = primals_1155 = primals_1153 = primals_1154 = getitem_343 = getitem_344 = None
        getitem_2116 = native_batch_norm_backward_default_153[0]
        getitem_2117 = native_batch_norm_backward_default_153[1]
        getitem_2118 = native_batch_norm_backward_default_153[2];  native_batch_norm_backward_default_153 = None
        convolution_backward_default_283 = torch.ops.aten.convolution_backward.default(getitem_2116, convolution_default_203, primals_1162, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2116 = convolution_default_203 = primals_1162 = None
        getitem_2119 = convolution_backward_default_283[0]
        getitem_2120 = convolution_backward_default_283[1];  convolution_backward_default_283 = None
        convolution_backward_default_284 = torch.ops.aten.convolution_backward.default(getitem_2119, relu_default_64, primals_1161, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2119 = primals_1161 = None
        getitem_2122 = convolution_backward_default_284[0]
        getitem_2123 = convolution_backward_default_284[1];  convolution_backward_default_284 = None
        to_dtype_462 = torch.ops.aten.to.dtype(getitem_2122, torch.float32);  getitem_2122 = None
        to_dtype_463 = torch.ops.aten.to.dtype(relu_default_64, torch.float32);  relu_default_64 = None
        le_scalar_154 = torch.ops.aten.le.Scalar(to_dtype_463, 0);  to_dtype_463 = None
        new_zeros_default_418 = torch.ops.aten.new_zeros.default(to_dtype_462, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_154 = torch.ops.aten.where.self(le_scalar_154, new_zeros_default_418, to_dtype_462);  le_scalar_154 = new_zeros_default_418 = to_dtype_462 = None
        to_dtype_464 = torch.ops.aten.to.dtype(where_self_154, torch.float32);  where_self_154 = None
        add_tensor_237 = torch.ops.aten.add.Tensor(add_tensor_233, to_dtype_464);  add_tensor_233 = to_dtype_464 = None
        native_batch_norm_backward_default_154 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_237, convolution_default_202, primals_1225, primals_1223, primals_1224, getitem_340, getitem_341, True, 0.001, [True, True, True]);  add_tensor_237 = convolution_default_202 = primals_1225 = primals_1223 = primals_1224 = getitem_340 = getitem_341 = None
        getitem_2125 = native_batch_norm_backward_default_154[0]
        getitem_2126 = native_batch_norm_backward_default_154[1]
        getitem_2127 = native_batch_norm_backward_default_154[2];  native_batch_norm_backward_default_154 = None
        convolution_backward_default_285 = torch.ops.aten.convolution_backward.default(getitem_2125, relu_default_63, primals_1226, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2125 = primals_1226 = None
        getitem_2128 = convolution_backward_default_285[0]
        getitem_2129 = convolution_backward_default_285[1];  convolution_backward_default_285 = None
        to_dtype_465 = torch.ops.aten.to.dtype(getitem_2128, torch.float32);  getitem_2128 = None
        to_dtype_466 = torch.ops.aten.to.dtype(relu_default_63, torch.float32);  relu_default_63 = None
        le_scalar_155 = torch.ops.aten.le.Scalar(to_dtype_466, 0);  to_dtype_466 = None
        new_zeros_default_419 = torch.ops.aten.new_zeros.default(to_dtype_465, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_155 = torch.ops.aten.where.self(le_scalar_155, new_zeros_default_419, to_dtype_465);  le_scalar_155 = new_zeros_default_419 = to_dtype_465 = None
        to_dtype_467 = torch.ops.aten.to.dtype(where_self_155, torch.float32);  where_self_155 = None
        add_tensor_238 = torch.ops.aten.add.Tensor(to_dtype_434, to_dtype_467);  to_dtype_434 = to_dtype_467 = None
        native_batch_norm_backward_default_155 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_236, cat_default_11, primals_1231, primals_1229, primals_1230, getitem_337, getitem_338, True, 0.001, [True, True, True]);  add_tensor_236 = cat_default_11 = primals_1231 = primals_1229 = primals_1230 = getitem_337 = getitem_338 = None
        getitem_2131 = native_batch_norm_backward_default_155[0]
        getitem_2132 = native_batch_norm_backward_default_155[1]
        getitem_2133 = native_batch_norm_backward_default_155[2];  native_batch_norm_backward_default_155 = None
        slice_tensor_78 = torch.ops.aten.slice.Tensor(getitem_2131, 1, 0, 168)
        slice_tensor_79 = torch.ops.aten.slice.Tensor(getitem_2131, 1, 168, 336);  getitem_2131 = None
        convolution_backward_default_286 = torch.ops.aten.convolution_backward.default(slice_tensor_79, avg_pool2d_default_29, primals_1233, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_79 = avg_pool2d_default_29 = primals_1233 = None
        getitem_2134 = convolution_backward_default_286[0]
        getitem_2135 = convolution_backward_default_286[1];  convolution_backward_default_286 = None
        avg_pool2d_backward_default_40 = torch.ops.aten.avg_pool2d_backward.default(getitem_2134, constant_pad_nd_default_23, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2134 = constant_pad_nd_default_23 = None
        constant_pad_nd_default_40 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_40, [1, -1, 1, -1]);  avg_pool2d_backward_default_40 = None
        convolution_backward_default_287 = torch.ops.aten.convolution_backward.default(slice_tensor_78, avg_pool2d_default_28, primals_1232, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_78 = avg_pool2d_default_28 = primals_1232 = None
        getitem_2137 = convolution_backward_default_287[0]
        getitem_2138 = convolution_backward_default_287[1];  convolution_backward_default_287 = None
        avg_pool2d_backward_default_41 = torch.ops.aten.avg_pool2d_backward.default(getitem_2137, relu_default_62, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2137 = None
        add_tensor_239 = torch.ops.aten.add.Tensor(constant_pad_nd_default_40, avg_pool2d_backward_default_41);  constant_pad_nd_default_40 = avg_pool2d_backward_default_41 = None
        to_dtype_468 = torch.ops.aten.to.dtype(add_tensor_239, torch.float32);  add_tensor_239 = None
        to_dtype_469 = torch.ops.aten.to.dtype(relu_default_62, torch.float32);  relu_default_62 = None
        le_scalar_156 = torch.ops.aten.le.Scalar(to_dtype_469, 0);  to_dtype_469 = None
        new_zeros_default_420 = torch.ops.aten.new_zeros.default(to_dtype_468, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_156 = torch.ops.aten.where.self(le_scalar_156, new_zeros_default_420, to_dtype_468);  le_scalar_156 = new_zeros_default_420 = to_dtype_468 = None
        to_dtype_470 = torch.ops.aten.to.dtype(where_self_156, torch.float32);  where_self_156 = None
        slice_tensor_80 = torch.ops.aten.slice.Tensor(add_tensor_238, 1, 0, 336)
        slice_tensor_81 = torch.ops.aten.slice.Tensor(add_tensor_238, 1, 336, 672)
        slice_tensor_82 = torch.ops.aten.slice.Tensor(add_tensor_238, 1, 672, 1008)
        slice_tensor_83 = torch.ops.aten.slice.Tensor(add_tensor_238, 1, 1008, 1344);  add_tensor_238 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_83, constant_pad_nd_default_22, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_335);  constant_pad_nd_default_22 = getitem_335 = None
        constant_pad_nd_default_41 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_2, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_2 = None
        clone_default_62 = torch.ops.aten.clone.default(slice_tensor_83, memory_format = torch.contiguous_format);  slice_tensor_83 = None
        native_batch_norm_backward_default_156 = torch.ops.aten.native_batch_norm_backward.default(clone_default_62, convolution_default_199, primals_1707, primals_1705, primals_1706, getitem_332, getitem_333, True, 0.001, [True, True, True]);  clone_default_62 = convolution_default_199 = primals_1707 = primals_1705 = primals_1706 = getitem_332 = getitem_333 = None
        getitem_2140 = native_batch_norm_backward_default_156[0]
        getitem_2141 = native_batch_norm_backward_default_156[1]
        getitem_2142 = native_batch_norm_backward_default_156[2];  native_batch_norm_backward_default_156 = None
        convolution_backward_default_288 = torch.ops.aten.convolution_backward.default(getitem_2140, convolution_default_198, primals_1711, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2140 = convolution_default_198 = primals_1711 = None
        getitem_2143 = convolution_backward_default_288[0]
        getitem_2144 = convolution_backward_default_288[1];  convolution_backward_default_288 = None
        convolution_backward_default_289 = torch.ops.aten.convolution_backward.default(getitem_2143, relu__default_44, primals_1710, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2143 = primals_1710 = None
        getitem_2146 = convolution_backward_default_289[0]
        getitem_2147 = convolution_backward_default_289[1];  convolution_backward_default_289 = None
        to_dtype_471 = torch.ops.aten.to.dtype(getitem_2146, torch.float32);  getitem_2146 = None
        to_dtype_472 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_157 = torch.ops.aten.le.Scalar(to_dtype_472, 0);  to_dtype_472 = None
        new_zeros_default_421 = torch.ops.aten.new_zeros.default(to_dtype_471, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_157 = torch.ops.aten.where.self(le_scalar_157, new_zeros_default_421, to_dtype_471);  le_scalar_157 = new_zeros_default_421 = to_dtype_471 = None
        to_dtype_473 = torch.ops.aten.to.dtype(where_self_157, torch.float32);  where_self_157 = None
        native_batch_norm_backward_default_157 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_473, convolution_default_197, primals_1702, primals_1700, primals_1701, getitem_329, getitem_330, True, 0.001, [True, True, True]);  to_dtype_473 = convolution_default_197 = primals_1702 = primals_1700 = primals_1701 = getitem_329 = getitem_330 = None
        getitem_2149 = native_batch_norm_backward_default_157[0]
        getitem_2150 = native_batch_norm_backward_default_157[1]
        getitem_2151 = native_batch_norm_backward_default_157[2];  native_batch_norm_backward_default_157 = None
        convolution_backward_default_290 = torch.ops.aten.convolution_backward.default(getitem_2149, convolution_default_196, primals_1709, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2149 = convolution_default_196 = primals_1709 = None
        getitem_2152 = convolution_backward_default_290[0]
        getitem_2153 = convolution_backward_default_290[1];  convolution_backward_default_290 = None
        convolution_backward_default_291 = torch.ops.aten.convolution_backward.default(getitem_2152, relu_default_61, primals_1708, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2152 = primals_1708 = None
        getitem_2155 = convolution_backward_default_291[0]
        getitem_2156 = convolution_backward_default_291[1];  convolution_backward_default_291 = None
        to_dtype_474 = torch.ops.aten.to.dtype(getitem_2155, torch.float32);  getitem_2155 = None
        to_dtype_475 = torch.ops.aten.to.dtype(relu_default_61, torch.float32);  relu_default_61 = None
        le_scalar_158 = torch.ops.aten.le.Scalar(to_dtype_475, 0);  to_dtype_475 = None
        new_zeros_default_422 = torch.ops.aten.new_zeros.default(to_dtype_474, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_158 = torch.ops.aten.where.self(le_scalar_158, new_zeros_default_422, to_dtype_474);  le_scalar_158 = new_zeros_default_422 = to_dtype_474 = None
        to_dtype_476 = torch.ops.aten.to.dtype(where_self_158, torch.float32);  where_self_158 = None
        add_tensor_240 = torch.ops.aten.add.Tensor(slice_tensor_80, slice_tensor_82);  slice_tensor_80 = None
        avg_pool2d_backward_default_42 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_82, add_tensor_41, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_82 = add_tensor_41 = None
        add_tensor_241 = torch.ops.aten.add.Tensor(to_dtype_476, avg_pool2d_backward_default_42);  to_dtype_476 = avg_pool2d_backward_default_42 = None
        clone_default_63 = torch.ops.aten.clone.default(slice_tensor_81, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_158 = torch.ops.aten.native_batch_norm_backward.default(clone_default_63, convolution_default_195, primals_1693, primals_1691, primals_1692, getitem_326, getitem_327, True, 0.001, [True, True, True]);  clone_default_63 = convolution_default_195 = primals_1693 = primals_1691 = primals_1692 = getitem_326 = getitem_327 = None
        getitem_2158 = native_batch_norm_backward_default_158[0]
        getitem_2159 = native_batch_norm_backward_default_158[1]
        getitem_2160 = native_batch_norm_backward_default_158[2];  native_batch_norm_backward_default_158 = None
        convolution_backward_default_292 = torch.ops.aten.convolution_backward.default(getitem_2158, convolution_default_194, primals_1697, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2158 = convolution_default_194 = primals_1697 = None
        getitem_2161 = convolution_backward_default_292[0]
        getitem_2162 = convolution_backward_default_292[1];  convolution_backward_default_292 = None
        convolution_backward_default_293 = torch.ops.aten.convolution_backward.default(getitem_2161, relu__default_43, primals_1696, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2161 = primals_1696 = None
        getitem_2164 = convolution_backward_default_293[0]
        getitem_2165 = convolution_backward_default_293[1];  convolution_backward_default_293 = None
        to_dtype_477 = torch.ops.aten.to.dtype(getitem_2164, torch.float32);  getitem_2164 = None
        to_dtype_478 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_159 = torch.ops.aten.le.Scalar(to_dtype_478, 0);  to_dtype_478 = None
        new_zeros_default_423 = torch.ops.aten.new_zeros.default(to_dtype_477, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_159 = torch.ops.aten.where.self(le_scalar_159, new_zeros_default_423, to_dtype_477);  le_scalar_159 = new_zeros_default_423 = to_dtype_477 = None
        to_dtype_479 = torch.ops.aten.to.dtype(where_self_159, torch.float32);  where_self_159 = None
        native_batch_norm_backward_default_159 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_479, convolution_default_193, primals_1688, primals_1686, primals_1687, getitem_323, getitem_324, True, 0.001, [True, True, True]);  to_dtype_479 = convolution_default_193 = primals_1688 = primals_1686 = primals_1687 = getitem_323 = getitem_324 = None
        getitem_2167 = native_batch_norm_backward_default_159[0]
        getitem_2168 = native_batch_norm_backward_default_159[1]
        getitem_2169 = native_batch_norm_backward_default_159[2];  native_batch_norm_backward_default_159 = None
        convolution_backward_default_294 = torch.ops.aten.convolution_backward.default(getitem_2167, convolution_default_192, primals_1695, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2167 = convolution_default_192 = primals_1695 = None
        getitem_2170 = convolution_backward_default_294[0]
        getitem_2171 = convolution_backward_default_294[1];  convolution_backward_default_294 = None
        convolution_backward_default_295 = torch.ops.aten.convolution_backward.default(getitem_2170, constant_pad_nd_default_21, primals_1694, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2170 = constant_pad_nd_default_21 = primals_1694 = None
        getitem_2173 = convolution_backward_default_295[0]
        getitem_2174 = convolution_backward_default_295[1];  convolution_backward_default_295 = None
        constant_pad_nd_default_42 = torch.ops.aten.constant_pad_nd.default(getitem_2173, [-1, -2, -1, -2]);  getitem_2173 = None
        to_dtype_480 = torch.ops.aten.to.dtype(constant_pad_nd_default_42, torch.float32);  constant_pad_nd_default_42 = None
        to_dtype_481 = torch.ops.aten.to.dtype(relu_default_60, torch.float32);  relu_default_60 = None
        le_scalar_160 = torch.ops.aten.le.Scalar(to_dtype_481, 0);  to_dtype_481 = None
        new_zeros_default_424 = torch.ops.aten.new_zeros.default(to_dtype_480, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_160 = torch.ops.aten.where.self(le_scalar_160, new_zeros_default_424, to_dtype_480);  le_scalar_160 = new_zeros_default_424 = to_dtype_480 = None
        to_dtype_482 = torch.ops.aten.to.dtype(where_self_160, torch.float32);  where_self_160 = None
        avg_pool2d_backward_default_43 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_81, constant_pad_nd_default_20, [3, 3], [2, 2], [0, 0], False, False, None);  slice_tensor_81 = constant_pad_nd_default_20 = None
        constant_pad_nd_default_43 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_43, [0, -1, 0, -1]);  avg_pool2d_backward_default_43 = None
        add_tensor_242 = torch.ops.aten.add.Tensor(constant_pad_nd_default_41, constant_pad_nd_default_43);  constant_pad_nd_default_41 = constant_pad_nd_default_43 = None
        native_batch_norm_backward_default_160 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_240, convolution_default_191, primals_1679, primals_1677, primals_1678, getitem_320, getitem_321, True, 0.001, [True, True, True]);  convolution_default_191 = primals_1679 = primals_1677 = primals_1678 = getitem_320 = getitem_321 = None
        getitem_2176 = native_batch_norm_backward_default_160[0]
        getitem_2177 = native_batch_norm_backward_default_160[1]
        getitem_2178 = native_batch_norm_backward_default_160[2];  native_batch_norm_backward_default_160 = None
        convolution_backward_default_296 = torch.ops.aten.convolution_backward.default(getitem_2176, convolution_default_190, primals_1683, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2176 = convolution_default_190 = primals_1683 = None
        getitem_2179 = convolution_backward_default_296[0]
        getitem_2180 = convolution_backward_default_296[1];  convolution_backward_default_296 = None
        convolution_backward_default_297 = torch.ops.aten.convolution_backward.default(getitem_2179, relu__default_42, primals_1682, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2179 = primals_1682 = None
        getitem_2182 = convolution_backward_default_297[0]
        getitem_2183 = convolution_backward_default_297[1];  convolution_backward_default_297 = None
        to_dtype_483 = torch.ops.aten.to.dtype(getitem_2182, torch.float32);  getitem_2182 = None
        to_dtype_484 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_161 = torch.ops.aten.le.Scalar(to_dtype_484, 0);  to_dtype_484 = None
        new_zeros_default_425 = torch.ops.aten.new_zeros.default(to_dtype_483, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_161 = torch.ops.aten.where.self(le_scalar_161, new_zeros_default_425, to_dtype_483);  le_scalar_161 = new_zeros_default_425 = to_dtype_483 = None
        to_dtype_485 = torch.ops.aten.to.dtype(where_self_161, torch.float32);  where_self_161 = None
        native_batch_norm_backward_default_161 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_485, convolution_default_189, primals_1674, primals_1672, primals_1673, getitem_317, getitem_318, True, 0.001, [True, True, True]);  to_dtype_485 = convolution_default_189 = primals_1674 = primals_1672 = primals_1673 = getitem_317 = getitem_318 = None
        getitem_2185 = native_batch_norm_backward_default_161[0]
        getitem_2186 = native_batch_norm_backward_default_161[1]
        getitem_2187 = native_batch_norm_backward_default_161[2];  native_batch_norm_backward_default_161 = None
        convolution_backward_default_298 = torch.ops.aten.convolution_backward.default(getitem_2185, convolution_default_188, primals_1681, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2185 = convolution_default_188 = primals_1681 = None
        getitem_2188 = convolution_backward_default_298[0]
        getitem_2189 = convolution_backward_default_298[1];  convolution_backward_default_298 = None
        convolution_backward_default_299 = torch.ops.aten.convolution_backward.default(getitem_2188, constant_pad_nd_default_19, primals_1680, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2188 = constant_pad_nd_default_19 = primals_1680 = None
        getitem_2191 = convolution_backward_default_299[0]
        getitem_2192 = convolution_backward_default_299[1];  convolution_backward_default_299 = None
        constant_pad_nd_default_44 = torch.ops.aten.constant_pad_nd.default(getitem_2191, [-2, -3, -2, -3]);  getitem_2191 = None
        to_dtype_486 = torch.ops.aten.to.dtype(constant_pad_nd_default_44, torch.float32);  constant_pad_nd_default_44 = None
        to_dtype_487 = torch.ops.aten.to.dtype(relu_default_59, torch.float32);  relu_default_59 = None
        le_scalar_162 = torch.ops.aten.le.Scalar(to_dtype_487, 0);  to_dtype_487 = None
        new_zeros_default_426 = torch.ops.aten.new_zeros.default(to_dtype_486, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_162 = torch.ops.aten.where.self(le_scalar_162, new_zeros_default_426, to_dtype_486);  le_scalar_162 = new_zeros_default_426 = to_dtype_486 = None
        to_dtype_488 = torch.ops.aten.to.dtype(where_self_162, torch.float32);  where_self_162 = None
        add_tensor_243 = torch.ops.aten.add.Tensor(to_dtype_482, to_dtype_488);  to_dtype_482 = to_dtype_488 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_240, constant_pad_nd_default_18, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_315);  add_tensor_240 = constant_pad_nd_default_18 = getitem_315 = None
        constant_pad_nd_default_45 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_3, [0, -1, 0, -1]);  max_pool2d_with_indices_backward_default_3 = None
        add_tensor_244 = torch.ops.aten.add.Tensor(add_tensor_242, constant_pad_nd_default_45);  add_tensor_242 = constant_pad_nd_default_45 = None
        native_batch_norm_backward_default_162 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_241, convolution_default_187, primals_1665, primals_1663, primals_1664, getitem_312, getitem_313, True, 0.001, [True, True, True]);  convolution_default_187 = primals_1665 = primals_1663 = primals_1664 = getitem_312 = getitem_313 = None
        getitem_2194 = native_batch_norm_backward_default_162[0]
        getitem_2195 = native_batch_norm_backward_default_162[1]
        getitem_2196 = native_batch_norm_backward_default_162[2];  native_batch_norm_backward_default_162 = None
        convolution_backward_default_300 = torch.ops.aten.convolution_backward.default(getitem_2194, convolution_default_186, primals_1669, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2194 = convolution_default_186 = primals_1669 = None
        getitem_2197 = convolution_backward_default_300[0]
        getitem_2198 = convolution_backward_default_300[1];  convolution_backward_default_300 = None
        convolution_backward_default_301 = torch.ops.aten.convolution_backward.default(getitem_2197, relu__default_41, primals_1668, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2197 = primals_1668 = None
        getitem_2200 = convolution_backward_default_301[0]
        getitem_2201 = convolution_backward_default_301[1];  convolution_backward_default_301 = None
        to_dtype_489 = torch.ops.aten.to.dtype(getitem_2200, torch.float32);  getitem_2200 = None
        to_dtype_490 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_163 = torch.ops.aten.le.Scalar(to_dtype_490, 0);  to_dtype_490 = None
        new_zeros_default_427 = torch.ops.aten.new_zeros.default(to_dtype_489, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_163 = torch.ops.aten.where.self(le_scalar_163, new_zeros_default_427, to_dtype_489);  le_scalar_163 = new_zeros_default_427 = to_dtype_489 = None
        to_dtype_491 = torch.ops.aten.to.dtype(where_self_163, torch.float32);  where_self_163 = None
        native_batch_norm_backward_default_163 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_491, convolution_default_185, primals_1660, primals_1658, primals_1659, getitem_309, getitem_310, True, 0.001, [True, True, True]);  to_dtype_491 = convolution_default_185 = primals_1660 = primals_1658 = primals_1659 = getitem_309 = getitem_310 = None
        getitem_2203 = native_batch_norm_backward_default_163[0]
        getitem_2204 = native_batch_norm_backward_default_163[1]
        getitem_2205 = native_batch_norm_backward_default_163[2];  native_batch_norm_backward_default_163 = None
        convolution_backward_default_302 = torch.ops.aten.convolution_backward.default(getitem_2203, convolution_default_184, primals_1667, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2203 = convolution_default_184 = primals_1667 = None
        getitem_2206 = convolution_backward_default_302[0]
        getitem_2207 = convolution_backward_default_302[1];  convolution_backward_default_302 = None
        convolution_backward_default_303 = torch.ops.aten.convolution_backward.default(getitem_2206, constant_pad_nd_default_17, primals_1666, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2206 = constant_pad_nd_default_17 = primals_1666 = None
        getitem_2209 = convolution_backward_default_303[0]
        getitem_2210 = convolution_backward_default_303[1];  convolution_backward_default_303 = None
        constant_pad_nd_default_46 = torch.ops.aten.constant_pad_nd.default(getitem_2209, [-2, -3, -2, -3]);  getitem_2209 = None
        to_dtype_492 = torch.ops.aten.to.dtype(constant_pad_nd_default_46, torch.float32);  constant_pad_nd_default_46 = None
        to_dtype_493 = torch.ops.aten.to.dtype(relu_default_58, torch.float32);  relu_default_58 = None
        le_scalar_164 = torch.ops.aten.le.Scalar(to_dtype_493, 0);  to_dtype_493 = None
        new_zeros_default_428 = torch.ops.aten.new_zeros.default(to_dtype_492, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_164 = torch.ops.aten.where.self(le_scalar_164, new_zeros_default_428, to_dtype_492);  le_scalar_164 = new_zeros_default_428 = to_dtype_492 = None
        to_dtype_494 = torch.ops.aten.to.dtype(where_self_164, torch.float32);  where_self_164 = None
        add_tensor_245 = torch.ops.aten.add.Tensor(add_tensor_243, to_dtype_494);  add_tensor_243 = to_dtype_494 = None
        native_batch_norm_backward_default_164 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_241, convolution_default_183, primals_1651, primals_1649, primals_1650, getitem_306, getitem_307, True, 0.001, [True, True, True]);  add_tensor_241 = convolution_default_183 = primals_1651 = primals_1649 = primals_1650 = getitem_306 = getitem_307 = None
        getitem_2212 = native_batch_norm_backward_default_164[0]
        getitem_2213 = native_batch_norm_backward_default_164[1]
        getitem_2214 = native_batch_norm_backward_default_164[2];  native_batch_norm_backward_default_164 = None
        convolution_backward_default_304 = torch.ops.aten.convolution_backward.default(getitem_2212, convolution_default_182, primals_1655, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2212 = convolution_default_182 = primals_1655 = None
        getitem_2215 = convolution_backward_default_304[0]
        getitem_2216 = convolution_backward_default_304[1];  convolution_backward_default_304 = None
        convolution_backward_default_305 = torch.ops.aten.convolution_backward.default(getitem_2215, relu__default_40, primals_1654, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2215 = primals_1654 = None
        getitem_2218 = convolution_backward_default_305[0]
        getitem_2219 = convolution_backward_default_305[1];  convolution_backward_default_305 = None
        to_dtype_495 = torch.ops.aten.to.dtype(getitem_2218, torch.float32);  getitem_2218 = None
        to_dtype_496 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_165 = torch.ops.aten.le.Scalar(to_dtype_496, 0);  to_dtype_496 = None
        new_zeros_default_429 = torch.ops.aten.new_zeros.default(to_dtype_495, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_165 = torch.ops.aten.where.self(le_scalar_165, new_zeros_default_429, to_dtype_495);  le_scalar_165 = new_zeros_default_429 = to_dtype_495 = None
        to_dtype_497 = torch.ops.aten.to.dtype(where_self_165, torch.float32);  where_self_165 = None
        native_batch_norm_backward_default_165 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_497, convolution_default_181, primals_1646, primals_1644, primals_1645, getitem_303, getitem_304, True, 0.001, [True, True, True]);  to_dtype_497 = convolution_default_181 = primals_1646 = primals_1644 = primals_1645 = getitem_303 = getitem_304 = None
        getitem_2221 = native_batch_norm_backward_default_165[0]
        getitem_2222 = native_batch_norm_backward_default_165[1]
        getitem_2223 = native_batch_norm_backward_default_165[2];  native_batch_norm_backward_default_165 = None
        convolution_backward_default_306 = torch.ops.aten.convolution_backward.default(getitem_2221, convolution_default_180, primals_1653, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2221 = convolution_default_180 = primals_1653 = None
        getitem_2224 = convolution_backward_default_306[0]
        getitem_2225 = convolution_backward_default_306[1];  convolution_backward_default_306 = None
        convolution_backward_default_307 = torch.ops.aten.convolution_backward.default(getitem_2224, constant_pad_nd_default_16, primals_1652, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_2224 = constant_pad_nd_default_16 = primals_1652 = None
        getitem_2227 = convolution_backward_default_307[0]
        getitem_2228 = convolution_backward_default_307[1];  convolution_backward_default_307 = None
        constant_pad_nd_default_47 = torch.ops.aten.constant_pad_nd.default(getitem_2227, [-1, -2, -1, -2]);  getitem_2227 = None
        to_dtype_498 = torch.ops.aten.to.dtype(constant_pad_nd_default_47, torch.float32);  constant_pad_nd_default_47 = None
        to_dtype_499 = torch.ops.aten.to.dtype(relu_default_57, torch.float32);  relu_default_57 = None
        le_scalar_166 = torch.ops.aten.le.Scalar(to_dtype_499, 0);  to_dtype_499 = None
        new_zeros_default_430 = torch.ops.aten.new_zeros.default(to_dtype_498, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_166 = torch.ops.aten.where.self(le_scalar_166, new_zeros_default_430, to_dtype_498);  le_scalar_166 = new_zeros_default_430 = to_dtype_498 = None
        to_dtype_500 = torch.ops.aten.to.dtype(where_self_166, torch.float32);  where_self_166 = None
        add_tensor_246 = torch.ops.aten.add.Tensor(add_tensor_244, to_dtype_500);  add_tensor_244 = to_dtype_500 = None
        native_batch_norm_backward_default_166 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_246, convolution_default_179, primals_1716, primals_1714, primals_1715, getitem_300, getitem_301, True, 0.001, [True, True, True]);  add_tensor_246 = convolution_default_179 = primals_1716 = primals_1714 = primals_1715 = getitem_300 = getitem_301 = None
        getitem_2230 = native_batch_norm_backward_default_166[0]
        getitem_2231 = native_batch_norm_backward_default_166[1]
        getitem_2232 = native_batch_norm_backward_default_166[2];  native_batch_norm_backward_default_166 = None
        convolution_backward_default_308 = torch.ops.aten.convolution_backward.default(getitem_2230, relu_default_56, primals_1717, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2230 = primals_1717 = None
        getitem_2233 = convolution_backward_default_308[0]
        getitem_2234 = convolution_backward_default_308[1];  convolution_backward_default_308 = None
        to_dtype_501 = torch.ops.aten.to.dtype(getitem_2233, torch.float32);  getitem_2233 = None
        to_dtype_502 = torch.ops.aten.to.dtype(relu_default_56, torch.float32);  relu_default_56 = None
        le_scalar_167 = torch.ops.aten.le.Scalar(to_dtype_502, 0);  to_dtype_502 = None
        new_zeros_default_431 = torch.ops.aten.new_zeros.default(to_dtype_501, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_167 = torch.ops.aten.where.self(le_scalar_167, new_zeros_default_431, to_dtype_501);  le_scalar_167 = new_zeros_default_431 = to_dtype_501 = None
        to_dtype_503 = torch.ops.aten.to.dtype(where_self_167, torch.float32);  where_self_167 = None
        native_batch_norm_backward_default_167 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_245, convolution_default_178, primals_1722, primals_1720, primals_1721, getitem_297, getitem_298, True, 0.001, [True, True, True]);  add_tensor_245 = convolution_default_178 = primals_1722 = primals_1720 = primals_1721 = getitem_297 = getitem_298 = None
        getitem_2236 = native_batch_norm_backward_default_167[0]
        getitem_2237 = native_batch_norm_backward_default_167[1]
        getitem_2238 = native_batch_norm_backward_default_167[2];  native_batch_norm_backward_default_167 = None
        convolution_backward_default_309 = torch.ops.aten.convolution_backward.default(getitem_2236, relu_default_55, primals_1723, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2236 = primals_1723 = None
        getitem_2239 = convolution_backward_default_309[0]
        getitem_2240 = convolution_backward_default_309[1];  convolution_backward_default_309 = None
        to_dtype_504 = torch.ops.aten.to.dtype(getitem_2239, torch.float32);  getitem_2239 = None
        to_dtype_505 = torch.ops.aten.to.dtype(relu_default_55, torch.float32);  relu_default_55 = None
        le_scalar_168 = torch.ops.aten.le.Scalar(to_dtype_505, 0);  to_dtype_505 = None
        new_zeros_default_432 = torch.ops.aten.new_zeros.default(to_dtype_504, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_168 = torch.ops.aten.where.self(le_scalar_168, new_zeros_default_432, to_dtype_504);  le_scalar_168 = new_zeros_default_432 = to_dtype_504 = None
        to_dtype_506 = torch.ops.aten.to.dtype(where_self_168, torch.float32);  where_self_168 = None
        add_tensor_247 = torch.ops.aten.add.Tensor(to_dtype_470, to_dtype_506);  to_dtype_470 = to_dtype_506 = None
        slice_tensor_84 = torch.ops.aten.slice.Tensor(to_dtype_503, 1, 0, 168)
        slice_tensor_85 = torch.ops.aten.slice.Tensor(to_dtype_503, 1, 168, 336)
        slice_tensor_86 = torch.ops.aten.slice.Tensor(to_dtype_503, 1, 336, 504)
        slice_tensor_87 = torch.ops.aten.slice.Tensor(to_dtype_503, 1, 504, 672)
        slice_tensor_88 = torch.ops.aten.slice.Tensor(to_dtype_503, 1, 672, 840)
        slice_tensor_89 = torch.ops.aten.slice.Tensor(to_dtype_503, 1, 840, 1008);  to_dtype_503 = None
        clone_default_64 = torch.ops.aten.clone.default(slice_tensor_89, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_168 = torch.ops.aten.native_batch_norm_backward.default(clone_default_64, convolution_default_177, primals_1134, primals_1132, primals_1133, getitem_294, getitem_295, True, 0.001, [True, True, True]);  clone_default_64 = convolution_default_177 = primals_1134 = primals_1132 = primals_1133 = getitem_294 = getitem_295 = None
        getitem_2242 = native_batch_norm_backward_default_168[0]
        getitem_2243 = native_batch_norm_backward_default_168[1]
        getitem_2244 = native_batch_norm_backward_default_168[2];  native_batch_norm_backward_default_168 = None
        convolution_backward_default_310 = torch.ops.aten.convolution_backward.default(getitem_2242, convolution_default_176, primals_1138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2242 = convolution_default_176 = primals_1138 = None
        getitem_2245 = convolution_backward_default_310[0]
        getitem_2246 = convolution_backward_default_310[1];  convolution_backward_default_310 = None
        convolution_backward_default_311 = torch.ops.aten.convolution_backward.default(getitem_2245, relu__default_39, primals_1137, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2245 = primals_1137 = None
        getitem_2248 = convolution_backward_default_311[0]
        getitem_2249 = convolution_backward_default_311[1];  convolution_backward_default_311 = None
        to_dtype_507 = torch.ops.aten.to.dtype(getitem_2248, torch.float32);  getitem_2248 = None
        to_dtype_508 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_169 = torch.ops.aten.le.Scalar(to_dtype_508, 0);  to_dtype_508 = None
        new_zeros_default_433 = torch.ops.aten.new_zeros.default(to_dtype_507, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_169 = torch.ops.aten.where.self(le_scalar_169, new_zeros_default_433, to_dtype_507);  le_scalar_169 = new_zeros_default_433 = to_dtype_507 = None
        to_dtype_509 = torch.ops.aten.to.dtype(where_self_169, torch.float32);  where_self_169 = None
        native_batch_norm_backward_default_169 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_509, convolution_default_175, primals_1129, primals_1127, primals_1128, getitem_291, getitem_292, True, 0.001, [True, True, True]);  to_dtype_509 = convolution_default_175 = primals_1129 = primals_1127 = primals_1128 = getitem_291 = getitem_292 = None
        getitem_2251 = native_batch_norm_backward_default_169[0]
        getitem_2252 = native_batch_norm_backward_default_169[1]
        getitem_2253 = native_batch_norm_backward_default_169[2];  native_batch_norm_backward_default_169 = None
        convolution_backward_default_312 = torch.ops.aten.convolution_backward.default(getitem_2251, convolution_default_174, primals_1136, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2251 = convolution_default_174 = primals_1136 = None
        getitem_2254 = convolution_backward_default_312[0]
        getitem_2255 = convolution_backward_default_312[1];  convolution_backward_default_312 = None
        convolution_backward_default_313 = torch.ops.aten.convolution_backward.default(getitem_2254, relu_default_54, primals_1135, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2254 = primals_1135 = None
        getitem_2257 = convolution_backward_default_313[0]
        getitem_2258 = convolution_backward_default_313[1];  convolution_backward_default_313 = None
        to_dtype_510 = torch.ops.aten.to.dtype(getitem_2257, torch.float32);  getitem_2257 = None
        to_dtype_511 = torch.ops.aten.to.dtype(relu_default_54, torch.float32);  relu_default_54 = None
        le_scalar_170 = torch.ops.aten.le.Scalar(to_dtype_511, 0);  to_dtype_511 = None
        new_zeros_default_434 = torch.ops.aten.new_zeros.default(to_dtype_510, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_170 = torch.ops.aten.where.self(le_scalar_170, new_zeros_default_434, to_dtype_510);  le_scalar_170 = new_zeros_default_434 = to_dtype_510 = None
        to_dtype_512 = torch.ops.aten.to.dtype(where_self_170, torch.float32);  where_self_170 = None
        add_tensor_248 = torch.ops.aten.add.Tensor(slice_tensor_89, to_dtype_512);  slice_tensor_89 = to_dtype_512 = None
        avg_pool2d_backward_default_44 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_88, getitem_260, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_249 = torch.ops.aten.add.Tensor(slice_tensor_84, avg_pool2d_backward_default_44);  slice_tensor_84 = avg_pool2d_backward_default_44 = None
        avg_pool2d_backward_default_45 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_88, getitem_260, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_88 = getitem_260 = None
        add_tensor_250 = torch.ops.aten.add.Tensor(add_tensor_249, avg_pool2d_backward_default_45);  add_tensor_249 = avg_pool2d_backward_default_45 = None
        add_tensor_251 = torch.ops.aten.add.Tensor(add_tensor_250, slice_tensor_87);  add_tensor_250 = None
        avg_pool2d_backward_default_46 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_87, getitem_263, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_87 = getitem_263 = None
        add_tensor_252 = torch.ops.aten.add.Tensor(add_tensor_248, avg_pool2d_backward_default_46);  add_tensor_248 = avg_pool2d_backward_default_46 = None
        clone_default_65 = torch.ops.aten.clone.default(slice_tensor_86, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_170 = torch.ops.aten.native_batch_norm_backward.default(clone_default_65, convolution_default_173, primals_1120, primals_1118, primals_1119, getitem_288, getitem_289, True, 0.001, [True, True, True]);  clone_default_65 = convolution_default_173 = primals_1120 = primals_1118 = primals_1119 = getitem_288 = getitem_289 = None
        getitem_2260 = native_batch_norm_backward_default_170[0]
        getitem_2261 = native_batch_norm_backward_default_170[1]
        getitem_2262 = native_batch_norm_backward_default_170[2];  native_batch_norm_backward_default_170 = None
        convolution_backward_default_314 = torch.ops.aten.convolution_backward.default(getitem_2260, convolution_default_172, primals_1124, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2260 = convolution_default_172 = primals_1124 = None
        getitem_2263 = convolution_backward_default_314[0]
        getitem_2264 = convolution_backward_default_314[1];  convolution_backward_default_314 = None
        convolution_backward_default_315 = torch.ops.aten.convolution_backward.default(getitem_2263, relu__default_38, primals_1123, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2263 = primals_1123 = None
        getitem_2266 = convolution_backward_default_315[0]
        getitem_2267 = convolution_backward_default_315[1];  convolution_backward_default_315 = None
        to_dtype_513 = torch.ops.aten.to.dtype(getitem_2266, torch.float32);  getitem_2266 = None
        to_dtype_514 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_171 = torch.ops.aten.le.Scalar(to_dtype_514, 0);  to_dtype_514 = None
        new_zeros_default_435 = torch.ops.aten.new_zeros.default(to_dtype_513, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_171 = torch.ops.aten.where.self(le_scalar_171, new_zeros_default_435, to_dtype_513);  le_scalar_171 = new_zeros_default_435 = to_dtype_513 = None
        to_dtype_515 = torch.ops.aten.to.dtype(where_self_171, torch.float32);  where_self_171 = None
        native_batch_norm_backward_default_171 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_515, convolution_default_171, primals_1115, primals_1113, primals_1114, getitem_285, getitem_286, True, 0.001, [True, True, True]);  to_dtype_515 = convolution_default_171 = primals_1115 = primals_1113 = primals_1114 = getitem_285 = getitem_286 = None
        getitem_2269 = native_batch_norm_backward_default_171[0]
        getitem_2270 = native_batch_norm_backward_default_171[1]
        getitem_2271 = native_batch_norm_backward_default_171[2];  native_batch_norm_backward_default_171 = None
        convolution_backward_default_316 = torch.ops.aten.convolution_backward.default(getitem_2269, convolution_default_170, primals_1122, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2269 = convolution_default_170 = primals_1122 = None
        getitem_2272 = convolution_backward_default_316[0]
        getitem_2273 = convolution_backward_default_316[1];  convolution_backward_default_316 = None
        convolution_backward_default_317 = torch.ops.aten.convolution_backward.default(getitem_2272, relu_default_53, primals_1121, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2272 = primals_1121 = None
        getitem_2275 = convolution_backward_default_317[0]
        getitem_2276 = convolution_backward_default_317[1];  convolution_backward_default_317 = None
        to_dtype_516 = torch.ops.aten.to.dtype(getitem_2275, torch.float32);  getitem_2275 = None
        to_dtype_517 = torch.ops.aten.to.dtype(relu_default_53, torch.float32);  relu_default_53 = None
        le_scalar_172 = torch.ops.aten.le.Scalar(to_dtype_517, 0);  to_dtype_517 = None
        new_zeros_default_436 = torch.ops.aten.new_zeros.default(to_dtype_516, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_172 = torch.ops.aten.where.self(le_scalar_172, new_zeros_default_436, to_dtype_516);  le_scalar_172 = new_zeros_default_436 = to_dtype_516 = None
        to_dtype_518 = torch.ops.aten.to.dtype(where_self_172, torch.float32);  where_self_172 = None
        add_tensor_253 = torch.ops.aten.add.Tensor(add_tensor_251, to_dtype_518);  add_tensor_251 = to_dtype_518 = None
        clone_default_66 = torch.ops.aten.clone.default(slice_tensor_86, memory_format = torch.contiguous_format);  slice_tensor_86 = None
        native_batch_norm_backward_default_172 = torch.ops.aten.native_batch_norm_backward.default(clone_default_66, convolution_default_169, primals_1106, primals_1104, primals_1105, getitem_282, getitem_283, True, 0.001, [True, True, True]);  clone_default_66 = convolution_default_169 = primals_1106 = primals_1104 = primals_1105 = getitem_282 = getitem_283 = None
        getitem_2278 = native_batch_norm_backward_default_172[0]
        getitem_2279 = native_batch_norm_backward_default_172[1]
        getitem_2280 = native_batch_norm_backward_default_172[2];  native_batch_norm_backward_default_172 = None
        convolution_backward_default_318 = torch.ops.aten.convolution_backward.default(getitem_2278, convolution_default_168, primals_1110, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2278 = convolution_default_168 = primals_1110 = None
        getitem_2281 = convolution_backward_default_318[0]
        getitem_2282 = convolution_backward_default_318[1];  convolution_backward_default_318 = None
        convolution_backward_default_319 = torch.ops.aten.convolution_backward.default(getitem_2281, relu__default_37, primals_1109, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2281 = primals_1109 = None
        getitem_2284 = convolution_backward_default_319[0]
        getitem_2285 = convolution_backward_default_319[1];  convolution_backward_default_319 = None
        to_dtype_519 = torch.ops.aten.to.dtype(getitem_2284, torch.float32);  getitem_2284 = None
        to_dtype_520 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_173 = torch.ops.aten.le.Scalar(to_dtype_520, 0);  to_dtype_520 = None
        new_zeros_default_437 = torch.ops.aten.new_zeros.default(to_dtype_519, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_173 = torch.ops.aten.where.self(le_scalar_173, new_zeros_default_437, to_dtype_519);  le_scalar_173 = new_zeros_default_437 = to_dtype_519 = None
        to_dtype_521 = torch.ops.aten.to.dtype(where_self_173, torch.float32);  where_self_173 = None
        native_batch_norm_backward_default_173 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_521, convolution_default_167, primals_1101, primals_1099, primals_1100, getitem_279, getitem_280, True, 0.001, [True, True, True]);  to_dtype_521 = convolution_default_167 = primals_1101 = primals_1099 = primals_1100 = getitem_279 = getitem_280 = None
        getitem_2287 = native_batch_norm_backward_default_173[0]
        getitem_2288 = native_batch_norm_backward_default_173[1]
        getitem_2289 = native_batch_norm_backward_default_173[2];  native_batch_norm_backward_default_173 = None
        convolution_backward_default_320 = torch.ops.aten.convolution_backward.default(getitem_2287, convolution_default_166, primals_1108, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2287 = convolution_default_166 = primals_1108 = None
        getitem_2290 = convolution_backward_default_320[0]
        getitem_2291 = convolution_backward_default_320[1];  convolution_backward_default_320 = None
        convolution_backward_default_321 = torch.ops.aten.convolution_backward.default(getitem_2290, relu_default_52, primals_1107, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2290 = primals_1107 = None
        getitem_2293 = convolution_backward_default_321[0]
        getitem_2294 = convolution_backward_default_321[1];  convolution_backward_default_321 = None
        to_dtype_522 = torch.ops.aten.to.dtype(getitem_2293, torch.float32);  getitem_2293 = None
        to_dtype_523 = torch.ops.aten.to.dtype(relu_default_52, torch.float32);  relu_default_52 = None
        le_scalar_174 = torch.ops.aten.le.Scalar(to_dtype_523, 0);  to_dtype_523 = None
        new_zeros_default_438 = torch.ops.aten.new_zeros.default(to_dtype_522, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_174 = torch.ops.aten.where.self(le_scalar_174, new_zeros_default_438, to_dtype_522);  le_scalar_174 = new_zeros_default_438 = to_dtype_522 = None
        to_dtype_524 = torch.ops.aten.to.dtype(where_self_174, torch.float32);  where_self_174 = None
        add_tensor_254 = torch.ops.aten.add.Tensor(add_tensor_253, to_dtype_524);  add_tensor_253 = to_dtype_524 = None
        clone_default_67 = torch.ops.aten.clone.default(slice_tensor_85, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_174 = torch.ops.aten.native_batch_norm_backward.default(clone_default_67, convolution_default_165, primals_1092, primals_1090, primals_1091, getitem_276, getitem_277, True, 0.001, [True, True, True]);  clone_default_67 = convolution_default_165 = primals_1092 = primals_1090 = primals_1091 = getitem_276 = getitem_277 = None
        getitem_2296 = native_batch_norm_backward_default_174[0]
        getitem_2297 = native_batch_norm_backward_default_174[1]
        getitem_2298 = native_batch_norm_backward_default_174[2];  native_batch_norm_backward_default_174 = None
        convolution_backward_default_322 = torch.ops.aten.convolution_backward.default(getitem_2296, convolution_default_164, primals_1096, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2296 = convolution_default_164 = primals_1096 = None
        getitem_2299 = convolution_backward_default_322[0]
        getitem_2300 = convolution_backward_default_322[1];  convolution_backward_default_322 = None
        convolution_backward_default_323 = torch.ops.aten.convolution_backward.default(getitem_2299, relu__default_36, primals_1095, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2299 = primals_1095 = None
        getitem_2302 = convolution_backward_default_323[0]
        getitem_2303 = convolution_backward_default_323[1];  convolution_backward_default_323 = None
        to_dtype_525 = torch.ops.aten.to.dtype(getitem_2302, torch.float32);  getitem_2302 = None
        to_dtype_526 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_175 = torch.ops.aten.le.Scalar(to_dtype_526, 0);  to_dtype_526 = None
        new_zeros_default_439 = torch.ops.aten.new_zeros.default(to_dtype_525, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_175 = torch.ops.aten.where.self(le_scalar_175, new_zeros_default_439, to_dtype_525);  le_scalar_175 = new_zeros_default_439 = to_dtype_525 = None
        to_dtype_527 = torch.ops.aten.to.dtype(where_self_175, torch.float32);  where_self_175 = None
        native_batch_norm_backward_default_175 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_527, convolution_default_163, primals_1087, primals_1085, primals_1086, getitem_273, getitem_274, True, 0.001, [True, True, True]);  to_dtype_527 = convolution_default_163 = primals_1087 = primals_1085 = primals_1086 = getitem_273 = getitem_274 = None
        getitem_2305 = native_batch_norm_backward_default_175[0]
        getitem_2306 = native_batch_norm_backward_default_175[1]
        getitem_2307 = native_batch_norm_backward_default_175[2];  native_batch_norm_backward_default_175 = None
        convolution_backward_default_324 = torch.ops.aten.convolution_backward.default(getitem_2305, convolution_default_162, primals_1094, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2305 = convolution_default_162 = primals_1094 = None
        getitem_2308 = convolution_backward_default_324[0]
        getitem_2309 = convolution_backward_default_324[1];  convolution_backward_default_324 = None
        convolution_backward_default_325 = torch.ops.aten.convolution_backward.default(getitem_2308, relu_default_51, primals_1093, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2308 = primals_1093 = None
        getitem_2311 = convolution_backward_default_325[0]
        getitem_2312 = convolution_backward_default_325[1];  convolution_backward_default_325 = None
        to_dtype_528 = torch.ops.aten.to.dtype(getitem_2311, torch.float32);  getitem_2311 = None
        to_dtype_529 = torch.ops.aten.to.dtype(relu_default_51, torch.float32);  relu_default_51 = None
        le_scalar_176 = torch.ops.aten.le.Scalar(to_dtype_529, 0);  to_dtype_529 = None
        new_zeros_default_440 = torch.ops.aten.new_zeros.default(to_dtype_528, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_176 = torch.ops.aten.where.self(le_scalar_176, new_zeros_default_440, to_dtype_528);  le_scalar_176 = new_zeros_default_440 = to_dtype_528 = None
        to_dtype_530 = torch.ops.aten.to.dtype(where_self_176, torch.float32);  where_self_176 = None
        add_tensor_255 = torch.ops.aten.add.Tensor(add_tensor_254, to_dtype_530);  add_tensor_254 = to_dtype_530 = None
        clone_default_68 = torch.ops.aten.clone.default(slice_tensor_85, memory_format = torch.contiguous_format);  slice_tensor_85 = None
        native_batch_norm_backward_default_176 = torch.ops.aten.native_batch_norm_backward.default(clone_default_68, convolution_default_161, primals_1078, primals_1076, primals_1077, getitem_270, getitem_271, True, 0.001, [True, True, True]);  clone_default_68 = convolution_default_161 = primals_1078 = primals_1076 = primals_1077 = getitem_270 = getitem_271 = None
        getitem_2314 = native_batch_norm_backward_default_176[0]
        getitem_2315 = native_batch_norm_backward_default_176[1]
        getitem_2316 = native_batch_norm_backward_default_176[2];  native_batch_norm_backward_default_176 = None
        convolution_backward_default_326 = torch.ops.aten.convolution_backward.default(getitem_2314, convolution_default_160, primals_1082, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2314 = convolution_default_160 = primals_1082 = None
        getitem_2317 = convolution_backward_default_326[0]
        getitem_2318 = convolution_backward_default_326[1];  convolution_backward_default_326 = None
        convolution_backward_default_327 = torch.ops.aten.convolution_backward.default(getitem_2317, relu__default_35, primals_1081, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2317 = primals_1081 = None
        getitem_2320 = convolution_backward_default_327[0]
        getitem_2321 = convolution_backward_default_327[1];  convolution_backward_default_327 = None
        to_dtype_531 = torch.ops.aten.to.dtype(getitem_2320, torch.float32);  getitem_2320 = None
        to_dtype_532 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_177 = torch.ops.aten.le.Scalar(to_dtype_532, 0);  to_dtype_532 = None
        new_zeros_default_441 = torch.ops.aten.new_zeros.default(to_dtype_531, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_177 = torch.ops.aten.where.self(le_scalar_177, new_zeros_default_441, to_dtype_531);  le_scalar_177 = new_zeros_default_441 = to_dtype_531 = None
        to_dtype_533 = torch.ops.aten.to.dtype(where_self_177, torch.float32);  where_self_177 = None
        native_batch_norm_backward_default_177 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_533, convolution_default_159, primals_1073, primals_1071, primals_1072, getitem_267, getitem_268, True, 0.001, [True, True, True]);  to_dtype_533 = convolution_default_159 = primals_1073 = primals_1071 = primals_1072 = getitem_267 = getitem_268 = None
        getitem_2323 = native_batch_norm_backward_default_177[0]
        getitem_2324 = native_batch_norm_backward_default_177[1]
        getitem_2325 = native_batch_norm_backward_default_177[2];  native_batch_norm_backward_default_177 = None
        convolution_backward_default_328 = torch.ops.aten.convolution_backward.default(getitem_2323, convolution_default_158, primals_1080, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2323 = convolution_default_158 = primals_1080 = None
        getitem_2326 = convolution_backward_default_328[0]
        getitem_2327 = convolution_backward_default_328[1];  convolution_backward_default_328 = None
        convolution_backward_default_329 = torch.ops.aten.convolution_backward.default(getitem_2326, relu_default_50, primals_1079, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2326 = primals_1079 = None
        getitem_2329 = convolution_backward_default_329[0]
        getitem_2330 = convolution_backward_default_329[1];  convolution_backward_default_329 = None
        to_dtype_534 = torch.ops.aten.to.dtype(getitem_2329, torch.float32);  getitem_2329 = None
        to_dtype_535 = torch.ops.aten.to.dtype(relu_default_50, torch.float32);  relu_default_50 = None
        le_scalar_178 = torch.ops.aten.le.Scalar(to_dtype_535, 0);  to_dtype_535 = None
        new_zeros_default_442 = torch.ops.aten.new_zeros.default(to_dtype_534, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_178 = torch.ops.aten.where.self(le_scalar_178, new_zeros_default_442, to_dtype_534);  le_scalar_178 = new_zeros_default_442 = to_dtype_534 = None
        to_dtype_536 = torch.ops.aten.to.dtype(where_self_178, torch.float32);  where_self_178 = None
        add_tensor_256 = torch.ops.aten.add.Tensor(add_tensor_252, to_dtype_536);  add_tensor_252 = to_dtype_536 = None
        native_batch_norm_backward_default_178 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_256, convolution_default_157, primals_1143, primals_1141, primals_1142, getitem_264, getitem_265, True, 0.001, [True, True, True]);  add_tensor_256 = convolution_default_157 = primals_1143 = primals_1141 = primals_1142 = getitem_264 = getitem_265 = None
        getitem_2332 = native_batch_norm_backward_default_178[0]
        getitem_2333 = native_batch_norm_backward_default_178[1]
        getitem_2334 = native_batch_norm_backward_default_178[2];  native_batch_norm_backward_default_178 = None
        convolution_backward_default_330 = torch.ops.aten.convolution_backward.default(getitem_2332, relu_default_49, primals_1144, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2332 = primals_1144 = None
        getitem_2335 = convolution_backward_default_330[0]
        getitem_2336 = convolution_backward_default_330[1];  convolution_backward_default_330 = None
        to_dtype_537 = torch.ops.aten.to.dtype(getitem_2335, torch.float32);  getitem_2335 = None
        to_dtype_538 = torch.ops.aten.to.dtype(relu_default_49, torch.float32);  relu_default_49 = None
        le_scalar_179 = torch.ops.aten.le.Scalar(to_dtype_538, 0);  to_dtype_538 = None
        new_zeros_default_443 = torch.ops.aten.new_zeros.default(to_dtype_537, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_179 = torch.ops.aten.where.self(le_scalar_179, new_zeros_default_443, to_dtype_537);  le_scalar_179 = new_zeros_default_443 = to_dtype_537 = None
        to_dtype_539 = torch.ops.aten.to.dtype(where_self_179, torch.float32);  where_self_179 = None
        add_tensor_257 = torch.ops.aten.add.Tensor(add_tensor_247, to_dtype_539);  add_tensor_247 = to_dtype_539 = None
        native_batch_norm_backward_default_179 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_255, convolution_default_156, primals_1149, primals_1147, primals_1148, getitem_261, getitem_262, True, 0.001, [True, True, True]);  add_tensor_255 = convolution_default_156 = primals_1149 = primals_1147 = primals_1148 = getitem_261 = getitem_262 = None
        getitem_2338 = native_batch_norm_backward_default_179[0]
        getitem_2339 = native_batch_norm_backward_default_179[1]
        getitem_2340 = native_batch_norm_backward_default_179[2];  native_batch_norm_backward_default_179 = None
        convolution_backward_default_331 = torch.ops.aten.convolution_backward.default(getitem_2338, relu_default_48, primals_1150, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2338 = primals_1150 = None
        getitem_2341 = convolution_backward_default_331[0]
        getitem_2342 = convolution_backward_default_331[1];  convolution_backward_default_331 = None
        to_dtype_540 = torch.ops.aten.to.dtype(getitem_2341, torch.float32);  getitem_2341 = None
        to_dtype_541 = torch.ops.aten.to.dtype(relu_default_48, torch.float32);  relu_default_48 = None
        le_scalar_180 = torch.ops.aten.le.Scalar(to_dtype_541, 0);  to_dtype_541 = None
        new_zeros_default_444 = torch.ops.aten.new_zeros.default(to_dtype_540, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_180 = torch.ops.aten.where.self(le_scalar_180, new_zeros_default_444, to_dtype_540);  le_scalar_180 = new_zeros_default_444 = to_dtype_540 = None
        to_dtype_542 = torch.ops.aten.to.dtype(where_self_180, torch.float32);  where_self_180 = None
        slice_tensor_90 = torch.ops.aten.slice.Tensor(add_tensor_257, 1, 0, 168)
        slice_tensor_91 = torch.ops.aten.slice.Tensor(add_tensor_257, 1, 168, 336)
        slice_tensor_92 = torch.ops.aten.slice.Tensor(add_tensor_257, 1, 336, 504)
        slice_tensor_93 = torch.ops.aten.slice.Tensor(add_tensor_257, 1, 504, 672)
        slice_tensor_94 = torch.ops.aten.slice.Tensor(add_tensor_257, 1, 672, 840)
        slice_tensor_95 = torch.ops.aten.slice.Tensor(add_tensor_257, 1, 840, 1008);  add_tensor_257 = None
        clone_default_69 = torch.ops.aten.clone.default(slice_tensor_95, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_180 = torch.ops.aten.native_batch_norm_backward.default(clone_default_69, convolution_default_155, primals_1052, primals_1050, primals_1051, getitem_258, getitem_259, True, 0.001, [True, True, True]);  clone_default_69 = convolution_default_155 = primals_1052 = primals_1050 = primals_1051 = getitem_258 = getitem_259 = None
        getitem_2344 = native_batch_norm_backward_default_180[0]
        getitem_2345 = native_batch_norm_backward_default_180[1]
        getitem_2346 = native_batch_norm_backward_default_180[2];  native_batch_norm_backward_default_180 = None
        convolution_backward_default_332 = torch.ops.aten.convolution_backward.default(getitem_2344, convolution_default_154, primals_1056, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2344 = convolution_default_154 = primals_1056 = None
        getitem_2347 = convolution_backward_default_332[0]
        getitem_2348 = convolution_backward_default_332[1];  convolution_backward_default_332 = None
        convolution_backward_default_333 = torch.ops.aten.convolution_backward.default(getitem_2347, relu__default_34, primals_1055, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2347 = primals_1055 = None
        getitem_2350 = convolution_backward_default_333[0]
        getitem_2351 = convolution_backward_default_333[1];  convolution_backward_default_333 = None
        to_dtype_543 = torch.ops.aten.to.dtype(getitem_2350, torch.float32);  getitem_2350 = None
        to_dtype_544 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_181 = torch.ops.aten.le.Scalar(to_dtype_544, 0);  to_dtype_544 = None
        new_zeros_default_445 = torch.ops.aten.new_zeros.default(to_dtype_543, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_181 = torch.ops.aten.where.self(le_scalar_181, new_zeros_default_445, to_dtype_543);  le_scalar_181 = new_zeros_default_445 = to_dtype_543 = None
        to_dtype_545 = torch.ops.aten.to.dtype(where_self_181, torch.float32);  where_self_181 = None
        native_batch_norm_backward_default_181 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_545, convolution_default_153, primals_1047, primals_1045, primals_1046, getitem_255, getitem_256, True, 0.001, [True, True, True]);  to_dtype_545 = convolution_default_153 = primals_1047 = primals_1045 = primals_1046 = getitem_255 = getitem_256 = None
        getitem_2353 = native_batch_norm_backward_default_181[0]
        getitem_2354 = native_batch_norm_backward_default_181[1]
        getitem_2355 = native_batch_norm_backward_default_181[2];  native_batch_norm_backward_default_181 = None
        convolution_backward_default_334 = torch.ops.aten.convolution_backward.default(getitem_2353, convolution_default_152, primals_1054, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2353 = convolution_default_152 = primals_1054 = None
        getitem_2356 = convolution_backward_default_334[0]
        getitem_2357 = convolution_backward_default_334[1];  convolution_backward_default_334 = None
        convolution_backward_default_335 = torch.ops.aten.convolution_backward.default(getitem_2356, relu_default_47, primals_1053, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2356 = primals_1053 = None
        getitem_2359 = convolution_backward_default_335[0]
        getitem_2360 = convolution_backward_default_335[1];  convolution_backward_default_335 = None
        to_dtype_546 = torch.ops.aten.to.dtype(getitem_2359, torch.float32);  getitem_2359 = None
        to_dtype_547 = torch.ops.aten.to.dtype(relu_default_47, torch.float32);  relu_default_47 = None
        le_scalar_182 = torch.ops.aten.le.Scalar(to_dtype_547, 0);  to_dtype_547 = None
        new_zeros_default_446 = torch.ops.aten.new_zeros.default(to_dtype_546, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_182 = torch.ops.aten.where.self(le_scalar_182, new_zeros_default_446, to_dtype_546);  le_scalar_182 = new_zeros_default_446 = to_dtype_546 = None
        to_dtype_548 = torch.ops.aten.to.dtype(where_self_182, torch.float32);  where_self_182 = None
        add_tensor_258 = torch.ops.aten.add.Tensor(slice_tensor_95, to_dtype_548);  slice_tensor_95 = to_dtype_548 = None
        avg_pool2d_backward_default_47 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_94, getitem_224, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_259 = torch.ops.aten.add.Tensor(slice_tensor_90, avg_pool2d_backward_default_47);  slice_tensor_90 = avg_pool2d_backward_default_47 = None
        avg_pool2d_backward_default_48 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_94, getitem_224, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_94 = getitem_224 = None
        add_tensor_260 = torch.ops.aten.add.Tensor(add_tensor_259, avg_pool2d_backward_default_48);  add_tensor_259 = avg_pool2d_backward_default_48 = None
        add_tensor_261 = torch.ops.aten.add.Tensor(add_tensor_260, slice_tensor_93);  add_tensor_260 = None
        avg_pool2d_backward_default_49 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_93, getitem_227, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_93 = getitem_227 = None
        add_tensor_262 = torch.ops.aten.add.Tensor(add_tensor_258, avg_pool2d_backward_default_49);  add_tensor_258 = avg_pool2d_backward_default_49 = None
        clone_default_70 = torch.ops.aten.clone.default(slice_tensor_92, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_182 = torch.ops.aten.native_batch_norm_backward.default(clone_default_70, convolution_default_151, primals_1038, primals_1036, primals_1037, getitem_252, getitem_253, True, 0.001, [True, True, True]);  clone_default_70 = convolution_default_151 = primals_1038 = primals_1036 = primals_1037 = getitem_252 = getitem_253 = None
        getitem_2362 = native_batch_norm_backward_default_182[0]
        getitem_2363 = native_batch_norm_backward_default_182[1]
        getitem_2364 = native_batch_norm_backward_default_182[2];  native_batch_norm_backward_default_182 = None
        convolution_backward_default_336 = torch.ops.aten.convolution_backward.default(getitem_2362, convolution_default_150, primals_1042, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2362 = convolution_default_150 = primals_1042 = None
        getitem_2365 = convolution_backward_default_336[0]
        getitem_2366 = convolution_backward_default_336[1];  convolution_backward_default_336 = None
        convolution_backward_default_337 = torch.ops.aten.convolution_backward.default(getitem_2365, relu__default_33, primals_1041, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2365 = primals_1041 = None
        getitem_2368 = convolution_backward_default_337[0]
        getitem_2369 = convolution_backward_default_337[1];  convolution_backward_default_337 = None
        to_dtype_549 = torch.ops.aten.to.dtype(getitem_2368, torch.float32);  getitem_2368 = None
        to_dtype_550 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_183 = torch.ops.aten.le.Scalar(to_dtype_550, 0);  to_dtype_550 = None
        new_zeros_default_447 = torch.ops.aten.new_zeros.default(to_dtype_549, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_183 = torch.ops.aten.where.self(le_scalar_183, new_zeros_default_447, to_dtype_549);  le_scalar_183 = new_zeros_default_447 = to_dtype_549 = None
        to_dtype_551 = torch.ops.aten.to.dtype(where_self_183, torch.float32);  where_self_183 = None
        native_batch_norm_backward_default_183 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_551, convolution_default_149, primals_1033, primals_1031, primals_1032, getitem_249, getitem_250, True, 0.001, [True, True, True]);  to_dtype_551 = convolution_default_149 = primals_1033 = primals_1031 = primals_1032 = getitem_249 = getitem_250 = None
        getitem_2371 = native_batch_norm_backward_default_183[0]
        getitem_2372 = native_batch_norm_backward_default_183[1]
        getitem_2373 = native_batch_norm_backward_default_183[2];  native_batch_norm_backward_default_183 = None
        convolution_backward_default_338 = torch.ops.aten.convolution_backward.default(getitem_2371, convolution_default_148, primals_1040, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2371 = convolution_default_148 = primals_1040 = None
        getitem_2374 = convolution_backward_default_338[0]
        getitem_2375 = convolution_backward_default_338[1];  convolution_backward_default_338 = None
        convolution_backward_default_339 = torch.ops.aten.convolution_backward.default(getitem_2374, relu_default_46, primals_1039, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2374 = primals_1039 = None
        getitem_2377 = convolution_backward_default_339[0]
        getitem_2378 = convolution_backward_default_339[1];  convolution_backward_default_339 = None
        to_dtype_552 = torch.ops.aten.to.dtype(getitem_2377, torch.float32);  getitem_2377 = None
        to_dtype_553 = torch.ops.aten.to.dtype(relu_default_46, torch.float32);  relu_default_46 = None
        le_scalar_184 = torch.ops.aten.le.Scalar(to_dtype_553, 0);  to_dtype_553 = None
        new_zeros_default_448 = torch.ops.aten.new_zeros.default(to_dtype_552, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_184 = torch.ops.aten.where.self(le_scalar_184, new_zeros_default_448, to_dtype_552);  le_scalar_184 = new_zeros_default_448 = to_dtype_552 = None
        to_dtype_554 = torch.ops.aten.to.dtype(where_self_184, torch.float32);  where_self_184 = None
        add_tensor_263 = torch.ops.aten.add.Tensor(add_tensor_261, to_dtype_554);  add_tensor_261 = to_dtype_554 = None
        clone_default_71 = torch.ops.aten.clone.default(slice_tensor_92, memory_format = torch.contiguous_format);  slice_tensor_92 = None
        native_batch_norm_backward_default_184 = torch.ops.aten.native_batch_norm_backward.default(clone_default_71, convolution_default_147, primals_1024, primals_1022, primals_1023, getitem_246, getitem_247, True, 0.001, [True, True, True]);  clone_default_71 = convolution_default_147 = primals_1024 = primals_1022 = primals_1023 = getitem_246 = getitem_247 = None
        getitem_2380 = native_batch_norm_backward_default_184[0]
        getitem_2381 = native_batch_norm_backward_default_184[1]
        getitem_2382 = native_batch_norm_backward_default_184[2];  native_batch_norm_backward_default_184 = None
        convolution_backward_default_340 = torch.ops.aten.convolution_backward.default(getitem_2380, convolution_default_146, primals_1028, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2380 = convolution_default_146 = primals_1028 = None
        getitem_2383 = convolution_backward_default_340[0]
        getitem_2384 = convolution_backward_default_340[1];  convolution_backward_default_340 = None
        convolution_backward_default_341 = torch.ops.aten.convolution_backward.default(getitem_2383, relu__default_32, primals_1027, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2383 = primals_1027 = None
        getitem_2386 = convolution_backward_default_341[0]
        getitem_2387 = convolution_backward_default_341[1];  convolution_backward_default_341 = None
        to_dtype_555 = torch.ops.aten.to.dtype(getitem_2386, torch.float32);  getitem_2386 = None
        to_dtype_556 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_185 = torch.ops.aten.le.Scalar(to_dtype_556, 0);  to_dtype_556 = None
        new_zeros_default_449 = torch.ops.aten.new_zeros.default(to_dtype_555, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_185 = torch.ops.aten.where.self(le_scalar_185, new_zeros_default_449, to_dtype_555);  le_scalar_185 = new_zeros_default_449 = to_dtype_555 = None
        to_dtype_557 = torch.ops.aten.to.dtype(where_self_185, torch.float32);  where_self_185 = None
        native_batch_norm_backward_default_185 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_557, convolution_default_145, primals_1019, primals_1017, primals_1018, getitem_243, getitem_244, True, 0.001, [True, True, True]);  to_dtype_557 = convolution_default_145 = primals_1019 = primals_1017 = primals_1018 = getitem_243 = getitem_244 = None
        getitem_2389 = native_batch_norm_backward_default_185[0]
        getitem_2390 = native_batch_norm_backward_default_185[1]
        getitem_2391 = native_batch_norm_backward_default_185[2];  native_batch_norm_backward_default_185 = None
        convolution_backward_default_342 = torch.ops.aten.convolution_backward.default(getitem_2389, convolution_default_144, primals_1026, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2389 = convolution_default_144 = primals_1026 = None
        getitem_2392 = convolution_backward_default_342[0]
        getitem_2393 = convolution_backward_default_342[1];  convolution_backward_default_342 = None
        convolution_backward_default_343 = torch.ops.aten.convolution_backward.default(getitem_2392, relu_default_45, primals_1025, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2392 = primals_1025 = None
        getitem_2395 = convolution_backward_default_343[0]
        getitem_2396 = convolution_backward_default_343[1];  convolution_backward_default_343 = None
        to_dtype_558 = torch.ops.aten.to.dtype(getitem_2395, torch.float32);  getitem_2395 = None
        to_dtype_559 = torch.ops.aten.to.dtype(relu_default_45, torch.float32);  relu_default_45 = None
        le_scalar_186 = torch.ops.aten.le.Scalar(to_dtype_559, 0);  to_dtype_559 = None
        new_zeros_default_450 = torch.ops.aten.new_zeros.default(to_dtype_558, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_186 = torch.ops.aten.where.self(le_scalar_186, new_zeros_default_450, to_dtype_558);  le_scalar_186 = new_zeros_default_450 = to_dtype_558 = None
        to_dtype_560 = torch.ops.aten.to.dtype(where_self_186, torch.float32);  where_self_186 = None
        add_tensor_264 = torch.ops.aten.add.Tensor(add_tensor_263, to_dtype_560);  add_tensor_263 = to_dtype_560 = None
        clone_default_72 = torch.ops.aten.clone.default(slice_tensor_91, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_186 = torch.ops.aten.native_batch_norm_backward.default(clone_default_72, convolution_default_143, primals_1010, primals_1008, primals_1009, getitem_240, getitem_241, True, 0.001, [True, True, True]);  clone_default_72 = convolution_default_143 = primals_1010 = primals_1008 = primals_1009 = getitem_240 = getitem_241 = None
        getitem_2398 = native_batch_norm_backward_default_186[0]
        getitem_2399 = native_batch_norm_backward_default_186[1]
        getitem_2400 = native_batch_norm_backward_default_186[2];  native_batch_norm_backward_default_186 = None
        convolution_backward_default_344 = torch.ops.aten.convolution_backward.default(getitem_2398, convolution_default_142, primals_1014, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2398 = convolution_default_142 = primals_1014 = None
        getitem_2401 = convolution_backward_default_344[0]
        getitem_2402 = convolution_backward_default_344[1];  convolution_backward_default_344 = None
        convolution_backward_default_345 = torch.ops.aten.convolution_backward.default(getitem_2401, relu__default_31, primals_1013, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2401 = primals_1013 = None
        getitem_2404 = convolution_backward_default_345[0]
        getitem_2405 = convolution_backward_default_345[1];  convolution_backward_default_345 = None
        to_dtype_561 = torch.ops.aten.to.dtype(getitem_2404, torch.float32);  getitem_2404 = None
        to_dtype_562 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_187 = torch.ops.aten.le.Scalar(to_dtype_562, 0);  to_dtype_562 = None
        new_zeros_default_451 = torch.ops.aten.new_zeros.default(to_dtype_561, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_187 = torch.ops.aten.where.self(le_scalar_187, new_zeros_default_451, to_dtype_561);  le_scalar_187 = new_zeros_default_451 = to_dtype_561 = None
        to_dtype_563 = torch.ops.aten.to.dtype(where_self_187, torch.float32);  where_self_187 = None
        native_batch_norm_backward_default_187 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_563, convolution_default_141, primals_1005, primals_1003, primals_1004, getitem_237, getitem_238, True, 0.001, [True, True, True]);  to_dtype_563 = convolution_default_141 = primals_1005 = primals_1003 = primals_1004 = getitem_237 = getitem_238 = None
        getitem_2407 = native_batch_norm_backward_default_187[0]
        getitem_2408 = native_batch_norm_backward_default_187[1]
        getitem_2409 = native_batch_norm_backward_default_187[2];  native_batch_norm_backward_default_187 = None
        convolution_backward_default_346 = torch.ops.aten.convolution_backward.default(getitem_2407, convolution_default_140, primals_1012, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2407 = convolution_default_140 = primals_1012 = None
        getitem_2410 = convolution_backward_default_346[0]
        getitem_2411 = convolution_backward_default_346[1];  convolution_backward_default_346 = None
        convolution_backward_default_347 = torch.ops.aten.convolution_backward.default(getitem_2410, relu_default_44, primals_1011, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2410 = primals_1011 = None
        getitem_2413 = convolution_backward_default_347[0]
        getitem_2414 = convolution_backward_default_347[1];  convolution_backward_default_347 = None
        to_dtype_564 = torch.ops.aten.to.dtype(getitem_2413, torch.float32);  getitem_2413 = None
        to_dtype_565 = torch.ops.aten.to.dtype(relu_default_44, torch.float32);  relu_default_44 = None
        le_scalar_188 = torch.ops.aten.le.Scalar(to_dtype_565, 0);  to_dtype_565 = None
        new_zeros_default_452 = torch.ops.aten.new_zeros.default(to_dtype_564, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_188 = torch.ops.aten.where.self(le_scalar_188, new_zeros_default_452, to_dtype_564);  le_scalar_188 = new_zeros_default_452 = to_dtype_564 = None
        to_dtype_566 = torch.ops.aten.to.dtype(where_self_188, torch.float32);  where_self_188 = None
        add_tensor_265 = torch.ops.aten.add.Tensor(add_tensor_264, to_dtype_566);  add_tensor_264 = to_dtype_566 = None
        clone_default_73 = torch.ops.aten.clone.default(slice_tensor_91, memory_format = torch.contiguous_format);  slice_tensor_91 = None
        native_batch_norm_backward_default_188 = torch.ops.aten.native_batch_norm_backward.default(clone_default_73, convolution_default_139, primals_996, primals_994, primals_995, getitem_234, getitem_235, True, 0.001, [True, True, True]);  clone_default_73 = convolution_default_139 = primals_996 = primals_994 = primals_995 = getitem_234 = getitem_235 = None
        getitem_2416 = native_batch_norm_backward_default_188[0]
        getitem_2417 = native_batch_norm_backward_default_188[1]
        getitem_2418 = native_batch_norm_backward_default_188[2];  native_batch_norm_backward_default_188 = None
        convolution_backward_default_348 = torch.ops.aten.convolution_backward.default(getitem_2416, convolution_default_138, primals_1000, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2416 = convolution_default_138 = primals_1000 = None
        getitem_2419 = convolution_backward_default_348[0]
        getitem_2420 = convolution_backward_default_348[1];  convolution_backward_default_348 = None
        convolution_backward_default_349 = torch.ops.aten.convolution_backward.default(getitem_2419, relu__default_30, primals_999, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2419 = primals_999 = None
        getitem_2422 = convolution_backward_default_349[0]
        getitem_2423 = convolution_backward_default_349[1];  convolution_backward_default_349 = None
        to_dtype_567 = torch.ops.aten.to.dtype(getitem_2422, torch.float32);  getitem_2422 = None
        to_dtype_568 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_189 = torch.ops.aten.le.Scalar(to_dtype_568, 0);  to_dtype_568 = None
        new_zeros_default_453 = torch.ops.aten.new_zeros.default(to_dtype_567, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_189 = torch.ops.aten.where.self(le_scalar_189, new_zeros_default_453, to_dtype_567);  le_scalar_189 = new_zeros_default_453 = to_dtype_567 = None
        to_dtype_569 = torch.ops.aten.to.dtype(where_self_189, torch.float32);  where_self_189 = None
        native_batch_norm_backward_default_189 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_569, convolution_default_137, primals_991, primals_989, primals_990, getitem_231, getitem_232, True, 0.001, [True, True, True]);  to_dtype_569 = convolution_default_137 = primals_991 = primals_989 = primals_990 = getitem_231 = getitem_232 = None
        getitem_2425 = native_batch_norm_backward_default_189[0]
        getitem_2426 = native_batch_norm_backward_default_189[1]
        getitem_2427 = native_batch_norm_backward_default_189[2];  native_batch_norm_backward_default_189 = None
        convolution_backward_default_350 = torch.ops.aten.convolution_backward.default(getitem_2425, convolution_default_136, primals_998, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2425 = convolution_default_136 = primals_998 = None
        getitem_2428 = convolution_backward_default_350[0]
        getitem_2429 = convolution_backward_default_350[1];  convolution_backward_default_350 = None
        convolution_backward_default_351 = torch.ops.aten.convolution_backward.default(getitem_2428, relu_default_43, primals_997, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2428 = primals_997 = None
        getitem_2431 = convolution_backward_default_351[0]
        getitem_2432 = convolution_backward_default_351[1];  convolution_backward_default_351 = None
        to_dtype_570 = torch.ops.aten.to.dtype(getitem_2431, torch.float32);  getitem_2431 = None
        to_dtype_571 = torch.ops.aten.to.dtype(relu_default_43, torch.float32);  relu_default_43 = None
        le_scalar_190 = torch.ops.aten.le.Scalar(to_dtype_571, 0);  to_dtype_571 = None
        new_zeros_default_454 = torch.ops.aten.new_zeros.default(to_dtype_570, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_190 = torch.ops.aten.where.self(le_scalar_190, new_zeros_default_454, to_dtype_570);  le_scalar_190 = new_zeros_default_454 = to_dtype_570 = None
        to_dtype_572 = torch.ops.aten.to.dtype(where_self_190, torch.float32);  where_self_190 = None
        add_tensor_266 = torch.ops.aten.add.Tensor(add_tensor_262, to_dtype_572);  add_tensor_262 = to_dtype_572 = None
        native_batch_norm_backward_default_190 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_266, convolution_default_135, primals_1061, primals_1059, primals_1060, getitem_228, getitem_229, True, 0.001, [True, True, True]);  add_tensor_266 = convolution_default_135 = primals_1061 = primals_1059 = primals_1060 = getitem_228 = getitem_229 = None
        getitem_2434 = native_batch_norm_backward_default_190[0]
        getitem_2435 = native_batch_norm_backward_default_190[1]
        getitem_2436 = native_batch_norm_backward_default_190[2];  native_batch_norm_backward_default_190 = None
        convolution_backward_default_352 = torch.ops.aten.convolution_backward.default(getitem_2434, relu_default_42, primals_1062, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2434 = primals_1062 = None
        getitem_2437 = convolution_backward_default_352[0]
        getitem_2438 = convolution_backward_default_352[1];  convolution_backward_default_352 = None
        to_dtype_573 = torch.ops.aten.to.dtype(getitem_2437, torch.float32);  getitem_2437 = None
        to_dtype_574 = torch.ops.aten.to.dtype(relu_default_42, torch.float32);  relu_default_42 = None
        le_scalar_191 = torch.ops.aten.le.Scalar(to_dtype_574, 0);  to_dtype_574 = None
        new_zeros_default_455 = torch.ops.aten.new_zeros.default(to_dtype_573, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_191 = torch.ops.aten.where.self(le_scalar_191, new_zeros_default_455, to_dtype_573);  le_scalar_191 = new_zeros_default_455 = to_dtype_573 = None
        to_dtype_575 = torch.ops.aten.to.dtype(where_self_191, torch.float32);  where_self_191 = None
        add_tensor_267 = torch.ops.aten.add.Tensor(to_dtype_542, to_dtype_575);  to_dtype_542 = to_dtype_575 = None
        native_batch_norm_backward_default_191 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_265, convolution_default_134, primals_1067, primals_1065, primals_1066, getitem_225, getitem_226, True, 0.001, [True, True, True]);  add_tensor_265 = convolution_default_134 = primals_1067 = primals_1065 = primals_1066 = getitem_225 = getitem_226 = None
        getitem_2440 = native_batch_norm_backward_default_191[0]
        getitem_2441 = native_batch_norm_backward_default_191[1]
        getitem_2442 = native_batch_norm_backward_default_191[2];  native_batch_norm_backward_default_191 = None
        convolution_backward_default_353 = torch.ops.aten.convolution_backward.default(getitem_2440, relu_default_41, primals_1068, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2440 = primals_1068 = None
        getitem_2443 = convolution_backward_default_353[0]
        getitem_2444 = convolution_backward_default_353[1];  convolution_backward_default_353 = None
        to_dtype_576 = torch.ops.aten.to.dtype(getitem_2443, torch.float32);  getitem_2443 = None
        to_dtype_577 = torch.ops.aten.to.dtype(relu_default_41, torch.float32);  relu_default_41 = None
        le_scalar_192 = torch.ops.aten.le.Scalar(to_dtype_577, 0);  to_dtype_577 = None
        new_zeros_default_456 = torch.ops.aten.new_zeros.default(to_dtype_576, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_192 = torch.ops.aten.where.self(le_scalar_192, new_zeros_default_456, to_dtype_576);  le_scalar_192 = new_zeros_default_456 = to_dtype_576 = None
        to_dtype_578 = torch.ops.aten.to.dtype(where_self_192, torch.float32);  where_self_192 = None
        slice_tensor_96 = torch.ops.aten.slice.Tensor(add_tensor_267, 1, 0, 168)
        slice_tensor_97 = torch.ops.aten.slice.Tensor(add_tensor_267, 1, 168, 336)
        slice_tensor_98 = torch.ops.aten.slice.Tensor(add_tensor_267, 1, 336, 504)
        slice_tensor_99 = torch.ops.aten.slice.Tensor(add_tensor_267, 1, 504, 672)
        slice_tensor_100 = torch.ops.aten.slice.Tensor(add_tensor_267, 1, 672, 840)
        slice_tensor_101 = torch.ops.aten.slice.Tensor(add_tensor_267, 1, 840, 1008);  add_tensor_267 = None
        clone_default_74 = torch.ops.aten.clone.default(slice_tensor_101, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_192 = torch.ops.aten.native_batch_norm_backward.default(clone_default_74, convolution_default_133, primals_970, primals_968, primals_969, getitem_222, getitem_223, True, 0.001, [True, True, True]);  clone_default_74 = convolution_default_133 = primals_970 = primals_968 = primals_969 = getitem_222 = getitem_223 = None
        getitem_2446 = native_batch_norm_backward_default_192[0]
        getitem_2447 = native_batch_norm_backward_default_192[1]
        getitem_2448 = native_batch_norm_backward_default_192[2];  native_batch_norm_backward_default_192 = None
        convolution_backward_default_354 = torch.ops.aten.convolution_backward.default(getitem_2446, convolution_default_132, primals_974, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2446 = convolution_default_132 = primals_974 = None
        getitem_2449 = convolution_backward_default_354[0]
        getitem_2450 = convolution_backward_default_354[1];  convolution_backward_default_354 = None
        convolution_backward_default_355 = torch.ops.aten.convolution_backward.default(getitem_2449, relu__default_29, primals_973, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2449 = primals_973 = None
        getitem_2452 = convolution_backward_default_355[0]
        getitem_2453 = convolution_backward_default_355[1];  convolution_backward_default_355 = None
        to_dtype_579 = torch.ops.aten.to.dtype(getitem_2452, torch.float32);  getitem_2452 = None
        to_dtype_580 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_193 = torch.ops.aten.le.Scalar(to_dtype_580, 0);  to_dtype_580 = None
        new_zeros_default_457 = torch.ops.aten.new_zeros.default(to_dtype_579, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_193 = torch.ops.aten.where.self(le_scalar_193, new_zeros_default_457, to_dtype_579);  le_scalar_193 = new_zeros_default_457 = to_dtype_579 = None
        to_dtype_581 = torch.ops.aten.to.dtype(where_self_193, torch.float32);  where_self_193 = None
        native_batch_norm_backward_default_193 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_581, convolution_default_131, primals_965, primals_963, primals_964, getitem_219, getitem_220, True, 0.001, [True, True, True]);  to_dtype_581 = convolution_default_131 = primals_965 = primals_963 = primals_964 = getitem_219 = getitem_220 = None
        getitem_2455 = native_batch_norm_backward_default_193[0]
        getitem_2456 = native_batch_norm_backward_default_193[1]
        getitem_2457 = native_batch_norm_backward_default_193[2];  native_batch_norm_backward_default_193 = None
        convolution_backward_default_356 = torch.ops.aten.convolution_backward.default(getitem_2455, convolution_default_130, primals_972, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2455 = convolution_default_130 = primals_972 = None
        getitem_2458 = convolution_backward_default_356[0]
        getitem_2459 = convolution_backward_default_356[1];  convolution_backward_default_356 = None
        convolution_backward_default_357 = torch.ops.aten.convolution_backward.default(getitem_2458, relu_default_40, primals_971, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2458 = primals_971 = None
        getitem_2461 = convolution_backward_default_357[0]
        getitem_2462 = convolution_backward_default_357[1];  convolution_backward_default_357 = None
        to_dtype_582 = torch.ops.aten.to.dtype(getitem_2461, torch.float32);  getitem_2461 = None
        to_dtype_583 = torch.ops.aten.to.dtype(relu_default_40, torch.float32);  relu_default_40 = None
        le_scalar_194 = torch.ops.aten.le.Scalar(to_dtype_583, 0);  to_dtype_583 = None
        new_zeros_default_458 = torch.ops.aten.new_zeros.default(to_dtype_582, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_194 = torch.ops.aten.where.self(le_scalar_194, new_zeros_default_458, to_dtype_582);  le_scalar_194 = new_zeros_default_458 = to_dtype_582 = None
        to_dtype_584 = torch.ops.aten.to.dtype(where_self_194, torch.float32);  where_self_194 = None
        add_tensor_268 = torch.ops.aten.add.Tensor(slice_tensor_101, to_dtype_584);  slice_tensor_101 = to_dtype_584 = None
        avg_pool2d_backward_default_50 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_100, getitem_188, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_269 = torch.ops.aten.add.Tensor(slice_tensor_96, avg_pool2d_backward_default_50);  slice_tensor_96 = avg_pool2d_backward_default_50 = None
        avg_pool2d_backward_default_51 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_100, getitem_188, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_100 = getitem_188 = None
        add_tensor_270 = torch.ops.aten.add.Tensor(add_tensor_269, avg_pool2d_backward_default_51);  add_tensor_269 = avg_pool2d_backward_default_51 = None
        add_tensor_271 = torch.ops.aten.add.Tensor(add_tensor_270, slice_tensor_99);  add_tensor_270 = None
        avg_pool2d_backward_default_52 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_99, getitem_191, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_99 = getitem_191 = None
        add_tensor_272 = torch.ops.aten.add.Tensor(add_tensor_268, avg_pool2d_backward_default_52);  add_tensor_268 = avg_pool2d_backward_default_52 = None
        clone_default_75 = torch.ops.aten.clone.default(slice_tensor_98, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_194 = torch.ops.aten.native_batch_norm_backward.default(clone_default_75, convolution_default_129, primals_956, primals_954, primals_955, getitem_216, getitem_217, True, 0.001, [True, True, True]);  clone_default_75 = convolution_default_129 = primals_956 = primals_954 = primals_955 = getitem_216 = getitem_217 = None
        getitem_2464 = native_batch_norm_backward_default_194[0]
        getitem_2465 = native_batch_norm_backward_default_194[1]
        getitem_2466 = native_batch_norm_backward_default_194[2];  native_batch_norm_backward_default_194 = None
        convolution_backward_default_358 = torch.ops.aten.convolution_backward.default(getitem_2464, convolution_default_128, primals_960, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2464 = convolution_default_128 = primals_960 = None
        getitem_2467 = convolution_backward_default_358[0]
        getitem_2468 = convolution_backward_default_358[1];  convolution_backward_default_358 = None
        convolution_backward_default_359 = torch.ops.aten.convolution_backward.default(getitem_2467, relu__default_28, primals_959, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2467 = primals_959 = None
        getitem_2470 = convolution_backward_default_359[0]
        getitem_2471 = convolution_backward_default_359[1];  convolution_backward_default_359 = None
        to_dtype_585 = torch.ops.aten.to.dtype(getitem_2470, torch.float32);  getitem_2470 = None
        to_dtype_586 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_195 = torch.ops.aten.le.Scalar(to_dtype_586, 0);  to_dtype_586 = None
        new_zeros_default_459 = torch.ops.aten.new_zeros.default(to_dtype_585, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_195 = torch.ops.aten.where.self(le_scalar_195, new_zeros_default_459, to_dtype_585);  le_scalar_195 = new_zeros_default_459 = to_dtype_585 = None
        to_dtype_587 = torch.ops.aten.to.dtype(where_self_195, torch.float32);  where_self_195 = None
        native_batch_norm_backward_default_195 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_587, convolution_default_127, primals_951, primals_949, primals_950, getitem_213, getitem_214, True, 0.001, [True, True, True]);  to_dtype_587 = convolution_default_127 = primals_951 = primals_949 = primals_950 = getitem_213 = getitem_214 = None
        getitem_2473 = native_batch_norm_backward_default_195[0]
        getitem_2474 = native_batch_norm_backward_default_195[1]
        getitem_2475 = native_batch_norm_backward_default_195[2];  native_batch_norm_backward_default_195 = None
        convolution_backward_default_360 = torch.ops.aten.convolution_backward.default(getitem_2473, convolution_default_126, primals_958, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2473 = convolution_default_126 = primals_958 = None
        getitem_2476 = convolution_backward_default_360[0]
        getitem_2477 = convolution_backward_default_360[1];  convolution_backward_default_360 = None
        convolution_backward_default_361 = torch.ops.aten.convolution_backward.default(getitem_2476, relu_default_39, primals_957, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2476 = primals_957 = None
        getitem_2479 = convolution_backward_default_361[0]
        getitem_2480 = convolution_backward_default_361[1];  convolution_backward_default_361 = None
        to_dtype_588 = torch.ops.aten.to.dtype(getitem_2479, torch.float32);  getitem_2479 = None
        to_dtype_589 = torch.ops.aten.to.dtype(relu_default_39, torch.float32);  relu_default_39 = None
        le_scalar_196 = torch.ops.aten.le.Scalar(to_dtype_589, 0);  to_dtype_589 = None
        new_zeros_default_460 = torch.ops.aten.new_zeros.default(to_dtype_588, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_196 = torch.ops.aten.where.self(le_scalar_196, new_zeros_default_460, to_dtype_588);  le_scalar_196 = new_zeros_default_460 = to_dtype_588 = None
        to_dtype_590 = torch.ops.aten.to.dtype(where_self_196, torch.float32);  where_self_196 = None
        add_tensor_273 = torch.ops.aten.add.Tensor(add_tensor_271, to_dtype_590);  add_tensor_271 = to_dtype_590 = None
        clone_default_76 = torch.ops.aten.clone.default(slice_tensor_98, memory_format = torch.contiguous_format);  slice_tensor_98 = None
        native_batch_norm_backward_default_196 = torch.ops.aten.native_batch_norm_backward.default(clone_default_76, convolution_default_125, primals_942, primals_940, primals_941, getitem_210, getitem_211, True, 0.001, [True, True, True]);  clone_default_76 = convolution_default_125 = primals_942 = primals_940 = primals_941 = getitem_210 = getitem_211 = None
        getitem_2482 = native_batch_norm_backward_default_196[0]
        getitem_2483 = native_batch_norm_backward_default_196[1]
        getitem_2484 = native_batch_norm_backward_default_196[2];  native_batch_norm_backward_default_196 = None
        convolution_backward_default_362 = torch.ops.aten.convolution_backward.default(getitem_2482, convolution_default_124, primals_946, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2482 = convolution_default_124 = primals_946 = None
        getitem_2485 = convolution_backward_default_362[0]
        getitem_2486 = convolution_backward_default_362[1];  convolution_backward_default_362 = None
        convolution_backward_default_363 = torch.ops.aten.convolution_backward.default(getitem_2485, relu__default_27, primals_945, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2485 = primals_945 = None
        getitem_2488 = convolution_backward_default_363[0]
        getitem_2489 = convolution_backward_default_363[1];  convolution_backward_default_363 = None
        to_dtype_591 = torch.ops.aten.to.dtype(getitem_2488, torch.float32);  getitem_2488 = None
        to_dtype_592 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_197 = torch.ops.aten.le.Scalar(to_dtype_592, 0);  to_dtype_592 = None
        new_zeros_default_461 = torch.ops.aten.new_zeros.default(to_dtype_591, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_197 = torch.ops.aten.where.self(le_scalar_197, new_zeros_default_461, to_dtype_591);  le_scalar_197 = new_zeros_default_461 = to_dtype_591 = None
        to_dtype_593 = torch.ops.aten.to.dtype(where_self_197, torch.float32);  where_self_197 = None
        native_batch_norm_backward_default_197 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_593, convolution_default_123, primals_937, primals_935, primals_936, getitem_207, getitem_208, True, 0.001, [True, True, True]);  to_dtype_593 = convolution_default_123 = primals_937 = primals_935 = primals_936 = getitem_207 = getitem_208 = None
        getitem_2491 = native_batch_norm_backward_default_197[0]
        getitem_2492 = native_batch_norm_backward_default_197[1]
        getitem_2493 = native_batch_norm_backward_default_197[2];  native_batch_norm_backward_default_197 = None
        convolution_backward_default_364 = torch.ops.aten.convolution_backward.default(getitem_2491, convolution_default_122, primals_944, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2491 = convolution_default_122 = primals_944 = None
        getitem_2494 = convolution_backward_default_364[0]
        getitem_2495 = convolution_backward_default_364[1];  convolution_backward_default_364 = None
        convolution_backward_default_365 = torch.ops.aten.convolution_backward.default(getitem_2494, relu_default_38, primals_943, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2494 = primals_943 = None
        getitem_2497 = convolution_backward_default_365[0]
        getitem_2498 = convolution_backward_default_365[1];  convolution_backward_default_365 = None
        to_dtype_594 = torch.ops.aten.to.dtype(getitem_2497, torch.float32);  getitem_2497 = None
        to_dtype_595 = torch.ops.aten.to.dtype(relu_default_38, torch.float32);  relu_default_38 = None
        le_scalar_198 = torch.ops.aten.le.Scalar(to_dtype_595, 0);  to_dtype_595 = None
        new_zeros_default_462 = torch.ops.aten.new_zeros.default(to_dtype_594, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_198 = torch.ops.aten.where.self(le_scalar_198, new_zeros_default_462, to_dtype_594);  le_scalar_198 = new_zeros_default_462 = to_dtype_594 = None
        to_dtype_596 = torch.ops.aten.to.dtype(where_self_198, torch.float32);  where_self_198 = None
        add_tensor_274 = torch.ops.aten.add.Tensor(add_tensor_273, to_dtype_596);  add_tensor_273 = to_dtype_596 = None
        clone_default_77 = torch.ops.aten.clone.default(slice_tensor_97, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_198 = torch.ops.aten.native_batch_norm_backward.default(clone_default_77, convolution_default_121, primals_928, primals_926, primals_927, getitem_204, getitem_205, True, 0.001, [True, True, True]);  clone_default_77 = convolution_default_121 = primals_928 = primals_926 = primals_927 = getitem_204 = getitem_205 = None
        getitem_2500 = native_batch_norm_backward_default_198[0]
        getitem_2501 = native_batch_norm_backward_default_198[1]
        getitem_2502 = native_batch_norm_backward_default_198[2];  native_batch_norm_backward_default_198 = None
        convolution_backward_default_366 = torch.ops.aten.convolution_backward.default(getitem_2500, convolution_default_120, primals_932, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2500 = convolution_default_120 = primals_932 = None
        getitem_2503 = convolution_backward_default_366[0]
        getitem_2504 = convolution_backward_default_366[1];  convolution_backward_default_366 = None
        convolution_backward_default_367 = torch.ops.aten.convolution_backward.default(getitem_2503, relu__default_26, primals_931, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2503 = primals_931 = None
        getitem_2506 = convolution_backward_default_367[0]
        getitem_2507 = convolution_backward_default_367[1];  convolution_backward_default_367 = None
        to_dtype_597 = torch.ops.aten.to.dtype(getitem_2506, torch.float32);  getitem_2506 = None
        to_dtype_598 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_199 = torch.ops.aten.le.Scalar(to_dtype_598, 0);  to_dtype_598 = None
        new_zeros_default_463 = torch.ops.aten.new_zeros.default(to_dtype_597, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_199 = torch.ops.aten.where.self(le_scalar_199, new_zeros_default_463, to_dtype_597);  le_scalar_199 = new_zeros_default_463 = to_dtype_597 = None
        to_dtype_599 = torch.ops.aten.to.dtype(where_self_199, torch.float32);  where_self_199 = None
        native_batch_norm_backward_default_199 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_599, convolution_default_119, primals_923, primals_921, primals_922, getitem_201, getitem_202, True, 0.001, [True, True, True]);  to_dtype_599 = convolution_default_119 = primals_923 = primals_921 = primals_922 = getitem_201 = getitem_202 = None
        getitem_2509 = native_batch_norm_backward_default_199[0]
        getitem_2510 = native_batch_norm_backward_default_199[1]
        getitem_2511 = native_batch_norm_backward_default_199[2];  native_batch_norm_backward_default_199 = None
        convolution_backward_default_368 = torch.ops.aten.convolution_backward.default(getitem_2509, convolution_default_118, primals_930, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2509 = convolution_default_118 = primals_930 = None
        getitem_2512 = convolution_backward_default_368[0]
        getitem_2513 = convolution_backward_default_368[1];  convolution_backward_default_368 = None
        convolution_backward_default_369 = torch.ops.aten.convolution_backward.default(getitem_2512, relu_default_37, primals_929, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2512 = primals_929 = None
        getitem_2515 = convolution_backward_default_369[0]
        getitem_2516 = convolution_backward_default_369[1];  convolution_backward_default_369 = None
        to_dtype_600 = torch.ops.aten.to.dtype(getitem_2515, torch.float32);  getitem_2515 = None
        to_dtype_601 = torch.ops.aten.to.dtype(relu_default_37, torch.float32);  relu_default_37 = None
        le_scalar_200 = torch.ops.aten.le.Scalar(to_dtype_601, 0);  to_dtype_601 = None
        new_zeros_default_464 = torch.ops.aten.new_zeros.default(to_dtype_600, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_200 = torch.ops.aten.where.self(le_scalar_200, new_zeros_default_464, to_dtype_600);  le_scalar_200 = new_zeros_default_464 = to_dtype_600 = None
        to_dtype_602 = torch.ops.aten.to.dtype(where_self_200, torch.float32);  where_self_200 = None
        add_tensor_275 = torch.ops.aten.add.Tensor(add_tensor_274, to_dtype_602);  add_tensor_274 = to_dtype_602 = None
        clone_default_78 = torch.ops.aten.clone.default(slice_tensor_97, memory_format = torch.contiguous_format);  slice_tensor_97 = None
        native_batch_norm_backward_default_200 = torch.ops.aten.native_batch_norm_backward.default(clone_default_78, convolution_default_117, primals_914, primals_912, primals_913, getitem_198, getitem_199, True, 0.001, [True, True, True]);  clone_default_78 = convolution_default_117 = primals_914 = primals_912 = primals_913 = getitem_198 = getitem_199 = None
        getitem_2518 = native_batch_norm_backward_default_200[0]
        getitem_2519 = native_batch_norm_backward_default_200[1]
        getitem_2520 = native_batch_norm_backward_default_200[2];  native_batch_norm_backward_default_200 = None
        convolution_backward_default_370 = torch.ops.aten.convolution_backward.default(getitem_2518, convolution_default_116, primals_918, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2518 = convolution_default_116 = primals_918 = None
        getitem_2521 = convolution_backward_default_370[0]
        getitem_2522 = convolution_backward_default_370[1];  convolution_backward_default_370 = None
        convolution_backward_default_371 = torch.ops.aten.convolution_backward.default(getitem_2521, relu__default_25, primals_917, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2521 = primals_917 = None
        getitem_2524 = convolution_backward_default_371[0]
        getitem_2525 = convolution_backward_default_371[1];  convolution_backward_default_371 = None
        to_dtype_603 = torch.ops.aten.to.dtype(getitem_2524, torch.float32);  getitem_2524 = None
        to_dtype_604 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_201 = torch.ops.aten.le.Scalar(to_dtype_604, 0);  to_dtype_604 = None
        new_zeros_default_465 = torch.ops.aten.new_zeros.default(to_dtype_603, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_201 = torch.ops.aten.where.self(le_scalar_201, new_zeros_default_465, to_dtype_603);  le_scalar_201 = new_zeros_default_465 = to_dtype_603 = None
        to_dtype_605 = torch.ops.aten.to.dtype(where_self_201, torch.float32);  where_self_201 = None
        native_batch_norm_backward_default_201 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_605, convolution_default_115, primals_909, primals_907, primals_908, getitem_195, getitem_196, True, 0.001, [True, True, True]);  to_dtype_605 = convolution_default_115 = primals_909 = primals_907 = primals_908 = getitem_195 = getitem_196 = None
        getitem_2527 = native_batch_norm_backward_default_201[0]
        getitem_2528 = native_batch_norm_backward_default_201[1]
        getitem_2529 = native_batch_norm_backward_default_201[2];  native_batch_norm_backward_default_201 = None
        convolution_backward_default_372 = torch.ops.aten.convolution_backward.default(getitem_2527, convolution_default_114, primals_916, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2527 = convolution_default_114 = primals_916 = None
        getitem_2530 = convolution_backward_default_372[0]
        getitem_2531 = convolution_backward_default_372[1];  convolution_backward_default_372 = None
        convolution_backward_default_373 = torch.ops.aten.convolution_backward.default(getitem_2530, relu_default_36, primals_915, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2530 = primals_915 = None
        getitem_2533 = convolution_backward_default_373[0]
        getitem_2534 = convolution_backward_default_373[1];  convolution_backward_default_373 = None
        to_dtype_606 = torch.ops.aten.to.dtype(getitem_2533, torch.float32);  getitem_2533 = None
        to_dtype_607 = torch.ops.aten.to.dtype(relu_default_36, torch.float32);  relu_default_36 = None
        le_scalar_202 = torch.ops.aten.le.Scalar(to_dtype_607, 0);  to_dtype_607 = None
        new_zeros_default_466 = torch.ops.aten.new_zeros.default(to_dtype_606, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_202 = torch.ops.aten.where.self(le_scalar_202, new_zeros_default_466, to_dtype_606);  le_scalar_202 = new_zeros_default_466 = to_dtype_606 = None
        to_dtype_608 = torch.ops.aten.to.dtype(where_self_202, torch.float32);  where_self_202 = None
        add_tensor_276 = torch.ops.aten.add.Tensor(add_tensor_272, to_dtype_608);  add_tensor_272 = to_dtype_608 = None
        native_batch_norm_backward_default_202 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_276, convolution_default_113, primals_979, primals_977, primals_978, getitem_192, getitem_193, True, 0.001, [True, True, True]);  add_tensor_276 = convolution_default_113 = primals_979 = primals_977 = primals_978 = getitem_192 = getitem_193 = None
        getitem_2536 = native_batch_norm_backward_default_202[0]
        getitem_2537 = native_batch_norm_backward_default_202[1]
        getitem_2538 = native_batch_norm_backward_default_202[2];  native_batch_norm_backward_default_202 = None
        convolution_backward_default_374 = torch.ops.aten.convolution_backward.default(getitem_2536, relu_default_35, primals_980, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2536 = primals_980 = None
        getitem_2539 = convolution_backward_default_374[0]
        getitem_2540 = convolution_backward_default_374[1];  convolution_backward_default_374 = None
        to_dtype_609 = torch.ops.aten.to.dtype(getitem_2539, torch.float32);  getitem_2539 = None
        to_dtype_610 = torch.ops.aten.to.dtype(relu_default_35, torch.float32);  relu_default_35 = None
        le_scalar_203 = torch.ops.aten.le.Scalar(to_dtype_610, 0);  to_dtype_610 = None
        new_zeros_default_467 = torch.ops.aten.new_zeros.default(to_dtype_609, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_203 = torch.ops.aten.where.self(le_scalar_203, new_zeros_default_467, to_dtype_609);  le_scalar_203 = new_zeros_default_467 = to_dtype_609 = None
        to_dtype_611 = torch.ops.aten.to.dtype(where_self_203, torch.float32);  where_self_203 = None
        add_tensor_277 = torch.ops.aten.add.Tensor(to_dtype_578, to_dtype_611);  to_dtype_578 = to_dtype_611 = None
        native_batch_norm_backward_default_203 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_275, convolution_default_112, primals_985, primals_983, primals_984, getitem_189, getitem_190, True, 0.001, [True, True, True]);  add_tensor_275 = convolution_default_112 = primals_985 = primals_983 = primals_984 = getitem_189 = getitem_190 = None
        getitem_2542 = native_batch_norm_backward_default_203[0]
        getitem_2543 = native_batch_norm_backward_default_203[1]
        getitem_2544 = native_batch_norm_backward_default_203[2];  native_batch_norm_backward_default_203 = None
        convolution_backward_default_375 = torch.ops.aten.convolution_backward.default(getitem_2542, relu_default_34, primals_986, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2542 = primals_986 = None
        getitem_2545 = convolution_backward_default_375[0]
        getitem_2546 = convolution_backward_default_375[1];  convolution_backward_default_375 = None
        to_dtype_612 = torch.ops.aten.to.dtype(getitem_2545, torch.float32);  getitem_2545 = None
        to_dtype_613 = torch.ops.aten.to.dtype(relu_default_34, torch.float32);  relu_default_34 = None
        le_scalar_204 = torch.ops.aten.le.Scalar(to_dtype_613, 0);  to_dtype_613 = None
        new_zeros_default_468 = torch.ops.aten.new_zeros.default(to_dtype_612, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_204 = torch.ops.aten.where.self(le_scalar_204, new_zeros_default_468, to_dtype_612);  le_scalar_204 = new_zeros_default_468 = to_dtype_612 = None
        to_dtype_614 = torch.ops.aten.to.dtype(where_self_204, torch.float32);  where_self_204 = None
        slice_tensor_102 = torch.ops.aten.slice.Tensor(add_tensor_277, 1, 0, 168)
        slice_tensor_103 = torch.ops.aten.slice.Tensor(add_tensor_277, 1, 168, 336)
        slice_tensor_104 = torch.ops.aten.slice.Tensor(add_tensor_277, 1, 336, 504)
        slice_tensor_105 = torch.ops.aten.slice.Tensor(add_tensor_277, 1, 504, 672)
        slice_tensor_106 = torch.ops.aten.slice.Tensor(add_tensor_277, 1, 672, 840)
        slice_tensor_107 = torch.ops.aten.slice.Tensor(add_tensor_277, 1, 840, 1008);  add_tensor_277 = None
        clone_default_79 = torch.ops.aten.clone.default(slice_tensor_107, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_204 = torch.ops.aten.native_batch_norm_backward.default(clone_default_79, convolution_default_111, primals_888, primals_886, primals_887, getitem_186, getitem_187, True, 0.001, [True, True, True]);  clone_default_79 = convolution_default_111 = primals_888 = primals_886 = primals_887 = getitem_186 = getitem_187 = None
        getitem_2548 = native_batch_norm_backward_default_204[0]
        getitem_2549 = native_batch_norm_backward_default_204[1]
        getitem_2550 = native_batch_norm_backward_default_204[2];  native_batch_norm_backward_default_204 = None
        convolution_backward_default_376 = torch.ops.aten.convolution_backward.default(getitem_2548, convolution_default_110, primals_892, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2548 = convolution_default_110 = primals_892 = None
        getitem_2551 = convolution_backward_default_376[0]
        getitem_2552 = convolution_backward_default_376[1];  convolution_backward_default_376 = None
        convolution_backward_default_377 = torch.ops.aten.convolution_backward.default(getitem_2551, relu__default_24, primals_891, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2551 = primals_891 = None
        getitem_2554 = convolution_backward_default_377[0]
        getitem_2555 = convolution_backward_default_377[1];  convolution_backward_default_377 = None
        to_dtype_615 = torch.ops.aten.to.dtype(getitem_2554, torch.float32);  getitem_2554 = None
        to_dtype_616 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_205 = torch.ops.aten.le.Scalar(to_dtype_616, 0);  to_dtype_616 = None
        new_zeros_default_469 = torch.ops.aten.new_zeros.default(to_dtype_615, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_205 = torch.ops.aten.where.self(le_scalar_205, new_zeros_default_469, to_dtype_615);  le_scalar_205 = new_zeros_default_469 = to_dtype_615 = None
        to_dtype_617 = torch.ops.aten.to.dtype(where_self_205, torch.float32);  where_self_205 = None
        native_batch_norm_backward_default_205 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_617, convolution_default_109, primals_883, primals_881, primals_882, getitem_183, getitem_184, True, 0.001, [True, True, True]);  to_dtype_617 = convolution_default_109 = primals_883 = primals_881 = primals_882 = getitem_183 = getitem_184 = None
        getitem_2557 = native_batch_norm_backward_default_205[0]
        getitem_2558 = native_batch_norm_backward_default_205[1]
        getitem_2559 = native_batch_norm_backward_default_205[2];  native_batch_norm_backward_default_205 = None
        convolution_backward_default_378 = torch.ops.aten.convolution_backward.default(getitem_2557, convolution_default_108, primals_890, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2557 = convolution_default_108 = primals_890 = None
        getitem_2560 = convolution_backward_default_378[0]
        getitem_2561 = convolution_backward_default_378[1];  convolution_backward_default_378 = None
        convolution_backward_default_379 = torch.ops.aten.convolution_backward.default(getitem_2560, relu_default_33, primals_889, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2560 = primals_889 = None
        getitem_2563 = convolution_backward_default_379[0]
        getitem_2564 = convolution_backward_default_379[1];  convolution_backward_default_379 = None
        to_dtype_618 = torch.ops.aten.to.dtype(getitem_2563, torch.float32);  getitem_2563 = None
        to_dtype_619 = torch.ops.aten.to.dtype(relu_default_33, torch.float32);  relu_default_33 = None
        le_scalar_206 = torch.ops.aten.le.Scalar(to_dtype_619, 0);  to_dtype_619 = None
        new_zeros_default_470 = torch.ops.aten.new_zeros.default(to_dtype_618, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_206 = torch.ops.aten.where.self(le_scalar_206, new_zeros_default_470, to_dtype_618);  le_scalar_206 = new_zeros_default_470 = to_dtype_618 = None
        to_dtype_620 = torch.ops.aten.to.dtype(where_self_206, torch.float32);  where_self_206 = None
        add_tensor_278 = torch.ops.aten.add.Tensor(slice_tensor_107, to_dtype_620);  slice_tensor_107 = to_dtype_620 = None
        avg_pool2d_backward_default_53 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_106, getitem_152, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_279 = torch.ops.aten.add.Tensor(slice_tensor_102, avg_pool2d_backward_default_53);  slice_tensor_102 = avg_pool2d_backward_default_53 = None
        avg_pool2d_backward_default_54 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_106, getitem_152, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_106 = getitem_152 = None
        add_tensor_280 = torch.ops.aten.add.Tensor(add_tensor_279, avg_pool2d_backward_default_54);  add_tensor_279 = avg_pool2d_backward_default_54 = None
        add_tensor_281 = torch.ops.aten.add.Tensor(add_tensor_280, slice_tensor_105);  add_tensor_280 = None
        avg_pool2d_backward_default_55 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_105, getitem_155, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_105 = getitem_155 = None
        add_tensor_282 = torch.ops.aten.add.Tensor(add_tensor_278, avg_pool2d_backward_default_55);  add_tensor_278 = avg_pool2d_backward_default_55 = None
        clone_default_80 = torch.ops.aten.clone.default(slice_tensor_104, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_206 = torch.ops.aten.native_batch_norm_backward.default(clone_default_80, convolution_default_107, primals_874, primals_872, primals_873, getitem_180, getitem_181, True, 0.001, [True, True, True]);  clone_default_80 = convolution_default_107 = primals_874 = primals_872 = primals_873 = getitem_180 = getitem_181 = None
        getitem_2566 = native_batch_norm_backward_default_206[0]
        getitem_2567 = native_batch_norm_backward_default_206[1]
        getitem_2568 = native_batch_norm_backward_default_206[2];  native_batch_norm_backward_default_206 = None
        convolution_backward_default_380 = torch.ops.aten.convolution_backward.default(getitem_2566, convolution_default_106, primals_878, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2566 = convolution_default_106 = primals_878 = None
        getitem_2569 = convolution_backward_default_380[0]
        getitem_2570 = convolution_backward_default_380[1];  convolution_backward_default_380 = None
        convolution_backward_default_381 = torch.ops.aten.convolution_backward.default(getitem_2569, relu__default_23, primals_877, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2569 = primals_877 = None
        getitem_2572 = convolution_backward_default_381[0]
        getitem_2573 = convolution_backward_default_381[1];  convolution_backward_default_381 = None
        to_dtype_621 = torch.ops.aten.to.dtype(getitem_2572, torch.float32);  getitem_2572 = None
        to_dtype_622 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_207 = torch.ops.aten.le.Scalar(to_dtype_622, 0);  to_dtype_622 = None
        new_zeros_default_471 = torch.ops.aten.new_zeros.default(to_dtype_621, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_207 = torch.ops.aten.where.self(le_scalar_207, new_zeros_default_471, to_dtype_621);  le_scalar_207 = new_zeros_default_471 = to_dtype_621 = None
        to_dtype_623 = torch.ops.aten.to.dtype(where_self_207, torch.float32);  where_self_207 = None
        native_batch_norm_backward_default_207 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_623, convolution_default_105, primals_869, primals_867, primals_868, getitem_177, getitem_178, True, 0.001, [True, True, True]);  to_dtype_623 = convolution_default_105 = primals_869 = primals_867 = primals_868 = getitem_177 = getitem_178 = None
        getitem_2575 = native_batch_norm_backward_default_207[0]
        getitem_2576 = native_batch_norm_backward_default_207[1]
        getitem_2577 = native_batch_norm_backward_default_207[2];  native_batch_norm_backward_default_207 = None
        convolution_backward_default_382 = torch.ops.aten.convolution_backward.default(getitem_2575, convolution_default_104, primals_876, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2575 = convolution_default_104 = primals_876 = None
        getitem_2578 = convolution_backward_default_382[0]
        getitem_2579 = convolution_backward_default_382[1];  convolution_backward_default_382 = None
        convolution_backward_default_383 = torch.ops.aten.convolution_backward.default(getitem_2578, relu_default_32, primals_875, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2578 = primals_875 = None
        getitem_2581 = convolution_backward_default_383[0]
        getitem_2582 = convolution_backward_default_383[1];  convolution_backward_default_383 = None
        to_dtype_624 = torch.ops.aten.to.dtype(getitem_2581, torch.float32);  getitem_2581 = None
        to_dtype_625 = torch.ops.aten.to.dtype(relu_default_32, torch.float32);  relu_default_32 = None
        le_scalar_208 = torch.ops.aten.le.Scalar(to_dtype_625, 0);  to_dtype_625 = None
        new_zeros_default_472 = torch.ops.aten.new_zeros.default(to_dtype_624, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_208 = torch.ops.aten.where.self(le_scalar_208, new_zeros_default_472, to_dtype_624);  le_scalar_208 = new_zeros_default_472 = to_dtype_624 = None
        to_dtype_626 = torch.ops.aten.to.dtype(where_self_208, torch.float32);  where_self_208 = None
        add_tensor_283 = torch.ops.aten.add.Tensor(add_tensor_281, to_dtype_626);  add_tensor_281 = to_dtype_626 = None
        clone_default_81 = torch.ops.aten.clone.default(slice_tensor_104, memory_format = torch.contiguous_format);  slice_tensor_104 = None
        native_batch_norm_backward_default_208 = torch.ops.aten.native_batch_norm_backward.default(clone_default_81, convolution_default_103, primals_860, primals_858, primals_859, getitem_174, getitem_175, True, 0.001, [True, True, True]);  clone_default_81 = convolution_default_103 = primals_860 = primals_858 = primals_859 = getitem_174 = getitem_175 = None
        getitem_2584 = native_batch_norm_backward_default_208[0]
        getitem_2585 = native_batch_norm_backward_default_208[1]
        getitem_2586 = native_batch_norm_backward_default_208[2];  native_batch_norm_backward_default_208 = None
        convolution_backward_default_384 = torch.ops.aten.convolution_backward.default(getitem_2584, convolution_default_102, primals_864, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2584 = convolution_default_102 = primals_864 = None
        getitem_2587 = convolution_backward_default_384[0]
        getitem_2588 = convolution_backward_default_384[1];  convolution_backward_default_384 = None
        convolution_backward_default_385 = torch.ops.aten.convolution_backward.default(getitem_2587, relu__default_22, primals_863, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2587 = primals_863 = None
        getitem_2590 = convolution_backward_default_385[0]
        getitem_2591 = convolution_backward_default_385[1];  convolution_backward_default_385 = None
        to_dtype_627 = torch.ops.aten.to.dtype(getitem_2590, torch.float32);  getitem_2590 = None
        to_dtype_628 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_209 = torch.ops.aten.le.Scalar(to_dtype_628, 0);  to_dtype_628 = None
        new_zeros_default_473 = torch.ops.aten.new_zeros.default(to_dtype_627, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_209 = torch.ops.aten.where.self(le_scalar_209, new_zeros_default_473, to_dtype_627);  le_scalar_209 = new_zeros_default_473 = to_dtype_627 = None
        to_dtype_629 = torch.ops.aten.to.dtype(where_self_209, torch.float32);  where_self_209 = None
        native_batch_norm_backward_default_209 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_629, convolution_default_101, primals_855, primals_853, primals_854, getitem_171, getitem_172, True, 0.001, [True, True, True]);  to_dtype_629 = convolution_default_101 = primals_855 = primals_853 = primals_854 = getitem_171 = getitem_172 = None
        getitem_2593 = native_batch_norm_backward_default_209[0]
        getitem_2594 = native_batch_norm_backward_default_209[1]
        getitem_2595 = native_batch_norm_backward_default_209[2];  native_batch_norm_backward_default_209 = None
        convolution_backward_default_386 = torch.ops.aten.convolution_backward.default(getitem_2593, convolution_default_100, primals_862, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2593 = convolution_default_100 = primals_862 = None
        getitem_2596 = convolution_backward_default_386[0]
        getitem_2597 = convolution_backward_default_386[1];  convolution_backward_default_386 = None
        convolution_backward_default_387 = torch.ops.aten.convolution_backward.default(getitem_2596, relu_default_31, primals_861, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2596 = primals_861 = None
        getitem_2599 = convolution_backward_default_387[0]
        getitem_2600 = convolution_backward_default_387[1];  convolution_backward_default_387 = None
        to_dtype_630 = torch.ops.aten.to.dtype(getitem_2599, torch.float32);  getitem_2599 = None
        to_dtype_631 = torch.ops.aten.to.dtype(relu_default_31, torch.float32);  relu_default_31 = None
        le_scalar_210 = torch.ops.aten.le.Scalar(to_dtype_631, 0);  to_dtype_631 = None
        new_zeros_default_474 = torch.ops.aten.new_zeros.default(to_dtype_630, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_210 = torch.ops.aten.where.self(le_scalar_210, new_zeros_default_474, to_dtype_630);  le_scalar_210 = new_zeros_default_474 = to_dtype_630 = None
        to_dtype_632 = torch.ops.aten.to.dtype(where_self_210, torch.float32);  where_self_210 = None
        add_tensor_284 = torch.ops.aten.add.Tensor(add_tensor_283, to_dtype_632);  add_tensor_283 = to_dtype_632 = None
        clone_default_82 = torch.ops.aten.clone.default(slice_tensor_103, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_210 = torch.ops.aten.native_batch_norm_backward.default(clone_default_82, convolution_default_99, primals_846, primals_844, primals_845, getitem_168, getitem_169, True, 0.001, [True, True, True]);  clone_default_82 = convolution_default_99 = primals_846 = primals_844 = primals_845 = getitem_168 = getitem_169 = None
        getitem_2602 = native_batch_norm_backward_default_210[0]
        getitem_2603 = native_batch_norm_backward_default_210[1]
        getitem_2604 = native_batch_norm_backward_default_210[2];  native_batch_norm_backward_default_210 = None
        convolution_backward_default_388 = torch.ops.aten.convolution_backward.default(getitem_2602, convolution_default_98, primals_850, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2602 = convolution_default_98 = primals_850 = None
        getitem_2605 = convolution_backward_default_388[0]
        getitem_2606 = convolution_backward_default_388[1];  convolution_backward_default_388 = None
        convolution_backward_default_389 = torch.ops.aten.convolution_backward.default(getitem_2605, relu__default_21, primals_849, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2605 = primals_849 = None
        getitem_2608 = convolution_backward_default_389[0]
        getitem_2609 = convolution_backward_default_389[1];  convolution_backward_default_389 = None
        to_dtype_633 = torch.ops.aten.to.dtype(getitem_2608, torch.float32);  getitem_2608 = None
        to_dtype_634 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_211 = torch.ops.aten.le.Scalar(to_dtype_634, 0);  to_dtype_634 = None
        new_zeros_default_475 = torch.ops.aten.new_zeros.default(to_dtype_633, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_211 = torch.ops.aten.where.self(le_scalar_211, new_zeros_default_475, to_dtype_633);  le_scalar_211 = new_zeros_default_475 = to_dtype_633 = None
        to_dtype_635 = torch.ops.aten.to.dtype(where_self_211, torch.float32);  where_self_211 = None
        native_batch_norm_backward_default_211 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_635, convolution_default_97, primals_841, primals_839, primals_840, getitem_165, getitem_166, True, 0.001, [True, True, True]);  to_dtype_635 = convolution_default_97 = primals_841 = primals_839 = primals_840 = getitem_165 = getitem_166 = None
        getitem_2611 = native_batch_norm_backward_default_211[0]
        getitem_2612 = native_batch_norm_backward_default_211[1]
        getitem_2613 = native_batch_norm_backward_default_211[2];  native_batch_norm_backward_default_211 = None
        convolution_backward_default_390 = torch.ops.aten.convolution_backward.default(getitem_2611, convolution_default_96, primals_848, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2611 = convolution_default_96 = primals_848 = None
        getitem_2614 = convolution_backward_default_390[0]
        getitem_2615 = convolution_backward_default_390[1];  convolution_backward_default_390 = None
        convolution_backward_default_391 = torch.ops.aten.convolution_backward.default(getitem_2614, relu_default_30, primals_847, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2614 = primals_847 = None
        getitem_2617 = convolution_backward_default_391[0]
        getitem_2618 = convolution_backward_default_391[1];  convolution_backward_default_391 = None
        to_dtype_636 = torch.ops.aten.to.dtype(getitem_2617, torch.float32);  getitem_2617 = None
        to_dtype_637 = torch.ops.aten.to.dtype(relu_default_30, torch.float32);  relu_default_30 = None
        le_scalar_212 = torch.ops.aten.le.Scalar(to_dtype_637, 0);  to_dtype_637 = None
        new_zeros_default_476 = torch.ops.aten.new_zeros.default(to_dtype_636, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_212 = torch.ops.aten.where.self(le_scalar_212, new_zeros_default_476, to_dtype_636);  le_scalar_212 = new_zeros_default_476 = to_dtype_636 = None
        to_dtype_638 = torch.ops.aten.to.dtype(where_self_212, torch.float32);  where_self_212 = None
        add_tensor_285 = torch.ops.aten.add.Tensor(add_tensor_284, to_dtype_638);  add_tensor_284 = to_dtype_638 = None
        clone_default_83 = torch.ops.aten.clone.default(slice_tensor_103, memory_format = torch.contiguous_format);  slice_tensor_103 = None
        native_batch_norm_backward_default_212 = torch.ops.aten.native_batch_norm_backward.default(clone_default_83, convolution_default_95, primals_832, primals_830, primals_831, getitem_162, getitem_163, True, 0.001, [True, True, True]);  clone_default_83 = convolution_default_95 = primals_832 = primals_830 = primals_831 = getitem_162 = getitem_163 = None
        getitem_2620 = native_batch_norm_backward_default_212[0]
        getitem_2621 = native_batch_norm_backward_default_212[1]
        getitem_2622 = native_batch_norm_backward_default_212[2];  native_batch_norm_backward_default_212 = None
        convolution_backward_default_392 = torch.ops.aten.convolution_backward.default(getitem_2620, convolution_default_94, primals_836, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2620 = convolution_default_94 = primals_836 = None
        getitem_2623 = convolution_backward_default_392[0]
        getitem_2624 = convolution_backward_default_392[1];  convolution_backward_default_392 = None
        convolution_backward_default_393 = torch.ops.aten.convolution_backward.default(getitem_2623, relu__default_20, primals_835, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2623 = primals_835 = None
        getitem_2626 = convolution_backward_default_393[0]
        getitem_2627 = convolution_backward_default_393[1];  convolution_backward_default_393 = None
        to_dtype_639 = torch.ops.aten.to.dtype(getitem_2626, torch.float32);  getitem_2626 = None
        to_dtype_640 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_213 = torch.ops.aten.le.Scalar(to_dtype_640, 0);  to_dtype_640 = None
        new_zeros_default_477 = torch.ops.aten.new_zeros.default(to_dtype_639, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_213 = torch.ops.aten.where.self(le_scalar_213, new_zeros_default_477, to_dtype_639);  le_scalar_213 = new_zeros_default_477 = to_dtype_639 = None
        to_dtype_641 = torch.ops.aten.to.dtype(where_self_213, torch.float32);  where_self_213 = None
        native_batch_norm_backward_default_213 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_641, convolution_default_93, primals_827, primals_825, primals_826, getitem_159, getitem_160, True, 0.001, [True, True, True]);  to_dtype_641 = convolution_default_93 = primals_827 = primals_825 = primals_826 = getitem_159 = getitem_160 = None
        getitem_2629 = native_batch_norm_backward_default_213[0]
        getitem_2630 = native_batch_norm_backward_default_213[1]
        getitem_2631 = native_batch_norm_backward_default_213[2];  native_batch_norm_backward_default_213 = None
        convolution_backward_default_394 = torch.ops.aten.convolution_backward.default(getitem_2629, convolution_default_92, primals_834, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2629 = convolution_default_92 = primals_834 = None
        getitem_2632 = convolution_backward_default_394[0]
        getitem_2633 = convolution_backward_default_394[1];  convolution_backward_default_394 = None
        convolution_backward_default_395 = torch.ops.aten.convolution_backward.default(getitem_2632, relu_default_29, primals_833, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2632 = primals_833 = None
        getitem_2635 = convolution_backward_default_395[0]
        getitem_2636 = convolution_backward_default_395[1];  convolution_backward_default_395 = None
        to_dtype_642 = torch.ops.aten.to.dtype(getitem_2635, torch.float32);  getitem_2635 = None
        to_dtype_643 = torch.ops.aten.to.dtype(relu_default_29, torch.float32);  relu_default_29 = None
        le_scalar_214 = torch.ops.aten.le.Scalar(to_dtype_643, 0);  to_dtype_643 = None
        new_zeros_default_478 = torch.ops.aten.new_zeros.default(to_dtype_642, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_214 = torch.ops.aten.where.self(le_scalar_214, new_zeros_default_478, to_dtype_642);  le_scalar_214 = new_zeros_default_478 = to_dtype_642 = None
        to_dtype_644 = torch.ops.aten.to.dtype(where_self_214, torch.float32);  where_self_214 = None
        add_tensor_286 = torch.ops.aten.add.Tensor(add_tensor_282, to_dtype_644);  add_tensor_282 = to_dtype_644 = None
        native_batch_norm_backward_default_214 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_286, convolution_default_91, primals_897, primals_895, primals_896, getitem_156, getitem_157, True, 0.001, [True, True, True]);  add_tensor_286 = convolution_default_91 = primals_897 = primals_895 = primals_896 = getitem_156 = getitem_157 = None
        getitem_2638 = native_batch_norm_backward_default_214[0]
        getitem_2639 = native_batch_norm_backward_default_214[1]
        getitem_2640 = native_batch_norm_backward_default_214[2];  native_batch_norm_backward_default_214 = None
        convolution_backward_default_396 = torch.ops.aten.convolution_backward.default(getitem_2638, relu_default_28, primals_898, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2638 = primals_898 = None
        getitem_2641 = convolution_backward_default_396[0]
        getitem_2642 = convolution_backward_default_396[1];  convolution_backward_default_396 = None
        to_dtype_645 = torch.ops.aten.to.dtype(getitem_2641, torch.float32);  getitem_2641 = None
        to_dtype_646 = torch.ops.aten.to.dtype(relu_default_28, torch.float32);  relu_default_28 = None
        le_scalar_215 = torch.ops.aten.le.Scalar(to_dtype_646, 0);  to_dtype_646 = None
        new_zeros_default_479 = torch.ops.aten.new_zeros.default(to_dtype_645, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_215 = torch.ops.aten.where.self(le_scalar_215, new_zeros_default_479, to_dtype_645);  le_scalar_215 = new_zeros_default_479 = to_dtype_645 = None
        to_dtype_647 = torch.ops.aten.to.dtype(where_self_215, torch.float32);  where_self_215 = None
        add_tensor_287 = torch.ops.aten.add.Tensor(to_dtype_614, to_dtype_647);  to_dtype_614 = to_dtype_647 = None
        native_batch_norm_backward_default_215 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_285, convolution_default_90, primals_903, primals_901, primals_902, getitem_153, getitem_154, True, 0.001, [True, True, True]);  add_tensor_285 = convolution_default_90 = primals_903 = primals_901 = primals_902 = getitem_153 = getitem_154 = None
        getitem_2644 = native_batch_norm_backward_default_215[0]
        getitem_2645 = native_batch_norm_backward_default_215[1]
        getitem_2646 = native_batch_norm_backward_default_215[2];  native_batch_norm_backward_default_215 = None
        convolution_backward_default_397 = torch.ops.aten.convolution_backward.default(getitem_2644, relu_default_27, primals_904, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2644 = primals_904 = None
        getitem_2647 = convolution_backward_default_397[0]
        getitem_2648 = convolution_backward_default_397[1];  convolution_backward_default_397 = None
        to_dtype_648 = torch.ops.aten.to.dtype(getitem_2647, torch.float32);  getitem_2647 = None
        to_dtype_649 = torch.ops.aten.to.dtype(relu_default_27, torch.float32);  relu_default_27 = None
        le_scalar_216 = torch.ops.aten.le.Scalar(to_dtype_649, 0);  to_dtype_649 = None
        new_zeros_default_480 = torch.ops.aten.new_zeros.default(to_dtype_648, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_216 = torch.ops.aten.where.self(le_scalar_216, new_zeros_default_480, to_dtype_648);  le_scalar_216 = new_zeros_default_480 = to_dtype_648 = None
        to_dtype_650 = torch.ops.aten.to.dtype(where_self_216, torch.float32);  where_self_216 = None
        slice_tensor_108 = torch.ops.aten.slice.Tensor(add_tensor_287, 1, 0, 168)
        slice_tensor_109 = torch.ops.aten.slice.Tensor(add_tensor_287, 1, 168, 336)
        slice_tensor_110 = torch.ops.aten.slice.Tensor(add_tensor_287, 1, 336, 504)
        slice_tensor_111 = torch.ops.aten.slice.Tensor(add_tensor_287, 1, 504, 672)
        slice_tensor_112 = torch.ops.aten.slice.Tensor(add_tensor_287, 1, 672, 840)
        slice_tensor_113 = torch.ops.aten.slice.Tensor(add_tensor_287, 1, 840, 1008);  add_tensor_287 = None
        clone_default_84 = torch.ops.aten.clone.default(slice_tensor_113, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_216 = torch.ops.aten.native_batch_norm_backward.default(clone_default_84, convolution_default_89, primals_806, primals_804, primals_805, getitem_150, getitem_151, True, 0.001, [True, True, True]);  clone_default_84 = convolution_default_89 = primals_806 = primals_804 = primals_805 = getitem_150 = getitem_151 = None
        getitem_2650 = native_batch_norm_backward_default_216[0]
        getitem_2651 = native_batch_norm_backward_default_216[1]
        getitem_2652 = native_batch_norm_backward_default_216[2];  native_batch_norm_backward_default_216 = None
        convolution_backward_default_398 = torch.ops.aten.convolution_backward.default(getitem_2650, convolution_default_88, primals_810, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2650 = convolution_default_88 = primals_810 = None
        getitem_2653 = convolution_backward_default_398[0]
        getitem_2654 = convolution_backward_default_398[1];  convolution_backward_default_398 = None
        convolution_backward_default_399 = torch.ops.aten.convolution_backward.default(getitem_2653, relu__default_19, primals_809, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2653 = primals_809 = None
        getitem_2656 = convolution_backward_default_399[0]
        getitem_2657 = convolution_backward_default_399[1];  convolution_backward_default_399 = None
        to_dtype_651 = torch.ops.aten.to.dtype(getitem_2656, torch.float32);  getitem_2656 = None
        to_dtype_652 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_217 = torch.ops.aten.le.Scalar(to_dtype_652, 0);  to_dtype_652 = None
        new_zeros_default_481 = torch.ops.aten.new_zeros.default(to_dtype_651, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_217 = torch.ops.aten.where.self(le_scalar_217, new_zeros_default_481, to_dtype_651);  le_scalar_217 = new_zeros_default_481 = to_dtype_651 = None
        to_dtype_653 = torch.ops.aten.to.dtype(where_self_217, torch.float32);  where_self_217 = None
        native_batch_norm_backward_default_217 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_653, convolution_default_87, primals_801, primals_799, primals_800, getitem_147, getitem_148, True, 0.001, [True, True, True]);  to_dtype_653 = convolution_default_87 = primals_801 = primals_799 = primals_800 = getitem_147 = getitem_148 = None
        getitem_2659 = native_batch_norm_backward_default_217[0]
        getitem_2660 = native_batch_norm_backward_default_217[1]
        getitem_2661 = native_batch_norm_backward_default_217[2];  native_batch_norm_backward_default_217 = None
        convolution_backward_default_400 = torch.ops.aten.convolution_backward.default(getitem_2659, convolution_default_86, primals_808, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2659 = convolution_default_86 = primals_808 = None
        getitem_2662 = convolution_backward_default_400[0]
        getitem_2663 = convolution_backward_default_400[1];  convolution_backward_default_400 = None
        convolution_backward_default_401 = torch.ops.aten.convolution_backward.default(getitem_2662, relu_default_26, primals_807, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2662 = primals_807 = None
        getitem_2665 = convolution_backward_default_401[0]
        getitem_2666 = convolution_backward_default_401[1];  convolution_backward_default_401 = None
        to_dtype_654 = torch.ops.aten.to.dtype(getitem_2665, torch.float32);  getitem_2665 = None
        to_dtype_655 = torch.ops.aten.to.dtype(relu_default_26, torch.float32);  relu_default_26 = None
        le_scalar_218 = torch.ops.aten.le.Scalar(to_dtype_655, 0);  to_dtype_655 = None
        new_zeros_default_482 = torch.ops.aten.new_zeros.default(to_dtype_654, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_218 = torch.ops.aten.where.self(le_scalar_218, new_zeros_default_482, to_dtype_654);  le_scalar_218 = new_zeros_default_482 = to_dtype_654 = None
        to_dtype_656 = torch.ops.aten.to.dtype(where_self_218, torch.float32);  where_self_218 = None
        add_tensor_288 = torch.ops.aten.add.Tensor(slice_tensor_113, to_dtype_656);  slice_tensor_113 = to_dtype_656 = None
        avg_pool2d_backward_default_56 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_112, getitem_116, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_289 = torch.ops.aten.add.Tensor(slice_tensor_108, avg_pool2d_backward_default_56);  slice_tensor_108 = avg_pool2d_backward_default_56 = None
        avg_pool2d_backward_default_57 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_112, getitem_116, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_112 = getitem_116 = None
        add_tensor_290 = torch.ops.aten.add.Tensor(add_tensor_289, avg_pool2d_backward_default_57);  add_tensor_289 = avg_pool2d_backward_default_57 = None
        add_tensor_291 = torch.ops.aten.add.Tensor(add_tensor_290, slice_tensor_111);  add_tensor_290 = None
        avg_pool2d_backward_default_58 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_111, getitem_119, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_111 = getitem_119 = None
        add_tensor_292 = torch.ops.aten.add.Tensor(add_tensor_288, avg_pool2d_backward_default_58);  add_tensor_288 = avg_pool2d_backward_default_58 = None
        clone_default_85 = torch.ops.aten.clone.default(slice_tensor_110, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_218 = torch.ops.aten.native_batch_norm_backward.default(clone_default_85, convolution_default_85, primals_792, primals_790, primals_791, getitem_144, getitem_145, True, 0.001, [True, True, True]);  clone_default_85 = convolution_default_85 = primals_792 = primals_790 = primals_791 = getitem_144 = getitem_145 = None
        getitem_2668 = native_batch_norm_backward_default_218[0]
        getitem_2669 = native_batch_norm_backward_default_218[1]
        getitem_2670 = native_batch_norm_backward_default_218[2];  native_batch_norm_backward_default_218 = None
        convolution_backward_default_402 = torch.ops.aten.convolution_backward.default(getitem_2668, convolution_default_84, primals_796, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2668 = convolution_default_84 = primals_796 = None
        getitem_2671 = convolution_backward_default_402[0]
        getitem_2672 = convolution_backward_default_402[1];  convolution_backward_default_402 = None
        convolution_backward_default_403 = torch.ops.aten.convolution_backward.default(getitem_2671, relu__default_18, primals_795, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2671 = primals_795 = None
        getitem_2674 = convolution_backward_default_403[0]
        getitem_2675 = convolution_backward_default_403[1];  convolution_backward_default_403 = None
        to_dtype_657 = torch.ops.aten.to.dtype(getitem_2674, torch.float32);  getitem_2674 = None
        to_dtype_658 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_219 = torch.ops.aten.le.Scalar(to_dtype_658, 0);  to_dtype_658 = None
        new_zeros_default_483 = torch.ops.aten.new_zeros.default(to_dtype_657, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_219 = torch.ops.aten.where.self(le_scalar_219, new_zeros_default_483, to_dtype_657);  le_scalar_219 = new_zeros_default_483 = to_dtype_657 = None
        to_dtype_659 = torch.ops.aten.to.dtype(where_self_219, torch.float32);  where_self_219 = None
        native_batch_norm_backward_default_219 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_659, convolution_default_83, primals_787, primals_785, primals_786, getitem_141, getitem_142, True, 0.001, [True, True, True]);  to_dtype_659 = convolution_default_83 = primals_787 = primals_785 = primals_786 = getitem_141 = getitem_142 = None
        getitem_2677 = native_batch_norm_backward_default_219[0]
        getitem_2678 = native_batch_norm_backward_default_219[1]
        getitem_2679 = native_batch_norm_backward_default_219[2];  native_batch_norm_backward_default_219 = None
        convolution_backward_default_404 = torch.ops.aten.convolution_backward.default(getitem_2677, convolution_default_82, primals_794, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2677 = convolution_default_82 = primals_794 = None
        getitem_2680 = convolution_backward_default_404[0]
        getitem_2681 = convolution_backward_default_404[1];  convolution_backward_default_404 = None
        convolution_backward_default_405 = torch.ops.aten.convolution_backward.default(getitem_2680, relu_default_25, primals_793, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2680 = primals_793 = None
        getitem_2683 = convolution_backward_default_405[0]
        getitem_2684 = convolution_backward_default_405[1];  convolution_backward_default_405 = None
        to_dtype_660 = torch.ops.aten.to.dtype(getitem_2683, torch.float32);  getitem_2683 = None
        to_dtype_661 = torch.ops.aten.to.dtype(relu_default_25, torch.float32);  relu_default_25 = None
        le_scalar_220 = torch.ops.aten.le.Scalar(to_dtype_661, 0);  to_dtype_661 = None
        new_zeros_default_484 = torch.ops.aten.new_zeros.default(to_dtype_660, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_220 = torch.ops.aten.where.self(le_scalar_220, new_zeros_default_484, to_dtype_660);  le_scalar_220 = new_zeros_default_484 = to_dtype_660 = None
        to_dtype_662 = torch.ops.aten.to.dtype(where_self_220, torch.float32);  where_self_220 = None
        add_tensor_293 = torch.ops.aten.add.Tensor(add_tensor_291, to_dtype_662);  add_tensor_291 = to_dtype_662 = None
        clone_default_86 = torch.ops.aten.clone.default(slice_tensor_110, memory_format = torch.contiguous_format);  slice_tensor_110 = None
        native_batch_norm_backward_default_220 = torch.ops.aten.native_batch_norm_backward.default(clone_default_86, convolution_default_81, primals_778, primals_776, primals_777, getitem_138, getitem_139, True, 0.001, [True, True, True]);  clone_default_86 = convolution_default_81 = primals_778 = primals_776 = primals_777 = getitem_138 = getitem_139 = None
        getitem_2686 = native_batch_norm_backward_default_220[0]
        getitem_2687 = native_batch_norm_backward_default_220[1]
        getitem_2688 = native_batch_norm_backward_default_220[2];  native_batch_norm_backward_default_220 = None
        convolution_backward_default_406 = torch.ops.aten.convolution_backward.default(getitem_2686, convolution_default_80, primals_782, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2686 = convolution_default_80 = primals_782 = None
        getitem_2689 = convolution_backward_default_406[0]
        getitem_2690 = convolution_backward_default_406[1];  convolution_backward_default_406 = None
        convolution_backward_default_407 = torch.ops.aten.convolution_backward.default(getitem_2689, relu__default_17, primals_781, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2689 = primals_781 = None
        getitem_2692 = convolution_backward_default_407[0]
        getitem_2693 = convolution_backward_default_407[1];  convolution_backward_default_407 = None
        to_dtype_663 = torch.ops.aten.to.dtype(getitem_2692, torch.float32);  getitem_2692 = None
        to_dtype_664 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_221 = torch.ops.aten.le.Scalar(to_dtype_664, 0);  to_dtype_664 = None
        new_zeros_default_485 = torch.ops.aten.new_zeros.default(to_dtype_663, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_221 = torch.ops.aten.where.self(le_scalar_221, new_zeros_default_485, to_dtype_663);  le_scalar_221 = new_zeros_default_485 = to_dtype_663 = None
        to_dtype_665 = torch.ops.aten.to.dtype(where_self_221, torch.float32);  where_self_221 = None
        native_batch_norm_backward_default_221 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_665, convolution_default_79, primals_773, primals_771, primals_772, getitem_135, getitem_136, True, 0.001, [True, True, True]);  to_dtype_665 = convolution_default_79 = primals_773 = primals_771 = primals_772 = getitem_135 = getitem_136 = None
        getitem_2695 = native_batch_norm_backward_default_221[0]
        getitem_2696 = native_batch_norm_backward_default_221[1]
        getitem_2697 = native_batch_norm_backward_default_221[2];  native_batch_norm_backward_default_221 = None
        convolution_backward_default_408 = torch.ops.aten.convolution_backward.default(getitem_2695, convolution_default_78, primals_780, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2695 = convolution_default_78 = primals_780 = None
        getitem_2698 = convolution_backward_default_408[0]
        getitem_2699 = convolution_backward_default_408[1];  convolution_backward_default_408 = None
        convolution_backward_default_409 = torch.ops.aten.convolution_backward.default(getitem_2698, relu_default_24, primals_779, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2698 = primals_779 = None
        getitem_2701 = convolution_backward_default_409[0]
        getitem_2702 = convolution_backward_default_409[1];  convolution_backward_default_409 = None
        to_dtype_666 = torch.ops.aten.to.dtype(getitem_2701, torch.float32);  getitem_2701 = None
        to_dtype_667 = torch.ops.aten.to.dtype(relu_default_24, torch.float32);  relu_default_24 = None
        le_scalar_222 = torch.ops.aten.le.Scalar(to_dtype_667, 0);  to_dtype_667 = None
        new_zeros_default_486 = torch.ops.aten.new_zeros.default(to_dtype_666, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_222 = torch.ops.aten.where.self(le_scalar_222, new_zeros_default_486, to_dtype_666);  le_scalar_222 = new_zeros_default_486 = to_dtype_666 = None
        to_dtype_668 = torch.ops.aten.to.dtype(where_self_222, torch.float32);  where_self_222 = None
        add_tensor_294 = torch.ops.aten.add.Tensor(add_tensor_293, to_dtype_668);  add_tensor_293 = to_dtype_668 = None
        clone_default_87 = torch.ops.aten.clone.default(slice_tensor_109, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_222 = torch.ops.aten.native_batch_norm_backward.default(clone_default_87, convolution_default_77, primals_764, primals_762, primals_763, getitem_132, getitem_133, True, 0.001, [True, True, True]);  clone_default_87 = convolution_default_77 = primals_764 = primals_762 = primals_763 = getitem_132 = getitem_133 = None
        getitem_2704 = native_batch_norm_backward_default_222[0]
        getitem_2705 = native_batch_norm_backward_default_222[1]
        getitem_2706 = native_batch_norm_backward_default_222[2];  native_batch_norm_backward_default_222 = None
        convolution_backward_default_410 = torch.ops.aten.convolution_backward.default(getitem_2704, convolution_default_76, primals_768, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2704 = convolution_default_76 = primals_768 = None
        getitem_2707 = convolution_backward_default_410[0]
        getitem_2708 = convolution_backward_default_410[1];  convolution_backward_default_410 = None
        convolution_backward_default_411 = torch.ops.aten.convolution_backward.default(getitem_2707, relu__default_16, primals_767, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2707 = primals_767 = None
        getitem_2710 = convolution_backward_default_411[0]
        getitem_2711 = convolution_backward_default_411[1];  convolution_backward_default_411 = None
        to_dtype_669 = torch.ops.aten.to.dtype(getitem_2710, torch.float32);  getitem_2710 = None
        to_dtype_670 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_223 = torch.ops.aten.le.Scalar(to_dtype_670, 0);  to_dtype_670 = None
        new_zeros_default_487 = torch.ops.aten.new_zeros.default(to_dtype_669, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_223 = torch.ops.aten.where.self(le_scalar_223, new_zeros_default_487, to_dtype_669);  le_scalar_223 = new_zeros_default_487 = to_dtype_669 = None
        to_dtype_671 = torch.ops.aten.to.dtype(where_self_223, torch.float32);  where_self_223 = None
        native_batch_norm_backward_default_223 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_671, convolution_default_75, primals_759, primals_757, primals_758, getitem_129, getitem_130, True, 0.001, [True, True, True]);  to_dtype_671 = convolution_default_75 = primals_759 = primals_757 = primals_758 = getitem_129 = getitem_130 = None
        getitem_2713 = native_batch_norm_backward_default_223[0]
        getitem_2714 = native_batch_norm_backward_default_223[1]
        getitem_2715 = native_batch_norm_backward_default_223[2];  native_batch_norm_backward_default_223 = None
        convolution_backward_default_412 = torch.ops.aten.convolution_backward.default(getitem_2713, convolution_default_74, primals_766, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2713 = convolution_default_74 = primals_766 = None
        getitem_2716 = convolution_backward_default_412[0]
        getitem_2717 = convolution_backward_default_412[1];  convolution_backward_default_412 = None
        convolution_backward_default_413 = torch.ops.aten.convolution_backward.default(getitem_2716, relu_default_23, primals_765, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2716 = primals_765 = None
        getitem_2719 = convolution_backward_default_413[0]
        getitem_2720 = convolution_backward_default_413[1];  convolution_backward_default_413 = None
        to_dtype_672 = torch.ops.aten.to.dtype(getitem_2719, torch.float32);  getitem_2719 = None
        to_dtype_673 = torch.ops.aten.to.dtype(relu_default_23, torch.float32);  relu_default_23 = None
        le_scalar_224 = torch.ops.aten.le.Scalar(to_dtype_673, 0);  to_dtype_673 = None
        new_zeros_default_488 = torch.ops.aten.new_zeros.default(to_dtype_672, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_224 = torch.ops.aten.where.self(le_scalar_224, new_zeros_default_488, to_dtype_672);  le_scalar_224 = new_zeros_default_488 = to_dtype_672 = None
        to_dtype_674 = torch.ops.aten.to.dtype(where_self_224, torch.float32);  where_self_224 = None
        add_tensor_295 = torch.ops.aten.add.Tensor(add_tensor_294, to_dtype_674);  add_tensor_294 = to_dtype_674 = None
        clone_default_88 = torch.ops.aten.clone.default(slice_tensor_109, memory_format = torch.contiguous_format);  slice_tensor_109 = None
        native_batch_norm_backward_default_224 = torch.ops.aten.native_batch_norm_backward.default(clone_default_88, convolution_default_73, primals_750, primals_748, primals_749, getitem_126, getitem_127, True, 0.001, [True, True, True]);  clone_default_88 = convolution_default_73 = primals_750 = primals_748 = primals_749 = getitem_126 = getitem_127 = None
        getitem_2722 = native_batch_norm_backward_default_224[0]
        getitem_2723 = native_batch_norm_backward_default_224[1]
        getitem_2724 = native_batch_norm_backward_default_224[2];  native_batch_norm_backward_default_224 = None
        convolution_backward_default_414 = torch.ops.aten.convolution_backward.default(getitem_2722, convolution_default_72, primals_754, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2722 = convolution_default_72 = primals_754 = None
        getitem_2725 = convolution_backward_default_414[0]
        getitem_2726 = convolution_backward_default_414[1];  convolution_backward_default_414 = None
        convolution_backward_default_415 = torch.ops.aten.convolution_backward.default(getitem_2725, relu__default_15, primals_753, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2725 = primals_753 = None
        getitem_2728 = convolution_backward_default_415[0]
        getitem_2729 = convolution_backward_default_415[1];  convolution_backward_default_415 = None
        to_dtype_675 = torch.ops.aten.to.dtype(getitem_2728, torch.float32);  getitem_2728 = None
        to_dtype_676 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_225 = torch.ops.aten.le.Scalar(to_dtype_676, 0);  to_dtype_676 = None
        new_zeros_default_489 = torch.ops.aten.new_zeros.default(to_dtype_675, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_225 = torch.ops.aten.where.self(le_scalar_225, new_zeros_default_489, to_dtype_675);  le_scalar_225 = new_zeros_default_489 = to_dtype_675 = None
        to_dtype_677 = torch.ops.aten.to.dtype(where_self_225, torch.float32);  where_self_225 = None
        native_batch_norm_backward_default_225 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_677, convolution_default_71, primals_745, primals_743, primals_744, getitem_123, getitem_124, True, 0.001, [True, True, True]);  to_dtype_677 = convolution_default_71 = primals_745 = primals_743 = primals_744 = getitem_123 = getitem_124 = None
        getitem_2731 = native_batch_norm_backward_default_225[0]
        getitem_2732 = native_batch_norm_backward_default_225[1]
        getitem_2733 = native_batch_norm_backward_default_225[2];  native_batch_norm_backward_default_225 = None
        convolution_backward_default_416 = torch.ops.aten.convolution_backward.default(getitem_2731, convolution_default_70, primals_752, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2731 = convolution_default_70 = primals_752 = None
        getitem_2734 = convolution_backward_default_416[0]
        getitem_2735 = convolution_backward_default_416[1];  convolution_backward_default_416 = None
        convolution_backward_default_417 = torch.ops.aten.convolution_backward.default(getitem_2734, relu_default_22, primals_751, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2734 = primals_751 = None
        getitem_2737 = convolution_backward_default_417[0]
        getitem_2738 = convolution_backward_default_417[1];  convolution_backward_default_417 = None
        to_dtype_678 = torch.ops.aten.to.dtype(getitem_2737, torch.float32);  getitem_2737 = None
        to_dtype_679 = torch.ops.aten.to.dtype(relu_default_22, torch.float32);  relu_default_22 = None
        le_scalar_226 = torch.ops.aten.le.Scalar(to_dtype_679, 0);  to_dtype_679 = None
        new_zeros_default_490 = torch.ops.aten.new_zeros.default(to_dtype_678, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_226 = torch.ops.aten.where.self(le_scalar_226, new_zeros_default_490, to_dtype_678);  le_scalar_226 = new_zeros_default_490 = to_dtype_678 = None
        to_dtype_680 = torch.ops.aten.to.dtype(where_self_226, torch.float32);  where_self_226 = None
        add_tensor_296 = torch.ops.aten.add.Tensor(add_tensor_292, to_dtype_680);  add_tensor_292 = to_dtype_680 = None
        native_batch_norm_backward_default_226 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_296, convolution_default_69, primals_815, primals_813, primals_814, getitem_120, getitem_121, True, 0.001, [True, True, True]);  add_tensor_296 = convolution_default_69 = primals_815 = primals_813 = primals_814 = getitem_120 = getitem_121 = None
        getitem_2740 = native_batch_norm_backward_default_226[0]
        getitem_2741 = native_batch_norm_backward_default_226[1]
        getitem_2742 = native_batch_norm_backward_default_226[2];  native_batch_norm_backward_default_226 = None
        convolution_backward_default_418 = torch.ops.aten.convolution_backward.default(getitem_2740, relu_default_21, primals_816, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2740 = primals_816 = None
        getitem_2743 = convolution_backward_default_418[0]
        getitem_2744 = convolution_backward_default_418[1];  convolution_backward_default_418 = None
        to_dtype_681 = torch.ops.aten.to.dtype(getitem_2743, torch.float32);  getitem_2743 = None
        to_dtype_682 = torch.ops.aten.to.dtype(relu_default_21, torch.float32);  relu_default_21 = None
        le_scalar_227 = torch.ops.aten.le.Scalar(to_dtype_682, 0);  to_dtype_682 = None
        new_zeros_default_491 = torch.ops.aten.new_zeros.default(to_dtype_681, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_227 = torch.ops.aten.where.self(le_scalar_227, new_zeros_default_491, to_dtype_681);  le_scalar_227 = new_zeros_default_491 = to_dtype_681 = None
        to_dtype_683 = torch.ops.aten.to.dtype(where_self_227, torch.float32);  where_self_227 = None
        add_tensor_297 = torch.ops.aten.add.Tensor(to_dtype_650, to_dtype_683);  to_dtype_650 = to_dtype_683 = None
        native_batch_norm_backward_default_227 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_295, convolution_default_68, primals_821, primals_819, primals_820, getitem_117, getitem_118, True, 0.001, [True, True, True]);  add_tensor_295 = convolution_default_68 = primals_821 = primals_819 = primals_820 = getitem_117 = getitem_118 = None
        getitem_2746 = native_batch_norm_backward_default_227[0]
        getitem_2747 = native_batch_norm_backward_default_227[1]
        getitem_2748 = native_batch_norm_backward_default_227[2];  native_batch_norm_backward_default_227 = None
        convolution_backward_default_419 = torch.ops.aten.convolution_backward.default(getitem_2746, relu_default_20, primals_822, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2746 = primals_822 = None
        getitem_2749 = convolution_backward_default_419[0]
        getitem_2750 = convolution_backward_default_419[1];  convolution_backward_default_419 = None
        to_dtype_684 = torch.ops.aten.to.dtype(getitem_2749, torch.float32);  getitem_2749 = None
        to_dtype_685 = torch.ops.aten.to.dtype(relu_default_20, torch.float32);  relu_default_20 = None
        le_scalar_228 = torch.ops.aten.le.Scalar(to_dtype_685, 0);  to_dtype_685 = None
        new_zeros_default_492 = torch.ops.aten.new_zeros.default(to_dtype_684, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_228 = torch.ops.aten.where.self(le_scalar_228, new_zeros_default_492, to_dtype_684);  le_scalar_228 = new_zeros_default_492 = to_dtype_684 = None
        to_dtype_686 = torch.ops.aten.to.dtype(where_self_228, torch.float32);  where_self_228 = None
        slice_tensor_114 = torch.ops.aten.slice.Tensor(add_tensor_297, 1, 0, 168)
        slice_tensor_115 = torch.ops.aten.slice.Tensor(add_tensor_297, 1, 168, 336)
        slice_tensor_116 = torch.ops.aten.slice.Tensor(add_tensor_297, 1, 336, 504)
        slice_tensor_117 = torch.ops.aten.slice.Tensor(add_tensor_297, 1, 504, 672)
        slice_tensor_118 = torch.ops.aten.slice.Tensor(add_tensor_297, 1, 672, 840)
        slice_tensor_119 = torch.ops.aten.slice.Tensor(add_tensor_297, 1, 840, 1008);  add_tensor_297 = None
        clone_default_89 = torch.ops.aten.clone.default(slice_tensor_119, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_228 = torch.ops.aten.native_batch_norm_backward.default(clone_default_89, convolution_default_67, primals_66, primals_64, primals_65, getitem_114, getitem_115, True, 0.001, [True, True, True]);  clone_default_89 = convolution_default_67 = primals_66 = primals_64 = primals_65 = getitem_114 = getitem_115 = None
        getitem_2752 = native_batch_norm_backward_default_228[0]
        getitem_2753 = native_batch_norm_backward_default_228[1]
        getitem_2754 = native_batch_norm_backward_default_228[2];  native_batch_norm_backward_default_228 = None
        convolution_backward_default_420 = torch.ops.aten.convolution_backward.default(getitem_2752, convolution_default_66, primals_70, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2752 = convolution_default_66 = primals_70 = None
        getitem_2755 = convolution_backward_default_420[0]
        getitem_2756 = convolution_backward_default_420[1];  convolution_backward_default_420 = None
        convolution_backward_default_421 = torch.ops.aten.convolution_backward.default(getitem_2755, relu__default_14, primals_69, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2755 = primals_69 = None
        getitem_2758 = convolution_backward_default_421[0]
        getitem_2759 = convolution_backward_default_421[1];  convolution_backward_default_421 = None
        to_dtype_687 = torch.ops.aten.to.dtype(getitem_2758, torch.float32);  getitem_2758 = None
        to_dtype_688 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_229 = torch.ops.aten.le.Scalar(to_dtype_688, 0);  to_dtype_688 = None
        new_zeros_default_493 = torch.ops.aten.new_zeros.default(to_dtype_687, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_229 = torch.ops.aten.where.self(le_scalar_229, new_zeros_default_493, to_dtype_687);  le_scalar_229 = new_zeros_default_493 = to_dtype_687 = None
        to_dtype_689 = torch.ops.aten.to.dtype(where_self_229, torch.float32);  where_self_229 = None
        native_batch_norm_backward_default_229 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_689, convolution_default_65, primals_61, primals_59, primals_60, getitem_111, getitem_112, True, 0.001, [True, True, True]);  to_dtype_689 = convolution_default_65 = primals_61 = primals_59 = primals_60 = getitem_111 = getitem_112 = None
        getitem_2761 = native_batch_norm_backward_default_229[0]
        getitem_2762 = native_batch_norm_backward_default_229[1]
        getitem_2763 = native_batch_norm_backward_default_229[2];  native_batch_norm_backward_default_229 = None
        convolution_backward_default_422 = torch.ops.aten.convolution_backward.default(getitem_2761, convolution_default_64, primals_68, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2761 = convolution_default_64 = primals_68 = None
        getitem_2764 = convolution_backward_default_422[0]
        getitem_2765 = convolution_backward_default_422[1];  convolution_backward_default_422 = None
        convolution_backward_default_423 = torch.ops.aten.convolution_backward.default(getitem_2764, relu_default_19, primals_67, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2764 = primals_67 = None
        getitem_2767 = convolution_backward_default_423[0]
        getitem_2768 = convolution_backward_default_423[1];  convolution_backward_default_423 = None
        to_dtype_690 = torch.ops.aten.to.dtype(getitem_2767, torch.float32);  getitem_2767 = None
        to_dtype_691 = torch.ops.aten.to.dtype(relu_default_19, torch.float32);  relu_default_19 = None
        le_scalar_230 = torch.ops.aten.le.Scalar(to_dtype_691, 0);  to_dtype_691 = None
        new_zeros_default_494 = torch.ops.aten.new_zeros.default(to_dtype_690, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_230 = torch.ops.aten.where.self(le_scalar_230, new_zeros_default_494, to_dtype_690);  le_scalar_230 = new_zeros_default_494 = to_dtype_690 = None
        to_dtype_692 = torch.ops.aten.to.dtype(where_self_230, torch.float32);  where_self_230 = None
        add_tensor_298 = torch.ops.aten.add.Tensor(slice_tensor_119, to_dtype_692);  slice_tensor_119 = to_dtype_692 = None
        avg_pool2d_backward_default_59 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_118, getitem_80, [3, 3], [1, 1], [1, 1], False, False, None)
        add_tensor_299 = torch.ops.aten.add.Tensor(slice_tensor_114, avg_pool2d_backward_default_59);  slice_tensor_114 = avg_pool2d_backward_default_59 = None
        avg_pool2d_backward_default_60 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_118, getitem_80, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_118 = getitem_80 = None
        add_tensor_300 = torch.ops.aten.add.Tensor(add_tensor_299, avg_pool2d_backward_default_60);  add_tensor_299 = avg_pool2d_backward_default_60 = None
        add_tensor_301 = torch.ops.aten.add.Tensor(add_tensor_300, slice_tensor_117);  add_tensor_300 = None
        avg_pool2d_backward_default_61 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_117, getitem_83, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_117 = getitem_83 = None
        add_tensor_302 = torch.ops.aten.add.Tensor(add_tensor_298, avg_pool2d_backward_default_61);  add_tensor_298 = avg_pool2d_backward_default_61 = None
        clone_default_90 = torch.ops.aten.clone.default(slice_tensor_116, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_230 = torch.ops.aten.native_batch_norm_backward.default(clone_default_90, convolution_default_63, primals_52, primals_50, primals_51, getitem_108, getitem_109, True, 0.001, [True, True, True]);  clone_default_90 = convolution_default_63 = primals_52 = primals_50 = primals_51 = getitem_108 = getitem_109 = None
        getitem_2770 = native_batch_norm_backward_default_230[0]
        getitem_2771 = native_batch_norm_backward_default_230[1]
        getitem_2772 = native_batch_norm_backward_default_230[2];  native_batch_norm_backward_default_230 = None
        convolution_backward_default_424 = torch.ops.aten.convolution_backward.default(getitem_2770, convolution_default_62, primals_56, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2770 = convolution_default_62 = primals_56 = None
        getitem_2773 = convolution_backward_default_424[0]
        getitem_2774 = convolution_backward_default_424[1];  convolution_backward_default_424 = None
        convolution_backward_default_425 = torch.ops.aten.convolution_backward.default(getitem_2773, relu__default_13, primals_55, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2773 = primals_55 = None
        getitem_2776 = convolution_backward_default_425[0]
        getitem_2777 = convolution_backward_default_425[1];  convolution_backward_default_425 = None
        to_dtype_693 = torch.ops.aten.to.dtype(getitem_2776, torch.float32);  getitem_2776 = None
        to_dtype_694 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_231 = torch.ops.aten.le.Scalar(to_dtype_694, 0);  to_dtype_694 = None
        new_zeros_default_495 = torch.ops.aten.new_zeros.default(to_dtype_693, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_231 = torch.ops.aten.where.self(le_scalar_231, new_zeros_default_495, to_dtype_693);  le_scalar_231 = new_zeros_default_495 = to_dtype_693 = None
        to_dtype_695 = torch.ops.aten.to.dtype(where_self_231, torch.float32);  where_self_231 = None
        native_batch_norm_backward_default_231 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_695, convolution_default_61, primals_47, primals_45, primals_46, getitem_105, getitem_106, True, 0.001, [True, True, True]);  to_dtype_695 = convolution_default_61 = primals_47 = primals_45 = primals_46 = getitem_105 = getitem_106 = None
        getitem_2779 = native_batch_norm_backward_default_231[0]
        getitem_2780 = native_batch_norm_backward_default_231[1]
        getitem_2781 = native_batch_norm_backward_default_231[2];  native_batch_norm_backward_default_231 = None
        convolution_backward_default_426 = torch.ops.aten.convolution_backward.default(getitem_2779, convolution_default_60, primals_54, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2779 = convolution_default_60 = primals_54 = None
        getitem_2782 = convolution_backward_default_426[0]
        getitem_2783 = convolution_backward_default_426[1];  convolution_backward_default_426 = None
        convolution_backward_default_427 = torch.ops.aten.convolution_backward.default(getitem_2782, relu_default_18, primals_53, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2782 = primals_53 = None
        getitem_2785 = convolution_backward_default_427[0]
        getitem_2786 = convolution_backward_default_427[1];  convolution_backward_default_427 = None
        to_dtype_696 = torch.ops.aten.to.dtype(getitem_2785, torch.float32);  getitem_2785 = None
        to_dtype_697 = torch.ops.aten.to.dtype(relu_default_18, torch.float32);  relu_default_18 = None
        le_scalar_232 = torch.ops.aten.le.Scalar(to_dtype_697, 0);  to_dtype_697 = None
        new_zeros_default_496 = torch.ops.aten.new_zeros.default(to_dtype_696, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_232 = torch.ops.aten.where.self(le_scalar_232, new_zeros_default_496, to_dtype_696);  le_scalar_232 = new_zeros_default_496 = to_dtype_696 = None
        to_dtype_698 = torch.ops.aten.to.dtype(where_self_232, torch.float32);  where_self_232 = None
        add_tensor_303 = torch.ops.aten.add.Tensor(add_tensor_301, to_dtype_698);  add_tensor_301 = to_dtype_698 = None
        clone_default_91 = torch.ops.aten.clone.default(slice_tensor_116, memory_format = torch.contiguous_format);  slice_tensor_116 = None
        native_batch_norm_backward_default_232 = torch.ops.aten.native_batch_norm_backward.default(clone_default_91, convolution_default_59, primals_38, primals_36, primals_37, getitem_102, getitem_103, True, 0.001, [True, True, True]);  clone_default_91 = convolution_default_59 = primals_38 = primals_36 = primals_37 = getitem_102 = getitem_103 = None
        getitem_2788 = native_batch_norm_backward_default_232[0]
        getitem_2789 = native_batch_norm_backward_default_232[1]
        getitem_2790 = native_batch_norm_backward_default_232[2];  native_batch_norm_backward_default_232 = None
        convolution_backward_default_428 = torch.ops.aten.convolution_backward.default(getitem_2788, convolution_default_58, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2788 = convolution_default_58 = primals_42 = None
        getitem_2791 = convolution_backward_default_428[0]
        getitem_2792 = convolution_backward_default_428[1];  convolution_backward_default_428 = None
        convolution_backward_default_429 = torch.ops.aten.convolution_backward.default(getitem_2791, relu__default_12, primals_41, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2791 = primals_41 = None
        getitem_2794 = convolution_backward_default_429[0]
        getitem_2795 = convolution_backward_default_429[1];  convolution_backward_default_429 = None
        to_dtype_699 = torch.ops.aten.to.dtype(getitem_2794, torch.float32);  getitem_2794 = None
        to_dtype_700 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_233 = torch.ops.aten.le.Scalar(to_dtype_700, 0);  to_dtype_700 = None
        new_zeros_default_497 = torch.ops.aten.new_zeros.default(to_dtype_699, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_233 = torch.ops.aten.where.self(le_scalar_233, new_zeros_default_497, to_dtype_699);  le_scalar_233 = new_zeros_default_497 = to_dtype_699 = None
        to_dtype_701 = torch.ops.aten.to.dtype(where_self_233, torch.float32);  where_self_233 = None
        native_batch_norm_backward_default_233 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_701, convolution_default_57, primals_33, primals_31, primals_32, getitem_99, getitem_100, True, 0.001, [True, True, True]);  to_dtype_701 = convolution_default_57 = primals_33 = primals_31 = primals_32 = getitem_99 = getitem_100 = None
        getitem_2797 = native_batch_norm_backward_default_233[0]
        getitem_2798 = native_batch_norm_backward_default_233[1]
        getitem_2799 = native_batch_norm_backward_default_233[2];  native_batch_norm_backward_default_233 = None
        convolution_backward_default_430 = torch.ops.aten.convolution_backward.default(getitem_2797, convolution_default_56, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2797 = convolution_default_56 = primals_40 = None
        getitem_2800 = convolution_backward_default_430[0]
        getitem_2801 = convolution_backward_default_430[1];  convolution_backward_default_430 = None
        convolution_backward_default_431 = torch.ops.aten.convolution_backward.default(getitem_2800, relu_default_17, primals_39, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2800 = primals_39 = None
        getitem_2803 = convolution_backward_default_431[0]
        getitem_2804 = convolution_backward_default_431[1];  convolution_backward_default_431 = None
        to_dtype_702 = torch.ops.aten.to.dtype(getitem_2803, torch.float32);  getitem_2803 = None
        to_dtype_703 = torch.ops.aten.to.dtype(relu_default_17, torch.float32);  relu_default_17 = None
        le_scalar_234 = torch.ops.aten.le.Scalar(to_dtype_703, 0);  to_dtype_703 = None
        new_zeros_default_498 = torch.ops.aten.new_zeros.default(to_dtype_702, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_234 = torch.ops.aten.where.self(le_scalar_234, new_zeros_default_498, to_dtype_702);  le_scalar_234 = new_zeros_default_498 = to_dtype_702 = None
        to_dtype_704 = torch.ops.aten.to.dtype(where_self_234, torch.float32);  where_self_234 = None
        add_tensor_304 = torch.ops.aten.add.Tensor(add_tensor_303, to_dtype_704);  add_tensor_303 = to_dtype_704 = None
        clone_default_92 = torch.ops.aten.clone.default(slice_tensor_115, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_234 = torch.ops.aten.native_batch_norm_backward.default(clone_default_92, convolution_default_55, primals_24, primals_22, primals_23, getitem_96, getitem_97, True, 0.001, [True, True, True]);  clone_default_92 = convolution_default_55 = primals_24 = primals_22 = primals_23 = getitem_96 = getitem_97 = None
        getitem_2806 = native_batch_norm_backward_default_234[0]
        getitem_2807 = native_batch_norm_backward_default_234[1]
        getitem_2808 = native_batch_norm_backward_default_234[2];  native_batch_norm_backward_default_234 = None
        convolution_backward_default_432 = torch.ops.aten.convolution_backward.default(getitem_2806, convolution_default_54, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2806 = convolution_default_54 = primals_28 = None
        getitem_2809 = convolution_backward_default_432[0]
        getitem_2810 = convolution_backward_default_432[1];  convolution_backward_default_432 = None
        convolution_backward_default_433 = torch.ops.aten.convolution_backward.default(getitem_2809, relu__default_11, primals_27, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2809 = primals_27 = None
        getitem_2812 = convolution_backward_default_433[0]
        getitem_2813 = convolution_backward_default_433[1];  convolution_backward_default_433 = None
        to_dtype_705 = torch.ops.aten.to.dtype(getitem_2812, torch.float32);  getitem_2812 = None
        to_dtype_706 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_235 = torch.ops.aten.le.Scalar(to_dtype_706, 0);  to_dtype_706 = None
        new_zeros_default_499 = torch.ops.aten.new_zeros.default(to_dtype_705, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_235 = torch.ops.aten.where.self(le_scalar_235, new_zeros_default_499, to_dtype_705);  le_scalar_235 = new_zeros_default_499 = to_dtype_705 = None
        to_dtype_707 = torch.ops.aten.to.dtype(where_self_235, torch.float32);  where_self_235 = None
        native_batch_norm_backward_default_235 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_707, convolution_default_53, primals_19, primals_17, primals_18, getitem_93, getitem_94, True, 0.001, [True, True, True]);  to_dtype_707 = convolution_default_53 = primals_19 = primals_17 = primals_18 = getitem_93 = getitem_94 = None
        getitem_2815 = native_batch_norm_backward_default_235[0]
        getitem_2816 = native_batch_norm_backward_default_235[1]
        getitem_2817 = native_batch_norm_backward_default_235[2];  native_batch_norm_backward_default_235 = None
        convolution_backward_default_434 = torch.ops.aten.convolution_backward.default(getitem_2815, convolution_default_52, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2815 = convolution_default_52 = primals_26 = None
        getitem_2818 = convolution_backward_default_434[0]
        getitem_2819 = convolution_backward_default_434[1];  convolution_backward_default_434 = None
        convolution_backward_default_435 = torch.ops.aten.convolution_backward.default(getitem_2818, relu_default_16, primals_25, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2818 = primals_25 = None
        getitem_2821 = convolution_backward_default_435[0]
        getitem_2822 = convolution_backward_default_435[1];  convolution_backward_default_435 = None
        to_dtype_708 = torch.ops.aten.to.dtype(getitem_2821, torch.float32);  getitem_2821 = None
        to_dtype_709 = torch.ops.aten.to.dtype(relu_default_16, torch.float32);  relu_default_16 = None
        le_scalar_236 = torch.ops.aten.le.Scalar(to_dtype_709, 0);  to_dtype_709 = None
        new_zeros_default_500 = torch.ops.aten.new_zeros.default(to_dtype_708, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_236 = torch.ops.aten.where.self(le_scalar_236, new_zeros_default_500, to_dtype_708);  le_scalar_236 = new_zeros_default_500 = to_dtype_708 = None
        to_dtype_710 = torch.ops.aten.to.dtype(where_self_236, torch.float32);  where_self_236 = None
        add_tensor_305 = torch.ops.aten.add.Tensor(add_tensor_304, to_dtype_710);  add_tensor_304 = to_dtype_710 = None
        clone_default_93 = torch.ops.aten.clone.default(slice_tensor_115, memory_format = torch.contiguous_format);  slice_tensor_115 = None
        native_batch_norm_backward_default_236 = torch.ops.aten.native_batch_norm_backward.default(clone_default_93, convolution_default_51, primals_10, primals_8, primals_9, getitem_90, getitem_91, True, 0.001, [True, True, True]);  clone_default_93 = convolution_default_51 = primals_10 = primals_8 = primals_9 = getitem_90 = getitem_91 = None
        getitem_2824 = native_batch_norm_backward_default_236[0]
        getitem_2825 = native_batch_norm_backward_default_236[1]
        getitem_2826 = native_batch_norm_backward_default_236[2];  native_batch_norm_backward_default_236 = None
        convolution_backward_default_436 = torch.ops.aten.convolution_backward.default(getitem_2824, convolution_default_50, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2824 = convolution_default_50 = primals_14 = None
        getitem_2827 = convolution_backward_default_436[0]
        getitem_2828 = convolution_backward_default_436[1];  convolution_backward_default_436 = None
        convolution_backward_default_437 = torch.ops.aten.convolution_backward.default(getitem_2827, relu__default_10, primals_13, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2827 = primals_13 = None
        getitem_2830 = convolution_backward_default_437[0]
        getitem_2831 = convolution_backward_default_437[1];  convolution_backward_default_437 = None
        to_dtype_711 = torch.ops.aten.to.dtype(getitem_2830, torch.float32);  getitem_2830 = None
        to_dtype_712 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_237 = torch.ops.aten.le.Scalar(to_dtype_712, 0);  to_dtype_712 = None
        new_zeros_default_501 = torch.ops.aten.new_zeros.default(to_dtype_711, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_237 = torch.ops.aten.where.self(le_scalar_237, new_zeros_default_501, to_dtype_711);  le_scalar_237 = new_zeros_default_501 = to_dtype_711 = None
        to_dtype_713 = torch.ops.aten.to.dtype(where_self_237, torch.float32);  where_self_237 = None
        native_batch_norm_backward_default_237 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_713, convolution_default_49, primals_5, primals_3, primals_4, getitem_87, getitem_88, True, 0.001, [True, True, True]);  to_dtype_713 = convolution_default_49 = primals_5 = primals_3 = primals_4 = getitem_87 = getitem_88 = None
        getitem_2833 = native_batch_norm_backward_default_237[0]
        getitem_2834 = native_batch_norm_backward_default_237[1]
        getitem_2835 = native_batch_norm_backward_default_237[2];  native_batch_norm_backward_default_237 = None
        convolution_backward_default_438 = torch.ops.aten.convolution_backward.default(getitem_2833, convolution_default_48, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2833 = convolution_default_48 = primals_12 = None
        getitem_2836 = convolution_backward_default_438[0]
        getitem_2837 = convolution_backward_default_438[1];  convolution_backward_default_438 = None
        convolution_backward_default_439 = torch.ops.aten.convolution_backward.default(getitem_2836, relu_default_15, primals_11, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  getitem_2836 = primals_11 = None
        getitem_2839 = convolution_backward_default_439[0]
        getitem_2840 = convolution_backward_default_439[1];  convolution_backward_default_439 = None
        to_dtype_714 = torch.ops.aten.to.dtype(getitem_2839, torch.float32);  getitem_2839 = None
        to_dtype_715 = torch.ops.aten.to.dtype(relu_default_15, torch.float32);  relu_default_15 = None
        le_scalar_238 = torch.ops.aten.le.Scalar(to_dtype_715, 0);  to_dtype_715 = None
        new_zeros_default_502 = torch.ops.aten.new_zeros.default(to_dtype_714, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_238 = torch.ops.aten.where.self(le_scalar_238, new_zeros_default_502, to_dtype_714);  le_scalar_238 = new_zeros_default_502 = to_dtype_714 = None
        to_dtype_716 = torch.ops.aten.to.dtype(where_self_238, torch.float32);  where_self_238 = None
        add_tensor_306 = torch.ops.aten.add.Tensor(add_tensor_302, to_dtype_716);  add_tensor_302 = to_dtype_716 = None
        native_batch_norm_backward_default_238 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_306, convolution_default_47, primals_75, primals_73, primals_74, getitem_84, getitem_85, True, 0.001, [True, True, True]);  add_tensor_306 = convolution_default_47 = primals_75 = primals_73 = primals_74 = getitem_84 = getitem_85 = None
        getitem_2842 = native_batch_norm_backward_default_238[0]
        getitem_2843 = native_batch_norm_backward_default_238[1]
        getitem_2844 = native_batch_norm_backward_default_238[2];  native_batch_norm_backward_default_238 = None
        convolution_backward_default_440 = torch.ops.aten.convolution_backward.default(getitem_2842, relu_default_14, primals_76, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2842 = primals_76 = None
        getitem_2845 = convolution_backward_default_440[0]
        getitem_2846 = convolution_backward_default_440[1];  convolution_backward_default_440 = None
        to_dtype_717 = torch.ops.aten.to.dtype(getitem_2845, torch.float32);  getitem_2845 = None
        to_dtype_718 = torch.ops.aten.to.dtype(relu_default_14, torch.float32);  relu_default_14 = None
        le_scalar_239 = torch.ops.aten.le.Scalar(to_dtype_718, 0);  to_dtype_718 = None
        new_zeros_default_503 = torch.ops.aten.new_zeros.default(to_dtype_717, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_239 = torch.ops.aten.where.self(le_scalar_239, new_zeros_default_503, to_dtype_717);  le_scalar_239 = new_zeros_default_503 = to_dtype_717 = None
        to_dtype_719 = torch.ops.aten.to.dtype(where_self_239, torch.float32);  where_self_239 = None
        add_tensor_307 = torch.ops.aten.add.Tensor(to_dtype_686, to_dtype_719);  to_dtype_686 = to_dtype_719 = None
        native_batch_norm_backward_default_239 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_305, cat_default_3, primals_81, primals_79, primals_80, getitem_81, getitem_82, True, 0.001, [True, True, True]);  add_tensor_305 = cat_default_3 = primals_81 = primals_79 = primals_80 = getitem_81 = getitem_82 = None
        getitem_2848 = native_batch_norm_backward_default_239[0]
        getitem_2849 = native_batch_norm_backward_default_239[1]
        getitem_2850 = native_batch_norm_backward_default_239[2];  native_batch_norm_backward_default_239 = None
        slice_tensor_120 = torch.ops.aten.slice.Tensor(getitem_2848, 1, 0, 84)
        slice_tensor_121 = torch.ops.aten.slice.Tensor(getitem_2848, 1, 84, 168);  getitem_2848 = None
        convolution_backward_default_441 = torch.ops.aten.convolution_backward.default(slice_tensor_121, avg_pool2d_default_7, primals_83, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_121 = avg_pool2d_default_7 = primals_83 = None
        getitem_2851 = convolution_backward_default_441[0]
        getitem_2852 = convolution_backward_default_441[1];  convolution_backward_default_441 = None
        avg_pool2d_backward_default_62 = torch.ops.aten.avg_pool2d_backward.default(getitem_2851, constant_pad_nd_default_15, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2851 = constant_pad_nd_default_15 = None
        constant_pad_nd_default_48 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_62, [1, -1, 1, -1]);  avg_pool2d_backward_default_62 = None
        convolution_backward_default_442 = torch.ops.aten.convolution_backward.default(slice_tensor_120, avg_pool2d_default_6, primals_82, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_120 = avg_pool2d_default_6 = primals_82 = None
        getitem_2854 = convolution_backward_default_442[0]
        getitem_2855 = convolution_backward_default_442[1];  convolution_backward_default_442 = None
        avg_pool2d_backward_default_63 = torch.ops.aten.avg_pool2d_backward.default(getitem_2854, relu_default_13, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2854 = None
        add_tensor_308 = torch.ops.aten.add.Tensor(constant_pad_nd_default_48, avg_pool2d_backward_default_63);  constant_pad_nd_default_48 = avg_pool2d_backward_default_63 = None
        to_dtype_720 = torch.ops.aten.to.dtype(add_tensor_308, torch.float32);  add_tensor_308 = None
        to_dtype_721 = torch.ops.aten.to.dtype(relu_default_13, torch.float32);  relu_default_13 = None
        le_scalar_240 = torch.ops.aten.le.Scalar(to_dtype_721, 0);  to_dtype_721 = None
        new_zeros_default_504 = torch.ops.aten.new_zeros.default(to_dtype_720, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_240 = torch.ops.aten.where.self(le_scalar_240, new_zeros_default_504, to_dtype_720);  le_scalar_240 = new_zeros_default_504 = to_dtype_720 = None
        to_dtype_722 = torch.ops.aten.to.dtype(where_self_240, torch.float32);  where_self_240 = None
        slice_tensor_122 = torch.ops.aten.slice.Tensor(add_tensor_307, 1, 0, 84)
        slice_tensor_123 = torch.ops.aten.slice.Tensor(add_tensor_307, 1, 84, 168)
        slice_tensor_124 = torch.ops.aten.slice.Tensor(add_tensor_307, 1, 168, 252)
        slice_tensor_125 = torch.ops.aten.slice.Tensor(add_tensor_307, 1, 252, 336);  add_tensor_307 = None
        max_pool2d_with_indices_backward_default_4 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_125, constant_pad_nd_default_14, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_79);  constant_pad_nd_default_14 = getitem_79 = None
        constant_pad_nd_default_49 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_4, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_4 = None
        clone_default_94 = torch.ops.aten.clone.default(slice_tensor_125, memory_format = torch.contiguous_format);  slice_tensor_125 = None
        native_batch_norm_backward_default_240 = torch.ops.aten.native_batch_norm_backward.default(clone_default_94, convolution_default_44, primals_1621, primals_1619, primals_1620, getitem_76, getitem_77, True, 0.001, [True, True, True]);  clone_default_94 = convolution_default_44 = primals_1621 = primals_1619 = primals_1620 = getitem_76 = getitem_77 = None
        getitem_2857 = native_batch_norm_backward_default_240[0]
        getitem_2858 = native_batch_norm_backward_default_240[1]
        getitem_2859 = native_batch_norm_backward_default_240[2];  native_batch_norm_backward_default_240 = None
        convolution_backward_default_443 = torch.ops.aten.convolution_backward.default(getitem_2857, convolution_default_43, primals_1625, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2857 = convolution_default_43 = primals_1625 = None
        getitem_2860 = convolution_backward_default_443[0]
        getitem_2861 = convolution_backward_default_443[1];  convolution_backward_default_443 = None
        convolution_backward_default_444 = torch.ops.aten.convolution_backward.default(getitem_2860, relu__default_9, primals_1624, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2860 = primals_1624 = None
        getitem_2863 = convolution_backward_default_444[0]
        getitem_2864 = convolution_backward_default_444[1];  convolution_backward_default_444 = None
        to_dtype_723 = torch.ops.aten.to.dtype(getitem_2863, torch.float32);  getitem_2863 = None
        to_dtype_724 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_241 = torch.ops.aten.le.Scalar(to_dtype_724, 0);  to_dtype_724 = None
        new_zeros_default_505 = torch.ops.aten.new_zeros.default(to_dtype_723, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_241 = torch.ops.aten.where.self(le_scalar_241, new_zeros_default_505, to_dtype_723);  le_scalar_241 = new_zeros_default_505 = to_dtype_723 = None
        to_dtype_725 = torch.ops.aten.to.dtype(where_self_241, torch.float32);  where_self_241 = None
        native_batch_norm_backward_default_241 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_725, convolution_default_42, primals_1616, primals_1614, primals_1615, getitem_73, getitem_74, True, 0.001, [True, True, True]);  to_dtype_725 = convolution_default_42 = primals_1616 = primals_1614 = primals_1615 = getitem_73 = getitem_74 = None
        getitem_2866 = native_batch_norm_backward_default_241[0]
        getitem_2867 = native_batch_norm_backward_default_241[1]
        getitem_2868 = native_batch_norm_backward_default_241[2];  native_batch_norm_backward_default_241 = None
        convolution_backward_default_445 = torch.ops.aten.convolution_backward.default(getitem_2866, convolution_default_41, primals_1623, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2866 = convolution_default_41 = primals_1623 = None
        getitem_2869 = convolution_backward_default_445[0]
        getitem_2870 = convolution_backward_default_445[1];  convolution_backward_default_445 = None
        convolution_backward_default_446 = torch.ops.aten.convolution_backward.default(getitem_2869, relu_default_12, primals_1622, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2869 = primals_1622 = None
        getitem_2872 = convolution_backward_default_446[0]
        getitem_2873 = convolution_backward_default_446[1];  convolution_backward_default_446 = None
        to_dtype_726 = torch.ops.aten.to.dtype(getitem_2872, torch.float32);  getitem_2872 = None
        to_dtype_727 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar_242 = torch.ops.aten.le.Scalar(to_dtype_727, 0);  to_dtype_727 = None
        new_zeros_default_506 = torch.ops.aten.new_zeros.default(to_dtype_726, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_242 = torch.ops.aten.where.self(le_scalar_242, new_zeros_default_506, to_dtype_726);  le_scalar_242 = new_zeros_default_506 = to_dtype_726 = None
        to_dtype_728 = torch.ops.aten.to.dtype(where_self_242, torch.float32);  where_self_242 = None
        add_tensor_309 = torch.ops.aten.add.Tensor(slice_tensor_122, slice_tensor_124);  slice_tensor_122 = None
        avg_pool2d_backward_default_64 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_124, add_tensor_6, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_124 = add_tensor_6 = None
        add_tensor_310 = torch.ops.aten.add.Tensor(to_dtype_728, avg_pool2d_backward_default_64);  to_dtype_728 = avg_pool2d_backward_default_64 = None
        clone_default_95 = torch.ops.aten.clone.default(slice_tensor_123, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_242 = torch.ops.aten.native_batch_norm_backward.default(clone_default_95, convolution_default_40, primals_1607, primals_1605, primals_1606, getitem_70, getitem_71, True, 0.001, [True, True, True]);  clone_default_95 = convolution_default_40 = primals_1607 = primals_1605 = primals_1606 = getitem_70 = getitem_71 = None
        getitem_2875 = native_batch_norm_backward_default_242[0]
        getitem_2876 = native_batch_norm_backward_default_242[1]
        getitem_2877 = native_batch_norm_backward_default_242[2];  native_batch_norm_backward_default_242 = None
        convolution_backward_default_447 = torch.ops.aten.convolution_backward.default(getitem_2875, convolution_default_39, primals_1611, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2875 = convolution_default_39 = primals_1611 = None
        getitem_2878 = convolution_backward_default_447[0]
        getitem_2879 = convolution_backward_default_447[1];  convolution_backward_default_447 = None
        convolution_backward_default_448 = torch.ops.aten.convolution_backward.default(getitem_2878, relu__default_8, primals_1610, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2878 = primals_1610 = None
        getitem_2881 = convolution_backward_default_448[0]
        getitem_2882 = convolution_backward_default_448[1];  convolution_backward_default_448 = None
        to_dtype_729 = torch.ops.aten.to.dtype(getitem_2881, torch.float32);  getitem_2881 = None
        to_dtype_730 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_243 = torch.ops.aten.le.Scalar(to_dtype_730, 0);  to_dtype_730 = None
        new_zeros_default_507 = torch.ops.aten.new_zeros.default(to_dtype_729, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_243 = torch.ops.aten.where.self(le_scalar_243, new_zeros_default_507, to_dtype_729);  le_scalar_243 = new_zeros_default_507 = to_dtype_729 = None
        to_dtype_731 = torch.ops.aten.to.dtype(where_self_243, torch.float32);  where_self_243 = None
        native_batch_norm_backward_default_243 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_731, convolution_default_38, primals_1602, primals_1600, primals_1601, getitem_67, getitem_68, True, 0.001, [True, True, True]);  to_dtype_731 = convolution_default_38 = primals_1602 = primals_1600 = primals_1601 = getitem_67 = getitem_68 = None
        getitem_2884 = native_batch_norm_backward_default_243[0]
        getitem_2885 = native_batch_norm_backward_default_243[1]
        getitem_2886 = native_batch_norm_backward_default_243[2];  native_batch_norm_backward_default_243 = None
        convolution_backward_default_449 = torch.ops.aten.convolution_backward.default(getitem_2884, convolution_default_37, primals_1609, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2884 = convolution_default_37 = primals_1609 = None
        getitem_2887 = convolution_backward_default_449[0]
        getitem_2888 = convolution_backward_default_449[1];  convolution_backward_default_449 = None
        convolution_backward_default_450 = torch.ops.aten.convolution_backward.default(getitem_2887, constant_pad_nd_default_13, primals_1608, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2887 = constant_pad_nd_default_13 = primals_1608 = None
        getitem_2890 = convolution_backward_default_450[0]
        getitem_2891 = convolution_backward_default_450[1];  convolution_backward_default_450 = None
        constant_pad_nd_default_50 = torch.ops.aten.constant_pad_nd.default(getitem_2890, [-2, -2, -2, -2]);  getitem_2890 = None
        to_dtype_732 = torch.ops.aten.to.dtype(constant_pad_nd_default_50, torch.float32);  constant_pad_nd_default_50 = None
        to_dtype_733 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_244 = torch.ops.aten.le.Scalar(to_dtype_733, 0);  to_dtype_733 = None
        new_zeros_default_508 = torch.ops.aten.new_zeros.default(to_dtype_732, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_244 = torch.ops.aten.where.self(le_scalar_244, new_zeros_default_508, to_dtype_732);  le_scalar_244 = new_zeros_default_508 = to_dtype_732 = None
        to_dtype_734 = torch.ops.aten.to.dtype(where_self_244, torch.float32);  where_self_244 = None
        avg_pool2d_backward_default_65 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_123, constant_pad_nd_default_12, [3, 3], [2, 2], [0, 0], False, False, None);  slice_tensor_123 = constant_pad_nd_default_12 = None
        constant_pad_nd_default_51 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_65, [-1, -1, -1, -1]);  avg_pool2d_backward_default_65 = None
        add_tensor_311 = torch.ops.aten.add.Tensor(constant_pad_nd_default_49, constant_pad_nd_default_51);  constant_pad_nd_default_49 = constant_pad_nd_default_51 = None
        native_batch_norm_backward_default_244 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_309, convolution_default_36, primals_1593, primals_1591, primals_1592, getitem_64, getitem_65, True, 0.001, [True, True, True]);  convolution_default_36 = primals_1593 = primals_1591 = primals_1592 = getitem_64 = getitem_65 = None
        getitem_2893 = native_batch_norm_backward_default_244[0]
        getitem_2894 = native_batch_norm_backward_default_244[1]
        getitem_2895 = native_batch_norm_backward_default_244[2];  native_batch_norm_backward_default_244 = None
        convolution_backward_default_451 = torch.ops.aten.convolution_backward.default(getitem_2893, convolution_default_35, primals_1597, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2893 = convolution_default_35 = primals_1597 = None
        getitem_2896 = convolution_backward_default_451[0]
        getitem_2897 = convolution_backward_default_451[1];  convolution_backward_default_451 = None
        convolution_backward_default_452 = torch.ops.aten.convolution_backward.default(getitem_2896, relu__default_7, primals_1596, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2896 = primals_1596 = None
        getitem_2899 = convolution_backward_default_452[0]
        getitem_2900 = convolution_backward_default_452[1];  convolution_backward_default_452 = None
        to_dtype_735 = torch.ops.aten.to.dtype(getitem_2899, torch.float32);  getitem_2899 = None
        to_dtype_736 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_245 = torch.ops.aten.le.Scalar(to_dtype_736, 0);  to_dtype_736 = None
        new_zeros_default_509 = torch.ops.aten.new_zeros.default(to_dtype_735, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_245 = torch.ops.aten.where.self(le_scalar_245, new_zeros_default_509, to_dtype_735);  le_scalar_245 = new_zeros_default_509 = to_dtype_735 = None
        to_dtype_737 = torch.ops.aten.to.dtype(where_self_245, torch.float32);  where_self_245 = None
        native_batch_norm_backward_default_245 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_737, convolution_default_34, primals_1588, primals_1586, primals_1587, getitem_61, getitem_62, True, 0.001, [True, True, True]);  to_dtype_737 = convolution_default_34 = primals_1588 = primals_1586 = primals_1587 = getitem_61 = getitem_62 = None
        getitem_2902 = native_batch_norm_backward_default_245[0]
        getitem_2903 = native_batch_norm_backward_default_245[1]
        getitem_2904 = native_batch_norm_backward_default_245[2];  native_batch_norm_backward_default_245 = None
        convolution_backward_default_453 = torch.ops.aten.convolution_backward.default(getitem_2902, convolution_default_33, primals_1595, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2902 = convolution_default_33 = primals_1595 = None
        getitem_2905 = convolution_backward_default_453[0]
        getitem_2906 = convolution_backward_default_453[1];  convolution_backward_default_453 = None
        convolution_backward_default_454 = torch.ops.aten.convolution_backward.default(getitem_2905, constant_pad_nd_default_11, primals_1594, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2905 = constant_pad_nd_default_11 = primals_1594 = None
        getitem_2908 = convolution_backward_default_454[0]
        getitem_2909 = convolution_backward_default_454[1];  convolution_backward_default_454 = None
        constant_pad_nd_default_52 = torch.ops.aten.constant_pad_nd.default(getitem_2908, [-3, -3, -3, -3]);  getitem_2908 = None
        to_dtype_738 = torch.ops.aten.to.dtype(constant_pad_nd_default_52, torch.float32);  constant_pad_nd_default_52 = None
        to_dtype_739 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_246 = torch.ops.aten.le.Scalar(to_dtype_739, 0);  to_dtype_739 = None
        new_zeros_default_510 = torch.ops.aten.new_zeros.default(to_dtype_738, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_246 = torch.ops.aten.where.self(le_scalar_246, new_zeros_default_510, to_dtype_738);  le_scalar_246 = new_zeros_default_510 = to_dtype_738 = None
        to_dtype_740 = torch.ops.aten.to.dtype(where_self_246, torch.float32);  where_self_246 = None
        add_tensor_312 = torch.ops.aten.add.Tensor(to_dtype_734, to_dtype_740);  to_dtype_734 = to_dtype_740 = None
        max_pool2d_with_indices_backward_default_5 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_309, constant_pad_nd_default_10, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_59);  add_tensor_309 = constant_pad_nd_default_10 = getitem_59 = None
        constant_pad_nd_default_53 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_5, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_5 = None
        add_tensor_313 = torch.ops.aten.add.Tensor(add_tensor_311, constant_pad_nd_default_53);  add_tensor_311 = constant_pad_nd_default_53 = None
        native_batch_norm_backward_default_246 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_310, convolution_default_32, primals_1579, primals_1577, primals_1578, getitem_56, getitem_57, True, 0.001, [True, True, True]);  convolution_default_32 = primals_1579 = primals_1577 = primals_1578 = getitem_56 = getitem_57 = None
        getitem_2911 = native_batch_norm_backward_default_246[0]
        getitem_2912 = native_batch_norm_backward_default_246[1]
        getitem_2913 = native_batch_norm_backward_default_246[2];  native_batch_norm_backward_default_246 = None
        convolution_backward_default_455 = torch.ops.aten.convolution_backward.default(getitem_2911, convolution_default_31, primals_1583, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2911 = convolution_default_31 = primals_1583 = None
        getitem_2914 = convolution_backward_default_455[0]
        getitem_2915 = convolution_backward_default_455[1];  convolution_backward_default_455 = None
        convolution_backward_default_456 = torch.ops.aten.convolution_backward.default(getitem_2914, relu__default_6, primals_1582, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2914 = primals_1582 = None
        getitem_2917 = convolution_backward_default_456[0]
        getitem_2918 = convolution_backward_default_456[1];  convolution_backward_default_456 = None
        to_dtype_741 = torch.ops.aten.to.dtype(getitem_2917, torch.float32);  getitem_2917 = None
        to_dtype_742 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_247 = torch.ops.aten.le.Scalar(to_dtype_742, 0);  to_dtype_742 = None
        new_zeros_default_511 = torch.ops.aten.new_zeros.default(to_dtype_741, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_247 = torch.ops.aten.where.self(le_scalar_247, new_zeros_default_511, to_dtype_741);  le_scalar_247 = new_zeros_default_511 = to_dtype_741 = None
        to_dtype_743 = torch.ops.aten.to.dtype(where_self_247, torch.float32);  where_self_247 = None
        native_batch_norm_backward_default_247 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_743, convolution_default_30, primals_1574, primals_1572, primals_1573, getitem_53, getitem_54, True, 0.001, [True, True, True]);  to_dtype_743 = convolution_default_30 = primals_1574 = primals_1572 = primals_1573 = getitem_53 = getitem_54 = None
        getitem_2920 = native_batch_norm_backward_default_247[0]
        getitem_2921 = native_batch_norm_backward_default_247[1]
        getitem_2922 = native_batch_norm_backward_default_247[2];  native_batch_norm_backward_default_247 = None
        convolution_backward_default_457 = torch.ops.aten.convolution_backward.default(getitem_2920, convolution_default_29, primals_1581, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2920 = convolution_default_29 = primals_1581 = None
        getitem_2923 = convolution_backward_default_457[0]
        getitem_2924 = convolution_backward_default_457[1];  convolution_backward_default_457 = None
        convolution_backward_default_458 = torch.ops.aten.convolution_backward.default(getitem_2923, constant_pad_nd_default_9, primals_1580, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2923 = constant_pad_nd_default_9 = primals_1580 = None
        getitem_2926 = convolution_backward_default_458[0]
        getitem_2927 = convolution_backward_default_458[1];  convolution_backward_default_458 = None
        constant_pad_nd_default_54 = torch.ops.aten.constant_pad_nd.default(getitem_2926, [-3, -3, -3, -3]);  getitem_2926 = None
        to_dtype_744 = torch.ops.aten.to.dtype(constant_pad_nd_default_54, torch.float32);  constant_pad_nd_default_54 = None
        to_dtype_745 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_248 = torch.ops.aten.le.Scalar(to_dtype_745, 0);  to_dtype_745 = None
        new_zeros_default_512 = torch.ops.aten.new_zeros.default(to_dtype_744, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_248 = torch.ops.aten.where.self(le_scalar_248, new_zeros_default_512, to_dtype_744);  le_scalar_248 = new_zeros_default_512 = to_dtype_744 = None
        to_dtype_746 = torch.ops.aten.to.dtype(where_self_248, torch.float32);  where_self_248 = None
        add_tensor_314 = torch.ops.aten.add.Tensor(add_tensor_312, to_dtype_746);  add_tensor_312 = to_dtype_746 = None
        native_batch_norm_backward_default_248 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_310, convolution_default_28, primals_1565, primals_1563, primals_1564, getitem_50, getitem_51, True, 0.001, [True, True, True]);  add_tensor_310 = convolution_default_28 = primals_1565 = primals_1563 = primals_1564 = getitem_50 = getitem_51 = None
        getitem_2929 = native_batch_norm_backward_default_248[0]
        getitem_2930 = native_batch_norm_backward_default_248[1]
        getitem_2931 = native_batch_norm_backward_default_248[2];  native_batch_norm_backward_default_248 = None
        convolution_backward_default_459 = torch.ops.aten.convolution_backward.default(getitem_2929, convolution_default_27, primals_1569, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2929 = convolution_default_27 = primals_1569 = None
        getitem_2932 = convolution_backward_default_459[0]
        getitem_2933 = convolution_backward_default_459[1];  convolution_backward_default_459 = None
        convolution_backward_default_460 = torch.ops.aten.convolution_backward.default(getitem_2932, relu__default_5, primals_1568, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2932 = primals_1568 = None
        getitem_2935 = convolution_backward_default_460[0]
        getitem_2936 = convolution_backward_default_460[1];  convolution_backward_default_460 = None
        to_dtype_747 = torch.ops.aten.to.dtype(getitem_2935, torch.float32);  getitem_2935 = None
        to_dtype_748 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_249 = torch.ops.aten.le.Scalar(to_dtype_748, 0);  to_dtype_748 = None
        new_zeros_default_513 = torch.ops.aten.new_zeros.default(to_dtype_747, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_249 = torch.ops.aten.where.self(le_scalar_249, new_zeros_default_513, to_dtype_747);  le_scalar_249 = new_zeros_default_513 = to_dtype_747 = None
        to_dtype_749 = torch.ops.aten.to.dtype(where_self_249, torch.float32);  where_self_249 = None
        native_batch_norm_backward_default_249 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_749, convolution_default_26, primals_1560, primals_1558, primals_1559, getitem_47, getitem_48, True, 0.001, [True, True, True]);  to_dtype_749 = convolution_default_26 = primals_1560 = primals_1558 = primals_1559 = getitem_47 = getitem_48 = None
        getitem_2938 = native_batch_norm_backward_default_249[0]
        getitem_2939 = native_batch_norm_backward_default_249[1]
        getitem_2940 = native_batch_norm_backward_default_249[2];  native_batch_norm_backward_default_249 = None
        convolution_backward_default_461 = torch.ops.aten.convolution_backward.default(getitem_2938, convolution_default_25, primals_1567, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2938 = convolution_default_25 = primals_1567 = None
        getitem_2941 = convolution_backward_default_461[0]
        getitem_2942 = convolution_backward_default_461[1];  convolution_backward_default_461 = None
        convolution_backward_default_462 = torch.ops.aten.convolution_backward.default(getitem_2941, constant_pad_nd_default_8, primals_1566, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 84, [True, True, False]);  getitem_2941 = constant_pad_nd_default_8 = primals_1566 = None
        getitem_2944 = convolution_backward_default_462[0]
        getitem_2945 = convolution_backward_default_462[1];  convolution_backward_default_462 = None
        constant_pad_nd_default_55 = torch.ops.aten.constant_pad_nd.default(getitem_2944, [-2, -2, -2, -2]);  getitem_2944 = None
        to_dtype_750 = torch.ops.aten.to.dtype(constant_pad_nd_default_55, torch.float32);  constant_pad_nd_default_55 = None
        to_dtype_751 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_250 = torch.ops.aten.le.Scalar(to_dtype_751, 0);  to_dtype_751 = None
        new_zeros_default_514 = torch.ops.aten.new_zeros.default(to_dtype_750, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_250 = torch.ops.aten.where.self(le_scalar_250, new_zeros_default_514, to_dtype_750);  le_scalar_250 = new_zeros_default_514 = to_dtype_750 = None
        to_dtype_752 = torch.ops.aten.to.dtype(where_self_250, torch.float32);  where_self_250 = None
        add_tensor_315 = torch.ops.aten.add.Tensor(add_tensor_313, to_dtype_752);  add_tensor_313 = to_dtype_752 = None
        native_batch_norm_backward_default_250 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_314, cat_default_1, primals_1636, primals_1634, primals_1635, getitem_44, getitem_45, True, 0.001, [True, True, True]);  add_tensor_314 = cat_default_1 = primals_1636 = primals_1634 = primals_1635 = getitem_44 = getitem_45 = None
        getitem_2947 = native_batch_norm_backward_default_250[0]
        getitem_2948 = native_batch_norm_backward_default_250[1]
        getitem_2949 = native_batch_norm_backward_default_250[2];  native_batch_norm_backward_default_250 = None
        slice_tensor_126 = torch.ops.aten.slice.Tensor(getitem_2947, 1, 0, 42)
        slice_tensor_127 = torch.ops.aten.slice.Tensor(getitem_2947, 1, 42, 84);  getitem_2947 = None
        convolution_backward_default_463 = torch.ops.aten.convolution_backward.default(slice_tensor_127, avg_pool2d_default_3, primals_1638, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_127 = avg_pool2d_default_3 = primals_1638 = None
        getitem_2950 = convolution_backward_default_463[0]
        getitem_2951 = convolution_backward_default_463[1];  convolution_backward_default_463 = None
        avg_pool2d_backward_default_66 = torch.ops.aten.avg_pool2d_backward.default(getitem_2950, constant_pad_nd_default_7, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2950 = constant_pad_nd_default_7 = None
        constant_pad_nd_default_56 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_66, [1, -1, 1, -1]);  avg_pool2d_backward_default_66 = None
        convolution_backward_default_464 = torch.ops.aten.convolution_backward.default(slice_tensor_126, avg_pool2d_default_2, primals_1637, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_126 = avg_pool2d_default_2 = primals_1637 = None
        getitem_2953 = convolution_backward_default_464[0]
        getitem_2954 = convolution_backward_default_464[1];  convolution_backward_default_464 = None
        avg_pool2d_backward_default_67 = torch.ops.aten.avg_pool2d_backward.default(getitem_2953, relu_default_7, [1, 1], [2, 2], [0, 0], False, False, None);  getitem_2953 = None
        add_tensor_316 = torch.ops.aten.add.Tensor(constant_pad_nd_default_56, avg_pool2d_backward_default_67);  constant_pad_nd_default_56 = avg_pool2d_backward_default_67 = None
        to_dtype_753 = torch.ops.aten.to.dtype(add_tensor_316, torch.float32);  add_tensor_316 = None
        to_dtype_754 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_251 = torch.ops.aten.le.Scalar(to_dtype_754, 0);  to_dtype_754 = None
        new_zeros_default_515 = torch.ops.aten.new_zeros.default(to_dtype_753, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_251 = torch.ops.aten.where.self(le_scalar_251, new_zeros_default_515, to_dtype_753);  le_scalar_251 = new_zeros_default_515 = to_dtype_753 = None
        to_dtype_755 = torch.ops.aten.to.dtype(where_self_251, torch.float32);  where_self_251 = None
        native_batch_norm_backward_default_251 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_315, convolution_default_22, primals_1630, primals_1628, primals_1629, getitem_41, getitem_42, True, 0.001, [True, True, True]);  add_tensor_315 = convolution_default_22 = primals_1630 = primals_1628 = primals_1629 = getitem_41 = getitem_42 = None
        getitem_2956 = native_batch_norm_backward_default_251[0]
        getitem_2957 = native_batch_norm_backward_default_251[1]
        getitem_2958 = native_batch_norm_backward_default_251[2];  native_batch_norm_backward_default_251 = None
        convolution_backward_default_465 = torch.ops.aten.convolution_backward.default(getitem_2956, relu_default_6, primals_1631, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2956 = primals_1631 = None
        getitem_2959 = convolution_backward_default_465[0]
        getitem_2960 = convolution_backward_default_465[1];  convolution_backward_default_465 = None
        to_dtype_756 = torch.ops.aten.to.dtype(getitem_2959, torch.float32);  getitem_2959 = None
        to_dtype_757 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_252 = torch.ops.aten.le.Scalar(to_dtype_757, 0);  to_dtype_757 = None
        new_zeros_default_516 = torch.ops.aten.new_zeros.default(to_dtype_756, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_252 = torch.ops.aten.where.self(le_scalar_252, new_zeros_default_516, to_dtype_756);  le_scalar_252 = new_zeros_default_516 = to_dtype_756 = None
        to_dtype_758 = torch.ops.aten.to.dtype(where_self_252, torch.float32);  where_self_252 = None
        add_tensor_317 = torch.ops.aten.add.Tensor(to_dtype_722, to_dtype_758);  to_dtype_722 = to_dtype_758 = None
        slice_tensor_128 = torch.ops.aten.slice.Tensor(add_tensor_317, 1, 0, 42)
        slice_tensor_129 = torch.ops.aten.slice.Tensor(add_tensor_317, 1, 42, 84)
        slice_tensor_130 = torch.ops.aten.slice.Tensor(add_tensor_317, 1, 84, 126)
        slice_tensor_131 = torch.ops.aten.slice.Tensor(add_tensor_317, 1, 126, 168);  add_tensor_317 = None
        max_pool2d_with_indices_backward_default_6 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_131, constant_pad_nd_default_6, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_39);  constant_pad_nd_default_6 = getitem_39 = None
        constant_pad_nd_default_57 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_6, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_6 = None
        clone_default_96 = torch.ops.aten.clone.default(slice_tensor_131, memory_format = torch.contiguous_format);  slice_tensor_131 = None
        native_batch_norm_backward_default_252 = torch.ops.aten.native_batch_norm_backward.default(clone_default_96, convolution_default_21, primals_1545, primals_1543, primals_1544, getitem_36, getitem_37, True, 0.001, [True, True, True]);  clone_default_96 = convolution_default_21 = primals_1545 = primals_1543 = primals_1544 = getitem_36 = getitem_37 = None
        getitem_2962 = native_batch_norm_backward_default_252[0]
        getitem_2963 = native_batch_norm_backward_default_252[1]
        getitem_2964 = native_batch_norm_backward_default_252[2];  native_batch_norm_backward_default_252 = None
        convolution_backward_default_466 = torch.ops.aten.convolution_backward.default(getitem_2962, convolution_default_20, primals_1549, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2962 = convolution_default_20 = primals_1549 = None
        getitem_2965 = convolution_backward_default_466[0]
        getitem_2966 = convolution_backward_default_466[1];  convolution_backward_default_466 = None
        convolution_backward_default_467 = torch.ops.aten.convolution_backward.default(getitem_2965, relu__default_4, primals_1548, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 42, [True, True, False]);  getitem_2965 = primals_1548 = None
        getitem_2968 = convolution_backward_default_467[0]
        getitem_2969 = convolution_backward_default_467[1];  convolution_backward_default_467 = None
        to_dtype_759 = torch.ops.aten.to.dtype(getitem_2968, torch.float32);  getitem_2968 = None
        to_dtype_760 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_253 = torch.ops.aten.le.Scalar(to_dtype_760, 0);  to_dtype_760 = None
        new_zeros_default_517 = torch.ops.aten.new_zeros.default(to_dtype_759, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_253 = torch.ops.aten.where.self(le_scalar_253, new_zeros_default_517, to_dtype_759);  le_scalar_253 = new_zeros_default_517 = to_dtype_759 = None
        to_dtype_761 = torch.ops.aten.to.dtype(where_self_253, torch.float32);  where_self_253 = None
        native_batch_norm_backward_default_253 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_761, convolution_default_19, primals_1540, primals_1538, primals_1539, getitem_33, getitem_34, True, 0.001, [True, True, True]);  to_dtype_761 = convolution_default_19 = primals_1540 = primals_1538 = primals_1539 = getitem_33 = getitem_34 = None
        getitem_2971 = native_batch_norm_backward_default_253[0]
        getitem_2972 = native_batch_norm_backward_default_253[1]
        getitem_2973 = native_batch_norm_backward_default_253[2];  native_batch_norm_backward_default_253 = None
        convolution_backward_default_468 = torch.ops.aten.convolution_backward.default(getitem_2971, convolution_default_18, primals_1547, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2971 = convolution_default_18 = primals_1547 = None
        getitem_2974 = convolution_backward_default_468[0]
        getitem_2975 = convolution_backward_default_468[1];  convolution_backward_default_468 = None
        convolution_backward_default_469 = torch.ops.aten.convolution_backward.default(getitem_2974, relu_default_5, primals_1546, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 42, [True, True, False]);  getitem_2974 = primals_1546 = None
        getitem_2977 = convolution_backward_default_469[0]
        getitem_2978 = convolution_backward_default_469[1];  convolution_backward_default_469 = None
        to_dtype_762 = torch.ops.aten.to.dtype(getitem_2977, torch.float32);  getitem_2977 = None
        to_dtype_763 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_254 = torch.ops.aten.le.Scalar(to_dtype_763, 0);  to_dtype_763 = None
        new_zeros_default_518 = torch.ops.aten.new_zeros.default(to_dtype_762, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_254 = torch.ops.aten.where.self(le_scalar_254, new_zeros_default_518, to_dtype_762);  le_scalar_254 = new_zeros_default_518 = to_dtype_762 = None
        to_dtype_764 = torch.ops.aten.to.dtype(where_self_254, torch.float32);  where_self_254 = None
        add_tensor_318 = torch.ops.aten.add.Tensor(slice_tensor_128, slice_tensor_130);  slice_tensor_128 = None
        avg_pool2d_backward_default_68 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_130, add_tensor_1, [3, 3], [1, 1], [1, 1], False, False, None);  slice_tensor_130 = add_tensor_1 = None
        add_tensor_319 = torch.ops.aten.add.Tensor(to_dtype_764, avg_pool2d_backward_default_68);  to_dtype_764 = avg_pool2d_backward_default_68 = None
        clone_default_97 = torch.ops.aten.clone.default(slice_tensor_129, memory_format = torch.contiguous_format)
        native_batch_norm_backward_default_254 = torch.ops.aten.native_batch_norm_backward.default(clone_default_97, convolution_default_17, primals_1531, primals_1529, primals_1530, getitem_30, getitem_31, True, 0.001, [True, True, True]);  clone_default_97 = convolution_default_17 = primals_1531 = primals_1529 = primals_1530 = getitem_30 = getitem_31 = None
        getitem_2980 = native_batch_norm_backward_default_254[0]
        getitem_2981 = native_batch_norm_backward_default_254[1]
        getitem_2982 = native_batch_norm_backward_default_254[2];  native_batch_norm_backward_default_254 = None
        convolution_backward_default_470 = torch.ops.aten.convolution_backward.default(getitem_2980, convolution_default_16, primals_1535, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2980 = convolution_default_16 = primals_1535 = None
        getitem_2983 = convolution_backward_default_470[0]
        getitem_2984 = convolution_backward_default_470[1];  convolution_backward_default_470 = None
        convolution_backward_default_471 = torch.ops.aten.convolution_backward.default(getitem_2983, relu__default_3, primals_1534, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 42, [True, True, False]);  getitem_2983 = primals_1534 = None
        getitem_2986 = convolution_backward_default_471[0]
        getitem_2987 = convolution_backward_default_471[1];  convolution_backward_default_471 = None
        to_dtype_765 = torch.ops.aten.to.dtype(getitem_2986, torch.float32);  getitem_2986 = None
        to_dtype_766 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_255 = torch.ops.aten.le.Scalar(to_dtype_766, 0);  to_dtype_766 = None
        new_zeros_default_519 = torch.ops.aten.new_zeros.default(to_dtype_765, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_255 = torch.ops.aten.where.self(le_scalar_255, new_zeros_default_519, to_dtype_765);  le_scalar_255 = new_zeros_default_519 = to_dtype_765 = None
        to_dtype_767 = torch.ops.aten.to.dtype(where_self_255, torch.float32);  where_self_255 = None
        native_batch_norm_backward_default_255 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_767, convolution_default_15, primals_1526, primals_1524, primals_1525, getitem_27, getitem_28, True, 0.001, [True, True, True]);  to_dtype_767 = convolution_default_15 = primals_1526 = primals_1524 = primals_1525 = getitem_27 = getitem_28 = None
        getitem_2989 = native_batch_norm_backward_default_255[0]
        getitem_2990 = native_batch_norm_backward_default_255[1]
        getitem_2991 = native_batch_norm_backward_default_255[2];  native_batch_norm_backward_default_255 = None
        convolution_backward_default_472 = torch.ops.aten.convolution_backward.default(getitem_2989, convolution_default_14, primals_1533, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2989 = convolution_default_14 = primals_1533 = None
        getitem_2992 = convolution_backward_default_472[0]
        getitem_2993 = convolution_backward_default_472[1];  convolution_backward_default_472 = None
        convolution_backward_default_473 = torch.ops.aten.convolution_backward.default(getitem_2992, constant_pad_nd_default_5, primals_1532, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_2992 = constant_pad_nd_default_5 = primals_1532 = None
        getitem_2995 = convolution_backward_default_473[0]
        getitem_2996 = convolution_backward_default_473[1];  convolution_backward_default_473 = None
        constant_pad_nd_default_58 = torch.ops.aten.constant_pad_nd.default(getitem_2995, [-2, -2, -2, -2]);  getitem_2995 = None
        to_dtype_768 = torch.ops.aten.to.dtype(constant_pad_nd_default_58, torch.float32);  constant_pad_nd_default_58 = None
        to_dtype_769 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_256 = torch.ops.aten.le.Scalar(to_dtype_769, 0);  to_dtype_769 = None
        new_zeros_default_520 = torch.ops.aten.new_zeros.default(to_dtype_768, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_256 = torch.ops.aten.where.self(le_scalar_256, new_zeros_default_520, to_dtype_768);  le_scalar_256 = new_zeros_default_520 = to_dtype_768 = None
        to_dtype_770 = torch.ops.aten.to.dtype(where_self_256, torch.float32);  where_self_256 = None
        add_tensor_320 = torch.ops.aten.add.Tensor(to_dtype_755, to_dtype_770);  to_dtype_755 = to_dtype_770 = None
        avg_pool2d_backward_default_69 = torch.ops.aten.avg_pool2d_backward.default(slice_tensor_129, constant_pad_nd_default_4, [3, 3], [2, 2], [0, 0], False, False, None);  slice_tensor_129 = constant_pad_nd_default_4 = None
        constant_pad_nd_default_59 = torch.ops.aten.constant_pad_nd.default(avg_pool2d_backward_default_69, [-1, -1, -1, -1]);  avg_pool2d_backward_default_69 = None
        add_tensor_321 = torch.ops.aten.add.Tensor(constant_pad_nd_default_57, constant_pad_nd_default_59);  constant_pad_nd_default_57 = constant_pad_nd_default_59 = None
        native_batch_norm_backward_default_256 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_318, convolution_default_13, primals_1517, primals_1515, primals_1516, getitem_24, getitem_25, True, 0.001, [True, True, True]);  convolution_default_13 = primals_1517 = primals_1515 = primals_1516 = getitem_24 = getitem_25 = None
        getitem_2998 = native_batch_norm_backward_default_256[0]
        getitem_2999 = native_batch_norm_backward_default_256[1]
        getitem_3000 = native_batch_norm_backward_default_256[2];  native_batch_norm_backward_default_256 = None
        convolution_backward_default_474 = torch.ops.aten.convolution_backward.default(getitem_2998, convolution_default_12, primals_1521, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_2998 = convolution_default_12 = primals_1521 = None
        getitem_3001 = convolution_backward_default_474[0]
        getitem_3002 = convolution_backward_default_474[1];  convolution_backward_default_474 = None
        convolution_backward_default_475 = torch.ops.aten.convolution_backward.default(getitem_3001, relu__default_2, primals_1520, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 42, [True, True, False]);  getitem_3001 = primals_1520 = None
        getitem_3004 = convolution_backward_default_475[0]
        getitem_3005 = convolution_backward_default_475[1];  convolution_backward_default_475 = None
        to_dtype_771 = torch.ops.aten.to.dtype(getitem_3004, torch.float32);  getitem_3004 = None
        to_dtype_772 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_257 = torch.ops.aten.le.Scalar(to_dtype_772, 0);  to_dtype_772 = None
        new_zeros_default_521 = torch.ops.aten.new_zeros.default(to_dtype_771, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_257 = torch.ops.aten.where.self(le_scalar_257, new_zeros_default_521, to_dtype_771);  le_scalar_257 = new_zeros_default_521 = to_dtype_771 = None
        to_dtype_773 = torch.ops.aten.to.dtype(where_self_257, torch.float32);  where_self_257 = None
        native_batch_norm_backward_default_257 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_773, convolution_default_11, primals_1512, primals_1510, primals_1511, getitem_21, getitem_22, True, 0.001, [True, True, True]);  to_dtype_773 = convolution_default_11 = primals_1512 = primals_1510 = primals_1511 = getitem_21 = getitem_22 = None
        getitem_3007 = native_batch_norm_backward_default_257[0]
        getitem_3008 = native_batch_norm_backward_default_257[1]
        getitem_3009 = native_batch_norm_backward_default_257[2];  native_batch_norm_backward_default_257 = None
        convolution_backward_default_476 = torch.ops.aten.convolution_backward.default(getitem_3007, convolution_default_10, primals_1519, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_3007 = convolution_default_10 = primals_1519 = None
        getitem_3010 = convolution_backward_default_476[0]
        getitem_3011 = convolution_backward_default_476[1];  convolution_backward_default_476 = None
        convolution_backward_default_477 = torch.ops.aten.convolution_backward.default(getitem_3010, constant_pad_nd_default_3, primals_1518, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_3010 = constant_pad_nd_default_3 = primals_1518 = None
        getitem_3013 = convolution_backward_default_477[0]
        getitem_3014 = convolution_backward_default_477[1];  convolution_backward_default_477 = None
        constant_pad_nd_default_60 = torch.ops.aten.constant_pad_nd.default(getitem_3013, [-3, -3, -3, -3]);  getitem_3013 = None
        to_dtype_774 = torch.ops.aten.to.dtype(constant_pad_nd_default_60, torch.float32);  constant_pad_nd_default_60 = None
        to_dtype_775 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_258 = torch.ops.aten.le.Scalar(to_dtype_775, 0);  to_dtype_775 = None
        new_zeros_default_522 = torch.ops.aten.new_zeros.default(to_dtype_774, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_258 = torch.ops.aten.where.self(le_scalar_258, new_zeros_default_522, to_dtype_774);  le_scalar_258 = new_zeros_default_522 = to_dtype_774 = None
        to_dtype_776 = torch.ops.aten.to.dtype(where_self_258, torch.float32);  where_self_258 = None
        add_tensor_322 = torch.ops.aten.add.Tensor(add_tensor_320, to_dtype_776);  add_tensor_320 = to_dtype_776 = None
        max_pool2d_with_indices_backward_default_7 = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_318, constant_pad_nd_default_2, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_19);  add_tensor_318 = constant_pad_nd_default_2 = getitem_19 = None
        constant_pad_nd_default_61 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default_7, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default_7 = None
        add_tensor_323 = torch.ops.aten.add.Tensor(add_tensor_321, constant_pad_nd_default_61);  add_tensor_321 = constant_pad_nd_default_61 = None
        native_batch_norm_backward_default_258 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_319, convolution_default_9, primals_1503, primals_1501, primals_1502, getitem_16, getitem_17, True, 0.001, [True, True, True]);  convolution_default_9 = primals_1503 = primals_1501 = primals_1502 = getitem_16 = getitem_17 = None
        getitem_3016 = native_batch_norm_backward_default_258[0]
        getitem_3017 = native_batch_norm_backward_default_258[1]
        getitem_3018 = native_batch_norm_backward_default_258[2];  native_batch_norm_backward_default_258 = None
        convolution_backward_default_478 = torch.ops.aten.convolution_backward.default(getitem_3016, convolution_default_8, primals_1507, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_3016 = convolution_default_8 = primals_1507 = None
        getitem_3019 = convolution_backward_default_478[0]
        getitem_3020 = convolution_backward_default_478[1];  convolution_backward_default_478 = None
        convolution_backward_default_479 = torch.ops.aten.convolution_backward.default(getitem_3019, relu__default_1, primals_1506, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 42, [True, True, False]);  getitem_3019 = primals_1506 = None
        getitem_3022 = convolution_backward_default_479[0]
        getitem_3023 = convolution_backward_default_479[1];  convolution_backward_default_479 = None
        to_dtype_777 = torch.ops.aten.to.dtype(getitem_3022, torch.float32);  getitem_3022 = None
        to_dtype_778 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_259 = torch.ops.aten.le.Scalar(to_dtype_778, 0);  to_dtype_778 = None
        new_zeros_default_523 = torch.ops.aten.new_zeros.default(to_dtype_777, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_259 = torch.ops.aten.where.self(le_scalar_259, new_zeros_default_523, to_dtype_777);  le_scalar_259 = new_zeros_default_523 = to_dtype_777 = None
        to_dtype_779 = torch.ops.aten.to.dtype(where_self_259, torch.float32);  where_self_259 = None
        native_batch_norm_backward_default_259 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_779, convolution_default_7, primals_1498, primals_1496, primals_1497, getitem_13, getitem_14, True, 0.001, [True, True, True]);  to_dtype_779 = convolution_default_7 = primals_1498 = primals_1496 = primals_1497 = getitem_13 = getitem_14 = None
        getitem_3025 = native_batch_norm_backward_default_259[0]
        getitem_3026 = native_batch_norm_backward_default_259[1]
        getitem_3027 = native_batch_norm_backward_default_259[2];  native_batch_norm_backward_default_259 = None
        convolution_backward_default_480 = torch.ops.aten.convolution_backward.default(getitem_3025, convolution_default_6, primals_1505, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_3025 = convolution_default_6 = primals_1505 = None
        getitem_3028 = convolution_backward_default_480[0]
        getitem_3029 = convolution_backward_default_480[1];  convolution_backward_default_480 = None
        convolution_backward_default_481 = torch.ops.aten.convolution_backward.default(getitem_3028, constant_pad_nd_default_1, primals_1504, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_3028 = constant_pad_nd_default_1 = primals_1504 = None
        getitem_3031 = convolution_backward_default_481[0]
        getitem_3032 = convolution_backward_default_481[1];  convolution_backward_default_481 = None
        constant_pad_nd_default_62 = torch.ops.aten.constant_pad_nd.default(getitem_3031, [-3, -3, -3, -3]);  getitem_3031 = None
        to_dtype_780 = torch.ops.aten.to.dtype(constant_pad_nd_default_62, torch.float32);  constant_pad_nd_default_62 = None
        to_dtype_781 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_260 = torch.ops.aten.le.Scalar(to_dtype_781, 0);  to_dtype_781 = None
        new_zeros_default_524 = torch.ops.aten.new_zeros.default(to_dtype_780, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_260 = torch.ops.aten.where.self(le_scalar_260, new_zeros_default_524, to_dtype_780);  le_scalar_260 = new_zeros_default_524 = to_dtype_780 = None
        to_dtype_782 = torch.ops.aten.to.dtype(where_self_260, torch.float32);  where_self_260 = None
        add_tensor_324 = torch.ops.aten.add.Tensor(add_tensor_322, to_dtype_782);  add_tensor_322 = to_dtype_782 = None
        native_batch_norm_backward_default_260 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_319, convolution_default_5, primals_1489, primals_1487, primals_1488, getitem_10, getitem_11, True, 0.001, [True, True, True]);  add_tensor_319 = convolution_default_5 = primals_1489 = primals_1487 = primals_1488 = getitem_10 = getitem_11 = None
        getitem_3034 = native_batch_norm_backward_default_260[0]
        getitem_3035 = native_batch_norm_backward_default_260[1]
        getitem_3036 = native_batch_norm_backward_default_260[2];  native_batch_norm_backward_default_260 = None
        convolution_backward_default_482 = torch.ops.aten.convolution_backward.default(getitem_3034, convolution_default_4, primals_1493, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_3034 = convolution_default_4 = primals_1493 = None
        getitem_3037 = convolution_backward_default_482[0]
        getitem_3038 = convolution_backward_default_482[1];  convolution_backward_default_482 = None
        convolution_backward_default_483 = torch.ops.aten.convolution_backward.default(getitem_3037, relu__default, primals_1492, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 42, [True, True, False]);  getitem_3037 = primals_1492 = None
        getitem_3040 = convolution_backward_default_483[0]
        getitem_3041 = convolution_backward_default_483[1];  convolution_backward_default_483 = None
        to_dtype_783 = torch.ops.aten.to.dtype(getitem_3040, torch.float32);  getitem_3040 = None
        to_dtype_784 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_261 = torch.ops.aten.le.Scalar(to_dtype_784, 0);  to_dtype_784 = None
        new_zeros_default_525 = torch.ops.aten.new_zeros.default(to_dtype_783, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_261 = torch.ops.aten.where.self(le_scalar_261, new_zeros_default_525, to_dtype_783);  le_scalar_261 = new_zeros_default_525 = to_dtype_783 = None
        to_dtype_785 = torch.ops.aten.to.dtype(where_self_261, torch.float32);  where_self_261 = None
        native_batch_norm_backward_default_261 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_785, convolution_default_3, primals_1484, primals_1482, primals_1483, getitem_7, getitem_8, True, 0.001, [True, True, True]);  to_dtype_785 = convolution_default_3 = primals_1484 = primals_1482 = primals_1483 = getitem_7 = getitem_8 = None
        getitem_3043 = native_batch_norm_backward_default_261[0]
        getitem_3044 = native_batch_norm_backward_default_261[1]
        getitem_3045 = native_batch_norm_backward_default_261[2];  native_batch_norm_backward_default_261 = None
        convolution_backward_default_484 = torch.ops.aten.convolution_backward.default(getitem_3043, convolution_default_2, primals_1491, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_3043 = convolution_default_2 = primals_1491 = None
        getitem_3046 = convolution_backward_default_484[0]
        getitem_3047 = convolution_backward_default_484[1];  convolution_backward_default_484 = None
        convolution_backward_default_485 = torch.ops.aten.convolution_backward.default(getitem_3046, constant_pad_nd_default, primals_1490, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 42, [True, True, False]);  getitem_3046 = constant_pad_nd_default = primals_1490 = None
        getitem_3049 = convolution_backward_default_485[0]
        getitem_3050 = convolution_backward_default_485[1];  convolution_backward_default_485 = None
        constant_pad_nd_default_63 = torch.ops.aten.constant_pad_nd.default(getitem_3049, [-2, -2, -2, -2]);  getitem_3049 = None
        to_dtype_786 = torch.ops.aten.to.dtype(constant_pad_nd_default_63, torch.float32);  constant_pad_nd_default_63 = None
        to_dtype_787 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_262 = torch.ops.aten.le.Scalar(to_dtype_787, 0);  to_dtype_787 = None
        new_zeros_default_526 = torch.ops.aten.new_zeros.default(to_dtype_786, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_262 = torch.ops.aten.where.self(le_scalar_262, new_zeros_default_526, to_dtype_786);  le_scalar_262 = new_zeros_default_526 = to_dtype_786 = None
        to_dtype_788 = torch.ops.aten.to.dtype(where_self_262, torch.float32);  where_self_262 = None
        add_tensor_325 = torch.ops.aten.add.Tensor(add_tensor_323, to_dtype_788);  add_tensor_323 = to_dtype_788 = None
        native_batch_norm_backward_default_262 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_325, convolution_default_1, primals_1554, primals_1552, primals_1553, getitem_4, getitem_5, True, 0.001, [True, True, True]);  add_tensor_325 = convolution_default_1 = primals_1554 = primals_1552 = primals_1553 = getitem_4 = getitem_5 = None
        getitem_3052 = native_batch_norm_backward_default_262[0]
        getitem_3053 = native_batch_norm_backward_default_262[1]
        getitem_3054 = native_batch_norm_backward_default_262[2];  native_batch_norm_backward_default_262 = None
        convolution_backward_default_486 = torch.ops.aten.convolution_backward.default(getitem_3052, relu_default, primals_1555, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_3052 = primals_1555 = None
        getitem_3055 = convolution_backward_default_486[0]
        getitem_3056 = convolution_backward_default_486[1];  convolution_backward_default_486 = None
        to_dtype_789 = torch.ops.aten.to.dtype(getitem_3055, torch.float32);  getitem_3055 = None
        to_dtype_790 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_263 = torch.ops.aten.le.Scalar(to_dtype_790, 0);  to_dtype_790 = None
        new_zeros_default_527 = torch.ops.aten.new_zeros.default(to_dtype_789, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_263 = torch.ops.aten.where.self(le_scalar_263, new_zeros_default_527, to_dtype_789);  le_scalar_263 = new_zeros_default_527 = to_dtype_789 = None
        to_dtype_791 = torch.ops.aten.to.dtype(where_self_263, torch.float32);  where_self_263 = None
        add_tensor_326 = torch.ops.aten.add.Tensor(add_tensor_324, to_dtype_791);  add_tensor_324 = to_dtype_791 = None
        native_batch_norm_backward_default_263 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_326, convolution_default, primals_1810, primals_1808, primals_1809, getitem_1, getitem_2, True, 0.001, [True, True, True]);  add_tensor_326 = convolution_default = primals_1810 = primals_1808 = primals_1809 = getitem_1 = getitem_2 = None
        getitem_3058 = native_batch_norm_backward_default_263[0]
        getitem_3059 = native_batch_norm_backward_default_263[1]
        getitem_3060 = native_batch_norm_backward_default_263[2];  native_batch_norm_backward_default_263 = None
        convolution_backward_default_487 = torch.ops.aten.convolution_backward.default(getitem_3058, primals_1806, primals_1639, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_3058 = primals_1806 = primals_1639 = None
        getitem_3062 = convolution_backward_default_487[1];  convolution_backward_default_487 = None
        return [getitem_2835, None, None, None, getitem_2834, getitem_2826, None, None, None, getitem_2825, getitem_2840, getitem_2837, getitem_2831, getitem_2828, getitem_2817, None, None, None, getitem_2816, getitem_2808, None, None, None, getitem_2807, getitem_2822, getitem_2819, getitem_2813, getitem_2810, getitem_2799, None, None, None, getitem_2798, getitem_2790, None, None, None, getitem_2789, getitem_2804, getitem_2801, getitem_2795, getitem_2792, getitem_2781, None, None, None, getitem_2780, getitem_2772, None, None, None, getitem_2771, getitem_2786, getitem_2783, getitem_2777, getitem_2774, getitem_2763, None, None, None, getitem_2762, getitem_2754, None, None, None, getitem_2753, getitem_2768, getitem_2765, getitem_2759, getitem_2756, getitem_2844, None, None, None, getitem_2843, getitem_2846, getitem_2850, None, None, None, getitem_2849, getitem_2855, getitem_2852, getitem_1710, None, None, None, getitem_1709, getitem_1701, None, None, None, getitem_1700, getitem_1715, getitem_1712, getitem_1706, getitem_1703, getitem_1692, None, None, None, getitem_1691, getitem_1683, None, None, None, getitem_1682, getitem_1697, getitem_1694, getitem_1688, getitem_1685, getitem_1674, None, None, None, getitem_1673, getitem_1665, None, None, None, getitem_1664, getitem_1679, getitem_1676, getitem_1670, getitem_1667, getitem_1656, None, None, None, getitem_1655, getitem_1647, None, None, None, getitem_1646, getitem_1661, getitem_1658, getitem_1652, getitem_1649, getitem_1638, None, None, None, getitem_1637, getitem_1629, None, None, None, getitem_1628, getitem_1643, getitem_1640, getitem_1634, getitem_1631, getitem_1719, None, None, None, getitem_1718, getitem_1721, getitem_1725, None, None, None, getitem_1724, getitem_1727, getitem_1608, None, None, None, getitem_1607, getitem_1599, None, None, None, getitem_1598, getitem_1613, getitem_1610, getitem_1604, getitem_1601, getitem_1590, None, None, None, getitem_1589, getitem_1581, None, None, None, getitem_1580, getitem_1595, getitem_1592, getitem_1586, getitem_1583, getitem_1572, None, None, None, getitem_1571, getitem_1563, None, None, None, getitem_1562, getitem_1577, getitem_1574, getitem_1568, getitem_1565, getitem_1554, None, None, None, getitem_1553, getitem_1545, None, None, None, getitem_1544, getitem_1559, getitem_1556, getitem_1550, getitem_1547, getitem_1536, None, None, None, getitem_1535, getitem_1527, None, None, None, getitem_1526, getitem_1541, getitem_1538, getitem_1532, getitem_1529, getitem_1617, None, None, None, getitem_1616, getitem_1619, getitem_1623, None, None, None, getitem_1622, getitem_1625, getitem_1401, None, None, None, getitem_1400, getitem_1392, None, None, None, getitem_1391, getitem_1406, getitem_1403, getitem_1397, getitem_1394, getitem_1383, None, None, None, getitem_1382, getitem_1374, None, None, None, getitem_1373, getitem_1388, getitem_1385, getitem_1379, getitem_1376, getitem_1365, None, None, None, getitem_1364, getitem_1356, None, None, None, getitem_1355, getitem_1370, getitem_1367, getitem_1361, getitem_1358, getitem_1347, None, None, None, getitem_1346, getitem_1338, None, None, None, getitem_1337, getitem_1352, getitem_1349, getitem_1343, getitem_1340, getitem_1329, None, None, None, getitem_1328, getitem_1320, None, None, None, getitem_1319, getitem_1334, getitem_1331, getitem_1325, getitem_1322, getitem_1410, None, None, None, getitem_1409, getitem_1412, getitem_1416, None, None, None, getitem_1415, getitem_1421, getitem_1418, getitem_1299, None, None, None, getitem_1298, getitem_1290, None, None, None, getitem_1289, getitem_1304, getitem_1301, getitem_1295, getitem_1292, getitem_1281, None, None, None, getitem_1280, getitem_1272, None, None, None, getitem_1271, getitem_1286, getitem_1283, getitem_1277, getitem_1274, getitem_1263, None, None, None, getitem_1262, getitem_1254, None, None, None, getitem_1253, getitem_1268, getitem_1265, getitem_1259, getitem_1256, getitem_1245, None, None, None, getitem_1244, getitem_1236, None, None, None, getitem_1235, getitem_1250, getitem_1247, getitem_1241, getitem_1238, getitem_1227, None, None, None, getitem_1226, getitem_1218, None, None, None, getitem_1217, getitem_1232, getitem_1229, getitem_1223, getitem_1220, getitem_1308, None, None, None, getitem_1307, getitem_1310, getitem_1314, None, None, None, getitem_1313, getitem_1316, getitem_1197, None, None, None, getitem_1196, getitem_1188, None, None, None, getitem_1187, getitem_1202, getitem_1199, getitem_1193, getitem_1190, getitem_1179, None, None, None, getitem_1178, getitem_1170, None, None, None, getitem_1169, getitem_1184, getitem_1181, getitem_1175, getitem_1172, getitem_1161, None, None, None, getitem_1160, getitem_1152, None, None, None, getitem_1151, getitem_1166, getitem_1163, getitem_1157, getitem_1154, getitem_1143, None, None, None, getitem_1142, getitem_1134, None, None, None, getitem_1133, getitem_1148, getitem_1145, getitem_1139, getitem_1136, getitem_1125, None, None, None, getitem_1124, getitem_1116, None, None, None, getitem_1115, getitem_1130, getitem_1127, getitem_1121, getitem_1118, getitem_1206, None, None, None, getitem_1205, getitem_1208, getitem_1212, None, None, None, getitem_1211, getitem_1214, getitem_1095, None, None, None, getitem_1094, getitem_1086, None, None, None, getitem_1085, getitem_1100, getitem_1097, getitem_1091, getitem_1088, getitem_1077, None, None, None, getitem_1076, getitem_1068, None, None, None, getitem_1067, getitem_1082, getitem_1079, getitem_1073, getitem_1070, getitem_1059, None, None, None, getitem_1058, getitem_1050, None, None, None, getitem_1049, getitem_1064, getitem_1061, getitem_1055, getitem_1052, getitem_1041, None, None, None, getitem_1040, getitem_1032, None, None, None, getitem_1031, getitem_1046, getitem_1043, getitem_1037, getitem_1034, getitem_1023, None, None, None, getitem_1022, getitem_1014, None, None, None, getitem_1013, getitem_1028, getitem_1025, getitem_1019, getitem_1016, getitem_1104, None, None, None, getitem_1103, getitem_1106, getitem_1110, None, None, None, getitem_1109, getitem_1112, getitem_993, None, None, None, getitem_992, getitem_984, None, None, None, getitem_983, getitem_998, getitem_995, getitem_989, getitem_986, getitem_975, None, None, None, getitem_974, getitem_966, None, None, None, getitem_965, getitem_980, getitem_977, getitem_971, getitem_968, getitem_957, None, None, None, getitem_956, getitem_948, None, None, None, getitem_947, getitem_962, getitem_959, getitem_953, getitem_950, getitem_939, None, None, None, getitem_938, getitem_930, None, None, None, getitem_929, getitem_944, getitem_941, getitem_935, getitem_932, getitem_921, None, None, None, getitem_920, getitem_912, None, None, None, getitem_911, getitem_926, getitem_923, getitem_917, getitem_914, getitem_1002, None, None, None, getitem_1001, getitem_1004, getitem_1008, None, None, None, getitem_1007, getitem_1010, getitem_891, None, None, None, getitem_890, getitem_882, None, None, None, getitem_881, getitem_896, getitem_893, getitem_887, getitem_884, getitem_873, None, None, None, getitem_872, getitem_864, None, None, None, getitem_863, getitem_878, getitem_875, getitem_869, getitem_866, getitem_855, None, None, None, getitem_854, getitem_846, None, None, None, getitem_845, getitem_860, getitem_857, getitem_851, getitem_848, getitem_837, None, None, None, getitem_836, getitem_828, None, None, None, getitem_827, getitem_842, getitem_839, getitem_833, getitem_830, getitem_819, None, None, None, getitem_818, getitem_810, None, None, None, getitem_809, getitem_824, getitem_821, getitem_815, getitem_812, getitem_900, None, None, None, getitem_899, getitem_902, getitem_906, None, None, None, getitem_905, getitem_908, getitem_2733, None, None, None, getitem_2732, getitem_2724, None, None, None, getitem_2723, getitem_2738, getitem_2735, getitem_2729, getitem_2726, getitem_2715, None, None, None, getitem_2714, getitem_2706, None, None, None, getitem_2705, getitem_2720, getitem_2717, getitem_2711, getitem_2708, getitem_2697, None, None, None, getitem_2696, getitem_2688, None, None, None, getitem_2687, getitem_2702, getitem_2699, getitem_2693, getitem_2690, getitem_2679, None, None, None, getitem_2678, getitem_2670, None, None, None, getitem_2669, getitem_2684, getitem_2681, getitem_2675, getitem_2672, getitem_2661, None, None, None, getitem_2660, getitem_2652, None, None, None, getitem_2651, getitem_2666, getitem_2663, getitem_2657, getitem_2654, getitem_2742, None, None, None, getitem_2741, getitem_2744, getitem_2748, None, None, None, getitem_2747, getitem_2750, getitem_2631, None, None, None, getitem_2630, getitem_2622, None, None, None, getitem_2621, getitem_2636, getitem_2633, getitem_2627, getitem_2624, getitem_2613, None, None, None, getitem_2612, getitem_2604, None, None, None, getitem_2603, getitem_2618, getitem_2615, getitem_2609, getitem_2606, getitem_2595, None, None, None, getitem_2594, getitem_2586, None, None, None, getitem_2585, getitem_2600, getitem_2597, getitem_2591, getitem_2588, getitem_2577, None, None, None, getitem_2576, getitem_2568, None, None, None, getitem_2567, getitem_2582, getitem_2579, getitem_2573, getitem_2570, getitem_2559, None, None, None, getitem_2558, getitem_2550, None, None, None, getitem_2549, getitem_2564, getitem_2561, getitem_2555, getitem_2552, getitem_2640, None, None, None, getitem_2639, getitem_2642, getitem_2646, None, None, None, getitem_2645, getitem_2648, getitem_2529, None, None, None, getitem_2528, getitem_2520, None, None, None, getitem_2519, getitem_2534, getitem_2531, getitem_2525, getitem_2522, getitem_2511, None, None, None, getitem_2510, getitem_2502, None, None, None, getitem_2501, getitem_2516, getitem_2513, getitem_2507, getitem_2504, getitem_2493, None, None, None, getitem_2492, getitem_2484, None, None, None, getitem_2483, getitem_2498, getitem_2495, getitem_2489, getitem_2486, getitem_2475, None, None, None, getitem_2474, getitem_2466, None, None, None, getitem_2465, getitem_2480, getitem_2477, getitem_2471, getitem_2468, getitem_2457, None, None, None, getitem_2456, getitem_2448, None, None, None, getitem_2447, getitem_2462, getitem_2459, getitem_2453, getitem_2450, getitem_2538, None, None, None, getitem_2537, getitem_2540, getitem_2544, None, None, None, getitem_2543, getitem_2546, getitem_2427, None, None, None, getitem_2426, getitem_2418, None, None, None, getitem_2417, getitem_2432, getitem_2429, getitem_2423, getitem_2420, getitem_2409, None, None, None, getitem_2408, getitem_2400, None, None, None, getitem_2399, getitem_2414, getitem_2411, getitem_2405, getitem_2402, getitem_2391, None, None, None, getitem_2390, getitem_2382, None, None, None, getitem_2381, getitem_2396, getitem_2393, getitem_2387, getitem_2384, getitem_2373, None, None, None, getitem_2372, getitem_2364, None, None, None, getitem_2363, getitem_2378, getitem_2375, getitem_2369, getitem_2366, getitem_2355, None, None, None, getitem_2354, getitem_2346, None, None, None, getitem_2345, getitem_2360, getitem_2357, getitem_2351, getitem_2348, getitem_2436, None, None, None, getitem_2435, getitem_2438, getitem_2442, None, None, None, getitem_2441, getitem_2444, getitem_2325, None, None, None, getitem_2324, getitem_2316, None, None, None, getitem_2315, getitem_2330, getitem_2327, getitem_2321, getitem_2318, getitem_2307, None, None, None, getitem_2306, getitem_2298, None, None, None, getitem_2297, getitem_2312, getitem_2309, getitem_2303, getitem_2300, getitem_2289, None, None, None, getitem_2288, getitem_2280, None, None, None, getitem_2279, getitem_2294, getitem_2291, getitem_2285, getitem_2282, getitem_2271, None, None, None, getitem_2270, getitem_2262, None, None, None, getitem_2261, getitem_2276, getitem_2273, getitem_2267, getitem_2264, getitem_2253, None, None, None, getitem_2252, getitem_2244, None, None, None, getitem_2243, getitem_2258, getitem_2255, getitem_2249, getitem_2246, getitem_2334, None, None, None, getitem_2333, getitem_2336, getitem_2340, None, None, None, getitem_2339, getitem_2342, getitem_2118, None, None, None, getitem_2117, getitem_2109, None, None, None, getitem_2108, getitem_2123, getitem_2120, getitem_2114, getitem_2111, getitem_2100, None, None, None, getitem_2099, getitem_2091, None, None, None, getitem_2090, getitem_2105, getitem_2102, getitem_2096, getitem_2093, getitem_2082, None, None, None, getitem_2081, getitem_2073, None, None, None, getitem_2072, getitem_2087, getitem_2084, getitem_2078, getitem_2075, getitem_2064, None, None, None, getitem_2063, getitem_2055, None, None, None, getitem_2054, getitem_2069, getitem_2066, getitem_2060, getitem_2057, getitem_2046, None, None, None, getitem_2045, getitem_2037, None, None, None, getitem_2036, getitem_2051, getitem_2048, getitem_2042, getitem_2039, getitem_2127, None, None, None, getitem_2126, getitem_2129, getitem_2133, None, None, None, getitem_2132, getitem_2138, getitem_2135, getitem_2016, None, None, None, getitem_2015, getitem_2007, None, None, None, getitem_2006, getitem_2021, getitem_2018, getitem_2012, getitem_2009, getitem_1998, None, None, None, getitem_1997, getitem_1989, None, None, None, getitem_1988, getitem_2003, getitem_2000, getitem_1994, getitem_1991, getitem_1980, None, None, None, getitem_1979, getitem_1971, None, None, None, getitem_1970, getitem_1985, getitem_1982, getitem_1976, getitem_1973, getitem_1962, None, None, None, getitem_1961, getitem_1953, None, None, None, getitem_1952, getitem_1967, getitem_1964, getitem_1958, getitem_1955, getitem_1944, None, None, None, getitem_1943, getitem_1935, None, None, None, getitem_1934, getitem_1949, getitem_1946, getitem_1940, getitem_1937, getitem_2025, None, None, None, getitem_2024, getitem_2027, getitem_2031, None, None, None, getitem_2030, getitem_2033, getitem_1914, None, None, None, getitem_1913, getitem_1905, None, None, None, getitem_1904, getitem_1919, getitem_1916, getitem_1910, getitem_1907, getitem_1896, None, None, None, getitem_1895, getitem_1887, None, None, None, getitem_1886, getitem_1901, getitem_1898, getitem_1892, getitem_1889, getitem_1878, None, None, None, getitem_1877, getitem_1869, None, None, None, getitem_1868, getitem_1883, getitem_1880, getitem_1874, getitem_1871, getitem_1860, None, None, None, getitem_1859, getitem_1851, None, None, None, getitem_1850, getitem_1865, getitem_1862, getitem_1856, getitem_1853, getitem_1842, None, None, None, getitem_1841, getitem_1833, None, None, None, getitem_1832, getitem_1847, getitem_1844, getitem_1838, getitem_1835, getitem_1923, None, None, None, getitem_1922, getitem_1925, getitem_1929, None, None, None, getitem_1928, getitem_1931, getitem_1812, None, None, None, getitem_1811, getitem_1803, None, None, None, getitem_1802, getitem_1817, getitem_1814, getitem_1808, getitem_1805, getitem_1794, None, None, None, getitem_1793, getitem_1785, None, None, None, getitem_1784, getitem_1799, getitem_1796, getitem_1790, getitem_1787, getitem_1776, None, None, None, getitem_1775, getitem_1767, None, None, None, getitem_1766, getitem_1781, getitem_1778, getitem_1772, getitem_1769, getitem_1758, None, None, None, getitem_1757, getitem_1749, None, None, None, getitem_1748, getitem_1763, getitem_1760, getitem_1754, getitem_1751, getitem_1740, None, None, None, getitem_1739, getitem_1731, None, None, None, getitem_1730, getitem_1745, getitem_1742, getitem_1736, getitem_1733, getitem_1821, None, None, None, getitem_1820, getitem_1823, getitem_1827, None, None, None, getitem_1826, getitem_1829, getitem_3045, None, None, None, getitem_3044, getitem_3036, None, None, None, getitem_3035, getitem_3050, getitem_3047, getitem_3041, getitem_3038, getitem_3027, None, None, None, getitem_3026, getitem_3018, None, None, None, getitem_3017, getitem_3032, getitem_3029, getitem_3023, getitem_3020, getitem_3009, None, None, None, getitem_3008, getitem_3000, None, None, None, getitem_2999, getitem_3014, getitem_3011, getitem_3005, getitem_3002, getitem_2991, None, None, None, getitem_2990, getitem_2982, None, None, None, getitem_2981, getitem_2996, getitem_2993, getitem_2987, getitem_2984, getitem_2973, None, None, None, getitem_2972, getitem_2964, None, None, None, getitem_2963, getitem_2978, getitem_2975, getitem_2969, getitem_2966, getitem_3054, None, None, None, getitem_3053, getitem_3056, getitem_2940, None, None, None, getitem_2939, getitem_2931, None, None, None, getitem_2930, getitem_2945, getitem_2942, getitem_2936, getitem_2933, getitem_2922, None, None, None, getitem_2921, getitem_2913, None, None, None, getitem_2912, getitem_2927, getitem_2924, getitem_2918, getitem_2915, getitem_2904, None, None, None, getitem_2903, getitem_2895, None, None, None, getitem_2894, getitem_2909, getitem_2906, getitem_2900, getitem_2897, getitem_2886, None, None, None, getitem_2885, getitem_2877, None, None, None, getitem_2876, getitem_2891, getitem_2888, getitem_2882, getitem_2879, getitem_2868, None, None, None, getitem_2867, getitem_2859, None, None, None, getitem_2858, getitem_2873, getitem_2870, getitem_2864, getitem_2861, getitem_2958, None, None, None, getitem_2957, getitem_2960, getitem_2949, None, None, None, getitem_2948, getitem_2954, getitem_2951, getitem_3062, view_default_1, t_default_4, getitem_2223, None, None, None, getitem_2222, getitem_2214, None, None, None, getitem_2213, getitem_2228, getitem_2225, getitem_2219, getitem_2216, getitem_2205, None, None, None, getitem_2204, getitem_2196, None, None, None, getitem_2195, getitem_2210, getitem_2207, getitem_2201, getitem_2198, getitem_2187, None, None, None, getitem_2186, getitem_2178, None, None, None, getitem_2177, getitem_2192, getitem_2189, getitem_2183, getitem_2180, getitem_2169, None, None, None, getitem_2168, getitem_2160, None, None, None, getitem_2159, getitem_2174, getitem_2171, getitem_2165, getitem_2162, getitem_2151, None, None, None, getitem_2150, getitem_2142, None, None, None, getitem_2141, getitem_2156, getitem_2153, getitem_2147, getitem_2144, getitem_2232, None, None, None, getitem_2231, getitem_2234, getitem_2238, None, None, None, getitem_2237, getitem_2240, getitem_1506, None, None, None, getitem_1505, getitem_1497, None, None, None, getitem_1496, getitem_1511, getitem_1508, getitem_1502, getitem_1499, getitem_1488, None, None, None, getitem_1487, getitem_1479, None, None, None, getitem_1478, getitem_1493, getitem_1490, getitem_1484, getitem_1481, getitem_1470, None, None, None, getitem_1469, getitem_1461, None, None, None, getitem_1460, getitem_1475, getitem_1472, getitem_1466, getitem_1463, getitem_1452, None, None, None, getitem_1451, getitem_1443, None, None, None, getitem_1442, getitem_1457, getitem_1454, getitem_1448, getitem_1445, getitem_1434, None, None, None, getitem_1433, getitem_1425, None, None, None, getitem_1424, getitem_1439, getitem_1436, getitem_1430, getitem_1427, getitem_1515, None, None, None, getitem_1514, getitem_1517, getitem_1521, None, None, None, getitem_1520, getitem_1523, None, None, None, None, getitem_3059, getitem_3060]
        
