
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/nasnetalarge/nasnetalarge_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, primals_1024, primals_1025, primals_1026, primals_1027, primals_1028, primals_1029, primals_1030, primals_1031, primals_1032, primals_1033, primals_1034, primals_1035, primals_1036, primals_1037, primals_1038, primals_1039, primals_1040, primals_1041, primals_1042, primals_1043, primals_1044, primals_1045, primals_1046, primals_1047, primals_1048, primals_1049, primals_1050, primals_1051, primals_1052, primals_1053, primals_1054, primals_1055, primals_1056, primals_1057, primals_1058, primals_1059, primals_1060, primals_1061, primals_1062, primals_1063, primals_1064, primals_1065, primals_1066, primals_1067, primals_1068, primals_1069, primals_1070, primals_1071, primals_1072, primals_1073, primals_1074, primals_1075, primals_1076, primals_1077, primals_1078, primals_1079, primals_1080, primals_1081, primals_1082, primals_1083, primals_1084, primals_1085, primals_1086, primals_1087, primals_1088, primals_1089, primals_1090, primals_1091, primals_1092, primals_1093, primals_1094, primals_1095, primals_1096, primals_1097, primals_1098, primals_1099, primals_1100, primals_1101, primals_1102, primals_1103, primals_1104, primals_1105, primals_1106, primals_1107, primals_1108, primals_1109, primals_1110, primals_1111, primals_1112, primals_1113, primals_1114, primals_1115, primals_1116, primals_1117, primals_1118, primals_1119, primals_1120, primals_1121, primals_1122, primals_1123, primals_1124, primals_1125, primals_1126, primals_1127, primals_1128, primals_1129, primals_1130, primals_1131, primals_1132, primals_1133, primals_1134, primals_1135, primals_1136, primals_1137, primals_1138, primals_1139, primals_1140, primals_1141, primals_1142, primals_1143, primals_1144, primals_1145, primals_1146, primals_1147, primals_1148, primals_1149, primals_1150, primals_1151, primals_1152, primals_1153, primals_1154, primals_1155, primals_1156, primals_1157, primals_1158, primals_1159, primals_1160, primals_1161, primals_1162, primals_1163, primals_1164, primals_1165, primals_1166, primals_1167, primals_1168, primals_1169, primals_1170, primals_1171, primals_1172, primals_1173, primals_1174, primals_1175, primals_1176, primals_1177, primals_1178, primals_1179, primals_1180, primals_1181, primals_1182, primals_1183, primals_1184, primals_1185, primals_1186, primals_1187, primals_1188, primals_1189, primals_1190, primals_1191, primals_1192, primals_1193, primals_1194, primals_1195, primals_1196, primals_1197, primals_1198, primals_1199, primals_1200, primals_1201, primals_1202, primals_1203, primals_1204, primals_1205, primals_1206, primals_1207, primals_1208, primals_1209, primals_1210, primals_1211, primals_1212, primals_1213, primals_1214, primals_1215, primals_1216, primals_1217, primals_1218, primals_1219, primals_1220, primals_1221, primals_1222, primals_1223, primals_1224, primals_1225, primals_1226, primals_1227, primals_1228, primals_1229, primals_1230, primals_1231, primals_1232, primals_1233, primals_1234, primals_1235, primals_1236, primals_1237, primals_1238, primals_1239, primals_1240, primals_1241, primals_1242, primals_1243, primals_1244, primals_1245, primals_1246, primals_1247, primals_1248, primals_1249, primals_1250, primals_1251, primals_1252, primals_1253, primals_1254, primals_1255, primals_1256, primals_1257, primals_1258, primals_1259, primals_1260, primals_1261, primals_1262, primals_1263, primals_1264, primals_1265, primals_1266, primals_1267, primals_1268, primals_1269, primals_1270, primals_1271, primals_1272, primals_1273, primals_1274, primals_1275, primals_1276, primals_1277, primals_1278, primals_1279, primals_1280, primals_1281, primals_1282, primals_1283, primals_1284, primals_1285, primals_1286, primals_1287, primals_1288, primals_1289, primals_1290, primals_1291, primals_1292, primals_1293, primals_1294, primals_1295, primals_1296, primals_1297, primals_1298, primals_1299, primals_1300, primals_1301, primals_1302, primals_1303, primals_1304, primals_1305, primals_1306, primals_1307, primals_1308, primals_1309, primals_1310, primals_1311, primals_1312, primals_1313, primals_1314, primals_1315, primals_1316, primals_1317, primals_1318, primals_1319, primals_1320, primals_1321, primals_1322, primals_1323, primals_1324, primals_1325, primals_1326, primals_1327, primals_1328, primals_1329, primals_1330, primals_1331, primals_1332, primals_1333, primals_1334, primals_1335, primals_1336, primals_1337, primals_1338, primals_1339, primals_1340, primals_1341, primals_1342, primals_1343, primals_1344, primals_1345, primals_1346, primals_1347, primals_1348, primals_1349, primals_1350, primals_1351, primals_1352, primals_1353, primals_1354, primals_1355, primals_1356, primals_1357, primals_1358, primals_1359, primals_1360, primals_1361, primals_1362, primals_1363, primals_1364, primals_1365, primals_1366, primals_1367, primals_1368, primals_1369, primals_1370, primals_1371, primals_1372, primals_1373, primals_1374, primals_1375, primals_1376, primals_1377, primals_1378, primals_1379, primals_1380, primals_1381, primals_1382, primals_1383, primals_1384, primals_1385, primals_1386, primals_1387, primals_1388, primals_1389, primals_1390, primals_1391, primals_1392, primals_1393, primals_1394, primals_1395, primals_1396, primals_1397, primals_1398, primals_1399, primals_1400, primals_1401, primals_1402, primals_1403, primals_1404, primals_1405, primals_1406, primals_1407, primals_1408, primals_1409, primals_1410, primals_1411, primals_1412, primals_1413, primals_1414, primals_1415, primals_1416, primals_1417, primals_1418, primals_1419, primals_1420, primals_1421, primals_1422, primals_1423, primals_1424, primals_1425, primals_1426, primals_1427, primals_1428, primals_1429, primals_1430, primals_1431, primals_1432, primals_1433, primals_1434, primals_1435, primals_1436, primals_1437, primals_1438, primals_1439, primals_1440, primals_1441, primals_1442, primals_1443, primals_1444, primals_1445, primals_1446, primals_1447, primals_1448, primals_1449, primals_1450, primals_1451, primals_1452, primals_1453, primals_1454, primals_1455, primals_1456, primals_1457, primals_1458, primals_1459, primals_1460, primals_1461, primals_1462, primals_1463, primals_1464, primals_1465, primals_1466, primals_1467, primals_1468, primals_1469, primals_1470, primals_1471, primals_1472, primals_1473, primals_1474, primals_1475, primals_1476, primals_1477, primals_1478, primals_1479, primals_1480, primals_1481, primals_1482, primals_1483, primals_1484, primals_1485, primals_1486, primals_1487, primals_1488, primals_1489, primals_1490, primals_1491, primals_1492, primals_1493, primals_1494, primals_1495, primals_1496, primals_1497, primals_1498, primals_1499, primals_1500, primals_1501, primals_1502, primals_1503, primals_1504, primals_1505, primals_1506, primals_1507, primals_1508, primals_1509, primals_1510, primals_1511, primals_1512, primals_1513, primals_1514, primals_1515, primals_1516, primals_1517, primals_1518, primals_1519, primals_1520, primals_1521, primals_1522, primals_1523, primals_1524, primals_1525, primals_1526, primals_1527, primals_1528, primals_1529, primals_1530, primals_1531, primals_1532, primals_1533, primals_1534, primals_1535, primals_1536, primals_1537, primals_1538, primals_1539, primals_1540, primals_1541, primals_1542, primals_1543, primals_1544, primals_1545, primals_1546, primals_1547, primals_1548, primals_1549, primals_1550, primals_1551, primals_1552, primals_1553, primals_1554, primals_1555, primals_1556, primals_1557, primals_1558, primals_1559, primals_1560, primals_1561, primals_1562, primals_1563, primals_1564, primals_1565, primals_1566, primals_1567, primals_1568, primals_1569, primals_1570, primals_1571, primals_1572, primals_1573, primals_1574, primals_1575, primals_1576, primals_1577, primals_1578, primals_1579, primals_1580, primals_1581, primals_1582, primals_1583, primals_1584, primals_1585, primals_1586, primals_1587, primals_1588, primals_1589, primals_1590, primals_1591, primals_1592, primals_1593, primals_1594, primals_1595, primals_1596, primals_1597, primals_1598, primals_1599, primals_1600, primals_1601, primals_1602, primals_1603, primals_1604, primals_1605, primals_1606, primals_1607, primals_1608, primals_1609, primals_1610, primals_1611, primals_1612, primals_1613, primals_1614, primals_1615, primals_1616, primals_1617, primals_1618, primals_1619, primals_1620, primals_1621, primals_1622, primals_1623, primals_1624, primals_1625, primals_1626, primals_1627, primals_1628, primals_1629, primals_1630, primals_1631, primals_1632, primals_1633, primals_1634, primals_1635, primals_1636, primals_1637, primals_1638, primals_1639, primals_1640, primals_1641, primals_1642, primals_1643, primals_1644, primals_1645, primals_1646, primals_1647, primals_1648, primals_1649, primals_1650, primals_1651, primals_1652, primals_1653, primals_1654, primals_1655, primals_1656, primals_1657, primals_1658, primals_1659, primals_1660, primals_1661, primals_1662, primals_1663, primals_1664, primals_1665, primals_1666, primals_1667, primals_1668, primals_1669, primals_1670, primals_1671, primals_1672, primals_1673, primals_1674, primals_1675, primals_1676, primals_1677, primals_1678, primals_1679, primals_1680, primals_1681, primals_1682, primals_1683, primals_1684, primals_1685, primals_1686, primals_1687, primals_1688, primals_1689, primals_1690, primals_1691, primals_1692, primals_1693, primals_1694, primals_1695, primals_1696, primals_1697, primals_1698, primals_1699, primals_1700, primals_1701, primals_1702, primals_1703, primals_1704, primals_1705, primals_1706, primals_1707, primals_1708, primals_1709, primals_1710, primals_1711, primals_1712, primals_1713, primals_1714, primals_1715, primals_1716, primals_1717, primals_1718, primals_1719, primals_1720, primals_1721, primals_1722, primals_1723, primals_1724, primals_1725, primals_1726, primals_1727, primals_1728, primals_1729, primals_1730, primals_1731, primals_1732, primals_1733, primals_1734, primals_1735, primals_1736, primals_1737, primals_1738, primals_1739, primals_1740, primals_1741, primals_1742, primals_1743, primals_1744, primals_1745, primals_1746, primals_1747, primals_1748, primals_1749, primals_1750, primals_1751, primals_1752, primals_1753, primals_1754, primals_1755, primals_1756, primals_1757, primals_1758, primals_1759, primals_1760, primals_1761, primals_1762, primals_1763, primals_1764, primals_1765, primals_1766, primals_1767, primals_1768, primals_1769, primals_1770, primals_1771, primals_1772, primals_1773, primals_1774, primals_1775, primals_1776, primals_1777, primals_1778, primals_1779, primals_1780, primals_1781, primals_1782, primals_1783, primals_1784, primals_1785, primals_1786, primals_1787, primals_1788, primals_1789, primals_1790, primals_1791, primals_1792, primals_1793, primals_1794, primals_1795, primals_1796, primals_1797, primals_1798, primals_1799, primals_1800, primals_1801, primals_1802, primals_1803, primals_1804, primals_1805, primals_1806, primals_1807, primals_1808, primals_1809, primals_1810, primals_1811):
        convolution_default = torch.ops.aten.convolution.default(primals_1806, primals_1639, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_1807, 1);  primals_1807 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_1810, primals_1811, primals_1808, primals_1809, True, 0.1, 0.001);  primals_1811 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu_default = torch.ops.aten.relu.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(relu_default, primals_1555, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_1554, primals_1550, primals_1552, primals_1553, True, 0.1, 0.001);  primals_1550 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu_default_1 = torch.ops.aten.relu.default(getitem_3)
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(relu_default_1, [2, 2, 2, 2], 0.0)
        convolution_default_2 = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_1490, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 42)
        convolution_default_3 = torch.ops.aten.convolution.default(convolution_default_2, primals_1491, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_1484, primals_1480, primals_1482, primals_1483, True, 0.1, 0.001);  primals_1480 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default, primals_1492, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 42)
        convolution_default_5 = torch.ops.aten.convolution.default(convolution_default_4, primals_1493, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_1489, primals_1485, primals_1487, primals_1488, True, 0.1, 0.001);  primals_1485 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu_default_2 = torch.ops.aten.relu.default(getitem)
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(relu_default_2, [3, 3, 3, 3], 0.0)
        convolution_default_6 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, primals_1504, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        convolution_default_7 = torch.ops.aten.convolution.default(convolution_default_6, primals_1505, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_1498, primals_1494, primals_1496, primals_1497, True, 0.1, 0.001);  primals_1494 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_1, primals_1506, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 42)
        convolution_default_9 = torch.ops.aten.convolution.default(convolution_default_8, primals_1507, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_1503, primals_1499, primals_1501, primals_1502, True, 0.1, 0.001);  primals_1499 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_9, getitem_15);  getitem_9 = getitem_15 = None
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(getitem_3, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_2, [3, 3], [2, 2])
        getitem_18 = max_pool2d_with_indices_default[0]
        getitem_19 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        relu_default_3 = torch.ops.aten.relu.default(getitem)
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(relu_default_3, [3, 3, 3, 3], 0.0)
        convolution_default_10 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, primals_1518, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        convolution_default_11 = torch.ops.aten.convolution.default(convolution_default_10, primals_1519, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_1512, primals_1508, primals_1510, primals_1511, True, 0.1, 0.001);  primals_1508 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_2, primals_1520, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 42)
        convolution_default_13 = torch.ops.aten.convolution.default(convolution_default_12, primals_1521, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_1517, primals_1513, primals_1515, primals_1516, True, 0.1, 0.001);  primals_1513 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_18, getitem_23);  getitem_18 = getitem_23 = None
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(getitem_3, [1, 1, 1, 1], 0.0)
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_4, [3, 3], [2, 2], [0, 0], False, False)
        relu_default_4 = torch.ops.aten.relu.default(getitem)
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(relu_default_4, [2, 2, 2, 2], 0.0)
        convolution_default_14 = torch.ops.aten.convolution.default(constant_pad_nd_default_5, primals_1532, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        convolution_default_15 = torch.ops.aten.convolution.default(convolution_default_14, primals_1533, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_1526, primals_1522, primals_1524, primals_1525, True, 0.1, 0.001);  primals_1522 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_3, primals_1534, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 42)
        convolution_default_17 = torch.ops.aten.convolution.default(convolution_default_16, primals_1535, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_1531, primals_1527, primals_1529, primals_1530, True, 0.1, 0.001);  primals_1527 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(avg_pool2d_default, getitem_29);  avg_pool2d_default = getitem_29 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(add_tensor_1, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_4 = torch.ops.aten.add.Tensor(avg_pool2d_default_1, add_tensor_2);  avg_pool2d_default_1 = None
        relu_default_5 = torch.ops.aten.relu.default(add_tensor_1)
        convolution_default_18 = torch.ops.aten.convolution.default(relu_default_5, primals_1546, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 42)
        convolution_default_19 = torch.ops.aten.convolution.default(convolution_default_18, primals_1547, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_1540, primals_1536, primals_1538, primals_1539, True, 0.1, 0.001);  primals_1536 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_4, primals_1548, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 42)
        convolution_default_21 = torch.ops.aten.convolution.default(convolution_default_20, primals_1549, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_1545, primals_1541, primals_1543, primals_1544, True, 0.1, 0.001);  primals_1541 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_3, [1, 1, 1, 1], -inf);  getitem_3 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_6, [3, 3], [2, 2])
        getitem_38 = max_pool2d_with_indices_default_1[0]
        getitem_39 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_35, getitem_38);  getitem_35 = getitem_38 = None
        cat_default = torch.ops.aten.cat.default([add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5], 1);  add_tensor_2 = add_tensor_3 = add_tensor_4 = add_tensor_5 = None
        relu_default_6 = torch.ops.aten.relu.default(cat_default)
        convolution_default_22 = torch.ops.aten.convolution.default(relu_default_6, primals_1631, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_1630, primals_1626, primals_1628, primals_1629, True, 0.1, 0.001);  primals_1626 = None
        getitem_40 = native_batch_norm_default_12[0]
        getitem_41 = native_batch_norm_default_12[1]
        getitem_42 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu_default_7 = torch.ops.aten.relu.default(getitem);  getitem = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(relu_default_7, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_23 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_1637, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(relu_default_7, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_7, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_24 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_1638, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_1 = torch.ops.aten.cat.default([convolution_default_23, convolution_default_24], 1);  convolution_default_23 = convolution_default_24 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_1636, primals_1632, primals_1634, primals_1635, True, 0.1, 0.001);  primals_1632 = None
        getitem_43 = native_batch_norm_default_13[0]
        getitem_44 = native_batch_norm_default_13[1]
        getitem_45 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu_default_8 = torch.ops.aten.relu.default(getitem_40)
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(relu_default_8, [2, 2, 2, 2], 0.0)
        convolution_default_25 = torch.ops.aten.convolution.default(constant_pad_nd_default_8, primals_1566, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 84)
        convolution_default_26 = torch.ops.aten.convolution.default(convolution_default_25, primals_1567, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_1560, primals_1556, primals_1558, primals_1559, True, 0.1, 0.001);  primals_1556 = None
        getitem_46 = native_batch_norm_default_14[0]
        getitem_47 = native_batch_norm_default_14[1]
        getitem_48 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_46);  getitem_46 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_5, primals_1568, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 84)
        convolution_default_28 = torch.ops.aten.convolution.default(convolution_default_27, primals_1569, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_1565, primals_1561, primals_1563, primals_1564, True, 0.1, 0.001);  primals_1561 = None
        getitem_49 = native_batch_norm_default_15[0]
        getitem_50 = native_batch_norm_default_15[1]
        getitem_51 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu_default_9 = torch.ops.aten.relu.default(getitem_43)
        constant_pad_nd_default_9 = torch.ops.aten.constant_pad_nd.default(relu_default_9, [3, 3, 3, 3], 0.0)
        convolution_default_29 = torch.ops.aten.convolution.default(constant_pad_nd_default_9, primals_1580, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 84)
        convolution_default_30 = torch.ops.aten.convolution.default(convolution_default_29, primals_1581, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_1574, primals_1570, primals_1572, primals_1573, True, 0.1, 0.001);  primals_1570 = None
        getitem_52 = native_batch_norm_default_16[0]
        getitem_53 = native_batch_norm_default_16[1]
        getitem_54 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_6, primals_1582, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 84)
        convolution_default_32 = torch.ops.aten.convolution.default(convolution_default_31, primals_1583, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_1579, primals_1575, primals_1577, primals_1578, True, 0.1, 0.001);  primals_1575 = None
        getitem_55 = native_batch_norm_default_17[0]
        getitem_56 = native_batch_norm_default_17[1]
        getitem_57 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_49, getitem_55);  getitem_49 = getitem_55 = None
        constant_pad_nd_default_10 = torch.ops.aten.constant_pad_nd.default(getitem_40, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_10, [3, 3], [2, 2])
        getitem_58 = max_pool2d_with_indices_default_2[0]
        getitem_59 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        relu_default_10 = torch.ops.aten.relu.default(getitem_43)
        constant_pad_nd_default_11 = torch.ops.aten.constant_pad_nd.default(relu_default_10, [3, 3, 3, 3], 0.0)
        convolution_default_33 = torch.ops.aten.convolution.default(constant_pad_nd_default_11, primals_1594, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 84)
        convolution_default_34 = torch.ops.aten.convolution.default(convolution_default_33, primals_1595, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_1588, primals_1584, primals_1586, primals_1587, True, 0.1, 0.001);  primals_1584 = None
        getitem_60 = native_batch_norm_default_18[0]
        getitem_61 = native_batch_norm_default_18[1]
        getitem_62 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_7, primals_1596, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 84)
        convolution_default_36 = torch.ops.aten.convolution.default(convolution_default_35, primals_1597, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_1593, primals_1589, primals_1591, primals_1592, True, 0.1, 0.001);  primals_1589 = None
        getitem_63 = native_batch_norm_default_19[0]
        getitem_64 = native_batch_norm_default_19[1]
        getitem_65 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_58, getitem_63);  getitem_58 = getitem_63 = None
        constant_pad_nd_default_12 = torch.ops.aten.constant_pad_nd.default(getitem_40, [1, 1, 1, 1], 0.0)
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_12, [3, 3], [2, 2], [0, 0], False, False)
        relu_default_11 = torch.ops.aten.relu.default(getitem_43);  getitem_43 = None
        constant_pad_nd_default_13 = torch.ops.aten.constant_pad_nd.default(relu_default_11, [2, 2, 2, 2], 0.0)
        convolution_default_37 = torch.ops.aten.convolution.default(constant_pad_nd_default_13, primals_1608, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 84)
        convolution_default_38 = torch.ops.aten.convolution.default(convolution_default_37, primals_1609, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_1602, primals_1598, primals_1600, primals_1601, True, 0.1, 0.001);  primals_1598 = None
        getitem_66 = native_batch_norm_default_20[0]
        getitem_67 = native_batch_norm_default_20[1]
        getitem_68 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_8, primals_1610, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 84)
        convolution_default_40 = torch.ops.aten.convolution.default(convolution_default_39, primals_1611, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_1607, primals_1603, primals_1605, primals_1606, True, 0.1, 0.001);  primals_1603 = None
        getitem_69 = native_batch_norm_default_21[0]
        getitem_70 = native_batch_norm_default_21[1]
        getitem_71 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(avg_pool2d_default_4, getitem_69);  avg_pool2d_default_4 = getitem_69 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(add_tensor_6, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_9 = torch.ops.aten.add.Tensor(avg_pool2d_default_5, add_tensor_7);  avg_pool2d_default_5 = None
        relu_default_12 = torch.ops.aten.relu.default(add_tensor_6)
        convolution_default_41 = torch.ops.aten.convolution.default(relu_default_12, primals_1622, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 84)
        convolution_default_42 = torch.ops.aten.convolution.default(convolution_default_41, primals_1623, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_1616, primals_1612, primals_1614, primals_1615, True, 0.1, 0.001);  primals_1612 = None
        getitem_72 = native_batch_norm_default_22[0]
        getitem_73 = native_batch_norm_default_22[1]
        getitem_74 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_9, primals_1624, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 84)
        convolution_default_44 = torch.ops.aten.convolution.default(convolution_default_43, primals_1625, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_1621, primals_1617, primals_1619, primals_1620, True, 0.1, 0.001);  primals_1617 = None
        getitem_75 = native_batch_norm_default_23[0]
        getitem_76 = native_batch_norm_default_23[1]
        getitem_77 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        constant_pad_nd_default_14 = torch.ops.aten.constant_pad_nd.default(getitem_40, [1, 1, 1, 1], -inf);  getitem_40 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_14, [3, 3], [2, 2])
        getitem_78 = max_pool2d_with_indices_default_3[0]
        getitem_79 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_75, getitem_78);  getitem_75 = getitem_78 = None
        cat_default_2 = torch.ops.aten.cat.default([add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10], 1);  add_tensor_7 = add_tensor_8 = add_tensor_9 = add_tensor_10 = None
        relu_default_13 = torch.ops.aten.relu.default(cat_default);  cat_default = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(relu_default_13, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_45 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_82, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_15 = torch.ops.aten.constant_pad_nd.default(relu_default_13, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_15, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_46 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_83, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([convolution_default_45, convolution_default_46], 1);  convolution_default_45 = convolution_default_46 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_81, primals_77, primals_79, primals_80, True, 0.1, 0.001);  primals_77 = None
        getitem_80 = native_batch_norm_default_24[0]
        getitem_81 = native_batch_norm_default_24[1]
        getitem_82 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu_default_14 = torch.ops.aten.relu.default(cat_default_2)
        convolution_default_47 = torch.ops.aten.convolution.default(relu_default_14, primals_76, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_75, primals_71, primals_73, primals_74, True, 0.1, 0.001);  primals_71 = None
        getitem_83 = native_batch_norm_default_25[0]
        getitem_84 = native_batch_norm_default_25[1]
        getitem_85 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu_default_15 = torch.ops.aten.relu.default(getitem_83)
        convolution_default_48 = torch.ops.aten.convolution.default(relu_default_15, primals_11, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_49 = torch.ops.aten.convolution.default(convolution_default_48, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_5, primals_1, primals_3, primals_4, True, 0.1, 0.001);  primals_1 = None
        getitem_86 = native_batch_norm_default_26[0]
        getitem_87 = native_batch_norm_default_26[1]
        getitem_88 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_10, primals_13, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_51 = torch.ops.aten.convolution.default(convolution_default_50, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_10, primals_6, primals_8, primals_9, True, 0.1, 0.001);  primals_6 = None
        getitem_89 = native_batch_norm_default_27[0]
        getitem_90 = native_batch_norm_default_27[1]
        getitem_91 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu_default_16 = torch.ops.aten.relu.default(getitem_80)
        convolution_default_52 = torch.ops.aten.convolution.default(relu_default_16, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_53 = torch.ops.aten.convolution.default(convolution_default_52, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_19, primals_15, primals_17, primals_18, True, 0.1, 0.001);  primals_15 = None
        getitem_92 = native_batch_norm_default_28[0]
        getitem_93 = native_batch_norm_default_28[1]
        getitem_94 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_92);  getitem_92 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_11, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_55 = torch.ops.aten.convolution.default(convolution_default_54, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_24, primals_20, primals_22, primals_23, True, 0.1, 0.001);  primals_20 = None
        getitem_95 = native_batch_norm_default_29[0]
        getitem_96 = native_batch_norm_default_29[1]
        getitem_97 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_89, getitem_95);  getitem_89 = getitem_95 = None
        relu_default_17 = torch.ops.aten.relu.default(getitem_80)
        convolution_default_56 = torch.ops.aten.convolution.default(relu_default_17, primals_39, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_57 = torch.ops.aten.convolution.default(convolution_default_56, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_33, primals_29, primals_31, primals_32, True, 0.1, 0.001);  primals_29 = None
        getitem_98 = native_batch_norm_default_30[0]
        getitem_99 = native_batch_norm_default_30[1]
        getitem_100 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_12, primals_41, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_59 = torch.ops.aten.convolution.default(convolution_default_58, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_38, primals_34, primals_36, primals_37, True, 0.1, 0.001);  primals_34 = None
        getitem_101 = native_batch_norm_default_31[0]
        getitem_102 = native_batch_norm_default_31[1]
        getitem_103 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu_default_18 = torch.ops.aten.relu.default(getitem_80)
        convolution_default_60 = torch.ops.aten.convolution.default(relu_default_18, primals_53, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_61 = torch.ops.aten.convolution.default(convolution_default_60, primals_54, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_47, primals_43, primals_45, primals_46, True, 0.1, 0.001);  primals_43 = None
        getitem_104 = native_batch_norm_default_32[0]
        getitem_105 = native_batch_norm_default_32[1]
        getitem_106 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_13, primals_55, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_63 = torch.ops.aten.convolution.default(convolution_default_62, primals_56, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_52, primals_48, primals_50, primals_51, True, 0.1, 0.001);  primals_48 = None
        getitem_107 = native_batch_norm_default_33[0]
        getitem_108 = native_batch_norm_default_33[1]
        getitem_109 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_101, getitem_107);  getitem_101 = getitem_107 = None
        avg_pool2d_default_8 = torch.ops.aten.avg_pool2d.default(getitem_83, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_13 = torch.ops.aten.add.Tensor(avg_pool2d_default_8, getitem_80);  avg_pool2d_default_8 = None
        avg_pool2d_default_9 = torch.ops.aten.avg_pool2d.default(getitem_80, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_10 = torch.ops.aten.avg_pool2d.default(getitem_80, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_14 = torch.ops.aten.add.Tensor(avg_pool2d_default_9, avg_pool2d_default_10);  avg_pool2d_default_9 = avg_pool2d_default_10 = None
        relu_default_19 = torch.ops.aten.relu.default(getitem_83)
        convolution_default_64 = torch.ops.aten.convolution.default(relu_default_19, primals_67, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_65 = torch.ops.aten.convolution.default(convolution_default_64, primals_68, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_61, primals_57, primals_59, primals_60, True, 0.1, 0.001);  primals_57 = None
        getitem_110 = native_batch_norm_default_34[0]
        getitem_111 = native_batch_norm_default_34[1]
        getitem_112 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_110);  getitem_110 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_14, primals_69, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_67 = torch.ops.aten.convolution.default(convolution_default_66, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_66, primals_62, primals_64, primals_65, True, 0.1, 0.001);  primals_62 = None
        getitem_113 = native_batch_norm_default_35[0]
        getitem_114 = native_batch_norm_default_35[1]
        getitem_115 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_113, getitem_83);  getitem_113 = None
        cat_default_4 = torch.ops.aten.cat.default([getitem_80, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15], 1);  add_tensor_11 = add_tensor_12 = add_tensor_13 = add_tensor_14 = add_tensor_15 = None
        relu_default_20 = torch.ops.aten.relu.default(cat_default_2);  cat_default_2 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu_default_20, primals_822, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_821, primals_817, primals_819, primals_820, True, 0.1, 0.001);  primals_817 = None
        getitem_116 = native_batch_norm_default_36[0]
        getitem_117 = native_batch_norm_default_36[1]
        getitem_118 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu_default_21 = torch.ops.aten.relu.default(cat_default_4)
        convolution_default_69 = torch.ops.aten.convolution.default(relu_default_21, primals_816, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_815, primals_811, primals_813, primals_814, True, 0.1, 0.001);  primals_811 = None
        getitem_119 = native_batch_norm_default_37[0]
        getitem_120 = native_batch_norm_default_37[1]
        getitem_121 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu_default_22 = torch.ops.aten.relu.default(getitem_119)
        convolution_default_70 = torch.ops.aten.convolution.default(relu_default_22, primals_751, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_71 = torch.ops.aten.convolution.default(convolution_default_70, primals_752, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_745, primals_741, primals_743, primals_744, True, 0.1, 0.001);  primals_741 = None
        getitem_122 = native_batch_norm_default_38[0]
        getitem_123 = native_batch_norm_default_38[1]
        getitem_124 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_15, primals_753, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_73 = torch.ops.aten.convolution.default(convolution_default_72, primals_754, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_750, primals_746, primals_748, primals_749, True, 0.1, 0.001);  primals_746 = None
        getitem_125 = native_batch_norm_default_39[0]
        getitem_126 = native_batch_norm_default_39[1]
        getitem_127 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu_default_23 = torch.ops.aten.relu.default(getitem_116)
        convolution_default_74 = torch.ops.aten.convolution.default(relu_default_23, primals_765, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_75 = torch.ops.aten.convolution.default(convolution_default_74, primals_766, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_759, primals_755, primals_757, primals_758, True, 0.1, 0.001);  primals_755 = None
        getitem_128 = native_batch_norm_default_40[0]
        getitem_129 = native_batch_norm_default_40[1]
        getitem_130 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_128);  getitem_128 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_16, primals_767, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_77 = torch.ops.aten.convolution.default(convolution_default_76, primals_768, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_764, primals_760, primals_762, primals_763, True, 0.1, 0.001);  primals_760 = None
        getitem_131 = native_batch_norm_default_41[0]
        getitem_132 = native_batch_norm_default_41[1]
        getitem_133 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_125, getitem_131);  getitem_125 = getitem_131 = None
        relu_default_24 = torch.ops.aten.relu.default(getitem_116)
        convolution_default_78 = torch.ops.aten.convolution.default(relu_default_24, primals_779, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_79 = torch.ops.aten.convolution.default(convolution_default_78, primals_780, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_773, primals_769, primals_771, primals_772, True, 0.1, 0.001);  primals_769 = None
        getitem_134 = native_batch_norm_default_42[0]
        getitem_135 = native_batch_norm_default_42[1]
        getitem_136 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_17, primals_781, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_81 = torch.ops.aten.convolution.default(convolution_default_80, primals_782, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_778, primals_774, primals_776, primals_777, True, 0.1, 0.001);  primals_774 = None
        getitem_137 = native_batch_norm_default_43[0]
        getitem_138 = native_batch_norm_default_43[1]
        getitem_139 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu_default_25 = torch.ops.aten.relu.default(getitem_116)
        convolution_default_82 = torch.ops.aten.convolution.default(relu_default_25, primals_793, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_83 = torch.ops.aten.convolution.default(convolution_default_82, primals_794, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_787, primals_783, primals_785, primals_786, True, 0.1, 0.001);  primals_783 = None
        getitem_140 = native_batch_norm_default_44[0]
        getitem_141 = native_batch_norm_default_44[1]
        getitem_142 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_18, primals_795, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_85 = torch.ops.aten.convolution.default(convolution_default_84, primals_796, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_792, primals_788, primals_790, primals_791, True, 0.1, 0.001);  primals_788 = None
        getitem_143 = native_batch_norm_default_45[0]
        getitem_144 = native_batch_norm_default_45[1]
        getitem_145 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_137, getitem_143);  getitem_137 = getitem_143 = None
        avg_pool2d_default_11 = torch.ops.aten.avg_pool2d.default(getitem_119, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_18 = torch.ops.aten.add.Tensor(avg_pool2d_default_11, getitem_116);  avg_pool2d_default_11 = None
        avg_pool2d_default_12 = torch.ops.aten.avg_pool2d.default(getitem_116, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_13 = torch.ops.aten.avg_pool2d.default(getitem_116, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_19 = torch.ops.aten.add.Tensor(avg_pool2d_default_12, avg_pool2d_default_13);  avg_pool2d_default_12 = avg_pool2d_default_13 = None
        relu_default_26 = torch.ops.aten.relu.default(getitem_119)
        convolution_default_86 = torch.ops.aten.convolution.default(relu_default_26, primals_807, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_87 = torch.ops.aten.convolution.default(convolution_default_86, primals_808, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_801, primals_797, primals_799, primals_800, True, 0.1, 0.001);  primals_797 = None
        getitem_146 = native_batch_norm_default_46[0]
        getitem_147 = native_batch_norm_default_46[1]
        getitem_148 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_19, primals_809, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_89 = torch.ops.aten.convolution.default(convolution_default_88, primals_810, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_806, primals_802, primals_804, primals_805, True, 0.1, 0.001);  primals_802 = None
        getitem_149 = native_batch_norm_default_47[0]
        getitem_150 = native_batch_norm_default_47[1]
        getitem_151 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(getitem_149, getitem_119);  getitem_149 = None
        cat_default_5 = torch.ops.aten.cat.default([getitem_116, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20], 1);  add_tensor_16 = add_tensor_17 = add_tensor_18 = add_tensor_19 = add_tensor_20 = None
        relu_default_27 = torch.ops.aten.relu.default(cat_default_4);  cat_default_4 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu_default_27, primals_904, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_903, primals_899, primals_901, primals_902, True, 0.1, 0.001);  primals_899 = None
        getitem_152 = native_batch_norm_default_48[0]
        getitem_153 = native_batch_norm_default_48[1]
        getitem_154 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu_default_28 = torch.ops.aten.relu.default(cat_default_5)
        convolution_default_91 = torch.ops.aten.convolution.default(relu_default_28, primals_898, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_897, primals_893, primals_895, primals_896, True, 0.1, 0.001);  primals_893 = None
        getitem_155 = native_batch_norm_default_49[0]
        getitem_156 = native_batch_norm_default_49[1]
        getitem_157 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu_default_29 = torch.ops.aten.relu.default(getitem_155)
        convolution_default_92 = torch.ops.aten.convolution.default(relu_default_29, primals_833, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_93 = torch.ops.aten.convolution.default(convolution_default_92, primals_834, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_827, primals_823, primals_825, primals_826, True, 0.1, 0.001);  primals_823 = None
        getitem_158 = native_batch_norm_default_50[0]
        getitem_159 = native_batch_norm_default_50[1]
        getitem_160 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_20, primals_835, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_95 = torch.ops.aten.convolution.default(convolution_default_94, primals_836, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_832, primals_828, primals_830, primals_831, True, 0.1, 0.001);  primals_828 = None
        getitem_161 = native_batch_norm_default_51[0]
        getitem_162 = native_batch_norm_default_51[1]
        getitem_163 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu_default_30 = torch.ops.aten.relu.default(getitem_152)
        convolution_default_96 = torch.ops.aten.convolution.default(relu_default_30, primals_847, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_97 = torch.ops.aten.convolution.default(convolution_default_96, primals_848, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_841, primals_837, primals_839, primals_840, True, 0.1, 0.001);  primals_837 = None
        getitem_164 = native_batch_norm_default_52[0]
        getitem_165 = native_batch_norm_default_52[1]
        getitem_166 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_21, primals_849, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_99 = torch.ops.aten.convolution.default(convolution_default_98, primals_850, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_846, primals_842, primals_844, primals_845, True, 0.1, 0.001);  primals_842 = None
        getitem_167 = native_batch_norm_default_53[0]
        getitem_168 = native_batch_norm_default_53[1]
        getitem_169 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(getitem_161, getitem_167);  getitem_161 = getitem_167 = None
        relu_default_31 = torch.ops.aten.relu.default(getitem_152)
        convolution_default_100 = torch.ops.aten.convolution.default(relu_default_31, primals_861, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_101 = torch.ops.aten.convolution.default(convolution_default_100, primals_862, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_855, primals_851, primals_853, primals_854, True, 0.1, 0.001);  primals_851 = None
        getitem_170 = native_batch_norm_default_54[0]
        getitem_171 = native_batch_norm_default_54[1]
        getitem_172 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_22, primals_863, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_103 = torch.ops.aten.convolution.default(convolution_default_102, primals_864, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_860, primals_856, primals_858, primals_859, True, 0.1, 0.001);  primals_856 = None
        getitem_173 = native_batch_norm_default_55[0]
        getitem_174 = native_batch_norm_default_55[1]
        getitem_175 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu_default_32 = torch.ops.aten.relu.default(getitem_152)
        convolution_default_104 = torch.ops.aten.convolution.default(relu_default_32, primals_875, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_105 = torch.ops.aten.convolution.default(convolution_default_104, primals_876, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_869, primals_865, primals_867, primals_868, True, 0.1, 0.001);  primals_865 = None
        getitem_176 = native_batch_norm_default_56[0]
        getitem_177 = native_batch_norm_default_56[1]
        getitem_178 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_23, primals_877, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_107 = torch.ops.aten.convolution.default(convolution_default_106, primals_878, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_874, primals_870, primals_872, primals_873, True, 0.1, 0.001);  primals_870 = None
        getitem_179 = native_batch_norm_default_57[0]
        getitem_180 = native_batch_norm_default_57[1]
        getitem_181 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_173, getitem_179);  getitem_173 = getitem_179 = None
        avg_pool2d_default_14 = torch.ops.aten.avg_pool2d.default(getitem_155, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_23 = torch.ops.aten.add.Tensor(avg_pool2d_default_14, getitem_152);  avg_pool2d_default_14 = None
        avg_pool2d_default_15 = torch.ops.aten.avg_pool2d.default(getitem_152, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_16 = torch.ops.aten.avg_pool2d.default(getitem_152, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_24 = torch.ops.aten.add.Tensor(avg_pool2d_default_15, avg_pool2d_default_16);  avg_pool2d_default_15 = avg_pool2d_default_16 = None
        relu_default_33 = torch.ops.aten.relu.default(getitem_155)
        convolution_default_108 = torch.ops.aten.convolution.default(relu_default_33, primals_889, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_109 = torch.ops.aten.convolution.default(convolution_default_108, primals_890, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_883, primals_879, primals_881, primals_882, True, 0.1, 0.001);  primals_879 = None
        getitem_182 = native_batch_norm_default_58[0]
        getitem_183 = native_batch_norm_default_58[1]
        getitem_184 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_24, primals_891, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_111 = torch.ops.aten.convolution.default(convolution_default_110, primals_892, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_888, primals_884, primals_886, primals_887, True, 0.1, 0.001);  primals_884 = None
        getitem_185 = native_batch_norm_default_59[0]
        getitem_186 = native_batch_norm_default_59[1]
        getitem_187 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(getitem_185, getitem_155);  getitem_185 = None
        cat_default_6 = torch.ops.aten.cat.default([getitem_152, add_tensor_21, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_25], 1);  add_tensor_21 = add_tensor_22 = add_tensor_23 = add_tensor_24 = add_tensor_25 = None
        relu_default_34 = torch.ops.aten.relu.default(cat_default_5);  cat_default_5 = None
        convolution_default_112 = torch.ops.aten.convolution.default(relu_default_34, primals_986, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_985, primals_981, primals_983, primals_984, True, 0.1, 0.001);  primals_981 = None
        getitem_188 = native_batch_norm_default_60[0]
        getitem_189 = native_batch_norm_default_60[1]
        getitem_190 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu_default_35 = torch.ops.aten.relu.default(cat_default_6)
        convolution_default_113 = torch.ops.aten.convolution.default(relu_default_35, primals_980, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_979, primals_975, primals_977, primals_978, True, 0.1, 0.001);  primals_975 = None
        getitem_191 = native_batch_norm_default_61[0]
        getitem_192 = native_batch_norm_default_61[1]
        getitem_193 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu_default_36 = torch.ops.aten.relu.default(getitem_191)
        convolution_default_114 = torch.ops.aten.convolution.default(relu_default_36, primals_915, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_115 = torch.ops.aten.convolution.default(convolution_default_114, primals_916, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_909, primals_905, primals_907, primals_908, True, 0.1, 0.001);  primals_905 = None
        getitem_194 = native_batch_norm_default_62[0]
        getitem_195 = native_batch_norm_default_62[1]
        getitem_196 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_25, primals_917, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_117 = torch.ops.aten.convolution.default(convolution_default_116, primals_918, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_914, primals_910, primals_912, primals_913, True, 0.1, 0.001);  primals_910 = None
        getitem_197 = native_batch_norm_default_63[0]
        getitem_198 = native_batch_norm_default_63[1]
        getitem_199 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu_default_37 = torch.ops.aten.relu.default(getitem_188)
        convolution_default_118 = torch.ops.aten.convolution.default(relu_default_37, primals_929, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_119 = torch.ops.aten.convolution.default(convolution_default_118, primals_930, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_923, primals_919, primals_921, primals_922, True, 0.1, 0.001);  primals_919 = None
        getitem_200 = native_batch_norm_default_64[0]
        getitem_201 = native_batch_norm_default_64[1]
        getitem_202 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        convolution_default_120 = torch.ops.aten.convolution.default(relu__default_26, primals_931, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_121 = torch.ops.aten.convolution.default(convolution_default_120, primals_932, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_928, primals_924, primals_926, primals_927, True, 0.1, 0.001);  primals_924 = None
        getitem_203 = native_batch_norm_default_65[0]
        getitem_204 = native_batch_norm_default_65[1]
        getitem_205 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_197, getitem_203);  getitem_197 = getitem_203 = None
        relu_default_38 = torch.ops.aten.relu.default(getitem_188)
        convolution_default_122 = torch.ops.aten.convolution.default(relu_default_38, primals_943, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_123 = torch.ops.aten.convolution.default(convolution_default_122, primals_944, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_937, primals_933, primals_935, primals_936, True, 0.1, 0.001);  primals_933 = None
        getitem_206 = native_batch_norm_default_66[0]
        getitem_207 = native_batch_norm_default_66[1]
        getitem_208 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_27, primals_945, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_125 = torch.ops.aten.convolution.default(convolution_default_124, primals_946, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_942, primals_938, primals_940, primals_941, True, 0.1, 0.001);  primals_938 = None
        getitem_209 = native_batch_norm_default_67[0]
        getitem_210 = native_batch_norm_default_67[1]
        getitem_211 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu_default_39 = torch.ops.aten.relu.default(getitem_188)
        convolution_default_126 = torch.ops.aten.convolution.default(relu_default_39, primals_957, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_127 = torch.ops.aten.convolution.default(convolution_default_126, primals_958, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_951, primals_947, primals_949, primals_950, True, 0.1, 0.001);  primals_947 = None
        getitem_212 = native_batch_norm_default_68[0]
        getitem_213 = native_batch_norm_default_68[1]
        getitem_214 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_28, primals_959, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_129 = torch.ops.aten.convolution.default(convolution_default_128, primals_960, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_956, primals_952, primals_954, primals_955, True, 0.1, 0.001);  primals_952 = None
        getitem_215 = native_batch_norm_default_69[0]
        getitem_216 = native_batch_norm_default_69[1]
        getitem_217 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_209, getitem_215);  getitem_209 = getitem_215 = None
        avg_pool2d_default_17 = torch.ops.aten.avg_pool2d.default(getitem_191, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_28 = torch.ops.aten.add.Tensor(avg_pool2d_default_17, getitem_188);  avg_pool2d_default_17 = None
        avg_pool2d_default_18 = torch.ops.aten.avg_pool2d.default(getitem_188, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_19 = torch.ops.aten.avg_pool2d.default(getitem_188, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_29 = torch.ops.aten.add.Tensor(avg_pool2d_default_18, avg_pool2d_default_19);  avg_pool2d_default_18 = avg_pool2d_default_19 = None
        relu_default_40 = torch.ops.aten.relu.default(getitem_191)
        convolution_default_130 = torch.ops.aten.convolution.default(relu_default_40, primals_971, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_131 = torch.ops.aten.convolution.default(convolution_default_130, primals_972, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_965, primals_961, primals_963, primals_964, True, 0.1, 0.001);  primals_961 = None
        getitem_218 = native_batch_norm_default_70[0]
        getitem_219 = native_batch_norm_default_70[1]
        getitem_220 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu__default_29, primals_973, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_133 = torch.ops.aten.convolution.default(convolution_default_132, primals_974, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_970, primals_966, primals_968, primals_969, True, 0.1, 0.001);  primals_966 = None
        getitem_221 = native_batch_norm_default_71[0]
        getitem_222 = native_batch_norm_default_71[1]
        getitem_223 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(getitem_221, getitem_191);  getitem_221 = None
        cat_default_7 = torch.ops.aten.cat.default([getitem_188, add_tensor_26, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_30], 1);  add_tensor_26 = add_tensor_27 = add_tensor_28 = add_tensor_29 = add_tensor_30 = None
        relu_default_41 = torch.ops.aten.relu.default(cat_default_6);  cat_default_6 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu_default_41, primals_1068, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_1067, primals_1063, primals_1065, primals_1066, True, 0.1, 0.001);  primals_1063 = None
        getitem_224 = native_batch_norm_default_72[0]
        getitem_225 = native_batch_norm_default_72[1]
        getitem_226 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu_default_42 = torch.ops.aten.relu.default(cat_default_7)
        convolution_default_135 = torch.ops.aten.convolution.default(relu_default_42, primals_1062, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_1061, primals_1057, primals_1059, primals_1060, True, 0.1, 0.001);  primals_1057 = None
        getitem_227 = native_batch_norm_default_73[0]
        getitem_228 = native_batch_norm_default_73[1]
        getitem_229 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu_default_43 = torch.ops.aten.relu.default(getitem_227)
        convolution_default_136 = torch.ops.aten.convolution.default(relu_default_43, primals_997, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_137 = torch.ops.aten.convolution.default(convolution_default_136, primals_998, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_991, primals_987, primals_989, primals_990, True, 0.1, 0.001);  primals_987 = None
        getitem_230 = native_batch_norm_default_74[0]
        getitem_231 = native_batch_norm_default_74[1]
        getitem_232 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_138 = torch.ops.aten.convolution.default(relu__default_30, primals_999, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_139 = torch.ops.aten.convolution.default(convolution_default_138, primals_1000, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_996, primals_992, primals_994, primals_995, True, 0.1, 0.001);  primals_992 = None
        getitem_233 = native_batch_norm_default_75[0]
        getitem_234 = native_batch_norm_default_75[1]
        getitem_235 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu_default_44 = torch.ops.aten.relu.default(getitem_224)
        convolution_default_140 = torch.ops.aten.convolution.default(relu_default_44, primals_1011, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_141 = torch.ops.aten.convolution.default(convolution_default_140, primals_1012, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_1005, primals_1001, primals_1003, primals_1004, True, 0.1, 0.001);  primals_1001 = None
        getitem_236 = native_batch_norm_default_76[0]
        getitem_237 = native_batch_norm_default_76[1]
        getitem_238 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu__default_31, primals_1013, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_143 = torch.ops.aten.convolution.default(convolution_default_142, primals_1014, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_1010, primals_1006, primals_1008, primals_1009, True, 0.1, 0.001);  primals_1006 = None
        getitem_239 = native_batch_norm_default_77[0]
        getitem_240 = native_batch_norm_default_77[1]
        getitem_241 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(getitem_233, getitem_239);  getitem_233 = getitem_239 = None
        relu_default_45 = torch.ops.aten.relu.default(getitem_224)
        convolution_default_144 = torch.ops.aten.convolution.default(relu_default_45, primals_1025, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_145 = torch.ops.aten.convolution.default(convolution_default_144, primals_1026, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_1019, primals_1015, primals_1017, primals_1018, True, 0.1, 0.001);  primals_1015 = None
        getitem_242 = native_batch_norm_default_78[0]
        getitem_243 = native_batch_norm_default_78[1]
        getitem_244 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_32, primals_1027, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_147 = torch.ops.aten.convolution.default(convolution_default_146, primals_1028, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_1024, primals_1020, primals_1022, primals_1023, True, 0.1, 0.001);  primals_1020 = None
        getitem_245 = native_batch_norm_default_79[0]
        getitem_246 = native_batch_norm_default_79[1]
        getitem_247 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu_default_46 = torch.ops.aten.relu.default(getitem_224)
        convolution_default_148 = torch.ops.aten.convolution.default(relu_default_46, primals_1039, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_149 = torch.ops.aten.convolution.default(convolution_default_148, primals_1040, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_149, primals_1033, primals_1029, primals_1031, primals_1032, True, 0.1, 0.001);  primals_1029 = None
        getitem_248 = native_batch_norm_default_80[0]
        getitem_249 = native_batch_norm_default_80[1]
        getitem_250 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_150 = torch.ops.aten.convolution.default(relu__default_33, primals_1041, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_151 = torch.ops.aten.convolution.default(convolution_default_150, primals_1042, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_1038, primals_1034, primals_1036, primals_1037, True, 0.1, 0.001);  primals_1034 = None
        getitem_251 = native_batch_norm_default_81[0]
        getitem_252 = native_batch_norm_default_81[1]
        getitem_253 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_245, getitem_251);  getitem_245 = getitem_251 = None
        avg_pool2d_default_20 = torch.ops.aten.avg_pool2d.default(getitem_227, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_33 = torch.ops.aten.add.Tensor(avg_pool2d_default_20, getitem_224);  avg_pool2d_default_20 = None
        avg_pool2d_default_21 = torch.ops.aten.avg_pool2d.default(getitem_224, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_22 = torch.ops.aten.avg_pool2d.default(getitem_224, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_34 = torch.ops.aten.add.Tensor(avg_pool2d_default_21, avg_pool2d_default_22);  avg_pool2d_default_21 = avg_pool2d_default_22 = None
        relu_default_47 = torch.ops.aten.relu.default(getitem_227)
        convolution_default_152 = torch.ops.aten.convolution.default(relu_default_47, primals_1053, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_153 = torch.ops.aten.convolution.default(convolution_default_152, primals_1054, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_1047, primals_1043, primals_1045, primals_1046, True, 0.1, 0.001);  primals_1043 = None
        getitem_254 = native_batch_norm_default_82[0]
        getitem_255 = native_batch_norm_default_82[1]
        getitem_256 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        convolution_default_154 = torch.ops.aten.convolution.default(relu__default_34, primals_1055, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_155 = torch.ops.aten.convolution.default(convolution_default_154, primals_1056, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_155, primals_1052, primals_1048, primals_1050, primals_1051, True, 0.1, 0.001);  primals_1048 = None
        getitem_257 = native_batch_norm_default_83[0]
        getitem_258 = native_batch_norm_default_83[1]
        getitem_259 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_257, getitem_227);  getitem_257 = None
        cat_default_8 = torch.ops.aten.cat.default([getitem_224, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_34, add_tensor_35], 1);  add_tensor_31 = add_tensor_32 = add_tensor_33 = add_tensor_34 = add_tensor_35 = None
        relu_default_48 = torch.ops.aten.relu.default(cat_default_7);  cat_default_7 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu_default_48, primals_1150, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_1149, primals_1145, primals_1147, primals_1148, True, 0.1, 0.001);  primals_1145 = None
        getitem_260 = native_batch_norm_default_84[0]
        getitem_261 = native_batch_norm_default_84[1]
        getitem_262 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu_default_49 = torch.ops.aten.relu.default(cat_default_8)
        convolution_default_157 = torch.ops.aten.convolution.default(relu_default_49, primals_1144, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_1143, primals_1139, primals_1141, primals_1142, True, 0.1, 0.001);  primals_1139 = None
        getitem_263 = native_batch_norm_default_85[0]
        getitem_264 = native_batch_norm_default_85[1]
        getitem_265 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu_default_50 = torch.ops.aten.relu.default(getitem_263)
        convolution_default_158 = torch.ops.aten.convolution.default(relu_default_50, primals_1079, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_159 = torch.ops.aten.convolution.default(convolution_default_158, primals_1080, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_159, primals_1073, primals_1069, primals_1071, primals_1072, True, 0.1, 0.001);  primals_1069 = None
        getitem_266 = native_batch_norm_default_86[0]
        getitem_267 = native_batch_norm_default_86[1]
        getitem_268 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu__default_35, primals_1081, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_161 = torch.ops.aten.convolution.default(convolution_default_160, primals_1082, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_1078, primals_1074, primals_1076, primals_1077, True, 0.1, 0.001);  primals_1074 = None
        getitem_269 = native_batch_norm_default_87[0]
        getitem_270 = native_batch_norm_default_87[1]
        getitem_271 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu_default_51 = torch.ops.aten.relu.default(getitem_260)
        convolution_default_162 = torch.ops.aten.convolution.default(relu_default_51, primals_1093, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_163 = torch.ops.aten.convolution.default(convolution_default_162, primals_1094, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_1087, primals_1083, primals_1085, primals_1086, True, 0.1, 0.001);  primals_1083 = None
        getitem_272 = native_batch_norm_default_88[0]
        getitem_273 = native_batch_norm_default_88[1]
        getitem_274 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        convolution_default_164 = torch.ops.aten.convolution.default(relu__default_36, primals_1095, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_165 = torch.ops.aten.convolution.default(convolution_default_164, primals_1096, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_165, primals_1092, primals_1088, primals_1090, primals_1091, True, 0.1, 0.001);  primals_1088 = None
        getitem_275 = native_batch_norm_default_89[0]
        getitem_276 = native_batch_norm_default_89[1]
        getitem_277 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(getitem_269, getitem_275);  getitem_269 = getitem_275 = None
        relu_default_52 = torch.ops.aten.relu.default(getitem_260)
        convolution_default_166 = torch.ops.aten.convolution.default(relu_default_52, primals_1107, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_167 = torch.ops.aten.convolution.default(convolution_default_166, primals_1108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_1101, primals_1097, primals_1099, primals_1100, True, 0.1, 0.001);  primals_1097 = None
        getitem_278 = native_batch_norm_default_90[0]
        getitem_279 = native_batch_norm_default_90[1]
        getitem_280 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_168 = torch.ops.aten.convolution.default(relu__default_37, primals_1109, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        convolution_default_169 = torch.ops.aten.convolution.default(convolution_default_168, primals_1110, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_169, primals_1106, primals_1102, primals_1104, primals_1105, True, 0.1, 0.001);  primals_1102 = None
        getitem_281 = native_batch_norm_default_91[0]
        getitem_282 = native_batch_norm_default_91[1]
        getitem_283 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu_default_53 = torch.ops.aten.relu.default(getitem_260)
        convolution_default_170 = torch.ops.aten.convolution.default(relu_default_53, primals_1121, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_171 = torch.ops.aten.convolution.default(convolution_default_170, primals_1122, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_171, primals_1115, primals_1111, primals_1113, primals_1114, True, 0.1, 0.001);  primals_1111 = None
        getitem_284 = native_batch_norm_default_92[0]
        getitem_285 = native_batch_norm_default_92[1]
        getitem_286 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_172 = torch.ops.aten.convolution.default(relu__default_38, primals_1123, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_173 = torch.ops.aten.convolution.default(convolution_default_172, primals_1124, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_173, primals_1120, primals_1116, primals_1118, primals_1119, True, 0.1, 0.001);  primals_1116 = None
        getitem_287 = native_batch_norm_default_93[0]
        getitem_288 = native_batch_norm_default_93[1]
        getitem_289 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(getitem_281, getitem_287);  getitem_281 = getitem_287 = None
        avg_pool2d_default_23 = torch.ops.aten.avg_pool2d.default(getitem_263, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_38 = torch.ops.aten.add.Tensor(avg_pool2d_default_23, getitem_260);  avg_pool2d_default_23 = None
        avg_pool2d_default_24 = torch.ops.aten.avg_pool2d.default(getitem_260, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_25 = torch.ops.aten.avg_pool2d.default(getitem_260, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_39 = torch.ops.aten.add.Tensor(avg_pool2d_default_24, avg_pool2d_default_25);  avg_pool2d_default_24 = avg_pool2d_default_25 = None
        relu_default_54 = torch.ops.aten.relu.default(getitem_263)
        convolution_default_174 = torch.ops.aten.convolution.default(relu_default_54, primals_1135, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_175 = torch.ops.aten.convolution.default(convolution_default_174, primals_1136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_175, primals_1129, primals_1125, primals_1127, primals_1128, True, 0.1, 0.001);  primals_1125 = None
        getitem_290 = native_batch_norm_default_94[0]
        getitem_291 = native_batch_norm_default_94[1]
        getitem_292 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        convolution_default_176 = torch.ops.aten.convolution.default(relu__default_39, primals_1137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_177 = torch.ops.aten.convolution.default(convolution_default_176, primals_1138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_177, primals_1134, primals_1130, primals_1132, primals_1133, True, 0.1, 0.001);  primals_1130 = None
        getitem_293 = native_batch_norm_default_95[0]
        getitem_294 = native_batch_norm_default_95[1]
        getitem_295 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_293, getitem_263);  getitem_293 = None
        cat_default_9 = torch.ops.aten.cat.default([getitem_260, add_tensor_36, add_tensor_37, add_tensor_38, add_tensor_39, add_tensor_40], 1);  add_tensor_36 = add_tensor_37 = add_tensor_38 = add_tensor_39 = add_tensor_40 = None
        relu_default_55 = torch.ops.aten.relu.default(cat_default_8)
        convolution_default_178 = torch.ops.aten.convolution.default(relu_default_55, primals_1723, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_178, primals_1722, primals_1718, primals_1720, primals_1721, True, 0.1, 0.001);  primals_1718 = None
        getitem_296 = native_batch_norm_default_96[0]
        getitem_297 = native_batch_norm_default_96[1]
        getitem_298 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        relu_default_56 = torch.ops.aten.relu.default(cat_default_9);  cat_default_9 = None
        convolution_default_179 = torch.ops.aten.convolution.default(relu_default_56, primals_1717, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_179, primals_1716, primals_1712, primals_1714, primals_1715, True, 0.1, 0.001);  primals_1712 = None
        getitem_299 = native_batch_norm_default_97[0]
        getitem_300 = native_batch_norm_default_97[1]
        getitem_301 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        relu_default_57 = torch.ops.aten.relu.default(getitem_299)
        constant_pad_nd_default_16 = torch.ops.aten.constant_pad_nd.default(relu_default_57, [1, 2, 1, 2], 0.0)
        convolution_default_180 = torch.ops.aten.convolution.default(constant_pad_nd_default_16, primals_1652, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 336)
        convolution_default_181 = torch.ops.aten.convolution.default(convolution_default_180, primals_1653, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_181, primals_1646, primals_1642, primals_1644, primals_1645, True, 0.1, 0.001);  primals_1642 = None
        getitem_302 = native_batch_norm_default_98[0]
        getitem_303 = native_batch_norm_default_98[1]
        getitem_304 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_302);  getitem_302 = None
        convolution_default_182 = torch.ops.aten.convolution.default(relu__default_40, primals_1654, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_183 = torch.ops.aten.convolution.default(convolution_default_182, primals_1655, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_183, primals_1651, primals_1647, primals_1649, primals_1650, True, 0.1, 0.001);  primals_1647 = None
        getitem_305 = native_batch_norm_default_99[0]
        getitem_306 = native_batch_norm_default_99[1]
        getitem_307 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu_default_58 = torch.ops.aten.relu.default(getitem_296)
        constant_pad_nd_default_17 = torch.ops.aten.constant_pad_nd.default(relu_default_58, [2, 3, 2, 3], 0.0)
        convolution_default_184 = torch.ops.aten.convolution.default(constant_pad_nd_default_17, primals_1666, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 336)
        convolution_default_185 = torch.ops.aten.convolution.default(convolution_default_184, primals_1667, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_185, primals_1660, primals_1656, primals_1658, primals_1659, True, 0.1, 0.001);  primals_1656 = None
        getitem_308 = native_batch_norm_default_100[0]
        getitem_309 = native_batch_norm_default_100[1]
        getitem_310 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_186 = torch.ops.aten.convolution.default(relu__default_41, primals_1668, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 336)
        convolution_default_187 = torch.ops.aten.convolution.default(convolution_default_186, primals_1669, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_1665, primals_1661, primals_1663, primals_1664, True, 0.1, 0.001);  primals_1661 = None
        getitem_311 = native_batch_norm_default_101[0]
        getitem_312 = native_batch_norm_default_101[1]
        getitem_313 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_305, getitem_311);  getitem_305 = getitem_311 = None
        constant_pad_nd_default_18 = torch.ops.aten.constant_pad_nd.default(getitem_299, [0, 1, 0, 1], -inf)
        max_pool2d_with_indices_default_4 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_18, [3, 3], [2, 2])
        getitem_314 = max_pool2d_with_indices_default_4[0]
        getitem_315 = max_pool2d_with_indices_default_4[1];  max_pool2d_with_indices_default_4 = None
        relu_default_59 = torch.ops.aten.relu.default(getitem_296)
        constant_pad_nd_default_19 = torch.ops.aten.constant_pad_nd.default(relu_default_59, [2, 3, 2, 3], 0.0)
        convolution_default_188 = torch.ops.aten.convolution.default(constant_pad_nd_default_19, primals_1680, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 336)
        convolution_default_189 = torch.ops.aten.convolution.default(convolution_default_188, primals_1681, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_189, primals_1674, primals_1670, primals_1672, primals_1673, True, 0.1, 0.001);  primals_1670 = None
        getitem_316 = native_batch_norm_default_102[0]
        getitem_317 = native_batch_norm_default_102[1]
        getitem_318 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_316);  getitem_316 = None
        convolution_default_190 = torch.ops.aten.convolution.default(relu__default_42, primals_1682, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 336)
        convolution_default_191 = torch.ops.aten.convolution.default(convolution_default_190, primals_1683, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_191, primals_1679, primals_1675, primals_1677, primals_1678, True, 0.1, 0.001);  primals_1675 = None
        getitem_319 = native_batch_norm_default_103[0]
        getitem_320 = native_batch_norm_default_103[1]
        getitem_321 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(getitem_314, getitem_319);  getitem_314 = getitem_319 = None
        constant_pad_nd_default_20 = torch.ops.aten.constant_pad_nd.default(getitem_299, [0, 1, 0, 1], 0.0)
        avg_pool2d_default_26 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_20, [3, 3], [2, 2], [0, 0], False, False)
        relu_default_60 = torch.ops.aten.relu.default(getitem_296);  getitem_296 = None
        constant_pad_nd_default_21 = torch.ops.aten.constant_pad_nd.default(relu_default_60, [1, 2, 1, 2], 0.0)
        convolution_default_192 = torch.ops.aten.convolution.default(constant_pad_nd_default_21, primals_1694, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 336)
        convolution_default_193 = torch.ops.aten.convolution.default(convolution_default_192, primals_1695, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_193, primals_1688, primals_1684, primals_1686, primals_1687, True, 0.1, 0.001);  primals_1684 = None
        getitem_322 = native_batch_norm_default_104[0]
        getitem_323 = native_batch_norm_default_104[1]
        getitem_324 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_322);  getitem_322 = None
        convolution_default_194 = torch.ops.aten.convolution.default(relu__default_43, primals_1696, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_195 = torch.ops.aten.convolution.default(convolution_default_194, primals_1697, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_195, primals_1693, primals_1689, primals_1691, primals_1692, True, 0.1, 0.001);  primals_1689 = None
        getitem_325 = native_batch_norm_default_105[0]
        getitem_326 = native_batch_norm_default_105[1]
        getitem_327 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(avg_pool2d_default_26, getitem_325);  avg_pool2d_default_26 = getitem_325 = None
        avg_pool2d_default_27 = torch.ops.aten.avg_pool2d.default(add_tensor_41, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_44 = torch.ops.aten.add.Tensor(avg_pool2d_default_27, add_tensor_42);  avg_pool2d_default_27 = None
        relu_default_61 = torch.ops.aten.relu.default(add_tensor_41)
        convolution_default_196 = torch.ops.aten.convolution.default(relu_default_61, primals_1708, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_197 = torch.ops.aten.convolution.default(convolution_default_196, primals_1709, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_197, primals_1702, primals_1698, primals_1700, primals_1701, True, 0.1, 0.001);  primals_1698 = None
        getitem_328 = native_batch_norm_default_106[0]
        getitem_329 = native_batch_norm_default_106[1]
        getitem_330 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_328);  getitem_328 = None
        convolution_default_198 = torch.ops.aten.convolution.default(relu__default_44, primals_1710, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_199 = torch.ops.aten.convolution.default(convolution_default_198, primals_1711, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_199, primals_1707, primals_1703, primals_1705, primals_1706, True, 0.1, 0.001);  primals_1703 = None
        getitem_331 = native_batch_norm_default_107[0]
        getitem_332 = native_batch_norm_default_107[1]
        getitem_333 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        constant_pad_nd_default_22 = torch.ops.aten.constant_pad_nd.default(getitem_299, [0, 1, 0, 1], -inf);  getitem_299 = None
        max_pool2d_with_indices_default_5 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_22, [3, 3], [2, 2])
        getitem_334 = max_pool2d_with_indices_default_5[0]
        getitem_335 = max_pool2d_with_indices_default_5[1];  max_pool2d_with_indices_default_5 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_331, getitem_334);  getitem_331 = getitem_334 = None
        cat_default_10 = torch.ops.aten.cat.default([add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_45], 1);  add_tensor_42 = add_tensor_43 = add_tensor_44 = add_tensor_45 = None
        relu_default_62 = torch.ops.aten.relu.default(cat_default_8);  cat_default_8 = None
        avg_pool2d_default_28 = torch.ops.aten.avg_pool2d.default(relu_default_62, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_200 = torch.ops.aten.convolution.default(avg_pool2d_default_28, primals_1232, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_23 = torch.ops.aten.constant_pad_nd.default(relu_default_62, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_29 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_23, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_201 = torch.ops.aten.convolution.default(avg_pool2d_default_29, primals_1233, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_11 = torch.ops.aten.cat.default([convolution_default_200, convolution_default_201], 1);  convolution_default_200 = convolution_default_201 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(cat_default_11, primals_1231, primals_1227, primals_1229, primals_1230, True, 0.1, 0.001);  primals_1227 = None
        getitem_336 = native_batch_norm_default_108[0]
        getitem_337 = native_batch_norm_default_108[1]
        getitem_338 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu_default_63 = torch.ops.aten.relu.default(cat_default_10)
        convolution_default_202 = torch.ops.aten.convolution.default(relu_default_63, primals_1226, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_202, primals_1225, primals_1221, primals_1223, primals_1224, True, 0.1, 0.001);  primals_1221 = None
        getitem_339 = native_batch_norm_default_109[0]
        getitem_340 = native_batch_norm_default_109[1]
        getitem_341 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        relu_default_64 = torch.ops.aten.relu.default(getitem_339)
        convolution_default_203 = torch.ops.aten.convolution.default(relu_default_64, primals_1161, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_204 = torch.ops.aten.convolution.default(convolution_default_203, primals_1162, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_204, primals_1155, primals_1151, primals_1153, primals_1154, True, 0.1, 0.001);  primals_1151 = None
        getitem_342 = native_batch_norm_default_110[0]
        getitem_343 = native_batch_norm_default_110[1]
        getitem_344 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_342);  getitem_342 = None
        convolution_default_205 = torch.ops.aten.convolution.default(relu__default_45, primals_1163, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_206 = torch.ops.aten.convolution.default(convolution_default_205, primals_1164, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_206, primals_1160, primals_1156, primals_1158, primals_1159, True, 0.1, 0.001);  primals_1156 = None
        getitem_345 = native_batch_norm_default_111[0]
        getitem_346 = native_batch_norm_default_111[1]
        getitem_347 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        relu_default_65 = torch.ops.aten.relu.default(getitem_336)
        convolution_default_207 = torch.ops.aten.convolution.default(relu_default_65, primals_1175, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_208 = torch.ops.aten.convolution.default(convolution_default_207, primals_1176, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_208, primals_1169, primals_1165, primals_1167, primals_1168, True, 0.1, 0.001);  primals_1165 = None
        getitem_348 = native_batch_norm_default_112[0]
        getitem_349 = native_batch_norm_default_112[1]
        getitem_350 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_348);  getitem_348 = None
        convolution_default_209 = torch.ops.aten.convolution.default(relu__default_46, primals_1177, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_210 = torch.ops.aten.convolution.default(convolution_default_209, primals_1178, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_210, primals_1174, primals_1170, primals_1172, primals_1173, True, 0.1, 0.001);  primals_1170 = None
        getitem_351 = native_batch_norm_default_113[0]
        getitem_352 = native_batch_norm_default_113[1]
        getitem_353 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(getitem_345, getitem_351);  getitem_345 = getitem_351 = None
        relu_default_66 = torch.ops.aten.relu.default(getitem_336)
        convolution_default_211 = torch.ops.aten.convolution.default(relu_default_66, primals_1189, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_212 = torch.ops.aten.convolution.default(convolution_default_211, primals_1190, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_212, primals_1183, primals_1179, primals_1181, primals_1182, True, 0.1, 0.001);  primals_1179 = None
        getitem_354 = native_batch_norm_default_114[0]
        getitem_355 = native_batch_norm_default_114[1]
        getitem_356 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_354);  getitem_354 = None
        convolution_default_213 = torch.ops.aten.convolution.default(relu__default_47, primals_1191, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_214 = torch.ops.aten.convolution.default(convolution_default_213, primals_1192, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_214, primals_1188, primals_1184, primals_1186, primals_1187, True, 0.1, 0.001);  primals_1184 = None
        getitem_357 = native_batch_norm_default_115[0]
        getitem_358 = native_batch_norm_default_115[1]
        getitem_359 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        relu_default_67 = torch.ops.aten.relu.default(getitem_336)
        convolution_default_215 = torch.ops.aten.convolution.default(relu_default_67, primals_1203, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_216 = torch.ops.aten.convolution.default(convolution_default_215, primals_1204, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_216, primals_1197, primals_1193, primals_1195, primals_1196, True, 0.1, 0.001);  primals_1193 = None
        getitem_360 = native_batch_norm_default_116[0]
        getitem_361 = native_batch_norm_default_116[1]
        getitem_362 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_360);  getitem_360 = None
        convolution_default_217 = torch.ops.aten.convolution.default(relu__default_48, primals_1205, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_218 = torch.ops.aten.convolution.default(convolution_default_217, primals_1206, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_218, primals_1202, primals_1198, primals_1200, primals_1201, True, 0.1, 0.001);  primals_1198 = None
        getitem_363 = native_batch_norm_default_117[0]
        getitem_364 = native_batch_norm_default_117[1]
        getitem_365 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_357, getitem_363);  getitem_357 = getitem_363 = None
        avg_pool2d_default_30 = torch.ops.aten.avg_pool2d.default(getitem_339, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_48 = torch.ops.aten.add.Tensor(avg_pool2d_default_30, getitem_336);  avg_pool2d_default_30 = None
        avg_pool2d_default_31 = torch.ops.aten.avg_pool2d.default(getitem_336, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_32 = torch.ops.aten.avg_pool2d.default(getitem_336, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_49 = torch.ops.aten.add.Tensor(avg_pool2d_default_31, avg_pool2d_default_32);  avg_pool2d_default_31 = avg_pool2d_default_32 = None
        relu_default_68 = torch.ops.aten.relu.default(getitem_339)
        convolution_default_219 = torch.ops.aten.convolution.default(relu_default_68, primals_1217, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_220 = torch.ops.aten.convolution.default(convolution_default_219, primals_1218, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_220, primals_1211, primals_1207, primals_1209, primals_1210, True, 0.1, 0.001);  primals_1207 = None
        getitem_366 = native_batch_norm_default_118[0]
        getitem_367 = native_batch_norm_default_118[1]
        getitem_368 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_366);  getitem_366 = None
        convolution_default_221 = torch.ops.aten.convolution.default(relu__default_49, primals_1219, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_222 = torch.ops.aten.convolution.default(convolution_default_221, primals_1220, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_222, primals_1216, primals_1212, primals_1214, primals_1215, True, 0.1, 0.001);  primals_1212 = None
        getitem_369 = native_batch_norm_default_119[0]
        getitem_370 = native_batch_norm_default_119[1]
        getitem_371 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(getitem_369, getitem_339);  getitem_369 = None
        cat_default_12 = torch.ops.aten.cat.default([getitem_336, add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_49, add_tensor_50], 1);  add_tensor_46 = add_tensor_47 = add_tensor_48 = add_tensor_49 = add_tensor_50 = None
        relu_default_69 = torch.ops.aten.relu.default(cat_default_10);  cat_default_10 = None
        convolution_default_223 = torch.ops.aten.convolution.default(relu_default_69, primals_1315, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_223, primals_1314, primals_1310, primals_1312, primals_1313, True, 0.1, 0.001);  primals_1310 = None
        getitem_372 = native_batch_norm_default_120[0]
        getitem_373 = native_batch_norm_default_120[1]
        getitem_374 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        relu_default_70 = torch.ops.aten.relu.default(cat_default_12)
        convolution_default_224 = torch.ops.aten.convolution.default(relu_default_70, primals_1309, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_224, primals_1308, primals_1304, primals_1306, primals_1307, True, 0.1, 0.001);  primals_1304 = None
        getitem_375 = native_batch_norm_default_121[0]
        getitem_376 = native_batch_norm_default_121[1]
        getitem_377 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        relu_default_71 = torch.ops.aten.relu.default(getitem_375)
        convolution_default_225 = torch.ops.aten.convolution.default(relu_default_71, primals_1244, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_226 = torch.ops.aten.convolution.default(convolution_default_225, primals_1245, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_226, primals_1238, primals_1234, primals_1236, primals_1237, True, 0.1, 0.001);  primals_1234 = None
        getitem_378 = native_batch_norm_default_122[0]
        getitem_379 = native_batch_norm_default_122[1]
        getitem_380 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_378);  getitem_378 = None
        convolution_default_227 = torch.ops.aten.convolution.default(relu__default_50, primals_1246, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_228 = torch.ops.aten.convolution.default(convolution_default_227, primals_1247, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_228, primals_1243, primals_1239, primals_1241, primals_1242, True, 0.1, 0.001);  primals_1239 = None
        getitem_381 = native_batch_norm_default_123[0]
        getitem_382 = native_batch_norm_default_123[1]
        getitem_383 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        relu_default_72 = torch.ops.aten.relu.default(getitem_372)
        convolution_default_229 = torch.ops.aten.convolution.default(relu_default_72, primals_1258, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_230 = torch.ops.aten.convolution.default(convolution_default_229, primals_1259, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_230, primals_1252, primals_1248, primals_1250, primals_1251, True, 0.1, 0.001);  primals_1248 = None
        getitem_384 = native_batch_norm_default_124[0]
        getitem_385 = native_batch_norm_default_124[1]
        getitem_386 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_384);  getitem_384 = None
        convolution_default_231 = torch.ops.aten.convolution.default(relu__default_51, primals_1260, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_232 = torch.ops.aten.convolution.default(convolution_default_231, primals_1261, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_232, primals_1257, primals_1253, primals_1255, primals_1256, True, 0.1, 0.001);  primals_1253 = None
        getitem_387 = native_batch_norm_default_125[0]
        getitem_388 = native_batch_norm_default_125[1]
        getitem_389 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(getitem_381, getitem_387);  getitem_381 = getitem_387 = None
        relu_default_73 = torch.ops.aten.relu.default(getitem_372)
        convolution_default_233 = torch.ops.aten.convolution.default(relu_default_73, primals_1272, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_234 = torch.ops.aten.convolution.default(convolution_default_233, primals_1273, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_234, primals_1266, primals_1262, primals_1264, primals_1265, True, 0.1, 0.001);  primals_1262 = None
        getitem_390 = native_batch_norm_default_126[0]
        getitem_391 = native_batch_norm_default_126[1]
        getitem_392 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_390);  getitem_390 = None
        convolution_default_235 = torch.ops.aten.convolution.default(relu__default_52, primals_1274, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_236 = torch.ops.aten.convolution.default(convolution_default_235, primals_1275, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_236, primals_1271, primals_1267, primals_1269, primals_1270, True, 0.1, 0.001);  primals_1267 = None
        getitem_393 = native_batch_norm_default_127[0]
        getitem_394 = native_batch_norm_default_127[1]
        getitem_395 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        relu_default_74 = torch.ops.aten.relu.default(getitem_372)
        convolution_default_237 = torch.ops.aten.convolution.default(relu_default_74, primals_1286, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_238 = torch.ops.aten.convolution.default(convolution_default_237, primals_1287, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_238, primals_1280, primals_1276, primals_1278, primals_1279, True, 0.1, 0.001);  primals_1276 = None
        getitem_396 = native_batch_norm_default_128[0]
        getitem_397 = native_batch_norm_default_128[1]
        getitem_398 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_396);  getitem_396 = None
        convolution_default_239 = torch.ops.aten.convolution.default(relu__default_53, primals_1288, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_240 = torch.ops.aten.convolution.default(convolution_default_239, primals_1289, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_240, primals_1285, primals_1281, primals_1283, primals_1284, True, 0.1, 0.001);  primals_1281 = None
        getitem_399 = native_batch_norm_default_129[0]
        getitem_400 = native_batch_norm_default_129[1]
        getitem_401 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(getitem_393, getitem_399);  getitem_393 = getitem_399 = None
        avg_pool2d_default_33 = torch.ops.aten.avg_pool2d.default(getitem_375, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_53 = torch.ops.aten.add.Tensor(avg_pool2d_default_33, getitem_372);  avg_pool2d_default_33 = None
        avg_pool2d_default_34 = torch.ops.aten.avg_pool2d.default(getitem_372, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_35 = torch.ops.aten.avg_pool2d.default(getitem_372, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_54 = torch.ops.aten.add.Tensor(avg_pool2d_default_34, avg_pool2d_default_35);  avg_pool2d_default_34 = avg_pool2d_default_35 = None
        relu_default_75 = torch.ops.aten.relu.default(getitem_375)
        convolution_default_241 = torch.ops.aten.convolution.default(relu_default_75, primals_1300, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_242 = torch.ops.aten.convolution.default(convolution_default_241, primals_1301, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_242, primals_1294, primals_1290, primals_1292, primals_1293, True, 0.1, 0.001);  primals_1290 = None
        getitem_402 = native_batch_norm_default_130[0]
        getitem_403 = native_batch_norm_default_130[1]
        getitem_404 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_402);  getitem_402 = None
        convolution_default_243 = torch.ops.aten.convolution.default(relu__default_54, primals_1302, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_244 = torch.ops.aten.convolution.default(convolution_default_243, primals_1303, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_244, primals_1299, primals_1295, primals_1297, primals_1298, True, 0.1, 0.001);  primals_1295 = None
        getitem_405 = native_batch_norm_default_131[0]
        getitem_406 = native_batch_norm_default_131[1]
        getitem_407 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(getitem_405, getitem_375);  getitem_405 = None
        cat_default_13 = torch.ops.aten.cat.default([getitem_372, add_tensor_51, add_tensor_52, add_tensor_53, add_tensor_54, add_tensor_55], 1);  add_tensor_51 = add_tensor_52 = add_tensor_53 = add_tensor_54 = add_tensor_55 = None
        relu_default_76 = torch.ops.aten.relu.default(cat_default_12);  cat_default_12 = None
        convolution_default_245 = torch.ops.aten.convolution.default(relu_default_76, primals_1397, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_245, primals_1396, primals_1392, primals_1394, primals_1395, True, 0.1, 0.001);  primals_1392 = None
        getitem_408 = native_batch_norm_default_132[0]
        getitem_409 = native_batch_norm_default_132[1]
        getitem_410 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        relu_default_77 = torch.ops.aten.relu.default(cat_default_13)
        convolution_default_246 = torch.ops.aten.convolution.default(relu_default_77, primals_1391, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_246, primals_1390, primals_1386, primals_1388, primals_1389, True, 0.1, 0.001);  primals_1386 = None
        getitem_411 = native_batch_norm_default_133[0]
        getitem_412 = native_batch_norm_default_133[1]
        getitem_413 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        relu_default_78 = torch.ops.aten.relu.default(getitem_411)
        convolution_default_247 = torch.ops.aten.convolution.default(relu_default_78, primals_1326, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_248 = torch.ops.aten.convolution.default(convolution_default_247, primals_1327, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_248, primals_1320, primals_1316, primals_1318, primals_1319, True, 0.1, 0.001);  primals_1316 = None
        getitem_414 = native_batch_norm_default_134[0]
        getitem_415 = native_batch_norm_default_134[1]
        getitem_416 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_414);  getitem_414 = None
        convolution_default_249 = torch.ops.aten.convolution.default(relu__default_55, primals_1328, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_250 = torch.ops.aten.convolution.default(convolution_default_249, primals_1329, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_250, primals_1325, primals_1321, primals_1323, primals_1324, True, 0.1, 0.001);  primals_1321 = None
        getitem_417 = native_batch_norm_default_135[0]
        getitem_418 = native_batch_norm_default_135[1]
        getitem_419 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        relu_default_79 = torch.ops.aten.relu.default(getitem_408)
        convolution_default_251 = torch.ops.aten.convolution.default(relu_default_79, primals_1340, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_252 = torch.ops.aten.convolution.default(convolution_default_251, primals_1341, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_252, primals_1334, primals_1330, primals_1332, primals_1333, True, 0.1, 0.001);  primals_1330 = None
        getitem_420 = native_batch_norm_default_136[0]
        getitem_421 = native_batch_norm_default_136[1]
        getitem_422 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_420);  getitem_420 = None
        convolution_default_253 = torch.ops.aten.convolution.default(relu__default_56, primals_1342, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_254 = torch.ops.aten.convolution.default(convolution_default_253, primals_1343, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_254, primals_1339, primals_1335, primals_1337, primals_1338, True, 0.1, 0.001);  primals_1335 = None
        getitem_423 = native_batch_norm_default_137[0]
        getitem_424 = native_batch_norm_default_137[1]
        getitem_425 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_417, getitem_423);  getitem_417 = getitem_423 = None
        relu_default_80 = torch.ops.aten.relu.default(getitem_408)
        convolution_default_255 = torch.ops.aten.convolution.default(relu_default_80, primals_1354, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_256 = torch.ops.aten.convolution.default(convolution_default_255, primals_1355, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_256, primals_1348, primals_1344, primals_1346, primals_1347, True, 0.1, 0.001);  primals_1344 = None
        getitem_426 = native_batch_norm_default_138[0]
        getitem_427 = native_batch_norm_default_138[1]
        getitem_428 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_426);  getitem_426 = None
        convolution_default_257 = torch.ops.aten.convolution.default(relu__default_57, primals_1356, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_258 = torch.ops.aten.convolution.default(convolution_default_257, primals_1357, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_258, primals_1353, primals_1349, primals_1351, primals_1352, True, 0.1, 0.001);  primals_1349 = None
        getitem_429 = native_batch_norm_default_139[0]
        getitem_430 = native_batch_norm_default_139[1]
        getitem_431 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        relu_default_81 = torch.ops.aten.relu.default(getitem_408)
        convolution_default_259 = torch.ops.aten.convolution.default(relu_default_81, primals_1368, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_260 = torch.ops.aten.convolution.default(convolution_default_259, primals_1369, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_260, primals_1362, primals_1358, primals_1360, primals_1361, True, 0.1, 0.001);  primals_1358 = None
        getitem_432 = native_batch_norm_default_140[0]
        getitem_433 = native_batch_norm_default_140[1]
        getitem_434 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_432);  getitem_432 = None
        convolution_default_261 = torch.ops.aten.convolution.default(relu__default_58, primals_1370, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_262 = torch.ops.aten.convolution.default(convolution_default_261, primals_1371, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_262, primals_1367, primals_1363, primals_1365, primals_1366, True, 0.1, 0.001);  primals_1363 = None
        getitem_435 = native_batch_norm_default_141[0]
        getitem_436 = native_batch_norm_default_141[1]
        getitem_437 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(getitem_429, getitem_435);  getitem_429 = getitem_435 = None
        avg_pool2d_default_36 = torch.ops.aten.avg_pool2d.default(getitem_411, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_58 = torch.ops.aten.add.Tensor(avg_pool2d_default_36, getitem_408);  avg_pool2d_default_36 = None
        avg_pool2d_default_37 = torch.ops.aten.avg_pool2d.default(getitem_408, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_38 = torch.ops.aten.avg_pool2d.default(getitem_408, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_59 = torch.ops.aten.add.Tensor(avg_pool2d_default_37, avg_pool2d_default_38);  avg_pool2d_default_37 = avg_pool2d_default_38 = None
        relu_default_82 = torch.ops.aten.relu.default(getitem_411)
        convolution_default_263 = torch.ops.aten.convolution.default(relu_default_82, primals_1382, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_264 = torch.ops.aten.convolution.default(convolution_default_263, primals_1383, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_264, primals_1376, primals_1372, primals_1374, primals_1375, True, 0.1, 0.001);  primals_1372 = None
        getitem_438 = native_batch_norm_default_142[0]
        getitem_439 = native_batch_norm_default_142[1]
        getitem_440 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_438);  getitem_438 = None
        convolution_default_265 = torch.ops.aten.convolution.default(relu__default_59, primals_1384, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_266 = torch.ops.aten.convolution.default(convolution_default_265, primals_1385, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_266, primals_1381, primals_1377, primals_1379, primals_1380, True, 0.1, 0.001);  primals_1377 = None
        getitem_441 = native_batch_norm_default_143[0]
        getitem_442 = native_batch_norm_default_143[1]
        getitem_443 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(getitem_441, getitem_411);  getitem_441 = None
        cat_default_14 = torch.ops.aten.cat.default([getitem_408, add_tensor_56, add_tensor_57, add_tensor_58, add_tensor_59, add_tensor_60], 1);  add_tensor_56 = add_tensor_57 = add_tensor_58 = add_tensor_59 = add_tensor_60 = None
        relu_default_83 = torch.ops.aten.relu.default(cat_default_13);  cat_default_13 = None
        convolution_default_267 = torch.ops.aten.convolution.default(relu_default_83, primals_1479, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_267, primals_1478, primals_1474, primals_1476, primals_1477, True, 0.1, 0.001);  primals_1474 = None
        getitem_444 = native_batch_norm_default_144[0]
        getitem_445 = native_batch_norm_default_144[1]
        getitem_446 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        relu_default_84 = torch.ops.aten.relu.default(cat_default_14)
        convolution_default_268 = torch.ops.aten.convolution.default(relu_default_84, primals_1473, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_268, primals_1472, primals_1468, primals_1470, primals_1471, True, 0.1, 0.001);  primals_1468 = None
        getitem_447 = native_batch_norm_default_145[0]
        getitem_448 = native_batch_norm_default_145[1]
        getitem_449 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        relu_default_85 = torch.ops.aten.relu.default(getitem_447)
        convolution_default_269 = torch.ops.aten.convolution.default(relu_default_85, primals_1408, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_270 = torch.ops.aten.convolution.default(convolution_default_269, primals_1409, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_270, primals_1402, primals_1398, primals_1400, primals_1401, True, 0.1, 0.001);  primals_1398 = None
        getitem_450 = native_batch_norm_default_146[0]
        getitem_451 = native_batch_norm_default_146[1]
        getitem_452 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_450);  getitem_450 = None
        convolution_default_271 = torch.ops.aten.convolution.default(relu__default_60, primals_1410, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_272 = torch.ops.aten.convolution.default(convolution_default_271, primals_1411, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_272, primals_1407, primals_1403, primals_1405, primals_1406, True, 0.1, 0.001);  primals_1403 = None
        getitem_453 = native_batch_norm_default_147[0]
        getitem_454 = native_batch_norm_default_147[1]
        getitem_455 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        relu_default_86 = torch.ops.aten.relu.default(getitem_444)
        convolution_default_273 = torch.ops.aten.convolution.default(relu_default_86, primals_1422, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_274 = torch.ops.aten.convolution.default(convolution_default_273, primals_1423, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_274, primals_1416, primals_1412, primals_1414, primals_1415, True, 0.1, 0.001);  primals_1412 = None
        getitem_456 = native_batch_norm_default_148[0]
        getitem_457 = native_batch_norm_default_148[1]
        getitem_458 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_456);  getitem_456 = None
        convolution_default_275 = torch.ops.aten.convolution.default(relu__default_61, primals_1424, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_276 = torch.ops.aten.convolution.default(convolution_default_275, primals_1425, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_276, primals_1421, primals_1417, primals_1419, primals_1420, True, 0.1, 0.001);  primals_1417 = None
        getitem_459 = native_batch_norm_default_149[0]
        getitem_460 = native_batch_norm_default_149[1]
        getitem_461 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(getitem_453, getitem_459);  getitem_453 = getitem_459 = None
        relu_default_87 = torch.ops.aten.relu.default(getitem_444)
        convolution_default_277 = torch.ops.aten.convolution.default(relu_default_87, primals_1436, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_278 = torch.ops.aten.convolution.default(convolution_default_277, primals_1437, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_278, primals_1430, primals_1426, primals_1428, primals_1429, True, 0.1, 0.001);  primals_1426 = None
        getitem_462 = native_batch_norm_default_150[0]
        getitem_463 = native_batch_norm_default_150[1]
        getitem_464 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_462);  getitem_462 = None
        convolution_default_279 = torch.ops.aten.convolution.default(relu__default_62, primals_1438, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_280 = torch.ops.aten.convolution.default(convolution_default_279, primals_1439, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_280, primals_1435, primals_1431, primals_1433, primals_1434, True, 0.1, 0.001);  primals_1431 = None
        getitem_465 = native_batch_norm_default_151[0]
        getitem_466 = native_batch_norm_default_151[1]
        getitem_467 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        relu_default_88 = torch.ops.aten.relu.default(getitem_444)
        convolution_default_281 = torch.ops.aten.convolution.default(relu_default_88, primals_1450, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_282 = torch.ops.aten.convolution.default(convolution_default_281, primals_1451, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_282, primals_1444, primals_1440, primals_1442, primals_1443, True, 0.1, 0.001);  primals_1440 = None
        getitem_468 = native_batch_norm_default_152[0]
        getitem_469 = native_batch_norm_default_152[1]
        getitem_470 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_468);  getitem_468 = None
        convolution_default_283 = torch.ops.aten.convolution.default(relu__default_63, primals_1452, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_284 = torch.ops.aten.convolution.default(convolution_default_283, primals_1453, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_284, primals_1449, primals_1445, primals_1447, primals_1448, True, 0.1, 0.001);  primals_1445 = None
        getitem_471 = native_batch_norm_default_153[0]
        getitem_472 = native_batch_norm_default_153[1]
        getitem_473 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_465, getitem_471);  getitem_465 = getitem_471 = None
        avg_pool2d_default_39 = torch.ops.aten.avg_pool2d.default(getitem_447, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_63 = torch.ops.aten.add.Tensor(avg_pool2d_default_39, getitem_444);  avg_pool2d_default_39 = None
        avg_pool2d_default_40 = torch.ops.aten.avg_pool2d.default(getitem_444, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_41 = torch.ops.aten.avg_pool2d.default(getitem_444, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_64 = torch.ops.aten.add.Tensor(avg_pool2d_default_40, avg_pool2d_default_41);  avg_pool2d_default_40 = avg_pool2d_default_41 = None
        relu_default_89 = torch.ops.aten.relu.default(getitem_447)
        convolution_default_285 = torch.ops.aten.convolution.default(relu_default_89, primals_1464, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_286 = torch.ops.aten.convolution.default(convolution_default_285, primals_1465, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_286, primals_1458, primals_1454, primals_1456, primals_1457, True, 0.1, 0.001);  primals_1454 = None
        getitem_474 = native_batch_norm_default_154[0]
        getitem_475 = native_batch_norm_default_154[1]
        getitem_476 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_474);  getitem_474 = None
        convolution_default_287 = torch.ops.aten.convolution.default(relu__default_64, primals_1466, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_288 = torch.ops.aten.convolution.default(convolution_default_287, primals_1467, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_288, primals_1463, primals_1459, primals_1461, primals_1462, True, 0.1, 0.001);  primals_1459 = None
        getitem_477 = native_batch_norm_default_155[0]
        getitem_478 = native_batch_norm_default_155[1]
        getitem_479 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_477, getitem_447);  getitem_477 = None
        cat_default_15 = torch.ops.aten.cat.default([getitem_444, add_tensor_61, add_tensor_62, add_tensor_63, add_tensor_64, add_tensor_65], 1);  add_tensor_61 = add_tensor_62 = add_tensor_63 = add_tensor_64 = add_tensor_65 = None
        relu_default_90 = torch.ops.aten.relu.default(cat_default_14);  cat_default_14 = None
        convolution_default_289 = torch.ops.aten.convolution.default(relu_default_90, primals_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_289, primals_164, primals_160, primals_162, primals_163, True, 0.1, 0.001);  primals_160 = None
        getitem_480 = native_batch_norm_default_156[0]
        getitem_481 = native_batch_norm_default_156[1]
        getitem_482 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        relu_default_91 = torch.ops.aten.relu.default(cat_default_15)
        convolution_default_290 = torch.ops.aten.convolution.default(relu_default_91, primals_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_157 = torch.ops.aten.native_batch_norm.default(convolution_default_290, primals_158, primals_154, primals_156, primals_157, True, 0.1, 0.001);  primals_154 = None
        getitem_483 = native_batch_norm_default_157[0]
        getitem_484 = native_batch_norm_default_157[1]
        getitem_485 = native_batch_norm_default_157[2];  native_batch_norm_default_157 = None
        relu_default_92 = torch.ops.aten.relu.default(getitem_483)
        convolution_default_291 = torch.ops.aten.convolution.default(relu_default_92, primals_94, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_292 = torch.ops.aten.convolution.default(convolution_default_291, primals_95, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_158 = torch.ops.aten.native_batch_norm.default(convolution_default_292, primals_88, primals_84, primals_86, primals_87, True, 0.1, 0.001);  primals_84 = None
        getitem_486 = native_batch_norm_default_158[0]
        getitem_487 = native_batch_norm_default_158[1]
        getitem_488 = native_batch_norm_default_158[2];  native_batch_norm_default_158 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_486);  getitem_486 = None
        convolution_default_293 = torch.ops.aten.convolution.default(relu__default_65, primals_96, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_294 = torch.ops.aten.convolution.default(convolution_default_293, primals_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_159 = torch.ops.aten.native_batch_norm.default(convolution_default_294, primals_93, primals_89, primals_91, primals_92, True, 0.1, 0.001);  primals_89 = None
        getitem_489 = native_batch_norm_default_159[0]
        getitem_490 = native_batch_norm_default_159[1]
        getitem_491 = native_batch_norm_default_159[2];  native_batch_norm_default_159 = None
        relu_default_93 = torch.ops.aten.relu.default(getitem_480)
        convolution_default_295 = torch.ops.aten.convolution.default(relu_default_93, primals_108, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_296 = torch.ops.aten.convolution.default(convolution_default_295, primals_109, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_160 = torch.ops.aten.native_batch_norm.default(convolution_default_296, primals_102, primals_98, primals_100, primals_101, True, 0.1, 0.001);  primals_98 = None
        getitem_492 = native_batch_norm_default_160[0]
        getitem_493 = native_batch_norm_default_160[1]
        getitem_494 = native_batch_norm_default_160[2];  native_batch_norm_default_160 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_492);  getitem_492 = None
        convolution_default_297 = torch.ops.aten.convolution.default(relu__default_66, primals_110, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_298 = torch.ops.aten.convolution.default(convolution_default_297, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_161 = torch.ops.aten.native_batch_norm.default(convolution_default_298, primals_107, primals_103, primals_105, primals_106, True, 0.1, 0.001);  primals_103 = None
        getitem_495 = native_batch_norm_default_161[0]
        getitem_496 = native_batch_norm_default_161[1]
        getitem_497 = native_batch_norm_default_161[2];  native_batch_norm_default_161 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(getitem_489, getitem_495);  getitem_489 = getitem_495 = None
        relu_default_94 = torch.ops.aten.relu.default(getitem_480)
        convolution_default_299 = torch.ops.aten.convolution.default(relu_default_94, primals_122, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_300 = torch.ops.aten.convolution.default(convolution_default_299, primals_123, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_162 = torch.ops.aten.native_batch_norm.default(convolution_default_300, primals_116, primals_112, primals_114, primals_115, True, 0.1, 0.001);  primals_112 = None
        getitem_498 = native_batch_norm_default_162[0]
        getitem_499 = native_batch_norm_default_162[1]
        getitem_500 = native_batch_norm_default_162[2];  native_batch_norm_default_162 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_498);  getitem_498 = None
        convolution_default_301 = torch.ops.aten.convolution.default(relu__default_67, primals_124, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_302 = torch.ops.aten.convolution.default(convolution_default_301, primals_125, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_163 = torch.ops.aten.native_batch_norm.default(convolution_default_302, primals_121, primals_117, primals_119, primals_120, True, 0.1, 0.001);  primals_117 = None
        getitem_501 = native_batch_norm_default_163[0]
        getitem_502 = native_batch_norm_default_163[1]
        getitem_503 = native_batch_norm_default_163[2];  native_batch_norm_default_163 = None
        relu_default_95 = torch.ops.aten.relu.default(getitem_480)
        convolution_default_303 = torch.ops.aten.convolution.default(relu_default_95, primals_136, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_304 = torch.ops.aten.convolution.default(convolution_default_303, primals_137, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_164 = torch.ops.aten.native_batch_norm.default(convolution_default_304, primals_130, primals_126, primals_128, primals_129, True, 0.1, 0.001);  primals_126 = None
        getitem_504 = native_batch_norm_default_164[0]
        getitem_505 = native_batch_norm_default_164[1]
        getitem_506 = native_batch_norm_default_164[2];  native_batch_norm_default_164 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_504);  getitem_504 = None
        convolution_default_305 = torch.ops.aten.convolution.default(relu__default_68, primals_138, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_306 = torch.ops.aten.convolution.default(convolution_default_305, primals_139, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_165 = torch.ops.aten.native_batch_norm.default(convolution_default_306, primals_135, primals_131, primals_133, primals_134, True, 0.1, 0.001);  primals_131 = None
        getitem_507 = native_batch_norm_default_165[0]
        getitem_508 = native_batch_norm_default_165[1]
        getitem_509 = native_batch_norm_default_165[2];  native_batch_norm_default_165 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(getitem_501, getitem_507);  getitem_501 = getitem_507 = None
        avg_pool2d_default_42 = torch.ops.aten.avg_pool2d.default(getitem_483, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_68 = torch.ops.aten.add.Tensor(avg_pool2d_default_42, getitem_480);  avg_pool2d_default_42 = None
        avg_pool2d_default_43 = torch.ops.aten.avg_pool2d.default(getitem_480, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_44 = torch.ops.aten.avg_pool2d.default(getitem_480, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_69 = torch.ops.aten.add.Tensor(avg_pool2d_default_43, avg_pool2d_default_44);  avg_pool2d_default_43 = avg_pool2d_default_44 = None
        relu_default_96 = torch.ops.aten.relu.default(getitem_483)
        convolution_default_307 = torch.ops.aten.convolution.default(relu_default_96, primals_150, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_308 = torch.ops.aten.convolution.default(convolution_default_307, primals_151, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_166 = torch.ops.aten.native_batch_norm.default(convolution_default_308, primals_144, primals_140, primals_142, primals_143, True, 0.1, 0.001);  primals_140 = None
        getitem_510 = native_batch_norm_default_166[0]
        getitem_511 = native_batch_norm_default_166[1]
        getitem_512 = native_batch_norm_default_166[2];  native_batch_norm_default_166 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_510);  getitem_510 = None
        convolution_default_309 = torch.ops.aten.convolution.default(relu__default_69, primals_152, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_310 = torch.ops.aten.convolution.default(convolution_default_309, primals_153, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_167 = torch.ops.aten.native_batch_norm.default(convolution_default_310, primals_149, primals_145, primals_147, primals_148, True, 0.1, 0.001);  primals_145 = None
        getitem_513 = native_batch_norm_default_167[0]
        getitem_514 = native_batch_norm_default_167[1]
        getitem_515 = native_batch_norm_default_167[2];  native_batch_norm_default_167 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_513, getitem_483);  getitem_513 = None
        cat_default_16 = torch.ops.aten.cat.default([getitem_480, add_tensor_66, add_tensor_67, add_tensor_68, add_tensor_69, add_tensor_70], 1);  add_tensor_66 = add_tensor_67 = add_tensor_68 = add_tensor_69 = add_tensor_70 = None
        relu_default_97 = torch.ops.aten.relu.default(cat_default_15);  cat_default_15 = None
        convolution_default_311 = torch.ops.aten.convolution.default(relu_default_97, primals_247, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_168 = torch.ops.aten.native_batch_norm.default(convolution_default_311, primals_246, primals_242, primals_244, primals_245, True, 0.1, 0.001);  primals_242 = None
        getitem_516 = native_batch_norm_default_168[0]
        getitem_517 = native_batch_norm_default_168[1]
        getitem_518 = native_batch_norm_default_168[2];  native_batch_norm_default_168 = None
        relu_default_98 = torch.ops.aten.relu.default(cat_default_16)
        convolution_default_312 = torch.ops.aten.convolution.default(relu_default_98, primals_241, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_169 = torch.ops.aten.native_batch_norm.default(convolution_default_312, primals_240, primals_236, primals_238, primals_239, True, 0.1, 0.001);  primals_236 = None
        getitem_519 = native_batch_norm_default_169[0]
        getitem_520 = native_batch_norm_default_169[1]
        getitem_521 = native_batch_norm_default_169[2];  native_batch_norm_default_169 = None
        relu_default_99 = torch.ops.aten.relu.default(getitem_519)
        convolution_default_313 = torch.ops.aten.convolution.default(relu_default_99, primals_176, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_314 = torch.ops.aten.convolution.default(convolution_default_313, primals_177, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_170 = torch.ops.aten.native_batch_norm.default(convolution_default_314, primals_170, primals_166, primals_168, primals_169, True, 0.1, 0.001);  primals_166 = None
        getitem_522 = native_batch_norm_default_170[0]
        getitem_523 = native_batch_norm_default_170[1]
        getitem_524 = native_batch_norm_default_170[2];  native_batch_norm_default_170 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_522);  getitem_522 = None
        convolution_default_315 = torch.ops.aten.convolution.default(relu__default_70, primals_178, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_316 = torch.ops.aten.convolution.default(convolution_default_315, primals_179, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_171 = torch.ops.aten.native_batch_norm.default(convolution_default_316, primals_175, primals_171, primals_173, primals_174, True, 0.1, 0.001);  primals_171 = None
        getitem_525 = native_batch_norm_default_171[0]
        getitem_526 = native_batch_norm_default_171[1]
        getitem_527 = native_batch_norm_default_171[2];  native_batch_norm_default_171 = None
        relu_default_100 = torch.ops.aten.relu.default(getitem_516)
        convolution_default_317 = torch.ops.aten.convolution.default(relu_default_100, primals_190, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_318 = torch.ops.aten.convolution.default(convolution_default_317, primals_191, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_172 = torch.ops.aten.native_batch_norm.default(convolution_default_318, primals_184, primals_180, primals_182, primals_183, True, 0.1, 0.001);  primals_180 = None
        getitem_528 = native_batch_norm_default_172[0]
        getitem_529 = native_batch_norm_default_172[1]
        getitem_530 = native_batch_norm_default_172[2];  native_batch_norm_default_172 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_528);  getitem_528 = None
        convolution_default_319 = torch.ops.aten.convolution.default(relu__default_71, primals_192, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_320 = torch.ops.aten.convolution.default(convolution_default_319, primals_193, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_173 = torch.ops.aten.native_batch_norm.default(convolution_default_320, primals_189, primals_185, primals_187, primals_188, True, 0.1, 0.001);  primals_185 = None
        getitem_531 = native_batch_norm_default_173[0]
        getitem_532 = native_batch_norm_default_173[1]
        getitem_533 = native_batch_norm_default_173[2];  native_batch_norm_default_173 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(getitem_525, getitem_531);  getitem_525 = getitem_531 = None
        relu_default_101 = torch.ops.aten.relu.default(getitem_516)
        convolution_default_321 = torch.ops.aten.convolution.default(relu_default_101, primals_204, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_322 = torch.ops.aten.convolution.default(convolution_default_321, primals_205, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_174 = torch.ops.aten.native_batch_norm.default(convolution_default_322, primals_198, primals_194, primals_196, primals_197, True, 0.1, 0.001);  primals_194 = None
        getitem_534 = native_batch_norm_default_174[0]
        getitem_535 = native_batch_norm_default_174[1]
        getitem_536 = native_batch_norm_default_174[2];  native_batch_norm_default_174 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_534);  getitem_534 = None
        convolution_default_323 = torch.ops.aten.convolution.default(relu__default_72, primals_206, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        convolution_default_324 = torch.ops.aten.convolution.default(convolution_default_323, primals_207, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_175 = torch.ops.aten.native_batch_norm.default(convolution_default_324, primals_203, primals_199, primals_201, primals_202, True, 0.1, 0.001);  primals_199 = None
        getitem_537 = native_batch_norm_default_175[0]
        getitem_538 = native_batch_norm_default_175[1]
        getitem_539 = native_batch_norm_default_175[2];  native_batch_norm_default_175 = None
        relu_default_102 = torch.ops.aten.relu.default(getitem_516)
        convolution_default_325 = torch.ops.aten.convolution.default(relu_default_102, primals_218, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_326 = torch.ops.aten.convolution.default(convolution_default_325, primals_219, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_176 = torch.ops.aten.native_batch_norm.default(convolution_default_326, primals_212, primals_208, primals_210, primals_211, True, 0.1, 0.001);  primals_208 = None
        getitem_540 = native_batch_norm_default_176[0]
        getitem_541 = native_batch_norm_default_176[1]
        getitem_542 = native_batch_norm_default_176[2];  native_batch_norm_default_176 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_540);  getitem_540 = None
        convolution_default_327 = torch.ops.aten.convolution.default(relu__default_73, primals_220, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_328 = torch.ops.aten.convolution.default(convolution_default_327, primals_221, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_177 = torch.ops.aten.native_batch_norm.default(convolution_default_328, primals_217, primals_213, primals_215, primals_216, True, 0.1, 0.001);  primals_213 = None
        getitem_543 = native_batch_norm_default_177[0]
        getitem_544 = native_batch_norm_default_177[1]
        getitem_545 = native_batch_norm_default_177[2];  native_batch_norm_default_177 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(getitem_537, getitem_543);  getitem_537 = getitem_543 = None
        avg_pool2d_default_45 = torch.ops.aten.avg_pool2d.default(getitem_519, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_73 = torch.ops.aten.add.Tensor(avg_pool2d_default_45, getitem_516);  avg_pool2d_default_45 = None
        avg_pool2d_default_46 = torch.ops.aten.avg_pool2d.default(getitem_516, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_47 = torch.ops.aten.avg_pool2d.default(getitem_516, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_74 = torch.ops.aten.add.Tensor(avg_pool2d_default_46, avg_pool2d_default_47);  avg_pool2d_default_46 = avg_pool2d_default_47 = None
        relu_default_103 = torch.ops.aten.relu.default(getitem_519)
        convolution_default_329 = torch.ops.aten.convolution.default(relu_default_103, primals_232, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_330 = torch.ops.aten.convolution.default(convolution_default_329, primals_233, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_178 = torch.ops.aten.native_batch_norm.default(convolution_default_330, primals_226, primals_222, primals_224, primals_225, True, 0.1, 0.001);  primals_222 = None
        getitem_546 = native_batch_norm_default_178[0]
        getitem_547 = native_batch_norm_default_178[1]
        getitem_548 = native_batch_norm_default_178[2];  native_batch_norm_default_178 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_546);  getitem_546 = None
        convolution_default_331 = torch.ops.aten.convolution.default(relu__default_74, primals_234, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 336)
        convolution_default_332 = torch.ops.aten.convolution.default(convolution_default_331, primals_235, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_179 = torch.ops.aten.native_batch_norm.default(convolution_default_332, primals_231, primals_227, primals_229, primals_230, True, 0.1, 0.001);  primals_227 = None
        getitem_549 = native_batch_norm_default_179[0]
        getitem_550 = native_batch_norm_default_179[1]
        getitem_551 = native_batch_norm_default_179[2];  native_batch_norm_default_179 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(getitem_549, getitem_519);  getitem_549 = None
        cat_default_17 = torch.ops.aten.cat.default([getitem_516, add_tensor_71, add_tensor_72, add_tensor_73, add_tensor_74, add_tensor_75], 1);  add_tensor_71 = add_tensor_72 = add_tensor_73 = add_tensor_74 = add_tensor_75 = None
        relu_default_104 = torch.ops.aten.relu.default(cat_default_16)
        convolution_default_333 = torch.ops.aten.convolution.default(relu_default_104, primals_1805, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_180 = torch.ops.aten.native_batch_norm.default(convolution_default_333, primals_1804, primals_1800, primals_1802, primals_1803, True, 0.1, 0.001);  primals_1800 = None
        getitem_552 = native_batch_norm_default_180[0]
        getitem_553 = native_batch_norm_default_180[1]
        getitem_554 = native_batch_norm_default_180[2];  native_batch_norm_default_180 = None
        relu_default_105 = torch.ops.aten.relu.default(cat_default_17);  cat_default_17 = None
        convolution_default_334 = torch.ops.aten.convolution.default(relu_default_105, primals_1799, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_181 = torch.ops.aten.native_batch_norm.default(convolution_default_334, primals_1798, primals_1794, primals_1796, primals_1797, True, 0.1, 0.001);  primals_1794 = None
        getitem_555 = native_batch_norm_default_181[0]
        getitem_556 = native_batch_norm_default_181[1]
        getitem_557 = native_batch_norm_default_181[2];  native_batch_norm_default_181 = None
        relu_default_106 = torch.ops.aten.relu.default(getitem_555)
        constant_pad_nd_default_24 = torch.ops.aten.constant_pad_nd.default(relu_default_106, [2, 2, 2, 2], 0.0)
        convolution_default_335 = torch.ops.aten.convolution.default(constant_pad_nd_default_24, primals_1734, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 672)
        convolution_default_336 = torch.ops.aten.convolution.default(convolution_default_335, primals_1735, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_182 = torch.ops.aten.native_batch_norm.default(convolution_default_336, primals_1728, primals_1724, primals_1726, primals_1727, True, 0.1, 0.001);  primals_1724 = None
        getitem_558 = native_batch_norm_default_182[0]
        getitem_559 = native_batch_norm_default_182[1]
        getitem_560 = native_batch_norm_default_182[2];  native_batch_norm_default_182 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_558);  getitem_558 = None
        convolution_default_337 = torch.ops.aten.convolution.default(relu__default_75, primals_1736, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_338 = torch.ops.aten.convolution.default(convolution_default_337, primals_1737, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_183 = torch.ops.aten.native_batch_norm.default(convolution_default_338, primals_1733, primals_1729, primals_1731, primals_1732, True, 0.1, 0.001);  primals_1729 = None
        getitem_561 = native_batch_norm_default_183[0]
        getitem_562 = native_batch_norm_default_183[1]
        getitem_563 = native_batch_norm_default_183[2];  native_batch_norm_default_183 = None
        relu_default_107 = torch.ops.aten.relu.default(getitem_552)
        constant_pad_nd_default_25 = torch.ops.aten.constant_pad_nd.default(relu_default_107, [3, 3, 3, 3], 0.0)
        convolution_default_339 = torch.ops.aten.convolution.default(constant_pad_nd_default_25, primals_1748, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 672)
        convolution_default_340 = torch.ops.aten.convolution.default(convolution_default_339, primals_1749, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_184 = torch.ops.aten.native_batch_norm.default(convolution_default_340, primals_1742, primals_1738, primals_1740, primals_1741, True, 0.1, 0.001);  primals_1738 = None
        getitem_564 = native_batch_norm_default_184[0]
        getitem_565 = native_batch_norm_default_184[1]
        getitem_566 = native_batch_norm_default_184[2];  native_batch_norm_default_184 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_564);  getitem_564 = None
        convolution_default_341 = torch.ops.aten.convolution.default(relu__default_76, primals_1750, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 672)
        convolution_default_342 = torch.ops.aten.convolution.default(convolution_default_341, primals_1751, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_185 = torch.ops.aten.native_batch_norm.default(convolution_default_342, primals_1747, primals_1743, primals_1745, primals_1746, True, 0.1, 0.001);  primals_1743 = None
        getitem_567 = native_batch_norm_default_185[0]
        getitem_568 = native_batch_norm_default_185[1]
        getitem_569 = native_batch_norm_default_185[2];  native_batch_norm_default_185 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(getitem_561, getitem_567);  getitem_561 = getitem_567 = None
        constant_pad_nd_default_26 = torch.ops.aten.constant_pad_nd.default(getitem_555, [1, 1, 1, 1], -inf)
        max_pool2d_with_indices_default_6 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_26, [3, 3], [2, 2])
        getitem_570 = max_pool2d_with_indices_default_6[0]
        getitem_571 = max_pool2d_with_indices_default_6[1];  max_pool2d_with_indices_default_6 = None
        relu_default_108 = torch.ops.aten.relu.default(getitem_552)
        constant_pad_nd_default_27 = torch.ops.aten.constant_pad_nd.default(relu_default_108, [3, 3, 3, 3], 0.0)
        convolution_default_343 = torch.ops.aten.convolution.default(constant_pad_nd_default_27, primals_1762, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 672)
        convolution_default_344 = torch.ops.aten.convolution.default(convolution_default_343, primals_1763, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_186 = torch.ops.aten.native_batch_norm.default(convolution_default_344, primals_1756, primals_1752, primals_1754, primals_1755, True, 0.1, 0.001);  primals_1752 = None
        getitem_572 = native_batch_norm_default_186[0]
        getitem_573 = native_batch_norm_default_186[1]
        getitem_574 = native_batch_norm_default_186[2];  native_batch_norm_default_186 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_572);  getitem_572 = None
        convolution_default_345 = torch.ops.aten.convolution.default(relu__default_77, primals_1764, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 672)
        convolution_default_346 = torch.ops.aten.convolution.default(convolution_default_345, primals_1765, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_187 = torch.ops.aten.native_batch_norm.default(convolution_default_346, primals_1761, primals_1757, primals_1759, primals_1760, True, 0.1, 0.001);  primals_1757 = None
        getitem_575 = native_batch_norm_default_187[0]
        getitem_576 = native_batch_norm_default_187[1]
        getitem_577 = native_batch_norm_default_187[2];  native_batch_norm_default_187 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(getitem_570, getitem_575);  getitem_570 = getitem_575 = None
        constant_pad_nd_default_28 = torch.ops.aten.constant_pad_nd.default(getitem_555, [1, 1, 1, 1], 0.0)
        avg_pool2d_default_48 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_28, [3, 3], [2, 2], [0, 0], False, False)
        relu_default_109 = torch.ops.aten.relu.default(getitem_552);  getitem_552 = None
        constant_pad_nd_default_29 = torch.ops.aten.constant_pad_nd.default(relu_default_109, [2, 2, 2, 2], 0.0)
        convolution_default_347 = torch.ops.aten.convolution.default(constant_pad_nd_default_29, primals_1776, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 672)
        convolution_default_348 = torch.ops.aten.convolution.default(convolution_default_347, primals_1777, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_188 = torch.ops.aten.native_batch_norm.default(convolution_default_348, primals_1770, primals_1766, primals_1768, primals_1769, True, 0.1, 0.001);  primals_1766 = None
        getitem_578 = native_batch_norm_default_188[0]
        getitem_579 = native_batch_norm_default_188[1]
        getitem_580 = native_batch_norm_default_188[2];  native_batch_norm_default_188 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_578);  getitem_578 = None
        convolution_default_349 = torch.ops.aten.convolution.default(relu__default_78, primals_1778, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_350 = torch.ops.aten.convolution.default(convolution_default_349, primals_1779, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_189 = torch.ops.aten.native_batch_norm.default(convolution_default_350, primals_1775, primals_1771, primals_1773, primals_1774, True, 0.1, 0.001);  primals_1771 = None
        getitem_581 = native_batch_norm_default_189[0]
        getitem_582 = native_batch_norm_default_189[1]
        getitem_583 = native_batch_norm_default_189[2];  native_batch_norm_default_189 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(avg_pool2d_default_48, getitem_581);  avg_pool2d_default_48 = getitem_581 = None
        avg_pool2d_default_49 = torch.ops.aten.avg_pool2d.default(add_tensor_76, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_79 = torch.ops.aten.add.Tensor(avg_pool2d_default_49, add_tensor_77);  avg_pool2d_default_49 = None
        relu_default_110 = torch.ops.aten.relu.default(add_tensor_76)
        convolution_default_351 = torch.ops.aten.convolution.default(relu_default_110, primals_1790, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_352 = torch.ops.aten.convolution.default(convolution_default_351, primals_1791, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_190 = torch.ops.aten.native_batch_norm.default(convolution_default_352, primals_1784, primals_1780, primals_1782, primals_1783, True, 0.1, 0.001);  primals_1780 = None
        getitem_584 = native_batch_norm_default_190[0]
        getitem_585 = native_batch_norm_default_190[1]
        getitem_586 = native_batch_norm_default_190[2];  native_batch_norm_default_190 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_584);  getitem_584 = None
        convolution_default_353 = torch.ops.aten.convolution.default(relu__default_79, primals_1792, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_354 = torch.ops.aten.convolution.default(convolution_default_353, primals_1793, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_191 = torch.ops.aten.native_batch_norm.default(convolution_default_354, primals_1789, primals_1785, primals_1787, primals_1788, True, 0.1, 0.001);  primals_1785 = None
        getitem_587 = native_batch_norm_default_191[0]
        getitem_588 = native_batch_norm_default_191[1]
        getitem_589 = native_batch_norm_default_191[2];  native_batch_norm_default_191 = None
        constant_pad_nd_default_30 = torch.ops.aten.constant_pad_nd.default(getitem_555, [1, 1, 1, 1], -inf);  getitem_555 = None
        max_pool2d_with_indices_default_7 = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default_30, [3, 3], [2, 2])
        getitem_590 = max_pool2d_with_indices_default_7[0]
        getitem_591 = max_pool2d_with_indices_default_7[1];  max_pool2d_with_indices_default_7 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_587, getitem_590);  getitem_587 = getitem_590 = None
        cat_default_18 = torch.ops.aten.cat.default([add_tensor_77, add_tensor_78, add_tensor_79, add_tensor_80], 1);  add_tensor_77 = add_tensor_78 = add_tensor_79 = add_tensor_80 = None
        relu_default_111 = torch.ops.aten.relu.default(cat_default_16);  cat_default_16 = None
        avg_pool2d_default_50 = torch.ops.aten.avg_pool2d.default(relu_default_111, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_355 = torch.ops.aten.convolution.default(avg_pool2d_default_50, primals_329, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default_31 = torch.ops.aten.constant_pad_nd.default(relu_default_111, [-1, 1, -1, 1], 0.0)
        avg_pool2d_default_51 = torch.ops.aten.avg_pool2d.default(constant_pad_nd_default_31, [1, 1], [2, 2], [0, 0], False, False)
        convolution_default_356 = torch.ops.aten.convolution.default(avg_pool2d_default_51, primals_330, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_19 = torch.ops.aten.cat.default([convolution_default_355, convolution_default_356], 1);  convolution_default_355 = convolution_default_356 = None
        native_batch_norm_default_192 = torch.ops.aten.native_batch_norm.default(cat_default_19, primals_328, primals_324, primals_326, primals_327, True, 0.1, 0.001);  primals_324 = None
        getitem_592 = native_batch_norm_default_192[0]
        getitem_593 = native_batch_norm_default_192[1]
        getitem_594 = native_batch_norm_default_192[2];  native_batch_norm_default_192 = None
        relu_default_112 = torch.ops.aten.relu.default(cat_default_18)
        convolution_default_357 = torch.ops.aten.convolution.default(relu_default_112, primals_323, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_193 = torch.ops.aten.native_batch_norm.default(convolution_default_357, primals_322, primals_318, primals_320, primals_321, True, 0.1, 0.001);  primals_318 = None
        getitem_595 = native_batch_norm_default_193[0]
        getitem_596 = native_batch_norm_default_193[1]
        getitem_597 = native_batch_norm_default_193[2];  native_batch_norm_default_193 = None
        relu_default_113 = torch.ops.aten.relu.default(getitem_595)
        convolution_default_358 = torch.ops.aten.convolution.default(relu_default_113, primals_258, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_359 = torch.ops.aten.convolution.default(convolution_default_358, primals_259, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_194 = torch.ops.aten.native_batch_norm.default(convolution_default_359, primals_252, primals_248, primals_250, primals_251, True, 0.1, 0.001);  primals_248 = None
        getitem_598 = native_batch_norm_default_194[0]
        getitem_599 = native_batch_norm_default_194[1]
        getitem_600 = native_batch_norm_default_194[2];  native_batch_norm_default_194 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_598);  getitem_598 = None
        convolution_default_360 = torch.ops.aten.convolution.default(relu__default_80, primals_260, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_361 = torch.ops.aten.convolution.default(convolution_default_360, primals_261, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_195 = torch.ops.aten.native_batch_norm.default(convolution_default_361, primals_257, primals_253, primals_255, primals_256, True, 0.1, 0.001);  primals_253 = None
        getitem_601 = native_batch_norm_default_195[0]
        getitem_602 = native_batch_norm_default_195[1]
        getitem_603 = native_batch_norm_default_195[2];  native_batch_norm_default_195 = None
        relu_default_114 = torch.ops.aten.relu.default(getitem_592)
        convolution_default_362 = torch.ops.aten.convolution.default(relu_default_114, primals_272, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_363 = torch.ops.aten.convolution.default(convolution_default_362, primals_273, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_196 = torch.ops.aten.native_batch_norm.default(convolution_default_363, primals_266, primals_262, primals_264, primals_265, True, 0.1, 0.001);  primals_262 = None
        getitem_604 = native_batch_norm_default_196[0]
        getitem_605 = native_batch_norm_default_196[1]
        getitem_606 = native_batch_norm_default_196[2];  native_batch_norm_default_196 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_604);  getitem_604 = None
        convolution_default_364 = torch.ops.aten.convolution.default(relu__default_81, primals_274, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_365 = torch.ops.aten.convolution.default(convolution_default_364, primals_275, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_197 = torch.ops.aten.native_batch_norm.default(convolution_default_365, primals_271, primals_267, primals_269, primals_270, True, 0.1, 0.001);  primals_267 = None
        getitem_607 = native_batch_norm_default_197[0]
        getitem_608 = native_batch_norm_default_197[1]
        getitem_609 = native_batch_norm_default_197[2];  native_batch_norm_default_197 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(getitem_601, getitem_607);  getitem_601 = getitem_607 = None
        relu_default_115 = torch.ops.aten.relu.default(getitem_592)
        convolution_default_366 = torch.ops.aten.convolution.default(relu_default_115, primals_286, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_367 = torch.ops.aten.convolution.default(convolution_default_366, primals_287, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_198 = torch.ops.aten.native_batch_norm.default(convolution_default_367, primals_280, primals_276, primals_278, primals_279, True, 0.1, 0.001);  primals_276 = None
        getitem_610 = native_batch_norm_default_198[0]
        getitem_611 = native_batch_norm_default_198[1]
        getitem_612 = native_batch_norm_default_198[2];  native_batch_norm_default_198 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_610);  getitem_610 = None
        convolution_default_368 = torch.ops.aten.convolution.default(relu__default_82, primals_288, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_369 = torch.ops.aten.convolution.default(convolution_default_368, primals_289, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_199 = torch.ops.aten.native_batch_norm.default(convolution_default_369, primals_285, primals_281, primals_283, primals_284, True, 0.1, 0.001);  primals_281 = None
        getitem_613 = native_batch_norm_default_199[0]
        getitem_614 = native_batch_norm_default_199[1]
        getitem_615 = native_batch_norm_default_199[2];  native_batch_norm_default_199 = None
        relu_default_116 = torch.ops.aten.relu.default(getitem_592)
        convolution_default_370 = torch.ops.aten.convolution.default(relu_default_116, primals_300, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_371 = torch.ops.aten.convolution.default(convolution_default_370, primals_301, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_200 = torch.ops.aten.native_batch_norm.default(convolution_default_371, primals_294, primals_290, primals_292, primals_293, True, 0.1, 0.001);  primals_290 = None
        getitem_616 = native_batch_norm_default_200[0]
        getitem_617 = native_batch_norm_default_200[1]
        getitem_618 = native_batch_norm_default_200[2];  native_batch_norm_default_200 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_616);  getitem_616 = None
        convolution_default_372 = torch.ops.aten.convolution.default(relu__default_83, primals_302, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_373 = torch.ops.aten.convolution.default(convolution_default_372, primals_303, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_201 = torch.ops.aten.native_batch_norm.default(convolution_default_373, primals_299, primals_295, primals_297, primals_298, True, 0.1, 0.001);  primals_295 = None
        getitem_619 = native_batch_norm_default_201[0]
        getitem_620 = native_batch_norm_default_201[1]
        getitem_621 = native_batch_norm_default_201[2];  native_batch_norm_default_201 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(getitem_613, getitem_619);  getitem_613 = getitem_619 = None
        avg_pool2d_default_52 = torch.ops.aten.avg_pool2d.default(getitem_595, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_83 = torch.ops.aten.add.Tensor(avg_pool2d_default_52, getitem_592);  avg_pool2d_default_52 = None
        avg_pool2d_default_53 = torch.ops.aten.avg_pool2d.default(getitem_592, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_54 = torch.ops.aten.avg_pool2d.default(getitem_592, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_84 = torch.ops.aten.add.Tensor(avg_pool2d_default_53, avg_pool2d_default_54);  avg_pool2d_default_53 = avg_pool2d_default_54 = None
        relu_default_117 = torch.ops.aten.relu.default(getitem_595)
        convolution_default_374 = torch.ops.aten.convolution.default(relu_default_117, primals_314, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_375 = torch.ops.aten.convolution.default(convolution_default_374, primals_315, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_202 = torch.ops.aten.native_batch_norm.default(convolution_default_375, primals_308, primals_304, primals_306, primals_307, True, 0.1, 0.001);  primals_304 = None
        getitem_622 = native_batch_norm_default_202[0]
        getitem_623 = native_batch_norm_default_202[1]
        getitem_624 = native_batch_norm_default_202[2];  native_batch_norm_default_202 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_622);  getitem_622 = None
        convolution_default_376 = torch.ops.aten.convolution.default(relu__default_84, primals_316, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_377 = torch.ops.aten.convolution.default(convolution_default_376, primals_317, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_203 = torch.ops.aten.native_batch_norm.default(convolution_default_377, primals_313, primals_309, primals_311, primals_312, True, 0.1, 0.001);  primals_309 = None
        getitem_625 = native_batch_norm_default_203[0]
        getitem_626 = native_batch_norm_default_203[1]
        getitem_627 = native_batch_norm_default_203[2];  native_batch_norm_default_203 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(getitem_625, getitem_595);  getitem_625 = None
        cat_default_20 = torch.ops.aten.cat.default([getitem_592, add_tensor_81, add_tensor_82, add_tensor_83, add_tensor_84, add_tensor_85], 1);  add_tensor_81 = add_tensor_82 = add_tensor_83 = add_tensor_84 = add_tensor_85 = None
        relu_default_118 = torch.ops.aten.relu.default(cat_default_18);  cat_default_18 = None
        convolution_default_378 = torch.ops.aten.convolution.default(relu_default_118, primals_412, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_204 = torch.ops.aten.native_batch_norm.default(convolution_default_378, primals_411, primals_407, primals_409, primals_410, True, 0.1, 0.001);  primals_407 = None
        getitem_628 = native_batch_norm_default_204[0]
        getitem_629 = native_batch_norm_default_204[1]
        getitem_630 = native_batch_norm_default_204[2];  native_batch_norm_default_204 = None
        relu_default_119 = torch.ops.aten.relu.default(cat_default_20)
        convolution_default_379 = torch.ops.aten.convolution.default(relu_default_119, primals_406, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_205 = torch.ops.aten.native_batch_norm.default(convolution_default_379, primals_405, primals_401, primals_403, primals_404, True, 0.1, 0.001);  primals_401 = None
        getitem_631 = native_batch_norm_default_205[0]
        getitem_632 = native_batch_norm_default_205[1]
        getitem_633 = native_batch_norm_default_205[2];  native_batch_norm_default_205 = None
        relu_default_120 = torch.ops.aten.relu.default(getitem_631)
        convolution_default_380 = torch.ops.aten.convolution.default(relu_default_120, primals_341, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_381 = torch.ops.aten.convolution.default(convolution_default_380, primals_342, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_206 = torch.ops.aten.native_batch_norm.default(convolution_default_381, primals_335, primals_331, primals_333, primals_334, True, 0.1, 0.001);  primals_331 = None
        getitem_634 = native_batch_norm_default_206[0]
        getitem_635 = native_batch_norm_default_206[1]
        getitem_636 = native_batch_norm_default_206[2];  native_batch_norm_default_206 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_634);  getitem_634 = None
        convolution_default_382 = torch.ops.aten.convolution.default(relu__default_85, primals_343, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_383 = torch.ops.aten.convolution.default(convolution_default_382, primals_344, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_207 = torch.ops.aten.native_batch_norm.default(convolution_default_383, primals_340, primals_336, primals_338, primals_339, True, 0.1, 0.001);  primals_336 = None
        getitem_637 = native_batch_norm_default_207[0]
        getitem_638 = native_batch_norm_default_207[1]
        getitem_639 = native_batch_norm_default_207[2];  native_batch_norm_default_207 = None
        relu_default_121 = torch.ops.aten.relu.default(getitem_628)
        convolution_default_384 = torch.ops.aten.convolution.default(relu_default_121, primals_355, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_385 = torch.ops.aten.convolution.default(convolution_default_384, primals_356, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_208 = torch.ops.aten.native_batch_norm.default(convolution_default_385, primals_349, primals_345, primals_347, primals_348, True, 0.1, 0.001);  primals_345 = None
        getitem_640 = native_batch_norm_default_208[0]
        getitem_641 = native_batch_norm_default_208[1]
        getitem_642 = native_batch_norm_default_208[2];  native_batch_norm_default_208 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_640);  getitem_640 = None
        convolution_default_386 = torch.ops.aten.convolution.default(relu__default_86, primals_357, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_387 = torch.ops.aten.convolution.default(convolution_default_386, primals_358, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_209 = torch.ops.aten.native_batch_norm.default(convolution_default_387, primals_354, primals_350, primals_352, primals_353, True, 0.1, 0.001);  primals_350 = None
        getitem_643 = native_batch_norm_default_209[0]
        getitem_644 = native_batch_norm_default_209[1]
        getitem_645 = native_batch_norm_default_209[2];  native_batch_norm_default_209 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(getitem_637, getitem_643);  getitem_637 = getitem_643 = None
        relu_default_122 = torch.ops.aten.relu.default(getitem_628)
        convolution_default_388 = torch.ops.aten.convolution.default(relu_default_122, primals_369, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_389 = torch.ops.aten.convolution.default(convolution_default_388, primals_370, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_210 = torch.ops.aten.native_batch_norm.default(convolution_default_389, primals_363, primals_359, primals_361, primals_362, True, 0.1, 0.001);  primals_359 = None
        getitem_646 = native_batch_norm_default_210[0]
        getitem_647 = native_batch_norm_default_210[1]
        getitem_648 = native_batch_norm_default_210[2];  native_batch_norm_default_210 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_646);  getitem_646 = None
        convolution_default_390 = torch.ops.aten.convolution.default(relu__default_87, primals_371, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_391 = torch.ops.aten.convolution.default(convolution_default_390, primals_372, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_211 = torch.ops.aten.native_batch_norm.default(convolution_default_391, primals_368, primals_364, primals_366, primals_367, True, 0.1, 0.001);  primals_364 = None
        getitem_649 = native_batch_norm_default_211[0]
        getitem_650 = native_batch_norm_default_211[1]
        getitem_651 = native_batch_norm_default_211[2];  native_batch_norm_default_211 = None
        relu_default_123 = torch.ops.aten.relu.default(getitem_628)
        convolution_default_392 = torch.ops.aten.convolution.default(relu_default_123, primals_383, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_393 = torch.ops.aten.convolution.default(convolution_default_392, primals_384, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_212 = torch.ops.aten.native_batch_norm.default(convolution_default_393, primals_377, primals_373, primals_375, primals_376, True, 0.1, 0.001);  primals_373 = None
        getitem_652 = native_batch_norm_default_212[0]
        getitem_653 = native_batch_norm_default_212[1]
        getitem_654 = native_batch_norm_default_212[2];  native_batch_norm_default_212 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_652);  getitem_652 = None
        convolution_default_394 = torch.ops.aten.convolution.default(relu__default_88, primals_385, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_395 = torch.ops.aten.convolution.default(convolution_default_394, primals_386, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_213 = torch.ops.aten.native_batch_norm.default(convolution_default_395, primals_382, primals_378, primals_380, primals_381, True, 0.1, 0.001);  primals_378 = None
        getitem_655 = native_batch_norm_default_213[0]
        getitem_656 = native_batch_norm_default_213[1]
        getitem_657 = native_batch_norm_default_213[2];  native_batch_norm_default_213 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(getitem_649, getitem_655);  getitem_649 = getitem_655 = None
        avg_pool2d_default_55 = torch.ops.aten.avg_pool2d.default(getitem_631, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_88 = torch.ops.aten.add.Tensor(avg_pool2d_default_55, getitem_628);  avg_pool2d_default_55 = None
        avg_pool2d_default_56 = torch.ops.aten.avg_pool2d.default(getitem_628, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_57 = torch.ops.aten.avg_pool2d.default(getitem_628, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_89 = torch.ops.aten.add.Tensor(avg_pool2d_default_56, avg_pool2d_default_57);  avg_pool2d_default_56 = avg_pool2d_default_57 = None
        relu_default_124 = torch.ops.aten.relu.default(getitem_631)
        convolution_default_396 = torch.ops.aten.convolution.default(relu_default_124, primals_397, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_397 = torch.ops.aten.convolution.default(convolution_default_396, primals_398, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_214 = torch.ops.aten.native_batch_norm.default(convolution_default_397, primals_391, primals_387, primals_389, primals_390, True, 0.1, 0.001);  primals_387 = None
        getitem_658 = native_batch_norm_default_214[0]
        getitem_659 = native_batch_norm_default_214[1]
        getitem_660 = native_batch_norm_default_214[2];  native_batch_norm_default_214 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_658);  getitem_658 = None
        convolution_default_398 = torch.ops.aten.convolution.default(relu__default_89, primals_399, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_399 = torch.ops.aten.convolution.default(convolution_default_398, primals_400, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_215 = torch.ops.aten.native_batch_norm.default(convolution_default_399, primals_396, primals_392, primals_394, primals_395, True, 0.1, 0.001);  primals_392 = None
        getitem_661 = native_batch_norm_default_215[0]
        getitem_662 = native_batch_norm_default_215[1]
        getitem_663 = native_batch_norm_default_215[2];  native_batch_norm_default_215 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(getitem_661, getitem_631);  getitem_661 = None
        cat_default_21 = torch.ops.aten.cat.default([getitem_628, add_tensor_86, add_tensor_87, add_tensor_88, add_tensor_89, add_tensor_90], 1);  add_tensor_86 = add_tensor_87 = add_tensor_88 = add_tensor_89 = add_tensor_90 = None
        relu_default_125 = torch.ops.aten.relu.default(cat_default_20);  cat_default_20 = None
        convolution_default_400 = torch.ops.aten.convolution.default(relu_default_125, primals_494, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_216 = torch.ops.aten.native_batch_norm.default(convolution_default_400, primals_493, primals_489, primals_491, primals_492, True, 0.1, 0.001);  primals_489 = None
        getitem_664 = native_batch_norm_default_216[0]
        getitem_665 = native_batch_norm_default_216[1]
        getitem_666 = native_batch_norm_default_216[2];  native_batch_norm_default_216 = None
        relu_default_126 = torch.ops.aten.relu.default(cat_default_21)
        convolution_default_401 = torch.ops.aten.convolution.default(relu_default_126, primals_488, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_217 = torch.ops.aten.native_batch_norm.default(convolution_default_401, primals_487, primals_483, primals_485, primals_486, True, 0.1, 0.001);  primals_483 = None
        getitem_667 = native_batch_norm_default_217[0]
        getitem_668 = native_batch_norm_default_217[1]
        getitem_669 = native_batch_norm_default_217[2];  native_batch_norm_default_217 = None
        relu_default_127 = torch.ops.aten.relu.default(getitem_667)
        convolution_default_402 = torch.ops.aten.convolution.default(relu_default_127, primals_423, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_403 = torch.ops.aten.convolution.default(convolution_default_402, primals_424, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_218 = torch.ops.aten.native_batch_norm.default(convolution_default_403, primals_417, primals_413, primals_415, primals_416, True, 0.1, 0.001);  primals_413 = None
        getitem_670 = native_batch_norm_default_218[0]
        getitem_671 = native_batch_norm_default_218[1]
        getitem_672 = native_batch_norm_default_218[2];  native_batch_norm_default_218 = None
        relu__default_90 = torch.ops.aten.relu_.default(getitem_670);  getitem_670 = None
        convolution_default_404 = torch.ops.aten.convolution.default(relu__default_90, primals_425, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_405 = torch.ops.aten.convolution.default(convolution_default_404, primals_426, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_219 = torch.ops.aten.native_batch_norm.default(convolution_default_405, primals_422, primals_418, primals_420, primals_421, True, 0.1, 0.001);  primals_418 = None
        getitem_673 = native_batch_norm_default_219[0]
        getitem_674 = native_batch_norm_default_219[1]
        getitem_675 = native_batch_norm_default_219[2];  native_batch_norm_default_219 = None
        relu_default_128 = torch.ops.aten.relu.default(getitem_664)
        convolution_default_406 = torch.ops.aten.convolution.default(relu_default_128, primals_437, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_407 = torch.ops.aten.convolution.default(convolution_default_406, primals_438, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_220 = torch.ops.aten.native_batch_norm.default(convolution_default_407, primals_431, primals_427, primals_429, primals_430, True, 0.1, 0.001);  primals_427 = None
        getitem_676 = native_batch_norm_default_220[0]
        getitem_677 = native_batch_norm_default_220[1]
        getitem_678 = native_batch_norm_default_220[2];  native_batch_norm_default_220 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_676);  getitem_676 = None
        convolution_default_408 = torch.ops.aten.convolution.default(relu__default_91, primals_439, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_409 = torch.ops.aten.convolution.default(convolution_default_408, primals_440, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_221 = torch.ops.aten.native_batch_norm.default(convolution_default_409, primals_436, primals_432, primals_434, primals_435, True, 0.1, 0.001);  primals_432 = None
        getitem_679 = native_batch_norm_default_221[0]
        getitem_680 = native_batch_norm_default_221[1]
        getitem_681 = native_batch_norm_default_221[2];  native_batch_norm_default_221 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(getitem_673, getitem_679);  getitem_673 = getitem_679 = None
        relu_default_129 = torch.ops.aten.relu.default(getitem_664)
        convolution_default_410 = torch.ops.aten.convolution.default(relu_default_129, primals_451, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_411 = torch.ops.aten.convolution.default(convolution_default_410, primals_452, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_222 = torch.ops.aten.native_batch_norm.default(convolution_default_411, primals_445, primals_441, primals_443, primals_444, True, 0.1, 0.001);  primals_441 = None
        getitem_682 = native_batch_norm_default_222[0]
        getitem_683 = native_batch_norm_default_222[1]
        getitem_684 = native_batch_norm_default_222[2];  native_batch_norm_default_222 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_682);  getitem_682 = None
        convolution_default_412 = torch.ops.aten.convolution.default(relu__default_92, primals_453, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_413 = torch.ops.aten.convolution.default(convolution_default_412, primals_454, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_223 = torch.ops.aten.native_batch_norm.default(convolution_default_413, primals_450, primals_446, primals_448, primals_449, True, 0.1, 0.001);  primals_446 = None
        getitem_685 = native_batch_norm_default_223[0]
        getitem_686 = native_batch_norm_default_223[1]
        getitem_687 = native_batch_norm_default_223[2];  native_batch_norm_default_223 = None
        relu_default_130 = torch.ops.aten.relu.default(getitem_664)
        convolution_default_414 = torch.ops.aten.convolution.default(relu_default_130, primals_465, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_415 = torch.ops.aten.convolution.default(convolution_default_414, primals_466, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_224 = torch.ops.aten.native_batch_norm.default(convolution_default_415, primals_459, primals_455, primals_457, primals_458, True, 0.1, 0.001);  primals_455 = None
        getitem_688 = native_batch_norm_default_224[0]
        getitem_689 = native_batch_norm_default_224[1]
        getitem_690 = native_batch_norm_default_224[2];  native_batch_norm_default_224 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_688);  getitem_688 = None
        convolution_default_416 = torch.ops.aten.convolution.default(relu__default_93, primals_467, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_417 = torch.ops.aten.convolution.default(convolution_default_416, primals_468, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_225 = torch.ops.aten.native_batch_norm.default(convolution_default_417, primals_464, primals_460, primals_462, primals_463, True, 0.1, 0.001);  primals_460 = None
        getitem_691 = native_batch_norm_default_225[0]
        getitem_692 = native_batch_norm_default_225[1]
        getitem_693 = native_batch_norm_default_225[2];  native_batch_norm_default_225 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_685, getitem_691);  getitem_685 = getitem_691 = None
        avg_pool2d_default_58 = torch.ops.aten.avg_pool2d.default(getitem_667, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_93 = torch.ops.aten.add.Tensor(avg_pool2d_default_58, getitem_664);  avg_pool2d_default_58 = None
        avg_pool2d_default_59 = torch.ops.aten.avg_pool2d.default(getitem_664, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_60 = torch.ops.aten.avg_pool2d.default(getitem_664, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_94 = torch.ops.aten.add.Tensor(avg_pool2d_default_59, avg_pool2d_default_60);  avg_pool2d_default_59 = avg_pool2d_default_60 = None
        relu_default_131 = torch.ops.aten.relu.default(getitem_667)
        convolution_default_418 = torch.ops.aten.convolution.default(relu_default_131, primals_479, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_419 = torch.ops.aten.convolution.default(convolution_default_418, primals_480, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_226 = torch.ops.aten.native_batch_norm.default(convolution_default_419, primals_473, primals_469, primals_471, primals_472, True, 0.1, 0.001);  primals_469 = None
        getitem_694 = native_batch_norm_default_226[0]
        getitem_695 = native_batch_norm_default_226[1]
        getitem_696 = native_batch_norm_default_226[2];  native_batch_norm_default_226 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_694);  getitem_694 = None
        convolution_default_420 = torch.ops.aten.convolution.default(relu__default_94, primals_481, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_421 = torch.ops.aten.convolution.default(convolution_default_420, primals_482, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_227 = torch.ops.aten.native_batch_norm.default(convolution_default_421, primals_478, primals_474, primals_476, primals_477, True, 0.1, 0.001);  primals_474 = None
        getitem_697 = native_batch_norm_default_227[0]
        getitem_698 = native_batch_norm_default_227[1]
        getitem_699 = native_batch_norm_default_227[2];  native_batch_norm_default_227 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(getitem_697, getitem_667);  getitem_697 = None
        cat_default_22 = torch.ops.aten.cat.default([getitem_664, add_tensor_91, add_tensor_92, add_tensor_93, add_tensor_94, add_tensor_95], 1);  add_tensor_91 = add_tensor_92 = add_tensor_93 = add_tensor_94 = add_tensor_95 = None
        relu_default_132 = torch.ops.aten.relu.default(cat_default_21);  cat_default_21 = None
        convolution_default_422 = torch.ops.aten.convolution.default(relu_default_132, primals_576, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_228 = torch.ops.aten.native_batch_norm.default(convolution_default_422, primals_575, primals_571, primals_573, primals_574, True, 0.1, 0.001);  primals_571 = None
        getitem_700 = native_batch_norm_default_228[0]
        getitem_701 = native_batch_norm_default_228[1]
        getitem_702 = native_batch_norm_default_228[2];  native_batch_norm_default_228 = None
        relu_default_133 = torch.ops.aten.relu.default(cat_default_22)
        convolution_default_423 = torch.ops.aten.convolution.default(relu_default_133, primals_570, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_229 = torch.ops.aten.native_batch_norm.default(convolution_default_423, primals_569, primals_565, primals_567, primals_568, True, 0.1, 0.001);  primals_565 = None
        getitem_703 = native_batch_norm_default_229[0]
        getitem_704 = native_batch_norm_default_229[1]
        getitem_705 = native_batch_norm_default_229[2];  native_batch_norm_default_229 = None
        relu_default_134 = torch.ops.aten.relu.default(getitem_703)
        convolution_default_424 = torch.ops.aten.convolution.default(relu_default_134, primals_505, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_425 = torch.ops.aten.convolution.default(convolution_default_424, primals_506, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_230 = torch.ops.aten.native_batch_norm.default(convolution_default_425, primals_499, primals_495, primals_497, primals_498, True, 0.1, 0.001);  primals_495 = None
        getitem_706 = native_batch_norm_default_230[0]
        getitem_707 = native_batch_norm_default_230[1]
        getitem_708 = native_batch_norm_default_230[2];  native_batch_norm_default_230 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_706);  getitem_706 = None
        convolution_default_426 = torch.ops.aten.convolution.default(relu__default_95, primals_507, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_427 = torch.ops.aten.convolution.default(convolution_default_426, primals_508, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_231 = torch.ops.aten.native_batch_norm.default(convolution_default_427, primals_504, primals_500, primals_502, primals_503, True, 0.1, 0.001);  primals_500 = None
        getitem_709 = native_batch_norm_default_231[0]
        getitem_710 = native_batch_norm_default_231[1]
        getitem_711 = native_batch_norm_default_231[2];  native_batch_norm_default_231 = None
        relu_default_135 = torch.ops.aten.relu.default(getitem_700)
        convolution_default_428 = torch.ops.aten.convolution.default(relu_default_135, primals_519, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_429 = torch.ops.aten.convolution.default(convolution_default_428, primals_520, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_232 = torch.ops.aten.native_batch_norm.default(convolution_default_429, primals_513, primals_509, primals_511, primals_512, True, 0.1, 0.001);  primals_509 = None
        getitem_712 = native_batch_norm_default_232[0]
        getitem_713 = native_batch_norm_default_232[1]
        getitem_714 = native_batch_norm_default_232[2];  native_batch_norm_default_232 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_712);  getitem_712 = None
        convolution_default_430 = torch.ops.aten.convolution.default(relu__default_96, primals_521, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_431 = torch.ops.aten.convolution.default(convolution_default_430, primals_522, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_233 = torch.ops.aten.native_batch_norm.default(convolution_default_431, primals_518, primals_514, primals_516, primals_517, True, 0.1, 0.001);  primals_514 = None
        getitem_715 = native_batch_norm_default_233[0]
        getitem_716 = native_batch_norm_default_233[1]
        getitem_717 = native_batch_norm_default_233[2];  native_batch_norm_default_233 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(getitem_709, getitem_715);  getitem_709 = getitem_715 = None
        relu_default_136 = torch.ops.aten.relu.default(getitem_700)
        convolution_default_432 = torch.ops.aten.convolution.default(relu_default_136, primals_533, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_433 = torch.ops.aten.convolution.default(convolution_default_432, primals_534, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_234 = torch.ops.aten.native_batch_norm.default(convolution_default_433, primals_527, primals_523, primals_525, primals_526, True, 0.1, 0.001);  primals_523 = None
        getitem_718 = native_batch_norm_default_234[0]
        getitem_719 = native_batch_norm_default_234[1]
        getitem_720 = native_batch_norm_default_234[2];  native_batch_norm_default_234 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_718);  getitem_718 = None
        convolution_default_434 = torch.ops.aten.convolution.default(relu__default_97, primals_535, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_435 = torch.ops.aten.convolution.default(convolution_default_434, primals_536, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_235 = torch.ops.aten.native_batch_norm.default(convolution_default_435, primals_532, primals_528, primals_530, primals_531, True, 0.1, 0.001);  primals_528 = None
        getitem_721 = native_batch_norm_default_235[0]
        getitem_722 = native_batch_norm_default_235[1]
        getitem_723 = native_batch_norm_default_235[2];  native_batch_norm_default_235 = None
        relu_default_137 = torch.ops.aten.relu.default(getitem_700)
        convolution_default_436 = torch.ops.aten.convolution.default(relu_default_137, primals_547, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_437 = torch.ops.aten.convolution.default(convolution_default_436, primals_548, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_236 = torch.ops.aten.native_batch_norm.default(convolution_default_437, primals_541, primals_537, primals_539, primals_540, True, 0.1, 0.001);  primals_537 = None
        getitem_724 = native_batch_norm_default_236[0]
        getitem_725 = native_batch_norm_default_236[1]
        getitem_726 = native_batch_norm_default_236[2];  native_batch_norm_default_236 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_724);  getitem_724 = None
        convolution_default_438 = torch.ops.aten.convolution.default(relu__default_98, primals_549, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_439 = torch.ops.aten.convolution.default(convolution_default_438, primals_550, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_237 = torch.ops.aten.native_batch_norm.default(convolution_default_439, primals_546, primals_542, primals_544, primals_545, True, 0.1, 0.001);  primals_542 = None
        getitem_727 = native_batch_norm_default_237[0]
        getitem_728 = native_batch_norm_default_237[1]
        getitem_729 = native_batch_norm_default_237[2];  native_batch_norm_default_237 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(getitem_721, getitem_727);  getitem_721 = getitem_727 = None
        avg_pool2d_default_61 = torch.ops.aten.avg_pool2d.default(getitem_703, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_98 = torch.ops.aten.add.Tensor(avg_pool2d_default_61, getitem_700);  avg_pool2d_default_61 = None
        avg_pool2d_default_62 = torch.ops.aten.avg_pool2d.default(getitem_700, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_63 = torch.ops.aten.avg_pool2d.default(getitem_700, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_99 = torch.ops.aten.add.Tensor(avg_pool2d_default_62, avg_pool2d_default_63);  avg_pool2d_default_62 = avg_pool2d_default_63 = None
        relu_default_138 = torch.ops.aten.relu.default(getitem_703)
        convolution_default_440 = torch.ops.aten.convolution.default(relu_default_138, primals_561, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_441 = torch.ops.aten.convolution.default(convolution_default_440, primals_562, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_238 = torch.ops.aten.native_batch_norm.default(convolution_default_441, primals_555, primals_551, primals_553, primals_554, True, 0.1, 0.001);  primals_551 = None
        getitem_730 = native_batch_norm_default_238[0]
        getitem_731 = native_batch_norm_default_238[1]
        getitem_732 = native_batch_norm_default_238[2];  native_batch_norm_default_238 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_730);  getitem_730 = None
        convolution_default_442 = torch.ops.aten.convolution.default(relu__default_99, primals_563, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_443 = torch.ops.aten.convolution.default(convolution_default_442, primals_564, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_239 = torch.ops.aten.native_batch_norm.default(convolution_default_443, primals_560, primals_556, primals_558, primals_559, True, 0.1, 0.001);  primals_556 = None
        getitem_733 = native_batch_norm_default_239[0]
        getitem_734 = native_batch_norm_default_239[1]
        getitem_735 = native_batch_norm_default_239[2];  native_batch_norm_default_239 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(getitem_733, getitem_703);  getitem_733 = None
        cat_default_23 = torch.ops.aten.cat.default([getitem_700, add_tensor_96, add_tensor_97, add_tensor_98, add_tensor_99, add_tensor_100], 1);  add_tensor_96 = add_tensor_97 = add_tensor_98 = add_tensor_99 = add_tensor_100 = None
        relu_default_139 = torch.ops.aten.relu.default(cat_default_22);  cat_default_22 = None
        convolution_default_444 = torch.ops.aten.convolution.default(relu_default_139, primals_658, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_240 = torch.ops.aten.native_batch_norm.default(convolution_default_444, primals_657, primals_653, primals_655, primals_656, True, 0.1, 0.001);  primals_653 = None
        getitem_736 = native_batch_norm_default_240[0]
        getitem_737 = native_batch_norm_default_240[1]
        getitem_738 = native_batch_norm_default_240[2];  native_batch_norm_default_240 = None
        relu_default_140 = torch.ops.aten.relu.default(cat_default_23)
        convolution_default_445 = torch.ops.aten.convolution.default(relu_default_140, primals_652, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_241 = torch.ops.aten.native_batch_norm.default(convolution_default_445, primals_651, primals_647, primals_649, primals_650, True, 0.1, 0.001);  primals_647 = None
        getitem_739 = native_batch_norm_default_241[0]
        getitem_740 = native_batch_norm_default_241[1]
        getitem_741 = native_batch_norm_default_241[2];  native_batch_norm_default_241 = None
        relu_default_141 = torch.ops.aten.relu.default(getitem_739)
        convolution_default_446 = torch.ops.aten.convolution.default(relu_default_141, primals_587, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_447 = torch.ops.aten.convolution.default(convolution_default_446, primals_588, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_242 = torch.ops.aten.native_batch_norm.default(convolution_default_447, primals_581, primals_577, primals_579, primals_580, True, 0.1, 0.001);  primals_577 = None
        getitem_742 = native_batch_norm_default_242[0]
        getitem_743 = native_batch_norm_default_242[1]
        getitem_744 = native_batch_norm_default_242[2];  native_batch_norm_default_242 = None
        relu__default_100 = torch.ops.aten.relu_.default(getitem_742);  getitem_742 = None
        convolution_default_448 = torch.ops.aten.convolution.default(relu__default_100, primals_589, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_449 = torch.ops.aten.convolution.default(convolution_default_448, primals_590, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_243 = torch.ops.aten.native_batch_norm.default(convolution_default_449, primals_586, primals_582, primals_584, primals_585, True, 0.1, 0.001);  primals_582 = None
        getitem_745 = native_batch_norm_default_243[0]
        getitem_746 = native_batch_norm_default_243[1]
        getitem_747 = native_batch_norm_default_243[2];  native_batch_norm_default_243 = None
        relu_default_142 = torch.ops.aten.relu.default(getitem_736)
        convolution_default_450 = torch.ops.aten.convolution.default(relu_default_142, primals_601, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_451 = torch.ops.aten.convolution.default(convolution_default_450, primals_602, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_244 = torch.ops.aten.native_batch_norm.default(convolution_default_451, primals_595, primals_591, primals_593, primals_594, True, 0.1, 0.001);  primals_591 = None
        getitem_748 = native_batch_norm_default_244[0]
        getitem_749 = native_batch_norm_default_244[1]
        getitem_750 = native_batch_norm_default_244[2];  native_batch_norm_default_244 = None
        relu__default_101 = torch.ops.aten.relu_.default(getitem_748);  getitem_748 = None
        convolution_default_452 = torch.ops.aten.convolution.default(relu__default_101, primals_603, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_453 = torch.ops.aten.convolution.default(convolution_default_452, primals_604, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_245 = torch.ops.aten.native_batch_norm.default(convolution_default_453, primals_600, primals_596, primals_598, primals_599, True, 0.1, 0.001);  primals_596 = None
        getitem_751 = native_batch_norm_default_245[0]
        getitem_752 = native_batch_norm_default_245[1]
        getitem_753 = native_batch_norm_default_245[2];  native_batch_norm_default_245 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(getitem_745, getitem_751);  getitem_745 = getitem_751 = None
        relu_default_143 = torch.ops.aten.relu.default(getitem_736)
        convolution_default_454 = torch.ops.aten.convolution.default(relu_default_143, primals_615, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_455 = torch.ops.aten.convolution.default(convolution_default_454, primals_616, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_246 = torch.ops.aten.native_batch_norm.default(convolution_default_455, primals_609, primals_605, primals_607, primals_608, True, 0.1, 0.001);  primals_605 = None
        getitem_754 = native_batch_norm_default_246[0]
        getitem_755 = native_batch_norm_default_246[1]
        getitem_756 = native_batch_norm_default_246[2];  native_batch_norm_default_246 = None
        relu__default_102 = torch.ops.aten.relu_.default(getitem_754);  getitem_754 = None
        convolution_default_456 = torch.ops.aten.convolution.default(relu__default_102, primals_617, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_457 = torch.ops.aten.convolution.default(convolution_default_456, primals_618, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_247 = torch.ops.aten.native_batch_norm.default(convolution_default_457, primals_614, primals_610, primals_612, primals_613, True, 0.1, 0.001);  primals_610 = None
        getitem_757 = native_batch_norm_default_247[0]
        getitem_758 = native_batch_norm_default_247[1]
        getitem_759 = native_batch_norm_default_247[2];  native_batch_norm_default_247 = None
        relu_default_144 = torch.ops.aten.relu.default(getitem_736)
        convolution_default_458 = torch.ops.aten.convolution.default(relu_default_144, primals_629, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_459 = torch.ops.aten.convolution.default(convolution_default_458, primals_630, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_248 = torch.ops.aten.native_batch_norm.default(convolution_default_459, primals_623, primals_619, primals_621, primals_622, True, 0.1, 0.001);  primals_619 = None
        getitem_760 = native_batch_norm_default_248[0]
        getitem_761 = native_batch_norm_default_248[1]
        getitem_762 = native_batch_norm_default_248[2];  native_batch_norm_default_248 = None
        relu__default_103 = torch.ops.aten.relu_.default(getitem_760);  getitem_760 = None
        convolution_default_460 = torch.ops.aten.convolution.default(relu__default_103, primals_631, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_461 = torch.ops.aten.convolution.default(convolution_default_460, primals_632, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_249 = torch.ops.aten.native_batch_norm.default(convolution_default_461, primals_628, primals_624, primals_626, primals_627, True, 0.1, 0.001);  primals_624 = None
        getitem_763 = native_batch_norm_default_249[0]
        getitem_764 = native_batch_norm_default_249[1]
        getitem_765 = native_batch_norm_default_249[2];  native_batch_norm_default_249 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(getitem_757, getitem_763);  getitem_757 = getitem_763 = None
        avg_pool2d_default_64 = torch.ops.aten.avg_pool2d.default(getitem_739, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_103 = torch.ops.aten.add.Tensor(avg_pool2d_default_64, getitem_736);  avg_pool2d_default_64 = None
        avg_pool2d_default_65 = torch.ops.aten.avg_pool2d.default(getitem_736, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_66 = torch.ops.aten.avg_pool2d.default(getitem_736, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_104 = torch.ops.aten.add.Tensor(avg_pool2d_default_65, avg_pool2d_default_66);  avg_pool2d_default_65 = avg_pool2d_default_66 = None
        relu_default_145 = torch.ops.aten.relu.default(getitem_739)
        convolution_default_462 = torch.ops.aten.convolution.default(relu_default_145, primals_643, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_463 = torch.ops.aten.convolution.default(convolution_default_462, primals_644, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_250 = torch.ops.aten.native_batch_norm.default(convolution_default_463, primals_637, primals_633, primals_635, primals_636, True, 0.1, 0.001);  primals_633 = None
        getitem_766 = native_batch_norm_default_250[0]
        getitem_767 = native_batch_norm_default_250[1]
        getitem_768 = native_batch_norm_default_250[2];  native_batch_norm_default_250 = None
        relu__default_104 = torch.ops.aten.relu_.default(getitem_766);  getitem_766 = None
        convolution_default_464 = torch.ops.aten.convolution.default(relu__default_104, primals_645, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_465 = torch.ops.aten.convolution.default(convolution_default_464, primals_646, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_251 = torch.ops.aten.native_batch_norm.default(convolution_default_465, primals_642, primals_638, primals_640, primals_641, True, 0.1, 0.001);  primals_638 = None
        getitem_769 = native_batch_norm_default_251[0]
        getitem_770 = native_batch_norm_default_251[1]
        getitem_771 = native_batch_norm_default_251[2];  native_batch_norm_default_251 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(getitem_769, getitem_739);  getitem_769 = None
        cat_default_24 = torch.ops.aten.cat.default([getitem_736, add_tensor_101, add_tensor_102, add_tensor_103, add_tensor_104, add_tensor_105], 1);  add_tensor_101 = add_tensor_102 = add_tensor_103 = add_tensor_104 = add_tensor_105 = None
        relu_default_146 = torch.ops.aten.relu.default(cat_default_23);  cat_default_23 = None
        convolution_default_466 = torch.ops.aten.convolution.default(relu_default_146, primals_740, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_252 = torch.ops.aten.native_batch_norm.default(convolution_default_466, primals_739, primals_735, primals_737, primals_738, True, 0.1, 0.001);  primals_735 = None
        getitem_772 = native_batch_norm_default_252[0]
        getitem_773 = native_batch_norm_default_252[1]
        getitem_774 = native_batch_norm_default_252[2];  native_batch_norm_default_252 = None
        relu_default_147 = torch.ops.aten.relu.default(cat_default_24);  cat_default_24 = None
        convolution_default_467 = torch.ops.aten.convolution.default(relu_default_147, primals_734, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_253 = torch.ops.aten.native_batch_norm.default(convolution_default_467, primals_733, primals_729, primals_731, primals_732, True, 0.1, 0.001);  primals_729 = None
        getitem_775 = native_batch_norm_default_253[0]
        getitem_776 = native_batch_norm_default_253[1]
        getitem_777 = native_batch_norm_default_253[2];  native_batch_norm_default_253 = None
        relu_default_148 = torch.ops.aten.relu.default(getitem_775)
        convolution_default_468 = torch.ops.aten.convolution.default(relu_default_148, primals_669, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_469 = torch.ops.aten.convolution.default(convolution_default_468, primals_670, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_254 = torch.ops.aten.native_batch_norm.default(convolution_default_469, primals_663, primals_659, primals_661, primals_662, True, 0.1, 0.001);  primals_659 = None
        getitem_778 = native_batch_norm_default_254[0]
        getitem_779 = native_batch_norm_default_254[1]
        getitem_780 = native_batch_norm_default_254[2];  native_batch_norm_default_254 = None
        relu__default_105 = torch.ops.aten.relu_.default(getitem_778);  getitem_778 = None
        convolution_default_470 = torch.ops.aten.convolution.default(relu__default_105, primals_671, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_471 = torch.ops.aten.convolution.default(convolution_default_470, primals_672, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_255 = torch.ops.aten.native_batch_norm.default(convolution_default_471, primals_668, primals_664, primals_666, primals_667, True, 0.1, 0.001);  primals_664 = None
        getitem_781 = native_batch_norm_default_255[0]
        getitem_782 = native_batch_norm_default_255[1]
        getitem_783 = native_batch_norm_default_255[2];  native_batch_norm_default_255 = None
        relu_default_149 = torch.ops.aten.relu.default(getitem_772)
        convolution_default_472 = torch.ops.aten.convolution.default(relu_default_149, primals_683, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_473 = torch.ops.aten.convolution.default(convolution_default_472, primals_684, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_256 = torch.ops.aten.native_batch_norm.default(convolution_default_473, primals_677, primals_673, primals_675, primals_676, True, 0.1, 0.001);  primals_673 = None
        getitem_784 = native_batch_norm_default_256[0]
        getitem_785 = native_batch_norm_default_256[1]
        getitem_786 = native_batch_norm_default_256[2];  native_batch_norm_default_256 = None
        relu__default_106 = torch.ops.aten.relu_.default(getitem_784);  getitem_784 = None
        convolution_default_474 = torch.ops.aten.convolution.default(relu__default_106, primals_685, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_475 = torch.ops.aten.convolution.default(convolution_default_474, primals_686, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_257 = torch.ops.aten.native_batch_norm.default(convolution_default_475, primals_682, primals_678, primals_680, primals_681, True, 0.1, 0.001);  primals_678 = None
        getitem_787 = native_batch_norm_default_257[0]
        getitem_788 = native_batch_norm_default_257[1]
        getitem_789 = native_batch_norm_default_257[2];  native_batch_norm_default_257 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(getitem_781, getitem_787);  getitem_781 = getitem_787 = None
        relu_default_150 = torch.ops.aten.relu.default(getitem_772)
        convolution_default_476 = torch.ops.aten.convolution.default(relu_default_150, primals_697, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_477 = torch.ops.aten.convolution.default(convolution_default_476, primals_698, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_258 = torch.ops.aten.native_batch_norm.default(convolution_default_477, primals_691, primals_687, primals_689, primals_690, True, 0.1, 0.001);  primals_687 = None
        getitem_790 = native_batch_norm_default_258[0]
        getitem_791 = native_batch_norm_default_258[1]
        getitem_792 = native_batch_norm_default_258[2];  native_batch_norm_default_258 = None
        relu__default_107 = torch.ops.aten.relu_.default(getitem_790);  getitem_790 = None
        convolution_default_478 = torch.ops.aten.convolution.default(relu__default_107, primals_699, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        convolution_default_479 = torch.ops.aten.convolution.default(convolution_default_478, primals_700, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_259 = torch.ops.aten.native_batch_norm.default(convolution_default_479, primals_696, primals_692, primals_694, primals_695, True, 0.1, 0.001);  primals_692 = None
        getitem_793 = native_batch_norm_default_259[0]
        getitem_794 = native_batch_norm_default_259[1]
        getitem_795 = native_batch_norm_default_259[2];  native_batch_norm_default_259 = None
        relu_default_151 = torch.ops.aten.relu.default(getitem_772)
        convolution_default_480 = torch.ops.aten.convolution.default(relu_default_151, primals_711, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_481 = torch.ops.aten.convolution.default(convolution_default_480, primals_712, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_260 = torch.ops.aten.native_batch_norm.default(convolution_default_481, primals_705, primals_701, primals_703, primals_704, True, 0.1, 0.001);  primals_701 = None
        getitem_796 = native_batch_norm_default_260[0]
        getitem_797 = native_batch_norm_default_260[1]
        getitem_798 = native_batch_norm_default_260[2];  native_batch_norm_default_260 = None
        relu__default_108 = torch.ops.aten.relu_.default(getitem_796);  getitem_796 = None
        convolution_default_482 = torch.ops.aten.convolution.default(relu__default_108, primals_713, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_483 = torch.ops.aten.convolution.default(convolution_default_482, primals_714, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_261 = torch.ops.aten.native_batch_norm.default(convolution_default_483, primals_710, primals_706, primals_708, primals_709, True, 0.1, 0.001);  primals_706 = None
        getitem_799 = native_batch_norm_default_261[0]
        getitem_800 = native_batch_norm_default_261[1]
        getitem_801 = native_batch_norm_default_261[2];  native_batch_norm_default_261 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(getitem_793, getitem_799);  getitem_793 = getitem_799 = None
        avg_pool2d_default_67 = torch.ops.aten.avg_pool2d.default(getitem_775, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_108 = torch.ops.aten.add.Tensor(avg_pool2d_default_67, getitem_772);  avg_pool2d_default_67 = None
        avg_pool2d_default_68 = torch.ops.aten.avg_pool2d.default(getitem_772, [3, 3], [1, 1], [1, 1], False, False)
        avg_pool2d_default_69 = torch.ops.aten.avg_pool2d.default(getitem_772, [3, 3], [1, 1], [1, 1], False, False)
        add_tensor_109 = torch.ops.aten.add.Tensor(avg_pool2d_default_68, avg_pool2d_default_69);  avg_pool2d_default_68 = avg_pool2d_default_69 = None
        relu_default_152 = torch.ops.aten.relu.default(getitem_775)
        convolution_default_484 = torch.ops.aten.convolution.default(relu_default_152, primals_725, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_485 = torch.ops.aten.convolution.default(convolution_default_484, primals_726, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_262 = torch.ops.aten.native_batch_norm.default(convolution_default_485, primals_719, primals_715, primals_717, primals_718, True, 0.1, 0.001);  primals_715 = None
        getitem_802 = native_batch_norm_default_262[0]
        getitem_803 = native_batch_norm_default_262[1]
        getitem_804 = native_batch_norm_default_262[2];  native_batch_norm_default_262 = None
        relu__default_109 = torch.ops.aten.relu_.default(getitem_802);  getitem_802 = None
        convolution_default_486 = torch.ops.aten.convolution.default(relu__default_109, primals_727, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 672)
        convolution_default_487 = torch.ops.aten.convolution.default(convolution_default_486, primals_728, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_263 = torch.ops.aten.native_batch_norm.default(convolution_default_487, primals_724, primals_720, primals_722, primals_723, True, 0.1, 0.001);  primals_720 = None
        getitem_805 = native_batch_norm_default_263[0]
        getitem_806 = native_batch_norm_default_263[1]
        getitem_807 = native_batch_norm_default_263[2];  native_batch_norm_default_263 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(getitem_805, getitem_775);  getitem_805 = None
        cat_default_25 = torch.ops.aten.cat.default([getitem_772, add_tensor_106, add_tensor_107, add_tensor_108, add_tensor_109, add_tensor_110], 1);  add_tensor_106 = add_tensor_107 = add_tensor_108 = add_tensor_109 = add_tensor_110 = None
        relu__default_110 = torch.ops.aten.relu_.default(cat_default_25);  cat_default_25 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_110, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [32, 4032]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_1641);  primals_1641 = None
        addmm_default = torch.ops.aten.addmm.default(primals_1640, view_default, t_default);  primals_1640 = None
        return [addmm_default, add_tensor, primals_713, primals_708, primals_705, getitem_253, primals_1395, getitem_28, getitem_326, getitem_27, getitem_714, getitem_461, getitem_713, getitem_252, primals_1400, getitem_327, primals_718, convolution_default_431, primals_283, primals_711, relu__default_3, convolution_default_241, getitem_460, cat_default_11, relu_default_61, relu__default_96, relu_default_75, convolution_default_430, primals_1397, primals_1402, primals_898, convolution_default_197, primals_1396, relu_default_139, primals_709, primals_895, convolution_default_17, convolution_default_196, getitem_404, convolution_default_278, convolution_default_242, primals_285, relu_default_48, convolution_default_277, convolution_default_16, convolution_default_152, primals_280, getitem_717, primals_714, getitem_330, primals_897, getitem_31, constant_pad_nd_default_22, primals_717, relu_default_47, getitem_403, relu_default_136, getitem_716, primals_712, convolution_default_280, getitem_30, getitem_329, relu__default_54, primals_279, primals_892, getitem_464, primals_896, relu__default_44, getitem_463, convolution_default_154, convolution_default_153, relu__default_62, getitem_255, convolution_default_243, primals_1401, convolution_default_432, relu_default_5, convolution_default_198, primals_710, getitem_256, avg_pool2d_default_2, primals_284, convolution_default_244, primals_278, primals_891, convolution_default_279, convolution_default_433, convolution_default_199, getitem_51, primals_941, primals_944, constant_pad_nd_default_10, getitem_500, getitem_50, primals_969, relu__default_45, relu__default_14, relu_default_116, convolution_default_205, convolution_default_66, convolution_default_206, relu__default_67, primals_971, convolution_default_67, primals_773, primals_951, convolution_default_301, relu_default_9, getitem_675, convolution_default_302, convolution_default_371, convolution_default_370, primals_964, relu_default_129, convolution_default_41, getitem_347, getitem_674, getitem_115, primals_943, primals_772, getitem_503, getitem_618, relu_default_66, relu_default_128, convolution_default_30, primals_950, primals_973, getitem_346, getitem_114, getitem_2, primals_776, convolution_default_405, getitem_502, getitem_617, primals_771, primals_1369, convolution_default_29, constant_pad_nd_default_13, relu_default_65, primals_970, getitem_117, getitem_1, constant_pad_nd_default_9, getitem_118, relu_default_95, relu__default_83, add_tensor_6, primals_1678, primals_779, primals_1367, convolution_default_406, primals_945, relu_default, getitem_54, primals_965, getitem_53, primals_778, primals_777, primals_1680, convolution_default_207, convolution_default_372, relu__default_6, getitem_677, primals_949, primals_1677, primals_972, convolution_default_303, convolution_default_407, getitem_116, primals_1681, primals_1370, primals_942, convolution_default_1, relu_default_21, convolution_default_408, convolution_default_208, primals_1674, convolution_default_373, primals_1366, primals_946, primals_968, convolution_default_304, convolution_default_31, getitem_678, primals_1365, primals_1679, convolution_default_32, getitem_4, getitem_349, convolution_default_69, primals_1368, primals_204, primals_1496, primals_1132, primals_1530, primals_1543, primals_1127, primals_1415, getitem_74, convolution_default_44, primals_207, primals_1129, primals_206, getitem_443, primals_1134, primals_1246, primals_1592, getitem_73, primals_1241, primals_1242, getitem_442, primals_1501, primals_1237, relu__default_9, primals_1545, getitem_444, primals_205, primals_1502, primals_1531, primals_1503, primals_1133, primals_211, primals_1497, convolution_default_43, convolution_default_266, primals_1238, primals_1565, getitem_445, primals_1244, primals_1135, primals_1504, primals_212, primals_1128, primals_1394, primals_203, primals_1243, getitem_446, relu_default_84, constant_pad_nd_default_14, getitem_77, primals_210, getitem_76, primals_1236, primals_1137, primals_1505, primals_1529, primals_1532, primals_1566, primals_1136, primals_1498, convolution_default_268, primals_1245, primals_1544, primals_1138, getitem_310, getitem_386, convolution_default_326, getitem_309, convolution_default_455, primals_1491, getitem_657, convolution_default_454, convolution_default_187, getitem_385, getitem_542, convolution_default_328, primals_700, relu_default_76, relu__default_41, getitem_756, getitem_656, getitem_758, relu__default_51, primals_695, convolution_default_186, getitem_541, getitem_755, primals_699, relu__default_73, convolution_default_231, convolution_default_232, relu__default_102, primals_1493, getitem_313, convolution_default_327, primals_704, relu_default_125, primals_696, getitem_312, convolution_default_456, getitem_315, add_tensor_41, relu_default_124, getitem_389, convolution_default_396, primals_1492, relu_default_73, primals_1490, getitem_388, getitem_545, getitem_544, convolution_default_457, relu__default_57, primals_703, convolution_default_397, constant_pad_nd_default_21, getitem_759, primals_697, primals_698, constant_pad_nd_default_19, convolution_default_234, primals_1802, relu_default_59, convolution_default_233, relu_default_104, primals_985, convolution_default_116, convolution_default_117, primals_102, getitem_292, primals_1022, getitem_154, primals_676, getitem_794, getitem_196, getitem_291, convolution_default_336, primals_111, primals_363, primals_115, primals_983, primals_1797, primals_101, relu_default_28, getitem_195, convolution_default_335, relu_default_151, primals_1791, primals_1792, primals_114, relu__default_39, constant_pad_nd_default_24, getitem_795, primals_690, primals_1327, primals_1790, convolution_default_91, constant_pad_nd_default_29, primals_116, primals_1032, relu__default_25, getitem_560, primals_681, convolution_default_176, convolution_default_481, primals_1025, getitem_559, convolution_default_480, primals_980, getitem_157, getitem_156, primals_105, getitem_155, convolution_default_177, primals_974, primals_1028, primals_689, relu__default_75, convolution_default_178, primals_685, getitem_295, primals_106, primals_979, getitem_798, primals_1789, primals_686, primals_1027, relu_default_29, primals_1024, primals_691, constant_pad_nd_default_18, primals_108, primals_1793, primals_1810, primals_361, getitem_294, primals_107, getitem_797, primals_677, convolution_default_337, primals_1026, primals_682, primals_683, primals_984, primals_986, getitem_199, convolution_default_134, relu__default_108, getitem_198, primals_1031, primals_1764, convolution_default_92, primals_366, primals_684, relu_default_37, convolution_default_338, convolution_default_93, convolution_default_482, primals_1796, primals_977, primals_100, getitem_297, getitem_562, primals_1023, primals_358, primals_680, primals_109, primals_978, primals_110, primals_362, convolution_default_118, primals_694, getitem_159, getitem_563, convolution_default_483, primals_450, primals_458, primals_1264, primals_1178, primals_224, convolution_default_421, primals_286, primals_451, getitem_696, primals_1183, primals_457, primals_221, getitem_695, primals_1153, primals_218, primals_225, primals_1578, primals_231, relu__default_94, primals_1147, primals_449, primals_1155, primals_1182, primals_1158, primals_215, primals_1259, primals_294, primals_1142, primals_1672, convolution_default_420, primals_1673, primals_459, primals_1150, primals_292, primals_1177, primals_1579, primals_1141, primals_1159, primals_288, primals_1149, primals_1668, primals_1260, primals_445, primals_1669, primals_1181, primals_287, primals_1154, primals_229, getitem_698, getitem_699, primals_1162, primals_1563, primals_219, primals_1144, primals_452, primals_289, primals_216, primals_1176, primals_226, primals_1265, primals_448, primals_1161, primals_453, primals_217, primals_1143, primals_293, primals_1160, primals_1360, primals_220, primals_1258, primals_1261, primals_230, primals_1488, primals_454, primals_1148, getitem_235, relu_default_91, primals_1619, convolution_default, primals_1621, getitem_5, getitem_638, getitem_639, primals_1110, getitem_425, primals_1104, primals_1594, relu_default_1, relu_default_44, convolution_default_267, convolution_default_290, primals_482, primals_1564, primals_497, primals_1616, getitem_96, primals_1333, primals_1709, primals_1706, convolution_default_256, primals_1710, convolution_default_255, relu_default_121, primals_1624, convolution_default_141, primals_1620, convolution_default_140, convolution_default_3, convolution_default_57, getitem_485, getitem_97, primals_498, primals_1337, getitem_484, primals_486, primals_1338, primals_1629, primals_485, primals_1708, convolution_default_56, convolution_default_2, getitem_483, convolution_default_384, primals_487, getitem_428, convolution_default_385, primals_1329, primals_1105, getitem_238, relu_default_122, primals_1596, constant_pad_nd_default, primals_1328, primals_903, relu_default_92, getitem_100, getitem_427, primals_904, getitem_8, getitem_237, primals_902, getitem_642, getitem_7, primals_907, primals_1628, primals_488, primals_1109, primals_1623, primals_1107, primals_1615, getitem_99, relu__default_31, primals_1625, convolution_default_291, getitem_641, primals_1614, primals_481, relu__default, relu__default_12, primals_1622, relu__default_86, primals_1332, primals_1595, primals_1707, primals_1705, convolution_default_257, getitem_487, convolution_default_142, primals_480, primals_909, convolution_default_292, convolution_default_4, primals_494, primals_492, primals_1711, convolution_default_58, primals_1106, primals_1334, convolution_default_293, primals_901, convolution_default_386, convolution_default_258, convolution_default_143, primals_479, getitem_488, primals_1597, convolution_default_5, primals_491, primals_1108, primals_493, convolution_default_387, primals_908, convolution_default_59, convolution_default_359, getitem_735, convolution_default_358, primals_1760, primals_1762, relu__default_78, primals_861, getitem_580, getitem_736, primals_60, convolution_default_349, primals_1714, primals_1067, convolution_default_350, getitem_600, getitem_737, getitem_139, primals_53, primals_45, primals_1060, primals_864, getitem_599, primals_1763, getitem_738, getitem_138, getitem_583, relu_default_140, primals_47, primals_869, primals_867, relu__default_80, relu_default_25, primals_50, getitem_582, primals_59, primals_1065, convolution_default_81, primals_862, primals_1414, primals_46, primals_1761, primals_1072, primals_1068, convolution_default_360, convolution_default_445, getitem_739, primals_51, primals_1061, relu_default_110, primals_1609, avg_pool2d_default_51, convolution_default_82, primals_1073, primals_1798, getitem_740, convolution_default_351, convolution_default_361, getitem_741, convolution_default_83, primals_55, primals_868, primals_1759, primals_1071, primals_56, relu_default_141, primals_863, primals_52, primals_1059, cat_default_19, getitem_603, primals_1066, getitem_141, primals_54, getitem_142, getitem_602, convolution_default_352, primals_1062, relu_default_114, convolution_default_446, convolution_default_106, primals_1540, convolution_default_165, relu_default_34, convolution_default_220, getitem_57, convolution_default_219, primals_738, getitem_467, getitem_178, getitem_177, getitem_277, getitem_56, getitem_368, getitem_466, primals_1697, convolution_default_130, getitem_276, primals_740, relu__default_23, getitem_59, primals_743, relu_default_88, getitem_367, primals_1694, relu__default_49, primals_1696, constant_pad_nd_default_12, convolution_default_107, getitem_220, convolution_default_167, primals_744, relu_default_40, convolution_default_131, convolution_default_282, getitem_181, convolution_default_166, convolution_default_281, primals_1695, convolution_default_221, relu_default_10, getitem_180, getitem_219, primals_1692, primals_745, primals_1693, primals_748, relu__default_29, getitem_370, getitem_280, getitem_470, convolution_default_33, primals_739, getitem_279, convolution_default_222, constant_pad_nd_default_11, getitem_469, convolution_default_34, convolution_default_132, getitem_371, convolution_default_168, convolution_default_283, primals_1691, relu__default_37, relu__default_63, primals_1539, getitem_61, convolution_default_133, relu__default_91, primals_613, primals_1437, getitem_333, getitem_350, getitem_720, getitem_524, getitem_523, primals_618, primals_1650, getitem_719, relu__default_46, getitem_620, getitem_332, convolution_default_209, primals_750, relu__default_97, convolution_default_210, convolution_default_315, relu__default_70, getitem_621, getitem_681, primals_614, primals_1651, primals_1649, primals_609, getitem_335, convolution_default_374, primals_1655, getitem_353, primals_749, getitem_680, primals_616, convolution_default_434, primals_753, convolution_default_316, getitem_352, convolution_default_435, primals_757, getitem_527, primals_600, relu_default_117, primals_1653, avg_pool2d_default_29, convolution_default_409, primals_604, getitem_723, primals_754, primals_612, primals_601, getitem_526, convolution_default_375, getitem_722, primals_1439, convolution_default_410, primals_1654, primals_617, relu_default_100, primals_751, relu_default_137, getitem_624, convolution_default_376, primals_1652, getitem_623, convolution_default_211, primals_759, constant_pad_nd_default_23, primals_603, convolution_default_411, primals_615, primals_1438, relu__default_84, primals_758, primals_602, primals_608, getitem_382, getitem_336, convolution_default_212, getitem_683, convolution_default_317, getitem_684, getitem_337, convolution_default_436, getitem_338, primals_752, convolution_default_437, primals_607, convolution_default_318, convolution_default_306, getitem_777, constant_pad_nd_default_2, getitem_505, primals_1086, relu__default_34, convolution_default_19, getitem_506, relu_default_148, primals_1783, relu_default_2, getitem_34, primals_1085, relu__default_68, getitem_10, convolution_default_21, primals_1076, convolution_default_469, convolution_default_305, convolution_default_468, primals_1087, getitem_259, getitem_11, getitem_33, primals_1081, primals_1078, getitem_780, convolution_default_7, getitem_258, relu__default_4, getitem_509, getitem_260, primals_1082, convolution_default_6, getitem_779, convolution_default_20, constant_pad_nd_default_1, getitem_508, primals_1077, convolution_default_155, add_tensor_1, relu__default_105, getitem_261, getitem_14, primals_1079, getitem_13, convolution_default_311, relu__default_1, getitem_262, constant_pad_nd_default_6, relu_default_49, getitem_37, convolution_default_470, getitem_36, relu_default_97, convolution_default_471, relu_default_96, convolution_default_8, convolution_default_9, convolution_default_157, primals_1080, primals_170, primals_553, primals_169, primals_656, getitem_406, getitem_407, primals_444, primals_439, relu__default_20, primals_174, primals_1273, primals_1271, getitem_121, primals_422, primals_1435, getitem_120, convolution_default_94, primals_675, primals_1272, primals_1436, primals_424, getitem_119, convolution_default_95, getitem_408, primals_1279, getitem_409, primals_661, primals_1270, primals_1423, getitem_160, relu_default_22, primals_429, primals_435, primals_550, primals_1269, getitem_163, primals_430, primals_657, primals_1433, primals_1453, primals_1419, getitem_410, primals_666, primals_1434, relu_default_77, primals_1379, convolution_default_71, primals_438, convolution_default_70, getitem_162, primals_669, primals_1266, primals_1572, primals_555, primals_1380, primals_1430, primals_426, primals_1425, primals_431, primals_668, primals_1274, primals_1577, relu_default_30, primals_165, primals_421, primals_436, primals_662, primals_1285, primals_1428, primals_173, primals_423, primals_672, primals_1421, primals_667, primals_417, primals_1275, convolution_default_246, primals_420, primals_658, getitem_124, getitem_123, getitem_411, primals_1284, primals_425, primals_1429, primals_168, primals_437, primals_1280, primals_559, convolution_default_96, relu__default_15, primals_1452, primals_1422, primals_176, primals_443, primals_1420, primals_1573, primals_1424, primals_175, primals_670, primals_1574, primals_1283, primals_663, convolution_default_97, getitem_412, primals_440, getitem_413, primals_554, primals_1278, primals_434, primals_558, primals_671, convolution_default_72, relu_default_78, convolution_default_73, primals_1339, getitem_79, primals_1009, relu_default_144, convolution_default_188, relu_default_107, primals_1355, convolution_default_189, convolution_default_459, avg_pool2d_default_7, convolution_default_458, getitem_80, convolution_default_340, convolution_default_190, getitem_318, convolution_default_339, primals_1004, getitem_762, getitem_81, getitem_317, primals_1351, constant_pad_nd_default_25, constant_pad_nd_default_15, primals_1005, primals_1340, relu__default_42, getitem_761, primals_999, getitem_566, primals_1346, primals_1353, primals_1343, getitem_565, relu__default_103, primals_1356, primals_1003, relu__default_76, primals_1008, relu_default_14, primals_1000, convolution_default_460, getitem_320, primals_1352, getitem_82, convolution_default_341, convolution_default_191, primals_1357, convolution_default_47, primals_1348, convolution_default_461, primals_1341, convolution_default_342, getitem_321, avg_pool2d_default_28, primals_1342, primals_1010, getitem_764, getitem_84, primals_1347, getitem_83, add_tensor_76, primals_1354, primals_1033, getitem_659, primals_1408, primals_1163, primals_1037, convolution_default_236, getitem_660, primals_1168, relu_default_133, getitem_392, primals_1113, primals_1644, getitem_202, getitem_700, primals_1645, convolution_default_121, relu__default_89, getitem_702, getitem_800, primals_1038, convolution_default_398, getitem_391, primals_1039, primals_1124, primals_1538, convolution_default_399, getitem_201, primals_1411, primals_1164, getitem_801, primals_1114, relu__default_52, convolution_default_423, primals_1118, relu__default_26, getitem_701, getitem_663, primals_1122, primals_1040, convolution_default_119, primals_1533, primals_1740, getitem_664, convolution_default_235, getitem_705, primals_1172, getitem_662, getitem_704, primals_1409, getitem_703, convolution_default_120, primals_1173, primals_1742, relu__default_110, primals_1169, primals_1042, getitem_665, relu_default_152, primals_1174, relu_default_134, convolution_default_484, primals_1407, primals_1121, primals_1123, primals_1041, primals_1119, primals_1167, getitem_395, getitem_394, primals_1639, getitem_205, relu_default_38, getitem_666, primals_1416, getitem_204, primals_1120, convolution_default_424, convolution_default_485, primals_1410, relu_default_74, primals_1175, primals_1115, primals_1534, primals_1036, primals_1741, primals_1535, convolution_default_425, relu_default_126, getitem_803, relu_default_45, getitem_804, primals_1294, getitem_240, primals_416, getitem_449, getitem_448, getitem_103, getitem_102, getitem_241, getitem_298, primals_1292, getitem_645, relu_default_56, getitem_644, convolution_default_329, primals_767, primals_412, primals_765, getitem_447, relu_default_103, primals_762, relu_default_85, relu_default_18, primals_763, convolution_default_145, primals_1288, convolution_default_144, primals_411, getitem_301, convolution_default_270, getitem_548, relu_default_62, convolution_default_269, primals_1601, convolution_default_61, getitem_300, convolution_default_60, convolution_default_330, convolution_default_388, primals_405, primals_1784, getitem_244, primals_406, relu_default_57, getitem_452, primals_1286, getitem_547, primals_1287, getitem_106, getitem_243, getitem_648, primals_409, relu__default_74, relu__default_32, getitem_451, getitem_105, getitem_647, primals_1787, primals_768, relu__default_60, relu__default_13, relu__default_87, primals_1289, primals_1788, primals_766, convolution_default_331, convolution_default_146, convolution_default_180, constant_pad_nd_default_16, primals_764, convolution_default_181, convolution_default_271, convolution_default_62, convolution_default_390, primals_410, primals_1293, convolution_default_332, convolution_default_147, primals_415, primals_1600, convolution_default_272, getitem_303, convolution_default_333, convolution_default_63, convolution_default_391, primals_258, primals_1470, relu__default_18, convolution_default_84, primals_1754, primals_251, convolution_default_85, primals_1219, primals_256, primals_1220, primals_1768, primals_1568, getitem_145, primals_1770, primals_255, primals_1218, getitem_144, primals_1471, primals_1476, primals_257, primals_1756, primals_1569, primals_1473, primals_1755, primals_1216, relu_default_27, primals_1211, relu_default_26, primals_252, convolution_default_90, primals_259, convolution_default_86, primals_1214, primals_1217, primals_1769, primals_135, primals_1472, primals_250, primals_1215, convolution_default_87, primals_626, convolution_default_112, getitem_372, getitem_17, getitem_430, relu__default_65, relu__default_7, primals_623, getitem_373, getitem_431, getitem_62, convolution_default_363, primals_622, convolution_default_109, convolution_default_362, convolution_default_35, convolution_default_108, getitem_744, convolution_default_449, getitem_16, convolution_default_36, relu_default_81, primals_630, relu_default_70, getitem_374, getitem_19, getitem_184, getitem_491, getitem_606, getitem_743, convolution_default_260, primals_636, convolution_default_259, getitem_65, relu_default_94, relu_default_115, relu__default_100, getitem_490, getitem_605, primals_628, getitem_183, convolution_default_224, getitem_434, getitem_64, convolution_default_447, constant_pad_nd_default_4, relu_default_93, relu__default_81, relu__default_24, convolution_default_448, avg_pool2d_default_6, convolution_default_294, convolution_default_22, getitem_433, getitem_377, relu_default_3, getitem_376, primals_629, getitem_375, relu__default_58, convolution_default_364, convolution_default_110, primals_621, convolution_default_295, relu_default_71, primals_631, primals_1702, relu_default_13, convolution_default_10, relu_default_11, getitem_747, primals_1451, convolution_default_466, constant_pad_nd_default_3, convolution_default_365, getitem_746, primals_1450, convolution_default_38, primals_1463, convolution_default_261, convolution_default_111, primals_627, convolution_default_11, convolution_default_296, primals_635, primals_637, convolution_default_37, convolution_default_225, getitem_608, getitem_609, getitem_186, convolution_default_262, primals_1701, getitem_493, primals_632, getitem_22, getitem_21, getitem_494, relu_default_142, convolution_default_226, getitem_187, primals_1307, getitem_530, primals_847, primals_1306, getitem_529, getitem_39, getitem_42, primals_1302, getitem_41, relu__default_71, primals_849, primals_844, primals_1303, primals_1301, primals_1300, relu_default_7, primals_850, primals_1299, primals_1750, convolution_default_320, primals_1751, constant_pad_nd_default_26, primals_1313, convolution_default_319, primals_1506, primals_853, primals_1749, primals_854, getitem_533, primals_858, primals_1314, primals_1582, primals_855, relu_default_101, primals_1315, cat_default_1, getitem_532, primals_1583, primals_846, avg_pool2d_default_3, primals_1308, primals_859, primals_1309, primals_845, constant_pad_nd_default_7, primals_860, primals_1312, convolution_default_322, convolution_default_321, primals_848, primals_1298, primals_1297, getitem_44, getitem_223, getitem_783, primals_1746, getitem_586, primals_333, primals_825, getitem_585, relu__default_92, primals_1587, convolution_default_412, primals_338, getitem_222, convolution_default_354, convolution_default_413, relu_default_149, primals_1591, getitem_283, getitem_473, relu_default_150, getitem_782, relu__default_79, getitem_224, convolution_default_175, primals_330, primals_832, convolution_default_353, convolution_default_473, primals_826, getitem_282, getitem_472, getitem_687, convolution_default_472, primals_831, getitem_225, primals_833, relu_default_53, getitem_686, getitem_786, primals_1250, convolution_default_169, convolution_default_284, getitem_554, getitem_589, relu_default_130, getitem_226, relu_default_42, avg_pool2d_default_50, getitem_785, primals_1247, primals_334, getitem_588, convolution_default_170, relu_default_90, primals_335, relu__default_106, primals_821, primals_834, primals_1747, getitem_285, convolution_default_414, relu_default_89, convolution_default_289, getitem_591, convolution_default_285, convolution_default_135, constant_pad_nd_default_31, convolution_default_171, convolution_default_474, primals_1588, convolution_default_415, constant_pad_nd_default_30, primals_830, getitem_286, getitem_228, convolution_default_286, convolution_default_400, convolution_default_475, primals_822, primals_1745, primals_827, getitem_229, getitem_689, primals_1251, getitem_227, convolution_default_172, relu__default_38, getitem_355, getitem_765, getitem_356, primals_640, primals_649, relu__default_47, primals_1443, primals_650, convolution_default_213, primals_1799, convolution_default_214, relu_default_146, primals_651, convolution_default_462, primals_644, getitem_359, convolution_default_465, primals_642, getitem_358, primals_655, getitem_768, primals_643, relu_default_145, convolution_default_463, relu_default_67, primals_652, getitem_767, primals_641, relu__default_104, convolution_default_215, primals_645, convolution_default_216, convolution_default_464, primals_646, primals_505, convolution_default_377, primals_5, primals_31, primals_532, primals_507, getitem_726, primals_41, primals_536, getitem_127, getitem_265, getitem_627, getitem_264, getitem_725, primals_511, relu_default_24, getitem_263, primals_520, getitem_126, getitem_626, primals_519, primals_38, primals_517, relu_default_50, primals_508, relu__default_98, relu_default_23, getitem_628, primals_40, primals_531, primals_4, primals_36, primals_1663, convolution_default_159, primals_37, primals_516, convolution_default_158, getitem_629, convolution_default_439, primals_522, primals_513, primals_521, primals_518, convolution_default_438, convolution_default_74, primals_530, getitem_268, getitem_729, primals_526, primals_26, primals_512, convolution_default_75, getitem_630, primals_28, primals_1442, relu_default_119, primals_32, convolution_default_161, primals_535, getitem_267, getitem_728, primals_39, primals_533, primals_33, primals_1381, primals_1382, relu__default_35, getitem_129, relu_default_138, primals_1748, primals_527, getitem_631, getitem_130, convolution_default_379, convolution_default_76, primals_27, primals_504, relu__default_16, primals_42, primals_503, primals_506, primals_534, convolution_default_160, primals_8, primals_499, primals_3, primals_525, primals_9, primals_502, primals_316, primals_804, getitem_166, getitem_569, primals_732, primals_801, primals_807, primals_1205, primals_315, convolution_default_248, convolution_default_247, getitem_512, primals_1715, getitem_571, convolution_default_307, getitem_568, primals_311, primals_1200, convolution_default_99, relu__default_21, primals_1776, convolution_default_98, primals_1203, primals_149, primals_734, convolution_default_308, primals_722, getitem_416, primals_733, getitem_511, constant_pad_nd_default_28, primals_719, primals_1362, primals_150, primals_1716, getitem_165, getitem_415, relu__default_69, primals_724, primals_1774, primals_1717, relu_default_108, primals_163, primals_1202, getitem_169, primals_1507, primals_1631, primals_1634, relu__default_55, primals_1209, primals_726, primals_1201, primals_1636, primals_151, convolution_default_344, primals_725, primals_1778, primals_313, primals_731, primals_317, primals_808, getitem_168, convolution_default_309, primals_312, convolution_default_343, primals_1773, primals_806, constant_pad_nd_default_27, primals_737, primals_158, primals_805, primals_1204, primals_1630, primals_314, convolution_default_249, primals_1206, convolution_default_310, primals_1210, getitem_573, primals_164, getitem_574, primals_1775, convolution_default_250, primals_1637, primals_800, convolution_default_100, primals_156, primals_727, primals_1638, relu__default_77, primals_159, primals_1777, getitem_515, primals_152, primals_1635, getitem_514, getitem_418, getitem_419, primals_1765, convolution_default_345, convolution_default_101, primals_162, primals_728, primals_153, primals_723, primals_157, primals_809, primals_595, primals_787, primals_1804, primals_1808, getitem_85, getitem_109, convolution_default_237, convolution_default_238, primals_1191, relu_default_63, primals_137, primals_790, primals_1546, primals_791, relu_default_15, primals_275, primals_796, getitem_108, primals_598, primals_1646, primals_1700, relu_default_60, getitem_398, primals_786, convolution_default_202, primals_599, convolution_default_49, convolution_default_245, primals_1187, convolution_default_48, primals_269, primals_594, primals_580, getitem_397, primals_785, primals_1192, primals_1196, getitem_341, primals_1186, convolution_default_193, convolution_default_192, getitem_340, getitem_339, relu__default_53, getitem_88, primals_1195, primals_148, getitem_324, primals_1803, primals_260, getitem_87, primals_264, primals_1805, relu_default_20, getitem_323, convolution_default_239, primals_138, relu__default_10, primals_588, primals_795, primals_147, relu__default_43, primals_142, relu_default_19, primals_782, primals_579, convolution_default_64, primals_143, primals_265, primals_1548, primals_1809, primals_587, convolution_default_203, primals_585, primals_1547, primals_586, primals_793, primals_794, convolution_default_240, convolution_default_50, primals_781, primals_270, primals_274, convolution_default_194, primals_584, convolution_default_204, convolution_default_65, primals_271, primals_792, primals_1197, getitem_401, primals_1189, primals_273, convolution_default_51, getitem_400, primals_581, primals_144, convolution_default_195, getitem_343, primals_593, primals_799, primals_139, primals_589, getitem_111, primals_780, primals_1806, primals_261, primals_590, primals_1188, getitem_112, primals_266, relu_default_64, primals_272, primals_1190, primals_1549, convolution_default_123, getitem_247, getitem_436, primals_922, convolution_default_122, getitem_246, relu_default_87, primals_921, convolution_default_401, relu__default_109, primals_1046, getitem_455, convolution_default_486, getitem_454, primals_916, convolution_default_487, getitem_208, primals_1045, relu_default_46, getitem_669, primals_1054, getitem_668, primals_1053, getitem_667, primals_1375, getitem_437, getitem_207, relu_default_86, primals_913, getitem_807, primals_1047, convolution_default_149, convolution_default_148, relu__default_27, relu_default_127, relu_default_83, convolution_default_263, convolution_default_274, getitem_806, convolution_default_273, primals_1374, getitem_250, relu_default_82, view_default, convolution_default_402, convolution_default_124, primals_1376, getitem_458, primals_1056, primals_915, getitem_249, convolution_default_403, convolution_default_276, relu__default_33, getitem_457, t_default, primals_914, primals_918, convolution_default_264, primals_1050, convolution_default_125, relu__default_61, getitem_671, getitem_672, convolution_default_150, convolution_default_265, primals_912, getitem_211, getitem_440, primals_917, convolution_default_151, convolution_default_404, primals_1447, getitem_210, getitem_439, relu__default_90, convolution_default_275, relu_default_39, relu__default_59, primals_1052, primals_1055, primals_1051, getitem_551, getitem_550, primals_574, primals_1090, primals_344, primals_573, getitem_148, primals_1092, primals_1094, primals_564, primals_67, primals_1586, getitem_147, primals_466, primals_64, primals_1665, primals_80, primals_355, relu__default_19, getitem_553, primals_1101, primals_342, primals_357, primals_349, primals_1361, primals_1096, primals_463, primals_563, primals_562, primals_341, primals_356, primals_464, convolution_default_89, primals_1383, primals_1449, primals_69, primals_339, primals_73, primals_1100, primals_354, convolution_default_88, relu_default_105, primals_353, primals_1093, primals_70, primals_569, getitem_151, primals_74, primals_1666, primals_76, primals_561, primals_1667, primals_478, primals_560, primals_1091, convolution_default_334, primals_347, primals_575, getitem_150, primals_61, primals_352, primals_476, primals_66, primals_348, primals_477, primals_1664, primals_68, primals_65, primals_462, primals_472, primals_468, primals_576, primals_1095, primals_79, getitem_556, primals_467, primals_570, getitem_557, primals_471, primals_567, primals_75, primals_340, primals_473, primals_1099, relu_default_106, getitem_153, getitem_152, primals_568, primals_465, primals_343, primals_322, convolution_default_39, convolution_default_427, primals_545, getitem_304, getitem_707, convolution_default_378, primals_188, primals_1319, relu__default_2, primals_546, getitem_67, getitem_68, relu__default_66, getitem_708, convolution_default_12, convolution_default_297, relu__default_40, convolution_default_367, convolution_default_13, convolution_default_298, convolution_default_366, convolution_default_182, relu__default_95, convolution_default_183, convolution_default_426, primals_182, relu__default_8, primals_320, getitem_612, primals_544, primals_327, getitem_25, getitem_497, getitem_307, getitem_611, getitem_24, getitem_496, getitem_711, constant_pad_nd_default_20, primals_541, convolution_default_40, primals_323, getitem_306, convolution_default_42, relu__default_82, primals_549, primals_179, getitem_71, primals_191, primals_1325, getitem_710, primals_329, primals_183, relu_default_58, getitem_344, primals_328, getitem_70, relu_default_135, primals_190, primals_547, primals_539, relu_default_118, primals_192, convolution_default_368, primals_1320, primals_1610, convolution_default_299, relu_default_6, relu_default_4, primals_184, primals_189, primals_321, primals_1611, primals_177, convolution_default_369, primals_1326, primals_1581, convolution_default_300, convolution_default_428, primals_1580, relu_default_12, convolution_default_184, primals_1323, primals_178, primals_326, primals_1318, cat_default_3, constant_pad_nd_default_17, primals_187, convolution_default_14, getitem_614, constant_pad_nd_default_5, convolution_default_185, primals_548, convolution_default_68, getitem_615, primals_540, primals_1324, getitem_499, convolution_default_429, convolution_default_15, getitem_45, convolution_default_228, getitem_651, getitem_536, convolution_default_451, getitem_188, convolution_default_450, primals_1231, primals_196, primals_1512, getitem_189, getitem_380, primals_197, relu_default_8, getitem_379, getitem_535, getitem_650, getitem_750, primals_1384, getitem_289, primals_1224, primals_1515, relu_default_123, primals_1516, relu_default_35, relu__default_72, primals_1256, convolution_default_26, getitem_190, primals_201, primals_1517, relu__default_50, primals_1518, getitem_749, getitem_288, primals_202, primals_1257, convolution_default_25, primals_1520, relu__default_101, primals_1225, primals_1233, constant_pad_nd_default_8, convolution_default_323, convolution_default_324, convolution_default_393, primals_1510, convolution_default_392, convolution_default_227, primals_1232, convolution_default_113, convolution_default_173, getitem_48, primals_1519, getitem_383, getitem_47, convolution_default_452, primals_1511, primals_1223, primals_1465, relu__default_5, getitem_193, primals_198, primals_1521, relu_default_55, getitem_192, primals_1230, getitem_191, relu_default_54, getitem_539, primals_1252, getitem_654, getitem_538, getitem_653, relu_default_72, getitem_752, convolution_default_174, convolution_default_453, relu_default_36, relu_default_102, relu__default_88, convolution_default_179, primals_1464, primals_1255, convolution_default_27, primals_193, primals_1525, primals_1226, primals_1526, convolution_default_230, getitem_753, primals_1466, convolution_default_115, relu_default_143, primals_1229, convolution_default_229, primals_1524, convolution_default_28, convolution_default_114, convolution_default_325, convolution_default_394, convolution_default_395, primals_960, getitem_362, getitem_476, primals_1477, getitem_361, getitem_475, primals_957, getitem_690, primals_301, primals_308, primals_303, primals_956, convolution_default_218, convolution_default_288, primals_963, relu__default_93, convolution_default_416, primals_298, primals_297, primals_1018, relu__default_48, relu__default_64, convolution_default_417, convolution_default_217, convolution_default_287, primals_955, primals_1019, primals_1013, getitem_693, primals_1484, primals_1478, primals_1479, getitem_480, primals_1012, getitem_365, getitem_479, primals_1017, getitem_692, primals_1011, primals_959, primals_1014, primals_1391, primals_958, primals_1388, primals_1482, getitem_364, getitem_478, primals_954, primals_302, primals_1385, primals_307, convolution_default_223, relu_default_68, relu_default_132, primals_300, primals_299, primals_1390, relu_default_69, getitem_481, primals_1389, relu_default_131, convolution_default_422, primals_1483, primals_306, getitem_482, convolution_default_418, convolution_default_419, primals_1462, getitem_789, getitem_788, primals_1734, primals_990, primals_813, getitem_516, getitem_593, primals_382, primals_390, getitem_517, primals_816, relu_default_98, getitem_592, primals_384, primals_996, primals_381, getitem_518, primals_1457, primals_1731, primals_239, primals_1458, primals_234, primals_386, primals_391, convolution_default_477, primals_991, convolution_default_476, primals_1733, primals_385, convolution_default_312, primals_1461, primals_1721, primals_814, primals_1732, getitem_792, relu_default_112, primals_815, primals_819, getitem_521, getitem_520, getitem_519, getitem_791, primals_380, primals_994, getitem_594, primals_235, convolution_default_357, primals_995, primals_1658, primals_233, primals_394, getitem_595, relu__default_107, primals_998, primals_1737, primals_383, primals_1735, primals_1736, relu_default_99, primals_232, primals_1660, primals_989, primals_238, getitem_596, primals_1720, getitem_597, primals_810, primals_1489, primals_377, primals_1723, convolution_default_478, primals_389, convolution_default_313, relu_default_113, primals_1726, primals_997, primals_1456, primals_1728, primals_1659, primals_1722, convolution_default_479, primals_820, primals_1727, relu_default_31, convolution_default_314, relu_default_43, convolution_default_444, primals_241, convolution_default_440, primals_926, getitem_133, convolution_default_137, primals_935, convolution_default_136, primals_1552, primals_940, primals_246, primals_1558, getitem_732, getitem_132, primals_1687, primals_1688, getitem_232, convolution_default_441, primals_240, primals_888, primals_1686, getitem_231, convolution_default_77, getitem_731, primals_883, primals_927, primals_1683, relu__default_30, relu__default_99, primals_931, convolution_default_78, primals_1593, primals_887, primals_937, primals_930, primals_1553, primals_1560, primals_247, primals_929, primals_889, primals_244, convolution_default_138, primals_1444, convolution_default_442, primals_923, convolution_default_79, primals_1555, primals_936, primals_928, primals_1559, convolution_default_18, primals_1682, convolution_default_80, convolution_default_139, convolution_default_443, getitem_136, primals_890, getitem_135, primals_245, primals_886, relu__default_17, primals_1554, getitem_234, primals_932, getitem_734, convolution_default_156, primals_404, getitem_632, primals_398, relu_default_79, getitem_633, convolution_default_127, convolution_default_126, getitem_577, convolution_default_252, relu_default_120, convolution_default_251, convolution_default_389, getitem_770, primals_395, getitem_771, getitem_214, getitem_216, getitem_576, convolution_default_381, getitem_772, getitem_422, convolution_default_380, relu_default_111, getitem_213, primals_1567, getitem_773, getitem_421, convolution_default_346, relu__default_28, getitem_636, relu__default_56, getitem_635, getitem_774, primals_397, primals_1448, relu_default_109, relu_default_147, convolution_default_128, relu__default_85, primals_403, convolution_default_253, primals_399, convolution_default_347, convolution_default_467, convolution_default_129, convolution_default_382, convolution_default_348, convolution_default_254, primals_396, getitem_217, relu_default_80, convolution_default_383, getitem_776, relu_default_41, getitem_775, primals_400, getitem_424, getitem_579, primals_1602, relu_default_17, primals_878, getitem_90, getitem_172, getitem_171, primals_136, primals_10, primals_81, getitem_271, getitem_91, primals_376, convolution_default_103, primals_835, primals_121, relu_default_52, getitem_270, primals_368, relu_default_16, primals_92, primals_119, relu__default_22, primals_123, primals_19, primals_1782, convolution_default_102, primals_367, relu_default_51, primals_14, primals_134, primals_874, primals_877, convolution_default_52, convolution_default_53, primals_17, primals_875, primals_1607, primals_87, primals_839, primals_1605, primals_97, primals_133, primals_881, primals_22, primals_86, primals_128, getitem_94, primals_371, relu_default_33, primals_96, getitem_175, convolution_default_163, convolution_default_162, primals_1467, primals_873, primals_1371, primals_876, getitem_93, getitem_174, primals_840, primals_370, primals_24, primals_130, relu__default_11, primals_12, primals_375, relu_default_32, primals_88, primals_23, primals_122, primals_94, getitem_274, primals_1405, convolution_default_164, getitem_273, primals_1608, primals_95, primals_841, primals_124, primals_836, primals_13, primals_129, primals_82, primals_1406, primals_1779, convolution_default_54, relu__default_36, primals_83, primals_125, primals_872, primals_1487, convolution_default_104, primals_18, primals_11, primals_25, primals_91, primals_120, primals_369, primals_93, convolution_default_55, primals_882, convolution_default_105, primals_1606, primals_372]
        
