
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/gluon_xception65/gluon_xception65_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_4, getitem_304, getitem_187, getitem_305, primals_182, convolution_default_86, convolution_default_87, relu__default_22, primals_12, getitem_303, convolution_default_63, convolution_default_102, getitem_260, primals_10, getitem_259, primals_6, getitem_188, primals_366, getitem_308, relu__default_30, getitem_307, primals_11, primals_7, getitem_191, getitem_190, getitem_189, relu__default_35, primals_5, convolution_default_64, primals_183, getitem_263, convolution_default_103, getitem_262, getitem_261, getitem_309, primals_188, convolution_default_88, primals_186, relu_default_8, convolution_default_104, primals_187, getitem_310, getitem_193, getitem_311, getitem_194, primals_3, relu__default_2, getitem_38, getitem_212, convolution_default_5, getitem_211, getitem_236, convolution_default_6, getitem_235, convolution_default_13, convolution_default_14, getitem_41, primals_241, getitem_40, getitem_17, relu__default_27, getitem_16, getitem_15, relu_default_12, convolution_default_71, convolution_default_79, relu__default_6, primals_242, primals_181, getitem_215, getitem_214, primals_233, getitem_213, getitem_42, getitem_239, getitem_238, getitem_20, getitem_237, primals_237, getitem_19, convolution_default_72, primals_240, getitem_43, convolution_default_80, primals_236, getitem_44, relu__default_3, convolution_default_15, primals_235, getitem_217, convolution_default_7, getitem_218, primals_234, getitem_241, add_tensor_1, primals_272, primals_581, primals_582, primals_278, primals_224, primals_281, primals_273, primals_578, primals_223, primals_577, primals_576, primals_270, primals_573, primals_571, primals_271, primals_276, primals_572, primals_225, primals_221, primals_566, primals_277, primals_570, primals_585, primals_569, primals_583, primals_222, primals_269, primals_584, getitem_163, getitem_164, primals_309, primals_787, relu__default_19, primals_319, convolution_default_55, primals_786, primals_785, primals_321, primals_792, primals_789, getitem_167, getitem_166, getitem_165, primals_318, primals_794, convolution_default_56, primals_788, primals_320, primals_312, getitem_169, getitem_170, primals_314, primals_324, relu__default_20, convolution_default_57, primals_313, primals_793, primals_317, primals_795, primals_704, primals_710, primals_717, getitem_377, getitem_376, primals_714, primals_705, convolution_default_126, primals_709, primals_708, primals_715, primals_720, getitem_380, getitem_379, getitem_378, primals_713, primals_102, convolution_default_127, primals_106, primals_103, primals_111, primals_108, primals_716, getitem_382, primals_107, getitem_383, convolution_default_47, getitem_143, getitem_142, getitem_141, convolution_default_48, getitem_146, getitem_145, relu__default_17, convolution_default_49, primals_288, primals_283, primals_282, primals_293, primals_284, primals_285, primals_294, primals_290, primals_289, relu__default_14, primals_681, primals_680, primals_679, getitem_119, getitem_118, primals_678, getitem_117, primals_677, primals_374, primals_674, primals_369, convolution_default_40, primals_673, primals_379, getitem_122, primals_672, getitem_121, primals_368, primals_367, primals_669, primals_377, primals_378, primals_668, primals_373, relu_default_7, primals_372, primals_667, primals_666, convolution_default_41, primals_665, getitem_95, getitem_94, getitem_93, convolution_default_32, getitem_98, getitem_97, relu__default_12, convolution_default_33, getitem_99, getitem_266, primals_257, getitem_265, getitem_71, getitem_70, getitem_69, primals_265, primals_258, convolution_default_89, primals_261, convolution_default_24, getitem_269, primals_253, getitem_268, getitem_74, getitem_267, getitem_73, convolution_default_90, primals_266, primals_252, relu__default_9, convolution_default_25, getitem_271, getitem_272, primals_259, primals_254, primals_264, getitem_76, convolution_default_91, primals_260, getitem_75, relu__default_31, getitem_47, primals_330, primals_157, getitem_46, getitem_314, primals_325, getitem_313, primals_326, getitem_338, primals_154, getitem_337, primals_73, primals_66, relu__default_36, primals_156, primals_155, getitem_50, getitem_49, primals_341, primals_145, primals_329, convolution_default_105, convolution_default_113, relu_default, primals_65, primals_70, getitem_317, getitem_316, getitem_315, getitem_341, relu_default_3, getitem_340, primals_150, getitem_339, primals_64, primals_153, primals_332, primals_143, convolution_default_106, primals_76, primals_331, getitem_52, primals_336, convolution_default_16, convolution_default_17, convolution_default_114, primals_333, primals_69, primals_78, primals_71, primals_72, primals_144, relu__default_4, relu_default_15, primals_149, getitem_51, primals_337, primals_338, getitem_53, getitem_319, primals_79, getitem_320, primals_77, convolution_default, convolution_default_18, getitem_343, primals_148, getitem_242, relu_default_11, getitem_23, getitem_21, convolution_default_65, getitem_22, relu__default_28, convolution_default_81, primals_758, convolution_default_82, primals_761, convolution_default_8, getitem_197, primals_757, getitem_196, getitem_195, primals_112, primals_756, primals_113, getitem_245, convolution_default_66, getitem_244, getitem_26, getitem_243, getitem_25, primals_753, primals_752, primals_121, getitem_200, primals_114, primals_750, getitem_199, primals_120, relu_default_2, primals_749, primals_118, primals_751, relu__default_23, getitem_247, primals_115, convolution_default_9, getitem_248, primals_119, primals_746, primals_125, primals_745, getitem_28, convolution_default_67, primals_744, primals_126, primals_124, getitem_29, relu_default_14, convolution_default_10, convolution_default_83, relu__default_25, getitem_290, getitem_289, convolution_default_73, convolution_default_74, convolution_default_120, primals_48, primals_42, relu__default_33, convolution_default_97, getitem_362, getitem_221, getitem_361, getitem_220, getitem_360, primals_41, getitem_219, primals_40, convolution_default_121, primals_49, getitem_293, getitem_292, getitem_291, primals_47, getitem_365, getitem_224, primals_45, getitem_364, getitem_223, convolution_default_98, primals_46, primals_37, relu__default_41, relu__default_26, getitem_295, primals_36, primals_35, convolution_default_122, convolution_default_75, getitem_296, primals_34, convolution_default_99, relu__default_34, primals_768, primals_725, primals_726, getitem_173, primals_727, getitem_172, getitem_171, primals_765, primals_728, primals_764, primals_729, primals_770, primals_732, convolution_default_58, getitem_176, primals_733, getitem_175, primals_734, primals_773, primals_738, primals_775, primals_776, primals_737, primals_777, relu_default_10, primals_722, primals_740, convolution_default_59, primals_782, primals_762, primals_739, primals_763, primals_780, primals_769, primals_721, primals_781, getitem_178, primals_741, getitem_177, primals_774, primals_168, getitem_149, primals_60, getitem_147, getitem_148, primals_160, primals_52, primals_54, primals_166, primals_57, primals_59, convolution_default_50, getitem_152, primals_161, getitem_151, primals_58, primals_167, relu__default_18, primals_61, primals_172, primals_171, primals_176, primals_163, convolution_default_51, primals_53, primals_177, getitem_154, primals_173, getitem_155, getitem_153, primals_162, getitem_125, getitem_124, getitem_123, convolution_default_42, getitem_128, getitem_127, relu__default_15, convolution_default_43, getitem_129, getitem_130, getitem_131, convolution_default_44, getitem_100, primals_552, getitem_101, primals_213, primals_553, primals_205, convolution_default_34, primals_207, primals_561, primals_356, getitem_104, primals_548, getitem_103, primals_565, primals_206, primals_357, primals_361, primals_355, primals_214, primals_362, primals_559, primals_209, relu_default_6, primals_560, primals_212, primals_557, convolution_default_35, primals_558, getitem_105, primals_549, primals_360, primals_208, primals_554, getitem_106, primals_216, primals_564, getitem_107, primals_546, primals_365, primals_547, convolution_default_36, primals_215, primals_641, primals_617, relu__default_44, convolution_default_128, getitem_77, primals_500, convolution_default_26, convolution_default_129, primals_504, primals_618, convolution_default_27, primals_620, getitem_80, primals_631, getitem_79, primals_192, primals_499, getitem_386, primals_501, getitem_385, primals_606, getitem_384, primals_632, primals_191, primals_613, primals_633, primals_202, relu__default_10, primals_201, primals_200, primals_605, primals_621, primals_638, primals_194, primals_637, primals_643, getitem_389, primals_506, primals_636, getitem_388, primals_607, getitem_83, primals_642, getitem_82, primals_492, primals_619, getitem_81, primals_624, primals_612, primals_497, primals_625, relu__default_45, primals_193, primals_498, primals_626, convolution_default_28, primals_609, primals_493, primals_494, primals_195, primals_614, primals_505, convolution_default_130, primals_198, primals_629, primals_608, primals_199, primals_630, primals_593, primals_596, primals_690, primals_691, primals_602, primals_692, primals_693, primals_588, primals_601, primals_696, primals_597, primals_697, primals_698, primals_590, primals_589, primals_701, primals_702, primals_703, primals_600, primals_684, primals_595, primals_685, primals_689, primals_594, primals_686, primals_133, primals_138, primals_129, primals_130, primals_137, primals_131, primals_136, primals_141, primals_132, primals_142, getitem_344, getitem_227, getitem_226, primals_22, relu__default_39, relu__default_43, convolution_default_107, convolution_default_115, primals_535, getitem_225, primals_536, convolution_default_116, convolution_default_76, primals_15, getitem_323, primals_537, getitem_322, getitem_321, primals_27, getitem_230, getitem_347, getitem_229, getitem_346, primals_29, getitem_345, convolution_default_108, primals_16, primals_534, primals_23, primals_540, primals_545, getitem_326, relu_default_13, primals_528, primals_529, getitem_325, convolution_default_117, primals_28, convolution_default_77, getitem_349, primals_30, getitem_231, getitem_350, primals_17, relu__default_37, primals_18, getitem_232, primals_530, relu__default_40, primals_24, primals_542, primals_19, convolution_default_78, convolution_default_109, getitem_233, primals_31, primals_541, primals_533, add_tensor_18, primals_433, primals_420, primals_416, getitem_56, getitem_275, getitem_55, getitem_274, primals_415, getitem_273, getitem_299, getitem_298, getitem_297, getitem_2, relu__default_7, getitem_1, convolution_default_19, convolution_default_92, relu__default, getitem_278, convolution_default_100, getitem_277, getitem_302, primals_417, getitem_301, getitem_59, getitem_58, getitem_57, convolution_default_1, relu__default_32, primals_427, primals_428, convolution_default_20, convolution_default_93, primals_425, convolution_default_119, primals_432, primals_429, convolution_default_2, convolution_default_101, getitem_4, getitem_5, primals_421, relu__default_1, primals_422, getitem_61, getitem_280, primals_426, getitem_279, convolution_default_84, getitem_179, getitem_32, getitem_251, getitem_31, getitem_250, getitem_30, convolution_default_60, getitem_249, convolution_default_61, getitem_182, getitem_181, convolution_default_11, relu__default_21, getitem_254, getitem_253, getitem_35, getitem_34, getitem_183, relu__default_29, relu__default_5, getitem_184, convolution_default_85, getitem_185, convolution_default_12, convolution_default_62, getitem_256, getitem_257, getitem_37, getitem_255, getitem_36, primals_230, getitem_202, getitem_203, primals_229, getitem_201, convolution_default_68, convolution_default_69, getitem_206, getitem_205, relu__default_24, primals_228, getitem_207, getitem_208, getitem_209, convolution_default_70, primals_408, getitem_368, getitem_367, primals_409, primals_414, primals_402, getitem_366, primals_413, convolution_default_123, getitem_371, getitem_370, relu__default_42, primals_398, convolution_default_124, getitem_372, primals_397, primals_410, primals_403, getitem_373, primals_401, getitem_374, primals_405, primals_404, convolution_default_125, primals_396, primals_380, primals_390, convolution_default_52, primals_348, primals_345, primals_381, getitem_158, getitem_157, primals_100, primals_391, primals_344, primals_393, primals_343, primals_350, relu_default_9, convolution_default_53, primals_392, primals_389, primals_384, getitem_161, getitem_160, getitem_159, primals_353, primals_101, primals_99, primals_385, convolution_default_54, primals_386, primals_354, primals_342, primals_349, convolution_default_45, getitem_134, getitem_133, relu__default_16, getitem_137, getitem_136, getitem_135, convolution_default_46, relu_default_5, getitem_139, getitem_140, getitem_392, getitem_110, getitem_391, getitem_109, getitem_390, convolution_default_37, relu__default_13, convolution_default_131, getitem_395, getitem_394, getitem_113, getitem_112, getitem_111, relu__default_46, convolution_default_38, view_default, getitem_115, convolution_default_39, t_default, getitem_116, getitem_85, primals_656, getitem_86, primals_245, primals_657, primals_645, convolution_default_29, getitem_89, getitem_88, primals_248, primals_655, getitem_87, primals_653, primals_649, primals_650, convolution_default_30, primals_246, primals_654, primals_662, primals_644, primals_648, primals_660, getitem_91, getitem_92, primals_661, relu__default_11, convolution_default_31, primals_247, primals_456, primals_463, relu_default_1, primals_453, primals_457, getitem_8, primals_465, getitem_7, primals_89, primals_87, primals_461, primals_94, primals_464, primals_96, primals_82, convolution_default_3, getitem_11, getitem_10, getitem_9, primals_95, primals_91, primals_88, primals_83, convolution_default_4, primals_469, primals_468, primals_462, primals_470, primals_458, primals_90, getitem_13, getitem_14, primals_84, primals_178, getitem_62, primals_480, getitem_329, getitem_327, getitem_328, primals_473, relu__default_8, primals_481, convolution_default_21, convolution_default_110, convolution_default_22, getitem_65, primals_474, getitem_332, getitem_64, getitem_63, primals_482, getitem_331, relu__default_38, primals_488, convolution_default_111, primals_475, getitem_67, primals_485, getitem_68, getitem_333, primals_486, getitem_334, primals_477, primals_489, convolution_default_112, primals_476, relu_default_4, getitem_335, convolution_default_23, primals_487, primals_446, getitem_281, primals_516, convolution_default_118, primals_437, primals_308, primals_305, primals_509, getitem_353, getitem_352, primals_438, getitem_351, primals_523, convolution_default_94, primals_440, primals_295, primals_296, primals_434, getitem_284, primals_510, getitem_283, primals_444, primals_441, primals_302, primals_521, primals_449, primals_450, primals_513, getitem_356, getitem_355, primals_439, relu_default_16, primals_452, primals_511, convolution_default_95, getitem_285, primals_451, primals_297, primals_249, primals_306, primals_525, getitem_286, primals_307, getitem_287, primals_518, primals_445, primals_517, primals_512, convolution_default_96, primals_522, primals_300, getitem_358, getitem_359, primals_301, primals_524, relu_default_17, tangents_1):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [64, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [64, 2048, 10, 10]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 100);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_132, to_dtype);  le_scalar = new_zeros_default_132 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_131, primals_193, primals_191, primals_192, getitem_394, getitem_395, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_131 = primals_193 = primals_191 = primals_192 = getitem_394 = getitem_395 = None
        getitem_396 = native_batch_norm_backward_default[0]
        getitem_397 = native_batch_norm_backward_default[1]
        getitem_398 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_396, getitem_390, primals_216, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_396 = getitem_390 = primals_216 = None
        getitem_399 = convolution_backward_default[0]
        getitem_400 = convolution_backward_default[1];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_399, convolution_default_130, primals_214, primals_212, primals_213, getitem_391, getitem_392, True, 1e-05, [True, True, True]);  getitem_399 = convolution_default_130 = primals_214 = primals_212 = primals_213 = getitem_391 = getitem_392 = None
        getitem_402 = native_batch_norm_backward_default_1[0]
        getitem_403 = native_batch_norm_backward_default_1[1]
        getitem_404 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_402, relu__default_45, primals_215, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1536, [True, True, False]);  getitem_402 = primals_215 = None
        getitem_405 = convolution_backward_default_1[0]
        getitem_406 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_405, torch.float32);  getitem_405 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_133, to_dtype_3);  le_scalar_1 = new_zeros_default_133 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_129, primals_188, primals_186, primals_187, getitem_388, getitem_389, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_129 = primals_188 = primals_186 = primals_187 = getitem_388 = getitem_389 = None
        getitem_408 = native_batch_norm_backward_default_2[0]
        getitem_409 = native_batch_norm_backward_default_2[1]
        getitem_410 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_408, getitem_384, primals_209, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_408 = getitem_384 = primals_209 = None
        getitem_411 = convolution_backward_default_2[0]
        getitem_412 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(getitem_411, convolution_default_128, primals_207, primals_205, primals_206, getitem_385, getitem_386, True, 1e-05, [True, True, True]);  getitem_411 = convolution_default_128 = primals_207 = primals_205 = primals_206 = getitem_385 = getitem_386 = None
        getitem_414 = native_batch_norm_backward_default_3[0]
        getitem_415 = native_batch_norm_backward_default_3[1]
        getitem_416 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_414, relu__default_44, primals_208, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1536, [True, True, False]);  getitem_414 = primals_208 = None
        getitem_417 = convolution_backward_default_3[0]
        getitem_418 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_417, torch.float32);  getitem_417 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_134, to_dtype_6);  le_scalar_2 = new_zeros_default_134 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_127, primals_183, primals_181, primals_182, getitem_382, getitem_383, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_127 = primals_183 = primals_181 = primals_182 = getitem_382 = getitem_383 = None
        getitem_420 = native_batch_norm_backward_default_4[0]
        getitem_421 = native_batch_norm_backward_default_4[1]
        getitem_422 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_420, getitem_378, primals_202, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_420 = getitem_378 = primals_202 = None
        getitem_423 = convolution_backward_default_4[0]
        getitem_424 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(getitem_423, convolution_default_126, primals_200, primals_198, primals_199, getitem_379, getitem_380, True, 1e-05, [True, True, True]);  getitem_423 = convolution_default_126 = primals_200 = primals_198 = primals_199 = getitem_379 = getitem_380 = None
        getitem_426 = native_batch_norm_backward_default_5[0]
        getitem_427 = native_batch_norm_backward_default_5[1]
        getitem_428 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_426, relu__default_43, primals_201, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1024, [True, True, False]);  getitem_426 = primals_201 = None
        getitem_429 = convolution_backward_default_5[0]
        getitem_430 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_429, torch.float32);  getitem_429 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_135, to_dtype_9);  le_scalar_3 = new_zeros_default_135 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_125, primals_78, primals_76, primals_77, getitem_376, getitem_377, True, 1e-05, [True, True, True]);  convolution_default_125 = primals_78 = primals_76 = primals_77 = getitem_376 = getitem_377 = None
        getitem_432 = native_batch_norm_backward_default_6[0]
        getitem_433 = native_batch_norm_backward_default_6[1]
        getitem_434 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_432, getitem_372, primals_73, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_432 = getitem_372 = primals_73 = None
        getitem_435 = convolution_backward_default_6[0]
        getitem_436 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(getitem_435, convolution_default_124, primals_71, primals_69, primals_70, getitem_373, getitem_374, True, 1e-05, [True, True, True]);  getitem_435 = convolution_default_124 = primals_71 = primals_69 = primals_70 = getitem_373 = getitem_374 = None
        getitem_438 = native_batch_norm_backward_default_7[0]
        getitem_439 = native_batch_norm_backward_default_7[1]
        getitem_440 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_438, relu__default_42, primals_72, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1024, [True, True, False]);  getitem_438 = primals_72 = None
        getitem_441 = convolution_backward_default_7[0]
        getitem_442 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_441, torch.float32);  getitem_441 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_136, to_dtype_12);  le_scalar_4 = new_zeros_default_136 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_123, primals_66, primals_64, primals_65, getitem_370, getitem_371, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_123 = primals_66 = primals_64 = primals_65 = getitem_370 = getitem_371 = None
        getitem_444 = native_batch_norm_backward_default_8[0]
        getitem_445 = native_batch_norm_backward_default_8[1]
        getitem_446 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_444, getitem_366, primals_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_444 = getitem_366 = primals_61 = None
        getitem_447 = convolution_backward_default_8[0]
        getitem_448 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(getitem_447, convolution_default_122, primals_59, primals_57, primals_58, getitem_367, getitem_368, True, 1e-05, [True, True, True]);  getitem_447 = convolution_default_122 = primals_59 = primals_57 = primals_58 = getitem_367 = getitem_368 = None
        getitem_450 = native_batch_norm_backward_default_9[0]
        getitem_451 = native_batch_norm_backward_default_9[1]
        getitem_452 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_450, relu__default_41, primals_60, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_450 = primals_60 = None
        getitem_453 = convolution_backward_default_9[0]
        getitem_454 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_453, torch.float32);  getitem_453 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_137, to_dtype_15);  le_scalar_5 = new_zeros_default_137 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_121, primals_54, primals_52, primals_53, getitem_364, getitem_365, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_121 = primals_54 = primals_52 = primals_53 = getitem_364 = getitem_365 = None
        getitem_456 = native_batch_norm_backward_default_10[0]
        getitem_457 = native_batch_norm_backward_default_10[1]
        getitem_458 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_456, getitem_360, primals_49, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_456 = getitem_360 = primals_49 = None
        getitem_459 = convolution_backward_default_10[0]
        getitem_460 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(getitem_459, convolution_default_120, primals_47, primals_45, primals_46, getitem_361, getitem_362, True, 1e-05, [True, True, True]);  getitem_459 = convolution_default_120 = primals_47 = primals_45 = primals_46 = getitem_361 = getitem_362 = None
        getitem_462 = native_batch_norm_backward_default_11[0]
        getitem_463 = native_batch_norm_backward_default_11[1]
        getitem_464 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_462, relu_default_17, primals_48, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_462 = primals_48 = None
        getitem_465 = convolution_backward_default_11[0]
        getitem_466 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_465, torch.float32);  getitem_465 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_17, torch.float32);  relu_default_17 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_138, to_dtype_18);  le_scalar_6 = new_zeros_default_138 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_119, primals_84, primals_82, primals_83, getitem_358, getitem_359, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_119 = primals_84 = primals_82 = primals_83 = getitem_358 = getitem_359 = None
        getitem_468 = native_batch_norm_backward_default_12[0]
        getitem_469 = native_batch_norm_backward_default_12[1]
        getitem_470 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_468, add_tensor_18, primals_79, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_468 = add_tensor_18 = primals_79 = None
        getitem_471 = convolution_backward_default_12[0]
        getitem_472 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(to_dtype_20, getitem_471);  to_dtype_20 = getitem_471 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_20, convolution_default_118, primals_470, primals_468, primals_469, getitem_355, getitem_356, True, 1e-05, [True, True, True]);  convolution_default_118 = primals_470 = primals_468 = primals_469 = getitem_355 = getitem_356 = None
        getitem_474 = native_batch_norm_backward_default_13[0]
        getitem_475 = native_batch_norm_backward_default_13[1]
        getitem_476 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_474, getitem_351, primals_465, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_474 = getitem_351 = primals_465 = None
        getitem_477 = convolution_backward_default_13[0]
        getitem_478 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(getitem_477, convolution_default_117, primals_463, primals_461, primals_462, getitem_352, getitem_353, True, 1e-05, [True, True, True]);  getitem_477 = convolution_default_117 = primals_463 = primals_461 = primals_462 = getitem_352 = getitem_353 = None
        getitem_480 = native_batch_norm_backward_default_14[0]
        getitem_481 = native_batch_norm_backward_default_14[1]
        getitem_482 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_480, relu__default_40, primals_464, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_480 = primals_464 = None
        getitem_483 = convolution_backward_default_14[0]
        getitem_484 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_483, torch.float32);  getitem_483 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_139, to_dtype_21);  le_scalar_7 = new_zeros_default_139 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_116, primals_458, primals_456, primals_457, getitem_349, getitem_350, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_116 = primals_458 = primals_456 = primals_457 = getitem_349 = getitem_350 = None
        getitem_486 = native_batch_norm_backward_default_15[0]
        getitem_487 = native_batch_norm_backward_default_15[1]
        getitem_488 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_486, getitem_345, primals_453, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_486 = getitem_345 = primals_453 = None
        getitem_489 = convolution_backward_default_15[0]
        getitem_490 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_489, convolution_default_115, primals_451, primals_449, primals_450, getitem_346, getitem_347, True, 1e-05, [True, True, True]);  getitem_489 = convolution_default_115 = primals_451 = primals_449 = primals_450 = getitem_346 = getitem_347 = None
        getitem_492 = native_batch_norm_backward_default_16[0]
        getitem_493 = native_batch_norm_backward_default_16[1]
        getitem_494 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_492, relu__default_39, primals_452, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_492 = primals_452 = None
        getitem_495 = convolution_backward_default_16[0]
        getitem_496 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_495, torch.float32);  getitem_495 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_140, to_dtype_24);  le_scalar_8 = new_zeros_default_140 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_114, primals_446, primals_444, primals_445, getitem_343, getitem_344, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_114 = primals_446 = primals_444 = primals_445 = getitem_343 = getitem_344 = None
        getitem_498 = native_batch_norm_backward_default_17[0]
        getitem_499 = native_batch_norm_backward_default_17[1]
        getitem_500 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_498, getitem_339, primals_441, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_498 = getitem_339 = primals_441 = None
        getitem_501 = convolution_backward_default_17[0]
        getitem_502 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(getitem_501, convolution_default_113, primals_439, primals_437, primals_438, getitem_340, getitem_341, True, 1e-05, [True, True, True]);  getitem_501 = convolution_default_113 = primals_439 = primals_437 = primals_438 = getitem_340 = getitem_341 = None
        getitem_504 = native_batch_norm_backward_default_18[0]
        getitem_505 = native_batch_norm_backward_default_18[1]
        getitem_506 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_504, relu_default_16, primals_440, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_504 = primals_440 = None
        getitem_507 = convolution_backward_default_18[0]
        getitem_508 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_507, torch.float32);  getitem_507 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu_default_16, torch.float32);  relu_default_16 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_141, to_dtype_27);  le_scalar_9 = new_zeros_default_141 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, to_dtype_29);  add_tensor_20 = to_dtype_29 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_21, convolution_default_112, primals_434, primals_432, primals_433, getitem_337, getitem_338, True, 1e-05, [True, True, True]);  convolution_default_112 = primals_434 = primals_432 = primals_433 = getitem_337 = getitem_338 = None
        getitem_510 = native_batch_norm_backward_default_19[0]
        getitem_511 = native_batch_norm_backward_default_19[1]
        getitem_512 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_510, getitem_333, primals_429, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_510 = getitem_333 = primals_429 = None
        getitem_513 = convolution_backward_default_19[0]
        getitem_514 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(getitem_513, convolution_default_111, primals_427, primals_425, primals_426, getitem_334, getitem_335, True, 1e-05, [True, True, True]);  getitem_513 = convolution_default_111 = primals_427 = primals_425 = primals_426 = getitem_334 = getitem_335 = None
        getitem_516 = native_batch_norm_backward_default_20[0]
        getitem_517 = native_batch_norm_backward_default_20[1]
        getitem_518 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_516, relu__default_38, primals_428, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_516 = primals_428 = None
        getitem_519 = convolution_backward_default_20[0]
        getitem_520 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_519, torch.float32);  getitem_519 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_142, to_dtype_30);  le_scalar_10 = new_zeros_default_142 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_110, primals_422, primals_420, primals_421, getitem_331, getitem_332, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_110 = primals_422 = primals_420 = primals_421 = getitem_331 = getitem_332 = None
        getitem_522 = native_batch_norm_backward_default_21[0]
        getitem_523 = native_batch_norm_backward_default_21[1]
        getitem_524 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_522, getitem_327, primals_417, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_522 = getitem_327 = primals_417 = None
        getitem_525 = convolution_backward_default_21[0]
        getitem_526 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(getitem_525, convolution_default_109, primals_415, primals_413, primals_414, getitem_328, getitem_329, True, 1e-05, [True, True, True]);  getitem_525 = convolution_default_109 = primals_415 = primals_413 = primals_414 = getitem_328 = getitem_329 = None
        getitem_528 = native_batch_norm_backward_default_22[0]
        getitem_529 = native_batch_norm_backward_default_22[1]
        getitem_530 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_528, relu__default_37, primals_416, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_528 = primals_416 = None
        getitem_531 = convolution_backward_default_22[0]
        getitem_532 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_531, torch.float32);  getitem_531 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_143, to_dtype_33);  le_scalar_11 = new_zeros_default_143 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_108, primals_410, primals_408, primals_409, getitem_325, getitem_326, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_108 = primals_410 = primals_408 = primals_409 = getitem_325 = getitem_326 = None
        getitem_534 = native_batch_norm_backward_default_23[0]
        getitem_535 = native_batch_norm_backward_default_23[1]
        getitem_536 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_534, getitem_321, primals_405, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_534 = getitem_321 = primals_405 = None
        getitem_537 = convolution_backward_default_23[0]
        getitem_538 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(getitem_537, convolution_default_107, primals_403, primals_401, primals_402, getitem_322, getitem_323, True, 1e-05, [True, True, True]);  getitem_537 = convolution_default_107 = primals_403 = primals_401 = primals_402 = getitem_322 = getitem_323 = None
        getitem_540 = native_batch_norm_backward_default_24[0]
        getitem_541 = native_batch_norm_backward_default_24[1]
        getitem_542 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_540, relu_default_15, primals_404, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_540 = primals_404 = None
        getitem_543 = convolution_backward_default_24[0]
        getitem_544 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_543, torch.float32);  getitem_543 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu_default_15, torch.float32);  relu_default_15 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_144, to_dtype_36);  le_scalar_12 = new_zeros_default_144 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, to_dtype_38);  add_tensor_21 = to_dtype_38 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_22, convolution_default_106, primals_398, primals_396, primals_397, getitem_319, getitem_320, True, 1e-05, [True, True, True]);  convolution_default_106 = primals_398 = primals_396 = primals_397 = getitem_319 = getitem_320 = None
        getitem_546 = native_batch_norm_backward_default_25[0]
        getitem_547 = native_batch_norm_backward_default_25[1]
        getitem_548 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_546, getitem_315, primals_393, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_546 = getitem_315 = primals_393 = None
        getitem_549 = convolution_backward_default_25[0]
        getitem_550 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(getitem_549, convolution_default_105, primals_391, primals_389, primals_390, getitem_316, getitem_317, True, 1e-05, [True, True, True]);  getitem_549 = convolution_default_105 = primals_391 = primals_389 = primals_390 = getitem_316 = getitem_317 = None
        getitem_552 = native_batch_norm_backward_default_26[0]
        getitem_553 = native_batch_norm_backward_default_26[1]
        getitem_554 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_552, relu__default_36, primals_392, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_552 = primals_392 = None
        getitem_555 = convolution_backward_default_26[0]
        getitem_556 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_555, torch.float32);  getitem_555 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_145, to_dtype_39);  le_scalar_13 = new_zeros_default_145 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_104, primals_386, primals_384, primals_385, getitem_313, getitem_314, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_104 = primals_386 = primals_384 = primals_385 = getitem_313 = getitem_314 = None
        getitem_558 = native_batch_norm_backward_default_27[0]
        getitem_559 = native_batch_norm_backward_default_27[1]
        getitem_560 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_558, getitem_309, primals_381, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_558 = getitem_309 = primals_381 = None
        getitem_561 = convolution_backward_default_27[0]
        getitem_562 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(getitem_561, convolution_default_103, primals_379, primals_377, primals_378, getitem_310, getitem_311, True, 1e-05, [True, True, True]);  getitem_561 = convolution_default_103 = primals_379 = primals_377 = primals_378 = getitem_310 = getitem_311 = None
        getitem_564 = native_batch_norm_backward_default_28[0]
        getitem_565 = native_batch_norm_backward_default_28[1]
        getitem_566 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_564, relu__default_35, primals_380, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_564 = primals_380 = None
        getitem_567 = convolution_backward_default_28[0]
        getitem_568 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_567, torch.float32);  getitem_567 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_146, to_dtype_42);  le_scalar_14 = new_zeros_default_146 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_102, primals_374, primals_372, primals_373, getitem_307, getitem_308, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_102 = primals_374 = primals_372 = primals_373 = getitem_307 = getitem_308 = None
        getitem_570 = native_batch_norm_backward_default_29[0]
        getitem_571 = native_batch_norm_backward_default_29[1]
        getitem_572 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_570, getitem_303, primals_369, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_570 = getitem_303 = primals_369 = None
        getitem_573 = convolution_backward_default_29[0]
        getitem_574 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(getitem_573, convolution_default_101, primals_367, primals_365, primals_366, getitem_304, getitem_305, True, 1e-05, [True, True, True]);  getitem_573 = convolution_default_101 = primals_367 = primals_365 = primals_366 = getitem_304 = getitem_305 = None
        getitem_576 = native_batch_norm_backward_default_30[0]
        getitem_577 = native_batch_norm_backward_default_30[1]
        getitem_578 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_576, relu_default_14, primals_368, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_576 = primals_368 = None
        getitem_579 = convolution_backward_default_30[0]
        getitem_580 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_579, torch.float32);  getitem_579 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu_default_14, torch.float32);  relu_default_14 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_147, to_dtype_45);  le_scalar_15 = new_zeros_default_147 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_22, to_dtype_47);  add_tensor_22 = to_dtype_47 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_23, convolution_default_100, primals_362, primals_360, primals_361, getitem_301, getitem_302, True, 1e-05, [True, True, True]);  convolution_default_100 = primals_362 = primals_360 = primals_361 = getitem_301 = getitem_302 = None
        getitem_582 = native_batch_norm_backward_default_31[0]
        getitem_583 = native_batch_norm_backward_default_31[1]
        getitem_584 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_582, getitem_297, primals_357, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_582 = getitem_297 = primals_357 = None
        getitem_585 = convolution_backward_default_31[0]
        getitem_586 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(getitem_585, convolution_default_99, primals_355, primals_353, primals_354, getitem_298, getitem_299, True, 1e-05, [True, True, True]);  getitem_585 = convolution_default_99 = primals_355 = primals_353 = primals_354 = getitem_298 = getitem_299 = None
        getitem_588 = native_batch_norm_backward_default_32[0]
        getitem_589 = native_batch_norm_backward_default_32[1]
        getitem_590 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_588, relu__default_34, primals_356, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_588 = primals_356 = None
        getitem_591 = convolution_backward_default_32[0]
        getitem_592 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_591, torch.float32);  getitem_591 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_148, to_dtype_48);  le_scalar_16 = new_zeros_default_148 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_98, primals_350, primals_348, primals_349, getitem_295, getitem_296, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_98 = primals_350 = primals_348 = primals_349 = getitem_295 = getitem_296 = None
        getitem_594 = native_batch_norm_backward_default_33[0]
        getitem_595 = native_batch_norm_backward_default_33[1]
        getitem_596 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_594, getitem_291, primals_345, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_594 = getitem_291 = primals_345 = None
        getitem_597 = convolution_backward_default_33[0]
        getitem_598 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(getitem_597, convolution_default_97, primals_343, primals_341, primals_342, getitem_292, getitem_293, True, 1e-05, [True, True, True]);  getitem_597 = convolution_default_97 = primals_343 = primals_341 = primals_342 = getitem_292 = getitem_293 = None
        getitem_600 = native_batch_norm_backward_default_34[0]
        getitem_601 = native_batch_norm_backward_default_34[1]
        getitem_602 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_600, relu__default_33, primals_344, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_600 = primals_344 = None
        getitem_603 = convolution_backward_default_34[0]
        getitem_604 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_603, torch.float32);  getitem_603 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_149, to_dtype_51);  le_scalar_17 = new_zeros_default_149 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_96, primals_338, primals_336, primals_337, getitem_289, getitem_290, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_96 = primals_338 = primals_336 = primals_337 = getitem_289 = getitem_290 = None
        getitem_606 = native_batch_norm_backward_default_35[0]
        getitem_607 = native_batch_norm_backward_default_35[1]
        getitem_608 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_606, getitem_285, primals_333, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_606 = getitem_285 = primals_333 = None
        getitem_609 = convolution_backward_default_35[0]
        getitem_610 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(getitem_609, convolution_default_95, primals_331, primals_329, primals_330, getitem_286, getitem_287, True, 1e-05, [True, True, True]);  getitem_609 = convolution_default_95 = primals_331 = primals_329 = primals_330 = getitem_286 = getitem_287 = None
        getitem_612 = native_batch_norm_backward_default_36[0]
        getitem_613 = native_batch_norm_backward_default_36[1]
        getitem_614 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_612, relu_default_13, primals_332, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_612 = primals_332 = None
        getitem_615 = convolution_backward_default_36[0]
        getitem_616 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_615, torch.float32);  getitem_615 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu_default_13, torch.float32);  relu_default_13 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_150, to_dtype_54);  le_scalar_18 = new_zeros_default_150 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, to_dtype_56);  add_tensor_23 = to_dtype_56 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_24, convolution_default_94, primals_326, primals_324, primals_325, getitem_283, getitem_284, True, 1e-05, [True, True, True]);  convolution_default_94 = primals_326 = primals_324 = primals_325 = getitem_283 = getitem_284 = None
        getitem_618 = native_batch_norm_backward_default_37[0]
        getitem_619 = native_batch_norm_backward_default_37[1]
        getitem_620 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_618, getitem_279, primals_321, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_618 = getitem_279 = primals_321 = None
        getitem_621 = convolution_backward_default_37[0]
        getitem_622 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(getitem_621, convolution_default_93, primals_319, primals_317, primals_318, getitem_280, getitem_281, True, 1e-05, [True, True, True]);  getitem_621 = convolution_default_93 = primals_319 = primals_317 = primals_318 = getitem_280 = getitem_281 = None
        getitem_624 = native_batch_norm_backward_default_38[0]
        getitem_625 = native_batch_norm_backward_default_38[1]
        getitem_626 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_624, relu__default_32, primals_320, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_624 = primals_320 = None
        getitem_627 = convolution_backward_default_38[0]
        getitem_628 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_627, torch.float32);  getitem_627 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_151, to_dtype_57);  le_scalar_19 = new_zeros_default_151 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_92, primals_314, primals_312, primals_313, getitem_277, getitem_278, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_92 = primals_314 = primals_312 = primals_313 = getitem_277 = getitem_278 = None
        getitem_630 = native_batch_norm_backward_default_39[0]
        getitem_631 = native_batch_norm_backward_default_39[1]
        getitem_632 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_630, getitem_273, primals_309, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_630 = getitem_273 = primals_309 = None
        getitem_633 = convolution_backward_default_39[0]
        getitem_634 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(getitem_633, convolution_default_91, primals_307, primals_305, primals_306, getitem_274, getitem_275, True, 1e-05, [True, True, True]);  getitem_633 = convolution_default_91 = primals_307 = primals_305 = primals_306 = getitem_274 = getitem_275 = None
        getitem_636 = native_batch_norm_backward_default_40[0]
        getitem_637 = native_batch_norm_backward_default_40[1]
        getitem_638 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_636, relu__default_31, primals_308, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_636 = primals_308 = None
        getitem_639 = convolution_backward_default_40[0]
        getitem_640 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_639, torch.float32);  getitem_639 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_152, to_dtype_60);  le_scalar_20 = new_zeros_default_152 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_90, primals_302, primals_300, primals_301, getitem_271, getitem_272, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_90 = primals_302 = primals_300 = primals_301 = getitem_271 = getitem_272 = None
        getitem_642 = native_batch_norm_backward_default_41[0]
        getitem_643 = native_batch_norm_backward_default_41[1]
        getitem_644 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_642, getitem_267, primals_297, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_642 = getitem_267 = primals_297 = None
        getitem_645 = convolution_backward_default_41[0]
        getitem_646 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(getitem_645, convolution_default_89, primals_295, primals_293, primals_294, getitem_268, getitem_269, True, 1e-05, [True, True, True]);  getitem_645 = convolution_default_89 = primals_295 = primals_293 = primals_294 = getitem_268 = getitem_269 = None
        getitem_648 = native_batch_norm_backward_default_42[0]
        getitem_649 = native_batch_norm_backward_default_42[1]
        getitem_650 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_648, relu_default_12, primals_296, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_648 = primals_296 = None
        getitem_651 = convolution_backward_default_42[0]
        getitem_652 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_651, torch.float32);  getitem_651 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_153, to_dtype_63);  le_scalar_21 = new_zeros_default_153 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, to_dtype_65);  add_tensor_24 = to_dtype_65 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_25, convolution_default_88, primals_290, primals_288, primals_289, getitem_265, getitem_266, True, 1e-05, [True, True, True]);  convolution_default_88 = primals_290 = primals_288 = primals_289 = getitem_265 = getitem_266 = None
        getitem_654 = native_batch_norm_backward_default_43[0]
        getitem_655 = native_batch_norm_backward_default_43[1]
        getitem_656 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_654, getitem_261, primals_285, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_654 = getitem_261 = primals_285 = None
        getitem_657 = convolution_backward_default_43[0]
        getitem_658 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(getitem_657, convolution_default_87, primals_283, primals_281, primals_282, getitem_262, getitem_263, True, 1e-05, [True, True, True]);  getitem_657 = convolution_default_87 = primals_283 = primals_281 = primals_282 = getitem_262 = getitem_263 = None
        getitem_660 = native_batch_norm_backward_default_44[0]
        getitem_661 = native_batch_norm_backward_default_44[1]
        getitem_662 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_660, relu__default_30, primals_284, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_660 = primals_284 = None
        getitem_663 = convolution_backward_default_44[0]
        getitem_664 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_663, torch.float32);  getitem_663 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_154, to_dtype_66);  le_scalar_22 = new_zeros_default_154 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_86, primals_278, primals_276, primals_277, getitem_259, getitem_260, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_86 = primals_278 = primals_276 = primals_277 = getitem_259 = getitem_260 = None
        getitem_666 = native_batch_norm_backward_default_45[0]
        getitem_667 = native_batch_norm_backward_default_45[1]
        getitem_668 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_666, getitem_255, primals_273, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_666 = getitem_255 = primals_273 = None
        getitem_669 = convolution_backward_default_45[0]
        getitem_670 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(getitem_669, convolution_default_85, primals_271, primals_269, primals_270, getitem_256, getitem_257, True, 1e-05, [True, True, True]);  getitem_669 = convolution_default_85 = primals_271 = primals_269 = primals_270 = getitem_256 = getitem_257 = None
        getitem_672 = native_batch_norm_backward_default_46[0]
        getitem_673 = native_batch_norm_backward_default_46[1]
        getitem_674 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_672, relu__default_29, primals_272, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_672 = primals_272 = None
        getitem_675 = convolution_backward_default_46[0]
        getitem_676 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_675, torch.float32);  getitem_675 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_155, to_dtype_69);  le_scalar_23 = new_zeros_default_155 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_84, primals_266, primals_264, primals_265, getitem_253, getitem_254, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_84 = primals_266 = primals_264 = primals_265 = getitem_253 = getitem_254 = None
        getitem_678 = native_batch_norm_backward_default_47[0]
        getitem_679 = native_batch_norm_backward_default_47[1]
        getitem_680 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_678, getitem_249, primals_261, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_678 = getitem_249 = primals_261 = None
        getitem_681 = convolution_backward_default_47[0]
        getitem_682 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(getitem_681, convolution_default_83, primals_259, primals_257, primals_258, getitem_250, getitem_251, True, 1e-05, [True, True, True]);  getitem_681 = convolution_default_83 = primals_259 = primals_257 = primals_258 = getitem_250 = getitem_251 = None
        getitem_684 = native_batch_norm_backward_default_48[0]
        getitem_685 = native_batch_norm_backward_default_48[1]
        getitem_686 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_684, relu_default_11, primals_260, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_684 = primals_260 = None
        getitem_687 = convolution_backward_default_48[0]
        getitem_688 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_687, torch.float32);  getitem_687 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_156, to_dtype_72);  le_scalar_24 = new_zeros_default_156 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(add_tensor_25, to_dtype_74);  add_tensor_25 = to_dtype_74 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_26, convolution_default_82, primals_794, primals_792, primals_793, getitem_247, getitem_248, True, 1e-05, [True, True, True]);  convolution_default_82 = primals_794 = primals_792 = primals_793 = getitem_247 = getitem_248 = None
        getitem_690 = native_batch_norm_backward_default_49[0]
        getitem_691 = native_batch_norm_backward_default_49[1]
        getitem_692 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_690, getitem_243, primals_789, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_690 = getitem_243 = primals_789 = None
        getitem_693 = convolution_backward_default_49[0]
        getitem_694 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(getitem_693, convolution_default_81, primals_787, primals_785, primals_786, getitem_244, getitem_245, True, 1e-05, [True, True, True]);  getitem_693 = convolution_default_81 = primals_787 = primals_785 = primals_786 = getitem_244 = getitem_245 = None
        getitem_696 = native_batch_norm_backward_default_50[0]
        getitem_697 = native_batch_norm_backward_default_50[1]
        getitem_698 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_696, relu__default_28, primals_788, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_696 = primals_788 = None
        getitem_699 = convolution_backward_default_50[0]
        getitem_700 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_699, torch.float32);  getitem_699 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_157, to_dtype_75);  le_scalar_25 = new_zeros_default_157 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_80, primals_782, primals_780, primals_781, getitem_241, getitem_242, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_80 = primals_782 = primals_780 = primals_781 = getitem_241 = getitem_242 = None
        getitem_702 = native_batch_norm_backward_default_51[0]
        getitem_703 = native_batch_norm_backward_default_51[1]
        getitem_704 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_702, getitem_237, primals_777, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_702 = getitem_237 = primals_777 = None
        getitem_705 = convolution_backward_default_51[0]
        getitem_706 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(getitem_705, convolution_default_79, primals_775, primals_773, primals_774, getitem_238, getitem_239, True, 1e-05, [True, True, True]);  getitem_705 = convolution_default_79 = primals_775 = primals_773 = primals_774 = getitem_238 = getitem_239 = None
        getitem_708 = native_batch_norm_backward_default_52[0]
        getitem_709 = native_batch_norm_backward_default_52[1]
        getitem_710 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_708, relu__default_27, primals_776, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_708 = primals_776 = None
        getitem_711 = convolution_backward_default_52[0]
        getitem_712 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_711, torch.float32);  getitem_711 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_158, to_dtype_78);  le_scalar_26 = new_zeros_default_158 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_78, primals_770, primals_768, primals_769, getitem_235, getitem_236, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_78 = primals_770 = primals_768 = primals_769 = getitem_235 = getitem_236 = None
        getitem_714 = native_batch_norm_backward_default_53[0]
        getitem_715 = native_batch_norm_backward_default_53[1]
        getitem_716 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_714, getitem_231, primals_765, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_714 = getitem_231 = primals_765 = None
        getitem_717 = convolution_backward_default_53[0]
        getitem_718 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(getitem_717, convolution_default_77, primals_763, primals_761, primals_762, getitem_232, getitem_233, True, 1e-05, [True, True, True]);  getitem_717 = convolution_default_77 = primals_763 = primals_761 = primals_762 = getitem_232 = getitem_233 = None
        getitem_720 = native_batch_norm_backward_default_54[0]
        getitem_721 = native_batch_norm_backward_default_54[1]
        getitem_722 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_720, relu_default_10, primals_764, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_720 = primals_764 = None
        getitem_723 = convolution_backward_default_54[0]
        getitem_724 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_723, torch.float32);  getitem_723 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_159, to_dtype_81);  le_scalar_27 = new_zeros_default_159 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, to_dtype_83);  add_tensor_26 = to_dtype_83 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_27, convolution_default_76, primals_758, primals_756, primals_757, getitem_229, getitem_230, True, 1e-05, [True, True, True]);  convolution_default_76 = primals_758 = primals_756 = primals_757 = getitem_229 = getitem_230 = None
        getitem_726 = native_batch_norm_backward_default_55[0]
        getitem_727 = native_batch_norm_backward_default_55[1]
        getitem_728 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_726, getitem_225, primals_753, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_726 = getitem_225 = primals_753 = None
        getitem_729 = convolution_backward_default_55[0]
        getitem_730 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(getitem_729, convolution_default_75, primals_751, primals_749, primals_750, getitem_226, getitem_227, True, 1e-05, [True, True, True]);  getitem_729 = convolution_default_75 = primals_751 = primals_749 = primals_750 = getitem_226 = getitem_227 = None
        getitem_732 = native_batch_norm_backward_default_56[0]
        getitem_733 = native_batch_norm_backward_default_56[1]
        getitem_734 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_732, relu__default_26, primals_752, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_732 = primals_752 = None
        getitem_735 = convolution_backward_default_56[0]
        getitem_736 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_735, torch.float32);  getitem_735 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_160, to_dtype_84);  le_scalar_28 = new_zeros_default_160 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_74, primals_746, primals_744, primals_745, getitem_223, getitem_224, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_74 = primals_746 = primals_744 = primals_745 = getitem_223 = getitem_224 = None
        getitem_738 = native_batch_norm_backward_default_57[0]
        getitem_739 = native_batch_norm_backward_default_57[1]
        getitem_740 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_738, getitem_219, primals_741, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_738 = getitem_219 = primals_741 = None
        getitem_741 = convolution_backward_default_57[0]
        getitem_742 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(getitem_741, convolution_default_73, primals_739, primals_737, primals_738, getitem_220, getitem_221, True, 1e-05, [True, True, True]);  getitem_741 = convolution_default_73 = primals_739 = primals_737 = primals_738 = getitem_220 = getitem_221 = None
        getitem_744 = native_batch_norm_backward_default_58[0]
        getitem_745 = native_batch_norm_backward_default_58[1]
        getitem_746 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_744, relu__default_25, primals_740, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_744 = primals_740 = None
        getitem_747 = convolution_backward_default_58[0]
        getitem_748 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_747, torch.float32);  getitem_747 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_161, to_dtype_87);  le_scalar_29 = new_zeros_default_161 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_72, primals_734, primals_732, primals_733, getitem_217, getitem_218, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_72 = primals_734 = primals_732 = primals_733 = getitem_217 = getitem_218 = None
        getitem_750 = native_batch_norm_backward_default_59[0]
        getitem_751 = native_batch_norm_backward_default_59[1]
        getitem_752 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_750, getitem_213, primals_729, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_750 = getitem_213 = primals_729 = None
        getitem_753 = convolution_backward_default_59[0]
        getitem_754 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(getitem_753, convolution_default_71, primals_727, primals_725, primals_726, getitem_214, getitem_215, True, 1e-05, [True, True, True]);  getitem_753 = convolution_default_71 = primals_727 = primals_725 = primals_726 = getitem_214 = getitem_215 = None
        getitem_756 = native_batch_norm_backward_default_60[0]
        getitem_757 = native_batch_norm_backward_default_60[1]
        getitem_758 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_756, relu_default_9, primals_728, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_756 = primals_728 = None
        getitem_759 = convolution_backward_default_60[0]
        getitem_760 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_759, torch.float32);  getitem_759 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_162, to_dtype_90);  le_scalar_30 = new_zeros_default_162 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, to_dtype_92);  add_tensor_27 = to_dtype_92 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_28, convolution_default_70, primals_722, primals_720, primals_721, getitem_211, getitem_212, True, 1e-05, [True, True, True]);  convolution_default_70 = primals_722 = primals_720 = primals_721 = getitem_211 = getitem_212 = None
        getitem_762 = native_batch_norm_backward_default_61[0]
        getitem_763 = native_batch_norm_backward_default_61[1]
        getitem_764 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_762, getitem_207, primals_717, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_762 = getitem_207 = primals_717 = None
        getitem_765 = convolution_backward_default_61[0]
        getitem_766 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(getitem_765, convolution_default_69, primals_715, primals_713, primals_714, getitem_208, getitem_209, True, 1e-05, [True, True, True]);  getitem_765 = convolution_default_69 = primals_715 = primals_713 = primals_714 = getitem_208 = getitem_209 = None
        getitem_768 = native_batch_norm_backward_default_62[0]
        getitem_769 = native_batch_norm_backward_default_62[1]
        getitem_770 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_768, relu__default_24, primals_716, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_768 = primals_716 = None
        getitem_771 = convolution_backward_default_62[0]
        getitem_772 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_771, torch.float32);  getitem_771 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_163, to_dtype_93);  le_scalar_31 = new_zeros_default_163 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_68, primals_710, primals_708, primals_709, getitem_205, getitem_206, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_68 = primals_710 = primals_708 = primals_709 = getitem_205 = getitem_206 = None
        getitem_774 = native_batch_norm_backward_default_63[0]
        getitem_775 = native_batch_norm_backward_default_63[1]
        getitem_776 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_774, getitem_201, primals_705, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_774 = getitem_201 = primals_705 = None
        getitem_777 = convolution_backward_default_63[0]
        getitem_778 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(getitem_777, convolution_default_67, primals_703, primals_701, primals_702, getitem_202, getitem_203, True, 1e-05, [True, True, True]);  getitem_777 = convolution_default_67 = primals_703 = primals_701 = primals_702 = getitem_202 = getitem_203 = None
        getitem_780 = native_batch_norm_backward_default_64[0]
        getitem_781 = native_batch_norm_backward_default_64[1]
        getitem_782 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_780, relu__default_23, primals_704, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_780 = primals_704 = None
        getitem_783 = convolution_backward_default_64[0]
        getitem_784 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_783, torch.float32);  getitem_783 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_164, to_dtype_96);  le_scalar_32 = new_zeros_default_164 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_66, primals_698, primals_696, primals_697, getitem_199, getitem_200, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_66 = primals_698 = primals_696 = primals_697 = getitem_199 = getitem_200 = None
        getitem_786 = native_batch_norm_backward_default_65[0]
        getitem_787 = native_batch_norm_backward_default_65[1]
        getitem_788 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_786, getitem_195, primals_693, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_786 = getitem_195 = primals_693 = None
        getitem_789 = convolution_backward_default_65[0]
        getitem_790 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(getitem_789, convolution_default_65, primals_691, primals_689, primals_690, getitem_196, getitem_197, True, 1e-05, [True, True, True]);  getitem_789 = convolution_default_65 = primals_691 = primals_689 = primals_690 = getitem_196 = getitem_197 = None
        getitem_792 = native_batch_norm_backward_default_66[0]
        getitem_793 = native_batch_norm_backward_default_66[1]
        getitem_794 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_792, relu_default_8, primals_692, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_792 = primals_692 = None
        getitem_795 = convolution_backward_default_66[0]
        getitem_796 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_795, torch.float32);  getitem_795 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_165, to_dtype_99);  le_scalar_33 = new_zeros_default_165 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(add_tensor_28, to_dtype_101);  add_tensor_28 = to_dtype_101 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_29, convolution_default_64, primals_686, primals_684, primals_685, getitem_193, getitem_194, True, 1e-05, [True, True, True]);  convolution_default_64 = primals_686 = primals_684 = primals_685 = getitem_193 = getitem_194 = None
        getitem_798 = native_batch_norm_backward_default_67[0]
        getitem_799 = native_batch_norm_backward_default_67[1]
        getitem_800 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_798, getitem_189, primals_681, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_798 = getitem_189 = primals_681 = None
        getitem_801 = convolution_backward_default_67[0]
        getitem_802 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(getitem_801, convolution_default_63, primals_679, primals_677, primals_678, getitem_190, getitem_191, True, 1e-05, [True, True, True]);  getitem_801 = convolution_default_63 = primals_679 = primals_677 = primals_678 = getitem_190 = getitem_191 = None
        getitem_804 = native_batch_norm_backward_default_68[0]
        getitem_805 = native_batch_norm_backward_default_68[1]
        getitem_806 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_804, relu__default_22, primals_680, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_804 = primals_680 = None
        getitem_807 = convolution_backward_default_68[0]
        getitem_808 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_807, torch.float32);  getitem_807 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_166, to_dtype_102);  le_scalar_34 = new_zeros_default_166 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_62, primals_674, primals_672, primals_673, getitem_187, getitem_188, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_62 = primals_674 = primals_672 = primals_673 = getitem_187 = getitem_188 = None
        getitem_810 = native_batch_norm_backward_default_69[0]
        getitem_811 = native_batch_norm_backward_default_69[1]
        getitem_812 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_810, getitem_183, primals_669, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_810 = getitem_183 = primals_669 = None
        getitem_813 = convolution_backward_default_69[0]
        getitem_814 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(getitem_813, convolution_default_61, primals_667, primals_665, primals_666, getitem_184, getitem_185, True, 1e-05, [True, True, True]);  getitem_813 = convolution_default_61 = primals_667 = primals_665 = primals_666 = getitem_184 = getitem_185 = None
        getitem_816 = native_batch_norm_backward_default_70[0]
        getitem_817 = native_batch_norm_backward_default_70[1]
        getitem_818 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_816, relu__default_21, primals_668, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_816 = primals_668 = None
        getitem_819 = convolution_backward_default_70[0]
        getitem_820 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_819, torch.float32);  getitem_819 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_167, to_dtype_105);  le_scalar_35 = new_zeros_default_167 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_60, primals_662, primals_660, primals_661, getitem_181, getitem_182, True, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_60 = primals_662 = primals_660 = primals_661 = getitem_181 = getitem_182 = None
        getitem_822 = native_batch_norm_backward_default_71[0]
        getitem_823 = native_batch_norm_backward_default_71[1]
        getitem_824 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_822, getitem_177, primals_657, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_822 = getitem_177 = primals_657 = None
        getitem_825 = convolution_backward_default_71[0]
        getitem_826 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(getitem_825, convolution_default_59, primals_655, primals_653, primals_654, getitem_178, getitem_179, True, 1e-05, [True, True, True]);  getitem_825 = convolution_default_59 = primals_655 = primals_653 = primals_654 = getitem_178 = getitem_179 = None
        getitem_828 = native_batch_norm_backward_default_72[0]
        getitem_829 = native_batch_norm_backward_default_72[1]
        getitem_830 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_828, relu_default_7, primals_656, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_828 = primals_656 = None
        getitem_831 = convolution_backward_default_72[0]
        getitem_832 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_831, torch.float32);  getitem_831 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_168, to_dtype_108);  le_scalar_36 = new_zeros_default_168 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_29, to_dtype_110);  add_tensor_29 = to_dtype_110 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_30, convolution_default_58, primals_650, primals_648, primals_649, getitem_175, getitem_176, True, 1e-05, [True, True, True]);  convolution_default_58 = primals_650 = primals_648 = primals_649 = getitem_175 = getitem_176 = None
        getitem_834 = native_batch_norm_backward_default_73[0]
        getitem_835 = native_batch_norm_backward_default_73[1]
        getitem_836 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_834, getitem_171, primals_645, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_834 = getitem_171 = primals_645 = None
        getitem_837 = convolution_backward_default_73[0]
        getitem_838 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(getitem_837, convolution_default_57, primals_643, primals_641, primals_642, getitem_172, getitem_173, True, 1e-05, [True, True, True]);  getitem_837 = convolution_default_57 = primals_643 = primals_641 = primals_642 = getitem_172 = getitem_173 = None
        getitem_840 = native_batch_norm_backward_default_74[0]
        getitem_841 = native_batch_norm_backward_default_74[1]
        getitem_842 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_840, relu__default_20, primals_644, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_840 = primals_644 = None
        getitem_843 = convolution_backward_default_74[0]
        getitem_844 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_843, torch.float32);  getitem_843 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_169, to_dtype_111);  le_scalar_37 = new_zeros_default_169 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_56, primals_638, primals_636, primals_637, getitem_169, getitem_170, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_56 = primals_638 = primals_636 = primals_637 = getitem_169 = getitem_170 = None
        getitem_846 = native_batch_norm_backward_default_75[0]
        getitem_847 = native_batch_norm_backward_default_75[1]
        getitem_848 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_846, getitem_165, primals_633, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_846 = getitem_165 = primals_633 = None
        getitem_849 = convolution_backward_default_75[0]
        getitem_850 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(getitem_849, convolution_default_55, primals_631, primals_629, primals_630, getitem_166, getitem_167, True, 1e-05, [True, True, True]);  getitem_849 = convolution_default_55 = primals_631 = primals_629 = primals_630 = getitem_166 = getitem_167 = None
        getitem_852 = native_batch_norm_backward_default_76[0]
        getitem_853 = native_batch_norm_backward_default_76[1]
        getitem_854 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_852, relu__default_19, primals_632, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_852 = primals_632 = None
        getitem_855 = convolution_backward_default_76[0]
        getitem_856 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_855, torch.float32);  getitem_855 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_170, to_dtype_114);  le_scalar_38 = new_zeros_default_170 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_54, primals_626, primals_624, primals_625, getitem_163, getitem_164, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_54 = primals_626 = primals_624 = primals_625 = getitem_163 = getitem_164 = None
        getitem_858 = native_batch_norm_backward_default_77[0]
        getitem_859 = native_batch_norm_backward_default_77[1]
        getitem_860 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_858, getitem_159, primals_621, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_858 = getitem_159 = primals_621 = None
        getitem_861 = convolution_backward_default_77[0]
        getitem_862 = convolution_backward_default_77[1];  convolution_backward_default_77 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(getitem_861, convolution_default_53, primals_619, primals_617, primals_618, getitem_160, getitem_161, True, 1e-05, [True, True, True]);  getitem_861 = convolution_default_53 = primals_619 = primals_617 = primals_618 = getitem_160 = getitem_161 = None
        getitem_864 = native_batch_norm_backward_default_78[0]
        getitem_865 = native_batch_norm_backward_default_78[1]
        getitem_866 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_864, relu_default_6, primals_620, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_864 = primals_620 = None
        getitem_867 = convolution_backward_default_78[0]
        getitem_868 = convolution_backward_default_78[1];  convolution_backward_default_78 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_867, torch.float32);  getitem_867 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_171, to_dtype_117);  le_scalar_39 = new_zeros_default_171 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, to_dtype_119);  add_tensor_30 = to_dtype_119 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_31, convolution_default_52, primals_614, primals_612, primals_613, getitem_157, getitem_158, True, 1e-05, [True, True, True]);  convolution_default_52 = primals_614 = primals_612 = primals_613 = getitem_157 = getitem_158 = None
        getitem_870 = native_batch_norm_backward_default_79[0]
        getitem_871 = native_batch_norm_backward_default_79[1]
        getitem_872 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_870, getitem_153, primals_609, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_870 = getitem_153 = primals_609 = None
        getitem_873 = convolution_backward_default_79[0]
        getitem_874 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(getitem_873, convolution_default_51, primals_607, primals_605, primals_606, getitem_154, getitem_155, True, 1e-05, [True, True, True]);  getitem_873 = convolution_default_51 = primals_607 = primals_605 = primals_606 = getitem_154 = getitem_155 = None
        getitem_876 = native_batch_norm_backward_default_80[0]
        getitem_877 = native_batch_norm_backward_default_80[1]
        getitem_878 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_876, relu__default_18, primals_608, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_876 = primals_608 = None
        getitem_879 = convolution_backward_default_80[0]
        getitem_880 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_879, torch.float32);  getitem_879 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_172, to_dtype_120);  le_scalar_40 = new_zeros_default_172 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_50, primals_602, primals_600, primals_601, getitem_151, getitem_152, True, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_50 = primals_602 = primals_600 = primals_601 = getitem_151 = getitem_152 = None
        getitem_882 = native_batch_norm_backward_default_81[0]
        getitem_883 = native_batch_norm_backward_default_81[1]
        getitem_884 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_882, getitem_147, primals_597, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_882 = getitem_147 = primals_597 = None
        getitem_885 = convolution_backward_default_81[0]
        getitem_886 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(getitem_885, convolution_default_49, primals_595, primals_593, primals_594, getitem_148, getitem_149, True, 1e-05, [True, True, True]);  getitem_885 = convolution_default_49 = primals_595 = primals_593 = primals_594 = getitem_148 = getitem_149 = None
        getitem_888 = native_batch_norm_backward_default_82[0]
        getitem_889 = native_batch_norm_backward_default_82[1]
        getitem_890 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_888, relu__default_17, primals_596, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_888 = primals_596 = None
        getitem_891 = convolution_backward_default_82[0]
        getitem_892 = convolution_backward_default_82[1];  convolution_backward_default_82 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_891, torch.float32);  getitem_891 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_173, to_dtype_123);  le_scalar_41 = new_zeros_default_173 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_48, primals_590, primals_588, primals_589, getitem_145, getitem_146, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_48 = primals_590 = primals_588 = primals_589 = getitem_145 = getitem_146 = None
        getitem_894 = native_batch_norm_backward_default_83[0]
        getitem_895 = native_batch_norm_backward_default_83[1]
        getitem_896 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_894, getitem_141, primals_585, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_894 = getitem_141 = primals_585 = None
        getitem_897 = convolution_backward_default_83[0]
        getitem_898 = convolution_backward_default_83[1];  convolution_backward_default_83 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(getitem_897, convolution_default_47, primals_583, primals_581, primals_582, getitem_142, getitem_143, True, 1e-05, [True, True, True]);  getitem_897 = convolution_default_47 = primals_583 = primals_581 = primals_582 = getitem_142 = getitem_143 = None
        getitem_900 = native_batch_norm_backward_default_84[0]
        getitem_901 = native_batch_norm_backward_default_84[1]
        getitem_902 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_900, relu_default_5, primals_584, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_900 = primals_584 = None
        getitem_903 = convolution_backward_default_84[0]
        getitem_904 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_903, torch.float32);  getitem_903 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_174, to_dtype_126);  le_scalar_42 = new_zeros_default_174 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(add_tensor_31, to_dtype_128);  add_tensor_31 = to_dtype_128 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_32, convolution_default_46, primals_578, primals_576, primals_577, getitem_139, getitem_140, True, 1e-05, [True, True, True]);  convolution_default_46 = primals_578 = primals_576 = primals_577 = getitem_139 = getitem_140 = None
        getitem_906 = native_batch_norm_backward_default_85[0]
        getitem_907 = native_batch_norm_backward_default_85[1]
        getitem_908 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_906, getitem_135, primals_573, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_906 = getitem_135 = primals_573 = None
        getitem_909 = convolution_backward_default_85[0]
        getitem_910 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(getitem_909, convolution_default_45, primals_571, primals_569, primals_570, getitem_136, getitem_137, True, 1e-05, [True, True, True]);  getitem_909 = convolution_default_45 = primals_571 = primals_569 = primals_570 = getitem_136 = getitem_137 = None
        getitem_912 = native_batch_norm_backward_default_86[0]
        getitem_913 = native_batch_norm_backward_default_86[1]
        getitem_914 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_912, relu__default_16, primals_572, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_912 = primals_572 = None
        getitem_915 = convolution_backward_default_86[0]
        getitem_916 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_915, torch.float32);  getitem_915 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_175, to_dtype_129);  le_scalar_43 = new_zeros_default_175 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_44, primals_566, primals_564, primals_565, getitem_133, getitem_134, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_44 = primals_566 = primals_564 = primals_565 = getitem_133 = getitem_134 = None
        getitem_918 = native_batch_norm_backward_default_87[0]
        getitem_919 = native_batch_norm_backward_default_87[1]
        getitem_920 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_918, getitem_129, primals_561, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_918 = getitem_129 = primals_561 = None
        getitem_921 = convolution_backward_default_87[0]
        getitem_922 = convolution_backward_default_87[1];  convolution_backward_default_87 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(getitem_921, convolution_default_43, primals_559, primals_557, primals_558, getitem_130, getitem_131, True, 1e-05, [True, True, True]);  getitem_921 = convolution_default_43 = primals_559 = primals_557 = primals_558 = getitem_130 = getitem_131 = None
        getitem_924 = native_batch_norm_backward_default_88[0]
        getitem_925 = native_batch_norm_backward_default_88[1]
        getitem_926 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_924, relu__default_15, primals_560, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_924 = primals_560 = None
        getitem_927 = convolution_backward_default_88[0]
        getitem_928 = convolution_backward_default_88[1];  convolution_backward_default_88 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_927, torch.float32);  getitem_927 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_176, to_dtype_132);  le_scalar_44 = new_zeros_default_176 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_42, primals_554, primals_552, primals_553, getitem_127, getitem_128, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_42 = primals_554 = primals_552 = primals_553 = getitem_127 = getitem_128 = None
        getitem_930 = native_batch_norm_backward_default_89[0]
        getitem_931 = native_batch_norm_backward_default_89[1]
        getitem_932 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_930, getitem_123, primals_549, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_930 = getitem_123 = primals_549 = None
        getitem_933 = convolution_backward_default_89[0]
        getitem_934 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(getitem_933, convolution_default_41, primals_547, primals_545, primals_546, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  getitem_933 = convolution_default_41 = primals_547 = primals_545 = primals_546 = getitem_124 = getitem_125 = None
        getitem_936 = native_batch_norm_backward_default_90[0]
        getitem_937 = native_batch_norm_backward_default_90[1]
        getitem_938 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_936, relu_default_4, primals_548, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_936 = primals_548 = None
        getitem_939 = convolution_backward_default_90[0]
        getitem_940 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_939, torch.float32);  getitem_939 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_177, to_dtype_135);  le_scalar_45 = new_zeros_default_177 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_32, to_dtype_137);  add_tensor_32 = to_dtype_137 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_33, convolution_default_40, primals_542, primals_540, primals_541, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  convolution_default_40 = primals_542 = primals_540 = primals_541 = getitem_121 = getitem_122 = None
        getitem_942 = native_batch_norm_backward_default_91[0]
        getitem_943 = native_batch_norm_backward_default_91[1]
        getitem_944 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_942, getitem_117, primals_537, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_942 = getitem_117 = primals_537 = None
        getitem_945 = convolution_backward_default_91[0]
        getitem_946 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(getitem_945, convolution_default_39, primals_535, primals_533, primals_534, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  getitem_945 = convolution_default_39 = primals_535 = primals_533 = primals_534 = getitem_118 = getitem_119 = None
        getitem_948 = native_batch_norm_backward_default_92[0]
        getitem_949 = native_batch_norm_backward_default_92[1]
        getitem_950 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_948, relu__default_14, primals_536, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_948 = primals_536 = None
        getitem_951 = convolution_backward_default_92[0]
        getitem_952 = convolution_backward_default_92[1];  convolution_backward_default_92 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_951, torch.float32);  getitem_951 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_178, to_dtype_138);  le_scalar_46 = new_zeros_default_178 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_38, primals_530, primals_528, primals_529, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_38 = primals_530 = primals_528 = primals_529 = getitem_115 = getitem_116 = None
        getitem_954 = native_batch_norm_backward_default_93[0]
        getitem_955 = native_batch_norm_backward_default_93[1]
        getitem_956 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_954, getitem_111, primals_525, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_954 = getitem_111 = primals_525 = None
        getitem_957 = convolution_backward_default_93[0]
        getitem_958 = convolution_backward_default_93[1];  convolution_backward_default_93 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(getitem_957, convolution_default_37, primals_523, primals_521, primals_522, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  getitem_957 = convolution_default_37 = primals_523 = primals_521 = primals_522 = getitem_112 = getitem_113 = None
        getitem_960 = native_batch_norm_backward_default_94[0]
        getitem_961 = native_batch_norm_backward_default_94[1]
        getitem_962 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_960, relu__default_13, primals_524, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_960 = primals_524 = None
        getitem_963 = convolution_backward_default_94[0]
        getitem_964 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_963, torch.float32);  getitem_963 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_179, to_dtype_141);  le_scalar_47 = new_zeros_default_179 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_36, primals_518, primals_516, primals_517, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_36 = primals_518 = primals_516 = primals_517 = getitem_109 = getitem_110 = None
        getitem_966 = native_batch_norm_backward_default_95[0]
        getitem_967 = native_batch_norm_backward_default_95[1]
        getitem_968 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_966, getitem_105, primals_513, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_966 = getitem_105 = primals_513 = None
        getitem_969 = convolution_backward_default_95[0]
        getitem_970 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(getitem_969, convolution_default_35, primals_511, primals_509, primals_510, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  getitem_969 = convolution_default_35 = primals_511 = primals_509 = primals_510 = getitem_106 = getitem_107 = None
        getitem_972 = native_batch_norm_backward_default_96[0]
        getitem_973 = native_batch_norm_backward_default_96[1]
        getitem_974 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_972, relu_default_3, primals_512, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_972 = primals_512 = None
        getitem_975 = convolution_backward_default_96[0]
        getitem_976 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_975, torch.float32);  getitem_975 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_180, to_dtype_144);  le_scalar_48 = new_zeros_default_180 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, to_dtype_146);  add_tensor_33 = to_dtype_146 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_34, convolution_default_34, primals_506, primals_504, primals_505, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  convolution_default_34 = primals_506 = primals_504 = primals_505 = getitem_103 = getitem_104 = None
        getitem_978 = native_batch_norm_backward_default_97[0]
        getitem_979 = native_batch_norm_backward_default_97[1]
        getitem_980 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_978, getitem_99, primals_501, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_978 = getitem_99 = primals_501 = None
        getitem_981 = convolution_backward_default_97[0]
        getitem_982 = convolution_backward_default_97[1];  convolution_backward_default_97 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(getitem_981, convolution_default_33, primals_499, primals_497, primals_498, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  getitem_981 = convolution_default_33 = primals_499 = primals_497 = primals_498 = getitem_100 = getitem_101 = None
        getitem_984 = native_batch_norm_backward_default_98[0]
        getitem_985 = native_batch_norm_backward_default_98[1]
        getitem_986 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_984, relu__default_12, primals_500, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_984 = primals_500 = None
        getitem_987 = convolution_backward_default_98[0]
        getitem_988 = convolution_backward_default_98[1];  convolution_backward_default_98 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_987, torch.float32);  getitem_987 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_181, to_dtype_147);  le_scalar_49 = new_zeros_default_181 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_32, primals_494, primals_492, primals_493, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_32 = primals_494 = primals_492 = primals_493 = getitem_97 = getitem_98 = None
        getitem_990 = native_batch_norm_backward_default_99[0]
        getitem_991 = native_batch_norm_backward_default_99[1]
        getitem_992 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_990, getitem_93, primals_489, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_990 = getitem_93 = primals_489 = None
        getitem_993 = convolution_backward_default_99[0]
        getitem_994 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(getitem_993, convolution_default_31, primals_487, primals_485, primals_486, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  getitem_993 = convolution_default_31 = primals_487 = primals_485 = primals_486 = getitem_94 = getitem_95 = None
        getitem_996 = native_batch_norm_backward_default_100[0]
        getitem_997 = native_batch_norm_backward_default_100[1]
        getitem_998 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_996, relu__default_11, primals_488, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_996 = primals_488 = None
        getitem_999 = convolution_backward_default_100[0]
        getitem_1000 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_999, torch.float32);  getitem_999 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_182, to_dtype_150);  le_scalar_50 = new_zeros_default_182 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_30, primals_482, primals_480, primals_481, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  to_dtype_152 = convolution_default_30 = primals_482 = primals_480 = primals_481 = getitem_91 = getitem_92 = None
        getitem_1002 = native_batch_norm_backward_default_101[0]
        getitem_1003 = native_batch_norm_backward_default_101[1]
        getitem_1004 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1002, getitem_87, primals_477, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1002 = getitem_87 = primals_477 = None
        getitem_1005 = convolution_backward_default_101[0]
        getitem_1006 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(getitem_1005, convolution_default_29, primals_475, primals_473, primals_474, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  getitem_1005 = convolution_default_29 = primals_475 = primals_473 = primals_474 = getitem_88 = getitem_89 = None
        getitem_1008 = native_batch_norm_backward_default_102[0]
        getitem_1009 = native_batch_norm_backward_default_102[1]
        getitem_1010 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1008, relu_default_2, primals_476, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1008 = primals_476 = None
        getitem_1011 = convolution_backward_default_102[0]
        getitem_1012 = convolution_backward_default_102[1];  convolution_backward_default_102 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_1011, torch.float32);  getitem_1011 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_183, to_dtype_153);  le_scalar_51 = new_zeros_default_183 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(add_tensor_34, to_dtype_155);  add_tensor_34 = to_dtype_155 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_35, convolution_default_28, primals_254, primals_252, primals_253, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  convolution_default_28 = primals_254 = primals_252 = primals_253 = getitem_85 = getitem_86 = None
        getitem_1014 = native_batch_norm_backward_default_103[0]
        getitem_1015 = native_batch_norm_backward_default_103[1]
        getitem_1016 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_1014, getitem_81, primals_249, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1014 = getitem_81 = primals_249 = None
        getitem_1017 = convolution_backward_default_103[0]
        getitem_1018 = convolution_backward_default_103[1];  convolution_backward_default_103 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(getitem_1017, convolution_default_27, primals_247, primals_245, primals_246, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  getitem_1017 = convolution_default_27 = primals_247 = primals_245 = primals_246 = getitem_82 = getitem_83 = None
        getitem_1020 = native_batch_norm_backward_default_104[0]
        getitem_1021 = native_batch_norm_backward_default_104[1]
        getitem_1022 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_1020, relu__default_10, primals_248, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1020 = primals_248 = None
        getitem_1023 = convolution_backward_default_104[0]
        getitem_1024 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_1023, torch.float32);  getitem_1023 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_184, to_dtype_156);  le_scalar_52 = new_zeros_default_184 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_26, primals_242, primals_240, primals_241, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_158 = convolution_default_26 = primals_242 = primals_240 = primals_241 = getitem_79 = getitem_80 = None
        getitem_1026 = native_batch_norm_backward_default_105[0]
        getitem_1027 = native_batch_norm_backward_default_105[1]
        getitem_1028 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_1026, getitem_75, primals_237, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1026 = getitem_75 = primals_237 = None
        getitem_1029 = convolution_backward_default_105[0]
        getitem_1030 = convolution_backward_default_105[1];  convolution_backward_default_105 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(getitem_1029, convolution_default_25, primals_235, primals_233, primals_234, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  getitem_1029 = convolution_default_25 = primals_235 = primals_233 = primals_234 = getitem_76 = getitem_77 = None
        getitem_1032 = native_batch_norm_backward_default_106[0]
        getitem_1033 = native_batch_norm_backward_default_106[1]
        getitem_1034 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_1032, relu__default_9, primals_236, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1032 = primals_236 = None
        getitem_1035 = convolution_backward_default_106[0]
        getitem_1036 = convolution_backward_default_106[1];  convolution_backward_default_106 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_1035, torch.float32);  getitem_1035 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_185, to_dtype_159);  le_scalar_53 = new_zeros_default_185 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_24, primals_230, primals_228, primals_229, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_24 = primals_230 = primals_228 = primals_229 = getitem_73 = getitem_74 = None
        getitem_1038 = native_batch_norm_backward_default_107[0]
        getitem_1039 = native_batch_norm_backward_default_107[1]
        getitem_1040 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_1038, getitem_69, primals_225, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1038 = getitem_69 = primals_225 = None
        getitem_1041 = convolution_backward_default_107[0]
        getitem_1042 = convolution_backward_default_107[1];  convolution_backward_default_107 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(getitem_1041, convolution_default_23, primals_223, primals_221, primals_222, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  getitem_1041 = convolution_default_23 = primals_223 = primals_221 = primals_222 = getitem_70 = getitem_71 = None
        getitem_1044 = native_batch_norm_backward_default_108[0]
        getitem_1045 = native_batch_norm_backward_default_108[1]
        getitem_1046 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1044, relu_default_1, primals_224, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1044 = primals_224 = None
        getitem_1047 = convolution_backward_default_108[0]
        getitem_1048 = convolution_backward_default_108[1];  convolution_backward_default_108 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_1047, torch.float32);  getitem_1047 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_186, to_dtype_162);  le_scalar_54 = new_zeros_default_186 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_35, to_dtype_164);  add_tensor_35 = to_dtype_164 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_36, convolution_default_22, primals_162, primals_160, primals_161, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  convolution_default_22 = primals_162 = primals_160 = primals_161 = getitem_67 = getitem_68 = None
        getitem_1050 = native_batch_norm_backward_default_109[0]
        getitem_1051 = native_batch_norm_backward_default_109[1]
        getitem_1052 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1050, getitem_63, primals_157, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1050 = getitem_63 = primals_157 = None
        getitem_1053 = convolution_backward_default_109[0]
        getitem_1054 = convolution_backward_default_109[1];  convolution_backward_default_109 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(getitem_1053, convolution_default_21, primals_155, primals_153, primals_154, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  getitem_1053 = convolution_default_21 = primals_155 = primals_153 = primals_154 = getitem_64 = getitem_65 = None
        getitem_1056 = native_batch_norm_backward_default_110[0]
        getitem_1057 = native_batch_norm_backward_default_110[1]
        getitem_1058 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1056, relu__default_8, primals_156, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1056 = primals_156 = None
        getitem_1059 = convolution_backward_default_110[0]
        getitem_1060 = convolution_backward_default_110[1];  convolution_backward_default_110 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_1059, torch.float32);  getitem_1059 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_187, to_dtype_165);  le_scalar_55 = new_zeros_default_187 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_20, primals_150, primals_148, primals_149, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_167 = convolution_default_20 = primals_150 = primals_148 = primals_149 = getitem_61 = getitem_62 = None
        getitem_1062 = native_batch_norm_backward_default_111[0]
        getitem_1063 = native_batch_norm_backward_default_111[1]
        getitem_1064 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1062, getitem_57, primals_145, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1062 = getitem_57 = primals_145 = None
        getitem_1065 = convolution_backward_default_111[0]
        getitem_1066 = convolution_backward_default_111[1];  convolution_backward_default_111 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(getitem_1065, convolution_default_19, primals_143, primals_141, primals_142, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  getitem_1065 = convolution_default_19 = primals_143 = primals_141 = primals_142 = getitem_58 = getitem_59 = None
        getitem_1068 = native_batch_norm_backward_default_112[0]
        getitem_1069 = native_batch_norm_backward_default_112[1]
        getitem_1070 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_1068, relu__default_7, primals_144, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1068 = primals_144 = None
        getitem_1071 = convolution_backward_default_112[0]
        getitem_1072 = convolution_backward_default_112[1];  convolution_backward_default_112 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_1071, torch.float32);  getitem_1071 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_188, to_dtype_168);  le_scalar_56 = new_zeros_default_188 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_18, primals_138, primals_136, primals_137, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  to_dtype_170 = convolution_default_18 = primals_138 = primals_136 = primals_137 = getitem_55 = getitem_56 = None
        getitem_1074 = native_batch_norm_backward_default_113[0]
        getitem_1075 = native_batch_norm_backward_default_113[1]
        getitem_1076 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1074, getitem_51, primals_133, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1074 = getitem_51 = primals_133 = None
        getitem_1077 = convolution_backward_default_113[0]
        getitem_1078 = convolution_backward_default_113[1];  convolution_backward_default_113 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(getitem_1077, convolution_default_17, primals_131, primals_129, primals_130, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  getitem_1077 = convolution_default_17 = primals_131 = primals_129 = primals_130 = getitem_52 = getitem_53 = None
        getitem_1080 = native_batch_norm_backward_default_114[0]
        getitem_1081 = native_batch_norm_backward_default_114[1]
        getitem_1082 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1080, relu_default, primals_132, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 256, [True, True, False]);  getitem_1080 = primals_132 = None
        getitem_1083 = convolution_backward_default_114[0]
        getitem_1084 = convolution_backward_default_114[1];  convolution_backward_default_114 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_1083, torch.float32);  getitem_1083 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_189, to_dtype_171);  le_scalar_57 = new_zeros_default_189 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_36, convolution_default_16, primals_168, primals_166, primals_167, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  add_tensor_36 = convolution_default_16 = primals_168 = primals_166 = primals_167 = getitem_49 = getitem_50 = None
        getitem_1086 = native_batch_norm_backward_default_115[0]
        getitem_1087 = native_batch_norm_backward_default_115[1]
        getitem_1088 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1086, add_tensor_1, primals_163, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1086 = add_tensor_1 = primals_163 = None
        getitem_1089 = convolution_backward_default_115[0]
        getitem_1090 = convolution_backward_default_115[1];  convolution_backward_default_115 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(to_dtype_173, getitem_1089);  to_dtype_173 = getitem_1089 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_37, convolution_default_15, primals_120, primals_118, primals_119, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  convolution_default_15 = primals_120 = primals_118 = primals_119 = getitem_46 = getitem_47 = None
        getitem_1092 = native_batch_norm_backward_default_116[0]
        getitem_1093 = native_batch_norm_backward_default_116[1]
        getitem_1094 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1092, getitem_42, primals_115, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1092 = getitem_42 = primals_115 = None
        getitem_1095 = convolution_backward_default_116[0]
        getitem_1096 = convolution_backward_default_116[1];  convolution_backward_default_116 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(getitem_1095, convolution_default_14, primals_113, primals_111, primals_112, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  getitem_1095 = convolution_default_14 = primals_113 = primals_111 = primals_112 = getitem_43 = getitem_44 = None
        getitem_1098 = native_batch_norm_backward_default_117[0]
        getitem_1099 = native_batch_norm_backward_default_117[1]
        getitem_1100 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_1098, relu__default_6, primals_114, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 256, [True, True, False]);  getitem_1098 = primals_114 = None
        getitem_1101 = convolution_backward_default_117[0]
        getitem_1102 = convolution_backward_default_117[1];  convolution_backward_default_117 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_1101, torch.float32);  getitem_1101 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_190, to_dtype_174);  le_scalar_58 = new_zeros_default_190 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_13, primals_108, primals_106, primals_107, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_13 = primals_108 = primals_106 = primals_107 = getitem_40 = getitem_41 = None
        getitem_1104 = native_batch_norm_backward_default_118[0]
        getitem_1105 = native_batch_norm_backward_default_118[1]
        getitem_1106 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1104, getitem_36, primals_103, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1104 = getitem_36 = primals_103 = None
        getitem_1107 = convolution_backward_default_118[0]
        getitem_1108 = convolution_backward_default_118[1];  convolution_backward_default_118 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(getitem_1107, convolution_default_12, primals_101, primals_99, primals_100, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  getitem_1107 = convolution_default_12 = primals_101 = primals_99 = primals_100 = getitem_37 = getitem_38 = None
        getitem_1110 = native_batch_norm_backward_default_119[0]
        getitem_1111 = native_batch_norm_backward_default_119[1]
        getitem_1112 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1110, relu__default_5, primals_102, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 256, [True, True, False]);  getitem_1110 = primals_102 = None
        getitem_1113 = convolution_backward_default_119[0]
        getitem_1114 = convolution_backward_default_119[1];  convolution_backward_default_119 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_1113, torch.float32);  getitem_1113 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_191, to_dtype_177);  le_scalar_59 = new_zeros_default_191 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_11, primals_96, primals_94, primals_95, getitem_34, getitem_35, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_11 = primals_96 = primals_94 = primals_95 = getitem_34 = getitem_35 = None
        getitem_1116 = native_batch_norm_backward_default_120[0]
        getitem_1117 = native_batch_norm_backward_default_120[1]
        getitem_1118 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1116, getitem_30, primals_91, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1116 = getitem_30 = primals_91 = None
        getitem_1119 = convolution_backward_default_120[0]
        getitem_1120 = convolution_backward_default_120[1];  convolution_backward_default_120 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(getitem_1119, convolution_default_10, primals_89, primals_87, primals_88, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  getitem_1119 = convolution_default_10 = primals_89 = primals_87 = primals_88 = getitem_31 = getitem_32 = None
        getitem_1122 = native_batch_norm_backward_default_121[0]
        getitem_1123 = native_batch_norm_backward_default_121[1]
        getitem_1124 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1122, relu__default_4, primals_90, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_1122 = primals_90 = None
        getitem_1125 = convolution_backward_default_121[0]
        getitem_1126 = convolution_backward_default_121[1];  convolution_backward_default_121 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_37, convolution_default_9, primals_126, primals_124, primals_125, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  add_tensor_37 = convolution_default_9 = primals_126 = primals_124 = primals_125 = getitem_28 = getitem_29 = None
        getitem_1128 = native_batch_norm_backward_default_122[0]
        getitem_1129 = native_batch_norm_backward_default_122[1]
        getitem_1130 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1128, relu__default_4, primals_121, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1128 = primals_121 = None
        getitem_1131 = convolution_backward_default_122[0]
        getitem_1132 = convolution_backward_default_122[1];  convolution_backward_default_122 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_1125, getitem_1131);  getitem_1125 = getitem_1131 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_38, torch.float32);  add_tensor_38 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_192, to_dtype_180);  le_scalar_60 = new_zeros_default_192 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_8, primals_36, primals_34, primals_35, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  convolution_default_8 = primals_36 = primals_34 = primals_35 = getitem_25 = getitem_26 = None
        getitem_1134 = native_batch_norm_backward_default_123[0]
        getitem_1135 = native_batch_norm_backward_default_123[1]
        getitem_1136 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1134, getitem_21, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1134 = getitem_21 = primals_31 = None
        getitem_1137 = convolution_backward_default_123[0]
        getitem_1138 = convolution_backward_default_123[1];  convolution_backward_default_123 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(getitem_1137, convolution_default_7, primals_29, primals_27, primals_28, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  getitem_1137 = convolution_default_7 = primals_29 = primals_27 = primals_28 = getitem_22 = getitem_23 = None
        getitem_1140 = native_batch_norm_backward_default_124[0]
        getitem_1141 = native_batch_norm_backward_default_124[1]
        getitem_1142 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1140, relu__default_3, primals_30, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_1140 = primals_30 = None
        getitem_1143 = convolution_backward_default_124[0]
        getitem_1144 = convolution_backward_default_124[1];  convolution_backward_default_124 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_1143, torch.float32);  getitem_1143 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_193, to_dtype_183);  le_scalar_61 = new_zeros_default_193 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_6, primals_24, primals_22, primals_23, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_185 = convolution_default_6 = primals_24 = primals_22 = primals_23 = getitem_19 = getitem_20 = None
        getitem_1146 = native_batch_norm_backward_default_125[0]
        getitem_1147 = native_batch_norm_backward_default_125[1]
        getitem_1148 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1146, getitem_15, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1146 = getitem_15 = primals_19 = None
        getitem_1149 = convolution_backward_default_125[0]
        getitem_1150 = convolution_backward_default_125[1];  convolution_backward_default_125 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(getitem_1149, convolution_default_5, primals_17, primals_15, primals_16, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  getitem_1149 = convolution_default_5 = primals_17 = primals_15 = primals_16 = getitem_16 = getitem_17 = None
        getitem_1152 = native_batch_norm_backward_default_126[0]
        getitem_1153 = native_batch_norm_backward_default_126[1]
        getitem_1154 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1152, relu__default_2, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_1152 = primals_18 = None
        getitem_1155 = convolution_backward_default_126[0]
        getitem_1156 = convolution_backward_default_126[1];  convolution_backward_default_126 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_1155, torch.float32);  getitem_1155 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_194, to_dtype_186);  le_scalar_62 = new_zeros_default_194 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_4, primals_12, primals_10, primals_11, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_4 = primals_12 = primals_10 = primals_11 = getitem_13 = getitem_14 = None
        getitem_1158 = native_batch_norm_backward_default_127[0]
        getitem_1159 = native_batch_norm_backward_default_127[1]
        getitem_1160 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1158, getitem_9, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1158 = getitem_9 = primals_7 = None
        getitem_1161 = convolution_backward_default_127[0]
        getitem_1162 = convolution_backward_default_127[1];  convolution_backward_default_127 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(getitem_1161, convolution_default_3, primals_5, primals_3, primals_4, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  getitem_1161 = convolution_default_3 = primals_5 = primals_3 = primals_4 = getitem_10 = getitem_11 = None
        getitem_1164 = native_batch_norm_backward_default_128[0]
        getitem_1165 = native_batch_norm_backward_default_128[1]
        getitem_1166 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1164, relu__default_1, primals_6, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 64, [True, True, False]);  getitem_1164 = primals_6 = None
        getitem_1167 = convolution_backward_default_128[0]
        getitem_1168 = convolution_backward_default_128[1];  convolution_backward_default_128 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_2, primals_42, primals_40, primals_41, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_182 = convolution_default_2 = primals_42 = primals_40 = primals_41 = getitem_7 = getitem_8 = None
        getitem_1170 = native_batch_norm_backward_default_129[0]
        getitem_1171 = native_batch_norm_backward_default_129[1]
        getitem_1172 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1170, relu__default_1, primals_37, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1170 = primals_37 = None
        getitem_1173 = convolution_backward_default_129[0]
        getitem_1174 = convolution_backward_default_129[1];  convolution_backward_default_129 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_1167, getitem_1173);  getitem_1167 = getitem_1173 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_39, torch.float32);  add_tensor_39 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_195, to_dtype_189);  le_scalar_63 = new_zeros_default_195 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_1, primals_178, primals_176, primals_177, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_1 = primals_178 = primals_176 = primals_177 = getitem_4 = getitem_5 = None
        getitem_1176 = native_batch_norm_backward_default_130[0]
        getitem_1177 = native_batch_norm_backward_default_130[1]
        getitem_1178 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1176, relu__default, primals_195, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1176 = primals_195 = None
        getitem_1179 = convolution_backward_default_130[0]
        getitem_1180 = convolution_backward_default_130[1];  convolution_backward_default_130 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_1179, torch.float32);  getitem_1179 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_196, to_dtype_192);  le_scalar_64 = new_zeros_default_196 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default, primals_173, primals_171, primals_172, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default = primals_173 = primals_171 = primals_172 = getitem_1 = getitem_2 = None
        getitem_1182 = native_batch_norm_backward_default_131[0]
        getitem_1183 = native_batch_norm_backward_default_131[1]
        getitem_1184 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1182, primals_795, primals_194, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1182 = primals_795 = primals_194 = None
        getitem_1186 = convolution_backward_default_131[1];  convolution_backward_default_131 = None
        return [getitem_1166, None, None, None, getitem_1165, getitem_1168, getitem_1162, getitem_1160, None, None, None, getitem_1159, getitem_1154, None, None, None, getitem_1153, getitem_1156, getitem_1150, getitem_1148, None, None, None, getitem_1147, getitem_1142, None, None, None, getitem_1141, getitem_1144, getitem_1138, getitem_1136, None, None, None, getitem_1135, getitem_1174, getitem_1172, None, None, None, getitem_1171, getitem_464, None, None, None, getitem_463, getitem_466, getitem_460, getitem_458, None, None, None, getitem_457, getitem_452, None, None, None, getitem_451, getitem_454, getitem_448, getitem_446, None, None, None, getitem_445, getitem_440, None, None, None, getitem_439, getitem_442, getitem_436, getitem_434, None, None, None, getitem_433, getitem_472, getitem_470, None, None, None, getitem_469, getitem_1124, None, None, None, getitem_1123, getitem_1126, getitem_1120, getitem_1118, None, None, None, getitem_1117, getitem_1112, None, None, None, getitem_1111, getitem_1114, getitem_1108, getitem_1106, None, None, None, getitem_1105, getitem_1100, None, None, None, getitem_1099, getitem_1102, getitem_1096, getitem_1094, None, None, None, getitem_1093, getitem_1132, getitem_1130, None, None, None, getitem_1129, getitem_1082, None, None, None, getitem_1081, getitem_1084, getitem_1078, getitem_1076, None, None, None, getitem_1075, getitem_1070, None, None, None, getitem_1069, getitem_1072, getitem_1066, getitem_1064, None, None, None, getitem_1063, getitem_1058, None, None, None, getitem_1057, getitem_1060, getitem_1054, getitem_1052, None, None, None, getitem_1051, getitem_1090, getitem_1088, None, None, None, getitem_1087, getitem_1184, None, None, None, getitem_1183, getitem_1178, None, None, None, getitem_1177, getitem_422, None, None, None, getitem_421, getitem_410, None, None, None, getitem_409, getitem_398, None, None, None, getitem_397, getitem_1186, getitem_1180, getitem_428, None, None, None, getitem_427, getitem_430, getitem_424, getitem_416, None, None, None, getitem_415, getitem_418, getitem_412, getitem_404, None, None, None, getitem_403, getitem_406, getitem_400, view_default_1, t_default_4, getitem_1046, None, None, None, getitem_1045, getitem_1048, getitem_1042, getitem_1040, None, None, None, getitem_1039, getitem_1034, None, None, None, getitem_1033, getitem_1036, getitem_1030, getitem_1028, None, None, None, getitem_1027, getitem_1022, None, None, None, getitem_1021, getitem_1024, getitem_1018, getitem_1016, None, None, None, getitem_1015, getitem_686, None, None, None, getitem_685, getitem_688, getitem_682, getitem_680, None, None, None, getitem_679, getitem_674, None, None, None, getitem_673, getitem_676, getitem_670, getitem_668, None, None, None, getitem_667, getitem_662, None, None, None, getitem_661, getitem_664, getitem_658, getitem_656, None, None, None, getitem_655, getitem_650, None, None, None, getitem_649, getitem_652, getitem_646, getitem_644, None, None, None, getitem_643, getitem_638, None, None, None, getitem_637, getitem_640, getitem_634, getitem_632, None, None, None, getitem_631, getitem_626, None, None, None, getitem_625, getitem_628, getitem_622, getitem_620, None, None, None, getitem_619, getitem_614, None, None, None, getitem_613, getitem_616, getitem_610, getitem_608, None, None, None, getitem_607, getitem_602, None, None, None, getitem_601, getitem_604, getitem_598, getitem_596, None, None, None, getitem_595, getitem_590, None, None, None, getitem_589, getitem_592, getitem_586, getitem_584, None, None, None, getitem_583, getitem_578, None, None, None, getitem_577, getitem_580, getitem_574, getitem_572, None, None, None, getitem_571, getitem_566, None, None, None, getitem_565, getitem_568, getitem_562, getitem_560, None, None, None, getitem_559, getitem_554, None, None, None, getitem_553, getitem_556, getitem_550, getitem_548, None, None, None, getitem_547, getitem_542, None, None, None, getitem_541, getitem_544, getitem_538, getitem_536, None, None, None, getitem_535, getitem_530, None, None, None, getitem_529, getitem_532, getitem_526, getitem_524, None, None, None, getitem_523, getitem_518, None, None, None, getitem_517, getitem_520, getitem_514, getitem_512, None, None, None, getitem_511, getitem_506, None, None, None, getitem_505, getitem_508, getitem_502, getitem_500, None, None, None, getitem_499, getitem_494, None, None, None, getitem_493, getitem_496, getitem_490, getitem_488, None, None, None, getitem_487, getitem_482, None, None, None, getitem_481, getitem_484, getitem_478, getitem_476, None, None, None, getitem_475, getitem_1010, None, None, None, getitem_1009, getitem_1012, getitem_1006, getitem_1004, None, None, None, getitem_1003, getitem_998, None, None, None, getitem_997, getitem_1000, getitem_994, getitem_992, None, None, None, getitem_991, getitem_986, None, None, None, getitem_985, getitem_988, getitem_982, getitem_980, None, None, None, getitem_979, getitem_974, None, None, None, getitem_973, getitem_976, getitem_970, getitem_968, None, None, None, getitem_967, getitem_962, None, None, None, getitem_961, getitem_964, getitem_958, getitem_956, None, None, None, getitem_955, getitem_950, None, None, None, getitem_949, getitem_952, getitem_946, getitem_944, None, None, None, getitem_943, getitem_938, None, None, None, getitem_937, getitem_940, getitem_934, getitem_932, None, None, None, getitem_931, getitem_926, None, None, None, getitem_925, getitem_928, getitem_922, getitem_920, None, None, None, getitem_919, getitem_914, None, None, None, getitem_913, getitem_916, getitem_910, getitem_908, None, None, None, getitem_907, getitem_902, None, None, None, getitem_901, getitem_904, getitem_898, getitem_896, None, None, None, getitem_895, getitem_890, None, None, None, getitem_889, getitem_892, getitem_886, getitem_884, None, None, None, getitem_883, getitem_878, None, None, None, getitem_877, getitem_880, getitem_874, getitem_872, None, None, None, getitem_871, getitem_866, None, None, None, getitem_865, getitem_868, getitem_862, getitem_860, None, None, None, getitem_859, getitem_854, None, None, None, getitem_853, getitem_856, getitem_850, getitem_848, None, None, None, getitem_847, getitem_842, None, None, None, getitem_841, getitem_844, getitem_838, getitem_836, None, None, None, getitem_835, getitem_830, None, None, None, getitem_829, getitem_832, getitem_826, getitem_824, None, None, None, getitem_823, getitem_818, None, None, None, getitem_817, getitem_820, getitem_814, getitem_812, None, None, None, getitem_811, getitem_806, None, None, None, getitem_805, getitem_808, getitem_802, getitem_800, None, None, None, getitem_799, getitem_794, None, None, None, getitem_793, getitem_796, getitem_790, getitem_788, None, None, None, getitem_787, getitem_782, None, None, None, getitem_781, getitem_784, getitem_778, getitem_776, None, None, None, getitem_775, getitem_770, None, None, None, getitem_769, getitem_772, getitem_766, getitem_764, None, None, None, getitem_763, getitem_758, None, None, None, getitem_757, getitem_760, getitem_754, getitem_752, None, None, None, getitem_751, getitem_746, None, None, None, getitem_745, getitem_748, getitem_742, getitem_740, None, None, None, getitem_739, getitem_734, None, None, None, getitem_733, getitem_736, getitem_730, getitem_728, None, None, None, getitem_727, getitem_722, None, None, None, getitem_721, getitem_724, getitem_718, getitem_716, None, None, None, getitem_715, getitem_710, None, None, None, getitem_709, getitem_712, getitem_706, getitem_704, None, None, None, getitem_703, getitem_698, None, None, None, getitem_697, getitem_700, getitem_694, getitem_692, None, None, None, getitem_691, None]
        
