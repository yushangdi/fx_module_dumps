
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/gluon_xception65/gluon_xception65_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795):
        convolution_default = torch.ops.aten.convolution.default(primals_795, primals_194, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_173, primals_169, primals_171, primals_172, True, 0.1, 1e-05);  primals_169 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_195, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_178, primals_174, primals_176, primals_177, True, 0.1, 1e-05);  primals_174 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_37, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_42, primals_38, primals_40, primals_41, True, 0.1, 1e-05);  primals_38 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_1, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_9, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_12, primals_8, primals_10, primals_11, True, 0.1, 1e-05);  primals_8 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_2, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_17, primals_13, primals_15, primals_16, True, 0.1, 1e-05);  primals_13 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_24, primals_20, primals_22, primals_23, True, 0.1, 1e-05);  primals_20 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_3, primals_30, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 128)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_29, primals_25, primals_27, primals_28, True, 0.1, 1e-05);  primals_25 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_21, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_36, primals_32, primals_34, primals_35, True, 0.1, 1e-05);  primals_32 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add_tensor = torch.ops.aten.add.Tensor(getitem_24, getitem_6);  getitem_24 = getitem_6 = None
        relu__default_4 = torch.ops.aten.relu_.default(add_tensor);  add_tensor = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_4, primals_121, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_126, primals_122, primals_124, primals_125, True, 0.1, 1e-05);  primals_122 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_4, primals_90, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_89, primals_85, primals_87, primals_88, True, 0.1, 1e-05);  primals_85 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        convolution_default_11 = torch.ops.aten.convolution.default(getitem_30, primals_91, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_96, primals_92, primals_94, primals_95, True, 0.1, 1e-05);  primals_92 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_33);  getitem_33 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_5, primals_102, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 256)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_101, primals_97, primals_99, primals_100, True, 0.1, 1e-05);  primals_97 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(getitem_36, primals_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_108, primals_104, primals_106, primals_107, True, 0.1, 1e-05);  primals_104 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_6, primals_114, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 256)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_113, primals_109, primals_111, primals_112, True, 0.1, 1e-05);  primals_109 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        convolution_default_15 = torch.ops.aten.convolution.default(getitem_42, primals_115, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_120, primals_116, primals_118, primals_119, True, 0.1, 1e-05);  primals_116 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_45, getitem_27);  getitem_45 = getitem_27 = None
        convolution_default_16 = torch.ops.aten.convolution.default(add_tensor_1, primals_163, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_168, primals_164, primals_166, primals_167, True, 0.1, 1e-05);  primals_164 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu_default = torch.ops.aten.relu.default(add_tensor_1)
        convolution_default_17 = torch.ops.aten.convolution.default(relu_default, primals_132, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 256)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_131, primals_127, primals_129, primals_130, True, 0.1, 1e-05);  primals_127 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(getitem_51, primals_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_138, primals_134, primals_136, primals_137, True, 0.1, 1e-05);  primals_134 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_7, primals_144, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_143, primals_139, primals_141, primals_142, True, 0.1, 1e-05);  primals_139 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_57, primals_145, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_150, primals_146, primals_148, primals_149, True, 0.1, 1e-05);  primals_146 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_8, primals_156, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_155, primals_151, primals_153, primals_154, True, 0.1, 1e-05);  primals_151 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(getitem_63, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_162, primals_158, primals_160, primals_161, True, 0.1, 1e-05);  primals_158 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_66, getitem_48);  getitem_66 = getitem_48 = None
        relu_default_1 = torch.ops.aten.relu.default(add_tensor_2)
        convolution_default_23 = torch.ops.aten.convolution.default(relu_default_1, primals_224, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_223, primals_219, primals_221, primals_222, True, 0.1, 1e-05);  primals_219 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        convolution_default_24 = torch.ops.aten.convolution.default(getitem_69, primals_225, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_230, primals_226, primals_228, primals_229, True, 0.1, 1e-05);  primals_226 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_9, primals_236, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_235, primals_231, primals_233, primals_234, True, 0.1, 1e-05);  primals_231 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        convolution_default_26 = torch.ops.aten.convolution.default(getitem_75, primals_237, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_242, primals_238, primals_240, primals_241, True, 0.1, 1e-05);  primals_238 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_10, primals_248, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_247, primals_243, primals_245, primals_246, True, 0.1, 1e-05);  primals_243 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        convolution_default_28 = torch.ops.aten.convolution.default(getitem_81, primals_249, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_254, primals_250, primals_252, primals_253, True, 0.1, 1e-05);  primals_250 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_84, add_tensor_2);  getitem_84 = add_tensor_2 = None
        relu_default_2 = torch.ops.aten.relu.default(add_tensor_3)
        convolution_default_29 = torch.ops.aten.convolution.default(relu_default_2, primals_476, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_475, primals_471, primals_473, primals_474, True, 0.1, 1e-05);  primals_471 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        convolution_default_30 = torch.ops.aten.convolution.default(getitem_87, primals_477, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_482, primals_478, primals_480, primals_481, True, 0.1, 1e-05);  primals_478 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_11, primals_488, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_487, primals_483, primals_485, primals_486, True, 0.1, 1e-05);  primals_483 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        convolution_default_32 = torch.ops.aten.convolution.default(getitem_93, primals_489, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_494, primals_490, primals_492, primals_493, True, 0.1, 1e-05);  primals_490 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_12, primals_500, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_499, primals_495, primals_497, primals_498, True, 0.1, 1e-05);  primals_495 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_99, primals_501, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_506, primals_502, primals_504, primals_505, True, 0.1, 1e-05);  primals_502 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_102, add_tensor_3);  getitem_102 = add_tensor_3 = None
        relu_default_3 = torch.ops.aten.relu.default(add_tensor_4)
        convolution_default_35 = torch.ops.aten.convolution.default(relu_default_3, primals_512, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_511, primals_507, primals_509, primals_510, True, 0.1, 1e-05);  primals_507 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        convolution_default_36 = torch.ops.aten.convolution.default(getitem_105, primals_513, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_518, primals_514, primals_516, primals_517, True, 0.1, 1e-05);  primals_514 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_13, primals_524, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_523, primals_519, primals_521, primals_522, True, 0.1, 1e-05);  primals_519 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        convolution_default_38 = torch.ops.aten.convolution.default(getitem_111, primals_525, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_530, primals_526, primals_528, primals_529, True, 0.1, 1e-05);  primals_526 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_14, primals_536, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_535, primals_531, primals_533, primals_534, True, 0.1, 1e-05);  primals_531 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_117, primals_537, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_542, primals_538, primals_540, primals_541, True, 0.1, 1e-05);  primals_538 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_120, add_tensor_4);  getitem_120 = add_tensor_4 = None
        relu_default_4 = torch.ops.aten.relu.default(add_tensor_5)
        convolution_default_41 = torch.ops.aten.convolution.default(relu_default_4, primals_548, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_547, primals_543, primals_545, primals_546, True, 0.1, 1e-05);  primals_543 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(getitem_123, primals_549, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_554, primals_550, primals_552, primals_553, True, 0.1, 1e-05);  primals_550 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_15, primals_560, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_559, primals_555, primals_557, primals_558, True, 0.1, 1e-05);  primals_555 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        convolution_default_44 = torch.ops.aten.convolution.default(getitem_129, primals_561, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_566, primals_562, primals_564, primals_565, True, 0.1, 1e-05);  primals_562 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_16, primals_572, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_571, primals_567, primals_569, primals_570, True, 0.1, 1e-05);  primals_567 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        convolution_default_46 = torch.ops.aten.convolution.default(getitem_135, primals_573, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_578, primals_574, primals_576, primals_577, True, 0.1, 1e-05);  primals_574 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_138, add_tensor_5);  getitem_138 = add_tensor_5 = None
        relu_default_5 = torch.ops.aten.relu.default(add_tensor_6)
        convolution_default_47 = torch.ops.aten.convolution.default(relu_default_5, primals_584, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_583, primals_579, primals_581, primals_582, True, 0.1, 1e-05);  primals_579 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        convolution_default_48 = torch.ops.aten.convolution.default(getitem_141, primals_585, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_590, primals_586, primals_588, primals_589, True, 0.1, 1e-05);  primals_586 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_17, primals_596, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_595, primals_591, primals_593, primals_594, True, 0.1, 1e-05);  primals_591 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        convolution_default_50 = torch.ops.aten.convolution.default(getitem_147, primals_597, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_602, primals_598, primals_600, primals_601, True, 0.1, 1e-05);  primals_598 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_18, primals_608, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_607, primals_603, primals_605, primals_606, True, 0.1, 1e-05);  primals_603 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        convolution_default_52 = torch.ops.aten.convolution.default(getitem_153, primals_609, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_614, primals_610, primals_612, primals_613, True, 0.1, 1e-05);  primals_610 = None
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_156, add_tensor_6);  getitem_156 = add_tensor_6 = None
        relu_default_6 = torch.ops.aten.relu.default(add_tensor_7)
        convolution_default_53 = torch.ops.aten.convolution.default(relu_default_6, primals_620, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_619, primals_615, primals_617, primals_618, True, 0.1, 1e-05);  primals_615 = None
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(getitem_159, primals_621, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_626, primals_622, primals_624, primals_625, True, 0.1, 1e-05);  primals_622 = None
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_19, primals_632, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_631, primals_627, primals_629, primals_630, True, 0.1, 1e-05);  primals_627 = None
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        convolution_default_56 = torch.ops.aten.convolution.default(getitem_165, primals_633, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_638, primals_634, primals_636, primals_637, True, 0.1, 1e-05);  primals_634 = None
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_20, primals_644, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_643, primals_639, primals_641, primals_642, True, 0.1, 1e-05);  primals_639 = None
        getitem_171 = native_batch_norm_default_57[0]
        getitem_172 = native_batch_norm_default_57[1]
        getitem_173 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        convolution_default_58 = torch.ops.aten.convolution.default(getitem_171, primals_645, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_650, primals_646, primals_648, primals_649, True, 0.1, 1e-05);  primals_646 = None
        getitem_174 = native_batch_norm_default_58[0]
        getitem_175 = native_batch_norm_default_58[1]
        getitem_176 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_174, add_tensor_7);  getitem_174 = add_tensor_7 = None
        relu_default_7 = torch.ops.aten.relu.default(add_tensor_8)
        convolution_default_59 = torch.ops.aten.convolution.default(relu_default_7, primals_656, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_655, primals_651, primals_653, primals_654, True, 0.1, 1e-05);  primals_651 = None
        getitem_177 = native_batch_norm_default_59[0]
        getitem_178 = native_batch_norm_default_59[1]
        getitem_179 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        convolution_default_60 = torch.ops.aten.convolution.default(getitem_177, primals_657, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_662, primals_658, primals_660, primals_661, True, 0.1, 1e-05);  primals_658 = None
        getitem_180 = native_batch_norm_default_60[0]
        getitem_181 = native_batch_norm_default_60[1]
        getitem_182 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_180);  getitem_180 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_21, primals_668, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_667, primals_663, primals_665, primals_666, True, 0.1, 1e-05);  primals_663 = None
        getitem_183 = native_batch_norm_default_61[0]
        getitem_184 = native_batch_norm_default_61[1]
        getitem_185 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        convolution_default_62 = torch.ops.aten.convolution.default(getitem_183, primals_669, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_674, primals_670, primals_672, primals_673, True, 0.1, 1e-05);  primals_670 = None
        getitem_186 = native_batch_norm_default_62[0]
        getitem_187 = native_batch_norm_default_62[1]
        getitem_188 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_186);  getitem_186 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_22, primals_680, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_679, primals_675, primals_677, primals_678, True, 0.1, 1e-05);  primals_675 = None
        getitem_189 = native_batch_norm_default_63[0]
        getitem_190 = native_batch_norm_default_63[1]
        getitem_191 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        convolution_default_64 = torch.ops.aten.convolution.default(getitem_189, primals_681, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_686, primals_682, primals_684, primals_685, True, 0.1, 1e-05);  primals_682 = None
        getitem_192 = native_batch_norm_default_64[0]
        getitem_193 = native_batch_norm_default_64[1]
        getitem_194 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_192, add_tensor_8);  getitem_192 = add_tensor_8 = None
        relu_default_8 = torch.ops.aten.relu.default(add_tensor_9)
        convolution_default_65 = torch.ops.aten.convolution.default(relu_default_8, primals_692, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_195 = native_batch_norm_default_65[0]
        getitem_196 = native_batch_norm_default_65[1]
        getitem_197 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        convolution_default_66 = torch.ops.aten.convolution.default(getitem_195, primals_693, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_698, primals_694, primals_696, primals_697, True, 0.1, 1e-05);  primals_694 = None
        getitem_198 = native_batch_norm_default_66[0]
        getitem_199 = native_batch_norm_default_66[1]
        getitem_200 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_198);  getitem_198 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_23, primals_704, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_703, primals_699, primals_701, primals_702, True, 0.1, 1e-05);  primals_699 = None
        getitem_201 = native_batch_norm_default_67[0]
        getitem_202 = native_batch_norm_default_67[1]
        getitem_203 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        convolution_default_68 = torch.ops.aten.convolution.default(getitem_201, primals_705, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_710, primals_706, primals_708, primals_709, True, 0.1, 1e-05);  primals_706 = None
        getitem_204 = native_batch_norm_default_68[0]
        getitem_205 = native_batch_norm_default_68[1]
        getitem_206 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_204);  getitem_204 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_24, primals_716, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_715, primals_711, primals_713, primals_714, True, 0.1, 1e-05);  primals_711 = None
        getitem_207 = native_batch_norm_default_69[0]
        getitem_208 = native_batch_norm_default_69[1]
        getitem_209 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        convolution_default_70 = torch.ops.aten.convolution.default(getitem_207, primals_717, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_722, primals_718, primals_720, primals_721, True, 0.1, 1e-05);  primals_718 = None
        getitem_210 = native_batch_norm_default_70[0]
        getitem_211 = native_batch_norm_default_70[1]
        getitem_212 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_210, add_tensor_9);  getitem_210 = add_tensor_9 = None
        relu_default_9 = torch.ops.aten.relu.default(add_tensor_10)
        convolution_default_71 = torch.ops.aten.convolution.default(relu_default_9, primals_728, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_727, primals_723, primals_725, primals_726, True, 0.1, 1e-05);  primals_723 = None
        getitem_213 = native_batch_norm_default_71[0]
        getitem_214 = native_batch_norm_default_71[1]
        getitem_215 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        convolution_default_72 = torch.ops.aten.convolution.default(getitem_213, primals_729, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_734, primals_730, primals_732, primals_733, True, 0.1, 1e-05);  primals_730 = None
        getitem_216 = native_batch_norm_default_72[0]
        getitem_217 = native_batch_norm_default_72[1]
        getitem_218 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_216);  getitem_216 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_25, primals_740, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_739, primals_735, primals_737, primals_738, True, 0.1, 1e-05);  primals_735 = None
        getitem_219 = native_batch_norm_default_73[0]
        getitem_220 = native_batch_norm_default_73[1]
        getitem_221 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        convolution_default_74 = torch.ops.aten.convolution.default(getitem_219, primals_741, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_746, primals_742, primals_744, primals_745, True, 0.1, 1e-05);  primals_742 = None
        getitem_222 = native_batch_norm_default_74[0]
        getitem_223 = native_batch_norm_default_74[1]
        getitem_224 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_222);  getitem_222 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_26, primals_752, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_751, primals_747, primals_749, primals_750, True, 0.1, 1e-05);  primals_747 = None
        getitem_225 = native_batch_norm_default_75[0]
        getitem_226 = native_batch_norm_default_75[1]
        getitem_227 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        convolution_default_76 = torch.ops.aten.convolution.default(getitem_225, primals_753, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_758, primals_754, primals_756, primals_757, True, 0.1, 1e-05);  primals_754 = None
        getitem_228 = native_batch_norm_default_76[0]
        getitem_229 = native_batch_norm_default_76[1]
        getitem_230 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_228, add_tensor_10);  getitem_228 = add_tensor_10 = None
        relu_default_10 = torch.ops.aten.relu.default(add_tensor_11)
        convolution_default_77 = torch.ops.aten.convolution.default(relu_default_10, primals_764, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_763, primals_759, primals_761, primals_762, True, 0.1, 1e-05);  primals_759 = None
        getitem_231 = native_batch_norm_default_77[0]
        getitem_232 = native_batch_norm_default_77[1]
        getitem_233 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        convolution_default_78 = torch.ops.aten.convolution.default(getitem_231, primals_765, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_770, primals_766, primals_768, primals_769, True, 0.1, 1e-05);  primals_766 = None
        getitem_234 = native_batch_norm_default_78[0]
        getitem_235 = native_batch_norm_default_78[1]
        getitem_236 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_234);  getitem_234 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_27, primals_776, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_775, primals_771, primals_773, primals_774, True, 0.1, 1e-05);  primals_771 = None
        getitem_237 = native_batch_norm_default_79[0]
        getitem_238 = native_batch_norm_default_79[1]
        getitem_239 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        convolution_default_80 = torch.ops.aten.convolution.default(getitem_237, primals_777, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_782, primals_778, primals_780, primals_781, True, 0.1, 1e-05);  primals_778 = None
        getitem_240 = native_batch_norm_default_80[0]
        getitem_241 = native_batch_norm_default_80[1]
        getitem_242 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_240);  getitem_240 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_28, primals_788, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_787, primals_783, primals_785, primals_786, True, 0.1, 1e-05);  primals_783 = None
        getitem_243 = native_batch_norm_default_81[0]
        getitem_244 = native_batch_norm_default_81[1]
        getitem_245 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        convolution_default_82 = torch.ops.aten.convolution.default(getitem_243, primals_789, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_794, primals_790, primals_792, primals_793, True, 0.1, 1e-05);  primals_790 = None
        getitem_246 = native_batch_norm_default_82[0]
        getitem_247 = native_batch_norm_default_82[1]
        getitem_248 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_246, add_tensor_11);  getitem_246 = add_tensor_11 = None
        relu_default_11 = torch.ops.aten.relu.default(add_tensor_12)
        convolution_default_83 = torch.ops.aten.convolution.default(relu_default_11, primals_260, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_259, primals_255, primals_257, primals_258, True, 0.1, 1e-05);  primals_255 = None
        getitem_249 = native_batch_norm_default_83[0]
        getitem_250 = native_batch_norm_default_83[1]
        getitem_251 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        convolution_default_84 = torch.ops.aten.convolution.default(getitem_249, primals_261, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_266, primals_262, primals_264, primals_265, True, 0.1, 1e-05);  primals_262 = None
        getitem_252 = native_batch_norm_default_84[0]
        getitem_253 = native_batch_norm_default_84[1]
        getitem_254 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_252);  getitem_252 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_29, primals_272, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_271, primals_267, primals_269, primals_270, True, 0.1, 1e-05);  primals_267 = None
        getitem_255 = native_batch_norm_default_85[0]
        getitem_256 = native_batch_norm_default_85[1]
        getitem_257 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        convolution_default_86 = torch.ops.aten.convolution.default(getitem_255, primals_273, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_278, primals_274, primals_276, primals_277, True, 0.1, 1e-05);  primals_274 = None
        getitem_258 = native_batch_norm_default_86[0]
        getitem_259 = native_batch_norm_default_86[1]
        getitem_260 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_258);  getitem_258 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_30, primals_284, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_283, primals_279, primals_281, primals_282, True, 0.1, 1e-05);  primals_279 = None
        getitem_261 = native_batch_norm_default_87[0]
        getitem_262 = native_batch_norm_default_87[1]
        getitem_263 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        convolution_default_88 = torch.ops.aten.convolution.default(getitem_261, primals_285, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_290, primals_286, primals_288, primals_289, True, 0.1, 1e-05);  primals_286 = None
        getitem_264 = native_batch_norm_default_88[0]
        getitem_265 = native_batch_norm_default_88[1]
        getitem_266 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(getitem_264, add_tensor_12);  getitem_264 = add_tensor_12 = None
        relu_default_12 = torch.ops.aten.relu.default(add_tensor_13)
        convolution_default_89 = torch.ops.aten.convolution.default(relu_default_12, primals_296, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_295, primals_291, primals_293, primals_294, True, 0.1, 1e-05);  primals_291 = None
        getitem_267 = native_batch_norm_default_89[0]
        getitem_268 = native_batch_norm_default_89[1]
        getitem_269 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        convolution_default_90 = torch.ops.aten.convolution.default(getitem_267, primals_297, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_302, primals_298, primals_300, primals_301, True, 0.1, 1e-05);  primals_298 = None
        getitem_270 = native_batch_norm_default_90[0]
        getitem_271 = native_batch_norm_default_90[1]
        getitem_272 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_270);  getitem_270 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_31, primals_308, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_307, primals_303, primals_305, primals_306, True, 0.1, 1e-05);  primals_303 = None
        getitem_273 = native_batch_norm_default_91[0]
        getitem_274 = native_batch_norm_default_91[1]
        getitem_275 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        convolution_default_92 = torch.ops.aten.convolution.default(getitem_273, primals_309, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_314, primals_310, primals_312, primals_313, True, 0.1, 1e-05);  primals_310 = None
        getitem_276 = native_batch_norm_default_92[0]
        getitem_277 = native_batch_norm_default_92[1]
        getitem_278 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_276);  getitem_276 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_32, primals_320, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_319, primals_315, primals_317, primals_318, True, 0.1, 1e-05);  primals_315 = None
        getitem_279 = native_batch_norm_default_93[0]
        getitem_280 = native_batch_norm_default_93[1]
        getitem_281 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        convolution_default_94 = torch.ops.aten.convolution.default(getitem_279, primals_321, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_326, primals_322, primals_324, primals_325, True, 0.1, 1e-05);  primals_322 = None
        getitem_282 = native_batch_norm_default_94[0]
        getitem_283 = native_batch_norm_default_94[1]
        getitem_284 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(getitem_282, add_tensor_13);  getitem_282 = add_tensor_13 = None
        relu_default_13 = torch.ops.aten.relu.default(add_tensor_14)
        convolution_default_95 = torch.ops.aten.convolution.default(relu_default_13, primals_332, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_331, primals_327, primals_329, primals_330, True, 0.1, 1e-05);  primals_327 = None
        getitem_285 = native_batch_norm_default_95[0]
        getitem_286 = native_batch_norm_default_95[1]
        getitem_287 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        convolution_default_96 = torch.ops.aten.convolution.default(getitem_285, primals_333, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_338, primals_334, primals_336, primals_337, True, 0.1, 1e-05);  primals_334 = None
        getitem_288 = native_batch_norm_default_96[0]
        getitem_289 = native_batch_norm_default_96[1]
        getitem_290 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_288);  getitem_288 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_33, primals_344, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_343, primals_339, primals_341, primals_342, True, 0.1, 1e-05);  primals_339 = None
        getitem_291 = native_batch_norm_default_97[0]
        getitem_292 = native_batch_norm_default_97[1]
        getitem_293 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        convolution_default_98 = torch.ops.aten.convolution.default(getitem_291, primals_345, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_350, primals_346, primals_348, primals_349, True, 0.1, 1e-05);  primals_346 = None
        getitem_294 = native_batch_norm_default_98[0]
        getitem_295 = native_batch_norm_default_98[1]
        getitem_296 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_294);  getitem_294 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_34, primals_356, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_355, primals_351, primals_353, primals_354, True, 0.1, 1e-05);  primals_351 = None
        getitem_297 = native_batch_norm_default_99[0]
        getitem_298 = native_batch_norm_default_99[1]
        getitem_299 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        convolution_default_100 = torch.ops.aten.convolution.default(getitem_297, primals_357, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_362, primals_358, primals_360, primals_361, True, 0.1, 1e-05);  primals_358 = None
        getitem_300 = native_batch_norm_default_100[0]
        getitem_301 = native_batch_norm_default_100[1]
        getitem_302 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_300, add_tensor_14);  getitem_300 = add_tensor_14 = None
        relu_default_14 = torch.ops.aten.relu.default(add_tensor_15)
        convolution_default_101 = torch.ops.aten.convolution.default(relu_default_14, primals_368, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_367, primals_363, primals_365, primals_366, True, 0.1, 1e-05);  primals_363 = None
        getitem_303 = native_batch_norm_default_101[0]
        getitem_304 = native_batch_norm_default_101[1]
        getitem_305 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        convolution_default_102 = torch.ops.aten.convolution.default(getitem_303, primals_369, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_374, primals_370, primals_372, primals_373, True, 0.1, 1e-05);  primals_370 = None
        getitem_306 = native_batch_norm_default_102[0]
        getitem_307 = native_batch_norm_default_102[1]
        getitem_308 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_306);  getitem_306 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_35, primals_380, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_379, primals_375, primals_377, primals_378, True, 0.1, 1e-05);  primals_375 = None
        getitem_309 = native_batch_norm_default_103[0]
        getitem_310 = native_batch_norm_default_103[1]
        getitem_311 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        convolution_default_104 = torch.ops.aten.convolution.default(getitem_309, primals_381, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_386, primals_382, primals_384, primals_385, True, 0.1, 1e-05);  primals_382 = None
        getitem_312 = native_batch_norm_default_104[0]
        getitem_313 = native_batch_norm_default_104[1]
        getitem_314 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_312);  getitem_312 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_36, primals_392, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_391, primals_387, primals_389, primals_390, True, 0.1, 1e-05);  primals_387 = None
        getitem_315 = native_batch_norm_default_105[0]
        getitem_316 = native_batch_norm_default_105[1]
        getitem_317 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        convolution_default_106 = torch.ops.aten.convolution.default(getitem_315, primals_393, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_398, primals_394, primals_396, primals_397, True, 0.1, 1e-05);  primals_394 = None
        getitem_318 = native_batch_norm_default_106[0]
        getitem_319 = native_batch_norm_default_106[1]
        getitem_320 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_318, add_tensor_15);  getitem_318 = add_tensor_15 = None
        relu_default_15 = torch.ops.aten.relu.default(add_tensor_16)
        convolution_default_107 = torch.ops.aten.convolution.default(relu_default_15, primals_404, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_403, primals_399, primals_401, primals_402, True, 0.1, 1e-05);  primals_399 = None
        getitem_321 = native_batch_norm_default_107[0]
        getitem_322 = native_batch_norm_default_107[1]
        getitem_323 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        convolution_default_108 = torch.ops.aten.convolution.default(getitem_321, primals_405, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_410, primals_406, primals_408, primals_409, True, 0.1, 1e-05);  primals_406 = None
        getitem_324 = native_batch_norm_default_108[0]
        getitem_325 = native_batch_norm_default_108[1]
        getitem_326 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_324);  getitem_324 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_37, primals_416, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_415, primals_411, primals_413, primals_414, True, 0.1, 1e-05);  primals_411 = None
        getitem_327 = native_batch_norm_default_109[0]
        getitem_328 = native_batch_norm_default_109[1]
        getitem_329 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        convolution_default_110 = torch.ops.aten.convolution.default(getitem_327, primals_417, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_422, primals_418, primals_420, primals_421, True, 0.1, 1e-05);  primals_418 = None
        getitem_330 = native_batch_norm_default_110[0]
        getitem_331 = native_batch_norm_default_110[1]
        getitem_332 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_330);  getitem_330 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_38, primals_428, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_427, primals_423, primals_425, primals_426, True, 0.1, 1e-05);  primals_423 = None
        getitem_333 = native_batch_norm_default_111[0]
        getitem_334 = native_batch_norm_default_111[1]
        getitem_335 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        convolution_default_112 = torch.ops.aten.convolution.default(getitem_333, primals_429, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_434, primals_430, primals_432, primals_433, True, 0.1, 1e-05);  primals_430 = None
        getitem_336 = native_batch_norm_default_112[0]
        getitem_337 = native_batch_norm_default_112[1]
        getitem_338 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_336, add_tensor_16);  getitem_336 = add_tensor_16 = None
        relu_default_16 = torch.ops.aten.relu.default(add_tensor_17)
        convolution_default_113 = torch.ops.aten.convolution.default(relu_default_16, primals_440, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_439, primals_435, primals_437, primals_438, True, 0.1, 1e-05);  primals_435 = None
        getitem_339 = native_batch_norm_default_113[0]
        getitem_340 = native_batch_norm_default_113[1]
        getitem_341 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        convolution_default_114 = torch.ops.aten.convolution.default(getitem_339, primals_441, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_446, primals_442, primals_444, primals_445, True, 0.1, 1e-05);  primals_442 = None
        getitem_342 = native_batch_norm_default_114[0]
        getitem_343 = native_batch_norm_default_114[1]
        getitem_344 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_342);  getitem_342 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_39, primals_452, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_451, primals_447, primals_449, primals_450, True, 0.1, 1e-05);  primals_447 = None
        getitem_345 = native_batch_norm_default_115[0]
        getitem_346 = native_batch_norm_default_115[1]
        getitem_347 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        convolution_default_116 = torch.ops.aten.convolution.default(getitem_345, primals_453, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_458, primals_454, primals_456, primals_457, True, 0.1, 1e-05);  primals_454 = None
        getitem_348 = native_batch_norm_default_116[0]
        getitem_349 = native_batch_norm_default_116[1]
        getitem_350 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_348);  getitem_348 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_40, primals_464, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_463, primals_459, primals_461, primals_462, True, 0.1, 1e-05);  primals_459 = None
        getitem_351 = native_batch_norm_default_117[0]
        getitem_352 = native_batch_norm_default_117[1]
        getitem_353 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        convolution_default_118 = torch.ops.aten.convolution.default(getitem_351, primals_465, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_470, primals_466, primals_468, primals_469, True, 0.1, 1e-05);  primals_466 = None
        getitem_354 = native_batch_norm_default_118[0]
        getitem_355 = native_batch_norm_default_118[1]
        getitem_356 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_354, add_tensor_17);  getitem_354 = add_tensor_17 = None
        convolution_default_119 = torch.ops.aten.convolution.default(add_tensor_18, primals_79, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_84, primals_80, primals_82, primals_83, True, 0.1, 1e-05);  primals_80 = None
        getitem_357 = native_batch_norm_default_119[0]
        getitem_358 = native_batch_norm_default_119[1]
        getitem_359 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        relu_default_17 = torch.ops.aten.relu.default(add_tensor_18)
        convolution_default_120 = torch.ops.aten.convolution.default(relu_default_17, primals_48, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_47, primals_43, primals_45, primals_46, True, 0.1, 1e-05);  primals_43 = None
        getitem_360 = native_batch_norm_default_120[0]
        getitem_361 = native_batch_norm_default_120[1]
        getitem_362 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        convolution_default_121 = torch.ops.aten.convolution.default(getitem_360, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_54, primals_50, primals_52, primals_53, True, 0.1, 1e-05);  primals_50 = None
        getitem_363 = native_batch_norm_default_121[0]
        getitem_364 = native_batch_norm_default_121[1]
        getitem_365 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_363);  getitem_363 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_41, primals_60, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_59, primals_55, primals_57, primals_58, True, 0.1, 1e-05);  primals_55 = None
        getitem_366 = native_batch_norm_default_122[0]
        getitem_367 = native_batch_norm_default_122[1]
        getitem_368 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        convolution_default_123 = torch.ops.aten.convolution.default(getitem_366, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_66, primals_62, primals_64, primals_65, True, 0.1, 1e-05);  primals_62 = None
        getitem_369 = native_batch_norm_default_123[0]
        getitem_370 = native_batch_norm_default_123[1]
        getitem_371 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_369);  getitem_369 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_42, primals_72, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1024)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_71, primals_67, primals_69, primals_70, True, 0.1, 1e-05);  primals_67 = None
        getitem_372 = native_batch_norm_default_124[0]
        getitem_373 = native_batch_norm_default_124[1]
        getitem_374 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        convolution_default_125 = torch.ops.aten.convolution.default(getitem_372, primals_73, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_78, primals_74, primals_76, primals_77, True, 0.1, 1e-05);  primals_74 = None
        getitem_375 = native_batch_norm_default_125[0]
        getitem_376 = native_batch_norm_default_125[1]
        getitem_377 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_375, getitem_357);  getitem_375 = getitem_357 = None
        relu__default_43 = torch.ops.aten.relu_.default(add_tensor_19);  add_tensor_19 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_43, primals_201, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1024)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_200, primals_196, primals_198, primals_199, True, 0.1, 1e-05);  primals_196 = None
        getitem_378 = native_batch_norm_default_126[0]
        getitem_379 = native_batch_norm_default_126[1]
        getitem_380 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        convolution_default_127 = torch.ops.aten.convolution.default(getitem_378, primals_202, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_183, primals_179, primals_181, primals_182, True, 0.1, 1e-05);  primals_179 = None
        getitem_381 = native_batch_norm_default_127[0]
        getitem_382 = native_batch_norm_default_127[1]
        getitem_383 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_381);  getitem_381 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_44, primals_208, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1536)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_207, primals_203, primals_205, primals_206, True, 0.1, 1e-05);  primals_203 = None
        getitem_384 = native_batch_norm_default_128[0]
        getitem_385 = native_batch_norm_default_128[1]
        getitem_386 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        convolution_default_129 = torch.ops.aten.convolution.default(getitem_384, primals_209, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_188, primals_184, primals_186, primals_187, True, 0.1, 1e-05);  primals_184 = None
        getitem_387 = native_batch_norm_default_129[0]
        getitem_388 = native_batch_norm_default_129[1]
        getitem_389 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_387);  getitem_387 = None
        convolution_default_130 = torch.ops.aten.convolution.default(relu__default_45, primals_215, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1536)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_214, primals_210, primals_212, primals_213, True, 0.1, 1e-05);  primals_210 = None
        getitem_390 = native_batch_norm_default_130[0]
        getitem_391 = native_batch_norm_default_130[1]
        getitem_392 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        convolution_default_131 = torch.ops.aten.convolution.default(getitem_390, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_193, primals_189, primals_191, primals_192, True, 0.1, 1e-05);  primals_189 = None
        getitem_393 = native_batch_norm_default_131[0]
        getitem_394 = native_batch_norm_default_131[1]
        getitem_395 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_393);  getitem_393 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_46, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [64, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_218);  primals_218 = None
        addmm_default = torch.ops.aten.addmm.default(primals_217, view_default, t_default);  primals_217 = None
        return [addmm_default, primals_4, getitem_304, getitem_187, getitem_305, primals_182, convolution_default_86, convolution_default_87, relu__default_22, primals_12, getitem_303, convolution_default_63, convolution_default_102, getitem_260, primals_10, getitem_259, primals_6, getitem_188, primals_366, getitem_308, relu__default_30, getitem_307, primals_11, primals_7, getitem_191, getitem_190, getitem_189, relu__default_35, primals_5, convolution_default_64, primals_183, getitem_263, convolution_default_103, getitem_262, getitem_261, getitem_309, primals_188, convolution_default_88, primals_186, relu_default_8, convolution_default_104, primals_187, getitem_310, getitem_193, getitem_311, getitem_194, primals_3, relu__default_2, getitem_38, getitem_212, convolution_default_5, getitem_211, getitem_236, convolution_default_6, getitem_235, convolution_default_13, convolution_default_14, getitem_41, primals_241, getitem_40, getitem_17, relu__default_27, getitem_16, getitem_15, relu_default_12, convolution_default_71, convolution_default_79, relu__default_6, primals_242, primals_181, getitem_215, getitem_214, primals_233, getitem_213, getitem_42, getitem_239, getitem_238, getitem_20, getitem_237, primals_237, getitem_19, convolution_default_72, primals_240, getitem_43, convolution_default_80, primals_236, getitem_44, relu__default_3, convolution_default_15, primals_235, getitem_217, convolution_default_7, getitem_218, primals_234, getitem_241, add_tensor_1, primals_272, primals_581, primals_582, primals_278, primals_224, primals_281, primals_273, primals_578, primals_223, primals_577, primals_576, primals_270, primals_573, primals_571, primals_271, primals_276, primals_572, primals_225, primals_221, primals_566, primals_277, primals_570, primals_585, primals_569, primals_583, primals_222, primals_269, primals_584, getitem_163, getitem_164, primals_309, primals_787, relu__default_19, primals_319, convolution_default_55, primals_786, primals_785, primals_321, primals_792, primals_789, getitem_167, getitem_166, getitem_165, primals_318, primals_794, convolution_default_56, primals_788, primals_320, primals_312, getitem_169, getitem_170, primals_314, primals_324, relu__default_20, convolution_default_57, primals_313, primals_793, primals_317, primals_795, primals_704, primals_710, primals_717, getitem_377, getitem_376, primals_714, primals_705, convolution_default_126, primals_709, primals_708, primals_715, primals_720, getitem_380, getitem_379, getitem_378, primals_713, primals_102, convolution_default_127, primals_106, primals_103, primals_111, primals_108, primals_716, getitem_382, primals_107, getitem_383, convolution_default_47, getitem_143, getitem_142, getitem_141, convolution_default_48, getitem_146, getitem_145, relu__default_17, convolution_default_49, primals_288, primals_283, primals_282, primals_293, primals_284, primals_285, primals_294, primals_290, primals_289, relu__default_14, primals_681, primals_680, primals_679, getitem_119, getitem_118, primals_678, getitem_117, primals_677, primals_374, primals_674, primals_369, convolution_default_40, primals_673, primals_379, getitem_122, primals_672, getitem_121, primals_368, primals_367, primals_669, primals_377, primals_378, primals_668, primals_373, relu_default_7, primals_372, primals_667, primals_666, convolution_default_41, primals_665, getitem_95, getitem_94, getitem_93, convolution_default_32, getitem_98, getitem_97, relu__default_12, convolution_default_33, getitem_99, getitem_266, primals_257, getitem_265, getitem_71, getitem_70, getitem_69, primals_265, primals_258, convolution_default_89, primals_261, convolution_default_24, getitem_269, primals_253, getitem_268, getitem_74, getitem_267, getitem_73, convolution_default_90, primals_266, primals_252, relu__default_9, convolution_default_25, getitem_271, getitem_272, primals_259, primals_254, primals_264, getitem_76, convolution_default_91, primals_260, getitem_75, relu__default_31, getitem_47, primals_330, primals_157, getitem_46, getitem_314, primals_325, getitem_313, primals_326, getitem_338, primals_154, getitem_337, primals_73, primals_66, relu__default_36, primals_156, primals_155, getitem_50, getitem_49, primals_341, primals_145, primals_329, convolution_default_105, convolution_default_113, relu_default, primals_65, primals_70, getitem_317, getitem_316, getitem_315, getitem_341, relu_default_3, getitem_340, primals_150, getitem_339, primals_64, primals_153, primals_332, primals_143, convolution_default_106, primals_76, primals_331, getitem_52, primals_336, convolution_default_16, convolution_default_17, convolution_default_114, primals_333, primals_69, primals_78, primals_71, primals_72, primals_144, relu__default_4, relu_default_15, primals_149, getitem_51, primals_337, primals_338, getitem_53, getitem_319, primals_79, getitem_320, primals_77, convolution_default, convolution_default_18, getitem_343, primals_148, getitem_242, relu_default_11, getitem_23, getitem_21, convolution_default_65, getitem_22, relu__default_28, convolution_default_81, primals_758, convolution_default_82, primals_761, convolution_default_8, getitem_197, primals_757, getitem_196, getitem_195, primals_112, primals_756, primals_113, getitem_245, convolution_default_66, getitem_244, getitem_26, getitem_243, getitem_25, primals_753, primals_752, primals_121, getitem_200, primals_114, primals_750, getitem_199, primals_120, relu_default_2, primals_749, primals_118, primals_751, relu__default_23, getitem_247, primals_115, convolution_default_9, getitem_248, primals_119, primals_746, primals_125, primals_745, getitem_28, convolution_default_67, primals_744, primals_126, primals_124, getitem_29, relu_default_14, convolution_default_10, convolution_default_83, relu__default_25, getitem_290, getitem_289, convolution_default_73, convolution_default_74, convolution_default_120, primals_48, primals_42, relu__default_33, convolution_default_97, getitem_362, getitem_221, getitem_361, getitem_220, getitem_360, primals_41, getitem_219, primals_40, convolution_default_121, primals_49, getitem_293, getitem_292, getitem_291, primals_47, getitem_365, getitem_224, primals_45, getitem_364, getitem_223, convolution_default_98, primals_46, primals_37, relu__default_41, relu__default_26, getitem_295, primals_36, primals_35, convolution_default_122, convolution_default_75, getitem_296, primals_34, convolution_default_99, relu__default_34, primals_768, primals_725, primals_726, getitem_173, primals_727, getitem_172, getitem_171, primals_765, primals_728, primals_764, primals_729, primals_770, primals_732, convolution_default_58, getitem_176, primals_733, getitem_175, primals_734, primals_773, primals_738, primals_775, primals_776, primals_737, primals_777, relu_default_10, primals_722, primals_740, convolution_default_59, primals_782, primals_762, primals_739, primals_763, primals_780, primals_769, primals_721, primals_781, getitem_178, primals_741, getitem_177, primals_774, primals_168, getitem_149, primals_60, getitem_147, getitem_148, primals_160, primals_52, primals_54, primals_166, primals_57, primals_59, convolution_default_50, getitem_152, primals_161, getitem_151, primals_58, primals_167, relu__default_18, primals_61, primals_172, primals_171, primals_176, primals_163, convolution_default_51, primals_53, primals_177, getitem_154, primals_173, getitem_155, getitem_153, primals_162, getitem_125, getitem_124, getitem_123, convolution_default_42, getitem_128, getitem_127, relu__default_15, convolution_default_43, getitem_129, getitem_130, getitem_131, convolution_default_44, getitem_100, primals_552, getitem_101, primals_213, primals_553, primals_205, convolution_default_34, primals_207, primals_561, primals_356, getitem_104, primals_548, getitem_103, primals_565, primals_206, primals_357, primals_361, primals_355, primals_214, primals_362, primals_559, primals_209, relu_default_6, primals_560, primals_212, primals_557, convolution_default_35, primals_558, getitem_105, primals_549, primals_360, primals_208, primals_554, getitem_106, primals_216, primals_564, getitem_107, primals_546, primals_365, primals_547, convolution_default_36, primals_215, primals_641, primals_617, relu__default_44, convolution_default_128, getitem_77, primals_500, convolution_default_26, convolution_default_129, primals_504, primals_618, convolution_default_27, primals_620, getitem_80, primals_631, getitem_79, primals_192, primals_499, getitem_386, primals_501, getitem_385, primals_606, getitem_384, primals_632, primals_191, primals_613, primals_633, primals_202, relu__default_10, primals_201, primals_200, primals_605, primals_621, primals_638, primals_194, primals_637, primals_643, getitem_389, primals_506, primals_636, getitem_388, primals_607, getitem_83, primals_642, getitem_82, primals_492, primals_619, getitem_81, primals_624, primals_612, primals_497, primals_625, relu__default_45, primals_193, primals_498, primals_626, convolution_default_28, primals_609, primals_493, primals_494, primals_195, primals_614, primals_505, convolution_default_130, primals_198, primals_629, primals_608, primals_199, primals_630, primals_593, primals_596, primals_690, primals_691, primals_602, primals_692, primals_693, primals_588, primals_601, primals_696, primals_597, primals_697, primals_698, primals_590, primals_589, primals_701, primals_702, primals_703, primals_600, primals_684, primals_595, primals_685, primals_689, primals_594, primals_686, primals_133, primals_138, primals_129, primals_130, primals_137, primals_131, primals_136, primals_141, primals_132, primals_142, getitem_344, getitem_227, getitem_226, primals_22, relu__default_39, relu__default_43, convolution_default_107, convolution_default_115, primals_535, getitem_225, primals_536, convolution_default_116, convolution_default_76, primals_15, getitem_323, primals_537, getitem_322, getitem_321, primals_27, getitem_230, getitem_347, getitem_229, getitem_346, primals_29, getitem_345, convolution_default_108, primals_16, primals_534, primals_23, primals_540, primals_545, getitem_326, relu_default_13, primals_528, primals_529, getitem_325, convolution_default_117, primals_28, convolution_default_77, getitem_349, primals_30, getitem_231, getitem_350, primals_17, relu__default_37, primals_18, getitem_232, primals_530, relu__default_40, primals_24, primals_542, primals_19, convolution_default_78, convolution_default_109, getitem_233, primals_31, primals_541, primals_533, add_tensor_18, primals_433, primals_420, primals_416, getitem_56, getitem_275, getitem_55, getitem_274, primals_415, getitem_273, getitem_299, getitem_298, getitem_297, getitem_2, relu__default_7, getitem_1, convolution_default_19, convolution_default_92, relu__default, getitem_278, convolution_default_100, getitem_277, getitem_302, primals_417, getitem_301, getitem_59, getitem_58, getitem_57, convolution_default_1, relu__default_32, primals_427, primals_428, convolution_default_20, convolution_default_93, primals_425, convolution_default_119, primals_432, primals_429, convolution_default_2, convolution_default_101, getitem_4, getitem_5, primals_421, relu__default_1, primals_422, getitem_61, getitem_280, primals_426, getitem_279, convolution_default_84, getitem_179, getitem_32, getitem_251, getitem_31, getitem_250, getitem_30, convolution_default_60, getitem_249, convolution_default_61, getitem_182, getitem_181, convolution_default_11, relu__default_21, getitem_254, getitem_253, getitem_35, getitem_34, getitem_183, relu__default_29, relu__default_5, getitem_184, convolution_default_85, getitem_185, convolution_default_12, convolution_default_62, getitem_256, getitem_257, getitem_37, getitem_255, getitem_36, primals_230, getitem_202, getitem_203, primals_229, getitem_201, convolution_default_68, convolution_default_69, getitem_206, getitem_205, relu__default_24, primals_228, getitem_207, getitem_208, getitem_209, convolution_default_70, primals_408, getitem_368, getitem_367, primals_409, primals_414, primals_402, getitem_366, primals_413, convolution_default_123, getitem_371, getitem_370, relu__default_42, primals_398, convolution_default_124, getitem_372, primals_397, primals_410, primals_403, getitem_373, primals_401, getitem_374, primals_405, primals_404, convolution_default_125, primals_396, primals_380, primals_390, convolution_default_52, primals_348, primals_345, primals_381, getitem_158, getitem_157, primals_100, primals_391, primals_344, primals_393, primals_343, primals_350, relu_default_9, convolution_default_53, primals_392, primals_389, primals_384, getitem_161, getitem_160, getitem_159, primals_353, primals_101, primals_99, primals_385, convolution_default_54, primals_386, primals_354, primals_342, primals_349, convolution_default_45, getitem_134, getitem_133, relu__default_16, getitem_137, getitem_136, getitem_135, convolution_default_46, relu_default_5, getitem_139, getitem_140, getitem_392, getitem_110, getitem_391, getitem_109, getitem_390, convolution_default_37, relu__default_13, convolution_default_131, getitem_395, getitem_394, getitem_113, getitem_112, getitem_111, relu__default_46, convolution_default_38, view_default, getitem_115, convolution_default_39, t_default, getitem_116, getitem_85, primals_656, getitem_86, primals_245, primals_657, primals_645, convolution_default_29, getitem_89, getitem_88, primals_248, primals_655, getitem_87, primals_653, primals_649, primals_650, convolution_default_30, primals_246, primals_654, primals_662, primals_644, primals_648, primals_660, getitem_91, getitem_92, primals_661, relu__default_11, convolution_default_31, primals_247, primals_456, primals_463, relu_default_1, primals_453, primals_457, getitem_8, primals_465, getitem_7, primals_89, primals_87, primals_461, primals_94, primals_464, primals_96, primals_82, convolution_default_3, getitem_11, getitem_10, getitem_9, primals_95, primals_91, primals_88, primals_83, convolution_default_4, primals_469, primals_468, primals_462, primals_470, primals_458, primals_90, getitem_13, getitem_14, primals_84, primals_178, getitem_62, primals_480, getitem_329, getitem_327, getitem_328, primals_473, relu__default_8, primals_481, convolution_default_21, convolution_default_110, convolution_default_22, getitem_65, primals_474, getitem_332, getitem_64, getitem_63, primals_482, getitem_331, relu__default_38, primals_488, convolution_default_111, primals_475, getitem_67, primals_485, getitem_68, getitem_333, primals_486, getitem_334, primals_477, primals_489, convolution_default_112, primals_476, relu_default_4, getitem_335, convolution_default_23, primals_487, primals_446, getitem_281, primals_516, convolution_default_118, primals_437, primals_308, primals_305, primals_509, getitem_353, getitem_352, primals_438, getitem_351, primals_523, convolution_default_94, primals_440, primals_295, primals_296, primals_434, getitem_284, primals_510, getitem_283, primals_444, primals_441, primals_302, primals_521, primals_449, primals_450, primals_513, getitem_356, getitem_355, primals_439, relu_default_16, primals_452, primals_511, convolution_default_95, getitem_285, primals_451, primals_297, primals_249, primals_306, primals_525, getitem_286, primals_307, getitem_287, primals_518, primals_445, primals_517, primals_512, convolution_default_96, primals_522, primals_300, getitem_358, getitem_359, primals_301, primals_524, relu_default_17]
        
