
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/gluon_xception65/gluon_xception65_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_795, primals_194, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_170, 1);  primals_170 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_173, primals_169, primals_171, primals_172, True, 0.1, 1e-05);  primals_169 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_195, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_175, 1);  primals_175 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_178, primals_174, primals_176, primals_177, True, 0.1, 1e-05);  primals_174 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_37, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_39, 1);  primals_39 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_42, primals_38, primals_40, primals_41, True, 0.1, 1e-05);  primals_38 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_1, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 64)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_9, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_9, 1);  primals_9 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_12, primals_8, primals_10, primals_11, True, 0.1, 1e-05);  primals_8 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_2, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_14, 1);  primals_14 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_17, primals_13, primals_15, primals_16, True, 0.1, 1e-05);  primals_13 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_21, 1);  primals_21 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_24, primals_20, primals_22, primals_23, True, 0.1, 1e-05);  primals_20 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_3, primals_30, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 128)
        add__tensor_7 = torch.ops.aten.add_.Tensor(primals_26, 1);  primals_26 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_29, primals_25, primals_27, primals_28, True, 0.1, 1e-05);  primals_25 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_21, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_33, 1);  primals_33 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_36, primals_32, primals_34, primals_35, True, 0.1, 1e-05);  primals_32 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor = torch.ops.aten.add.Tensor(getitem_24, getitem_6);  getitem_24 = getitem_6 = None
        relu__default_4 = torch.ops.aten.relu_.default(add_tensor);  add_tensor = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_4, primals_121, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_123, 1);  primals_123 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_126, primals_122, primals_124, primals_125, True, 0.1, 1e-05);  primals_122 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_4, primals_90, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 128)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_86, 1);  primals_86 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_89, primals_85, primals_87, primals_88, True, 0.1, 1e-05);  primals_85 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_11 = torch.ops.aten.convolution.default(getitem_30, primals_91, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(primals_93, 1);  primals_93 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_96, primals_92, primals_94, primals_95, True, 0.1, 1e-05);  primals_92 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_33);  getitem_33 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_5, primals_102, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 256)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_98, 1);  primals_98 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_101, primals_97, primals_99, primals_100, True, 0.1, 1e-05);  primals_97 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_13 = torch.ops.aten.convolution.default(getitem_36, primals_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_105, 1);  primals_105 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_108, primals_104, primals_106, primals_107, True, 0.1, 1e-05);  primals_104 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_6, primals_114, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 256)
        add__tensor_14 = torch.ops.aten.add_.Tensor(primals_110, 1);  primals_110 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_113, primals_109, primals_111, primals_112, True, 0.1, 1e-05);  primals_109 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_15 = torch.ops.aten.convolution.default(getitem_42, primals_115, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_117, 1);  primals_117 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_120, primals_116, primals_118, primals_119, True, 0.1, 1e-05);  primals_116 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_1 = torch.ops.aten.add.Tensor(getitem_45, getitem_27);  getitem_45 = getitem_27 = None
        convolution_default_16 = torch.ops.aten.convolution.default(add_tensor_1, primals_163, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_165, 1);  primals_165 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_168, primals_164, primals_166, primals_167, True, 0.1, 1e-05);  primals_164 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default = torch.ops.aten.relu.default(add_tensor_1)
        convolution_default_17 = torch.ops.aten.convolution.default(relu_default, primals_132, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 256)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_128, 1);  primals_128 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_131, primals_127, primals_129, primals_130, True, 0.1, 1e-05);  primals_127 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_18 = torch.ops.aten.convolution.default(getitem_51, primals_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_135, 1);  primals_135 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_138, primals_134, primals_136, primals_137, True, 0.1, 1e-05);  primals_134 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_54);  getitem_54 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_7, primals_144, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_19 = torch.ops.aten.add_.Tensor(primals_140, 1);  primals_140 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_143, primals_139, primals_141, primals_142, True, 0.1, 1e-05);  primals_139 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_57, primals_145, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_20 = torch.ops.aten.add_.Tensor(primals_147, 1);  primals_147 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_150, primals_146, primals_148, primals_149, True, 0.1, 1e-05);  primals_146 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_8, primals_156, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_152, 1);  primals_152 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_155, primals_151, primals_153, primals_154, True, 0.1, 1e-05);  primals_151 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_22 = torch.ops.aten.convolution.default(getitem_63, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_159, 1);  primals_159 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_162, primals_158, primals_160, primals_161, True, 0.1, 1e-05);  primals_158 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_66, getitem_48);  getitem_66 = getitem_48 = None
        relu_default_1 = torch.ops.aten.relu.default(add_tensor_2)
        convolution_default_23 = torch.ops.aten.convolution.default(relu_default_1, primals_224, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_23 = torch.ops.aten.add_.Tensor(primals_220, 1);  primals_220 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_223, primals_219, primals_221, primals_222, True, 0.1, 1e-05);  primals_219 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_24 = torch.ops.aten.convolution.default(getitem_69, primals_225, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_24 = torch.ops.aten.add_.Tensor(primals_227, 1);  primals_227 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_230, primals_226, primals_228, primals_229, True, 0.1, 1e-05);  primals_226 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_72);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_9, primals_236, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_25 = torch.ops.aten.add_.Tensor(primals_232, 1);  primals_232 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_235, primals_231, primals_233, primals_234, True, 0.1, 1e-05);  primals_231 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_26 = torch.ops.aten.convolution.default(getitem_75, primals_237, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_26 = torch.ops.aten.add_.Tensor(primals_239, 1);  primals_239 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_242, primals_238, primals_240, primals_241, True, 0.1, 1e-05);  primals_238 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_10, primals_248, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_244, 1);  primals_244 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_247, primals_243, primals_245, primals_246, True, 0.1, 1e-05);  primals_243 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_28 = torch.ops.aten.convolution.default(getitem_81, primals_249, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_28 = torch.ops.aten.add_.Tensor(primals_251, 1);  primals_251 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_254, primals_250, primals_252, primals_253, True, 0.1, 1e-05);  primals_250 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_84, add_tensor_2);  getitem_84 = add_tensor_2 = None
        relu_default_2 = torch.ops.aten.relu.default(add_tensor_3)
        convolution_default_29 = torch.ops.aten.convolution.default(relu_default_2, primals_476, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_29 = torch.ops.aten.add_.Tensor(primals_472, 1);  primals_472 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_475, primals_471, primals_473, primals_474, True, 0.1, 1e-05);  primals_471 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_30 = torch.ops.aten.convolution.default(getitem_87, primals_477, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_479, 1);  primals_479 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_482, primals_478, primals_480, primals_481, True, 0.1, 1e-05);  primals_478 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_90);  getitem_90 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_11, primals_488, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_484, 1);  primals_484 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_487, primals_483, primals_485, primals_486, True, 0.1, 1e-05);  primals_483 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_32 = torch.ops.aten.convolution.default(getitem_93, primals_489, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_32 = torch.ops.aten.add_.Tensor(primals_491, 1);  primals_491 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_494, primals_490, primals_492, primals_493, True, 0.1, 1e-05);  primals_490 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_12, primals_500, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_496, 1);  primals_496 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_499, primals_495, primals_497, primals_498, True, 0.1, 1e-05);  primals_495 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_99, primals_501, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_34 = torch.ops.aten.add_.Tensor(primals_503, 1);  primals_503 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_506, primals_502, primals_504, primals_505, True, 0.1, 1e-05);  primals_502 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_102, add_tensor_3);  getitem_102 = add_tensor_3 = None
        relu_default_3 = torch.ops.aten.relu.default(add_tensor_4)
        convolution_default_35 = torch.ops.aten.convolution.default(relu_default_3, primals_512, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_35 = torch.ops.aten.add_.Tensor(primals_508, 1);  primals_508 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_511, primals_507, primals_509, primals_510, True, 0.1, 1e-05);  primals_507 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_36 = torch.ops.aten.convolution.default(getitem_105, primals_513, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_36 = torch.ops.aten.add_.Tensor(primals_515, 1);  primals_515 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_518, primals_514, primals_516, primals_517, True, 0.1, 1e-05);  primals_514 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_108);  getitem_108 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_13, primals_524, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_520, 1);  primals_520 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_523, primals_519, primals_521, primals_522, True, 0.1, 1e-05);  primals_519 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_38 = torch.ops.aten.convolution.default(getitem_111, primals_525, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_38 = torch.ops.aten.add_.Tensor(primals_527, 1);  primals_527 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_530, primals_526, primals_528, primals_529, True, 0.1, 1e-05);  primals_526 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_14, primals_536, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_39 = torch.ops.aten.add_.Tensor(primals_532, 1);  primals_532 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_535, primals_531, primals_533, primals_534, True, 0.1, 1e-05);  primals_531 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_117, primals_537, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_40 = torch.ops.aten.add_.Tensor(primals_539, 1);  primals_539 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_542, primals_538, primals_540, primals_541, True, 0.1, 1e-05);  primals_538 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_120, add_tensor_4);  getitem_120 = add_tensor_4 = None
        relu_default_4 = torch.ops.aten.relu.default(add_tensor_5)
        convolution_default_41 = torch.ops.aten.convolution.default(relu_default_4, primals_548, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_41 = torch.ops.aten.add_.Tensor(primals_544, 1);  primals_544 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_547, primals_543, primals_545, primals_546, True, 0.1, 1e-05);  primals_543 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_42 = torch.ops.aten.convolution.default(getitem_123, primals_549, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_42 = torch.ops.aten.add_.Tensor(primals_551, 1);  primals_551 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_554, primals_550, primals_552, primals_553, True, 0.1, 1e-05);  primals_550 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_126);  getitem_126 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_15, primals_560, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_43 = torch.ops.aten.add_.Tensor(primals_556, 1);  primals_556 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_559, primals_555, primals_557, primals_558, True, 0.1, 1e-05);  primals_555 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_44 = torch.ops.aten.convolution.default(getitem_129, primals_561, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_44 = torch.ops.aten.add_.Tensor(primals_563, 1);  primals_563 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_566, primals_562, primals_564, primals_565, True, 0.1, 1e-05);  primals_562 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_16, primals_572, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_45 = torch.ops.aten.add_.Tensor(primals_568, 1);  primals_568 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_571, primals_567, primals_569, primals_570, True, 0.1, 1e-05);  primals_567 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_46 = torch.ops.aten.convolution.default(getitem_135, primals_573, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_46 = torch.ops.aten.add_.Tensor(primals_575, 1);  primals_575 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_578, primals_574, primals_576, primals_577, True, 0.1, 1e-05);  primals_574 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_6 = torch.ops.aten.add.Tensor(getitem_138, add_tensor_5);  getitem_138 = add_tensor_5 = None
        relu_default_5 = torch.ops.aten.relu.default(add_tensor_6)
        convolution_default_47 = torch.ops.aten.convolution.default(relu_default_5, primals_584, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_47 = torch.ops.aten.add_.Tensor(primals_580, 1);  primals_580 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_583, primals_579, primals_581, primals_582, True, 0.1, 1e-05);  primals_579 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_48 = torch.ops.aten.convolution.default(getitem_141, primals_585, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_48 = torch.ops.aten.add_.Tensor(primals_587, 1);  primals_587 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_590, primals_586, primals_588, primals_589, True, 0.1, 1e-05);  primals_586 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_17, primals_596, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_49 = torch.ops.aten.add_.Tensor(primals_592, 1);  primals_592 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_595, primals_591, primals_593, primals_594, True, 0.1, 1e-05);  primals_591 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_50 = torch.ops.aten.convolution.default(getitem_147, primals_597, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_50 = torch.ops.aten.add_.Tensor(primals_599, 1);  primals_599 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_602, primals_598, primals_600, primals_601, True, 0.1, 1e-05);  primals_598 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_18, primals_608, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_51 = torch.ops.aten.add_.Tensor(primals_604, 1);  primals_604 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_607, primals_603, primals_605, primals_606, True, 0.1, 1e-05);  primals_603 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_52 = torch.ops.aten.convolution.default(getitem_153, primals_609, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_52 = torch.ops.aten.add_.Tensor(primals_611, 1);  primals_611 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_614, primals_610, primals_612, primals_613, True, 0.1, 1e-05);  primals_610 = None
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_156, add_tensor_6);  getitem_156 = add_tensor_6 = None
        relu_default_6 = torch.ops.aten.relu.default(add_tensor_7)
        convolution_default_53 = torch.ops.aten.convolution.default(relu_default_6, primals_620, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_53 = torch.ops.aten.add_.Tensor(primals_616, 1);  primals_616 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_619, primals_615, primals_617, primals_618, True, 0.1, 1e-05);  primals_615 = None
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_54 = torch.ops.aten.convolution.default(getitem_159, primals_621, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_54 = torch.ops.aten.add_.Tensor(primals_623, 1);  primals_623 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_626, primals_622, primals_624, primals_625, True, 0.1, 1e-05);  primals_622 = None
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_19, primals_632, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_55 = torch.ops.aten.add_.Tensor(primals_628, 1);  primals_628 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_631, primals_627, primals_629, primals_630, True, 0.1, 1e-05);  primals_627 = None
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_56 = torch.ops.aten.convolution.default(getitem_165, primals_633, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_56 = torch.ops.aten.add_.Tensor(primals_635, 1);  primals_635 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_638, primals_634, primals_636, primals_637, True, 0.1, 1e-05);  primals_634 = None
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_20, primals_644, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_57 = torch.ops.aten.add_.Tensor(primals_640, 1);  primals_640 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_643, primals_639, primals_641, primals_642, True, 0.1, 1e-05);  primals_639 = None
        getitem_171 = native_batch_norm_default_57[0]
        getitem_172 = native_batch_norm_default_57[1]
        getitem_173 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_58 = torch.ops.aten.convolution.default(getitem_171, primals_645, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_58 = torch.ops.aten.add_.Tensor(primals_647, 1);  primals_647 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_650, primals_646, primals_648, primals_649, True, 0.1, 1e-05);  primals_646 = None
        getitem_174 = native_batch_norm_default_58[0]
        getitem_175 = native_batch_norm_default_58[1]
        getitem_176 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_8 = torch.ops.aten.add.Tensor(getitem_174, add_tensor_7);  getitem_174 = add_tensor_7 = None
        relu_default_7 = torch.ops.aten.relu.default(add_tensor_8)
        convolution_default_59 = torch.ops.aten.convolution.default(relu_default_7, primals_656, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_59 = torch.ops.aten.add_.Tensor(primals_652, 1);  primals_652 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_655, primals_651, primals_653, primals_654, True, 0.1, 1e-05);  primals_651 = None
        getitem_177 = native_batch_norm_default_59[0]
        getitem_178 = native_batch_norm_default_59[1]
        getitem_179 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_60 = torch.ops.aten.convolution.default(getitem_177, primals_657, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_60 = torch.ops.aten.add_.Tensor(primals_659, 1);  primals_659 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_662, primals_658, primals_660, primals_661, True, 0.1, 1e-05);  primals_658 = None
        getitem_180 = native_batch_norm_default_60[0]
        getitem_181 = native_batch_norm_default_60[1]
        getitem_182 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_180);  getitem_180 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_21, primals_668, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_61 = torch.ops.aten.add_.Tensor(primals_664, 1);  primals_664 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_667, primals_663, primals_665, primals_666, True, 0.1, 1e-05);  primals_663 = None
        getitem_183 = native_batch_norm_default_61[0]
        getitem_184 = native_batch_norm_default_61[1]
        getitem_185 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_62 = torch.ops.aten.convolution.default(getitem_183, primals_669, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_62 = torch.ops.aten.add_.Tensor(primals_671, 1);  primals_671 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_674, primals_670, primals_672, primals_673, True, 0.1, 1e-05);  primals_670 = None
        getitem_186 = native_batch_norm_default_62[0]
        getitem_187 = native_batch_norm_default_62[1]
        getitem_188 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_62, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_186);  getitem_186 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_22, primals_680, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_63 = torch.ops.aten.add_.Tensor(primals_676, 1);  primals_676 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_679, primals_675, primals_677, primals_678, True, 0.1, 1e-05);  primals_675 = None
        getitem_189 = native_batch_norm_default_63[0]
        getitem_190 = native_batch_norm_default_63[1]
        getitem_191 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_64 = torch.ops.aten.convolution.default(getitem_189, primals_681, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_64 = torch.ops.aten.add_.Tensor(primals_683, 1);  primals_683 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_686, primals_682, primals_684, primals_685, True, 0.1, 1e-05);  primals_682 = None
        getitem_192 = native_batch_norm_default_64[0]
        getitem_193 = native_batch_norm_default_64[1]
        getitem_194 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_192, add_tensor_8);  getitem_192 = add_tensor_8 = None
        relu_default_8 = torch.ops.aten.relu.default(add_tensor_9)
        convolution_default_65 = torch.ops.aten.convolution.default(relu_default_8, primals_692, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_65 = torch.ops.aten.add_.Tensor(primals_688, 1);  primals_688 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_195 = native_batch_norm_default_65[0]
        getitem_196 = native_batch_norm_default_65[1]
        getitem_197 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_66 = torch.ops.aten.convolution.default(getitem_195, primals_693, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_66 = torch.ops.aten.add_.Tensor(primals_695, 1);  primals_695 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_698, primals_694, primals_696, primals_697, True, 0.1, 1e-05);  primals_694 = None
        getitem_198 = native_batch_norm_default_66[0]
        getitem_199 = native_batch_norm_default_66[1]
        getitem_200 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_198);  getitem_198 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_23, primals_704, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_67 = torch.ops.aten.add_.Tensor(primals_700, 1);  primals_700 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_703, primals_699, primals_701, primals_702, True, 0.1, 1e-05);  primals_699 = None
        getitem_201 = native_batch_norm_default_67[0]
        getitem_202 = native_batch_norm_default_67[1]
        getitem_203 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_67, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_68 = torch.ops.aten.convolution.default(getitem_201, primals_705, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_68 = torch.ops.aten.add_.Tensor(primals_707, 1);  primals_707 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_710, primals_706, primals_708, primals_709, True, 0.1, 1e-05);  primals_706 = None
        getitem_204 = native_batch_norm_default_68[0]
        getitem_205 = native_batch_norm_default_68[1]
        getitem_206 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_204);  getitem_204 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_24, primals_716, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_69 = torch.ops.aten.add_.Tensor(primals_712, 1);  primals_712 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_715, primals_711, primals_713, primals_714, True, 0.1, 1e-05);  primals_711 = None
        getitem_207 = native_batch_norm_default_69[0]
        getitem_208 = native_batch_norm_default_69[1]
        getitem_209 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_70 = torch.ops.aten.convolution.default(getitem_207, primals_717, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_70 = torch.ops.aten.add_.Tensor(primals_719, 1);  primals_719 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_722, primals_718, primals_720, primals_721, True, 0.1, 1e-05);  primals_718 = None
        getitem_210 = native_batch_norm_default_70[0]
        getitem_211 = native_batch_norm_default_70[1]
        getitem_212 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_210, add_tensor_9);  getitem_210 = add_tensor_9 = None
        relu_default_9 = torch.ops.aten.relu.default(add_tensor_10)
        convolution_default_71 = torch.ops.aten.convolution.default(relu_default_9, primals_728, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_71 = torch.ops.aten.add_.Tensor(primals_724, 1);  primals_724 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_727, primals_723, primals_725, primals_726, True, 0.1, 1e-05);  primals_723 = None
        getitem_213 = native_batch_norm_default_71[0]
        getitem_214 = native_batch_norm_default_71[1]
        getitem_215 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_71, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_72 = torch.ops.aten.convolution.default(getitem_213, primals_729, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_72 = torch.ops.aten.add_.Tensor(primals_731, 1);  primals_731 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_734, primals_730, primals_732, primals_733, True, 0.1, 1e-05);  primals_730 = None
        getitem_216 = native_batch_norm_default_72[0]
        getitem_217 = native_batch_norm_default_72[1]
        getitem_218 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_72, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_216);  getitem_216 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_25, primals_740, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_73 = torch.ops.aten.add_.Tensor(primals_736, 1);  primals_736 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_739, primals_735, primals_737, primals_738, True, 0.1, 1e-05);  primals_735 = None
        getitem_219 = native_batch_norm_default_73[0]
        getitem_220 = native_batch_norm_default_73[1]
        getitem_221 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_74 = torch.ops.aten.convolution.default(getitem_219, primals_741, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_74 = torch.ops.aten.add_.Tensor(primals_743, 1);  primals_743 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_746, primals_742, primals_744, primals_745, True, 0.1, 1e-05);  primals_742 = None
        getitem_222 = native_batch_norm_default_74[0]
        getitem_223 = native_batch_norm_default_74[1]
        getitem_224 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_222);  getitem_222 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_26, primals_752, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_75 = torch.ops.aten.add_.Tensor(primals_748, 1);  primals_748 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_751, primals_747, primals_749, primals_750, True, 0.1, 1e-05);  primals_747 = None
        getitem_225 = native_batch_norm_default_75[0]
        getitem_226 = native_batch_norm_default_75[1]
        getitem_227 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_76 = torch.ops.aten.convolution.default(getitem_225, primals_753, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_76 = torch.ops.aten.add_.Tensor(primals_755, 1);  primals_755 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_758, primals_754, primals_756, primals_757, True, 0.1, 1e-05);  primals_754 = None
        getitem_228 = native_batch_norm_default_76[0]
        getitem_229 = native_batch_norm_default_76[1]
        getitem_230 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_228, add_tensor_10);  getitem_228 = add_tensor_10 = None
        relu_default_10 = torch.ops.aten.relu.default(add_tensor_11)
        convolution_default_77 = torch.ops.aten.convolution.default(relu_default_10, primals_764, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_77 = torch.ops.aten.add_.Tensor(primals_760, 1);  primals_760 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_763, primals_759, primals_761, primals_762, True, 0.1, 1e-05);  primals_759 = None
        getitem_231 = native_batch_norm_default_77[0]
        getitem_232 = native_batch_norm_default_77[1]
        getitem_233 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_77, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_78 = torch.ops.aten.convolution.default(getitem_231, primals_765, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_78 = torch.ops.aten.add_.Tensor(primals_767, 1);  primals_767 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_770, primals_766, primals_768, primals_769, True, 0.1, 1e-05);  primals_766 = None
        getitem_234 = native_batch_norm_default_78[0]
        getitem_235 = native_batch_norm_default_78[1]
        getitem_236 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_234);  getitem_234 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_27, primals_776, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_79 = torch.ops.aten.add_.Tensor(primals_772, 1);  primals_772 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_775, primals_771, primals_773, primals_774, True, 0.1, 1e-05);  primals_771 = None
        getitem_237 = native_batch_norm_default_79[0]
        getitem_238 = native_batch_norm_default_79[1]
        getitem_239 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_80 = torch.ops.aten.convolution.default(getitem_237, primals_777, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_80 = torch.ops.aten.add_.Tensor(primals_779, 1);  primals_779 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_782, primals_778, primals_780, primals_781, True, 0.1, 1e-05);  primals_778 = None
        getitem_240 = native_batch_norm_default_80[0]
        getitem_241 = native_batch_norm_default_80[1]
        getitem_242 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_240);  getitem_240 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_28, primals_788, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_81 = torch.ops.aten.add_.Tensor(primals_784, 1);  primals_784 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_787, primals_783, primals_785, primals_786, True, 0.1, 1e-05);  primals_783 = None
        getitem_243 = native_batch_norm_default_81[0]
        getitem_244 = native_batch_norm_default_81[1]
        getitem_245 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_81, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_82 = torch.ops.aten.convolution.default(getitem_243, primals_789, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_82 = torch.ops.aten.add_.Tensor(primals_791, 1);  primals_791 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_794, primals_790, primals_792, primals_793, True, 0.1, 1e-05);  primals_790 = None
        getitem_246 = native_batch_norm_default_82[0]
        getitem_247 = native_batch_norm_default_82[1]
        getitem_248 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_82, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_246, add_tensor_11);  getitem_246 = add_tensor_11 = None
        relu_default_11 = torch.ops.aten.relu.default(add_tensor_12)
        convolution_default_83 = torch.ops.aten.convolution.default(relu_default_11, primals_260, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_83 = torch.ops.aten.add_.Tensor(primals_256, 1);  primals_256 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_259, primals_255, primals_257, primals_258, True, 0.1, 1e-05);  primals_255 = None
        getitem_249 = native_batch_norm_default_83[0]
        getitem_250 = native_batch_norm_default_83[1]
        getitem_251 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_84 = torch.ops.aten.convolution.default(getitem_249, primals_261, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_84 = torch.ops.aten.add_.Tensor(primals_263, 1);  primals_263 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_266, primals_262, primals_264, primals_265, True, 0.1, 1e-05);  primals_262 = None
        getitem_252 = native_batch_norm_default_84[0]
        getitem_253 = native_batch_norm_default_84[1]
        getitem_254 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_252);  getitem_252 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_29, primals_272, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_85 = torch.ops.aten.add_.Tensor(primals_268, 1);  primals_268 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_271, primals_267, primals_269, primals_270, True, 0.1, 1e-05);  primals_267 = None
        getitem_255 = native_batch_norm_default_85[0]
        getitem_256 = native_batch_norm_default_85[1]
        getitem_257 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_86 = torch.ops.aten.convolution.default(getitem_255, primals_273, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_86 = torch.ops.aten.add_.Tensor(primals_275, 1);  primals_275 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_278, primals_274, primals_276, primals_277, True, 0.1, 1e-05);  primals_274 = None
        getitem_258 = native_batch_norm_default_86[0]
        getitem_259 = native_batch_norm_default_86[1]
        getitem_260 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_86, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_258);  getitem_258 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_30, primals_284, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_87 = torch.ops.aten.add_.Tensor(primals_280, 1);  primals_280 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_283, primals_279, primals_281, primals_282, True, 0.1, 1e-05);  primals_279 = None
        getitem_261 = native_batch_norm_default_87[0]
        getitem_262 = native_batch_norm_default_87[1]
        getitem_263 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_87, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_88 = torch.ops.aten.convolution.default(getitem_261, primals_285, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_88 = torch.ops.aten.add_.Tensor(primals_287, 1);  primals_287 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_290, primals_286, primals_288, primals_289, True, 0.1, 1e-05);  primals_286 = None
        getitem_264 = native_batch_norm_default_88[0]
        getitem_265 = native_batch_norm_default_88[1]
        getitem_266 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_13 = torch.ops.aten.add.Tensor(getitem_264, add_tensor_12);  getitem_264 = add_tensor_12 = None
        relu_default_12 = torch.ops.aten.relu.default(add_tensor_13)
        convolution_default_89 = torch.ops.aten.convolution.default(relu_default_12, primals_296, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_89 = torch.ops.aten.add_.Tensor(primals_292, 1);  primals_292 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_295, primals_291, primals_293, primals_294, True, 0.1, 1e-05);  primals_291 = None
        getitem_267 = native_batch_norm_default_89[0]
        getitem_268 = native_batch_norm_default_89[1]
        getitem_269 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_90 = torch.ops.aten.convolution.default(getitem_267, primals_297, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_90 = torch.ops.aten.add_.Tensor(primals_299, 1);  primals_299 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_302, primals_298, primals_300, primals_301, True, 0.1, 1e-05);  primals_298 = None
        getitem_270 = native_batch_norm_default_90[0]
        getitem_271 = native_batch_norm_default_90[1]
        getitem_272 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_270);  getitem_270 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_31, primals_308, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_91 = torch.ops.aten.add_.Tensor(primals_304, 1);  primals_304 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_307, primals_303, primals_305, primals_306, True, 0.1, 1e-05);  primals_303 = None
        getitem_273 = native_batch_norm_default_91[0]
        getitem_274 = native_batch_norm_default_91[1]
        getitem_275 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_91, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_92 = torch.ops.aten.convolution.default(getitem_273, primals_309, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_92 = torch.ops.aten.add_.Tensor(primals_311, 1);  primals_311 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_314, primals_310, primals_312, primals_313, True, 0.1, 1e-05);  primals_310 = None
        getitem_276 = native_batch_norm_default_92[0]
        getitem_277 = native_batch_norm_default_92[1]
        getitem_278 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_92, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_276);  getitem_276 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_32, primals_320, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_93 = torch.ops.aten.add_.Tensor(primals_316, 1);  primals_316 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_319, primals_315, primals_317, primals_318, True, 0.1, 1e-05);  primals_315 = None
        getitem_279 = native_batch_norm_default_93[0]
        getitem_280 = native_batch_norm_default_93[1]
        getitem_281 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_94 = torch.ops.aten.convolution.default(getitem_279, primals_321, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_94 = torch.ops.aten.add_.Tensor(primals_323, 1);  primals_323 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_326, primals_322, primals_324, primals_325, True, 0.1, 1e-05);  primals_322 = None
        getitem_282 = native_batch_norm_default_94[0]
        getitem_283 = native_batch_norm_default_94[1]
        getitem_284 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_14 = torch.ops.aten.add.Tensor(getitem_282, add_tensor_13);  getitem_282 = add_tensor_13 = None
        relu_default_13 = torch.ops.aten.relu.default(add_tensor_14)
        convolution_default_95 = torch.ops.aten.convolution.default(relu_default_13, primals_332, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_95 = torch.ops.aten.add_.Tensor(primals_328, 1);  primals_328 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_331, primals_327, primals_329, primals_330, True, 0.1, 1e-05);  primals_327 = None
        getitem_285 = native_batch_norm_default_95[0]
        getitem_286 = native_batch_norm_default_95[1]
        getitem_287 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_95, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_96 = torch.ops.aten.convolution.default(getitem_285, primals_333, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_96 = torch.ops.aten.add_.Tensor(primals_335, 1);  primals_335 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_338, primals_334, primals_336, primals_337, True, 0.1, 1e-05);  primals_334 = None
        getitem_288 = native_batch_norm_default_96[0]
        getitem_289 = native_batch_norm_default_96[1]
        getitem_290 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_96, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_33 = torch.ops.aten.relu_.default(getitem_288);  getitem_288 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_33, primals_344, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_97 = torch.ops.aten.add_.Tensor(primals_340, 1);  primals_340 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_343, primals_339, primals_341, primals_342, True, 0.1, 1e-05);  primals_339 = None
        getitem_291 = native_batch_norm_default_97[0]
        getitem_292 = native_batch_norm_default_97[1]
        getitem_293 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_97, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_98 = torch.ops.aten.convolution.default(getitem_291, primals_345, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_98 = torch.ops.aten.add_.Tensor(primals_347, 1);  primals_347 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_350, primals_346, primals_348, primals_349, True, 0.1, 1e-05);  primals_346 = None
        getitem_294 = native_batch_norm_default_98[0]
        getitem_295 = native_batch_norm_default_98[1]
        getitem_296 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_34 = torch.ops.aten.relu_.default(getitem_294);  getitem_294 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_34, primals_356, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_99 = torch.ops.aten.add_.Tensor(primals_352, 1);  primals_352 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_355, primals_351, primals_353, primals_354, True, 0.1, 1e-05);  primals_351 = None
        getitem_297 = native_batch_norm_default_99[0]
        getitem_298 = native_batch_norm_default_99[1]
        getitem_299 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_99, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_100 = torch.ops.aten.convolution.default(getitem_297, primals_357, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_100 = torch.ops.aten.add_.Tensor(primals_359, 1);  primals_359 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_362, primals_358, primals_360, primals_361, True, 0.1, 1e-05);  primals_358 = None
        getitem_300 = native_batch_norm_default_100[0]
        getitem_301 = native_batch_norm_default_100[1]
        getitem_302 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_300, add_tensor_14);  getitem_300 = add_tensor_14 = None
        relu_default_14 = torch.ops.aten.relu.default(add_tensor_15)
        convolution_default_101 = torch.ops.aten.convolution.default(relu_default_14, primals_368, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_101 = torch.ops.aten.add_.Tensor(primals_364, 1);  primals_364 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_367, primals_363, primals_365, primals_366, True, 0.1, 1e-05);  primals_363 = None
        getitem_303 = native_batch_norm_default_101[0]
        getitem_304 = native_batch_norm_default_101[1]
        getitem_305 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_101, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_102 = torch.ops.aten.convolution.default(getitem_303, primals_369, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_102 = torch.ops.aten.add_.Tensor(primals_371, 1);  primals_371 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_374, primals_370, primals_372, primals_373, True, 0.1, 1e-05);  primals_370 = None
        getitem_306 = native_batch_norm_default_102[0]
        getitem_307 = native_batch_norm_default_102[1]
        getitem_308 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_102, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_35 = torch.ops.aten.relu_.default(getitem_306);  getitem_306 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_35, primals_380, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_103 = torch.ops.aten.add_.Tensor(primals_376, 1);  primals_376 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_379, primals_375, primals_377, primals_378, True, 0.1, 1e-05);  primals_375 = None
        getitem_309 = native_batch_norm_default_103[0]
        getitem_310 = native_batch_norm_default_103[1]
        getitem_311 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_103, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_104 = torch.ops.aten.convolution.default(getitem_309, primals_381, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_104 = torch.ops.aten.add_.Tensor(primals_383, 1);  primals_383 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_386, primals_382, primals_384, primals_385, True, 0.1, 1e-05);  primals_382 = None
        getitem_312 = native_batch_norm_default_104[0]
        getitem_313 = native_batch_norm_default_104[1]
        getitem_314 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_36 = torch.ops.aten.relu_.default(getitem_312);  getitem_312 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_36, primals_392, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_105 = torch.ops.aten.add_.Tensor(primals_388, 1);  primals_388 = None
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_391, primals_387, primals_389, primals_390, True, 0.1, 1e-05);  primals_387 = None
        getitem_315 = native_batch_norm_default_105[0]
        getitem_316 = native_batch_norm_default_105[1]
        getitem_317 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_105, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_106 = torch.ops.aten.convolution.default(getitem_315, primals_393, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_106 = torch.ops.aten.add_.Tensor(primals_395, 1);  primals_395 = None
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_398, primals_394, primals_396, primals_397, True, 0.1, 1e-05);  primals_394 = None
        getitem_318 = native_batch_norm_default_106[0]
        getitem_319 = native_batch_norm_default_106[1]
        getitem_320 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_106, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_318, add_tensor_15);  getitem_318 = add_tensor_15 = None
        relu_default_15 = torch.ops.aten.relu.default(add_tensor_16)
        convolution_default_107 = torch.ops.aten.convolution.default(relu_default_15, primals_404, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_107 = torch.ops.aten.add_.Tensor(primals_400, 1);  primals_400 = None
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_403, primals_399, primals_401, primals_402, True, 0.1, 1e-05);  primals_399 = None
        getitem_321 = native_batch_norm_default_107[0]
        getitem_322 = native_batch_norm_default_107[1]
        getitem_323 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_107, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_108 = torch.ops.aten.convolution.default(getitem_321, primals_405, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_108 = torch.ops.aten.add_.Tensor(primals_407, 1);  primals_407 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_410, primals_406, primals_408, primals_409, True, 0.1, 1e-05);  primals_406 = None
        getitem_324 = native_batch_norm_default_108[0]
        getitem_325 = native_batch_norm_default_108[1]
        getitem_326 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_324);  getitem_324 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_37, primals_416, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_109 = torch.ops.aten.add_.Tensor(primals_412, 1);  primals_412 = None
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_415, primals_411, primals_413, primals_414, True, 0.1, 1e-05);  primals_411 = None
        getitem_327 = native_batch_norm_default_109[0]
        getitem_328 = native_batch_norm_default_109[1]
        getitem_329 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_110 = torch.ops.aten.convolution.default(getitem_327, primals_417, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_110 = torch.ops.aten.add_.Tensor(primals_419, 1);  primals_419 = None
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_422, primals_418, primals_420, primals_421, True, 0.1, 1e-05);  primals_418 = None
        getitem_330 = native_batch_norm_default_110[0]
        getitem_331 = native_batch_norm_default_110[1]
        getitem_332 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_38 = torch.ops.aten.relu_.default(getitem_330);  getitem_330 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_38, primals_428, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_111 = torch.ops.aten.add_.Tensor(primals_424, 1);  primals_424 = None
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_427, primals_423, primals_425, primals_426, True, 0.1, 1e-05);  primals_423 = None
        getitem_333 = native_batch_norm_default_111[0]
        getitem_334 = native_batch_norm_default_111[1]
        getitem_335 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_111, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_112 = torch.ops.aten.convolution.default(getitem_333, primals_429, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_112 = torch.ops.aten.add_.Tensor(primals_431, 1);  primals_431 = None
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_434, primals_430, primals_432, primals_433, True, 0.1, 1e-05);  primals_430 = None
        getitem_336 = native_batch_norm_default_112[0]
        getitem_337 = native_batch_norm_default_112[1]
        getitem_338 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_112, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_336, add_tensor_16);  getitem_336 = add_tensor_16 = None
        relu_default_16 = torch.ops.aten.relu.default(add_tensor_17)
        convolution_default_113 = torch.ops.aten.convolution.default(relu_default_16, primals_440, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_113 = torch.ops.aten.add_.Tensor(primals_436, 1);  primals_436 = None
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_439, primals_435, primals_437, primals_438, True, 0.1, 1e-05);  primals_435 = None
        getitem_339 = native_batch_norm_default_113[0]
        getitem_340 = native_batch_norm_default_113[1]
        getitem_341 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_113, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_114 = torch.ops.aten.convolution.default(getitem_339, primals_441, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_114 = torch.ops.aten.add_.Tensor(primals_443, 1);  primals_443 = None
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_446, primals_442, primals_444, primals_445, True, 0.1, 1e-05);  primals_442 = None
        getitem_342 = native_batch_norm_default_114[0]
        getitem_343 = native_batch_norm_default_114[1]
        getitem_344 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_39 = torch.ops.aten.relu_.default(getitem_342);  getitem_342 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_39, primals_452, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_115 = torch.ops.aten.add_.Tensor(primals_448, 1);  primals_448 = None
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_451, primals_447, primals_449, primals_450, True, 0.1, 1e-05);  primals_447 = None
        getitem_345 = native_batch_norm_default_115[0]
        getitem_346 = native_batch_norm_default_115[1]
        getitem_347 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_115, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_116 = torch.ops.aten.convolution.default(getitem_345, primals_453, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_116 = torch.ops.aten.add_.Tensor(primals_455, 1);  primals_455 = None
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_458, primals_454, primals_456, primals_457, True, 0.1, 1e-05);  primals_454 = None
        getitem_348 = native_batch_norm_default_116[0]
        getitem_349 = native_batch_norm_default_116[1]
        getitem_350 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_40 = torch.ops.aten.relu_.default(getitem_348);  getitem_348 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_40, primals_464, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_117 = torch.ops.aten.add_.Tensor(primals_460, 1);  primals_460 = None
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_463, primals_459, primals_461, primals_462, True, 0.1, 1e-05);  primals_459 = None
        getitem_351 = native_batch_norm_default_117[0]
        getitem_352 = native_batch_norm_default_117[1]
        getitem_353 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_117, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_118 = torch.ops.aten.convolution.default(getitem_351, primals_465, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_118 = torch.ops.aten.add_.Tensor(primals_467, 1);  primals_467 = None
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_470, primals_466, primals_468, primals_469, True, 0.1, 1e-05);  primals_466 = None
        getitem_354 = native_batch_norm_default_118[0]
        getitem_355 = native_batch_norm_default_118[1]
        getitem_356 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_118, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_18 = torch.ops.aten.add.Tensor(getitem_354, add_tensor_17);  getitem_354 = add_tensor_17 = None
        convolution_default_119 = torch.ops.aten.convolution.default(add_tensor_18, primals_79, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_119 = torch.ops.aten.add_.Tensor(primals_81, 1);  primals_81 = None
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_84, primals_80, primals_82, primals_83, True, 0.1, 1e-05);  primals_80 = None
        getitem_357 = native_batch_norm_default_119[0]
        getitem_358 = native_batch_norm_default_119[1]
        getitem_359 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu_default_17 = torch.ops.aten.relu.default(add_tensor_18)
        convolution_default_120 = torch.ops.aten.convolution.default(relu_default_17, primals_48, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_120 = torch.ops.aten.add_.Tensor(primals_44, 1);  primals_44 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_47, primals_43, primals_45, primals_46, True, 0.1, 1e-05);  primals_43 = None
        getitem_360 = native_batch_norm_default_120[0]
        getitem_361 = native_batch_norm_default_120[1]
        getitem_362 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_121 = torch.ops.aten.convolution.default(getitem_360, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_121 = torch.ops.aten.add_.Tensor(primals_51, 1);  primals_51 = None
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_54, primals_50, primals_52, primals_53, True, 0.1, 1e-05);  primals_50 = None
        getitem_363 = native_batch_norm_default_121[0]
        getitem_364 = native_batch_norm_default_121[1]
        getitem_365 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_121, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_41 = torch.ops.aten.relu_.default(getitem_363);  getitem_363 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_41, primals_60, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 728)
        add__tensor_122 = torch.ops.aten.add_.Tensor(primals_56, 1);  primals_56 = None
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_59, primals_55, primals_57, primals_58, True, 0.1, 1e-05);  primals_55 = None
        getitem_366 = native_batch_norm_default_122[0]
        getitem_367 = native_batch_norm_default_122[1]
        getitem_368 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_123 = torch.ops.aten.convolution.default(getitem_366, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_123 = torch.ops.aten.add_.Tensor(primals_63, 1);  primals_63 = None
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_66, primals_62, primals_64, primals_65, True, 0.1, 1e-05);  primals_62 = None
        getitem_369 = native_batch_norm_default_123[0]
        getitem_370 = native_batch_norm_default_123[1]
        getitem_371 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_123, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_42 = torch.ops.aten.relu_.default(getitem_369);  getitem_369 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_42, primals_72, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1024)
        add__tensor_124 = torch.ops.aten.add_.Tensor(primals_68, 1);  primals_68 = None
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_71, primals_67, primals_69, primals_70, True, 0.1, 1e-05);  primals_67 = None
        getitem_372 = native_batch_norm_default_124[0]
        getitem_373 = native_batch_norm_default_124[1]
        getitem_374 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_124, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_125 = torch.ops.aten.convolution.default(getitem_372, primals_73, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_125 = torch.ops.aten.add_.Tensor(primals_75, 1);  primals_75 = None
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_78, primals_74, primals_76, primals_77, True, 0.1, 1e-05);  primals_74 = None
        getitem_375 = native_batch_norm_default_125[0]
        getitem_376 = native_batch_norm_default_125[1]
        getitem_377 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_125, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_375, getitem_357);  getitem_375 = getitem_357 = None
        relu__default_43 = torch.ops.aten.relu_.default(add_tensor_19);  add_tensor_19 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_43, primals_201, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1024)
        add__tensor_126 = torch.ops.aten.add_.Tensor(primals_197, 1);  primals_197 = None
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_200, primals_196, primals_198, primals_199, True, 0.1, 1e-05);  primals_196 = None
        getitem_378 = native_batch_norm_default_126[0]
        getitem_379 = native_batch_norm_default_126[1]
        getitem_380 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_127 = torch.ops.aten.convolution.default(getitem_378, primals_202, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_127 = torch.ops.aten.add_.Tensor(primals_180, 1);  primals_180 = None
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_183, primals_179, primals_181, primals_182, True, 0.1, 1e-05);  primals_179 = None
        getitem_381 = native_batch_norm_default_127[0]
        getitem_382 = native_batch_norm_default_127[1]
        getitem_383 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_127, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_44 = torch.ops.aten.relu_.default(getitem_381);  getitem_381 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_44, primals_208, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1536)
        add__tensor_128 = torch.ops.aten.add_.Tensor(primals_204, 1);  primals_204 = None
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_207, primals_203, primals_205, primals_206, True, 0.1, 1e-05);  primals_203 = None
        getitem_384 = native_batch_norm_default_128[0]
        getitem_385 = native_batch_norm_default_128[1]
        getitem_386 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_129 = torch.ops.aten.convolution.default(getitem_384, primals_209, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_129 = torch.ops.aten.add_.Tensor(primals_185, 1);  primals_185 = None
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_188, primals_184, primals_186, primals_187, True, 0.1, 1e-05);  primals_184 = None
        getitem_387 = native_batch_norm_default_129[0]
        getitem_388 = native_batch_norm_default_129[1]
        getitem_389 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_129, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_45 = torch.ops.aten.relu_.default(getitem_387);  getitem_387 = None
        convolution_default_130 = torch.ops.aten.convolution.default(relu__default_45, primals_215, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1536)
        add__tensor_130 = torch.ops.aten.add_.Tensor(primals_211, 1);  primals_211 = None
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_214, primals_210, primals_212, primals_213, True, 0.1, 1e-05);  primals_210 = None
        getitem_390 = native_batch_norm_default_130[0]
        getitem_391 = native_batch_norm_default_130[1]
        getitem_392 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_130, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_131 = torch.ops.aten.convolution.default(getitem_390, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_131 = torch.ops.aten.add_.Tensor(primals_190, 1);  primals_190 = None
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_193, primals_189, primals_191, primals_192, True, 0.1, 1e-05);  primals_189 = None
        getitem_393 = native_batch_norm_default_131[0]
        getitem_394 = native_batch_norm_default_131[1]
        getitem_395 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_46 = torch.ops.aten.relu_.default(getitem_393);  getitem_393 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_46, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [64, 2048]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_218);  primals_218 = None
        addmm_default = torch.ops.aten.addmm.default(primals_217, view_default, t_default);  primals_217 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [64, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [64, 2048, 10, 10]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 100);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_132, to_dtype);  le_scalar = new_zeros_default_132 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_131, primals_193, primals_191, primals_192, getitem_394, getitem_395, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_131 = primals_193 = primals_191 = primals_192 = getitem_394 = getitem_395 = None
        getitem_396 = native_batch_norm_backward_default[0]
        getitem_397 = native_batch_norm_backward_default[1]
        getitem_398 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_396, getitem_390, primals_216, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_396 = getitem_390 = primals_216 = None
        getitem_399 = convolution_backward_default[0]
        getitem_400 = convolution_backward_default[1]
        getitem_401 = convolution_backward_default[2];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_399, convolution_default_130, primals_214, primals_212, primals_213, getitem_391, getitem_392, True, 1e-05, [True, True, True]);  getitem_399 = convolution_default_130 = primals_214 = primals_212 = primals_213 = getitem_391 = getitem_392 = None
        getitem_402 = native_batch_norm_backward_default_1[0]
        getitem_403 = native_batch_norm_backward_default_1[1]
        getitem_404 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_402, relu__default_45, primals_215, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1536, [True, True, False]);  getitem_402 = primals_215 = None
        getitem_405 = convolution_backward_default_1[0]
        getitem_406 = convolution_backward_default_1[1]
        getitem_407 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_405, torch.float32);  getitem_405 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_133, to_dtype_3);  le_scalar_1 = new_zeros_default_133 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_129, primals_188, primals_186, primals_187, getitem_388, getitem_389, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_129 = primals_188 = primals_186 = primals_187 = getitem_388 = getitem_389 = None
        getitem_408 = native_batch_norm_backward_default_2[0]
        getitem_409 = native_batch_norm_backward_default_2[1]
        getitem_410 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_408, getitem_384, primals_209, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_408 = getitem_384 = primals_209 = None
        getitem_411 = convolution_backward_default_2[0]
        getitem_412 = convolution_backward_default_2[1]
        getitem_413 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(getitem_411, convolution_default_128, primals_207, primals_205, primals_206, getitem_385, getitem_386, True, 1e-05, [True, True, True]);  getitem_411 = convolution_default_128 = primals_207 = primals_205 = primals_206 = getitem_385 = getitem_386 = None
        getitem_414 = native_batch_norm_backward_default_3[0]
        getitem_415 = native_batch_norm_backward_default_3[1]
        getitem_416 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_414, relu__default_44, primals_208, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1536, [True, True, False]);  getitem_414 = primals_208 = None
        getitem_417 = convolution_backward_default_3[0]
        getitem_418 = convolution_backward_default_3[1]
        getitem_419 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_417, torch.float32);  getitem_417 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_134, to_dtype_6);  le_scalar_2 = new_zeros_default_134 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_127, primals_183, primals_181, primals_182, getitem_382, getitem_383, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_127 = primals_183 = primals_181 = primals_182 = getitem_382 = getitem_383 = None
        getitem_420 = native_batch_norm_backward_default_4[0]
        getitem_421 = native_batch_norm_backward_default_4[1]
        getitem_422 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_420, getitem_378, primals_202, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_420 = getitem_378 = primals_202 = None
        getitem_423 = convolution_backward_default_4[0]
        getitem_424 = convolution_backward_default_4[1]
        getitem_425 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(getitem_423, convolution_default_126, primals_200, primals_198, primals_199, getitem_379, getitem_380, True, 1e-05, [True, True, True]);  getitem_423 = convolution_default_126 = primals_200 = primals_198 = primals_199 = getitem_379 = getitem_380 = None
        getitem_426 = native_batch_norm_backward_default_5[0]
        getitem_427 = native_batch_norm_backward_default_5[1]
        getitem_428 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_426, relu__default_43, primals_201, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1024, [True, True, False]);  getitem_426 = primals_201 = None
        getitem_429 = convolution_backward_default_5[0]
        getitem_430 = convolution_backward_default_5[1]
        getitem_431 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_429, torch.float32);  getitem_429 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_135, to_dtype_9);  le_scalar_3 = new_zeros_default_135 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_125, primals_78, primals_76, primals_77, getitem_376, getitem_377, True, 1e-05, [True, True, True]);  convolution_default_125 = primals_78 = primals_76 = primals_77 = getitem_376 = getitem_377 = None
        getitem_432 = native_batch_norm_backward_default_6[0]
        getitem_433 = native_batch_norm_backward_default_6[1]
        getitem_434 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_432, getitem_372, primals_73, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_432 = getitem_372 = primals_73 = None
        getitem_435 = convolution_backward_default_6[0]
        getitem_436 = convolution_backward_default_6[1]
        getitem_437 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(getitem_435, convolution_default_124, primals_71, primals_69, primals_70, getitem_373, getitem_374, True, 1e-05, [True, True, True]);  getitem_435 = convolution_default_124 = primals_71 = primals_69 = primals_70 = getitem_373 = getitem_374 = None
        getitem_438 = native_batch_norm_backward_default_7[0]
        getitem_439 = native_batch_norm_backward_default_7[1]
        getitem_440 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_438, relu__default_42, primals_72, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1024, [True, True, False]);  getitem_438 = primals_72 = None
        getitem_441 = convolution_backward_default_7[0]
        getitem_442 = convolution_backward_default_7[1]
        getitem_443 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_441, torch.float32);  getitem_441 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_136, to_dtype_12);  le_scalar_4 = new_zeros_default_136 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_123, primals_66, primals_64, primals_65, getitem_370, getitem_371, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_123 = primals_66 = primals_64 = primals_65 = getitem_370 = getitem_371 = None
        getitem_444 = native_batch_norm_backward_default_8[0]
        getitem_445 = native_batch_norm_backward_default_8[1]
        getitem_446 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_444, getitem_366, primals_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_444 = getitem_366 = primals_61 = None
        getitem_447 = convolution_backward_default_8[0]
        getitem_448 = convolution_backward_default_8[1]
        getitem_449 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(getitem_447, convolution_default_122, primals_59, primals_57, primals_58, getitem_367, getitem_368, True, 1e-05, [True, True, True]);  getitem_447 = convolution_default_122 = primals_59 = primals_57 = primals_58 = getitem_367 = getitem_368 = None
        getitem_450 = native_batch_norm_backward_default_9[0]
        getitem_451 = native_batch_norm_backward_default_9[1]
        getitem_452 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_450, relu__default_41, primals_60, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_450 = primals_60 = None
        getitem_453 = convolution_backward_default_9[0]
        getitem_454 = convolution_backward_default_9[1]
        getitem_455 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_453, torch.float32);  getitem_453 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_137, to_dtype_15);  le_scalar_5 = new_zeros_default_137 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_121, primals_54, primals_52, primals_53, getitem_364, getitem_365, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_121 = primals_54 = primals_52 = primals_53 = getitem_364 = getitem_365 = None
        getitem_456 = native_batch_norm_backward_default_10[0]
        getitem_457 = native_batch_norm_backward_default_10[1]
        getitem_458 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_456, getitem_360, primals_49, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_456 = getitem_360 = primals_49 = None
        getitem_459 = convolution_backward_default_10[0]
        getitem_460 = convolution_backward_default_10[1]
        getitem_461 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(getitem_459, convolution_default_120, primals_47, primals_45, primals_46, getitem_361, getitem_362, True, 1e-05, [True, True, True]);  getitem_459 = convolution_default_120 = primals_47 = primals_45 = primals_46 = getitem_361 = getitem_362 = None
        getitem_462 = native_batch_norm_backward_default_11[0]
        getitem_463 = native_batch_norm_backward_default_11[1]
        getitem_464 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_462, relu_default_17, primals_48, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_462 = primals_48 = None
        getitem_465 = convolution_backward_default_11[0]
        getitem_466 = convolution_backward_default_11[1]
        getitem_467 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_465, torch.float32);  getitem_465 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu_default_17, torch.float32);  relu_default_17 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_138, to_dtype_18);  le_scalar_6 = new_zeros_default_138 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_119, primals_84, primals_82, primals_83, getitem_358, getitem_359, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_119 = primals_84 = primals_82 = primals_83 = getitem_358 = getitem_359 = None
        getitem_468 = native_batch_norm_backward_default_12[0]
        getitem_469 = native_batch_norm_backward_default_12[1]
        getitem_470 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_468, add_tensor_18, primals_79, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_468 = add_tensor_18 = primals_79 = None
        getitem_471 = convolution_backward_default_12[0]
        getitem_472 = convolution_backward_default_12[1]
        getitem_473 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(to_dtype_20, getitem_471);  to_dtype_20 = getitem_471 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_20, convolution_default_118, primals_470, primals_468, primals_469, getitem_355, getitem_356, True, 1e-05, [True, True, True]);  convolution_default_118 = primals_470 = primals_468 = primals_469 = getitem_355 = getitem_356 = None
        getitem_474 = native_batch_norm_backward_default_13[0]
        getitem_475 = native_batch_norm_backward_default_13[1]
        getitem_476 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_474, getitem_351, primals_465, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_474 = getitem_351 = primals_465 = None
        getitem_477 = convolution_backward_default_13[0]
        getitem_478 = convolution_backward_default_13[1]
        getitem_479 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(getitem_477, convolution_default_117, primals_463, primals_461, primals_462, getitem_352, getitem_353, True, 1e-05, [True, True, True]);  getitem_477 = convolution_default_117 = primals_463 = primals_461 = primals_462 = getitem_352 = getitem_353 = None
        getitem_480 = native_batch_norm_backward_default_14[0]
        getitem_481 = native_batch_norm_backward_default_14[1]
        getitem_482 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_480, relu__default_40, primals_464, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_480 = primals_464 = None
        getitem_483 = convolution_backward_default_14[0]
        getitem_484 = convolution_backward_default_14[1]
        getitem_485 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_483, torch.float32);  getitem_483 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_139, to_dtype_21);  le_scalar_7 = new_zeros_default_139 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_116, primals_458, primals_456, primals_457, getitem_349, getitem_350, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_116 = primals_458 = primals_456 = primals_457 = getitem_349 = getitem_350 = None
        getitem_486 = native_batch_norm_backward_default_15[0]
        getitem_487 = native_batch_norm_backward_default_15[1]
        getitem_488 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_486, getitem_345, primals_453, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_486 = getitem_345 = primals_453 = None
        getitem_489 = convolution_backward_default_15[0]
        getitem_490 = convolution_backward_default_15[1]
        getitem_491 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_489, convolution_default_115, primals_451, primals_449, primals_450, getitem_346, getitem_347, True, 1e-05, [True, True, True]);  getitem_489 = convolution_default_115 = primals_451 = primals_449 = primals_450 = getitem_346 = getitem_347 = None
        getitem_492 = native_batch_norm_backward_default_16[0]
        getitem_493 = native_batch_norm_backward_default_16[1]
        getitem_494 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_492, relu__default_39, primals_452, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_492 = primals_452 = None
        getitem_495 = convolution_backward_default_16[0]
        getitem_496 = convolution_backward_default_16[1]
        getitem_497 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_495, torch.float32);  getitem_495 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_140, to_dtype_24);  le_scalar_8 = new_zeros_default_140 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_114, primals_446, primals_444, primals_445, getitem_343, getitem_344, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_114 = primals_446 = primals_444 = primals_445 = getitem_343 = getitem_344 = None
        getitem_498 = native_batch_norm_backward_default_17[0]
        getitem_499 = native_batch_norm_backward_default_17[1]
        getitem_500 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_498, getitem_339, primals_441, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_498 = getitem_339 = primals_441 = None
        getitem_501 = convolution_backward_default_17[0]
        getitem_502 = convolution_backward_default_17[1]
        getitem_503 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(getitem_501, convolution_default_113, primals_439, primals_437, primals_438, getitem_340, getitem_341, True, 1e-05, [True, True, True]);  getitem_501 = convolution_default_113 = primals_439 = primals_437 = primals_438 = getitem_340 = getitem_341 = None
        getitem_504 = native_batch_norm_backward_default_18[0]
        getitem_505 = native_batch_norm_backward_default_18[1]
        getitem_506 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_504, relu_default_16, primals_440, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_504 = primals_440 = None
        getitem_507 = convolution_backward_default_18[0]
        getitem_508 = convolution_backward_default_18[1]
        getitem_509 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_507, torch.float32);  getitem_507 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu_default_16, torch.float32);  relu_default_16 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_141, to_dtype_27);  le_scalar_9 = new_zeros_default_141 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, to_dtype_29);  add_tensor_20 = to_dtype_29 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_21, convolution_default_112, primals_434, primals_432, primals_433, getitem_337, getitem_338, True, 1e-05, [True, True, True]);  convolution_default_112 = primals_434 = primals_432 = primals_433 = getitem_337 = getitem_338 = None
        getitem_510 = native_batch_norm_backward_default_19[0]
        getitem_511 = native_batch_norm_backward_default_19[1]
        getitem_512 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_510, getitem_333, primals_429, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_510 = getitem_333 = primals_429 = None
        getitem_513 = convolution_backward_default_19[0]
        getitem_514 = convolution_backward_default_19[1]
        getitem_515 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(getitem_513, convolution_default_111, primals_427, primals_425, primals_426, getitem_334, getitem_335, True, 1e-05, [True, True, True]);  getitem_513 = convolution_default_111 = primals_427 = primals_425 = primals_426 = getitem_334 = getitem_335 = None
        getitem_516 = native_batch_norm_backward_default_20[0]
        getitem_517 = native_batch_norm_backward_default_20[1]
        getitem_518 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_516, relu__default_38, primals_428, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_516 = primals_428 = None
        getitem_519 = convolution_backward_default_20[0]
        getitem_520 = convolution_backward_default_20[1]
        getitem_521 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_519, torch.float32);  getitem_519 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_142, to_dtype_30);  le_scalar_10 = new_zeros_default_142 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_110, primals_422, primals_420, primals_421, getitem_331, getitem_332, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_110 = primals_422 = primals_420 = primals_421 = getitem_331 = getitem_332 = None
        getitem_522 = native_batch_norm_backward_default_21[0]
        getitem_523 = native_batch_norm_backward_default_21[1]
        getitem_524 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_522, getitem_327, primals_417, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_522 = getitem_327 = primals_417 = None
        getitem_525 = convolution_backward_default_21[0]
        getitem_526 = convolution_backward_default_21[1]
        getitem_527 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(getitem_525, convolution_default_109, primals_415, primals_413, primals_414, getitem_328, getitem_329, True, 1e-05, [True, True, True]);  getitem_525 = convolution_default_109 = primals_415 = primals_413 = primals_414 = getitem_328 = getitem_329 = None
        getitem_528 = native_batch_norm_backward_default_22[0]
        getitem_529 = native_batch_norm_backward_default_22[1]
        getitem_530 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_528, relu__default_37, primals_416, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_528 = primals_416 = None
        getitem_531 = convolution_backward_default_22[0]
        getitem_532 = convolution_backward_default_22[1]
        getitem_533 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_531, torch.float32);  getitem_531 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_143, to_dtype_33);  le_scalar_11 = new_zeros_default_143 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_108, primals_410, primals_408, primals_409, getitem_325, getitem_326, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_108 = primals_410 = primals_408 = primals_409 = getitem_325 = getitem_326 = None
        getitem_534 = native_batch_norm_backward_default_23[0]
        getitem_535 = native_batch_norm_backward_default_23[1]
        getitem_536 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_534, getitem_321, primals_405, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_534 = getitem_321 = primals_405 = None
        getitem_537 = convolution_backward_default_23[0]
        getitem_538 = convolution_backward_default_23[1]
        getitem_539 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(getitem_537, convolution_default_107, primals_403, primals_401, primals_402, getitem_322, getitem_323, True, 1e-05, [True, True, True]);  getitem_537 = convolution_default_107 = primals_403 = primals_401 = primals_402 = getitem_322 = getitem_323 = None
        getitem_540 = native_batch_norm_backward_default_24[0]
        getitem_541 = native_batch_norm_backward_default_24[1]
        getitem_542 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_540, relu_default_15, primals_404, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_540 = primals_404 = None
        getitem_543 = convolution_backward_default_24[0]
        getitem_544 = convolution_backward_default_24[1]
        getitem_545 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_543, torch.float32);  getitem_543 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu_default_15, torch.float32);  relu_default_15 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_144, to_dtype_36);  le_scalar_12 = new_zeros_default_144 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, to_dtype_38);  add_tensor_21 = to_dtype_38 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_22, convolution_default_106, primals_398, primals_396, primals_397, getitem_319, getitem_320, True, 1e-05, [True, True, True]);  convolution_default_106 = primals_398 = primals_396 = primals_397 = getitem_319 = getitem_320 = None
        getitem_546 = native_batch_norm_backward_default_25[0]
        getitem_547 = native_batch_norm_backward_default_25[1]
        getitem_548 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_546, getitem_315, primals_393, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_546 = getitem_315 = primals_393 = None
        getitem_549 = convolution_backward_default_25[0]
        getitem_550 = convolution_backward_default_25[1]
        getitem_551 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(getitem_549, convolution_default_105, primals_391, primals_389, primals_390, getitem_316, getitem_317, True, 1e-05, [True, True, True]);  getitem_549 = convolution_default_105 = primals_391 = primals_389 = primals_390 = getitem_316 = getitem_317 = None
        getitem_552 = native_batch_norm_backward_default_26[0]
        getitem_553 = native_batch_norm_backward_default_26[1]
        getitem_554 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_552, relu__default_36, primals_392, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_552 = primals_392 = None
        getitem_555 = convolution_backward_default_26[0]
        getitem_556 = convolution_backward_default_26[1]
        getitem_557 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_555, torch.float32);  getitem_555 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_145, to_dtype_39);  le_scalar_13 = new_zeros_default_145 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_104, primals_386, primals_384, primals_385, getitem_313, getitem_314, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_104 = primals_386 = primals_384 = primals_385 = getitem_313 = getitem_314 = None
        getitem_558 = native_batch_norm_backward_default_27[0]
        getitem_559 = native_batch_norm_backward_default_27[1]
        getitem_560 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_558, getitem_309, primals_381, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_558 = getitem_309 = primals_381 = None
        getitem_561 = convolution_backward_default_27[0]
        getitem_562 = convolution_backward_default_27[1]
        getitem_563 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(getitem_561, convolution_default_103, primals_379, primals_377, primals_378, getitem_310, getitem_311, True, 1e-05, [True, True, True]);  getitem_561 = convolution_default_103 = primals_379 = primals_377 = primals_378 = getitem_310 = getitem_311 = None
        getitem_564 = native_batch_norm_backward_default_28[0]
        getitem_565 = native_batch_norm_backward_default_28[1]
        getitem_566 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_564, relu__default_35, primals_380, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_564 = primals_380 = None
        getitem_567 = convolution_backward_default_28[0]
        getitem_568 = convolution_backward_default_28[1]
        getitem_569 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_567, torch.float32);  getitem_567 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_146, to_dtype_42);  le_scalar_14 = new_zeros_default_146 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_102, primals_374, primals_372, primals_373, getitem_307, getitem_308, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_102 = primals_374 = primals_372 = primals_373 = getitem_307 = getitem_308 = None
        getitem_570 = native_batch_norm_backward_default_29[0]
        getitem_571 = native_batch_norm_backward_default_29[1]
        getitem_572 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_570, getitem_303, primals_369, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_570 = getitem_303 = primals_369 = None
        getitem_573 = convolution_backward_default_29[0]
        getitem_574 = convolution_backward_default_29[1]
        getitem_575 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(getitem_573, convolution_default_101, primals_367, primals_365, primals_366, getitem_304, getitem_305, True, 1e-05, [True, True, True]);  getitem_573 = convolution_default_101 = primals_367 = primals_365 = primals_366 = getitem_304 = getitem_305 = None
        getitem_576 = native_batch_norm_backward_default_30[0]
        getitem_577 = native_batch_norm_backward_default_30[1]
        getitem_578 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_576, relu_default_14, primals_368, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_576 = primals_368 = None
        getitem_579 = convolution_backward_default_30[0]
        getitem_580 = convolution_backward_default_30[1]
        getitem_581 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_579, torch.float32);  getitem_579 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu_default_14, torch.float32);  relu_default_14 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_147, to_dtype_45);  le_scalar_15 = new_zeros_default_147 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(add_tensor_22, to_dtype_47);  add_tensor_22 = to_dtype_47 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_23, convolution_default_100, primals_362, primals_360, primals_361, getitem_301, getitem_302, True, 1e-05, [True, True, True]);  convolution_default_100 = primals_362 = primals_360 = primals_361 = getitem_301 = getitem_302 = None
        getitem_582 = native_batch_norm_backward_default_31[0]
        getitem_583 = native_batch_norm_backward_default_31[1]
        getitem_584 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_582, getitem_297, primals_357, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_582 = getitem_297 = primals_357 = None
        getitem_585 = convolution_backward_default_31[0]
        getitem_586 = convolution_backward_default_31[1]
        getitem_587 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(getitem_585, convolution_default_99, primals_355, primals_353, primals_354, getitem_298, getitem_299, True, 1e-05, [True, True, True]);  getitem_585 = convolution_default_99 = primals_355 = primals_353 = primals_354 = getitem_298 = getitem_299 = None
        getitem_588 = native_batch_norm_backward_default_32[0]
        getitem_589 = native_batch_norm_backward_default_32[1]
        getitem_590 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_588, relu__default_34, primals_356, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_588 = primals_356 = None
        getitem_591 = convolution_backward_default_32[0]
        getitem_592 = convolution_backward_default_32[1]
        getitem_593 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_591, torch.float32);  getitem_591 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_148, to_dtype_48);  le_scalar_16 = new_zeros_default_148 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_98, primals_350, primals_348, primals_349, getitem_295, getitem_296, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_98 = primals_350 = primals_348 = primals_349 = getitem_295 = getitem_296 = None
        getitem_594 = native_batch_norm_backward_default_33[0]
        getitem_595 = native_batch_norm_backward_default_33[1]
        getitem_596 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_594, getitem_291, primals_345, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_594 = getitem_291 = primals_345 = None
        getitem_597 = convolution_backward_default_33[0]
        getitem_598 = convolution_backward_default_33[1]
        getitem_599 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(getitem_597, convolution_default_97, primals_343, primals_341, primals_342, getitem_292, getitem_293, True, 1e-05, [True, True, True]);  getitem_597 = convolution_default_97 = primals_343 = primals_341 = primals_342 = getitem_292 = getitem_293 = None
        getitem_600 = native_batch_norm_backward_default_34[0]
        getitem_601 = native_batch_norm_backward_default_34[1]
        getitem_602 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_600, relu__default_33, primals_344, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_600 = primals_344 = None
        getitem_603 = convolution_backward_default_34[0]
        getitem_604 = convolution_backward_default_34[1]
        getitem_605 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_603, torch.float32);  getitem_603 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_149, to_dtype_51);  le_scalar_17 = new_zeros_default_149 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_96, primals_338, primals_336, primals_337, getitem_289, getitem_290, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_96 = primals_338 = primals_336 = primals_337 = getitem_289 = getitem_290 = None
        getitem_606 = native_batch_norm_backward_default_35[0]
        getitem_607 = native_batch_norm_backward_default_35[1]
        getitem_608 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_606, getitem_285, primals_333, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_606 = getitem_285 = primals_333 = None
        getitem_609 = convolution_backward_default_35[0]
        getitem_610 = convolution_backward_default_35[1]
        getitem_611 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(getitem_609, convolution_default_95, primals_331, primals_329, primals_330, getitem_286, getitem_287, True, 1e-05, [True, True, True]);  getitem_609 = convolution_default_95 = primals_331 = primals_329 = primals_330 = getitem_286 = getitem_287 = None
        getitem_612 = native_batch_norm_backward_default_36[0]
        getitem_613 = native_batch_norm_backward_default_36[1]
        getitem_614 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_612, relu_default_13, primals_332, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_612 = primals_332 = None
        getitem_615 = convolution_backward_default_36[0]
        getitem_616 = convolution_backward_default_36[1]
        getitem_617 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_615, torch.float32);  getitem_615 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu_default_13, torch.float32);  relu_default_13 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_150, to_dtype_54);  le_scalar_18 = new_zeros_default_150 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, to_dtype_56);  add_tensor_23 = to_dtype_56 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_24, convolution_default_94, primals_326, primals_324, primals_325, getitem_283, getitem_284, True, 1e-05, [True, True, True]);  convolution_default_94 = primals_326 = primals_324 = primals_325 = getitem_283 = getitem_284 = None
        getitem_618 = native_batch_norm_backward_default_37[0]
        getitem_619 = native_batch_norm_backward_default_37[1]
        getitem_620 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_618, getitem_279, primals_321, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_618 = getitem_279 = primals_321 = None
        getitem_621 = convolution_backward_default_37[0]
        getitem_622 = convolution_backward_default_37[1]
        getitem_623 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(getitem_621, convolution_default_93, primals_319, primals_317, primals_318, getitem_280, getitem_281, True, 1e-05, [True, True, True]);  getitem_621 = convolution_default_93 = primals_319 = primals_317 = primals_318 = getitem_280 = getitem_281 = None
        getitem_624 = native_batch_norm_backward_default_38[0]
        getitem_625 = native_batch_norm_backward_default_38[1]
        getitem_626 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_624, relu__default_32, primals_320, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_624 = primals_320 = None
        getitem_627 = convolution_backward_default_38[0]
        getitem_628 = convolution_backward_default_38[1]
        getitem_629 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_627, torch.float32);  getitem_627 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_151, to_dtype_57);  le_scalar_19 = new_zeros_default_151 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_92, primals_314, primals_312, primals_313, getitem_277, getitem_278, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_92 = primals_314 = primals_312 = primals_313 = getitem_277 = getitem_278 = None
        getitem_630 = native_batch_norm_backward_default_39[0]
        getitem_631 = native_batch_norm_backward_default_39[1]
        getitem_632 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_630, getitem_273, primals_309, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_630 = getitem_273 = primals_309 = None
        getitem_633 = convolution_backward_default_39[0]
        getitem_634 = convolution_backward_default_39[1]
        getitem_635 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(getitem_633, convolution_default_91, primals_307, primals_305, primals_306, getitem_274, getitem_275, True, 1e-05, [True, True, True]);  getitem_633 = convolution_default_91 = primals_307 = primals_305 = primals_306 = getitem_274 = getitem_275 = None
        getitem_636 = native_batch_norm_backward_default_40[0]
        getitem_637 = native_batch_norm_backward_default_40[1]
        getitem_638 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_636, relu__default_31, primals_308, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_636 = primals_308 = None
        getitem_639 = convolution_backward_default_40[0]
        getitem_640 = convolution_backward_default_40[1]
        getitem_641 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_639, torch.float32);  getitem_639 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_152, to_dtype_60);  le_scalar_20 = new_zeros_default_152 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_90, primals_302, primals_300, primals_301, getitem_271, getitem_272, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_90 = primals_302 = primals_300 = primals_301 = getitem_271 = getitem_272 = None
        getitem_642 = native_batch_norm_backward_default_41[0]
        getitem_643 = native_batch_norm_backward_default_41[1]
        getitem_644 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_642, getitem_267, primals_297, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_642 = getitem_267 = primals_297 = None
        getitem_645 = convolution_backward_default_41[0]
        getitem_646 = convolution_backward_default_41[1]
        getitem_647 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(getitem_645, convolution_default_89, primals_295, primals_293, primals_294, getitem_268, getitem_269, True, 1e-05, [True, True, True]);  getitem_645 = convolution_default_89 = primals_295 = primals_293 = primals_294 = getitem_268 = getitem_269 = None
        getitem_648 = native_batch_norm_backward_default_42[0]
        getitem_649 = native_batch_norm_backward_default_42[1]
        getitem_650 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_648, relu_default_12, primals_296, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_648 = primals_296 = None
        getitem_651 = convolution_backward_default_42[0]
        getitem_652 = convolution_backward_default_42[1]
        getitem_653 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_651, torch.float32);  getitem_651 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu_default_12, torch.float32);  relu_default_12 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_153, to_dtype_63);  le_scalar_21 = new_zeros_default_153 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, to_dtype_65);  add_tensor_24 = to_dtype_65 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_25, convolution_default_88, primals_290, primals_288, primals_289, getitem_265, getitem_266, True, 1e-05, [True, True, True]);  convolution_default_88 = primals_290 = primals_288 = primals_289 = getitem_265 = getitem_266 = None
        getitem_654 = native_batch_norm_backward_default_43[0]
        getitem_655 = native_batch_norm_backward_default_43[1]
        getitem_656 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_654, getitem_261, primals_285, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_654 = getitem_261 = primals_285 = None
        getitem_657 = convolution_backward_default_43[0]
        getitem_658 = convolution_backward_default_43[1]
        getitem_659 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(getitem_657, convolution_default_87, primals_283, primals_281, primals_282, getitem_262, getitem_263, True, 1e-05, [True, True, True]);  getitem_657 = convolution_default_87 = primals_283 = primals_281 = primals_282 = getitem_262 = getitem_263 = None
        getitem_660 = native_batch_norm_backward_default_44[0]
        getitem_661 = native_batch_norm_backward_default_44[1]
        getitem_662 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_660, relu__default_30, primals_284, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_660 = primals_284 = None
        getitem_663 = convolution_backward_default_44[0]
        getitem_664 = convolution_backward_default_44[1]
        getitem_665 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_663, torch.float32);  getitem_663 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_154, to_dtype_66);  le_scalar_22 = new_zeros_default_154 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_86, primals_278, primals_276, primals_277, getitem_259, getitem_260, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_86 = primals_278 = primals_276 = primals_277 = getitem_259 = getitem_260 = None
        getitem_666 = native_batch_norm_backward_default_45[0]
        getitem_667 = native_batch_norm_backward_default_45[1]
        getitem_668 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_666, getitem_255, primals_273, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_666 = getitem_255 = primals_273 = None
        getitem_669 = convolution_backward_default_45[0]
        getitem_670 = convolution_backward_default_45[1]
        getitem_671 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(getitem_669, convolution_default_85, primals_271, primals_269, primals_270, getitem_256, getitem_257, True, 1e-05, [True, True, True]);  getitem_669 = convolution_default_85 = primals_271 = primals_269 = primals_270 = getitem_256 = getitem_257 = None
        getitem_672 = native_batch_norm_backward_default_46[0]
        getitem_673 = native_batch_norm_backward_default_46[1]
        getitem_674 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_672, relu__default_29, primals_272, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_672 = primals_272 = None
        getitem_675 = convolution_backward_default_46[0]
        getitem_676 = convolution_backward_default_46[1]
        getitem_677 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_675, torch.float32);  getitem_675 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_155, to_dtype_69);  le_scalar_23 = new_zeros_default_155 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_84, primals_266, primals_264, primals_265, getitem_253, getitem_254, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_84 = primals_266 = primals_264 = primals_265 = getitem_253 = getitem_254 = None
        getitem_678 = native_batch_norm_backward_default_47[0]
        getitem_679 = native_batch_norm_backward_default_47[1]
        getitem_680 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_678, getitem_249, primals_261, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_678 = getitem_249 = primals_261 = None
        getitem_681 = convolution_backward_default_47[0]
        getitem_682 = convolution_backward_default_47[1]
        getitem_683 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(getitem_681, convolution_default_83, primals_259, primals_257, primals_258, getitem_250, getitem_251, True, 1e-05, [True, True, True]);  getitem_681 = convolution_default_83 = primals_259 = primals_257 = primals_258 = getitem_250 = getitem_251 = None
        getitem_684 = native_batch_norm_backward_default_48[0]
        getitem_685 = native_batch_norm_backward_default_48[1]
        getitem_686 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_684, relu_default_11, primals_260, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_684 = primals_260 = None
        getitem_687 = convolution_backward_default_48[0]
        getitem_688 = convolution_backward_default_48[1]
        getitem_689 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_687, torch.float32);  getitem_687 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu_default_11, torch.float32);  relu_default_11 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_156, to_dtype_72);  le_scalar_24 = new_zeros_default_156 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(add_tensor_25, to_dtype_74);  add_tensor_25 = to_dtype_74 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_26, convolution_default_82, primals_794, primals_792, primals_793, getitem_247, getitem_248, True, 1e-05, [True, True, True]);  convolution_default_82 = primals_794 = primals_792 = primals_793 = getitem_247 = getitem_248 = None
        getitem_690 = native_batch_norm_backward_default_49[0]
        getitem_691 = native_batch_norm_backward_default_49[1]
        getitem_692 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_690, getitem_243, primals_789, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_690 = getitem_243 = primals_789 = None
        getitem_693 = convolution_backward_default_49[0]
        getitem_694 = convolution_backward_default_49[1]
        getitem_695 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(getitem_693, convolution_default_81, primals_787, primals_785, primals_786, getitem_244, getitem_245, True, 1e-05, [True, True, True]);  getitem_693 = convolution_default_81 = primals_787 = primals_785 = primals_786 = getitem_244 = getitem_245 = None
        getitem_696 = native_batch_norm_backward_default_50[0]
        getitem_697 = native_batch_norm_backward_default_50[1]
        getitem_698 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_696, relu__default_28, primals_788, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_696 = primals_788 = None
        getitem_699 = convolution_backward_default_50[0]
        getitem_700 = convolution_backward_default_50[1]
        getitem_701 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_699, torch.float32);  getitem_699 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_157, to_dtype_75);  le_scalar_25 = new_zeros_default_157 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_80, primals_782, primals_780, primals_781, getitem_241, getitem_242, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_80 = primals_782 = primals_780 = primals_781 = getitem_241 = getitem_242 = None
        getitem_702 = native_batch_norm_backward_default_51[0]
        getitem_703 = native_batch_norm_backward_default_51[1]
        getitem_704 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_702, getitem_237, primals_777, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_702 = getitem_237 = primals_777 = None
        getitem_705 = convolution_backward_default_51[0]
        getitem_706 = convolution_backward_default_51[1]
        getitem_707 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(getitem_705, convolution_default_79, primals_775, primals_773, primals_774, getitem_238, getitem_239, True, 1e-05, [True, True, True]);  getitem_705 = convolution_default_79 = primals_775 = primals_773 = primals_774 = getitem_238 = getitem_239 = None
        getitem_708 = native_batch_norm_backward_default_52[0]
        getitem_709 = native_batch_norm_backward_default_52[1]
        getitem_710 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_708, relu__default_27, primals_776, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_708 = primals_776 = None
        getitem_711 = convolution_backward_default_52[0]
        getitem_712 = convolution_backward_default_52[1]
        getitem_713 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_711, torch.float32);  getitem_711 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_158, to_dtype_78);  le_scalar_26 = new_zeros_default_158 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_78, primals_770, primals_768, primals_769, getitem_235, getitem_236, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_78 = primals_770 = primals_768 = primals_769 = getitem_235 = getitem_236 = None
        getitem_714 = native_batch_norm_backward_default_53[0]
        getitem_715 = native_batch_norm_backward_default_53[1]
        getitem_716 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_714, getitem_231, primals_765, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_714 = getitem_231 = primals_765 = None
        getitem_717 = convolution_backward_default_53[0]
        getitem_718 = convolution_backward_default_53[1]
        getitem_719 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(getitem_717, convolution_default_77, primals_763, primals_761, primals_762, getitem_232, getitem_233, True, 1e-05, [True, True, True]);  getitem_717 = convolution_default_77 = primals_763 = primals_761 = primals_762 = getitem_232 = getitem_233 = None
        getitem_720 = native_batch_norm_backward_default_54[0]
        getitem_721 = native_batch_norm_backward_default_54[1]
        getitem_722 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_720, relu_default_10, primals_764, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_720 = primals_764 = None
        getitem_723 = convolution_backward_default_54[0]
        getitem_724 = convolution_backward_default_54[1]
        getitem_725 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_723, torch.float32);  getitem_723 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu_default_10, torch.float32);  relu_default_10 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_159, to_dtype_81);  le_scalar_27 = new_zeros_default_159 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, to_dtype_83);  add_tensor_26 = to_dtype_83 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_27, convolution_default_76, primals_758, primals_756, primals_757, getitem_229, getitem_230, True, 1e-05, [True, True, True]);  convolution_default_76 = primals_758 = primals_756 = primals_757 = getitem_229 = getitem_230 = None
        getitem_726 = native_batch_norm_backward_default_55[0]
        getitem_727 = native_batch_norm_backward_default_55[1]
        getitem_728 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_726, getitem_225, primals_753, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_726 = getitem_225 = primals_753 = None
        getitem_729 = convolution_backward_default_55[0]
        getitem_730 = convolution_backward_default_55[1]
        getitem_731 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(getitem_729, convolution_default_75, primals_751, primals_749, primals_750, getitem_226, getitem_227, True, 1e-05, [True, True, True]);  getitem_729 = convolution_default_75 = primals_751 = primals_749 = primals_750 = getitem_226 = getitem_227 = None
        getitem_732 = native_batch_norm_backward_default_56[0]
        getitem_733 = native_batch_norm_backward_default_56[1]
        getitem_734 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_732, relu__default_26, primals_752, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_732 = primals_752 = None
        getitem_735 = convolution_backward_default_56[0]
        getitem_736 = convolution_backward_default_56[1]
        getitem_737 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_735, torch.float32);  getitem_735 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_160, to_dtype_84);  le_scalar_28 = new_zeros_default_160 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_74, primals_746, primals_744, primals_745, getitem_223, getitem_224, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_74 = primals_746 = primals_744 = primals_745 = getitem_223 = getitem_224 = None
        getitem_738 = native_batch_norm_backward_default_57[0]
        getitem_739 = native_batch_norm_backward_default_57[1]
        getitem_740 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_738, getitem_219, primals_741, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_738 = getitem_219 = primals_741 = None
        getitem_741 = convolution_backward_default_57[0]
        getitem_742 = convolution_backward_default_57[1]
        getitem_743 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(getitem_741, convolution_default_73, primals_739, primals_737, primals_738, getitem_220, getitem_221, True, 1e-05, [True, True, True]);  getitem_741 = convolution_default_73 = primals_739 = primals_737 = primals_738 = getitem_220 = getitem_221 = None
        getitem_744 = native_batch_norm_backward_default_58[0]
        getitem_745 = native_batch_norm_backward_default_58[1]
        getitem_746 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_744, relu__default_25, primals_740, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_744 = primals_740 = None
        getitem_747 = convolution_backward_default_58[0]
        getitem_748 = convolution_backward_default_58[1]
        getitem_749 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_747, torch.float32);  getitem_747 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_161, to_dtype_87);  le_scalar_29 = new_zeros_default_161 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_72, primals_734, primals_732, primals_733, getitem_217, getitem_218, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_72 = primals_734 = primals_732 = primals_733 = getitem_217 = getitem_218 = None
        getitem_750 = native_batch_norm_backward_default_59[0]
        getitem_751 = native_batch_norm_backward_default_59[1]
        getitem_752 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_750, getitem_213, primals_729, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_750 = getitem_213 = primals_729 = None
        getitem_753 = convolution_backward_default_59[0]
        getitem_754 = convolution_backward_default_59[1]
        getitem_755 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(getitem_753, convolution_default_71, primals_727, primals_725, primals_726, getitem_214, getitem_215, True, 1e-05, [True, True, True]);  getitem_753 = convolution_default_71 = primals_727 = primals_725 = primals_726 = getitem_214 = getitem_215 = None
        getitem_756 = native_batch_norm_backward_default_60[0]
        getitem_757 = native_batch_norm_backward_default_60[1]
        getitem_758 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_756, relu_default_9, primals_728, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_756 = primals_728 = None
        getitem_759 = convolution_backward_default_60[0]
        getitem_760 = convolution_backward_default_60[1]
        getitem_761 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_759, torch.float32);  getitem_759 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu_default_9, torch.float32);  relu_default_9 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_162, to_dtype_90);  le_scalar_30 = new_zeros_default_162 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, to_dtype_92);  add_tensor_27 = to_dtype_92 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_28, convolution_default_70, primals_722, primals_720, primals_721, getitem_211, getitem_212, True, 1e-05, [True, True, True]);  convolution_default_70 = primals_722 = primals_720 = primals_721 = getitem_211 = getitem_212 = None
        getitem_762 = native_batch_norm_backward_default_61[0]
        getitem_763 = native_batch_norm_backward_default_61[1]
        getitem_764 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_762, getitem_207, primals_717, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_762 = getitem_207 = primals_717 = None
        getitem_765 = convolution_backward_default_61[0]
        getitem_766 = convolution_backward_default_61[1]
        getitem_767 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(getitem_765, convolution_default_69, primals_715, primals_713, primals_714, getitem_208, getitem_209, True, 1e-05, [True, True, True]);  getitem_765 = convolution_default_69 = primals_715 = primals_713 = primals_714 = getitem_208 = getitem_209 = None
        getitem_768 = native_batch_norm_backward_default_62[0]
        getitem_769 = native_batch_norm_backward_default_62[1]
        getitem_770 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_768, relu__default_24, primals_716, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_768 = primals_716 = None
        getitem_771 = convolution_backward_default_62[0]
        getitem_772 = convolution_backward_default_62[1]
        getitem_773 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_771, torch.float32);  getitem_771 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_163, to_dtype_93);  le_scalar_31 = new_zeros_default_163 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_68, primals_710, primals_708, primals_709, getitem_205, getitem_206, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_68 = primals_710 = primals_708 = primals_709 = getitem_205 = getitem_206 = None
        getitem_774 = native_batch_norm_backward_default_63[0]
        getitem_775 = native_batch_norm_backward_default_63[1]
        getitem_776 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_774, getitem_201, primals_705, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_774 = getitem_201 = primals_705 = None
        getitem_777 = convolution_backward_default_63[0]
        getitem_778 = convolution_backward_default_63[1]
        getitem_779 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(getitem_777, convolution_default_67, primals_703, primals_701, primals_702, getitem_202, getitem_203, True, 1e-05, [True, True, True]);  getitem_777 = convolution_default_67 = primals_703 = primals_701 = primals_702 = getitem_202 = getitem_203 = None
        getitem_780 = native_batch_norm_backward_default_64[0]
        getitem_781 = native_batch_norm_backward_default_64[1]
        getitem_782 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_780, relu__default_23, primals_704, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_780 = primals_704 = None
        getitem_783 = convolution_backward_default_64[0]
        getitem_784 = convolution_backward_default_64[1]
        getitem_785 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_783, torch.float32);  getitem_783 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_164, to_dtype_96);  le_scalar_32 = new_zeros_default_164 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_66, primals_698, primals_696, primals_697, getitem_199, getitem_200, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_66 = primals_698 = primals_696 = primals_697 = getitem_199 = getitem_200 = None
        getitem_786 = native_batch_norm_backward_default_65[0]
        getitem_787 = native_batch_norm_backward_default_65[1]
        getitem_788 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_786, getitem_195, primals_693, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_786 = getitem_195 = primals_693 = None
        getitem_789 = convolution_backward_default_65[0]
        getitem_790 = convolution_backward_default_65[1]
        getitem_791 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(getitem_789, convolution_default_65, primals_691, primals_689, primals_690, getitem_196, getitem_197, True, 1e-05, [True, True, True]);  getitem_789 = convolution_default_65 = primals_691 = primals_689 = primals_690 = getitem_196 = getitem_197 = None
        getitem_792 = native_batch_norm_backward_default_66[0]
        getitem_793 = native_batch_norm_backward_default_66[1]
        getitem_794 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_792, relu_default_8, primals_692, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_792 = primals_692 = None
        getitem_795 = convolution_backward_default_66[0]
        getitem_796 = convolution_backward_default_66[1]
        getitem_797 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_795, torch.float32);  getitem_795 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu_default_8, torch.float32);  relu_default_8 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_165, to_dtype_99);  le_scalar_33 = new_zeros_default_165 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(add_tensor_28, to_dtype_101);  add_tensor_28 = to_dtype_101 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_29, convolution_default_64, primals_686, primals_684, primals_685, getitem_193, getitem_194, True, 1e-05, [True, True, True]);  convolution_default_64 = primals_686 = primals_684 = primals_685 = getitem_193 = getitem_194 = None
        getitem_798 = native_batch_norm_backward_default_67[0]
        getitem_799 = native_batch_norm_backward_default_67[1]
        getitem_800 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_798, getitem_189, primals_681, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_798 = getitem_189 = primals_681 = None
        getitem_801 = convolution_backward_default_67[0]
        getitem_802 = convolution_backward_default_67[1]
        getitem_803 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(getitem_801, convolution_default_63, primals_679, primals_677, primals_678, getitem_190, getitem_191, True, 1e-05, [True, True, True]);  getitem_801 = convolution_default_63 = primals_679 = primals_677 = primals_678 = getitem_190 = getitem_191 = None
        getitem_804 = native_batch_norm_backward_default_68[0]
        getitem_805 = native_batch_norm_backward_default_68[1]
        getitem_806 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_804, relu__default_22, primals_680, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_804 = primals_680 = None
        getitem_807 = convolution_backward_default_68[0]
        getitem_808 = convolution_backward_default_68[1]
        getitem_809 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_807, torch.float32);  getitem_807 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_166, to_dtype_102);  le_scalar_34 = new_zeros_default_166 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_62, primals_674, primals_672, primals_673, getitem_187, getitem_188, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_62 = primals_674 = primals_672 = primals_673 = getitem_187 = getitem_188 = None
        getitem_810 = native_batch_norm_backward_default_69[0]
        getitem_811 = native_batch_norm_backward_default_69[1]
        getitem_812 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_810, getitem_183, primals_669, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_810 = getitem_183 = primals_669 = None
        getitem_813 = convolution_backward_default_69[0]
        getitem_814 = convolution_backward_default_69[1]
        getitem_815 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(getitem_813, convolution_default_61, primals_667, primals_665, primals_666, getitem_184, getitem_185, True, 1e-05, [True, True, True]);  getitem_813 = convolution_default_61 = primals_667 = primals_665 = primals_666 = getitem_184 = getitem_185 = None
        getitem_816 = native_batch_norm_backward_default_70[0]
        getitem_817 = native_batch_norm_backward_default_70[1]
        getitem_818 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_816, relu__default_21, primals_668, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_816 = primals_668 = None
        getitem_819 = convolution_backward_default_70[0]
        getitem_820 = convolution_backward_default_70[1]
        getitem_821 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_819, torch.float32);  getitem_819 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_167, to_dtype_105);  le_scalar_35 = new_zeros_default_167 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_60, primals_662, primals_660, primals_661, getitem_181, getitem_182, True, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_60 = primals_662 = primals_660 = primals_661 = getitem_181 = getitem_182 = None
        getitem_822 = native_batch_norm_backward_default_71[0]
        getitem_823 = native_batch_norm_backward_default_71[1]
        getitem_824 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_822, getitem_177, primals_657, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_822 = getitem_177 = primals_657 = None
        getitem_825 = convolution_backward_default_71[0]
        getitem_826 = convolution_backward_default_71[1]
        getitem_827 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(getitem_825, convolution_default_59, primals_655, primals_653, primals_654, getitem_178, getitem_179, True, 1e-05, [True, True, True]);  getitem_825 = convolution_default_59 = primals_655 = primals_653 = primals_654 = getitem_178 = getitem_179 = None
        getitem_828 = native_batch_norm_backward_default_72[0]
        getitem_829 = native_batch_norm_backward_default_72[1]
        getitem_830 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_828, relu_default_7, primals_656, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_828 = primals_656 = None
        getitem_831 = convolution_backward_default_72[0]
        getitem_832 = convolution_backward_default_72[1]
        getitem_833 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_831, torch.float32);  getitem_831 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu_default_7, torch.float32);  relu_default_7 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_168, to_dtype_108);  le_scalar_36 = new_zeros_default_168 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_29, to_dtype_110);  add_tensor_29 = to_dtype_110 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_30, convolution_default_58, primals_650, primals_648, primals_649, getitem_175, getitem_176, True, 1e-05, [True, True, True]);  convolution_default_58 = primals_650 = primals_648 = primals_649 = getitem_175 = getitem_176 = None
        getitem_834 = native_batch_norm_backward_default_73[0]
        getitem_835 = native_batch_norm_backward_default_73[1]
        getitem_836 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_834, getitem_171, primals_645, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_834 = getitem_171 = primals_645 = None
        getitem_837 = convolution_backward_default_73[0]
        getitem_838 = convolution_backward_default_73[1]
        getitem_839 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(getitem_837, convolution_default_57, primals_643, primals_641, primals_642, getitem_172, getitem_173, True, 1e-05, [True, True, True]);  getitem_837 = convolution_default_57 = primals_643 = primals_641 = primals_642 = getitem_172 = getitem_173 = None
        getitem_840 = native_batch_norm_backward_default_74[0]
        getitem_841 = native_batch_norm_backward_default_74[1]
        getitem_842 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_840, relu__default_20, primals_644, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_840 = primals_644 = None
        getitem_843 = convolution_backward_default_74[0]
        getitem_844 = convolution_backward_default_74[1]
        getitem_845 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_843, torch.float32);  getitem_843 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_169, to_dtype_111);  le_scalar_37 = new_zeros_default_169 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_56, primals_638, primals_636, primals_637, getitem_169, getitem_170, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_56 = primals_638 = primals_636 = primals_637 = getitem_169 = getitem_170 = None
        getitem_846 = native_batch_norm_backward_default_75[0]
        getitem_847 = native_batch_norm_backward_default_75[1]
        getitem_848 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_846, getitem_165, primals_633, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_846 = getitem_165 = primals_633 = None
        getitem_849 = convolution_backward_default_75[0]
        getitem_850 = convolution_backward_default_75[1]
        getitem_851 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(getitem_849, convolution_default_55, primals_631, primals_629, primals_630, getitem_166, getitem_167, True, 1e-05, [True, True, True]);  getitem_849 = convolution_default_55 = primals_631 = primals_629 = primals_630 = getitem_166 = getitem_167 = None
        getitem_852 = native_batch_norm_backward_default_76[0]
        getitem_853 = native_batch_norm_backward_default_76[1]
        getitem_854 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_852, relu__default_19, primals_632, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_852 = primals_632 = None
        getitem_855 = convolution_backward_default_76[0]
        getitem_856 = convolution_backward_default_76[1]
        getitem_857 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_855, torch.float32);  getitem_855 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_170, to_dtype_114);  le_scalar_38 = new_zeros_default_170 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_54, primals_626, primals_624, primals_625, getitem_163, getitem_164, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_54 = primals_626 = primals_624 = primals_625 = getitem_163 = getitem_164 = None
        getitem_858 = native_batch_norm_backward_default_77[0]
        getitem_859 = native_batch_norm_backward_default_77[1]
        getitem_860 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_858, getitem_159, primals_621, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_858 = getitem_159 = primals_621 = None
        getitem_861 = convolution_backward_default_77[0]
        getitem_862 = convolution_backward_default_77[1]
        getitem_863 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(getitem_861, convolution_default_53, primals_619, primals_617, primals_618, getitem_160, getitem_161, True, 1e-05, [True, True, True]);  getitem_861 = convolution_default_53 = primals_619 = primals_617 = primals_618 = getitem_160 = getitem_161 = None
        getitem_864 = native_batch_norm_backward_default_78[0]
        getitem_865 = native_batch_norm_backward_default_78[1]
        getitem_866 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_864, relu_default_6, primals_620, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_864 = primals_620 = None
        getitem_867 = convolution_backward_default_78[0]
        getitem_868 = convolution_backward_default_78[1]
        getitem_869 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_867, torch.float32);  getitem_867 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu_default_6, torch.float32);  relu_default_6 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_171, to_dtype_117);  le_scalar_39 = new_zeros_default_171 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, to_dtype_119);  add_tensor_30 = to_dtype_119 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_31, convolution_default_52, primals_614, primals_612, primals_613, getitem_157, getitem_158, True, 1e-05, [True, True, True]);  convolution_default_52 = primals_614 = primals_612 = primals_613 = getitem_157 = getitem_158 = None
        getitem_870 = native_batch_norm_backward_default_79[0]
        getitem_871 = native_batch_norm_backward_default_79[1]
        getitem_872 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_870, getitem_153, primals_609, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_870 = getitem_153 = primals_609 = None
        getitem_873 = convolution_backward_default_79[0]
        getitem_874 = convolution_backward_default_79[1]
        getitem_875 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(getitem_873, convolution_default_51, primals_607, primals_605, primals_606, getitem_154, getitem_155, True, 1e-05, [True, True, True]);  getitem_873 = convolution_default_51 = primals_607 = primals_605 = primals_606 = getitem_154 = getitem_155 = None
        getitem_876 = native_batch_norm_backward_default_80[0]
        getitem_877 = native_batch_norm_backward_default_80[1]
        getitem_878 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_876, relu__default_18, primals_608, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_876 = primals_608 = None
        getitem_879 = convolution_backward_default_80[0]
        getitem_880 = convolution_backward_default_80[1]
        getitem_881 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_879, torch.float32);  getitem_879 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_172, to_dtype_120);  le_scalar_40 = new_zeros_default_172 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_50, primals_602, primals_600, primals_601, getitem_151, getitem_152, True, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_50 = primals_602 = primals_600 = primals_601 = getitem_151 = getitem_152 = None
        getitem_882 = native_batch_norm_backward_default_81[0]
        getitem_883 = native_batch_norm_backward_default_81[1]
        getitem_884 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_882, getitem_147, primals_597, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_882 = getitem_147 = primals_597 = None
        getitem_885 = convolution_backward_default_81[0]
        getitem_886 = convolution_backward_default_81[1]
        getitem_887 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(getitem_885, convolution_default_49, primals_595, primals_593, primals_594, getitem_148, getitem_149, True, 1e-05, [True, True, True]);  getitem_885 = convolution_default_49 = primals_595 = primals_593 = primals_594 = getitem_148 = getitem_149 = None
        getitem_888 = native_batch_norm_backward_default_82[0]
        getitem_889 = native_batch_norm_backward_default_82[1]
        getitem_890 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_888, relu__default_17, primals_596, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_888 = primals_596 = None
        getitem_891 = convolution_backward_default_82[0]
        getitem_892 = convolution_backward_default_82[1]
        getitem_893 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_891, torch.float32);  getitem_891 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_173, to_dtype_123);  le_scalar_41 = new_zeros_default_173 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_48, primals_590, primals_588, primals_589, getitem_145, getitem_146, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_48 = primals_590 = primals_588 = primals_589 = getitem_145 = getitem_146 = None
        getitem_894 = native_batch_norm_backward_default_83[0]
        getitem_895 = native_batch_norm_backward_default_83[1]
        getitem_896 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_894, getitem_141, primals_585, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_894 = getitem_141 = primals_585 = None
        getitem_897 = convolution_backward_default_83[0]
        getitem_898 = convolution_backward_default_83[1]
        getitem_899 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(getitem_897, convolution_default_47, primals_583, primals_581, primals_582, getitem_142, getitem_143, True, 1e-05, [True, True, True]);  getitem_897 = convolution_default_47 = primals_583 = primals_581 = primals_582 = getitem_142 = getitem_143 = None
        getitem_900 = native_batch_norm_backward_default_84[0]
        getitem_901 = native_batch_norm_backward_default_84[1]
        getitem_902 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_900, relu_default_5, primals_584, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_900 = primals_584 = None
        getitem_903 = convolution_backward_default_84[0]
        getitem_904 = convolution_backward_default_84[1]
        getitem_905 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_903, torch.float32);  getitem_903 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu_default_5, torch.float32);  relu_default_5 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_174, to_dtype_126);  le_scalar_42 = new_zeros_default_174 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(add_tensor_31, to_dtype_128);  add_tensor_31 = to_dtype_128 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_32, convolution_default_46, primals_578, primals_576, primals_577, getitem_139, getitem_140, True, 1e-05, [True, True, True]);  convolution_default_46 = primals_578 = primals_576 = primals_577 = getitem_139 = getitem_140 = None
        getitem_906 = native_batch_norm_backward_default_85[0]
        getitem_907 = native_batch_norm_backward_default_85[1]
        getitem_908 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_906, getitem_135, primals_573, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_906 = getitem_135 = primals_573 = None
        getitem_909 = convolution_backward_default_85[0]
        getitem_910 = convolution_backward_default_85[1]
        getitem_911 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(getitem_909, convolution_default_45, primals_571, primals_569, primals_570, getitem_136, getitem_137, True, 1e-05, [True, True, True]);  getitem_909 = convolution_default_45 = primals_571 = primals_569 = primals_570 = getitem_136 = getitem_137 = None
        getitem_912 = native_batch_norm_backward_default_86[0]
        getitem_913 = native_batch_norm_backward_default_86[1]
        getitem_914 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_912, relu__default_16, primals_572, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_912 = primals_572 = None
        getitem_915 = convolution_backward_default_86[0]
        getitem_916 = convolution_backward_default_86[1]
        getitem_917 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_915, torch.float32);  getitem_915 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_175, to_dtype_129);  le_scalar_43 = new_zeros_default_175 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_44, primals_566, primals_564, primals_565, getitem_133, getitem_134, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_44 = primals_566 = primals_564 = primals_565 = getitem_133 = getitem_134 = None
        getitem_918 = native_batch_norm_backward_default_87[0]
        getitem_919 = native_batch_norm_backward_default_87[1]
        getitem_920 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_918, getitem_129, primals_561, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_918 = getitem_129 = primals_561 = None
        getitem_921 = convolution_backward_default_87[0]
        getitem_922 = convolution_backward_default_87[1]
        getitem_923 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(getitem_921, convolution_default_43, primals_559, primals_557, primals_558, getitem_130, getitem_131, True, 1e-05, [True, True, True]);  getitem_921 = convolution_default_43 = primals_559 = primals_557 = primals_558 = getitem_130 = getitem_131 = None
        getitem_924 = native_batch_norm_backward_default_88[0]
        getitem_925 = native_batch_norm_backward_default_88[1]
        getitem_926 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_924, relu__default_15, primals_560, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_924 = primals_560 = None
        getitem_927 = convolution_backward_default_88[0]
        getitem_928 = convolution_backward_default_88[1]
        getitem_929 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_927, torch.float32);  getitem_927 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_176, to_dtype_132);  le_scalar_44 = new_zeros_default_176 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_42, primals_554, primals_552, primals_553, getitem_127, getitem_128, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_42 = primals_554 = primals_552 = primals_553 = getitem_127 = getitem_128 = None
        getitem_930 = native_batch_norm_backward_default_89[0]
        getitem_931 = native_batch_norm_backward_default_89[1]
        getitem_932 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_930, getitem_123, primals_549, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_930 = getitem_123 = primals_549 = None
        getitem_933 = convolution_backward_default_89[0]
        getitem_934 = convolution_backward_default_89[1]
        getitem_935 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(getitem_933, convolution_default_41, primals_547, primals_545, primals_546, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  getitem_933 = convolution_default_41 = primals_547 = primals_545 = primals_546 = getitem_124 = getitem_125 = None
        getitem_936 = native_batch_norm_backward_default_90[0]
        getitem_937 = native_batch_norm_backward_default_90[1]
        getitem_938 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_936, relu_default_4, primals_548, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_936 = primals_548 = None
        getitem_939 = convolution_backward_default_90[0]
        getitem_940 = convolution_backward_default_90[1]
        getitem_941 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_939, torch.float32);  getitem_939 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu_default_4, torch.float32);  relu_default_4 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_177, to_dtype_135);  le_scalar_45 = new_zeros_default_177 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_32, to_dtype_137);  add_tensor_32 = to_dtype_137 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_33, convolution_default_40, primals_542, primals_540, primals_541, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  convolution_default_40 = primals_542 = primals_540 = primals_541 = getitem_121 = getitem_122 = None
        getitem_942 = native_batch_norm_backward_default_91[0]
        getitem_943 = native_batch_norm_backward_default_91[1]
        getitem_944 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_942, getitem_117, primals_537, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_942 = getitem_117 = primals_537 = None
        getitem_945 = convolution_backward_default_91[0]
        getitem_946 = convolution_backward_default_91[1]
        getitem_947 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(getitem_945, convolution_default_39, primals_535, primals_533, primals_534, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  getitem_945 = convolution_default_39 = primals_535 = primals_533 = primals_534 = getitem_118 = getitem_119 = None
        getitem_948 = native_batch_norm_backward_default_92[0]
        getitem_949 = native_batch_norm_backward_default_92[1]
        getitem_950 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_948, relu__default_14, primals_536, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_948 = primals_536 = None
        getitem_951 = convolution_backward_default_92[0]
        getitem_952 = convolution_backward_default_92[1]
        getitem_953 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_951, torch.float32);  getitem_951 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_178, to_dtype_138);  le_scalar_46 = new_zeros_default_178 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_38, primals_530, primals_528, primals_529, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_38 = primals_530 = primals_528 = primals_529 = getitem_115 = getitem_116 = None
        getitem_954 = native_batch_norm_backward_default_93[0]
        getitem_955 = native_batch_norm_backward_default_93[1]
        getitem_956 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_954, getitem_111, primals_525, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_954 = getitem_111 = primals_525 = None
        getitem_957 = convolution_backward_default_93[0]
        getitem_958 = convolution_backward_default_93[1]
        getitem_959 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(getitem_957, convolution_default_37, primals_523, primals_521, primals_522, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  getitem_957 = convolution_default_37 = primals_523 = primals_521 = primals_522 = getitem_112 = getitem_113 = None
        getitem_960 = native_batch_norm_backward_default_94[0]
        getitem_961 = native_batch_norm_backward_default_94[1]
        getitem_962 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_960, relu__default_13, primals_524, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_960 = primals_524 = None
        getitem_963 = convolution_backward_default_94[0]
        getitem_964 = convolution_backward_default_94[1]
        getitem_965 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_963, torch.float32);  getitem_963 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_179, to_dtype_141);  le_scalar_47 = new_zeros_default_179 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_36, primals_518, primals_516, primals_517, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_36 = primals_518 = primals_516 = primals_517 = getitem_109 = getitem_110 = None
        getitem_966 = native_batch_norm_backward_default_95[0]
        getitem_967 = native_batch_norm_backward_default_95[1]
        getitem_968 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_966, getitem_105, primals_513, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_966 = getitem_105 = primals_513 = None
        getitem_969 = convolution_backward_default_95[0]
        getitem_970 = convolution_backward_default_95[1]
        getitem_971 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(getitem_969, convolution_default_35, primals_511, primals_509, primals_510, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  getitem_969 = convolution_default_35 = primals_511 = primals_509 = primals_510 = getitem_106 = getitem_107 = None
        getitem_972 = native_batch_norm_backward_default_96[0]
        getitem_973 = native_batch_norm_backward_default_96[1]
        getitem_974 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_972, relu_default_3, primals_512, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_972 = primals_512 = None
        getitem_975 = convolution_backward_default_96[0]
        getitem_976 = convolution_backward_default_96[1]
        getitem_977 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_975, torch.float32);  getitem_975 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu_default_3, torch.float32);  relu_default_3 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_180, to_dtype_144);  le_scalar_48 = new_zeros_default_180 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, to_dtype_146);  add_tensor_33 = to_dtype_146 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_34, convolution_default_34, primals_506, primals_504, primals_505, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  convolution_default_34 = primals_506 = primals_504 = primals_505 = getitem_103 = getitem_104 = None
        getitem_978 = native_batch_norm_backward_default_97[0]
        getitem_979 = native_batch_norm_backward_default_97[1]
        getitem_980 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_978, getitem_99, primals_501, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_978 = getitem_99 = primals_501 = None
        getitem_981 = convolution_backward_default_97[0]
        getitem_982 = convolution_backward_default_97[1]
        getitem_983 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(getitem_981, convolution_default_33, primals_499, primals_497, primals_498, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  getitem_981 = convolution_default_33 = primals_499 = primals_497 = primals_498 = getitem_100 = getitem_101 = None
        getitem_984 = native_batch_norm_backward_default_98[0]
        getitem_985 = native_batch_norm_backward_default_98[1]
        getitem_986 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_984, relu__default_12, primals_500, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_984 = primals_500 = None
        getitem_987 = convolution_backward_default_98[0]
        getitem_988 = convolution_backward_default_98[1]
        getitem_989 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_987, torch.float32);  getitem_987 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_181, to_dtype_147);  le_scalar_49 = new_zeros_default_181 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_32, primals_494, primals_492, primals_493, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_32 = primals_494 = primals_492 = primals_493 = getitem_97 = getitem_98 = None
        getitem_990 = native_batch_norm_backward_default_99[0]
        getitem_991 = native_batch_norm_backward_default_99[1]
        getitem_992 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_990, getitem_93, primals_489, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_990 = getitem_93 = primals_489 = None
        getitem_993 = convolution_backward_default_99[0]
        getitem_994 = convolution_backward_default_99[1]
        getitem_995 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(getitem_993, convolution_default_31, primals_487, primals_485, primals_486, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  getitem_993 = convolution_default_31 = primals_487 = primals_485 = primals_486 = getitem_94 = getitem_95 = None
        getitem_996 = native_batch_norm_backward_default_100[0]
        getitem_997 = native_batch_norm_backward_default_100[1]
        getitem_998 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_996, relu__default_11, primals_488, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_996 = primals_488 = None
        getitem_999 = convolution_backward_default_100[0]
        getitem_1000 = convolution_backward_default_100[1]
        getitem_1001 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_999, torch.float32);  getitem_999 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_182, to_dtype_150);  le_scalar_50 = new_zeros_default_182 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_30, primals_482, primals_480, primals_481, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  to_dtype_152 = convolution_default_30 = primals_482 = primals_480 = primals_481 = getitem_91 = getitem_92 = None
        getitem_1002 = native_batch_norm_backward_default_101[0]
        getitem_1003 = native_batch_norm_backward_default_101[1]
        getitem_1004 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1002, getitem_87, primals_477, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1002 = getitem_87 = primals_477 = None
        getitem_1005 = convolution_backward_default_101[0]
        getitem_1006 = convolution_backward_default_101[1]
        getitem_1007 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(getitem_1005, convolution_default_29, primals_475, primals_473, primals_474, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  getitem_1005 = convolution_default_29 = primals_475 = primals_473 = primals_474 = getitem_88 = getitem_89 = None
        getitem_1008 = native_batch_norm_backward_default_102[0]
        getitem_1009 = native_batch_norm_backward_default_102[1]
        getitem_1010 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1008, relu_default_2, primals_476, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1008 = primals_476 = None
        getitem_1011 = convolution_backward_default_102[0]
        getitem_1012 = convolution_backward_default_102[1]
        getitem_1013 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_1011, torch.float32);  getitem_1011 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu_default_2, torch.float32);  relu_default_2 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_183, to_dtype_153);  le_scalar_51 = new_zeros_default_183 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(add_tensor_34, to_dtype_155);  add_tensor_34 = to_dtype_155 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_35, convolution_default_28, primals_254, primals_252, primals_253, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  convolution_default_28 = primals_254 = primals_252 = primals_253 = getitem_85 = getitem_86 = None
        getitem_1014 = native_batch_norm_backward_default_103[0]
        getitem_1015 = native_batch_norm_backward_default_103[1]
        getitem_1016 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_1014, getitem_81, primals_249, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1014 = getitem_81 = primals_249 = None
        getitem_1017 = convolution_backward_default_103[0]
        getitem_1018 = convolution_backward_default_103[1]
        getitem_1019 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(getitem_1017, convolution_default_27, primals_247, primals_245, primals_246, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  getitem_1017 = convolution_default_27 = primals_247 = primals_245 = primals_246 = getitem_82 = getitem_83 = None
        getitem_1020 = native_batch_norm_backward_default_104[0]
        getitem_1021 = native_batch_norm_backward_default_104[1]
        getitem_1022 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_1020, relu__default_10, primals_248, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1020 = primals_248 = None
        getitem_1023 = convolution_backward_default_104[0]
        getitem_1024 = convolution_backward_default_104[1]
        getitem_1025 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_1023, torch.float32);  getitem_1023 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_184, to_dtype_156);  le_scalar_52 = new_zeros_default_184 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_26, primals_242, primals_240, primals_241, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_158 = convolution_default_26 = primals_242 = primals_240 = primals_241 = getitem_79 = getitem_80 = None
        getitem_1026 = native_batch_norm_backward_default_105[0]
        getitem_1027 = native_batch_norm_backward_default_105[1]
        getitem_1028 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_1026, getitem_75, primals_237, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1026 = getitem_75 = primals_237 = None
        getitem_1029 = convolution_backward_default_105[0]
        getitem_1030 = convolution_backward_default_105[1]
        getitem_1031 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(getitem_1029, convolution_default_25, primals_235, primals_233, primals_234, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  getitem_1029 = convolution_default_25 = primals_235 = primals_233 = primals_234 = getitem_76 = getitem_77 = None
        getitem_1032 = native_batch_norm_backward_default_106[0]
        getitem_1033 = native_batch_norm_backward_default_106[1]
        getitem_1034 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_1032, relu__default_9, primals_236, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1032 = primals_236 = None
        getitem_1035 = convolution_backward_default_106[0]
        getitem_1036 = convolution_backward_default_106[1]
        getitem_1037 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_1035, torch.float32);  getitem_1035 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_185, to_dtype_159);  le_scalar_53 = new_zeros_default_185 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_24, primals_230, primals_228, primals_229, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_24 = primals_230 = primals_228 = primals_229 = getitem_73 = getitem_74 = None
        getitem_1038 = native_batch_norm_backward_default_107[0]
        getitem_1039 = native_batch_norm_backward_default_107[1]
        getitem_1040 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_1038, getitem_69, primals_225, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1038 = getitem_69 = primals_225 = None
        getitem_1041 = convolution_backward_default_107[0]
        getitem_1042 = convolution_backward_default_107[1]
        getitem_1043 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(getitem_1041, convolution_default_23, primals_223, primals_221, primals_222, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  getitem_1041 = convolution_default_23 = primals_223 = primals_221 = primals_222 = getitem_70 = getitem_71 = None
        getitem_1044 = native_batch_norm_backward_default_108[0]
        getitem_1045 = native_batch_norm_backward_default_108[1]
        getitem_1046 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1044, relu_default_1, primals_224, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1044 = primals_224 = None
        getitem_1047 = convolution_backward_default_108[0]
        getitem_1048 = convolution_backward_default_108[1]
        getitem_1049 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_1047, torch.float32);  getitem_1047 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu_default_1, torch.float32);  relu_default_1 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_186, to_dtype_162);  le_scalar_54 = new_zeros_default_186 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_35, to_dtype_164);  add_tensor_35 = to_dtype_164 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_36, convolution_default_22, primals_162, primals_160, primals_161, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  convolution_default_22 = primals_162 = primals_160 = primals_161 = getitem_67 = getitem_68 = None
        getitem_1050 = native_batch_norm_backward_default_109[0]
        getitem_1051 = native_batch_norm_backward_default_109[1]
        getitem_1052 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1050, getitem_63, primals_157, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1050 = getitem_63 = primals_157 = None
        getitem_1053 = convolution_backward_default_109[0]
        getitem_1054 = convolution_backward_default_109[1]
        getitem_1055 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(getitem_1053, convolution_default_21, primals_155, primals_153, primals_154, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  getitem_1053 = convolution_default_21 = primals_155 = primals_153 = primals_154 = getitem_64 = getitem_65 = None
        getitem_1056 = native_batch_norm_backward_default_110[0]
        getitem_1057 = native_batch_norm_backward_default_110[1]
        getitem_1058 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1056, relu__default_8, primals_156, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1056 = primals_156 = None
        getitem_1059 = convolution_backward_default_110[0]
        getitem_1060 = convolution_backward_default_110[1]
        getitem_1061 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_1059, torch.float32);  getitem_1059 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_187, to_dtype_165);  le_scalar_55 = new_zeros_default_187 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_20, primals_150, primals_148, primals_149, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_167 = convolution_default_20 = primals_150 = primals_148 = primals_149 = getitem_61 = getitem_62 = None
        getitem_1062 = native_batch_norm_backward_default_111[0]
        getitem_1063 = native_batch_norm_backward_default_111[1]
        getitem_1064 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1062, getitem_57, primals_145, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1062 = getitem_57 = primals_145 = None
        getitem_1065 = convolution_backward_default_111[0]
        getitem_1066 = convolution_backward_default_111[1]
        getitem_1067 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(getitem_1065, convolution_default_19, primals_143, primals_141, primals_142, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  getitem_1065 = convolution_default_19 = primals_143 = primals_141 = primals_142 = getitem_58 = getitem_59 = None
        getitem_1068 = native_batch_norm_backward_default_112[0]
        getitem_1069 = native_batch_norm_backward_default_112[1]
        getitem_1070 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_1068, relu__default_7, primals_144, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 728, [True, True, False]);  getitem_1068 = primals_144 = None
        getitem_1071 = convolution_backward_default_112[0]
        getitem_1072 = convolution_backward_default_112[1]
        getitem_1073 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_1071, torch.float32);  getitem_1071 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_188, to_dtype_168);  le_scalar_56 = new_zeros_default_188 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_18, primals_138, primals_136, primals_137, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  to_dtype_170 = convolution_default_18 = primals_138 = primals_136 = primals_137 = getitem_55 = getitem_56 = None
        getitem_1074 = native_batch_norm_backward_default_113[0]
        getitem_1075 = native_batch_norm_backward_default_113[1]
        getitem_1076 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1074, getitem_51, primals_133, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1074 = getitem_51 = primals_133 = None
        getitem_1077 = convolution_backward_default_113[0]
        getitem_1078 = convolution_backward_default_113[1]
        getitem_1079 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(getitem_1077, convolution_default_17, primals_131, primals_129, primals_130, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  getitem_1077 = convolution_default_17 = primals_131 = primals_129 = primals_130 = getitem_52 = getitem_53 = None
        getitem_1080 = native_batch_norm_backward_default_114[0]
        getitem_1081 = native_batch_norm_backward_default_114[1]
        getitem_1082 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1080, relu_default, primals_132, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 256, [True, True, False]);  getitem_1080 = primals_132 = None
        getitem_1083 = convolution_backward_default_114[0]
        getitem_1084 = convolution_backward_default_114[1]
        getitem_1085 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_1083, torch.float32);  getitem_1083 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu_default, torch.float32);  relu_default = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_189, to_dtype_171);  le_scalar_57 = new_zeros_default_189 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_36, convolution_default_16, primals_168, primals_166, primals_167, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  add_tensor_36 = convolution_default_16 = primals_168 = primals_166 = primals_167 = getitem_49 = getitem_50 = None
        getitem_1086 = native_batch_norm_backward_default_115[0]
        getitem_1087 = native_batch_norm_backward_default_115[1]
        getitem_1088 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1086, add_tensor_1, primals_163, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1086 = add_tensor_1 = primals_163 = None
        getitem_1089 = convolution_backward_default_115[0]
        getitem_1090 = convolution_backward_default_115[1]
        getitem_1091 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(to_dtype_173, getitem_1089);  to_dtype_173 = getitem_1089 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_37, convolution_default_15, primals_120, primals_118, primals_119, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  convolution_default_15 = primals_120 = primals_118 = primals_119 = getitem_46 = getitem_47 = None
        getitem_1092 = native_batch_norm_backward_default_116[0]
        getitem_1093 = native_batch_norm_backward_default_116[1]
        getitem_1094 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1092, getitem_42, primals_115, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1092 = getitem_42 = primals_115 = None
        getitem_1095 = convolution_backward_default_116[0]
        getitem_1096 = convolution_backward_default_116[1]
        getitem_1097 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(getitem_1095, convolution_default_14, primals_113, primals_111, primals_112, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  getitem_1095 = convolution_default_14 = primals_113 = primals_111 = primals_112 = getitem_43 = getitem_44 = None
        getitem_1098 = native_batch_norm_backward_default_117[0]
        getitem_1099 = native_batch_norm_backward_default_117[1]
        getitem_1100 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_1098, relu__default_6, primals_114, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 256, [True, True, False]);  getitem_1098 = primals_114 = None
        getitem_1101 = convolution_backward_default_117[0]
        getitem_1102 = convolution_backward_default_117[1]
        getitem_1103 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_1101, torch.float32);  getitem_1101 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_190, to_dtype_174);  le_scalar_58 = new_zeros_default_190 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_13, primals_108, primals_106, primals_107, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_13 = primals_108 = primals_106 = primals_107 = getitem_40 = getitem_41 = None
        getitem_1104 = native_batch_norm_backward_default_118[0]
        getitem_1105 = native_batch_norm_backward_default_118[1]
        getitem_1106 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1104, getitem_36, primals_103, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1104 = getitem_36 = primals_103 = None
        getitem_1107 = convolution_backward_default_118[0]
        getitem_1108 = convolution_backward_default_118[1]
        getitem_1109 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(getitem_1107, convolution_default_12, primals_101, primals_99, primals_100, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  getitem_1107 = convolution_default_12 = primals_101 = primals_99 = primals_100 = getitem_37 = getitem_38 = None
        getitem_1110 = native_batch_norm_backward_default_119[0]
        getitem_1111 = native_batch_norm_backward_default_119[1]
        getitem_1112 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1110, relu__default_5, primals_102, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 256, [True, True, False]);  getitem_1110 = primals_102 = None
        getitem_1113 = convolution_backward_default_119[0]
        getitem_1114 = convolution_backward_default_119[1]
        getitem_1115 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_1113, torch.float32);  getitem_1113 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_191, to_dtype_177);  le_scalar_59 = new_zeros_default_191 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_11, primals_96, primals_94, primals_95, getitem_34, getitem_35, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_11 = primals_96 = primals_94 = primals_95 = getitem_34 = getitem_35 = None
        getitem_1116 = native_batch_norm_backward_default_120[0]
        getitem_1117 = native_batch_norm_backward_default_120[1]
        getitem_1118 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1116, getitem_30, primals_91, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1116 = getitem_30 = primals_91 = None
        getitem_1119 = convolution_backward_default_120[0]
        getitem_1120 = convolution_backward_default_120[1]
        getitem_1121 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(getitem_1119, convolution_default_10, primals_89, primals_87, primals_88, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  getitem_1119 = convolution_default_10 = primals_89 = primals_87 = primals_88 = getitem_31 = getitem_32 = None
        getitem_1122 = native_batch_norm_backward_default_121[0]
        getitem_1123 = native_batch_norm_backward_default_121[1]
        getitem_1124 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1122, relu__default_4, primals_90, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_1122 = primals_90 = None
        getitem_1125 = convolution_backward_default_121[0]
        getitem_1126 = convolution_backward_default_121[1]
        getitem_1127 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_37, convolution_default_9, primals_126, primals_124, primals_125, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  add_tensor_37 = convolution_default_9 = primals_126 = primals_124 = primals_125 = getitem_28 = getitem_29 = None
        getitem_1128 = native_batch_norm_backward_default_122[0]
        getitem_1129 = native_batch_norm_backward_default_122[1]
        getitem_1130 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1128, relu__default_4, primals_121, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1128 = primals_121 = None
        getitem_1131 = convolution_backward_default_122[0]
        getitem_1132 = convolution_backward_default_122[1]
        getitem_1133 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_1125, getitem_1131);  getitem_1125 = getitem_1131 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_38, torch.float32);  add_tensor_38 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_192, to_dtype_180);  le_scalar_60 = new_zeros_default_192 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_8, primals_36, primals_34, primals_35, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  convolution_default_8 = primals_36 = primals_34 = primals_35 = getitem_25 = getitem_26 = None
        getitem_1134 = native_batch_norm_backward_default_123[0]
        getitem_1135 = native_batch_norm_backward_default_123[1]
        getitem_1136 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1134, getitem_21, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1134 = getitem_21 = primals_31 = None
        getitem_1137 = convolution_backward_default_123[0]
        getitem_1138 = convolution_backward_default_123[1]
        getitem_1139 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(getitem_1137, convolution_default_7, primals_29, primals_27, primals_28, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  getitem_1137 = convolution_default_7 = primals_29 = primals_27 = primals_28 = getitem_22 = getitem_23 = None
        getitem_1140 = native_batch_norm_backward_default_124[0]
        getitem_1141 = native_batch_norm_backward_default_124[1]
        getitem_1142 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1140, relu__default_3, primals_30, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_1140 = primals_30 = None
        getitem_1143 = convolution_backward_default_124[0]
        getitem_1144 = convolution_backward_default_124[1]
        getitem_1145 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_1143, torch.float32);  getitem_1143 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_193, to_dtype_183);  le_scalar_61 = new_zeros_default_193 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_6, primals_24, primals_22, primals_23, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_185 = convolution_default_6 = primals_24 = primals_22 = primals_23 = getitem_19 = getitem_20 = None
        getitem_1146 = native_batch_norm_backward_default_125[0]
        getitem_1147 = native_batch_norm_backward_default_125[1]
        getitem_1148 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1146, getitem_15, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1146 = getitem_15 = primals_19 = None
        getitem_1149 = convolution_backward_default_125[0]
        getitem_1150 = convolution_backward_default_125[1]
        getitem_1151 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(getitem_1149, convolution_default_5, primals_17, primals_15, primals_16, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  getitem_1149 = convolution_default_5 = primals_17 = primals_15 = primals_16 = getitem_16 = getitem_17 = None
        getitem_1152 = native_batch_norm_backward_default_126[0]
        getitem_1153 = native_batch_norm_backward_default_126[1]
        getitem_1154 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1152, relu__default_2, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 128, [True, True, False]);  getitem_1152 = primals_18 = None
        getitem_1155 = convolution_backward_default_126[0]
        getitem_1156 = convolution_backward_default_126[1]
        getitem_1157 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_1155, torch.float32);  getitem_1155 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_194, to_dtype_186);  le_scalar_62 = new_zeros_default_194 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_4, primals_12, primals_10, primals_11, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_4 = primals_12 = primals_10 = primals_11 = getitem_13 = getitem_14 = None
        getitem_1158 = native_batch_norm_backward_default_127[0]
        getitem_1159 = native_batch_norm_backward_default_127[1]
        getitem_1160 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1158, getitem_9, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1158 = getitem_9 = primals_7 = None
        getitem_1161 = convolution_backward_default_127[0]
        getitem_1162 = convolution_backward_default_127[1]
        getitem_1163 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(getitem_1161, convolution_default_3, primals_5, primals_3, primals_4, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  getitem_1161 = convolution_default_3 = primals_5 = primals_3 = primals_4 = getitem_10 = getitem_11 = None
        getitem_1164 = native_batch_norm_backward_default_128[0]
        getitem_1165 = native_batch_norm_backward_default_128[1]
        getitem_1166 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1164, relu__default_1, primals_6, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 64, [True, True, False]);  getitem_1164 = primals_6 = None
        getitem_1167 = convolution_backward_default_128[0]
        getitem_1168 = convolution_backward_default_128[1]
        getitem_1169 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_2, primals_42, primals_40, primals_41, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_182 = convolution_default_2 = primals_42 = primals_40 = primals_41 = getitem_7 = getitem_8 = None
        getitem_1170 = native_batch_norm_backward_default_129[0]
        getitem_1171 = native_batch_norm_backward_default_129[1]
        getitem_1172 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1170, relu__default_1, primals_37, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1170 = primals_37 = None
        getitem_1173 = convolution_backward_default_129[0]
        getitem_1174 = convolution_backward_default_129[1]
        getitem_1175 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_1167, getitem_1173);  getitem_1167 = getitem_1173 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_39, torch.float32);  add_tensor_39 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_195, to_dtype_189);  le_scalar_63 = new_zeros_default_195 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_1, primals_178, primals_176, primals_177, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_1 = primals_178 = primals_176 = primals_177 = getitem_4 = getitem_5 = None
        getitem_1176 = native_batch_norm_backward_default_130[0]
        getitem_1177 = native_batch_norm_backward_default_130[1]
        getitem_1178 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1176, relu__default, primals_195, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1176 = primals_195 = None
        getitem_1179 = convolution_backward_default_130[0]
        getitem_1180 = convolution_backward_default_130[1]
        getitem_1181 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_1179, torch.float32);  getitem_1179 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_196, to_dtype_192);  le_scalar_64 = new_zeros_default_196 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default, primals_173, primals_171, primals_172, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default = primals_173 = primals_171 = primals_172 = getitem_1 = getitem_2 = None
        getitem_1182 = native_batch_norm_backward_default_131[0]
        getitem_1183 = native_batch_norm_backward_default_131[1]
        getitem_1184 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1182, primals_795, primals_194, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1182 = primals_795 = primals_194 = None
        getitem_1185 = convolution_backward_default_131[0]
        getitem_1186 = convolution_backward_default_131[1]
        getitem_1187 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        return [addmm_default, getitem_1166, None, None, None, getitem_1165, getitem_1168, getitem_1162, getitem_1160, None, None, None, getitem_1159, getitem_1154, None, None, None, getitem_1153, getitem_1156, getitem_1150, getitem_1148, None, None, None, getitem_1147, getitem_1142, None, None, None, getitem_1141, getitem_1144, getitem_1138, getitem_1136, None, None, None, getitem_1135, getitem_1174, getitem_1172, None, None, None, getitem_1171, getitem_464, None, None, None, getitem_463, getitem_466, getitem_460, getitem_458, None, None, None, getitem_457, getitem_452, None, None, None, getitem_451, getitem_454, getitem_448, getitem_446, None, None, None, getitem_445, getitem_440, None, None, None, getitem_439, getitem_442, getitem_436, getitem_434, None, None, None, getitem_433, getitem_472, getitem_470, None, None, None, getitem_469, getitem_1124, None, None, None, getitem_1123, getitem_1126, getitem_1120, getitem_1118, None, None, None, getitem_1117, getitem_1112, None, None, None, getitem_1111, getitem_1114, getitem_1108, getitem_1106, None, None, None, getitem_1105, getitem_1100, None, None, None, getitem_1099, getitem_1102, getitem_1096, getitem_1094, None, None, None, getitem_1093, getitem_1132, getitem_1130, None, None, None, getitem_1129, getitem_1082, None, None, None, getitem_1081, getitem_1084, getitem_1078, getitem_1076, None, None, None, getitem_1075, getitem_1070, None, None, None, getitem_1069, getitem_1072, getitem_1066, getitem_1064, None, None, None, getitem_1063, getitem_1058, None, None, None, getitem_1057, getitem_1060, getitem_1054, getitem_1052, None, None, None, getitem_1051, getitem_1090, getitem_1088, None, None, None, getitem_1087, getitem_1184, None, None, None, getitem_1183, getitem_1178, None, None, None, getitem_1177, getitem_422, None, None, None, getitem_421, getitem_410, None, None, None, getitem_409, getitem_398, None, None, None, getitem_397, getitem_1186, getitem_1180, getitem_428, None, None, None, getitem_427, getitem_430, getitem_424, getitem_416, None, None, None, getitem_415, getitem_418, getitem_412, getitem_404, None, None, None, getitem_403, getitem_406, getitem_400, view_default_1, t_default_4, getitem_1046, None, None, None, getitem_1045, getitem_1048, getitem_1042, getitem_1040, None, None, None, getitem_1039, getitem_1034, None, None, None, getitem_1033, getitem_1036, getitem_1030, getitem_1028, None, None, None, getitem_1027, getitem_1022, None, None, None, getitem_1021, getitem_1024, getitem_1018, getitem_1016, None, None, None, getitem_1015, getitem_686, None, None, None, getitem_685, getitem_688, getitem_682, getitem_680, None, None, None, getitem_679, getitem_674, None, None, None, getitem_673, getitem_676, getitem_670, getitem_668, None, None, None, getitem_667, getitem_662, None, None, None, getitem_661, getitem_664, getitem_658, getitem_656, None, None, None, getitem_655, getitem_650, None, None, None, getitem_649, getitem_652, getitem_646, getitem_644, None, None, None, getitem_643, getitem_638, None, None, None, getitem_637, getitem_640, getitem_634, getitem_632, None, None, None, getitem_631, getitem_626, None, None, None, getitem_625, getitem_628, getitem_622, getitem_620, None, None, None, getitem_619, getitem_614, None, None, None, getitem_613, getitem_616, getitem_610, getitem_608, None, None, None, getitem_607, getitem_602, None, None, None, getitem_601, getitem_604, getitem_598, getitem_596, None, None, None, getitem_595, getitem_590, None, None, None, getitem_589, getitem_592, getitem_586, getitem_584, None, None, None, getitem_583, getitem_578, None, None, None, getitem_577, getitem_580, getitem_574, getitem_572, None, None, None, getitem_571, getitem_566, None, None, None, getitem_565, getitem_568, getitem_562, getitem_560, None, None, None, getitem_559, getitem_554, None, None, None, getitem_553, getitem_556, getitem_550, getitem_548, None, None, None, getitem_547, getitem_542, None, None, None, getitem_541, getitem_544, getitem_538, getitem_536, None, None, None, getitem_535, getitem_530, None, None, None, getitem_529, getitem_532, getitem_526, getitem_524, None, None, None, getitem_523, getitem_518, None, None, None, getitem_517, getitem_520, getitem_514, getitem_512, None, None, None, getitem_511, getitem_506, None, None, None, getitem_505, getitem_508, getitem_502, getitem_500, None, None, None, getitem_499, getitem_494, None, None, None, getitem_493, getitem_496, getitem_490, getitem_488, None, None, None, getitem_487, getitem_482, None, None, None, getitem_481, getitem_484, getitem_478, getitem_476, None, None, None, getitem_475, getitem_1010, None, None, None, getitem_1009, getitem_1012, getitem_1006, getitem_1004, None, None, None, getitem_1003, getitem_998, None, None, None, getitem_997, getitem_1000, getitem_994, getitem_992, None, None, None, getitem_991, getitem_986, None, None, None, getitem_985, getitem_988, getitem_982, getitem_980, None, None, None, getitem_979, getitem_974, None, None, None, getitem_973, getitem_976, getitem_970, getitem_968, None, None, None, getitem_967, getitem_962, None, None, None, getitem_961, getitem_964, getitem_958, getitem_956, None, None, None, getitem_955, getitem_950, None, None, None, getitem_949, getitem_952, getitem_946, getitem_944, None, None, None, getitem_943, getitem_938, None, None, None, getitem_937, getitem_940, getitem_934, getitem_932, None, None, None, getitem_931, getitem_926, None, None, None, getitem_925, getitem_928, getitem_922, getitem_920, None, None, None, getitem_919, getitem_914, None, None, None, getitem_913, getitem_916, getitem_910, getitem_908, None, None, None, getitem_907, getitem_902, None, None, None, getitem_901, getitem_904, getitem_898, getitem_896, None, None, None, getitem_895, getitem_890, None, None, None, getitem_889, getitem_892, getitem_886, getitem_884, None, None, None, getitem_883, getitem_878, None, None, None, getitem_877, getitem_880, getitem_874, getitem_872, None, None, None, getitem_871, getitem_866, None, None, None, getitem_865, getitem_868, getitem_862, getitem_860, None, None, None, getitem_859, getitem_854, None, None, None, getitem_853, getitem_856, getitem_850, getitem_848, None, None, None, getitem_847, getitem_842, None, None, None, getitem_841, getitem_844, getitem_838, getitem_836, None, None, None, getitem_835, getitem_830, None, None, None, getitem_829, getitem_832, getitem_826, getitem_824, None, None, None, getitem_823, getitem_818, None, None, None, getitem_817, getitem_820, getitem_814, getitem_812, None, None, None, getitem_811, getitem_806, None, None, None, getitem_805, getitem_808, getitem_802, getitem_800, None, None, None, getitem_799, getitem_794, None, None, None, getitem_793, getitem_796, getitem_790, getitem_788, None, None, None, getitem_787, getitem_782, None, None, None, getitem_781, getitem_784, getitem_778, getitem_776, None, None, None, getitem_775, getitem_770, None, None, None, getitem_769, getitem_772, getitem_766, getitem_764, None, None, None, getitem_763, getitem_758, None, None, None, getitem_757, getitem_760, getitem_754, getitem_752, None, None, None, getitem_751, getitem_746, None, None, None, getitem_745, getitem_748, getitem_742, getitem_740, None, None, None, getitem_739, getitem_734, None, None, None, getitem_733, getitem_736, getitem_730, getitem_728, None, None, None, getitem_727, getitem_722, None, None, None, getitem_721, getitem_724, getitem_718, getitem_716, None, None, None, getitem_715, getitem_710, None, None, None, getitem_709, getitem_712, getitem_706, getitem_704, None, None, None, getitem_703, getitem_698, None, None, None, getitem_697, getitem_700, getitem_694, getitem_692, None, None, None, getitem_691, None]
        
