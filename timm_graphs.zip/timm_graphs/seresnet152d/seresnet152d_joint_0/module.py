
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/seresnet152d/seresnet152d_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, primals_898, primals_899, primals_900, primals_901, primals_902, primals_903, primals_904, primals_905, primals_906, primals_907, primals_908, primals_909, primals_910, primals_911, primals_912, primals_913, primals_914, primals_915, primals_916, primals_917, primals_918, primals_919, primals_920, primals_921, primals_922, primals_923, primals_924, primals_925, primals_926, primals_927, primals_928, primals_929, primals_930, primals_931, primals_932, primals_933, primals_934, primals_935, primals_936, primals_937, primals_938, primals_939, primals_940, primals_941, primals_942, primals_943, primals_944, primals_945, primals_946, primals_947, primals_948, primals_949, primals_950, primals_951, primals_952, primals_953, primals_954, primals_955, primals_956, primals_957, primals_958, primals_959, primals_960, primals_961, primals_962, primals_963, primals_964, primals_965, primals_966, primals_967, primals_968, primals_969, primals_970, primals_971, primals_972, primals_973, primals_974, primals_975, primals_976, primals_977, primals_978, primals_979, primals_980, primals_981, primals_982, primals_983, primals_984, primals_985, primals_986, primals_987, primals_988, primals_989, primals_990, primals_991, primals_992, primals_993, primals_994, primals_995, primals_996, primals_997, primals_998, primals_999, primals_1000, primals_1001, primals_1002, primals_1003, primals_1004, primals_1005, primals_1006, primals_1007, primals_1008, primals_1009, primals_1010, primals_1011, primals_1012, primals_1013, primals_1014, primals_1015, primals_1016, primals_1017, primals_1018, primals_1019, primals_1020, primals_1021, primals_1022, primals_1023, primals_1024, primals_1025, primals_1026, primals_1027, primals_1028, primals_1029, primals_1030, primals_1031, primals_1032, primals_1033, primals_1034, primals_1035, primals_1036, primals_1037, primals_1038, primals_1039, primals_1040, primals_1041, primals_1042, primals_1043, primals_1044, primals_1045, primals_1046, primals_1047, primals_1048, primals_1049, primals_1050, primals_1051, primals_1052, primals_1053, primals_1054, primals_1055, primals_1056, primals_1057, primals_1058, primals_1059, primals_1060, primals_1061, primals_1062, primals_1063, primals_1064, primals_1065, primals_1066, primals_1067, primals_1068, primals_1069, primals_1070, primals_1071, primals_1072, primals_1073, primals_1074, primals_1075, primals_1076, primals_1077, primals_1078, primals_1079, primals_1080, primals_1081, primals_1082, primals_1083, primals_1084, primals_1085, primals_1086, primals_1087, primals_1088, primals_1089, primals_1090, primals_1091, primals_1092, primals_1093, primals_1094, primals_1095, primals_1096, primals_1097, primals_1098, primals_1099, primals_1100, primals_1101, primals_1102, primals_1103, primals_1104, primals_1105, primals_1106, primals_1107, primals_1108, primals_1109, primals_1110, primals_1111, primals_1112, primals_1113, primals_1114, primals_1115, primals_1116, primals_1117, primals_1118, primals_1119, primals_1120, primals_1121, primals_1122, primals_1123, primals_1124, primals_1125, primals_1126, primals_1127, primals_1128, primals_1129, primals_1130, primals_1131, primals_1132, primals_1133, primals_1134, primals_1135, primals_1136, primals_1137, primals_1138, primals_1139, primals_1140, primals_1141, primals_1142, primals_1143, primals_1144, primals_1145, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_1145, primals_6, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_8, 1);  primals_8 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_11, primals_7, primals_9, primals_10, True, 0.1, 1e-05);  primals_7 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_14, 1);  primals_14 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_17, primals_13, primals_15, primals_16, True, 0.1, 1e-05);  primals_13 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_18, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_5, primals_1, primals_3, primals_4, True, 0.1, 1e-05);  primals_1 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2], [1, 1])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_22, 1);  primals_22 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_25, primals_21, primals_23, primals_24, True, 0.1, 1e-05);  primals_21 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_3, primals_37, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_27, 1);  primals_27 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_30, primals_26, primals_28, primals_29, True, 0.1, 1e-05);  primals_26 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_32, 1);  primals_32 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_35, primals_31, primals_33, primals_34, True, 0.1, 1e-05);  primals_31 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim = torch.ops.aten.mean.dim(getitem_17, [2, 3], True)
        convolution_default_6 = torch.ops.aten.convolution.default(mean_dim, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        relu__default_5 = torch.ops.aten.relu_.default(convolution_default_6);  convolution_default_6 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_7);  convolution_default_7 = None
        mul_tensor = torch.ops.aten.mul.Tensor(getitem_17, sigmoid_default)
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_9, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_41, 1);  primals_41 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_44, primals_40, primals_42, primals_43, True, 0.1, 1e-05);  primals_40 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_7 = torch.ops.aten.add_.Tensor(mul_tensor, getitem_20);  mul_tensor = getitem_20 = None
        relu__default_6 = torch.ops.aten.relu_.default(add__tensor_7);  add__tensor_7 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_50, 1);  primals_50 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_53, primals_49, primals_51, primals_52, True, 0.1, 1e-05);  primals_49 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_7, primals_65, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_55, 1);  primals_55 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_58, primals_54, primals_56, primals_57, True, 0.1, 1e-05);  primals_54 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_8, primals_66, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_60, 1);  primals_60 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_63, primals_59, primals_61, primals_62, True, 0.1, 1e-05);  primals_59 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_1 = torch.ops.aten.mean.dim(getitem_29, [2, 3], True)
        convolution_default_12 = torch.ops.aten.convolution.default(mean_dim_1, primals_68, primals_67, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_67 = None
        relu__default_9 = torch.ops.aten.relu_.default(convolution_default_12);  convolution_default_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_9, primals_70, primals_69, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_69 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_13);  convolution_default_13 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(getitem_29, sigmoid_default_1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(mul_tensor_1, relu__default_6);  mul_tensor_1 = None
        relu__default_10 = torch.ops.aten.relu_.default(add__tensor_11);  add__tensor_11 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_10, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_72, 1);  primals_72 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_75, primals_71, primals_73, primals_74, True, 0.1, 1e-05);  primals_71 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_11, primals_87, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_77, 1);  primals_77 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_80, primals_76, primals_78, primals_79, True, 0.1, 1e-05);  primals_76 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_12, primals_88, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_14 = torch.ops.aten.add_.Tensor(primals_82, 1);  primals_82 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_85, primals_81, primals_83, primals_84, True, 0.1, 1e-05);  primals_81 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_2 = torch.ops.aten.mean.dim(getitem_38, [2, 3], True)
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_2, primals_90, primals_89, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_89 = None
        relu__default_13 = torch.ops.aten.relu_.default(convolution_default_17);  convolution_default_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_13, primals_92, primals_91, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_91 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_18);  convolution_default_18 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(getitem_38, sigmoid_default_2)
        add__tensor_15 = torch.ops.aten.add_.Tensor(mul_tensor_2, relu__default_10);  mul_tensor_2 = None
        relu__default_14 = torch.ops.aten.relu_.default(add__tensor_15);  add__tensor_15 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_14, primals_108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_94, 1);  primals_94 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_97, primals_93, primals_95, primals_96, True, 0.1, 1e-05);  primals_93 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_15, primals_109, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_99, 1);  primals_99 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_102, primals_98, primals_100, primals_101, True, 0.1, 1e-05);  primals_98 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_16, primals_110, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_104, 1);  primals_104 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_107, primals_103, primals_105, primals_106, True, 0.1, 1e-05);  primals_103 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_3 = torch.ops.aten.mean.dim(getitem_47, [2, 3], True)
        convolution_default_22 = torch.ops.aten.convolution.default(mean_dim_3, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        relu__default_17 = torch.ops.aten.relu_.default(convolution_default_22);  convolution_default_22 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_17, primals_120, primals_119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_119 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_23);  convolution_default_23 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(getitem_47, sigmoid_default_3)
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(relu__default_14, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_24 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_19 = torch.ops.aten.add_.Tensor(primals_113, 1);  primals_113 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_116, primals_112, primals_114, primals_115, True, 0.1, 1e-05);  primals_112 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_20 = torch.ops.aten.add_.Tensor(mul_tensor_3, getitem_50);  mul_tensor_3 = getitem_50 = None
        relu__default_18 = torch.ops.aten.relu_.default(add__tensor_20);  add__tensor_20 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_18, primals_136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_122, 1);  primals_122 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_125, primals_121, primals_123, primals_124, True, 0.1, 1e-05);  primals_121 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_19, primals_137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_127, 1);  primals_127 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_130, primals_126, primals_128, primals_129, True, 0.1, 1e-05);  primals_126 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_20, primals_138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_23 = torch.ops.aten.add_.Tensor(primals_132, 1);  primals_132 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_135, primals_131, primals_133, primals_134, True, 0.1, 1e-05);  primals_131 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_4 = torch.ops.aten.mean.dim(getitem_59, [2, 3], True)
        convolution_default_28 = torch.ops.aten.convolution.default(mean_dim_4, primals_140, primals_139, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_139 = None
        relu__default_21 = torch.ops.aten.relu_.default(convolution_default_28);  convolution_default_28 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_21, primals_142, primals_141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_141 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_29);  convolution_default_29 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(getitem_59, sigmoid_default_4)
        add__tensor_24 = torch.ops.aten.add_.Tensor(mul_tensor_4, relu__default_18);  mul_tensor_4 = None
        relu__default_22 = torch.ops.aten.relu_.default(add__tensor_24);  add__tensor_24 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_22, primals_158, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_25 = torch.ops.aten.add_.Tensor(primals_144, 1);  primals_144 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_147, primals_143, primals_145, primals_146, True, 0.1, 1e-05);  primals_143 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_62);  getitem_62 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_23, primals_159, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_26 = torch.ops.aten.add_.Tensor(primals_149, 1);  primals_149 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_152, primals_148, primals_150, primals_151, True, 0.1, 1e-05);  primals_148 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_24, primals_160, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_154, 1);  primals_154 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_157, primals_153, primals_155, primals_156, True, 0.1, 1e-05);  primals_153 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_5 = torch.ops.aten.mean.dim(getitem_68, [2, 3], True)
        convolution_default_33 = torch.ops.aten.convolution.default(mean_dim_5, primals_162, primals_161, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_161 = None
        relu__default_25 = torch.ops.aten.relu_.default(convolution_default_33);  convolution_default_33 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_25, primals_164, primals_163, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_163 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_34);  convolution_default_34 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(getitem_68, sigmoid_default_5)
        add__tensor_28 = torch.ops.aten.add_.Tensor(mul_tensor_5, relu__default_22);  mul_tensor_5 = None
        relu__default_26 = torch.ops.aten.relu_.default(add__tensor_28);  add__tensor_28 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_26, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_29 = torch.ops.aten.add_.Tensor(primals_166, 1);  primals_166 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_169, primals_165, primals_167, primals_168, True, 0.1, 1e-05);  primals_165 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_71);  getitem_71 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_27, primals_181, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_171, 1);  primals_171 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_174, primals_170, primals_172, primals_173, True, 0.1, 1e-05);  primals_170 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_28, primals_182, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_176, 1);  primals_176 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_179, primals_175, primals_177, primals_178, True, 0.1, 1e-05);  primals_175 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_6 = torch.ops.aten.mean.dim(getitem_77, [2, 3], True)
        convolution_default_38 = torch.ops.aten.convolution.default(mean_dim_6, primals_184, primals_183, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_183 = None
        relu__default_29 = torch.ops.aten.relu_.default(convolution_default_38);  convolution_default_38 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_29, primals_186, primals_185, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_185 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_39);  convolution_default_39 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(getitem_77, sigmoid_default_6)
        add__tensor_32 = torch.ops.aten.add_.Tensor(mul_tensor_6, relu__default_26);  mul_tensor_6 = None
        relu__default_30 = torch.ops.aten.relu_.default(add__tensor_32);  add__tensor_32 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_30, primals_202, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_188, 1);  primals_188 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_191, primals_187, primals_189, primals_190, True, 0.1, 1e-05);  primals_187 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_80);  getitem_80 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_31, primals_203, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_34 = torch.ops.aten.add_.Tensor(primals_193, 1);  primals_193 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_196, primals_192, primals_194, primals_195, True, 0.1, 1e-05);  primals_192 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_32, primals_204, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_35 = torch.ops.aten.add_.Tensor(primals_198, 1);  primals_198 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_201, primals_197, primals_199, primals_200, True, 0.1, 1e-05);  primals_197 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_7 = torch.ops.aten.mean.dim(getitem_86, [2, 3], True)
        convolution_default_43 = torch.ops.aten.convolution.default(mean_dim_7, primals_206, primals_205, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_205 = None
        relu__default_33 = torch.ops.aten.relu_.default(convolution_default_43);  convolution_default_43 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_33, primals_208, primals_207, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_207 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_44);  convolution_default_44 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(getitem_86, sigmoid_default_7)
        add__tensor_36 = torch.ops.aten.add_.Tensor(mul_tensor_7, relu__default_30);  mul_tensor_7 = None
        relu__default_34 = torch.ops.aten.relu_.default(add__tensor_36);  add__tensor_36 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_34, primals_224, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_210, 1);  primals_210 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_213, primals_209, primals_211, primals_212, True, 0.1, 1e-05);  primals_209 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_35 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_35, primals_225, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_38 = torch.ops.aten.add_.Tensor(primals_215, 1);  primals_215 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_218, primals_214, primals_216, primals_217, True, 0.1, 1e-05);  primals_214 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_36 = torch.ops.aten.relu_.default(getitem_92);  getitem_92 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_36, primals_226, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_39 = torch.ops.aten.add_.Tensor(primals_220, 1);  primals_220 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_223, primals_219, primals_221, primals_222, True, 0.1, 1e-05);  primals_219 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_8 = torch.ops.aten.mean.dim(getitem_95, [2, 3], True)
        convolution_default_48 = torch.ops.aten.convolution.default(mean_dim_8, primals_228, primals_227, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_227 = None
        relu__default_37 = torch.ops.aten.relu_.default(convolution_default_48);  convolution_default_48 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_37, primals_230, primals_229, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_229 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_49);  convolution_default_49 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(getitem_95, sigmoid_default_8)
        add__tensor_40 = torch.ops.aten.add_.Tensor(mul_tensor_8, relu__default_34);  mul_tensor_8 = None
        relu__default_38 = torch.ops.aten.relu_.default(add__tensor_40);  add__tensor_40 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_38, primals_246, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_41 = torch.ops.aten.add_.Tensor(primals_232, 1);  primals_232 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_235, primals_231, primals_233, primals_234, True, 0.1, 1e-05);  primals_231 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_39 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_39, primals_247, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_42 = torch.ops.aten.add_.Tensor(primals_237, 1);  primals_237 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_240, primals_236, primals_238, primals_239, True, 0.1, 1e-05);  primals_236 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_40 = torch.ops.aten.relu_.default(getitem_101);  getitem_101 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_40, primals_248, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_43 = torch.ops.aten.add_.Tensor(primals_242, 1);  primals_242 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_245, primals_241, primals_243, primals_244, True, 0.1, 1e-05);  primals_241 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_9 = torch.ops.aten.mean.dim(getitem_104, [2, 3], True)
        convolution_default_53 = torch.ops.aten.convolution.default(mean_dim_9, primals_250, primals_249, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_249 = None
        relu__default_41 = torch.ops.aten.relu_.default(convolution_default_53);  convolution_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_41, primals_252, primals_251, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_251 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_54);  convolution_default_54 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(getitem_104, sigmoid_default_9)
        add__tensor_44 = torch.ops.aten.add_.Tensor(mul_tensor_9, relu__default_38);  mul_tensor_9 = None
        relu__default_42 = torch.ops.aten.relu_.default(add__tensor_44);  add__tensor_44 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_42, primals_268, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_45 = torch.ops.aten.add_.Tensor(primals_254, 1);  primals_254 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_257, primals_253, primals_255, primals_256, True, 0.1, 1e-05);  primals_253 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_43 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_43, primals_269, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_46 = torch.ops.aten.add_.Tensor(primals_259, 1);  primals_259 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_262, primals_258, primals_260, primals_261, True, 0.1, 1e-05);  primals_258 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_44 = torch.ops.aten.relu_.default(getitem_110);  getitem_110 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_44, primals_270, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_47 = torch.ops.aten.add_.Tensor(primals_264, 1);  primals_264 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_267, primals_263, primals_265, primals_266, True, 0.1, 1e-05);  primals_263 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_10 = torch.ops.aten.mean.dim(getitem_113, [2, 3], True)
        convolution_default_58 = torch.ops.aten.convolution.default(mean_dim_10, primals_272, primals_271, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_271 = None
        relu__default_45 = torch.ops.aten.relu_.default(convolution_default_58);  convolution_default_58 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_45, primals_274, primals_273, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_273 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_59);  convolution_default_59 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(getitem_113, sigmoid_default_10)
        add__tensor_48 = torch.ops.aten.add_.Tensor(mul_tensor_10, relu__default_42);  mul_tensor_10 = None
        relu__default_46 = torch.ops.aten.relu_.default(add__tensor_48);  add__tensor_48 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_46, primals_290, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_49 = torch.ops.aten.add_.Tensor(primals_276, 1);  primals_276 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_279, primals_275, primals_277, primals_278, True, 0.1, 1e-05);  primals_275 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_47 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_47, primals_291, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_50 = torch.ops.aten.add_.Tensor(primals_281, 1);  primals_281 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_284, primals_280, primals_282, primals_283, True, 0.1, 1e-05);  primals_280 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_48 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_48, primals_292, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_51 = torch.ops.aten.add_.Tensor(primals_286, 1);  primals_286 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_289, primals_285, primals_287, primals_288, True, 0.1, 1e-05);  primals_285 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_62, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_11 = torch.ops.aten.mean.dim(getitem_122, [2, 3], True)
        convolution_default_63 = torch.ops.aten.convolution.default(mean_dim_11, primals_300, primals_299, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_299 = None
        relu__default_49 = torch.ops.aten.relu_.default(convolution_default_63);  convolution_default_63 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_49, primals_302, primals_301, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_301 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_64);  convolution_default_64 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(getitem_122, sigmoid_default_11)
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(relu__default_46, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_65 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_293, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_52 = torch.ops.aten.add_.Tensor(primals_295, 1);  primals_295 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_298, primals_294, primals_296, primals_297, True, 0.1, 1e-05);  primals_294 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_53 = torch.ops.aten.add_.Tensor(mul_tensor_11, getitem_125);  mul_tensor_11 = getitem_125 = None
        relu__default_50 = torch.ops.aten.relu_.default(add__tensor_53);  add__tensor_53 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_50, primals_538, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_54 = torch.ops.aten.add_.Tensor(primals_524, 1);  primals_524 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_527, primals_523, primals_525, primals_526, True, 0.1, 1e-05);  primals_523 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_51 = torch.ops.aten.relu_.default(getitem_128);  getitem_128 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_51, primals_539, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_55 = torch.ops.aten.add_.Tensor(primals_529, 1);  primals_529 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_532, primals_528, primals_530, primals_531, True, 0.1, 1e-05);  primals_528 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_67, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_52 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_52, primals_540, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_56 = torch.ops.aten.add_.Tensor(primals_534, 1);  primals_534 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_537, primals_533, primals_535, primals_536, True, 0.1, 1e-05);  primals_533 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_12 = torch.ops.aten.mean.dim(getitem_134, [2, 3], True)
        convolution_default_69 = torch.ops.aten.convolution.default(mean_dim_12, primals_542, primals_541, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_541 = None
        relu__default_53 = torch.ops.aten.relu_.default(convolution_default_69);  convolution_default_69 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_53, primals_544, primals_543, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_543 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_70);  convolution_default_70 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(getitem_134, sigmoid_default_12)
        add__tensor_57 = torch.ops.aten.add_.Tensor(mul_tensor_12, relu__default_50);  mul_tensor_12 = None
        relu__default_54 = torch.ops.aten.relu_.default(add__tensor_57);  add__tensor_57 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_54, primals_780, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_58 = torch.ops.aten.add_.Tensor(primals_766, 1);  primals_766 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_769, primals_765, primals_767, primals_768, True, 0.1, 1e-05);  primals_765 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_71, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_55 = torch.ops.aten.relu_.default(getitem_137);  getitem_137 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_55, primals_781, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_59 = torch.ops.aten.add_.Tensor(primals_771, 1);  primals_771 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_774, primals_770, primals_772, primals_773, True, 0.1, 1e-05);  primals_770 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_72, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_56 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_56, primals_782, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_60 = torch.ops.aten.add_.Tensor(primals_776, 1);  primals_776 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_779, primals_775, primals_777, primals_778, True, 0.1, 1e-05);  primals_775 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_13 = torch.ops.aten.mean.dim(getitem_143, [2, 3], True)
        convolution_default_74 = torch.ops.aten.convolution.default(mean_dim_13, primals_784, primals_783, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_783 = None
        relu__default_57 = torch.ops.aten.relu_.default(convolution_default_74);  convolution_default_74 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_57, primals_786, primals_785, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_785 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_75);  convolution_default_75 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(getitem_143, sigmoid_default_13)
        add__tensor_61 = torch.ops.aten.add_.Tensor(mul_tensor_13, relu__default_54);  mul_tensor_13 = None
        relu__default_58 = torch.ops.aten.relu_.default(add__tensor_61);  add__tensor_61 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_58, primals_934, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_62 = torch.ops.aten.add_.Tensor(primals_920, 1);  primals_920 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_923, primals_919, primals_921, primals_922, True, 0.1, 1e-05);  primals_919 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_59 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_59, primals_935, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_63 = torch.ops.aten.add_.Tensor(primals_925, 1);  primals_925 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_928, primals_924, primals_926, primals_927, True, 0.1, 1e-05);  primals_924 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_77, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_60 = torch.ops.aten.relu_.default(getitem_149);  getitem_149 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_60, primals_936, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_64 = torch.ops.aten.add_.Tensor(primals_930, 1);  primals_930 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_933, primals_929, primals_931, primals_932, True, 0.1, 1e-05);  primals_929 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_14 = torch.ops.aten.mean.dim(getitem_152, [2, 3], True)
        convolution_default_79 = torch.ops.aten.convolution.default(mean_dim_14, primals_938, primals_937, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_937 = None
        relu__default_61 = torch.ops.aten.relu_.default(convolution_default_79);  convolution_default_79 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_61, primals_940, primals_939, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_939 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_80);  convolution_default_80 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(getitem_152, sigmoid_default_14)
        add__tensor_65 = torch.ops.aten.add_.Tensor(mul_tensor_14, relu__default_58);  mul_tensor_14 = None
        relu__default_62 = torch.ops.aten.relu_.default(add__tensor_65);  add__tensor_65 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_62, primals_956, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_66 = torch.ops.aten.add_.Tensor(primals_942, 1);  primals_942 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_945, primals_941, primals_943, primals_944, True, 0.1, 1e-05);  primals_941 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_81, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_63 = torch.ops.aten.relu_.default(getitem_155);  getitem_155 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_63, primals_957, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_67 = torch.ops.aten.add_.Tensor(primals_947, 1);  primals_947 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_950, primals_946, primals_948, primals_949, True, 0.1, 1e-05);  primals_946 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_82, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_64 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_64, primals_958, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_68 = torch.ops.aten.add_.Tensor(primals_952, 1);  primals_952 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_955, primals_951, primals_953, primals_954, True, 0.1, 1e-05);  primals_951 = None
        getitem_161 = native_batch_norm_default_53[0]
        getitem_162 = native_batch_norm_default_53[1]
        getitem_163 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_15 = torch.ops.aten.mean.dim(getitem_161, [2, 3], True)
        convolution_default_84 = torch.ops.aten.convolution.default(mean_dim_15, primals_960, primals_959, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_959 = None
        relu__default_65 = torch.ops.aten.relu_.default(convolution_default_84);  convolution_default_84 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_65, primals_962, primals_961, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_961 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_85);  convolution_default_85 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(getitem_161, sigmoid_default_15)
        add__tensor_69 = torch.ops.aten.add_.Tensor(mul_tensor_15, relu__default_62);  mul_tensor_15 = None
        relu__default_66 = torch.ops.aten.relu_.default(add__tensor_69);  add__tensor_69 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_66, primals_978, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_70 = torch.ops.aten.add_.Tensor(primals_964, 1);  primals_964 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_967, primals_963, primals_965, primals_966, True, 0.1, 1e-05);  primals_963 = None
        getitem_164 = native_batch_norm_default_54[0]
        getitem_165 = native_batch_norm_default_54[1]
        getitem_166 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_86, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_67 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_67, primals_979, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_71 = torch.ops.aten.add_.Tensor(primals_969, 1);  primals_969 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_972, primals_968, primals_970, primals_971, True, 0.1, 1e-05);  primals_968 = None
        getitem_167 = native_batch_norm_default_55[0]
        getitem_168 = native_batch_norm_default_55[1]
        getitem_169 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_87, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_68 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_68, primals_980, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_72 = torch.ops.aten.add_.Tensor(primals_974, 1);  primals_974 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_977, primals_973, primals_975, primals_976, True, 0.1, 1e-05);  primals_973 = None
        getitem_170 = native_batch_norm_default_56[0]
        getitem_171 = native_batch_norm_default_56[1]
        getitem_172 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_16 = torch.ops.aten.mean.dim(getitem_170, [2, 3], True)
        convolution_default_89 = torch.ops.aten.convolution.default(mean_dim_16, primals_982, primals_981, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_981 = None
        relu__default_69 = torch.ops.aten.relu_.default(convolution_default_89);  convolution_default_89 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_69, primals_984, primals_983, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_983 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(convolution_default_90);  convolution_default_90 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(getitem_170, sigmoid_default_16)
        add__tensor_73 = torch.ops.aten.add_.Tensor(mul_tensor_16, relu__default_66);  mul_tensor_16 = None
        relu__default_70 = torch.ops.aten.relu_.default(add__tensor_73);  add__tensor_73 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_70, primals_1000, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_74 = torch.ops.aten.add_.Tensor(primals_986, 1);  primals_986 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_989, primals_985, primals_987, primals_988, True, 0.1, 1e-05);  primals_985 = None
        getitem_173 = native_batch_norm_default_57[0]
        getitem_174 = native_batch_norm_default_57[1]
        getitem_175 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_91, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_71 = torch.ops.aten.relu_.default(getitem_173);  getitem_173 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_71, primals_1001, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_75 = torch.ops.aten.add_.Tensor(primals_991, 1);  primals_991 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_994, primals_990, primals_992, primals_993, True, 0.1, 1e-05);  primals_990 = None
        getitem_176 = native_batch_norm_default_58[0]
        getitem_177 = native_batch_norm_default_58[1]
        getitem_178 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_92, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_72 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_72, primals_1002, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_76 = torch.ops.aten.add_.Tensor(primals_996, 1);  primals_996 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_999, primals_995, primals_997, primals_998, True, 0.1, 1e-05);  primals_995 = None
        getitem_179 = native_batch_norm_default_59[0]
        getitem_180 = native_batch_norm_default_59[1]
        getitem_181 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_17 = torch.ops.aten.mean.dim(getitem_179, [2, 3], True)
        convolution_default_94 = torch.ops.aten.convolution.default(mean_dim_17, primals_1004, primals_1003, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1003 = None
        relu__default_73 = torch.ops.aten.relu_.default(convolution_default_94);  convolution_default_94 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_73, primals_1006, primals_1005, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1005 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_95);  convolution_default_95 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(getitem_179, sigmoid_default_17)
        add__tensor_77 = torch.ops.aten.add_.Tensor(mul_tensor_17, relu__default_70);  mul_tensor_17 = None
        relu__default_74 = torch.ops.aten.relu_.default(add__tensor_77);  add__tensor_77 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_74, primals_1022, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_78 = torch.ops.aten.add_.Tensor(primals_1008, 1);  primals_1008 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_1011, primals_1007, primals_1009, primals_1010, True, 0.1, 1e-05);  primals_1007 = None
        getitem_182 = native_batch_norm_default_60[0]
        getitem_183 = native_batch_norm_default_60[1]
        getitem_184 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_96, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_75 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_75, primals_1023, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_79 = torch.ops.aten.add_.Tensor(primals_1013, 1);  primals_1013 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_1016, primals_1012, primals_1014, primals_1015, True, 0.1, 1e-05);  primals_1012 = None
        getitem_185 = native_batch_norm_default_61[0]
        getitem_186 = native_batch_norm_default_61[1]
        getitem_187 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_97, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_76 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_76, primals_1024, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_80 = torch.ops.aten.add_.Tensor(primals_1018, 1);  primals_1018 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_1021, primals_1017, primals_1019, primals_1020, True, 0.1, 1e-05);  primals_1017 = None
        getitem_188 = native_batch_norm_default_62[0]
        getitem_189 = native_batch_norm_default_62[1]
        getitem_190 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_18 = torch.ops.aten.mean.dim(getitem_188, [2, 3], True)
        convolution_default_99 = torch.ops.aten.convolution.default(mean_dim_18, primals_1026, primals_1025, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1025 = None
        relu__default_77 = torch.ops.aten.relu_.default(convolution_default_99);  convolution_default_99 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_77, primals_1028, primals_1027, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1027 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(convolution_default_100);  convolution_default_100 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(getitem_188, sigmoid_default_18)
        add__tensor_81 = torch.ops.aten.add_.Tensor(mul_tensor_18, relu__default_74);  mul_tensor_18 = None
        relu__default_78 = torch.ops.aten.relu_.default(add__tensor_81);  add__tensor_81 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_78, primals_1044, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_82 = torch.ops.aten.add_.Tensor(primals_1030, 1);  primals_1030 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_1033, primals_1029, primals_1031, primals_1032, True, 0.1, 1e-05);  primals_1029 = None
        getitem_191 = native_batch_norm_default_63[0]
        getitem_192 = native_batch_norm_default_63[1]
        getitem_193 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_101, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_79 = torch.ops.aten.relu_.default(getitem_191);  getitem_191 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_79, primals_1045, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_83 = torch.ops.aten.add_.Tensor(primals_1035, 1);  primals_1035 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_1038, primals_1034, primals_1036, primals_1037, True, 0.1, 1e-05);  primals_1034 = None
        getitem_194 = native_batch_norm_default_64[0]
        getitem_195 = native_batch_norm_default_64[1]
        getitem_196 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_102, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_80 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_80, primals_1046, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_84 = torch.ops.aten.add_.Tensor(primals_1040, 1);  primals_1040 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_1043, primals_1039, primals_1041, primals_1042, True, 0.1, 1e-05);  primals_1039 = None
        getitem_197 = native_batch_norm_default_65[0]
        getitem_198 = native_batch_norm_default_65[1]
        getitem_199 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_103, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_19 = torch.ops.aten.mean.dim(getitem_197, [2, 3], True)
        convolution_default_104 = torch.ops.aten.convolution.default(mean_dim_19, primals_1048, primals_1047, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1047 = None
        relu__default_81 = torch.ops.aten.relu_.default(convolution_default_104);  convolution_default_104 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_81, primals_1050, primals_1049, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1049 = None
        sigmoid_default_19 = torch.ops.aten.sigmoid.default(convolution_default_105);  convolution_default_105 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(getitem_197, sigmoid_default_19)
        add__tensor_85 = torch.ops.aten.add_.Tensor(mul_tensor_19, relu__default_78);  mul_tensor_19 = None
        relu__default_82 = torch.ops.aten.relu_.default(add__tensor_85);  add__tensor_85 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_82, primals_1066, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_86 = torch.ops.aten.add_.Tensor(primals_1052, 1);  primals_1052 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_1055, primals_1051, primals_1053, primals_1054, True, 0.1, 1e-05);  primals_1051 = None
        getitem_200 = native_batch_norm_default_66[0]
        getitem_201 = native_batch_norm_default_66[1]
        getitem_202 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_106, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_83 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu__default_83, primals_1067, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_87 = torch.ops.aten.add_.Tensor(primals_1057, 1);  primals_1057 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_1060, primals_1056, primals_1058, primals_1059, True, 0.1, 1e-05);  primals_1056 = None
        getitem_203 = native_batch_norm_default_67[0]
        getitem_204 = native_batch_norm_default_67[1]
        getitem_205 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_107, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_84 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_84, primals_1068, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_88 = torch.ops.aten.add_.Tensor(primals_1062, 1);  primals_1062 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_1065, primals_1061, primals_1063, primals_1064, True, 0.1, 1e-05);  primals_1061 = None
        getitem_206 = native_batch_norm_default_68[0]
        getitem_207 = native_batch_norm_default_68[1]
        getitem_208 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_20 = torch.ops.aten.mean.dim(getitem_206, [2, 3], True)
        convolution_default_109 = torch.ops.aten.convolution.default(mean_dim_20, primals_1070, primals_1069, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1069 = None
        relu__default_85 = torch.ops.aten.relu_.default(convolution_default_109);  convolution_default_109 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_85, primals_1072, primals_1071, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1071 = None
        sigmoid_default_20 = torch.ops.aten.sigmoid.default(convolution_default_110);  convolution_default_110 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(getitem_206, sigmoid_default_20)
        add__tensor_89 = torch.ops.aten.add_.Tensor(mul_tensor_20, relu__default_82);  mul_tensor_20 = None
        relu__default_86 = torch.ops.aten.relu_.default(add__tensor_89);  add__tensor_89 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_86, primals_318, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_90 = torch.ops.aten.add_.Tensor(primals_304, 1);  primals_304 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_307, primals_303, primals_305, primals_306, True, 0.1, 1e-05);  primals_303 = None
        getitem_209 = native_batch_norm_default_69[0]
        getitem_210 = native_batch_norm_default_69[1]
        getitem_211 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_111, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_87 = torch.ops.aten.relu_.default(getitem_209);  getitem_209 = None
        convolution_default_112 = torch.ops.aten.convolution.default(relu__default_87, primals_319, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_91 = torch.ops.aten.add_.Tensor(primals_309, 1);  primals_309 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_312, primals_308, primals_310, primals_311, True, 0.1, 1e-05);  primals_308 = None
        getitem_212 = native_batch_norm_default_70[0]
        getitem_213 = native_batch_norm_default_70[1]
        getitem_214 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_112, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_88 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_113 = torch.ops.aten.convolution.default(relu__default_88, primals_320, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_92 = torch.ops.aten.add_.Tensor(primals_314, 1);  primals_314 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_317, primals_313, primals_315, primals_316, True, 0.1, 1e-05);  primals_313 = None
        getitem_215 = native_batch_norm_default_71[0]
        getitem_216 = native_batch_norm_default_71[1]
        getitem_217 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_113, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_21 = torch.ops.aten.mean.dim(getitem_215, [2, 3], True)
        convolution_default_114 = torch.ops.aten.convolution.default(mean_dim_21, primals_322, primals_321, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_321 = None
        relu__default_89 = torch.ops.aten.relu_.default(convolution_default_114);  convolution_default_114 = None
        convolution_default_115 = torch.ops.aten.convolution.default(relu__default_89, primals_324, primals_323, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_323 = None
        sigmoid_default_21 = torch.ops.aten.sigmoid.default(convolution_default_115);  convolution_default_115 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(getitem_215, sigmoid_default_21)
        add__tensor_93 = torch.ops.aten.add_.Tensor(mul_tensor_21, relu__default_86);  mul_tensor_21 = None
        relu__default_90 = torch.ops.aten.relu_.default(add__tensor_93);  add__tensor_93 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_90, primals_340, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_94 = torch.ops.aten.add_.Tensor(primals_326, 1);  primals_326 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_329, primals_325, primals_327, primals_328, True, 0.1, 1e-05);  primals_325 = None
        getitem_218 = native_batch_norm_default_72[0]
        getitem_219 = native_batch_norm_default_72[1]
        getitem_220 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_91 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_91, primals_341, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_95 = torch.ops.aten.add_.Tensor(primals_331, 1);  primals_331 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_334, primals_330, primals_332, primals_333, True, 0.1, 1e-05);  primals_330 = None
        getitem_221 = native_batch_norm_default_73[0]
        getitem_222 = native_batch_norm_default_73[1]
        getitem_223 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_117, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_92 = torch.ops.aten.relu_.default(getitem_221);  getitem_221 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_92, primals_342, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_96 = torch.ops.aten.add_.Tensor(primals_336, 1);  primals_336 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_339, primals_335, primals_337, primals_338, True, 0.1, 1e-05);  primals_335 = None
        getitem_224 = native_batch_norm_default_74[0]
        getitem_225 = native_batch_norm_default_74[1]
        getitem_226 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_118, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_22 = torch.ops.aten.mean.dim(getitem_224, [2, 3], True)
        convolution_default_119 = torch.ops.aten.convolution.default(mean_dim_22, primals_344, primals_343, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_343 = None
        relu__default_93 = torch.ops.aten.relu_.default(convolution_default_119);  convolution_default_119 = None
        convolution_default_120 = torch.ops.aten.convolution.default(relu__default_93, primals_346, primals_345, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_345 = None
        sigmoid_default_22 = torch.ops.aten.sigmoid.default(convolution_default_120);  convolution_default_120 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(getitem_224, sigmoid_default_22)
        add__tensor_97 = torch.ops.aten.add_.Tensor(mul_tensor_22, relu__default_90);  mul_tensor_22 = None
        relu__default_94 = torch.ops.aten.relu_.default(add__tensor_97);  add__tensor_97 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_94, primals_362, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_98 = torch.ops.aten.add_.Tensor(primals_348, 1);  primals_348 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_351, primals_347, primals_349, primals_350, True, 0.1, 1e-05);  primals_347 = None
        getitem_227 = native_batch_norm_default_75[0]
        getitem_228 = native_batch_norm_default_75[1]
        getitem_229 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_121, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_95 = torch.ops.aten.relu_.default(getitem_227);  getitem_227 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_95, primals_363, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_99 = torch.ops.aten.add_.Tensor(primals_353, 1);  primals_353 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_356, primals_352, primals_354, primals_355, True, 0.1, 1e-05);  primals_352 = None
        getitem_230 = native_batch_norm_default_76[0]
        getitem_231 = native_batch_norm_default_76[1]
        getitem_232 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_96 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_123 = torch.ops.aten.convolution.default(relu__default_96, primals_364, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_100 = torch.ops.aten.add_.Tensor(primals_358, 1);  primals_358 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_361, primals_357, primals_359, primals_360, True, 0.1, 1e-05);  primals_357 = None
        getitem_233 = native_batch_norm_default_77[0]
        getitem_234 = native_batch_norm_default_77[1]
        getitem_235 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_123, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_23 = torch.ops.aten.mean.dim(getitem_233, [2, 3], True)
        convolution_default_124 = torch.ops.aten.convolution.default(mean_dim_23, primals_366, primals_365, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_365 = None
        relu__default_97 = torch.ops.aten.relu_.default(convolution_default_124);  convolution_default_124 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu__default_97, primals_368, primals_367, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_367 = None
        sigmoid_default_23 = torch.ops.aten.sigmoid.default(convolution_default_125);  convolution_default_125 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(getitem_233, sigmoid_default_23)
        add__tensor_101 = torch.ops.aten.add_.Tensor(mul_tensor_23, relu__default_94);  mul_tensor_23 = None
        relu__default_98 = torch.ops.aten.relu_.default(add__tensor_101);  add__tensor_101 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_98, primals_384, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_102 = torch.ops.aten.add_.Tensor(primals_370, 1);  primals_370 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_373, primals_369, primals_371, primals_372, True, 0.1, 1e-05);  primals_369 = None
        getitem_236 = native_batch_norm_default_78[0]
        getitem_237 = native_batch_norm_default_78[1]
        getitem_238 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_99 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_127 = torch.ops.aten.convolution.default(relu__default_99, primals_385, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_103 = torch.ops.aten.add_.Tensor(primals_375, 1);  primals_375 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_378, primals_374, primals_376, primals_377, True, 0.1, 1e-05);  primals_374 = None
        getitem_239 = native_batch_norm_default_79[0]
        getitem_240 = native_batch_norm_default_79[1]
        getitem_241 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_127, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_100 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_128 = torch.ops.aten.convolution.default(relu__default_100, primals_386, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_104 = torch.ops.aten.add_.Tensor(primals_380, 1);  primals_380 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_383, primals_379, primals_381, primals_382, True, 0.1, 1e-05);  primals_379 = None
        getitem_242 = native_batch_norm_default_80[0]
        getitem_243 = native_batch_norm_default_80[1]
        getitem_244 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_24 = torch.ops.aten.mean.dim(getitem_242, [2, 3], True)
        convolution_default_129 = torch.ops.aten.convolution.default(mean_dim_24, primals_388, primals_387, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_387 = None
        relu__default_101 = torch.ops.aten.relu_.default(convolution_default_129);  convolution_default_129 = None
        convolution_default_130 = torch.ops.aten.convolution.default(relu__default_101, primals_390, primals_389, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_389 = None
        sigmoid_default_24 = torch.ops.aten.sigmoid.default(convolution_default_130);  convolution_default_130 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(getitem_242, sigmoid_default_24)
        add__tensor_105 = torch.ops.aten.add_.Tensor(mul_tensor_24, relu__default_98);  mul_tensor_24 = None
        relu__default_102 = torch.ops.aten.relu_.default(add__tensor_105);  add__tensor_105 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_102, primals_406, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_106 = torch.ops.aten.add_.Tensor(primals_392, 1);  primals_392 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_395, primals_391, primals_393, primals_394, True, 0.1, 1e-05);  primals_391 = None
        getitem_245 = native_batch_norm_default_81[0]
        getitem_246 = native_batch_norm_default_81[1]
        getitem_247 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_103 = torch.ops.aten.relu_.default(getitem_245);  getitem_245 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu__default_103, primals_407, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_107 = torch.ops.aten.add_.Tensor(primals_397, 1);  primals_397 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_400, primals_396, primals_398, primals_399, True, 0.1, 1e-05);  primals_396 = None
        getitem_248 = native_batch_norm_default_82[0]
        getitem_249 = native_batch_norm_default_82[1]
        getitem_250 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_132, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_104 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_133 = torch.ops.aten.convolution.default(relu__default_104, primals_408, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_108 = torch.ops.aten.add_.Tensor(primals_402, 1);  primals_402 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_405, primals_401, primals_403, primals_404, True, 0.1, 1e-05);  primals_401 = None
        getitem_251 = native_batch_norm_default_83[0]
        getitem_252 = native_batch_norm_default_83[1]
        getitem_253 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_133, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_25 = torch.ops.aten.mean.dim(getitem_251, [2, 3], True)
        convolution_default_134 = torch.ops.aten.convolution.default(mean_dim_25, primals_410, primals_409, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_409 = None
        relu__default_105 = torch.ops.aten.relu_.default(convolution_default_134);  convolution_default_134 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu__default_105, primals_412, primals_411, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_411 = None
        sigmoid_default_25 = torch.ops.aten.sigmoid.default(convolution_default_135);  convolution_default_135 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(getitem_251, sigmoid_default_25)
        add__tensor_109 = torch.ops.aten.add_.Tensor(mul_tensor_25, relu__default_102);  mul_tensor_25 = None
        relu__default_106 = torch.ops.aten.relu_.default(add__tensor_109);  add__tensor_109 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_106, primals_428, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_110 = torch.ops.aten.add_.Tensor(primals_414, 1);  primals_414 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_417, primals_413, primals_415, primals_416, True, 0.1, 1e-05);  primals_413 = None
        getitem_254 = native_batch_norm_default_84[0]
        getitem_255 = native_batch_norm_default_84[1]
        getitem_256 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_136, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_107 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        convolution_default_137 = torch.ops.aten.convolution.default(relu__default_107, primals_429, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_111 = torch.ops.aten.add_.Tensor(primals_419, 1);  primals_419 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_422, primals_418, primals_420, primals_421, True, 0.1, 1e-05);  primals_418 = None
        getitem_257 = native_batch_norm_default_85[0]
        getitem_258 = native_batch_norm_default_85[1]
        getitem_259 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_137, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_108 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        convolution_default_138 = torch.ops.aten.convolution.default(relu__default_108, primals_430, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_112 = torch.ops.aten.add_.Tensor(primals_424, 1);  primals_424 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_427, primals_423, primals_425, primals_426, True, 0.1, 1e-05);  primals_423 = None
        getitem_260 = native_batch_norm_default_86[0]
        getitem_261 = native_batch_norm_default_86[1]
        getitem_262 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_138, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_26 = torch.ops.aten.mean.dim(getitem_260, [2, 3], True)
        convolution_default_139 = torch.ops.aten.convolution.default(mean_dim_26, primals_432, primals_431, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_431 = None
        relu__default_109 = torch.ops.aten.relu_.default(convolution_default_139);  convolution_default_139 = None
        convolution_default_140 = torch.ops.aten.convolution.default(relu__default_109, primals_434, primals_433, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_433 = None
        sigmoid_default_26 = torch.ops.aten.sigmoid.default(convolution_default_140);  convolution_default_140 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(getitem_260, sigmoid_default_26)
        add__tensor_113 = torch.ops.aten.add_.Tensor(mul_tensor_26, relu__default_106);  mul_tensor_26 = None
        relu__default_110 = torch.ops.aten.relu_.default(add__tensor_113);  add__tensor_113 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_110, primals_450, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_114 = torch.ops.aten.add_.Tensor(primals_436, 1);  primals_436 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_439, primals_435, primals_437, primals_438, True, 0.1, 1e-05);  primals_435 = None
        getitem_263 = native_batch_norm_default_87[0]
        getitem_264 = native_batch_norm_default_87[1]
        getitem_265 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_141, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_111 = torch.ops.aten.relu_.default(getitem_263);  getitem_263 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu__default_111, primals_451, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_115 = torch.ops.aten.add_.Tensor(primals_441, 1);  primals_441 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_444, primals_440, primals_442, primals_443, True, 0.1, 1e-05);  primals_440 = None
        getitem_266 = native_batch_norm_default_88[0]
        getitem_267 = native_batch_norm_default_88[1]
        getitem_268 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_142, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_112 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_143 = torch.ops.aten.convolution.default(relu__default_112, primals_452, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_116 = torch.ops.aten.add_.Tensor(primals_446, 1);  primals_446 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_449, primals_445, primals_447, primals_448, True, 0.1, 1e-05);  primals_445 = None
        getitem_269 = native_batch_norm_default_89[0]
        getitem_270 = native_batch_norm_default_89[1]
        getitem_271 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_143, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_27 = torch.ops.aten.mean.dim(getitem_269, [2, 3], True)
        convolution_default_144 = torch.ops.aten.convolution.default(mean_dim_27, primals_454, primals_453, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_453 = None
        relu__default_113 = torch.ops.aten.relu_.default(convolution_default_144);  convolution_default_144 = None
        convolution_default_145 = torch.ops.aten.convolution.default(relu__default_113, primals_456, primals_455, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_455 = None
        sigmoid_default_27 = torch.ops.aten.sigmoid.default(convolution_default_145);  convolution_default_145 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(getitem_269, sigmoid_default_27)
        add__tensor_117 = torch.ops.aten.add_.Tensor(mul_tensor_27, relu__default_110);  mul_tensor_27 = None
        relu__default_114 = torch.ops.aten.relu_.default(add__tensor_117);  add__tensor_117 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_114, primals_472, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_118 = torch.ops.aten.add_.Tensor(primals_458, 1);  primals_458 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_461, primals_457, primals_459, primals_460, True, 0.1, 1e-05);  primals_457 = None
        getitem_272 = native_batch_norm_default_90[0]
        getitem_273 = native_batch_norm_default_90[1]
        getitem_274 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_146, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_115 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu__default_115, primals_473, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_119 = torch.ops.aten.add_.Tensor(primals_463, 1);  primals_463 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_466, primals_462, primals_464, primals_465, True, 0.1, 1e-05);  primals_462 = None
        getitem_275 = native_batch_norm_default_91[0]
        getitem_276 = native_batch_norm_default_91[1]
        getitem_277 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_147, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_116 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_148 = torch.ops.aten.convolution.default(relu__default_116, primals_474, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_120 = torch.ops.aten.add_.Tensor(primals_468, 1);  primals_468 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_471, primals_467, primals_469, primals_470, True, 0.1, 1e-05);  primals_467 = None
        getitem_278 = native_batch_norm_default_92[0]
        getitem_279 = native_batch_norm_default_92[1]
        getitem_280 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_148, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_28 = torch.ops.aten.mean.dim(getitem_278, [2, 3], True)
        convolution_default_149 = torch.ops.aten.convolution.default(mean_dim_28, primals_476, primals_475, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_475 = None
        relu__default_117 = torch.ops.aten.relu_.default(convolution_default_149);  convolution_default_149 = None
        convolution_default_150 = torch.ops.aten.convolution.default(relu__default_117, primals_478, primals_477, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_477 = None
        sigmoid_default_28 = torch.ops.aten.sigmoid.default(convolution_default_150);  convolution_default_150 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(getitem_278, sigmoid_default_28)
        add__tensor_121 = torch.ops.aten.add_.Tensor(mul_tensor_28, relu__default_114);  mul_tensor_28 = None
        relu__default_118 = torch.ops.aten.relu_.default(add__tensor_121);  add__tensor_121 = None
        convolution_default_151 = torch.ops.aten.convolution.default(relu__default_118, primals_494, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_122 = torch.ops.aten.add_.Tensor(primals_480, 1);  primals_480 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_151, primals_483, primals_479, primals_481, primals_482, True, 0.1, 1e-05);  primals_479 = None
        getitem_281 = native_batch_norm_default_93[0]
        getitem_282 = native_batch_norm_default_93[1]
        getitem_283 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_151, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_119 = torch.ops.aten.relu_.default(getitem_281);  getitem_281 = None
        convolution_default_152 = torch.ops.aten.convolution.default(relu__default_119, primals_495, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_123 = torch.ops.aten.add_.Tensor(primals_485, 1);  primals_485 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_152, primals_488, primals_484, primals_486, primals_487, True, 0.1, 1e-05);  primals_484 = None
        getitem_284 = native_batch_norm_default_94[0]
        getitem_285 = native_batch_norm_default_94[1]
        getitem_286 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_152, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_120 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_153 = torch.ops.aten.convolution.default(relu__default_120, primals_496, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_124 = torch.ops.aten.add_.Tensor(primals_490, 1);  primals_490 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_153, primals_493, primals_489, primals_491, primals_492, True, 0.1, 1e-05);  primals_489 = None
        getitem_287 = native_batch_norm_default_95[0]
        getitem_288 = native_batch_norm_default_95[1]
        getitem_289 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_153, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_29 = torch.ops.aten.mean.dim(getitem_287, [2, 3], True)
        convolution_default_154 = torch.ops.aten.convolution.default(mean_dim_29, primals_498, primals_497, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_497 = None
        relu__default_121 = torch.ops.aten.relu_.default(convolution_default_154);  convolution_default_154 = None
        convolution_default_155 = torch.ops.aten.convolution.default(relu__default_121, primals_500, primals_499, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_499 = None
        sigmoid_default_29 = torch.ops.aten.sigmoid.default(convolution_default_155);  convolution_default_155 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(getitem_287, sigmoid_default_29)
        add__tensor_125 = torch.ops.aten.add_.Tensor(mul_tensor_29, relu__default_118);  mul_tensor_29 = None
        relu__default_122 = torch.ops.aten.relu_.default(add__tensor_125);  add__tensor_125 = None
        convolution_default_156 = torch.ops.aten.convolution.default(relu__default_122, primals_516, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_126 = torch.ops.aten.add_.Tensor(primals_502, 1);  primals_502 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_156, primals_505, primals_501, primals_503, primals_504, True, 0.1, 1e-05);  primals_501 = None
        getitem_290 = native_batch_norm_default_96[0]
        getitem_291 = native_batch_norm_default_96[1]
        getitem_292 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_156, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_123 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        convolution_default_157 = torch.ops.aten.convolution.default(relu__default_123, primals_517, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_127 = torch.ops.aten.add_.Tensor(primals_507, 1);  primals_507 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_157, primals_510, primals_506, primals_508, primals_509, True, 0.1, 1e-05);  primals_506 = None
        getitem_293 = native_batch_norm_default_97[0]
        getitem_294 = native_batch_norm_default_97[1]
        getitem_295 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_157, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_124 = torch.ops.aten.relu_.default(getitem_293);  getitem_293 = None
        convolution_default_158 = torch.ops.aten.convolution.default(relu__default_124, primals_518, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_128 = torch.ops.aten.add_.Tensor(primals_512, 1);  primals_512 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_158, primals_515, primals_511, primals_513, primals_514, True, 0.1, 1e-05);  primals_511 = None
        getitem_296 = native_batch_norm_default_98[0]
        getitem_297 = native_batch_norm_default_98[1]
        getitem_298 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_158, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_30 = torch.ops.aten.mean.dim(getitem_296, [2, 3], True)
        convolution_default_159 = torch.ops.aten.convolution.default(mean_dim_30, primals_520, primals_519, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_519 = None
        relu__default_125 = torch.ops.aten.relu_.default(convolution_default_159);  convolution_default_159 = None
        convolution_default_160 = torch.ops.aten.convolution.default(relu__default_125, primals_522, primals_521, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_521 = None
        sigmoid_default_30 = torch.ops.aten.sigmoid.default(convolution_default_160);  convolution_default_160 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(getitem_296, sigmoid_default_30)
        add__tensor_129 = torch.ops.aten.add_.Tensor(mul_tensor_30, relu__default_122);  mul_tensor_30 = None
        relu__default_126 = torch.ops.aten.relu_.default(add__tensor_129);  add__tensor_129 = None
        convolution_default_161 = torch.ops.aten.convolution.default(relu__default_126, primals_560, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_130 = torch.ops.aten.add_.Tensor(primals_546, 1);  primals_546 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_161, primals_549, primals_545, primals_547, primals_548, True, 0.1, 1e-05);  primals_545 = None
        getitem_299 = native_batch_norm_default_99[0]
        getitem_300 = native_batch_norm_default_99[1]
        getitem_301 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_161, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_127 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        convolution_default_162 = torch.ops.aten.convolution.default(relu__default_127, primals_561, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_131 = torch.ops.aten.add_.Tensor(primals_551, 1);  primals_551 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_162, primals_554, primals_550, primals_552, primals_553, True, 0.1, 1e-05);  primals_550 = None
        getitem_302 = native_batch_norm_default_100[0]
        getitem_303 = native_batch_norm_default_100[1]
        getitem_304 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_162, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_128 = torch.ops.aten.relu_.default(getitem_302);  getitem_302 = None
        convolution_default_163 = torch.ops.aten.convolution.default(relu__default_128, primals_562, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_132 = torch.ops.aten.add_.Tensor(primals_556, 1);  primals_556 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_163, primals_559, primals_555, primals_557, primals_558, True, 0.1, 1e-05);  primals_555 = None
        getitem_305 = native_batch_norm_default_101[0]
        getitem_306 = native_batch_norm_default_101[1]
        getitem_307 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_163, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_31 = torch.ops.aten.mean.dim(getitem_305, [2, 3], True)
        convolution_default_164 = torch.ops.aten.convolution.default(mean_dim_31, primals_564, primals_563, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_563 = None
        relu__default_129 = torch.ops.aten.relu_.default(convolution_default_164);  convolution_default_164 = None
        convolution_default_165 = torch.ops.aten.convolution.default(relu__default_129, primals_566, primals_565, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_565 = None
        sigmoid_default_31 = torch.ops.aten.sigmoid.default(convolution_default_165);  convolution_default_165 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(getitem_305, sigmoid_default_31)
        add__tensor_133 = torch.ops.aten.add_.Tensor(mul_tensor_31, relu__default_126);  mul_tensor_31 = None
        relu__default_130 = torch.ops.aten.relu_.default(add__tensor_133);  add__tensor_133 = None
        convolution_default_166 = torch.ops.aten.convolution.default(relu__default_130, primals_582, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_134 = torch.ops.aten.add_.Tensor(primals_568, 1);  primals_568 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_166, primals_571, primals_567, primals_569, primals_570, True, 0.1, 1e-05);  primals_567 = None
        getitem_308 = native_batch_norm_default_102[0]
        getitem_309 = native_batch_norm_default_102[1]
        getitem_310 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_166, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_131 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_167 = torch.ops.aten.convolution.default(relu__default_131, primals_583, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_135 = torch.ops.aten.add_.Tensor(primals_573, 1);  primals_573 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_167, primals_576, primals_572, primals_574, primals_575, True, 0.1, 1e-05);  primals_572 = None
        getitem_311 = native_batch_norm_default_103[0]
        getitem_312 = native_batch_norm_default_103[1]
        getitem_313 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_167, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_132 = torch.ops.aten.relu_.default(getitem_311);  getitem_311 = None
        convolution_default_168 = torch.ops.aten.convolution.default(relu__default_132, primals_584, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_136 = torch.ops.aten.add_.Tensor(primals_578, 1);  primals_578 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_168, primals_581, primals_577, primals_579, primals_580, True, 0.1, 1e-05);  primals_577 = None
        getitem_314 = native_batch_norm_default_104[0]
        getitem_315 = native_batch_norm_default_104[1]
        getitem_316 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_168, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_32 = torch.ops.aten.mean.dim(getitem_314, [2, 3], True)
        convolution_default_169 = torch.ops.aten.convolution.default(mean_dim_32, primals_586, primals_585, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_585 = None
        relu__default_133 = torch.ops.aten.relu_.default(convolution_default_169);  convolution_default_169 = None
        convolution_default_170 = torch.ops.aten.convolution.default(relu__default_133, primals_588, primals_587, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_587 = None
        sigmoid_default_32 = torch.ops.aten.sigmoid.default(convolution_default_170);  convolution_default_170 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(getitem_314, sigmoid_default_32)
        add__tensor_137 = torch.ops.aten.add_.Tensor(mul_tensor_32, relu__default_130);  mul_tensor_32 = None
        relu__default_134 = torch.ops.aten.relu_.default(add__tensor_137);  add__tensor_137 = None
        convolution_default_171 = torch.ops.aten.convolution.default(relu__default_134, primals_604, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_138 = torch.ops.aten.add_.Tensor(primals_590, 1);  primals_590 = None
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_171, primals_593, primals_589, primals_591, primals_592, True, 0.1, 1e-05);  primals_589 = None
        getitem_317 = native_batch_norm_default_105[0]
        getitem_318 = native_batch_norm_default_105[1]
        getitem_319 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_171, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_135 = torch.ops.aten.relu_.default(getitem_317);  getitem_317 = None
        convolution_default_172 = torch.ops.aten.convolution.default(relu__default_135, primals_605, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_139 = torch.ops.aten.add_.Tensor(primals_595, 1);  primals_595 = None
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_172, primals_598, primals_594, primals_596, primals_597, True, 0.1, 1e-05);  primals_594 = None
        getitem_320 = native_batch_norm_default_106[0]
        getitem_321 = native_batch_norm_default_106[1]
        getitem_322 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_172, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_136 = torch.ops.aten.relu_.default(getitem_320);  getitem_320 = None
        convolution_default_173 = torch.ops.aten.convolution.default(relu__default_136, primals_606, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_140 = torch.ops.aten.add_.Tensor(primals_600, 1);  primals_600 = None
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_173, primals_603, primals_599, primals_601, primals_602, True, 0.1, 1e-05);  primals_599 = None
        getitem_323 = native_batch_norm_default_107[0]
        getitem_324 = native_batch_norm_default_107[1]
        getitem_325 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_173, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_33 = torch.ops.aten.mean.dim(getitem_323, [2, 3], True)
        convolution_default_174 = torch.ops.aten.convolution.default(mean_dim_33, primals_608, primals_607, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_607 = None
        relu__default_137 = torch.ops.aten.relu_.default(convolution_default_174);  convolution_default_174 = None
        convolution_default_175 = torch.ops.aten.convolution.default(relu__default_137, primals_610, primals_609, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_609 = None
        sigmoid_default_33 = torch.ops.aten.sigmoid.default(convolution_default_175);  convolution_default_175 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(getitem_323, sigmoid_default_33)
        add__tensor_141 = torch.ops.aten.add_.Tensor(mul_tensor_33, relu__default_134);  mul_tensor_33 = None
        relu__default_138 = torch.ops.aten.relu_.default(add__tensor_141);  add__tensor_141 = None
        convolution_default_176 = torch.ops.aten.convolution.default(relu__default_138, primals_626, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_142 = torch.ops.aten.add_.Tensor(primals_612, 1);  primals_612 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_176, primals_615, primals_611, primals_613, primals_614, True, 0.1, 1e-05);  primals_611 = None
        getitem_326 = native_batch_norm_default_108[0]
        getitem_327 = native_batch_norm_default_108[1]
        getitem_328 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_176, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_139 = torch.ops.aten.relu_.default(getitem_326);  getitem_326 = None
        convolution_default_177 = torch.ops.aten.convolution.default(relu__default_139, primals_627, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_143 = torch.ops.aten.add_.Tensor(primals_617, 1);  primals_617 = None
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_177, primals_620, primals_616, primals_618, primals_619, True, 0.1, 1e-05);  primals_616 = None
        getitem_329 = native_batch_norm_default_109[0]
        getitem_330 = native_batch_norm_default_109[1]
        getitem_331 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_177, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_140 = torch.ops.aten.relu_.default(getitem_329);  getitem_329 = None
        convolution_default_178 = torch.ops.aten.convolution.default(relu__default_140, primals_628, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_144 = torch.ops.aten.add_.Tensor(primals_622, 1);  primals_622 = None
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_178, primals_625, primals_621, primals_623, primals_624, True, 0.1, 1e-05);  primals_621 = None
        getitem_332 = native_batch_norm_default_110[0]
        getitem_333 = native_batch_norm_default_110[1]
        getitem_334 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_178, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_34 = torch.ops.aten.mean.dim(getitem_332, [2, 3], True)
        convolution_default_179 = torch.ops.aten.convolution.default(mean_dim_34, primals_630, primals_629, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_629 = None
        relu__default_141 = torch.ops.aten.relu_.default(convolution_default_179);  convolution_default_179 = None
        convolution_default_180 = torch.ops.aten.convolution.default(relu__default_141, primals_632, primals_631, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_631 = None
        sigmoid_default_34 = torch.ops.aten.sigmoid.default(convolution_default_180);  convolution_default_180 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(getitem_332, sigmoid_default_34)
        add__tensor_145 = torch.ops.aten.add_.Tensor(mul_tensor_34, relu__default_138);  mul_tensor_34 = None
        relu__default_142 = torch.ops.aten.relu_.default(add__tensor_145);  add__tensor_145 = None
        convolution_default_181 = torch.ops.aten.convolution.default(relu__default_142, primals_648, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_146 = torch.ops.aten.add_.Tensor(primals_634, 1);  primals_634 = None
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_181, primals_637, primals_633, primals_635, primals_636, True, 0.1, 1e-05);  primals_633 = None
        getitem_335 = native_batch_norm_default_111[0]
        getitem_336 = native_batch_norm_default_111[1]
        getitem_337 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_181, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_143 = torch.ops.aten.relu_.default(getitem_335);  getitem_335 = None
        convolution_default_182 = torch.ops.aten.convolution.default(relu__default_143, primals_649, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_147 = torch.ops.aten.add_.Tensor(primals_639, 1);  primals_639 = None
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_182, primals_642, primals_638, primals_640, primals_641, True, 0.1, 1e-05);  primals_638 = None
        getitem_338 = native_batch_norm_default_112[0]
        getitem_339 = native_batch_norm_default_112[1]
        getitem_340 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_182, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_144 = torch.ops.aten.relu_.default(getitem_338);  getitem_338 = None
        convolution_default_183 = torch.ops.aten.convolution.default(relu__default_144, primals_650, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_148 = torch.ops.aten.add_.Tensor(primals_644, 1);  primals_644 = None
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_183, primals_647, primals_643, primals_645, primals_646, True, 0.1, 1e-05);  primals_643 = None
        getitem_341 = native_batch_norm_default_113[0]
        getitem_342 = native_batch_norm_default_113[1]
        getitem_343 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_183, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_35 = torch.ops.aten.mean.dim(getitem_341, [2, 3], True)
        convolution_default_184 = torch.ops.aten.convolution.default(mean_dim_35, primals_652, primals_651, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_651 = None
        relu__default_145 = torch.ops.aten.relu_.default(convolution_default_184);  convolution_default_184 = None
        convolution_default_185 = torch.ops.aten.convolution.default(relu__default_145, primals_654, primals_653, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_653 = None
        sigmoid_default_35 = torch.ops.aten.sigmoid.default(convolution_default_185);  convolution_default_185 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(getitem_341, sigmoid_default_35)
        add__tensor_149 = torch.ops.aten.add_.Tensor(mul_tensor_35, relu__default_142);  mul_tensor_35 = None
        relu__default_146 = torch.ops.aten.relu_.default(add__tensor_149);  add__tensor_149 = None
        convolution_default_186 = torch.ops.aten.convolution.default(relu__default_146, primals_670, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_150 = torch.ops.aten.add_.Tensor(primals_656, 1);  primals_656 = None
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_186, primals_659, primals_655, primals_657, primals_658, True, 0.1, 1e-05);  primals_655 = None
        getitem_344 = native_batch_norm_default_114[0]
        getitem_345 = native_batch_norm_default_114[1]
        getitem_346 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_186, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_147 = torch.ops.aten.relu_.default(getitem_344);  getitem_344 = None
        convolution_default_187 = torch.ops.aten.convolution.default(relu__default_147, primals_671, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_151 = torch.ops.aten.add_.Tensor(primals_661, 1);  primals_661 = None
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_187, primals_664, primals_660, primals_662, primals_663, True, 0.1, 1e-05);  primals_660 = None
        getitem_347 = native_batch_norm_default_115[0]
        getitem_348 = native_batch_norm_default_115[1]
        getitem_349 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_187, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_148 = torch.ops.aten.relu_.default(getitem_347);  getitem_347 = None
        convolution_default_188 = torch.ops.aten.convolution.default(relu__default_148, primals_672, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_152 = torch.ops.aten.add_.Tensor(primals_666, 1);  primals_666 = None
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_188, primals_669, primals_665, primals_667, primals_668, True, 0.1, 1e-05);  primals_665 = None
        getitem_350 = native_batch_norm_default_116[0]
        getitem_351 = native_batch_norm_default_116[1]
        getitem_352 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_188, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_36 = torch.ops.aten.mean.dim(getitem_350, [2, 3], True)
        convolution_default_189 = torch.ops.aten.convolution.default(mean_dim_36, primals_674, primals_673, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_673 = None
        relu__default_149 = torch.ops.aten.relu_.default(convolution_default_189);  convolution_default_189 = None
        convolution_default_190 = torch.ops.aten.convolution.default(relu__default_149, primals_676, primals_675, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_675 = None
        sigmoid_default_36 = torch.ops.aten.sigmoid.default(convolution_default_190);  convolution_default_190 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(getitem_350, sigmoid_default_36)
        add__tensor_153 = torch.ops.aten.add_.Tensor(mul_tensor_36, relu__default_146);  mul_tensor_36 = None
        relu__default_150 = torch.ops.aten.relu_.default(add__tensor_153);  add__tensor_153 = None
        convolution_default_191 = torch.ops.aten.convolution.default(relu__default_150, primals_692, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_154 = torch.ops.aten.add_.Tensor(primals_678, 1);  primals_678 = None
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_191, primals_681, primals_677, primals_679, primals_680, True, 0.1, 1e-05);  primals_677 = None
        getitem_353 = native_batch_norm_default_117[0]
        getitem_354 = native_batch_norm_default_117[1]
        getitem_355 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_191, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_151 = torch.ops.aten.relu_.default(getitem_353);  getitem_353 = None
        convolution_default_192 = torch.ops.aten.convolution.default(relu__default_151, primals_693, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_155 = torch.ops.aten.add_.Tensor(primals_683, 1);  primals_683 = None
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_192, primals_686, primals_682, primals_684, primals_685, True, 0.1, 1e-05);  primals_682 = None
        getitem_356 = native_batch_norm_default_118[0]
        getitem_357 = native_batch_norm_default_118[1]
        getitem_358 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_192, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_152 = torch.ops.aten.relu_.default(getitem_356);  getitem_356 = None
        convolution_default_193 = torch.ops.aten.convolution.default(relu__default_152, primals_694, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_156 = torch.ops.aten.add_.Tensor(primals_688, 1);  primals_688 = None
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_193, primals_691, primals_687, primals_689, primals_690, True, 0.1, 1e-05);  primals_687 = None
        getitem_359 = native_batch_norm_default_119[0]
        getitem_360 = native_batch_norm_default_119[1]
        getitem_361 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_193, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_37 = torch.ops.aten.mean.dim(getitem_359, [2, 3], True)
        convolution_default_194 = torch.ops.aten.convolution.default(mean_dim_37, primals_696, primals_695, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_695 = None
        relu__default_153 = torch.ops.aten.relu_.default(convolution_default_194);  convolution_default_194 = None
        convolution_default_195 = torch.ops.aten.convolution.default(relu__default_153, primals_698, primals_697, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_697 = None
        sigmoid_default_37 = torch.ops.aten.sigmoid.default(convolution_default_195);  convolution_default_195 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(getitem_359, sigmoid_default_37)
        add__tensor_157 = torch.ops.aten.add_.Tensor(mul_tensor_37, relu__default_150);  mul_tensor_37 = None
        relu__default_154 = torch.ops.aten.relu_.default(add__tensor_157);  add__tensor_157 = None
        convolution_default_196 = torch.ops.aten.convolution.default(relu__default_154, primals_714, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_158 = torch.ops.aten.add_.Tensor(primals_700, 1);  primals_700 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_196, primals_703, primals_699, primals_701, primals_702, True, 0.1, 1e-05);  primals_699 = None
        getitem_362 = native_batch_norm_default_120[0]
        getitem_363 = native_batch_norm_default_120[1]
        getitem_364 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_196, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_155 = torch.ops.aten.relu_.default(getitem_362);  getitem_362 = None
        convolution_default_197 = torch.ops.aten.convolution.default(relu__default_155, primals_715, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_159 = torch.ops.aten.add_.Tensor(primals_705, 1);  primals_705 = None
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_197, primals_708, primals_704, primals_706, primals_707, True, 0.1, 1e-05);  primals_704 = None
        getitem_365 = native_batch_norm_default_121[0]
        getitem_366 = native_batch_norm_default_121[1]
        getitem_367 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_197, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_156 = torch.ops.aten.relu_.default(getitem_365);  getitem_365 = None
        convolution_default_198 = torch.ops.aten.convolution.default(relu__default_156, primals_716, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_160 = torch.ops.aten.add_.Tensor(primals_710, 1);  primals_710 = None
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_198, primals_713, primals_709, primals_711, primals_712, True, 0.1, 1e-05);  primals_709 = None
        getitem_368 = native_batch_norm_default_122[0]
        getitem_369 = native_batch_norm_default_122[1]
        getitem_370 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_198, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_38 = torch.ops.aten.mean.dim(getitem_368, [2, 3], True)
        convolution_default_199 = torch.ops.aten.convolution.default(mean_dim_38, primals_718, primals_717, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_717 = None
        relu__default_157 = torch.ops.aten.relu_.default(convolution_default_199);  convolution_default_199 = None
        convolution_default_200 = torch.ops.aten.convolution.default(relu__default_157, primals_720, primals_719, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_719 = None
        sigmoid_default_38 = torch.ops.aten.sigmoid.default(convolution_default_200);  convolution_default_200 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(getitem_368, sigmoid_default_38)
        add__tensor_161 = torch.ops.aten.add_.Tensor(mul_tensor_38, relu__default_154);  mul_tensor_38 = None
        relu__default_158 = torch.ops.aten.relu_.default(add__tensor_161);  add__tensor_161 = None
        convolution_default_201 = torch.ops.aten.convolution.default(relu__default_158, primals_736, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_162 = torch.ops.aten.add_.Tensor(primals_722, 1);  primals_722 = None
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_201, primals_725, primals_721, primals_723, primals_724, True, 0.1, 1e-05);  primals_721 = None
        getitem_371 = native_batch_norm_default_123[0]
        getitem_372 = native_batch_norm_default_123[1]
        getitem_373 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_201, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_159 = torch.ops.aten.relu_.default(getitem_371);  getitem_371 = None
        convolution_default_202 = torch.ops.aten.convolution.default(relu__default_159, primals_737, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_163 = torch.ops.aten.add_.Tensor(primals_727, 1);  primals_727 = None
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_202, primals_730, primals_726, primals_728, primals_729, True, 0.1, 1e-05);  primals_726 = None
        getitem_374 = native_batch_norm_default_124[0]
        getitem_375 = native_batch_norm_default_124[1]
        getitem_376 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_202, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_160 = torch.ops.aten.relu_.default(getitem_374);  getitem_374 = None
        convolution_default_203 = torch.ops.aten.convolution.default(relu__default_160, primals_738, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_164 = torch.ops.aten.add_.Tensor(primals_732, 1);  primals_732 = None
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_203, primals_735, primals_731, primals_733, primals_734, True, 0.1, 1e-05);  primals_731 = None
        getitem_377 = native_batch_norm_default_125[0]
        getitem_378 = native_batch_norm_default_125[1]
        getitem_379 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_203, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_39 = torch.ops.aten.mean.dim(getitem_377, [2, 3], True)
        convolution_default_204 = torch.ops.aten.convolution.default(mean_dim_39, primals_740, primals_739, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_739 = None
        relu__default_161 = torch.ops.aten.relu_.default(convolution_default_204);  convolution_default_204 = None
        convolution_default_205 = torch.ops.aten.convolution.default(relu__default_161, primals_742, primals_741, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_741 = None
        sigmoid_default_39 = torch.ops.aten.sigmoid.default(convolution_default_205);  convolution_default_205 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(getitem_377, sigmoid_default_39)
        add__tensor_165 = torch.ops.aten.add_.Tensor(mul_tensor_39, relu__default_158);  mul_tensor_39 = None
        relu__default_162 = torch.ops.aten.relu_.default(add__tensor_165);  add__tensor_165 = None
        convolution_default_206 = torch.ops.aten.convolution.default(relu__default_162, primals_758, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_166 = torch.ops.aten.add_.Tensor(primals_744, 1);  primals_744 = None
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_206, primals_747, primals_743, primals_745, primals_746, True, 0.1, 1e-05);  primals_743 = None
        getitem_380 = native_batch_norm_default_126[0]
        getitem_381 = native_batch_norm_default_126[1]
        getitem_382 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_206, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_163 = torch.ops.aten.relu_.default(getitem_380);  getitem_380 = None
        convolution_default_207 = torch.ops.aten.convolution.default(relu__default_163, primals_759, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_167 = torch.ops.aten.add_.Tensor(primals_749, 1);  primals_749 = None
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_207, primals_752, primals_748, primals_750, primals_751, True, 0.1, 1e-05);  primals_748 = None
        getitem_383 = native_batch_norm_default_127[0]
        getitem_384 = native_batch_norm_default_127[1]
        getitem_385 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_207, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_164 = torch.ops.aten.relu_.default(getitem_383);  getitem_383 = None
        convolution_default_208 = torch.ops.aten.convolution.default(relu__default_164, primals_760, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_168 = torch.ops.aten.add_.Tensor(primals_754, 1);  primals_754 = None
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_208, primals_757, primals_753, primals_755, primals_756, True, 0.1, 1e-05);  primals_753 = None
        getitem_386 = native_batch_norm_default_128[0]
        getitem_387 = native_batch_norm_default_128[1]
        getitem_388 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_208, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_40 = torch.ops.aten.mean.dim(getitem_386, [2, 3], True)
        convolution_default_209 = torch.ops.aten.convolution.default(mean_dim_40, primals_762, primals_761, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_761 = None
        relu__default_165 = torch.ops.aten.relu_.default(convolution_default_209);  convolution_default_209 = None
        convolution_default_210 = torch.ops.aten.convolution.default(relu__default_165, primals_764, primals_763, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_763 = None
        sigmoid_default_40 = torch.ops.aten.sigmoid.default(convolution_default_210);  convolution_default_210 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(getitem_386, sigmoid_default_40)
        add__tensor_169 = torch.ops.aten.add_.Tensor(mul_tensor_40, relu__default_162);  mul_tensor_40 = None
        relu__default_166 = torch.ops.aten.relu_.default(add__tensor_169);  add__tensor_169 = None
        convolution_default_211 = torch.ops.aten.convolution.default(relu__default_166, primals_802, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_170 = torch.ops.aten.add_.Tensor(primals_788, 1);  primals_788 = None
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_211, primals_791, primals_787, primals_789, primals_790, True, 0.1, 1e-05);  primals_787 = None
        getitem_389 = native_batch_norm_default_129[0]
        getitem_390 = native_batch_norm_default_129[1]
        getitem_391 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_211, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_167 = torch.ops.aten.relu_.default(getitem_389);  getitem_389 = None
        convolution_default_212 = torch.ops.aten.convolution.default(relu__default_167, primals_803, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_171 = torch.ops.aten.add_.Tensor(primals_793, 1);  primals_793 = None
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_212, primals_796, primals_792, primals_794, primals_795, True, 0.1, 1e-05);  primals_792 = None
        getitem_392 = native_batch_norm_default_130[0]
        getitem_393 = native_batch_norm_default_130[1]
        getitem_394 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_212, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_168 = torch.ops.aten.relu_.default(getitem_392);  getitem_392 = None
        convolution_default_213 = torch.ops.aten.convolution.default(relu__default_168, primals_804, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_172 = torch.ops.aten.add_.Tensor(primals_798, 1);  primals_798 = None
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_213, primals_801, primals_797, primals_799, primals_800, True, 0.1, 1e-05);  primals_797 = None
        getitem_395 = native_batch_norm_default_131[0]
        getitem_396 = native_batch_norm_default_131[1]
        getitem_397 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_213, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_41 = torch.ops.aten.mean.dim(getitem_395, [2, 3], True)
        convolution_default_214 = torch.ops.aten.convolution.default(mean_dim_41, primals_806, primals_805, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_805 = None
        relu__default_169 = torch.ops.aten.relu_.default(convolution_default_214);  convolution_default_214 = None
        convolution_default_215 = torch.ops.aten.convolution.default(relu__default_169, primals_808, primals_807, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_807 = None
        sigmoid_default_41 = torch.ops.aten.sigmoid.default(convolution_default_215);  convolution_default_215 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(getitem_395, sigmoid_default_41)
        add__tensor_173 = torch.ops.aten.add_.Tensor(mul_tensor_41, relu__default_166);  mul_tensor_41 = None
        relu__default_170 = torch.ops.aten.relu_.default(add__tensor_173);  add__tensor_173 = None
        convolution_default_216 = torch.ops.aten.convolution.default(relu__default_170, primals_824, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_174 = torch.ops.aten.add_.Tensor(primals_810, 1);  primals_810 = None
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_216, primals_813, primals_809, primals_811, primals_812, True, 0.1, 1e-05);  primals_809 = None
        getitem_398 = native_batch_norm_default_132[0]
        getitem_399 = native_batch_norm_default_132[1]
        getitem_400 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_216, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_171 = torch.ops.aten.relu_.default(getitem_398);  getitem_398 = None
        convolution_default_217 = torch.ops.aten.convolution.default(relu__default_171, primals_825, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_175 = torch.ops.aten.add_.Tensor(primals_815, 1);  primals_815 = None
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_217, primals_818, primals_814, primals_816, primals_817, True, 0.1, 1e-05);  primals_814 = None
        getitem_401 = native_batch_norm_default_133[0]
        getitem_402 = native_batch_norm_default_133[1]
        getitem_403 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_217, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_172 = torch.ops.aten.relu_.default(getitem_401);  getitem_401 = None
        convolution_default_218 = torch.ops.aten.convolution.default(relu__default_172, primals_826, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_176 = torch.ops.aten.add_.Tensor(primals_820, 1);  primals_820 = None
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_218, primals_823, primals_819, primals_821, primals_822, True, 0.1, 1e-05);  primals_819 = None
        getitem_404 = native_batch_norm_default_134[0]
        getitem_405 = native_batch_norm_default_134[1]
        getitem_406 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_218, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_42 = torch.ops.aten.mean.dim(getitem_404, [2, 3], True)
        convolution_default_219 = torch.ops.aten.convolution.default(mean_dim_42, primals_828, primals_827, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_827 = None
        relu__default_173 = torch.ops.aten.relu_.default(convolution_default_219);  convolution_default_219 = None
        convolution_default_220 = torch.ops.aten.convolution.default(relu__default_173, primals_830, primals_829, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_829 = None
        sigmoid_default_42 = torch.ops.aten.sigmoid.default(convolution_default_220);  convolution_default_220 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(getitem_404, sigmoid_default_42)
        add__tensor_177 = torch.ops.aten.add_.Tensor(mul_tensor_42, relu__default_170);  mul_tensor_42 = None
        relu__default_174 = torch.ops.aten.relu_.default(add__tensor_177);  add__tensor_177 = None
        convolution_default_221 = torch.ops.aten.convolution.default(relu__default_174, primals_846, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_178 = torch.ops.aten.add_.Tensor(primals_832, 1);  primals_832 = None
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_221, primals_835, primals_831, primals_833, primals_834, True, 0.1, 1e-05);  primals_831 = None
        getitem_407 = native_batch_norm_default_135[0]
        getitem_408 = native_batch_norm_default_135[1]
        getitem_409 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_221, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_175 = torch.ops.aten.relu_.default(getitem_407);  getitem_407 = None
        convolution_default_222 = torch.ops.aten.convolution.default(relu__default_175, primals_847, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_179 = torch.ops.aten.add_.Tensor(primals_837, 1);  primals_837 = None
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_222, primals_840, primals_836, primals_838, primals_839, True, 0.1, 1e-05);  primals_836 = None
        getitem_410 = native_batch_norm_default_136[0]
        getitem_411 = native_batch_norm_default_136[1]
        getitem_412 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_222, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_176 = torch.ops.aten.relu_.default(getitem_410);  getitem_410 = None
        convolution_default_223 = torch.ops.aten.convolution.default(relu__default_176, primals_848, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_180 = torch.ops.aten.add_.Tensor(primals_842, 1);  primals_842 = None
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_223, primals_845, primals_841, primals_843, primals_844, True, 0.1, 1e-05);  primals_841 = None
        getitem_413 = native_batch_norm_default_137[0]
        getitem_414 = native_batch_norm_default_137[1]
        getitem_415 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_223, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_43 = torch.ops.aten.mean.dim(getitem_413, [2, 3], True)
        convolution_default_224 = torch.ops.aten.convolution.default(mean_dim_43, primals_850, primals_849, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_849 = None
        relu__default_177 = torch.ops.aten.relu_.default(convolution_default_224);  convolution_default_224 = None
        convolution_default_225 = torch.ops.aten.convolution.default(relu__default_177, primals_852, primals_851, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_851 = None
        sigmoid_default_43 = torch.ops.aten.sigmoid.default(convolution_default_225);  convolution_default_225 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(getitem_413, sigmoid_default_43)
        add__tensor_181 = torch.ops.aten.add_.Tensor(mul_tensor_43, relu__default_174);  mul_tensor_43 = None
        relu__default_178 = torch.ops.aten.relu_.default(add__tensor_181);  add__tensor_181 = None
        convolution_default_226 = torch.ops.aten.convolution.default(relu__default_178, primals_868, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_182 = torch.ops.aten.add_.Tensor(primals_854, 1);  primals_854 = None
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_226, primals_857, primals_853, primals_855, primals_856, True, 0.1, 1e-05);  primals_853 = None
        getitem_416 = native_batch_norm_default_138[0]
        getitem_417 = native_batch_norm_default_138[1]
        getitem_418 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_226, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_179 = torch.ops.aten.relu_.default(getitem_416);  getitem_416 = None
        convolution_default_227 = torch.ops.aten.convolution.default(relu__default_179, primals_869, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_183 = torch.ops.aten.add_.Tensor(primals_859, 1);  primals_859 = None
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_227, primals_862, primals_858, primals_860, primals_861, True, 0.1, 1e-05);  primals_858 = None
        getitem_419 = native_batch_norm_default_139[0]
        getitem_420 = native_batch_norm_default_139[1]
        getitem_421 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_227, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_180 = torch.ops.aten.relu_.default(getitem_419);  getitem_419 = None
        convolution_default_228 = torch.ops.aten.convolution.default(relu__default_180, primals_870, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_184 = torch.ops.aten.add_.Tensor(primals_864, 1);  primals_864 = None
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_228, primals_867, primals_863, primals_865, primals_866, True, 0.1, 1e-05);  primals_863 = None
        getitem_422 = native_batch_norm_default_140[0]
        getitem_423 = native_batch_norm_default_140[1]
        getitem_424 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(convolution_default_228, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_44 = torch.ops.aten.mean.dim(getitem_422, [2, 3], True)
        convolution_default_229 = torch.ops.aten.convolution.default(mean_dim_44, primals_872, primals_871, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_871 = None
        relu__default_181 = torch.ops.aten.relu_.default(convolution_default_229);  convolution_default_229 = None
        convolution_default_230 = torch.ops.aten.convolution.default(relu__default_181, primals_874, primals_873, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_873 = None
        sigmoid_default_44 = torch.ops.aten.sigmoid.default(convolution_default_230);  convolution_default_230 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(getitem_422, sigmoid_default_44)
        add__tensor_185 = torch.ops.aten.add_.Tensor(mul_tensor_44, relu__default_178);  mul_tensor_44 = None
        relu__default_182 = torch.ops.aten.relu_.default(add__tensor_185);  add__tensor_185 = None
        convolution_default_231 = torch.ops.aten.convolution.default(relu__default_182, primals_890, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_186 = torch.ops.aten.add_.Tensor(primals_876, 1);  primals_876 = None
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_231, primals_879, primals_875, primals_877, primals_878, True, 0.1, 1e-05);  primals_875 = None
        getitem_425 = native_batch_norm_default_141[0]
        getitem_426 = native_batch_norm_default_141[1]
        getitem_427 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_231, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_183 = torch.ops.aten.relu_.default(getitem_425);  getitem_425 = None
        convolution_default_232 = torch.ops.aten.convolution.default(relu__default_183, primals_891, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_187 = torch.ops.aten.add_.Tensor(primals_881, 1);  primals_881 = None
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_232, primals_884, primals_880, primals_882, primals_883, True, 0.1, 1e-05);  primals_880 = None
        getitem_428 = native_batch_norm_default_142[0]
        getitem_429 = native_batch_norm_default_142[1]
        getitem_430 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_232, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_184 = torch.ops.aten.relu_.default(getitem_428);  getitem_428 = None
        convolution_default_233 = torch.ops.aten.convolution.default(relu__default_184, primals_892, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_188 = torch.ops.aten.add_.Tensor(primals_886, 1);  primals_886 = None
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_233, primals_889, primals_885, primals_887, primals_888, True, 0.1, 1e-05);  primals_885 = None
        getitem_431 = native_batch_norm_default_143[0]
        getitem_432 = native_batch_norm_default_143[1]
        getitem_433 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(convolution_default_233, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_45 = torch.ops.aten.mean.dim(getitem_431, [2, 3], True)
        convolution_default_234 = torch.ops.aten.convolution.default(mean_dim_45, primals_894, primals_893, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_893 = None
        relu__default_185 = torch.ops.aten.relu_.default(convolution_default_234);  convolution_default_234 = None
        convolution_default_235 = torch.ops.aten.convolution.default(relu__default_185, primals_896, primals_895, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_895 = None
        sigmoid_default_45 = torch.ops.aten.sigmoid.default(convolution_default_235);  convolution_default_235 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(getitem_431, sigmoid_default_45)
        add__tensor_189 = torch.ops.aten.add_.Tensor(mul_tensor_45, relu__default_182);  mul_tensor_45 = None
        relu__default_186 = torch.ops.aten.relu_.default(add__tensor_189);  add__tensor_189 = None
        convolution_default_236 = torch.ops.aten.convolution.default(relu__default_186, primals_912, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_190 = torch.ops.aten.add_.Tensor(primals_898, 1);  primals_898 = None
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_236, primals_901, primals_897, primals_899, primals_900, True, 0.1, 1e-05);  primals_897 = None
        getitem_434 = native_batch_norm_default_144[0]
        getitem_435 = native_batch_norm_default_144[1]
        getitem_436 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_236, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_187 = torch.ops.aten.relu_.default(getitem_434);  getitem_434 = None
        convolution_default_237 = torch.ops.aten.convolution.default(relu__default_187, primals_913, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_191 = torch.ops.aten.add_.Tensor(primals_903, 1);  primals_903 = None
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_237, primals_906, primals_902, primals_904, primals_905, True, 0.1, 1e-05);  primals_902 = None
        getitem_437 = native_batch_norm_default_145[0]
        getitem_438 = native_batch_norm_default_145[1]
        getitem_439 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_237, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_188 = torch.ops.aten.relu_.default(getitem_437);  getitem_437 = None
        convolution_default_238 = torch.ops.aten.convolution.default(relu__default_188, primals_914, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_192 = torch.ops.aten.add_.Tensor(primals_908, 1);  primals_908 = None
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_238, primals_911, primals_907, primals_909, primals_910, True, 0.1, 1e-05);  primals_907 = None
        getitem_440 = native_batch_norm_default_146[0]
        getitem_441 = native_batch_norm_default_146[1]
        getitem_442 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(convolution_default_238, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_46 = torch.ops.aten.mean.dim(getitem_440, [2, 3], True)
        convolution_default_239 = torch.ops.aten.convolution.default(mean_dim_46, primals_916, primals_915, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_915 = None
        relu__default_189 = torch.ops.aten.relu_.default(convolution_default_239);  convolution_default_239 = None
        convolution_default_240 = torch.ops.aten.convolution.default(relu__default_189, primals_918, primals_917, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_917 = None
        sigmoid_default_46 = torch.ops.aten.sigmoid.default(convolution_default_240);  convolution_default_240 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(getitem_440, sigmoid_default_46)
        add__tensor_193 = torch.ops.aten.add_.Tensor(mul_tensor_46, relu__default_186);  mul_tensor_46 = None
        relu__default_190 = torch.ops.aten.relu_.default(add__tensor_193);  add__tensor_193 = None
        convolution_default_241 = torch.ops.aten.convolution.default(relu__default_190, primals_1088, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_194 = torch.ops.aten.add_.Tensor(primals_1074, 1);  primals_1074 = None
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_241, primals_1077, primals_1073, primals_1075, primals_1076, True, 0.1, 1e-05);  primals_1073 = None
        getitem_443 = native_batch_norm_default_147[0]
        getitem_444 = native_batch_norm_default_147[1]
        getitem_445 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_241, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_191 = torch.ops.aten.relu_.default(getitem_443);  getitem_443 = None
        convolution_default_242 = torch.ops.aten.convolution.default(relu__default_191, primals_1089, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_195 = torch.ops.aten.add_.Tensor(primals_1079, 1);  primals_1079 = None
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_242, primals_1082, primals_1078, primals_1080, primals_1081, True, 0.1, 1e-05);  primals_1078 = None
        getitem_446 = native_batch_norm_default_148[0]
        getitem_447 = native_batch_norm_default_148[1]
        getitem_448 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_242, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_192 = torch.ops.aten.relu_.default(getitem_446);  getitem_446 = None
        convolution_default_243 = torch.ops.aten.convolution.default(relu__default_192, primals_1090, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_196 = torch.ops.aten.add_.Tensor(primals_1084, 1);  primals_1084 = None
        native_batch_norm_default_149 = torch.ops.aten.native_batch_norm.default(convolution_default_243, primals_1087, primals_1083, primals_1085, primals_1086, True, 0.1, 1e-05);  primals_1083 = None
        getitem_449 = native_batch_norm_default_149[0]
        getitem_450 = native_batch_norm_default_149[1]
        getitem_451 = native_batch_norm_default_149[2];  native_batch_norm_default_149 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(convolution_default_243, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_47 = torch.ops.aten.mean.dim(getitem_449, [2, 3], True)
        convolution_default_244 = torch.ops.aten.convolution.default(mean_dim_47, primals_1098, primals_1097, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1097 = None
        relu__default_193 = torch.ops.aten.relu_.default(convolution_default_244);  convolution_default_244 = None
        convolution_default_245 = torch.ops.aten.convolution.default(relu__default_193, primals_1100, primals_1099, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1099 = None
        sigmoid_default_47 = torch.ops.aten.sigmoid.default(convolution_default_245);  convolution_default_245 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(getitem_449, sigmoid_default_47)
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(relu__default_190, [2, 2], [2, 2], [0, 0], True, False)
        convolution_default_246 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_1091, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_197 = torch.ops.aten.add_.Tensor(primals_1093, 1);  primals_1093 = None
        native_batch_norm_default_150 = torch.ops.aten.native_batch_norm.default(convolution_default_246, primals_1096, primals_1092, primals_1094, primals_1095, True, 0.1, 1e-05);  primals_1092 = None
        getitem_452 = native_batch_norm_default_150[0]
        getitem_453 = native_batch_norm_default_150[1]
        getitem_454 = native_batch_norm_default_150[2];  native_batch_norm_default_150 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(convolution_default_246, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add__tensor_198 = torch.ops.aten.add_.Tensor(mul_tensor_47, getitem_452);  mul_tensor_47 = getitem_452 = None
        relu__default_194 = torch.ops.aten.relu_.default(add__tensor_198);  add__tensor_198 = None
        convolution_default_247 = torch.ops.aten.convolution.default(relu__default_194, primals_1116, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_199 = torch.ops.aten.add_.Tensor(primals_1102, 1);  primals_1102 = None
        native_batch_norm_default_151 = torch.ops.aten.native_batch_norm.default(convolution_default_247, primals_1105, primals_1101, primals_1103, primals_1104, True, 0.1, 1e-05);  primals_1101 = None
        getitem_455 = native_batch_norm_default_151[0]
        getitem_456 = native_batch_norm_default_151[1]
        getitem_457 = native_batch_norm_default_151[2];  native_batch_norm_default_151 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(convolution_default_247, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_195 = torch.ops.aten.relu_.default(getitem_455);  getitem_455 = None
        convolution_default_248 = torch.ops.aten.convolution.default(relu__default_195, primals_1117, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_200 = torch.ops.aten.add_.Tensor(primals_1107, 1);  primals_1107 = None
        native_batch_norm_default_152 = torch.ops.aten.native_batch_norm.default(convolution_default_248, primals_1110, primals_1106, primals_1108, primals_1109, True, 0.1, 1e-05);  primals_1106 = None
        getitem_458 = native_batch_norm_default_152[0]
        getitem_459 = native_batch_norm_default_152[1]
        getitem_460 = native_batch_norm_default_152[2];  native_batch_norm_default_152 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(convolution_default_248, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_196 = torch.ops.aten.relu_.default(getitem_458);  getitem_458 = None
        convolution_default_249 = torch.ops.aten.convolution.default(relu__default_196, primals_1118, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_201 = torch.ops.aten.add_.Tensor(primals_1112, 1);  primals_1112 = None
        native_batch_norm_default_153 = torch.ops.aten.native_batch_norm.default(convolution_default_249, primals_1115, primals_1111, primals_1113, primals_1114, True, 0.1, 1e-05);  primals_1111 = None
        getitem_461 = native_batch_norm_default_153[0]
        getitem_462 = native_batch_norm_default_153[1]
        getitem_463 = native_batch_norm_default_153[2];  native_batch_norm_default_153 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(convolution_default_249, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_48 = torch.ops.aten.mean.dim(getitem_461, [2, 3], True)
        convolution_default_250 = torch.ops.aten.convolution.default(mean_dim_48, primals_1120, primals_1119, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1119 = None
        relu__default_197 = torch.ops.aten.relu_.default(convolution_default_250);  convolution_default_250 = None
        convolution_default_251 = torch.ops.aten.convolution.default(relu__default_197, primals_1122, primals_1121, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1121 = None
        sigmoid_default_48 = torch.ops.aten.sigmoid.default(convolution_default_251);  convolution_default_251 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(getitem_461, sigmoid_default_48)
        add__tensor_202 = torch.ops.aten.add_.Tensor(mul_tensor_48, relu__default_194);  mul_tensor_48 = None
        relu__default_198 = torch.ops.aten.relu_.default(add__tensor_202);  add__tensor_202 = None
        convolution_default_252 = torch.ops.aten.convolution.default(relu__default_198, primals_1138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_203 = torch.ops.aten.add_.Tensor(primals_1124, 1);  primals_1124 = None
        native_batch_norm_default_154 = torch.ops.aten.native_batch_norm.default(convolution_default_252, primals_1127, primals_1123, primals_1125, primals_1126, True, 0.1, 1e-05);  primals_1123 = None
        getitem_464 = native_batch_norm_default_154[0]
        getitem_465 = native_batch_norm_default_154[1]
        getitem_466 = native_batch_norm_default_154[2];  native_batch_norm_default_154 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(convolution_default_252, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_199 = torch.ops.aten.relu_.default(getitem_464);  getitem_464 = None
        convolution_default_253 = torch.ops.aten.convolution.default(relu__default_199, primals_1139, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_204 = torch.ops.aten.add_.Tensor(primals_1129, 1);  primals_1129 = None
        native_batch_norm_default_155 = torch.ops.aten.native_batch_norm.default(convolution_default_253, primals_1132, primals_1128, primals_1130, primals_1131, True, 0.1, 1e-05);  primals_1128 = None
        getitem_467 = native_batch_norm_default_155[0]
        getitem_468 = native_batch_norm_default_155[1]
        getitem_469 = native_batch_norm_default_155[2];  native_batch_norm_default_155 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(convolution_default_253, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_200 = torch.ops.aten.relu_.default(getitem_467);  getitem_467 = None
        convolution_default_254 = torch.ops.aten.convolution.default(relu__default_200, primals_1140, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_205 = torch.ops.aten.add_.Tensor(primals_1134, 1);  primals_1134 = None
        native_batch_norm_default_156 = torch.ops.aten.native_batch_norm.default(convolution_default_254, primals_1137, primals_1133, primals_1135, primals_1136, True, 0.1, 1e-05);  primals_1133 = None
        getitem_470 = native_batch_norm_default_156[0]
        getitem_471 = native_batch_norm_default_156[1]
        getitem_472 = native_batch_norm_default_156[2];  native_batch_norm_default_156 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(convolution_default_254, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_49 = torch.ops.aten.mean.dim(getitem_470, [2, 3], True)
        convolution_default_255 = torch.ops.aten.convolution.default(mean_dim_49, primals_1142, primals_1141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1141 = None
        relu__default_201 = torch.ops.aten.relu_.default(convolution_default_255);  convolution_default_255 = None
        convolution_default_256 = torch.ops.aten.convolution.default(relu__default_201, primals_1144, primals_1143, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1143 = None
        sigmoid_default_49 = torch.ops.aten.sigmoid.default(convolution_default_256);  convolution_default_256 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(getitem_470, sigmoid_default_49)
        add__tensor_206 = torch.ops.aten.add_.Tensor(mul_tensor_49, relu__default_198);  mul_tensor_49 = None
        relu__default_202 = torch.ops.aten.relu_.default(add__tensor_206);  add__tensor_206 = None
        mean_dim_50 = torch.ops.aten.mean.dim(relu__default_202, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_50, [64, 2048]);  mean_dim_50 = None
        t_default = torch.ops.aten.t.default(primals_20);  primals_20 = None
        addmm_default = torch.ops.aten.addmm.default(primals_19, view_default, t_default);  primals_19 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [64, 2048, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [64, 2048, 10, 10]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 100);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_202, torch.float32);  relu__default_202 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_157, to_dtype);  le_scalar = new_zeros_default_157 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(to_dtype_2, getitem_470);  getitem_470 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_2, sigmoid_default_49)
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_50, [2, 3], True);  mul_tensor_50 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_49, torch.float32);  sigmoid_default_49 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar);  to_dtype_4 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_52);  mul_tensor_52 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_53, torch.float32);  mul_tensor_53 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_5, relu__default_201, primals_1144, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = primals_1144 = None
        getitem_473 = convolution_backward_default[0]
        getitem_474 = convolution_backward_default[1]
        getitem_475 = convolution_backward_default[2];  convolution_backward_default = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_473, torch.float32);  getitem_473 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_201, torch.float32);  relu__default_201 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_158, to_dtype_6);  le_scalar_1 = new_zeros_default_158 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_49, primals_1142, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_49 = primals_1142 = None
        getitem_476 = convolution_backward_default_1[0]
        getitem_477 = convolution_backward_default_1[1]
        getitem_478 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_476, [64, 2048, 10, 10]);  getitem_476 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 100);  expand_default_1 = None
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_51, div_scalar_1);  mul_tensor_51 = div_scalar_1 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(add_tensor, convolution_default_254, primals_1137, primals_1135, primals_1136, getitem_471, getitem_472, True, 1e-05, [True, True, True]);  add_tensor = convolution_default_254 = primals_1137 = primals_1135 = primals_1136 = getitem_471 = getitem_472 = None
        getitem_479 = native_batch_norm_backward_default[0]
        getitem_480 = native_batch_norm_backward_default[1]
        getitem_481 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_479, relu__default_200, primals_1140, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_479 = primals_1140 = None
        getitem_482 = convolution_backward_default_2[0]
        getitem_483 = convolution_backward_default_2[1]
        getitem_484 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_482, torch.float32);  getitem_482 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_200, torch.float32);  relu__default_200 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_159, to_dtype_9);  le_scalar_2 = new_zeros_default_159 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_253, primals_1132, primals_1130, primals_1131, getitem_468, getitem_469, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_253 = primals_1132 = primals_1130 = primals_1131 = getitem_468 = getitem_469 = None
        getitem_485 = native_batch_norm_backward_default_1[0]
        getitem_486 = native_batch_norm_backward_default_1[1]
        getitem_487 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_485, relu__default_199, primals_1139, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_485 = primals_1139 = None
        getitem_488 = convolution_backward_default_3[0]
        getitem_489 = convolution_backward_default_3[1]
        getitem_490 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_488, torch.float32);  getitem_488 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_199, torch.float32);  relu__default_199 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_160, to_dtype_12);  le_scalar_3 = new_zeros_default_160 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_252, primals_1127, primals_1125, primals_1126, getitem_465, getitem_466, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_252 = primals_1127 = primals_1125 = primals_1126 = getitem_465 = getitem_466 = None
        getitem_491 = native_batch_norm_backward_default_2[0]
        getitem_492 = native_batch_norm_backward_default_2[1]
        getitem_493 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_491, relu__default_198, primals_1138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_491 = primals_1138 = None
        getitem_494 = convolution_backward_default_4[0]
        getitem_495 = convolution_backward_default_4[1]
        getitem_496 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_494);  to_dtype_2 = getitem_494 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_198, torch.float32);  relu__default_198 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_161, to_dtype_15);  le_scalar_4 = new_zeros_default_161 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_17, getitem_461);  getitem_461 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_17, sigmoid_default_48)
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_54, [2, 3], True);  mul_tensor_54 = None
        to_dtype_18 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_19 = torch.ops.aten.to.dtype(sigmoid_default_48, torch.float32);  sigmoid_default_48 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_19, 1)
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_1);  to_dtype_19 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_56);  mul_tensor_56 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_18, conj_physical_default_1);  to_dtype_18 = conj_physical_default_1 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_57, torch.float32);  mul_tensor_57 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(to_dtype_20, relu__default_197, primals_1122, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = primals_1122 = None
        getitem_497 = convolution_backward_default_5[0]
        getitem_498 = convolution_backward_default_5[1]
        getitem_499 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_497, torch.float32);  getitem_497 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_197, torch.float32);  relu__default_197 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_162, to_dtype_21);  le_scalar_5 = new_zeros_default_162 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(to_dtype_23, mean_dim_48, primals_1120, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_23 = mean_dim_48 = primals_1120 = None
        getitem_500 = convolution_backward_default_6[0]
        getitem_501 = convolution_backward_default_6[1]
        getitem_502 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_500, [64, 2048, 10, 10]);  getitem_500 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 100);  expand_default_2 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_55, div_scalar_2);  mul_tensor_55 = div_scalar_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_2, convolution_default_249, primals_1115, primals_1113, primals_1114, getitem_462, getitem_463, True, 1e-05, [True, True, True]);  add_tensor_2 = convolution_default_249 = primals_1115 = primals_1113 = primals_1114 = getitem_462 = getitem_463 = None
        getitem_503 = native_batch_norm_backward_default_3[0]
        getitem_504 = native_batch_norm_backward_default_3[1]
        getitem_505 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_503, relu__default_196, primals_1118, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_503 = primals_1118 = None
        getitem_506 = convolution_backward_default_7[0]
        getitem_507 = convolution_backward_default_7[1]
        getitem_508 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_506, torch.float32);  getitem_506 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_196, torch.float32);  relu__default_196 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_163, to_dtype_24);  le_scalar_6 = new_zeros_default_163 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_248, primals_1110, primals_1108, primals_1109, getitem_459, getitem_460, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_248 = primals_1110 = primals_1108 = primals_1109 = getitem_459 = getitem_460 = None
        getitem_509 = native_batch_norm_backward_default_4[0]
        getitem_510 = native_batch_norm_backward_default_4[1]
        getitem_511 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_509, relu__default_195, primals_1117, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_509 = primals_1117 = None
        getitem_512 = convolution_backward_default_8[0]
        getitem_513 = convolution_backward_default_8[1]
        getitem_514 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_512, torch.float32);  getitem_512 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_195, torch.float32);  relu__default_195 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_164, to_dtype_27);  le_scalar_7 = new_zeros_default_164 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_247, primals_1105, primals_1103, primals_1104, getitem_456, getitem_457, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_247 = primals_1105 = primals_1103 = primals_1104 = getitem_456 = getitem_457 = None
        getitem_515 = native_batch_norm_backward_default_5[0]
        getitem_516 = native_batch_norm_backward_default_5[1]
        getitem_517 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_515, relu__default_194, primals_1116, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_515 = primals_1116 = None
        getitem_518 = convolution_backward_default_9[0]
        getitem_519 = convolution_backward_default_9[1]
        getitem_520 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(to_dtype_17, getitem_518);  to_dtype_17 = getitem_518 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_194, torch.float32);  relu__default_194 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_165, to_dtype_30);  le_scalar_8 = new_zeros_default_165 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_246, primals_1096, primals_1094, primals_1095, getitem_453, getitem_454, True, 1e-05, [True, True, True]);  convolution_default_246 = primals_1096 = primals_1094 = primals_1095 = getitem_453 = getitem_454 = None
        getitem_521 = native_batch_norm_backward_default_6[0]
        getitem_522 = native_batch_norm_backward_default_6[1]
        getitem_523 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_521, avg_pool2d_default_2, primals_1091, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_521 = avg_pool2d_default_2 = primals_1091 = None
        getitem_524 = convolution_backward_default_10[0]
        getitem_525 = convolution_backward_default_10[1]
        getitem_526 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_524, relu__default_190, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_524 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_32, getitem_449);  getitem_449 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_32, sigmoid_default_47);  to_dtype_32 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_58, [2, 3], True);  mul_tensor_58 = None
        to_dtype_33 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_34 = torch.ops.aten.to.dtype(sigmoid_default_47, torch.float32);  sigmoid_default_47 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(to_dtype_34, 1)
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_2);  to_dtype_34 = rsub_scalar_2 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_60);  mul_tensor_60 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_33, conj_physical_default_2);  to_dtype_33 = conj_physical_default_2 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_61, torch.float32);  mul_tensor_61 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(to_dtype_35, relu__default_193, primals_1100, [2048], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = primals_1100 = None
        getitem_527 = convolution_backward_default_11[0]
        getitem_528 = convolution_backward_default_11[1]
        getitem_529 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_527, torch.float32);  getitem_527 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_193, torch.float32);  relu__default_193 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_166, to_dtype_36);  le_scalar_9 = new_zeros_default_166 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_38, mean_dim_47, primals_1098, [128], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_38 = mean_dim_47 = primals_1098 = None
        getitem_530 = convolution_backward_default_12[0]
        getitem_531 = convolution_backward_default_12[1]
        getitem_532 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_530, [64, 2048, 10, 10]);  getitem_530 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 100);  expand_default_3 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_59, div_scalar_3);  mul_tensor_59 = div_scalar_3 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_4, convolution_default_243, primals_1087, primals_1085, primals_1086, getitem_450, getitem_451, True, 1e-05, [True, True, True]);  add_tensor_4 = convolution_default_243 = primals_1087 = primals_1085 = primals_1086 = getitem_450 = getitem_451 = None
        getitem_533 = native_batch_norm_backward_default_7[0]
        getitem_534 = native_batch_norm_backward_default_7[1]
        getitem_535 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_533, relu__default_192, primals_1090, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_533 = primals_1090 = None
        getitem_536 = convolution_backward_default_13[0]
        getitem_537 = convolution_backward_default_13[1]
        getitem_538 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_536, torch.float32);  getitem_536 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_192, torch.float32);  relu__default_192 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_167, to_dtype_39);  le_scalar_10 = new_zeros_default_167 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_242, primals_1082, primals_1080, primals_1081, getitem_447, getitem_448, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_242 = primals_1082 = primals_1080 = primals_1081 = getitem_447 = getitem_448 = None
        getitem_539 = native_batch_norm_backward_default_8[0]
        getitem_540 = native_batch_norm_backward_default_8[1]
        getitem_541 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_539, relu__default_191, primals_1089, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_539 = primals_1089 = None
        getitem_542 = convolution_backward_default_14[0]
        getitem_543 = convolution_backward_default_14[1]
        getitem_544 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_542, torch.float32);  getitem_542 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_191, torch.float32);  relu__default_191 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_168, to_dtype_42);  le_scalar_11 = new_zeros_default_168 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_241, primals_1077, primals_1075, primals_1076, getitem_444, getitem_445, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_241 = primals_1077 = primals_1075 = primals_1076 = getitem_444 = getitem_445 = None
        getitem_545 = native_batch_norm_backward_default_9[0]
        getitem_546 = native_batch_norm_backward_default_9[1]
        getitem_547 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_545, relu__default_190, primals_1088, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_545 = primals_1088 = None
        getitem_548 = convolution_backward_default_15[0]
        getitem_549 = convolution_backward_default_15[1]
        getitem_550 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default, getitem_548);  avg_pool2d_backward_default = getitem_548 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_190, torch.float32);  relu__default_190 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_169, to_dtype_45);  le_scalar_12 = new_zeros_default_169 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_47, getitem_440);  getitem_440 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_47, sigmoid_default_46)
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_62, [2, 3], True);  mul_tensor_62 = None
        to_dtype_48 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_49 = torch.ops.aten.to.dtype(sigmoid_default_46, torch.float32);  sigmoid_default_46 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(to_dtype_49, 1)
        mul_tensor_64 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_3);  to_dtype_49 = rsub_scalar_3 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_64);  mul_tensor_64 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_48, conj_physical_default_3);  to_dtype_48 = conj_physical_default_3 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_65, torch.float32);  mul_tensor_65 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(to_dtype_50, relu__default_189, primals_918, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_50 = primals_918 = None
        getitem_551 = convolution_backward_default_16[0]
        getitem_552 = convolution_backward_default_16[1]
        getitem_553 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_551, torch.float32);  getitem_551 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_189, torch.float32);  relu__default_189 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_170, to_dtype_51);  le_scalar_13 = new_zeros_default_170 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_53, mean_dim_46, primals_916, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = mean_dim_46 = primals_916 = None
        getitem_554 = convolution_backward_default_17[0]
        getitem_555 = convolution_backward_default_17[1]
        getitem_556 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_554, [64, 1024, 20, 20]);  getitem_554 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 400);  expand_default_4 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_63, div_scalar_4);  mul_tensor_63 = div_scalar_4 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_6, convolution_default_238, primals_911, primals_909, primals_910, getitem_441, getitem_442, True, 1e-05, [True, True, True]);  add_tensor_6 = convolution_default_238 = primals_911 = primals_909 = primals_910 = getitem_441 = getitem_442 = None
        getitem_557 = native_batch_norm_backward_default_10[0]
        getitem_558 = native_batch_norm_backward_default_10[1]
        getitem_559 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_557, relu__default_188, primals_914, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_557 = primals_914 = None
        getitem_560 = convolution_backward_default_18[0]
        getitem_561 = convolution_backward_default_18[1]
        getitem_562 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_560, torch.float32);  getitem_560 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_188, torch.float32);  relu__default_188 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_171, to_dtype_54);  le_scalar_14 = new_zeros_default_171 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_237, primals_906, primals_904, primals_905, getitem_438, getitem_439, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_237 = primals_906 = primals_904 = primals_905 = getitem_438 = getitem_439 = None
        getitem_563 = native_batch_norm_backward_default_11[0]
        getitem_564 = native_batch_norm_backward_default_11[1]
        getitem_565 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_563, relu__default_187, primals_913, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_563 = primals_913 = None
        getitem_566 = convolution_backward_default_19[0]
        getitem_567 = convolution_backward_default_19[1]
        getitem_568 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_566, torch.float32);  getitem_566 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_187, torch.float32);  relu__default_187 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_172, to_dtype_57);  le_scalar_15 = new_zeros_default_172 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_236, primals_901, primals_899, primals_900, getitem_435, getitem_436, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_236 = primals_901 = primals_899 = primals_900 = getitem_435 = getitem_436 = None
        getitem_569 = native_batch_norm_backward_default_12[0]
        getitem_570 = native_batch_norm_backward_default_12[1]
        getitem_571 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_569, relu__default_186, primals_912, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_569 = primals_912 = None
        getitem_572 = convolution_backward_default_20[0]
        getitem_573 = convolution_backward_default_20[1]
        getitem_574 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(to_dtype_47, getitem_572);  to_dtype_47 = getitem_572 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_186, torch.float32);  relu__default_186 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_173, to_dtype_60);  le_scalar_16 = new_zeros_default_173 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_62, getitem_431);  getitem_431 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(to_dtype_62, sigmoid_default_45)
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_66, [2, 3], True);  mul_tensor_66 = None
        to_dtype_63 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_45, torch.float32);  sigmoid_default_45 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_4);  to_dtype_64 = rsub_scalar_4 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_68);  mul_tensor_68 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_4);  to_dtype_63 = conj_physical_default_4 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_69, torch.float32);  mul_tensor_69 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(to_dtype_65, relu__default_185, primals_896, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = primals_896 = None
        getitem_575 = convolution_backward_default_21[0]
        getitem_576 = convolution_backward_default_21[1]
        getitem_577 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_575, torch.float32);  getitem_575 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_185, torch.float32);  relu__default_185 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_174, to_dtype_66);  le_scalar_17 = new_zeros_default_174 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_68, mean_dim_45, primals_894, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = mean_dim_45 = primals_894 = None
        getitem_578 = convolution_backward_default_22[0]
        getitem_579 = convolution_backward_default_22[1]
        getitem_580 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_578, [64, 1024, 20, 20]);  getitem_578 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 400);  expand_default_5 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_67, div_scalar_5);  mul_tensor_67 = div_scalar_5 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_8, convolution_default_233, primals_889, primals_887, primals_888, getitem_432, getitem_433, True, 1e-05, [True, True, True]);  add_tensor_8 = convolution_default_233 = primals_889 = primals_887 = primals_888 = getitem_432 = getitem_433 = None
        getitem_581 = native_batch_norm_backward_default_13[0]
        getitem_582 = native_batch_norm_backward_default_13[1]
        getitem_583 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_581, relu__default_184, primals_892, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_581 = primals_892 = None
        getitem_584 = convolution_backward_default_23[0]
        getitem_585 = convolution_backward_default_23[1]
        getitem_586 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_584, torch.float32);  getitem_584 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_184, torch.float32);  relu__default_184 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_175, to_dtype_69);  le_scalar_18 = new_zeros_default_175 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_232, primals_884, primals_882, primals_883, getitem_429, getitem_430, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_232 = primals_884 = primals_882 = primals_883 = getitem_429 = getitem_430 = None
        getitem_587 = native_batch_norm_backward_default_14[0]
        getitem_588 = native_batch_norm_backward_default_14[1]
        getitem_589 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_587, relu__default_183, primals_891, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_587 = primals_891 = None
        getitem_590 = convolution_backward_default_24[0]
        getitem_591 = convolution_backward_default_24[1]
        getitem_592 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_590, torch.float32);  getitem_590 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_183, torch.float32);  relu__default_183 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_176, to_dtype_72);  le_scalar_19 = new_zeros_default_176 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_231, primals_879, primals_877, primals_878, getitem_426, getitem_427, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_231 = primals_879 = primals_877 = primals_878 = getitem_426 = getitem_427 = None
        getitem_593 = native_batch_norm_backward_default_15[0]
        getitem_594 = native_batch_norm_backward_default_15[1]
        getitem_595 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_593, relu__default_182, primals_890, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_593 = primals_890 = None
        getitem_596 = convolution_backward_default_25[0]
        getitem_597 = convolution_backward_default_25[1]
        getitem_598 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_596);  to_dtype_62 = getitem_596 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_9, torch.float32);  add_tensor_9 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_182, torch.float32);  relu__default_182 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_177, to_dtype_75);  le_scalar_20 = new_zeros_default_177 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_77, getitem_422);  getitem_422 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(to_dtype_77, sigmoid_default_44)
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_70, [2, 3], True);  mul_tensor_70 = None
        to_dtype_78 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_79 = torch.ops.aten.to.dtype(sigmoid_default_44, torch.float32);  sigmoid_default_44 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_79, 1)
        mul_tensor_72 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_5);  to_dtype_79 = rsub_scalar_5 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_72);  mul_tensor_72 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_78, conj_physical_default_5);  to_dtype_78 = conj_physical_default_5 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_73, torch.float32);  mul_tensor_73 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(to_dtype_80, relu__default_181, primals_874, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = primals_874 = None
        getitem_599 = convolution_backward_default_26[0]
        getitem_600 = convolution_backward_default_26[1]
        getitem_601 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_599, torch.float32);  getitem_599 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_181, torch.float32);  relu__default_181 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_178, to_dtype_81);  le_scalar_21 = new_zeros_default_178 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_83, mean_dim_44, primals_872, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_83 = mean_dim_44 = primals_872 = None
        getitem_602 = convolution_backward_default_27[0]
        getitem_603 = convolution_backward_default_27[1]
        getitem_604 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_602, [64, 1024, 20, 20]);  getitem_602 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 400);  expand_default_6 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_71, div_scalar_6);  mul_tensor_71 = div_scalar_6 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_10, convolution_default_228, primals_867, primals_865, primals_866, getitem_423, getitem_424, True, 1e-05, [True, True, True]);  add_tensor_10 = convolution_default_228 = primals_867 = primals_865 = primals_866 = getitem_423 = getitem_424 = None
        getitem_605 = native_batch_norm_backward_default_16[0]
        getitem_606 = native_batch_norm_backward_default_16[1]
        getitem_607 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_605, relu__default_180, primals_870, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_605 = primals_870 = None
        getitem_608 = convolution_backward_default_28[0]
        getitem_609 = convolution_backward_default_28[1]
        getitem_610 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_608, torch.float32);  getitem_608 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_180, torch.float32);  relu__default_180 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_179, to_dtype_84);  le_scalar_22 = new_zeros_default_179 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_227, primals_862, primals_860, primals_861, getitem_420, getitem_421, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_227 = primals_862 = primals_860 = primals_861 = getitem_420 = getitem_421 = None
        getitem_611 = native_batch_norm_backward_default_17[0]
        getitem_612 = native_batch_norm_backward_default_17[1]
        getitem_613 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_611, relu__default_179, primals_869, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_611 = primals_869 = None
        getitem_614 = convolution_backward_default_29[0]
        getitem_615 = convolution_backward_default_29[1]
        getitem_616 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_614, torch.float32);  getitem_614 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_179, torch.float32);  relu__default_179 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_180, to_dtype_87);  le_scalar_23 = new_zeros_default_180 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_226, primals_857, primals_855, primals_856, getitem_417, getitem_418, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_226 = primals_857 = primals_855 = primals_856 = getitem_417 = getitem_418 = None
        getitem_617 = native_batch_norm_backward_default_18[0]
        getitem_618 = native_batch_norm_backward_default_18[1]
        getitem_619 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_617, relu__default_178, primals_868, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_617 = primals_868 = None
        getitem_620 = convolution_backward_default_30[0]
        getitem_621 = convolution_backward_default_30[1]
        getitem_622 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(to_dtype_77, getitem_620);  to_dtype_77 = getitem_620 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_11, torch.float32);  add_tensor_11 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_178, torch.float32);  relu__default_178 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_181, to_dtype_90);  le_scalar_24 = new_zeros_default_181 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_92, getitem_413);  getitem_413 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_92, sigmoid_default_43)
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_74, [2, 3], True);  mul_tensor_74 = None
        to_dtype_93 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_94 = torch.ops.aten.to.dtype(sigmoid_default_43, torch.float32);  sigmoid_default_43 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(to_dtype_94, 1)
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_6);  to_dtype_94 = rsub_scalar_6 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_76);  mul_tensor_76 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_93, conj_physical_default_6);  to_dtype_93 = conj_physical_default_6 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_77, torch.float32);  mul_tensor_77 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(to_dtype_95, relu__default_177, primals_852, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_95 = primals_852 = None
        getitem_623 = convolution_backward_default_31[0]
        getitem_624 = convolution_backward_default_31[1]
        getitem_625 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_623, torch.float32);  getitem_623 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_177, torch.float32);  relu__default_177 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_182, to_dtype_96);  le_scalar_25 = new_zeros_default_182 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(to_dtype_98, mean_dim_43, primals_850, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_98 = mean_dim_43 = primals_850 = None
        getitem_626 = convolution_backward_default_32[0]
        getitem_627 = convolution_backward_default_32[1]
        getitem_628 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_626, [64, 1024, 20, 20]);  getitem_626 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 400);  expand_default_7 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_75, div_scalar_7);  mul_tensor_75 = div_scalar_7 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_12, convolution_default_223, primals_845, primals_843, primals_844, getitem_414, getitem_415, True, 1e-05, [True, True, True]);  add_tensor_12 = convolution_default_223 = primals_845 = primals_843 = primals_844 = getitem_414 = getitem_415 = None
        getitem_629 = native_batch_norm_backward_default_19[0]
        getitem_630 = native_batch_norm_backward_default_19[1]
        getitem_631 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_629, relu__default_176, primals_848, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_629 = primals_848 = None
        getitem_632 = convolution_backward_default_33[0]
        getitem_633 = convolution_backward_default_33[1]
        getitem_634 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_632, torch.float32);  getitem_632 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_176, torch.float32);  relu__default_176 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_183, to_dtype_99);  le_scalar_26 = new_zeros_default_183 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_222, primals_840, primals_838, primals_839, getitem_411, getitem_412, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_222 = primals_840 = primals_838 = primals_839 = getitem_411 = getitem_412 = None
        getitem_635 = native_batch_norm_backward_default_20[0]
        getitem_636 = native_batch_norm_backward_default_20[1]
        getitem_637 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_635, relu__default_175, primals_847, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_635 = primals_847 = None
        getitem_638 = convolution_backward_default_34[0]
        getitem_639 = convolution_backward_default_34[1]
        getitem_640 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_638, torch.float32);  getitem_638 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_175, torch.float32);  relu__default_175 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_184, to_dtype_102);  le_scalar_27 = new_zeros_default_184 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_221, primals_835, primals_833, primals_834, getitem_408, getitem_409, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_221 = primals_835 = primals_833 = primals_834 = getitem_408 = getitem_409 = None
        getitem_641 = native_batch_norm_backward_default_21[0]
        getitem_642 = native_batch_norm_backward_default_21[1]
        getitem_643 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_641, relu__default_174, primals_846, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_641 = primals_846 = None
        getitem_644 = convolution_backward_default_35[0]
        getitem_645 = convolution_backward_default_35[1]
        getitem_646 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(to_dtype_92, getitem_644);  to_dtype_92 = getitem_644 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_13, torch.float32);  add_tensor_13 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_174, torch.float32);  relu__default_174 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_185, to_dtype_105);  le_scalar_28 = new_zeros_default_185 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(to_dtype_107, getitem_404);  getitem_404 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(to_dtype_107, sigmoid_default_42)
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_78, [2, 3], True);  mul_tensor_78 = None
        to_dtype_108 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_109 = torch.ops.aten.to.dtype(sigmoid_default_42, torch.float32);  sigmoid_default_42 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(to_dtype_109, 1)
        mul_tensor_80 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_7);  to_dtype_109 = rsub_scalar_7 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_80);  mul_tensor_80 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_108, conj_physical_default_7);  to_dtype_108 = conj_physical_default_7 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_81, torch.float32);  mul_tensor_81 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(to_dtype_110, relu__default_173, primals_830, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_110 = primals_830 = None
        getitem_647 = convolution_backward_default_36[0]
        getitem_648 = convolution_backward_default_36[1]
        getitem_649 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_647, torch.float32);  getitem_647 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_173, torch.float32);  relu__default_173 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_186, to_dtype_111);  le_scalar_29 = new_zeros_default_186 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_113, mean_dim_42, primals_828, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = mean_dim_42 = primals_828 = None
        getitem_650 = convolution_backward_default_37[0]
        getitem_651 = convolution_backward_default_37[1]
        getitem_652 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_650, [64, 1024, 20, 20]);  getitem_650 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 400);  expand_default_8 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_79, div_scalar_8);  mul_tensor_79 = div_scalar_8 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_14, convolution_default_218, primals_823, primals_821, primals_822, getitem_405, getitem_406, True, 1e-05, [True, True, True]);  add_tensor_14 = convolution_default_218 = primals_823 = primals_821 = primals_822 = getitem_405 = getitem_406 = None
        getitem_653 = native_batch_norm_backward_default_22[0]
        getitem_654 = native_batch_norm_backward_default_22[1]
        getitem_655 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_653, relu__default_172, primals_826, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_653 = primals_826 = None
        getitem_656 = convolution_backward_default_38[0]
        getitem_657 = convolution_backward_default_38[1]
        getitem_658 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_656, torch.float32);  getitem_656 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_172, torch.float32);  relu__default_172 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_187, to_dtype_114);  le_scalar_30 = new_zeros_default_187 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_217, primals_818, primals_816, primals_817, getitem_402, getitem_403, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_217 = primals_818 = primals_816 = primals_817 = getitem_402 = getitem_403 = None
        getitem_659 = native_batch_norm_backward_default_23[0]
        getitem_660 = native_batch_norm_backward_default_23[1]
        getitem_661 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_659, relu__default_171, primals_825, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_659 = primals_825 = None
        getitem_662 = convolution_backward_default_39[0]
        getitem_663 = convolution_backward_default_39[1]
        getitem_664 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_662, torch.float32);  getitem_662 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_171, torch.float32);  relu__default_171 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_188, to_dtype_117);  le_scalar_31 = new_zeros_default_188 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_216, primals_813, primals_811, primals_812, getitem_399, getitem_400, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_216 = primals_813 = primals_811 = primals_812 = getitem_399 = getitem_400 = None
        getitem_665 = native_batch_norm_backward_default_24[0]
        getitem_666 = native_batch_norm_backward_default_24[1]
        getitem_667 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_665, relu__default_170, primals_824, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_665 = primals_824 = None
        getitem_668 = convolution_backward_default_40[0]
        getitem_669 = convolution_backward_default_40[1]
        getitem_670 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(to_dtype_107, getitem_668);  to_dtype_107 = getitem_668 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_15, torch.float32);  add_tensor_15 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_170, torch.float32);  relu__default_170 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_189, to_dtype_120);  le_scalar_32 = new_zeros_default_189 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_122, getitem_395);  getitem_395 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(to_dtype_122, sigmoid_default_41)
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_82, [2, 3], True);  mul_tensor_82 = None
        to_dtype_123 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_124 = torch.ops.aten.to.dtype(sigmoid_default_41, torch.float32);  sigmoid_default_41 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(to_dtype_124, 1)
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_124, rsub_scalar_8);  to_dtype_124 = rsub_scalar_8 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_84);  mul_tensor_84 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(to_dtype_123, conj_physical_default_8);  to_dtype_123 = conj_physical_default_8 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_85, torch.float32);  mul_tensor_85 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(to_dtype_125, relu__default_169, primals_808, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = primals_808 = None
        getitem_671 = convolution_backward_default_41[0]
        getitem_672 = convolution_backward_default_41[1]
        getitem_673 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_671, torch.float32);  getitem_671 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_169, torch.float32);  relu__default_169 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_190, to_dtype_126);  le_scalar_33 = new_zeros_default_190 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(to_dtype_128, mean_dim_41, primals_806, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_128 = mean_dim_41 = primals_806 = None
        getitem_674 = convolution_backward_default_42[0]
        getitem_675 = convolution_backward_default_42[1]
        getitem_676 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        expand_default_9 = torch.ops.aten.expand.default(getitem_674, [64, 1024, 20, 20]);  getitem_674 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_9, 400);  expand_default_9 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(mul_tensor_83, div_scalar_9);  mul_tensor_83 = div_scalar_9 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_16, convolution_default_213, primals_801, primals_799, primals_800, getitem_396, getitem_397, True, 1e-05, [True, True, True]);  add_tensor_16 = convolution_default_213 = primals_801 = primals_799 = primals_800 = getitem_396 = getitem_397 = None
        getitem_677 = native_batch_norm_backward_default_25[0]
        getitem_678 = native_batch_norm_backward_default_25[1]
        getitem_679 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_677, relu__default_168, primals_804, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_677 = primals_804 = None
        getitem_680 = convolution_backward_default_43[0]
        getitem_681 = convolution_backward_default_43[1]
        getitem_682 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_680, torch.float32);  getitem_680 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_168, torch.float32);  relu__default_168 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_191, to_dtype_129);  le_scalar_34 = new_zeros_default_191 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_212, primals_796, primals_794, primals_795, getitem_393, getitem_394, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_212 = primals_796 = primals_794 = primals_795 = getitem_393 = getitem_394 = None
        getitem_683 = native_batch_norm_backward_default_26[0]
        getitem_684 = native_batch_norm_backward_default_26[1]
        getitem_685 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_683, relu__default_167, primals_803, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_683 = primals_803 = None
        getitem_686 = convolution_backward_default_44[0]
        getitem_687 = convolution_backward_default_44[1]
        getitem_688 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_686, torch.float32);  getitem_686 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_167, torch.float32);  relu__default_167 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_192, to_dtype_132);  le_scalar_35 = new_zeros_default_192 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_211, primals_791, primals_789, primals_790, getitem_390, getitem_391, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_211 = primals_791 = primals_789 = primals_790 = getitem_390 = getitem_391 = None
        getitem_689 = native_batch_norm_backward_default_27[0]
        getitem_690 = native_batch_norm_backward_default_27[1]
        getitem_691 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_689, relu__default_166, primals_802, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_689 = primals_802 = None
        getitem_692 = convolution_backward_default_45[0]
        getitem_693 = convolution_backward_default_45[1]
        getitem_694 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(to_dtype_122, getitem_692);  to_dtype_122 = getitem_692 = None
        to_dtype_135 = torch.ops.aten.to.dtype(add_tensor_17, torch.float32);  add_tensor_17 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_166, torch.float32);  relu__default_166 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_193, to_dtype_135);  le_scalar_36 = new_zeros_default_193 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_137, getitem_386);  getitem_386 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(to_dtype_137, sigmoid_default_40)
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_86, [2, 3], True);  mul_tensor_86 = None
        to_dtype_138 = torch.ops.aten.to.dtype(sum_dim_int_list_10, torch.float32);  sum_dim_int_list_10 = None
        to_dtype_139 = torch.ops.aten.to.dtype(sigmoid_default_40, torch.float32);  sigmoid_default_40 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(to_dtype_139, 1)
        mul_tensor_88 = torch.ops.aten.mul.Tensor(to_dtype_139, rsub_scalar_9);  to_dtype_139 = rsub_scalar_9 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_88);  mul_tensor_88 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_138, conj_physical_default_9);  to_dtype_138 = conj_physical_default_9 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_89, torch.float32);  mul_tensor_89 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(to_dtype_140, relu__default_165, primals_764, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_140 = primals_764 = None
        getitem_695 = convolution_backward_default_46[0]
        getitem_696 = convolution_backward_default_46[1]
        getitem_697 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_695, torch.float32);  getitem_695 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_165, torch.float32);  relu__default_165 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_194, to_dtype_141);  le_scalar_37 = new_zeros_default_194 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(to_dtype_143, mean_dim_40, primals_762, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_143 = mean_dim_40 = primals_762 = None
        getitem_698 = convolution_backward_default_47[0]
        getitem_699 = convolution_backward_default_47[1]
        getitem_700 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        expand_default_10 = torch.ops.aten.expand.default(getitem_698, [64, 1024, 20, 20]);  getitem_698 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_10, 400);  expand_default_10 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(mul_tensor_87, div_scalar_10);  mul_tensor_87 = div_scalar_10 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_18, convolution_default_208, primals_757, primals_755, primals_756, getitem_387, getitem_388, True, 1e-05, [True, True, True]);  add_tensor_18 = convolution_default_208 = primals_757 = primals_755 = primals_756 = getitem_387 = getitem_388 = None
        getitem_701 = native_batch_norm_backward_default_28[0]
        getitem_702 = native_batch_norm_backward_default_28[1]
        getitem_703 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_701, relu__default_164, primals_760, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_701 = primals_760 = None
        getitem_704 = convolution_backward_default_48[0]
        getitem_705 = convolution_backward_default_48[1]
        getitem_706 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_704, torch.float32);  getitem_704 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_164, torch.float32);  relu__default_164 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_195, to_dtype_144);  le_scalar_38 = new_zeros_default_195 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_207, primals_752, primals_750, primals_751, getitem_384, getitem_385, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_207 = primals_752 = primals_750 = primals_751 = getitem_384 = getitem_385 = None
        getitem_707 = native_batch_norm_backward_default_29[0]
        getitem_708 = native_batch_norm_backward_default_29[1]
        getitem_709 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_707, relu__default_163, primals_759, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_707 = primals_759 = None
        getitem_710 = convolution_backward_default_49[0]
        getitem_711 = convolution_backward_default_49[1]
        getitem_712 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_710, torch.float32);  getitem_710 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_163, torch.float32);  relu__default_163 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_196, to_dtype_147);  le_scalar_39 = new_zeros_default_196 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_206, primals_747, primals_745, primals_746, getitem_381, getitem_382, True, 1e-05, [True, True, True]);  to_dtype_149 = convolution_default_206 = primals_747 = primals_745 = primals_746 = getitem_381 = getitem_382 = None
        getitem_713 = native_batch_norm_backward_default_30[0]
        getitem_714 = native_batch_norm_backward_default_30[1]
        getitem_715 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_713, relu__default_162, primals_758, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_713 = primals_758 = None
        getitem_716 = convolution_backward_default_50[0]
        getitem_717 = convolution_backward_default_50[1]
        getitem_718 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(to_dtype_137, getitem_716);  to_dtype_137 = getitem_716 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_19, torch.float32);  add_tensor_19 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_162, torch.float32);  relu__default_162 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_197, to_dtype_150);  le_scalar_40 = new_zeros_default_197 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_152, getitem_377);  getitem_377 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(to_dtype_152, sigmoid_default_39)
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_90, [2, 3], True);  mul_tensor_90 = None
        to_dtype_153 = torch.ops.aten.to.dtype(sum_dim_int_list_11, torch.float32);  sum_dim_int_list_11 = None
        to_dtype_154 = torch.ops.aten.to.dtype(sigmoid_default_39, torch.float32);  sigmoid_default_39 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(to_dtype_154, 1)
        mul_tensor_92 = torch.ops.aten.mul.Tensor(to_dtype_154, rsub_scalar_10);  to_dtype_154 = rsub_scalar_10 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_92);  mul_tensor_92 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_153, conj_physical_default_10);  to_dtype_153 = conj_physical_default_10 = None
        to_dtype_155 = torch.ops.aten.to.dtype(mul_tensor_93, torch.float32);  mul_tensor_93 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(to_dtype_155, relu__default_161, primals_742, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_155 = primals_742 = None
        getitem_719 = convolution_backward_default_51[0]
        getitem_720 = convolution_backward_default_51[1]
        getitem_721 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_719, torch.float32);  getitem_719 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_161, torch.float32);  relu__default_161 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_198, to_dtype_156);  le_scalar_41 = new_zeros_default_198 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(to_dtype_158, mean_dim_39, primals_740, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_158 = mean_dim_39 = primals_740 = None
        getitem_722 = convolution_backward_default_52[0]
        getitem_723 = convolution_backward_default_52[1]
        getitem_724 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_722, [64, 1024, 20, 20]);  getitem_722 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_11, 400);  expand_default_11 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(mul_tensor_91, div_scalar_11);  mul_tensor_91 = div_scalar_11 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_20, convolution_default_203, primals_735, primals_733, primals_734, getitem_378, getitem_379, True, 1e-05, [True, True, True]);  add_tensor_20 = convolution_default_203 = primals_735 = primals_733 = primals_734 = getitem_378 = getitem_379 = None
        getitem_725 = native_batch_norm_backward_default_31[0]
        getitem_726 = native_batch_norm_backward_default_31[1]
        getitem_727 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_725, relu__default_160, primals_738, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_725 = primals_738 = None
        getitem_728 = convolution_backward_default_53[0]
        getitem_729 = convolution_backward_default_53[1]
        getitem_730 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_728, torch.float32);  getitem_728 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_160, torch.float32);  relu__default_160 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_199, to_dtype_159);  le_scalar_42 = new_zeros_default_199 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_202, primals_730, primals_728, primals_729, getitem_375, getitem_376, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_202 = primals_730 = primals_728 = primals_729 = getitem_375 = getitem_376 = None
        getitem_731 = native_batch_norm_backward_default_32[0]
        getitem_732 = native_batch_norm_backward_default_32[1]
        getitem_733 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_731, relu__default_159, primals_737, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_731 = primals_737 = None
        getitem_734 = convolution_backward_default_54[0]
        getitem_735 = convolution_backward_default_54[1]
        getitem_736 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_734, torch.float32);  getitem_734 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_159, torch.float32);  relu__default_159 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_200, to_dtype_162);  le_scalar_43 = new_zeros_default_200 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_201, primals_725, primals_723, primals_724, getitem_372, getitem_373, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_201 = primals_725 = primals_723 = primals_724 = getitem_372 = getitem_373 = None
        getitem_737 = native_batch_norm_backward_default_33[0]
        getitem_738 = native_batch_norm_backward_default_33[1]
        getitem_739 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_737, relu__default_158, primals_736, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_737 = primals_736 = None
        getitem_740 = convolution_backward_default_55[0]
        getitem_741 = convolution_backward_default_55[1]
        getitem_742 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(to_dtype_152, getitem_740);  to_dtype_152 = getitem_740 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_21, torch.float32);  add_tensor_21 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_158, torch.float32);  relu__default_158 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_201, to_dtype_165);  le_scalar_44 = new_zeros_default_201 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_167, getitem_368);  getitem_368 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(to_dtype_167, sigmoid_default_38)
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_94, [2, 3], True);  mul_tensor_94 = None
        to_dtype_168 = torch.ops.aten.to.dtype(sum_dim_int_list_12, torch.float32);  sum_dim_int_list_12 = None
        to_dtype_169 = torch.ops.aten.to.dtype(sigmoid_default_38, torch.float32);  sigmoid_default_38 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(to_dtype_169, 1)
        mul_tensor_96 = torch.ops.aten.mul.Tensor(to_dtype_169, rsub_scalar_11);  to_dtype_169 = rsub_scalar_11 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_96);  mul_tensor_96 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_168, conj_physical_default_11);  to_dtype_168 = conj_physical_default_11 = None
        to_dtype_170 = torch.ops.aten.to.dtype(mul_tensor_97, torch.float32);  mul_tensor_97 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(to_dtype_170, relu__default_157, primals_720, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_170 = primals_720 = None
        getitem_743 = convolution_backward_default_56[0]
        getitem_744 = convolution_backward_default_56[1]
        getitem_745 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_743, torch.float32);  getitem_743 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_157, torch.float32);  relu__default_157 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_202, to_dtype_171);  le_scalar_45 = new_zeros_default_202 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(to_dtype_173, mean_dim_38, primals_718, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_173 = mean_dim_38 = primals_718 = None
        getitem_746 = convolution_backward_default_57[0]
        getitem_747 = convolution_backward_default_57[1]
        getitem_748 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        expand_default_12 = torch.ops.aten.expand.default(getitem_746, [64, 1024, 20, 20]);  getitem_746 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_12, 400);  expand_default_12 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(mul_tensor_95, div_scalar_12);  mul_tensor_95 = div_scalar_12 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_22, convolution_default_198, primals_713, primals_711, primals_712, getitem_369, getitem_370, True, 1e-05, [True, True, True]);  add_tensor_22 = convolution_default_198 = primals_713 = primals_711 = primals_712 = getitem_369 = getitem_370 = None
        getitem_749 = native_batch_norm_backward_default_34[0]
        getitem_750 = native_batch_norm_backward_default_34[1]
        getitem_751 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_749, relu__default_156, primals_716, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_749 = primals_716 = None
        getitem_752 = convolution_backward_default_58[0]
        getitem_753 = convolution_backward_default_58[1]
        getitem_754 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_752, torch.float32);  getitem_752 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_156, torch.float32);  relu__default_156 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_203, to_dtype_174);  le_scalar_46 = new_zeros_default_203 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_197, primals_708, primals_706, primals_707, getitem_366, getitem_367, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_197 = primals_708 = primals_706 = primals_707 = getitem_366 = getitem_367 = None
        getitem_755 = native_batch_norm_backward_default_35[0]
        getitem_756 = native_batch_norm_backward_default_35[1]
        getitem_757 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_755, relu__default_155, primals_715, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_755 = primals_715 = None
        getitem_758 = convolution_backward_default_59[0]
        getitem_759 = convolution_backward_default_59[1]
        getitem_760 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_758, torch.float32);  getitem_758 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_155, torch.float32);  relu__default_155 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_204, to_dtype_177);  le_scalar_47 = new_zeros_default_204 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_196, primals_703, primals_701, primals_702, getitem_363, getitem_364, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_196 = primals_703 = primals_701 = primals_702 = getitem_363 = getitem_364 = None
        getitem_761 = native_batch_norm_backward_default_36[0]
        getitem_762 = native_batch_norm_backward_default_36[1]
        getitem_763 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_761, relu__default_154, primals_714, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_761 = primals_714 = None
        getitem_764 = convolution_backward_default_60[0]
        getitem_765 = convolution_backward_default_60[1]
        getitem_766 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(to_dtype_167, getitem_764);  to_dtype_167 = getitem_764 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_23, torch.float32);  add_tensor_23 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_154, torch.float32);  relu__default_154 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_205, to_dtype_180);  le_scalar_48 = new_zeros_default_205 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_182, getitem_359);  getitem_359 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(to_dtype_182, sigmoid_default_37)
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_98, [2, 3], True);  mul_tensor_98 = None
        to_dtype_183 = torch.ops.aten.to.dtype(sum_dim_int_list_13, torch.float32);  sum_dim_int_list_13 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default_37, torch.float32);  sigmoid_default_37 = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_100 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_12);  to_dtype_184 = rsub_scalar_12 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_100);  mul_tensor_100 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_12);  to_dtype_183 = conj_physical_default_12 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_101, torch.float32);  mul_tensor_101 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(to_dtype_185, relu__default_153, primals_698, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_185 = primals_698 = None
        getitem_767 = convolution_backward_default_61[0]
        getitem_768 = convolution_backward_default_61[1]
        getitem_769 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_767, torch.float32);  getitem_767 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_153, torch.float32);  relu__default_153 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_206, to_dtype_186);  le_scalar_49 = new_zeros_default_206 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(to_dtype_188, mean_dim_37, primals_696, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_188 = mean_dim_37 = primals_696 = None
        getitem_770 = convolution_backward_default_62[0]
        getitem_771 = convolution_backward_default_62[1]
        getitem_772 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        expand_default_13 = torch.ops.aten.expand.default(getitem_770, [64, 1024, 20, 20]);  getitem_770 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_13, 400);  expand_default_13 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_99, div_scalar_13);  mul_tensor_99 = div_scalar_13 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_24, convolution_default_193, primals_691, primals_689, primals_690, getitem_360, getitem_361, True, 1e-05, [True, True, True]);  add_tensor_24 = convolution_default_193 = primals_691 = primals_689 = primals_690 = getitem_360 = getitem_361 = None
        getitem_773 = native_batch_norm_backward_default_37[0]
        getitem_774 = native_batch_norm_backward_default_37[1]
        getitem_775 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_773, relu__default_152, primals_694, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_773 = primals_694 = None
        getitem_776 = convolution_backward_default_63[0]
        getitem_777 = convolution_backward_default_63[1]
        getitem_778 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_776, torch.float32);  getitem_776 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_152, torch.float32);  relu__default_152 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_207, to_dtype_189);  le_scalar_50 = new_zeros_default_207 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_192, primals_686, primals_684, primals_685, getitem_357, getitem_358, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_192 = primals_686 = primals_684 = primals_685 = getitem_357 = getitem_358 = None
        getitem_779 = native_batch_norm_backward_default_38[0]
        getitem_780 = native_batch_norm_backward_default_38[1]
        getitem_781 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_779, relu__default_151, primals_693, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_779 = primals_693 = None
        getitem_782 = convolution_backward_default_64[0]
        getitem_783 = convolution_backward_default_64[1]
        getitem_784 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_782, torch.float32);  getitem_782 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_151, torch.float32);  relu__default_151 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_208, to_dtype_192);  le_scalar_51 = new_zeros_default_208 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_191, primals_681, primals_679, primals_680, getitem_354, getitem_355, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default_191 = primals_681 = primals_679 = primals_680 = getitem_354 = getitem_355 = None
        getitem_785 = native_batch_norm_backward_default_39[0]
        getitem_786 = native_batch_norm_backward_default_39[1]
        getitem_787 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_785, relu__default_150, primals_692, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_785 = primals_692 = None
        getitem_788 = convolution_backward_default_65[0]
        getitem_789 = convolution_backward_default_65[1]
        getitem_790 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(to_dtype_182, getitem_788);  to_dtype_182 = getitem_788 = None
        to_dtype_195 = torch.ops.aten.to.dtype(add_tensor_25, torch.float32);  add_tensor_25 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_150, torch.float32);  relu__default_150 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_209, to_dtype_195);  le_scalar_52 = new_zeros_default_209 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_197, getitem_350);  getitem_350 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(to_dtype_197, sigmoid_default_36)
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(mul_tensor_102, [2, 3], True);  mul_tensor_102 = None
        to_dtype_198 = torch.ops.aten.to.dtype(sum_dim_int_list_14, torch.float32);  sum_dim_int_list_14 = None
        to_dtype_199 = torch.ops.aten.to.dtype(sigmoid_default_36, torch.float32);  sigmoid_default_36 = None
        rsub_scalar_13 = torch.ops.aten.rsub.Scalar(to_dtype_199, 1)
        mul_tensor_104 = torch.ops.aten.mul.Tensor(to_dtype_199, rsub_scalar_13);  to_dtype_199 = rsub_scalar_13 = None
        conj_physical_default_13 = torch.ops.aten.conj_physical.default(mul_tensor_104);  mul_tensor_104 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_198, conj_physical_default_13);  to_dtype_198 = conj_physical_default_13 = None
        to_dtype_200 = torch.ops.aten.to.dtype(mul_tensor_105, torch.float32);  mul_tensor_105 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(to_dtype_200, relu__default_149, primals_676, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_200 = primals_676 = None
        getitem_791 = convolution_backward_default_66[0]
        getitem_792 = convolution_backward_default_66[1]
        getitem_793 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_791, torch.float32);  getitem_791 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_149, torch.float32);  relu__default_149 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_210, to_dtype_201);  le_scalar_53 = new_zeros_default_210 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(to_dtype_203, mean_dim_36, primals_674, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_203 = mean_dim_36 = primals_674 = None
        getitem_794 = convolution_backward_default_67[0]
        getitem_795 = convolution_backward_default_67[1]
        getitem_796 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        expand_default_14 = torch.ops.aten.expand.default(getitem_794, [64, 1024, 20, 20]);  getitem_794 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_14, 400);  expand_default_14 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_103, div_scalar_14);  mul_tensor_103 = div_scalar_14 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_26, convolution_default_188, primals_669, primals_667, primals_668, getitem_351, getitem_352, True, 1e-05, [True, True, True]);  add_tensor_26 = convolution_default_188 = primals_669 = primals_667 = primals_668 = getitem_351 = getitem_352 = None
        getitem_797 = native_batch_norm_backward_default_40[0]
        getitem_798 = native_batch_norm_backward_default_40[1]
        getitem_799 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_797, relu__default_148, primals_672, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_797 = primals_672 = None
        getitem_800 = convolution_backward_default_68[0]
        getitem_801 = convolution_backward_default_68[1]
        getitem_802 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_800, torch.float32);  getitem_800 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_148, torch.float32);  relu__default_148 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_211, to_dtype_204);  le_scalar_54 = new_zeros_default_211 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_187, primals_664, primals_662, primals_663, getitem_348, getitem_349, True, 1e-05, [True, True, True]);  to_dtype_206 = convolution_default_187 = primals_664 = primals_662 = primals_663 = getitem_348 = getitem_349 = None
        getitem_803 = native_batch_norm_backward_default_41[0]
        getitem_804 = native_batch_norm_backward_default_41[1]
        getitem_805 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_803, relu__default_147, primals_671, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_803 = primals_671 = None
        getitem_806 = convolution_backward_default_69[0]
        getitem_807 = convolution_backward_default_69[1]
        getitem_808 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_806, torch.float32);  getitem_806 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_147, torch.float32);  relu__default_147 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_212, to_dtype_207);  le_scalar_55 = new_zeros_default_212 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_186, primals_659, primals_657, primals_658, getitem_345, getitem_346, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_186 = primals_659 = primals_657 = primals_658 = getitem_345 = getitem_346 = None
        getitem_809 = native_batch_norm_backward_default_42[0]
        getitem_810 = native_batch_norm_backward_default_42[1]
        getitem_811 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_809, relu__default_146, primals_670, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_809 = primals_670 = None
        getitem_812 = convolution_backward_default_70[0]
        getitem_813 = convolution_backward_default_70[1]
        getitem_814 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(to_dtype_197, getitem_812);  to_dtype_197 = getitem_812 = None
        to_dtype_210 = torch.ops.aten.to.dtype(add_tensor_27, torch.float32);  add_tensor_27 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_146, torch.float32);  relu__default_146 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_213, to_dtype_210);  le_scalar_56 = new_zeros_default_213 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_212, getitem_341);  getitem_341 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(to_dtype_212, sigmoid_default_35)
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_106, [2, 3], True);  mul_tensor_106 = None
        to_dtype_213 = torch.ops.aten.to.dtype(sum_dim_int_list_15, torch.float32);  sum_dim_int_list_15 = None
        to_dtype_214 = torch.ops.aten.to.dtype(sigmoid_default_35, torch.float32);  sigmoid_default_35 = None
        rsub_scalar_14 = torch.ops.aten.rsub.Scalar(to_dtype_214, 1)
        mul_tensor_108 = torch.ops.aten.mul.Tensor(to_dtype_214, rsub_scalar_14);  to_dtype_214 = rsub_scalar_14 = None
        conj_physical_default_14 = torch.ops.aten.conj_physical.default(mul_tensor_108);  mul_tensor_108 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_213, conj_physical_default_14);  to_dtype_213 = conj_physical_default_14 = None
        to_dtype_215 = torch.ops.aten.to.dtype(mul_tensor_109, torch.float32);  mul_tensor_109 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(to_dtype_215, relu__default_145, primals_654, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_215 = primals_654 = None
        getitem_815 = convolution_backward_default_71[0]
        getitem_816 = convolution_backward_default_71[1]
        getitem_817 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_815, torch.float32);  getitem_815 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_145, torch.float32);  relu__default_145 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_214, to_dtype_216);  le_scalar_57 = new_zeros_default_214 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(to_dtype_218, mean_dim_35, primals_652, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_218 = mean_dim_35 = primals_652 = None
        getitem_818 = convolution_backward_default_72[0]
        getitem_819 = convolution_backward_default_72[1]
        getitem_820 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        expand_default_15 = torch.ops.aten.expand.default(getitem_818, [64, 1024, 20, 20]);  getitem_818 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_15, 400);  expand_default_15 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(mul_tensor_107, div_scalar_15);  mul_tensor_107 = div_scalar_15 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_28, convolution_default_183, primals_647, primals_645, primals_646, getitem_342, getitem_343, True, 1e-05, [True, True, True]);  add_tensor_28 = convolution_default_183 = primals_647 = primals_645 = primals_646 = getitem_342 = getitem_343 = None
        getitem_821 = native_batch_norm_backward_default_43[0]
        getitem_822 = native_batch_norm_backward_default_43[1]
        getitem_823 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_821, relu__default_144, primals_650, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_821 = primals_650 = None
        getitem_824 = convolution_backward_default_73[0]
        getitem_825 = convolution_backward_default_73[1]
        getitem_826 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_824, torch.float32);  getitem_824 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_144, torch.float32);  relu__default_144 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_215, to_dtype_219);  le_scalar_58 = new_zeros_default_215 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_182, primals_642, primals_640, primals_641, getitem_339, getitem_340, True, 1e-05, [True, True, True]);  to_dtype_221 = convolution_default_182 = primals_642 = primals_640 = primals_641 = getitem_339 = getitem_340 = None
        getitem_827 = native_batch_norm_backward_default_44[0]
        getitem_828 = native_batch_norm_backward_default_44[1]
        getitem_829 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_827, relu__default_143, primals_649, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_827 = primals_649 = None
        getitem_830 = convolution_backward_default_74[0]
        getitem_831 = convolution_backward_default_74[1]
        getitem_832 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_830, torch.float32);  getitem_830 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_143, torch.float32);  relu__default_143 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_216, to_dtype_222);  le_scalar_59 = new_zeros_default_216 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_181, primals_637, primals_635, primals_636, getitem_336, getitem_337, True, 1e-05, [True, True, True]);  to_dtype_224 = convolution_default_181 = primals_637 = primals_635 = primals_636 = getitem_336 = getitem_337 = None
        getitem_833 = native_batch_norm_backward_default_45[0]
        getitem_834 = native_batch_norm_backward_default_45[1]
        getitem_835 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_833, relu__default_142, primals_648, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_833 = primals_648 = None
        getitem_836 = convolution_backward_default_75[0]
        getitem_837 = convolution_backward_default_75[1]
        getitem_838 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(to_dtype_212, getitem_836);  to_dtype_212 = getitem_836 = None
        to_dtype_225 = torch.ops.aten.to.dtype(add_tensor_29, torch.float32);  add_tensor_29 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_142, torch.float32);  relu__default_142 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_217, to_dtype_225);  le_scalar_60 = new_zeros_default_217 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(to_dtype_227, getitem_332);  getitem_332 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(to_dtype_227, sigmoid_default_34)
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(mul_tensor_110, [2, 3], True);  mul_tensor_110 = None
        to_dtype_228 = torch.ops.aten.to.dtype(sum_dim_int_list_16, torch.float32);  sum_dim_int_list_16 = None
        to_dtype_229 = torch.ops.aten.to.dtype(sigmoid_default_34, torch.float32);  sigmoid_default_34 = None
        rsub_scalar_15 = torch.ops.aten.rsub.Scalar(to_dtype_229, 1)
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_229, rsub_scalar_15);  to_dtype_229 = rsub_scalar_15 = None
        conj_physical_default_15 = torch.ops.aten.conj_physical.default(mul_tensor_112);  mul_tensor_112 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(to_dtype_228, conj_physical_default_15);  to_dtype_228 = conj_physical_default_15 = None
        to_dtype_230 = torch.ops.aten.to.dtype(mul_tensor_113, torch.float32);  mul_tensor_113 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(to_dtype_230, relu__default_141, primals_632, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_230 = primals_632 = None
        getitem_839 = convolution_backward_default_76[0]
        getitem_840 = convolution_backward_default_76[1]
        getitem_841 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_839, torch.float32);  getitem_839 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_141, torch.float32);  relu__default_141 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_218, to_dtype_231);  le_scalar_61 = new_zeros_default_218 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(to_dtype_233, mean_dim_34, primals_630, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_233 = mean_dim_34 = primals_630 = None
        getitem_842 = convolution_backward_default_77[0]
        getitem_843 = convolution_backward_default_77[1]
        getitem_844 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        expand_default_16 = torch.ops.aten.expand.default(getitem_842, [64, 1024, 20, 20]);  getitem_842 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_16, 400);  expand_default_16 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_111, div_scalar_16);  mul_tensor_111 = div_scalar_16 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_30, convolution_default_178, primals_625, primals_623, primals_624, getitem_333, getitem_334, True, 1e-05, [True, True, True]);  add_tensor_30 = convolution_default_178 = primals_625 = primals_623 = primals_624 = getitem_333 = getitem_334 = None
        getitem_845 = native_batch_norm_backward_default_46[0]
        getitem_846 = native_batch_norm_backward_default_46[1]
        getitem_847 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_845, relu__default_140, primals_628, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_845 = primals_628 = None
        getitem_848 = convolution_backward_default_78[0]
        getitem_849 = convolution_backward_default_78[1]
        getitem_850 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_848, torch.float32);  getitem_848 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_140, torch.float32);  relu__default_140 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_219, to_dtype_234);  le_scalar_62 = new_zeros_default_219 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_177, primals_620, primals_618, primals_619, getitem_330, getitem_331, True, 1e-05, [True, True, True]);  to_dtype_236 = convolution_default_177 = primals_620 = primals_618 = primals_619 = getitem_330 = getitem_331 = None
        getitem_851 = native_batch_norm_backward_default_47[0]
        getitem_852 = native_batch_norm_backward_default_47[1]
        getitem_853 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_851, relu__default_139, primals_627, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_851 = primals_627 = None
        getitem_854 = convolution_backward_default_79[0]
        getitem_855 = convolution_backward_default_79[1]
        getitem_856 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_854, torch.float32);  getitem_854 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_139, torch.float32);  relu__default_139 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_220, to_dtype_237);  le_scalar_63 = new_zeros_default_220 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_176, primals_615, primals_613, primals_614, getitem_327, getitem_328, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_176 = primals_615 = primals_613 = primals_614 = getitem_327 = getitem_328 = None
        getitem_857 = native_batch_norm_backward_default_48[0]
        getitem_858 = native_batch_norm_backward_default_48[1]
        getitem_859 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_857, relu__default_138, primals_626, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_857 = primals_626 = None
        getitem_860 = convolution_backward_default_80[0]
        getitem_861 = convolution_backward_default_80[1]
        getitem_862 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(to_dtype_227, getitem_860);  to_dtype_227 = getitem_860 = None
        to_dtype_240 = torch.ops.aten.to.dtype(add_tensor_31, torch.float32);  add_tensor_31 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_138, torch.float32);  relu__default_138 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_221, to_dtype_240);  le_scalar_64 = new_zeros_default_221 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(to_dtype_242, getitem_323);  getitem_323 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(to_dtype_242, sigmoid_default_33)
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_114, [2, 3], True);  mul_tensor_114 = None
        to_dtype_243 = torch.ops.aten.to.dtype(sum_dim_int_list_17, torch.float32);  sum_dim_int_list_17 = None
        to_dtype_244 = torch.ops.aten.to.dtype(sigmoid_default_33, torch.float32);  sigmoid_default_33 = None
        rsub_scalar_16 = torch.ops.aten.rsub.Scalar(to_dtype_244, 1)
        mul_tensor_116 = torch.ops.aten.mul.Tensor(to_dtype_244, rsub_scalar_16);  to_dtype_244 = rsub_scalar_16 = None
        conj_physical_default_16 = torch.ops.aten.conj_physical.default(mul_tensor_116);  mul_tensor_116 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_243, conj_physical_default_16);  to_dtype_243 = conj_physical_default_16 = None
        to_dtype_245 = torch.ops.aten.to.dtype(mul_tensor_117, torch.float32);  mul_tensor_117 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(to_dtype_245, relu__default_137, primals_610, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_245 = primals_610 = None
        getitem_863 = convolution_backward_default_81[0]
        getitem_864 = convolution_backward_default_81[1]
        getitem_865 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_863, torch.float32);  getitem_863 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_137, torch.float32);  relu__default_137 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_222, to_dtype_246);  le_scalar_65 = new_zeros_default_222 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(to_dtype_248, mean_dim_33, primals_608, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_248 = mean_dim_33 = primals_608 = None
        getitem_866 = convolution_backward_default_82[0]
        getitem_867 = convolution_backward_default_82[1]
        getitem_868 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        expand_default_17 = torch.ops.aten.expand.default(getitem_866, [64, 1024, 20, 20]);  getitem_866 = None
        div_scalar_17 = torch.ops.aten.div.Scalar(expand_default_17, 400);  expand_default_17 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_115, div_scalar_17);  mul_tensor_115 = div_scalar_17 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_32, convolution_default_173, primals_603, primals_601, primals_602, getitem_324, getitem_325, True, 1e-05, [True, True, True]);  add_tensor_32 = convolution_default_173 = primals_603 = primals_601 = primals_602 = getitem_324 = getitem_325 = None
        getitem_869 = native_batch_norm_backward_default_49[0]
        getitem_870 = native_batch_norm_backward_default_49[1]
        getitem_871 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_869, relu__default_136, primals_606, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_869 = primals_606 = None
        getitem_872 = convolution_backward_default_83[0]
        getitem_873 = convolution_backward_default_83[1]
        getitem_874 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_872, torch.float32);  getitem_872 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_136, torch.float32);  relu__default_136 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_223, to_dtype_249);  le_scalar_66 = new_zeros_default_223 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_172, primals_598, primals_596, primals_597, getitem_321, getitem_322, True, 1e-05, [True, True, True]);  to_dtype_251 = convolution_default_172 = primals_598 = primals_596 = primals_597 = getitem_321 = getitem_322 = None
        getitem_875 = native_batch_norm_backward_default_50[0]
        getitem_876 = native_batch_norm_backward_default_50[1]
        getitem_877 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_875, relu__default_135, primals_605, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_875 = primals_605 = None
        getitem_878 = convolution_backward_default_84[0]
        getitem_879 = convolution_backward_default_84[1]
        getitem_880 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_878, torch.float32);  getitem_878 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_135, torch.float32);  relu__default_135 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_224, to_dtype_252);  le_scalar_67 = new_zeros_default_224 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_171, primals_593, primals_591, primals_592, getitem_318, getitem_319, True, 1e-05, [True, True, True]);  to_dtype_254 = convolution_default_171 = primals_593 = primals_591 = primals_592 = getitem_318 = getitem_319 = None
        getitem_881 = native_batch_norm_backward_default_51[0]
        getitem_882 = native_batch_norm_backward_default_51[1]
        getitem_883 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_881, relu__default_134, primals_604, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_881 = primals_604 = None
        getitem_884 = convolution_backward_default_85[0]
        getitem_885 = convolution_backward_default_85[1]
        getitem_886 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(to_dtype_242, getitem_884);  to_dtype_242 = getitem_884 = None
        to_dtype_255 = torch.ops.aten.to.dtype(add_tensor_33, torch.float32);  add_tensor_33 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_134, torch.float32);  relu__default_134 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_225, to_dtype_255);  le_scalar_68 = new_zeros_default_225 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(to_dtype_257, getitem_314);  getitem_314 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(to_dtype_257, sigmoid_default_32)
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(mul_tensor_118, [2, 3], True);  mul_tensor_118 = None
        to_dtype_258 = torch.ops.aten.to.dtype(sum_dim_int_list_18, torch.float32);  sum_dim_int_list_18 = None
        to_dtype_259 = torch.ops.aten.to.dtype(sigmoid_default_32, torch.float32);  sigmoid_default_32 = None
        rsub_scalar_17 = torch.ops.aten.rsub.Scalar(to_dtype_259, 1)
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_259, rsub_scalar_17);  to_dtype_259 = rsub_scalar_17 = None
        conj_physical_default_17 = torch.ops.aten.conj_physical.default(mul_tensor_120);  mul_tensor_120 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_258, conj_physical_default_17);  to_dtype_258 = conj_physical_default_17 = None
        to_dtype_260 = torch.ops.aten.to.dtype(mul_tensor_121, torch.float32);  mul_tensor_121 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(to_dtype_260, relu__default_133, primals_588, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_260 = primals_588 = None
        getitem_887 = convolution_backward_default_86[0]
        getitem_888 = convolution_backward_default_86[1]
        getitem_889 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_887, torch.float32);  getitem_887 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_133, torch.float32);  relu__default_133 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_226, to_dtype_261);  le_scalar_69 = new_zeros_default_226 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(to_dtype_263, mean_dim_32, primals_586, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_263 = mean_dim_32 = primals_586 = None
        getitem_890 = convolution_backward_default_87[0]
        getitem_891 = convolution_backward_default_87[1]
        getitem_892 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        expand_default_18 = torch.ops.aten.expand.default(getitem_890, [64, 1024, 20, 20]);  getitem_890 = None
        div_scalar_18 = torch.ops.aten.div.Scalar(expand_default_18, 400);  expand_default_18 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(mul_tensor_119, div_scalar_18);  mul_tensor_119 = div_scalar_18 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_34, convolution_default_168, primals_581, primals_579, primals_580, getitem_315, getitem_316, True, 1e-05, [True, True, True]);  add_tensor_34 = convolution_default_168 = primals_581 = primals_579 = primals_580 = getitem_315 = getitem_316 = None
        getitem_893 = native_batch_norm_backward_default_52[0]
        getitem_894 = native_batch_norm_backward_default_52[1]
        getitem_895 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_893, relu__default_132, primals_584, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_893 = primals_584 = None
        getitem_896 = convolution_backward_default_88[0]
        getitem_897 = convolution_backward_default_88[1]
        getitem_898 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        to_dtype_264 = torch.ops.aten.to.dtype(getitem_896, torch.float32);  getitem_896 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_132, torch.float32);  relu__default_132 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_227, to_dtype_264);  le_scalar_70 = new_zeros_default_227 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_167, primals_576, primals_574, primals_575, getitem_312, getitem_313, True, 1e-05, [True, True, True]);  to_dtype_266 = convolution_default_167 = primals_576 = primals_574 = primals_575 = getitem_312 = getitem_313 = None
        getitem_899 = native_batch_norm_backward_default_53[0]
        getitem_900 = native_batch_norm_backward_default_53[1]
        getitem_901 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_899, relu__default_131, primals_583, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_899 = primals_583 = None
        getitem_902 = convolution_backward_default_89[0]
        getitem_903 = convolution_backward_default_89[1]
        getitem_904 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_902, torch.float32);  getitem_902 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_131, torch.float32);  relu__default_131 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_228, to_dtype_267);  le_scalar_71 = new_zeros_default_228 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_166, primals_571, primals_569, primals_570, getitem_309, getitem_310, True, 1e-05, [True, True, True]);  to_dtype_269 = convolution_default_166 = primals_571 = primals_569 = primals_570 = getitem_309 = getitem_310 = None
        getitem_905 = native_batch_norm_backward_default_54[0]
        getitem_906 = native_batch_norm_backward_default_54[1]
        getitem_907 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_905, relu__default_130, primals_582, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_905 = primals_582 = None
        getitem_908 = convolution_backward_default_90[0]
        getitem_909 = convolution_backward_default_90[1]
        getitem_910 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(to_dtype_257, getitem_908);  to_dtype_257 = getitem_908 = None
        to_dtype_270 = torch.ops.aten.to.dtype(add_tensor_35, torch.float32);  add_tensor_35 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_130, torch.float32);  relu__default_130 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_229, to_dtype_270);  le_scalar_72 = new_zeros_default_229 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(to_dtype_272, getitem_305);  getitem_305 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(to_dtype_272, sigmoid_default_31)
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(mul_tensor_122, [2, 3], True);  mul_tensor_122 = None
        to_dtype_273 = torch.ops.aten.to.dtype(sum_dim_int_list_19, torch.float32);  sum_dim_int_list_19 = None
        to_dtype_274 = torch.ops.aten.to.dtype(sigmoid_default_31, torch.float32);  sigmoid_default_31 = None
        rsub_scalar_18 = torch.ops.aten.rsub.Scalar(to_dtype_274, 1)
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_274, rsub_scalar_18);  to_dtype_274 = rsub_scalar_18 = None
        conj_physical_default_18 = torch.ops.aten.conj_physical.default(mul_tensor_124);  mul_tensor_124 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_273, conj_physical_default_18);  to_dtype_273 = conj_physical_default_18 = None
        to_dtype_275 = torch.ops.aten.to.dtype(mul_tensor_125, torch.float32);  mul_tensor_125 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(to_dtype_275, relu__default_129, primals_566, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_275 = primals_566 = None
        getitem_911 = convolution_backward_default_91[0]
        getitem_912 = convolution_backward_default_91[1]
        getitem_913 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        to_dtype_276 = torch.ops.aten.to.dtype(getitem_911, torch.float32);  getitem_911 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_129, torch.float32);  relu__default_129 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_230, to_dtype_276);  le_scalar_73 = new_zeros_default_230 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(to_dtype_278, mean_dim_31, primals_564, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_278 = mean_dim_31 = primals_564 = None
        getitem_914 = convolution_backward_default_92[0]
        getitem_915 = convolution_backward_default_92[1]
        getitem_916 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        expand_default_19 = torch.ops.aten.expand.default(getitem_914, [64, 1024, 20, 20]);  getitem_914 = None
        div_scalar_19 = torch.ops.aten.div.Scalar(expand_default_19, 400);  expand_default_19 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(mul_tensor_123, div_scalar_19);  mul_tensor_123 = div_scalar_19 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_36, convolution_default_163, primals_559, primals_557, primals_558, getitem_306, getitem_307, True, 1e-05, [True, True, True]);  add_tensor_36 = convolution_default_163 = primals_559 = primals_557 = primals_558 = getitem_306 = getitem_307 = None
        getitem_917 = native_batch_norm_backward_default_55[0]
        getitem_918 = native_batch_norm_backward_default_55[1]
        getitem_919 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_917, relu__default_128, primals_562, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_917 = primals_562 = None
        getitem_920 = convolution_backward_default_93[0]
        getitem_921 = convolution_backward_default_93[1]
        getitem_922 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_920, torch.float32);  getitem_920 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_128, torch.float32);  relu__default_128 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_231, to_dtype_279);  le_scalar_74 = new_zeros_default_231 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_162, primals_554, primals_552, primals_553, getitem_303, getitem_304, True, 1e-05, [True, True, True]);  to_dtype_281 = convolution_default_162 = primals_554 = primals_552 = primals_553 = getitem_303 = getitem_304 = None
        getitem_923 = native_batch_norm_backward_default_56[0]
        getitem_924 = native_batch_norm_backward_default_56[1]
        getitem_925 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_923, relu__default_127, primals_561, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_923 = primals_561 = None
        getitem_926 = convolution_backward_default_94[0]
        getitem_927 = convolution_backward_default_94[1]
        getitem_928 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_926, torch.float32);  getitem_926 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_127, torch.float32);  relu__default_127 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_232, to_dtype_282);  le_scalar_75 = new_zeros_default_232 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_161, primals_549, primals_547, primals_548, getitem_300, getitem_301, True, 1e-05, [True, True, True]);  to_dtype_284 = convolution_default_161 = primals_549 = primals_547 = primals_548 = getitem_300 = getitem_301 = None
        getitem_929 = native_batch_norm_backward_default_57[0]
        getitem_930 = native_batch_norm_backward_default_57[1]
        getitem_931 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_929, relu__default_126, primals_560, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_929 = primals_560 = None
        getitem_932 = convolution_backward_default_95[0]
        getitem_933 = convolution_backward_default_95[1]
        getitem_934 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(to_dtype_272, getitem_932);  to_dtype_272 = getitem_932 = None
        to_dtype_285 = torch.ops.aten.to.dtype(add_tensor_37, torch.float32);  add_tensor_37 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_126, torch.float32);  relu__default_126 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_233, to_dtype_285);  le_scalar_76 = new_zeros_default_233 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_287, getitem_296);  getitem_296 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(to_dtype_287, sigmoid_default_30)
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(mul_tensor_126, [2, 3], True);  mul_tensor_126 = None
        to_dtype_288 = torch.ops.aten.to.dtype(sum_dim_int_list_20, torch.float32);  sum_dim_int_list_20 = None
        to_dtype_289 = torch.ops.aten.to.dtype(sigmoid_default_30, torch.float32);  sigmoid_default_30 = None
        rsub_scalar_19 = torch.ops.aten.rsub.Scalar(to_dtype_289, 1)
        mul_tensor_128 = torch.ops.aten.mul.Tensor(to_dtype_289, rsub_scalar_19);  to_dtype_289 = rsub_scalar_19 = None
        conj_physical_default_19 = torch.ops.aten.conj_physical.default(mul_tensor_128);  mul_tensor_128 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_288, conj_physical_default_19);  to_dtype_288 = conj_physical_default_19 = None
        to_dtype_290 = torch.ops.aten.to.dtype(mul_tensor_129, torch.float32);  mul_tensor_129 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(to_dtype_290, relu__default_125, primals_522, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_290 = primals_522 = None
        getitem_935 = convolution_backward_default_96[0]
        getitem_936 = convolution_backward_default_96[1]
        getitem_937 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_935, torch.float32);  getitem_935 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_125, torch.float32);  relu__default_125 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_234, to_dtype_291);  le_scalar_77 = new_zeros_default_234 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(to_dtype_293, mean_dim_30, primals_520, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_293 = mean_dim_30 = primals_520 = None
        getitem_938 = convolution_backward_default_97[0]
        getitem_939 = convolution_backward_default_97[1]
        getitem_940 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        expand_default_20 = torch.ops.aten.expand.default(getitem_938, [64, 1024, 20, 20]);  getitem_938 = None
        div_scalar_20 = torch.ops.aten.div.Scalar(expand_default_20, 400);  expand_default_20 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_127, div_scalar_20);  mul_tensor_127 = div_scalar_20 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_38, convolution_default_158, primals_515, primals_513, primals_514, getitem_297, getitem_298, True, 1e-05, [True, True, True]);  add_tensor_38 = convolution_default_158 = primals_515 = primals_513 = primals_514 = getitem_297 = getitem_298 = None
        getitem_941 = native_batch_norm_backward_default_58[0]
        getitem_942 = native_batch_norm_backward_default_58[1]
        getitem_943 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_941, relu__default_124, primals_518, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_941 = primals_518 = None
        getitem_944 = convolution_backward_default_98[0]
        getitem_945 = convolution_backward_default_98[1]
        getitem_946 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_944, torch.float32);  getitem_944 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_124, torch.float32);  relu__default_124 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_235, to_dtype_294);  le_scalar_78 = new_zeros_default_235 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_157, primals_510, primals_508, primals_509, getitem_294, getitem_295, True, 1e-05, [True, True, True]);  to_dtype_296 = convolution_default_157 = primals_510 = primals_508 = primals_509 = getitem_294 = getitem_295 = None
        getitem_947 = native_batch_norm_backward_default_59[0]
        getitem_948 = native_batch_norm_backward_default_59[1]
        getitem_949 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_947, relu__default_123, primals_517, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_947 = primals_517 = None
        getitem_950 = convolution_backward_default_99[0]
        getitem_951 = convolution_backward_default_99[1]
        getitem_952 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_950, torch.float32);  getitem_950 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_123, torch.float32);  relu__default_123 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_236, to_dtype_297);  le_scalar_79 = new_zeros_default_236 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_156, primals_505, primals_503, primals_504, getitem_291, getitem_292, True, 1e-05, [True, True, True]);  to_dtype_299 = convolution_default_156 = primals_505 = primals_503 = primals_504 = getitem_291 = getitem_292 = None
        getitem_953 = native_batch_norm_backward_default_60[0]
        getitem_954 = native_batch_norm_backward_default_60[1]
        getitem_955 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_953, relu__default_122, primals_516, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_953 = primals_516 = None
        getitem_956 = convolution_backward_default_100[0]
        getitem_957 = convolution_backward_default_100[1]
        getitem_958 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(to_dtype_287, getitem_956);  to_dtype_287 = getitem_956 = None
        to_dtype_300 = torch.ops.aten.to.dtype(add_tensor_39, torch.float32);  add_tensor_39 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu__default_122, torch.float32);  relu__default_122 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_237 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_237, to_dtype_300);  le_scalar_80 = new_zeros_default_237 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(to_dtype_302, getitem_287);  getitem_287 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(to_dtype_302, sigmoid_default_29)
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(mul_tensor_130, [2, 3], True);  mul_tensor_130 = None
        to_dtype_303 = torch.ops.aten.to.dtype(sum_dim_int_list_21, torch.float32);  sum_dim_int_list_21 = None
        to_dtype_304 = torch.ops.aten.to.dtype(sigmoid_default_29, torch.float32);  sigmoid_default_29 = None
        rsub_scalar_20 = torch.ops.aten.rsub.Scalar(to_dtype_304, 1)
        mul_tensor_132 = torch.ops.aten.mul.Tensor(to_dtype_304, rsub_scalar_20);  to_dtype_304 = rsub_scalar_20 = None
        conj_physical_default_20 = torch.ops.aten.conj_physical.default(mul_tensor_132);  mul_tensor_132 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_303, conj_physical_default_20);  to_dtype_303 = conj_physical_default_20 = None
        to_dtype_305 = torch.ops.aten.to.dtype(mul_tensor_133, torch.float32);  mul_tensor_133 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(to_dtype_305, relu__default_121, primals_500, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_305 = primals_500 = None
        getitem_959 = convolution_backward_default_101[0]
        getitem_960 = convolution_backward_default_101[1]
        getitem_961 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        to_dtype_306 = torch.ops.aten.to.dtype(getitem_959, torch.float32);  getitem_959 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu__default_121, torch.float32);  relu__default_121 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_238 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_238, to_dtype_306);  le_scalar_81 = new_zeros_default_238 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(to_dtype_308, mean_dim_29, primals_498, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_308 = mean_dim_29 = primals_498 = None
        getitem_962 = convolution_backward_default_102[0]
        getitem_963 = convolution_backward_default_102[1]
        getitem_964 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        expand_default_21 = torch.ops.aten.expand.default(getitem_962, [64, 1024, 20, 20]);  getitem_962 = None
        div_scalar_21 = torch.ops.aten.div.Scalar(expand_default_21, 400);  expand_default_21 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(mul_tensor_131, div_scalar_21);  mul_tensor_131 = div_scalar_21 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_40, convolution_default_153, primals_493, primals_491, primals_492, getitem_288, getitem_289, True, 1e-05, [True, True, True]);  add_tensor_40 = convolution_default_153 = primals_493 = primals_491 = primals_492 = getitem_288 = getitem_289 = None
        getitem_965 = native_batch_norm_backward_default_61[0]
        getitem_966 = native_batch_norm_backward_default_61[1]
        getitem_967 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_965, relu__default_120, primals_496, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_965 = primals_496 = None
        getitem_968 = convolution_backward_default_103[0]
        getitem_969 = convolution_backward_default_103[1]
        getitem_970 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        to_dtype_309 = torch.ops.aten.to.dtype(getitem_968, torch.float32);  getitem_968 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu__default_120, torch.float32);  relu__default_120 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_239 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_239, to_dtype_309);  le_scalar_82 = new_zeros_default_239 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_152, primals_488, primals_486, primals_487, getitem_285, getitem_286, True, 1e-05, [True, True, True]);  to_dtype_311 = convolution_default_152 = primals_488 = primals_486 = primals_487 = getitem_285 = getitem_286 = None
        getitem_971 = native_batch_norm_backward_default_62[0]
        getitem_972 = native_batch_norm_backward_default_62[1]
        getitem_973 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_971, relu__default_119, primals_495, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_971 = primals_495 = None
        getitem_974 = convolution_backward_default_104[0]
        getitem_975 = convolution_backward_default_104[1]
        getitem_976 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        to_dtype_312 = torch.ops.aten.to.dtype(getitem_974, torch.float32);  getitem_974 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu__default_119, torch.float32);  relu__default_119 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_240 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_240, to_dtype_312);  le_scalar_83 = new_zeros_default_240 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_314, convolution_default_151, primals_483, primals_481, primals_482, getitem_282, getitem_283, True, 1e-05, [True, True, True]);  to_dtype_314 = convolution_default_151 = primals_483 = primals_481 = primals_482 = getitem_282 = getitem_283 = None
        getitem_977 = native_batch_norm_backward_default_63[0]
        getitem_978 = native_batch_norm_backward_default_63[1]
        getitem_979 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_977, relu__default_118, primals_494, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_977 = primals_494 = None
        getitem_980 = convolution_backward_default_105[0]
        getitem_981 = convolution_backward_default_105[1]
        getitem_982 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(to_dtype_302, getitem_980);  to_dtype_302 = getitem_980 = None
        to_dtype_315 = torch.ops.aten.to.dtype(add_tensor_41, torch.float32);  add_tensor_41 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu__default_118, torch.float32);  relu__default_118 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_241 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_241, to_dtype_315);  le_scalar_84 = new_zeros_default_241 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(to_dtype_317, getitem_278);  getitem_278 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(to_dtype_317, sigmoid_default_28)
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(mul_tensor_134, [2, 3], True);  mul_tensor_134 = None
        to_dtype_318 = torch.ops.aten.to.dtype(sum_dim_int_list_22, torch.float32);  sum_dim_int_list_22 = None
        to_dtype_319 = torch.ops.aten.to.dtype(sigmoid_default_28, torch.float32);  sigmoid_default_28 = None
        rsub_scalar_21 = torch.ops.aten.rsub.Scalar(to_dtype_319, 1)
        mul_tensor_136 = torch.ops.aten.mul.Tensor(to_dtype_319, rsub_scalar_21);  to_dtype_319 = rsub_scalar_21 = None
        conj_physical_default_21 = torch.ops.aten.conj_physical.default(mul_tensor_136);  mul_tensor_136 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_318, conj_physical_default_21);  to_dtype_318 = conj_physical_default_21 = None
        to_dtype_320 = torch.ops.aten.to.dtype(mul_tensor_137, torch.float32);  mul_tensor_137 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(to_dtype_320, relu__default_117, primals_478, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_320 = primals_478 = None
        getitem_983 = convolution_backward_default_106[0]
        getitem_984 = convolution_backward_default_106[1]
        getitem_985 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_983, torch.float32);  getitem_983 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu__default_117, torch.float32);  relu__default_117 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_242 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_242, to_dtype_321);  le_scalar_85 = new_zeros_default_242 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(to_dtype_323, mean_dim_28, primals_476, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_323 = mean_dim_28 = primals_476 = None
        getitem_986 = convolution_backward_default_107[0]
        getitem_987 = convolution_backward_default_107[1]
        getitem_988 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        expand_default_22 = torch.ops.aten.expand.default(getitem_986, [64, 1024, 20, 20]);  getitem_986 = None
        div_scalar_22 = torch.ops.aten.div.Scalar(expand_default_22, 400);  expand_default_22 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(mul_tensor_135, div_scalar_22);  mul_tensor_135 = div_scalar_22 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_42, convolution_default_148, primals_471, primals_469, primals_470, getitem_279, getitem_280, True, 1e-05, [True, True, True]);  add_tensor_42 = convolution_default_148 = primals_471 = primals_469 = primals_470 = getitem_279 = getitem_280 = None
        getitem_989 = native_batch_norm_backward_default_64[0]
        getitem_990 = native_batch_norm_backward_default_64[1]
        getitem_991 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_989, relu__default_116, primals_474, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_989 = primals_474 = None
        getitem_992 = convolution_backward_default_108[0]
        getitem_993 = convolution_backward_default_108[1]
        getitem_994 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        to_dtype_324 = torch.ops.aten.to.dtype(getitem_992, torch.float32);  getitem_992 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu__default_116, torch.float32);  relu__default_116 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_243 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_243, to_dtype_324);  le_scalar_86 = new_zeros_default_243 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_326, convolution_default_147, primals_466, primals_464, primals_465, getitem_276, getitem_277, True, 1e-05, [True, True, True]);  to_dtype_326 = convolution_default_147 = primals_466 = primals_464 = primals_465 = getitem_276 = getitem_277 = None
        getitem_995 = native_batch_norm_backward_default_65[0]
        getitem_996 = native_batch_norm_backward_default_65[1]
        getitem_997 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_995, relu__default_115, primals_473, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_995 = primals_473 = None
        getitem_998 = convolution_backward_default_109[0]
        getitem_999 = convolution_backward_default_109[1]
        getitem_1000 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        to_dtype_327 = torch.ops.aten.to.dtype(getitem_998, torch.float32);  getitem_998 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu__default_115, torch.float32);  relu__default_115 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_244 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_244, to_dtype_327);  le_scalar_87 = new_zeros_default_244 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_146, primals_461, primals_459, primals_460, getitem_273, getitem_274, True, 1e-05, [True, True, True]);  to_dtype_329 = convolution_default_146 = primals_461 = primals_459 = primals_460 = getitem_273 = getitem_274 = None
        getitem_1001 = native_batch_norm_backward_default_66[0]
        getitem_1002 = native_batch_norm_backward_default_66[1]
        getitem_1003 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1001, relu__default_114, primals_472, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1001 = primals_472 = None
        getitem_1004 = convolution_backward_default_110[0]
        getitem_1005 = convolution_backward_default_110[1]
        getitem_1006 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(to_dtype_317, getitem_1004);  to_dtype_317 = getitem_1004 = None
        to_dtype_330 = torch.ops.aten.to.dtype(add_tensor_43, torch.float32);  add_tensor_43 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu__default_114, torch.float32);  relu__default_114 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_245 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_245, to_dtype_330);  le_scalar_88 = new_zeros_default_245 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_332, getitem_269);  getitem_269 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(to_dtype_332, sigmoid_default_27)
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(mul_tensor_138, [2, 3], True);  mul_tensor_138 = None
        to_dtype_333 = torch.ops.aten.to.dtype(sum_dim_int_list_23, torch.float32);  sum_dim_int_list_23 = None
        to_dtype_334 = torch.ops.aten.to.dtype(sigmoid_default_27, torch.float32);  sigmoid_default_27 = None
        rsub_scalar_22 = torch.ops.aten.rsub.Scalar(to_dtype_334, 1)
        mul_tensor_140 = torch.ops.aten.mul.Tensor(to_dtype_334, rsub_scalar_22);  to_dtype_334 = rsub_scalar_22 = None
        conj_physical_default_22 = torch.ops.aten.conj_physical.default(mul_tensor_140);  mul_tensor_140 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_333, conj_physical_default_22);  to_dtype_333 = conj_physical_default_22 = None
        to_dtype_335 = torch.ops.aten.to.dtype(mul_tensor_141, torch.float32);  mul_tensor_141 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(to_dtype_335, relu__default_113, primals_456, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_335 = primals_456 = None
        getitem_1007 = convolution_backward_default_111[0]
        getitem_1008 = convolution_backward_default_111[1]
        getitem_1009 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        to_dtype_336 = torch.ops.aten.to.dtype(getitem_1007, torch.float32);  getitem_1007 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu__default_113, torch.float32);  relu__default_113 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_246 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_246, to_dtype_336);  le_scalar_89 = new_zeros_default_246 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(to_dtype_338, mean_dim_27, primals_454, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_338 = mean_dim_27 = primals_454 = None
        getitem_1010 = convolution_backward_default_112[0]
        getitem_1011 = convolution_backward_default_112[1]
        getitem_1012 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        expand_default_23 = torch.ops.aten.expand.default(getitem_1010, [64, 1024, 20, 20]);  getitem_1010 = None
        div_scalar_23 = torch.ops.aten.div.Scalar(expand_default_23, 400);  expand_default_23 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(mul_tensor_139, div_scalar_23);  mul_tensor_139 = div_scalar_23 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_44, convolution_default_143, primals_449, primals_447, primals_448, getitem_270, getitem_271, True, 1e-05, [True, True, True]);  add_tensor_44 = convolution_default_143 = primals_449 = primals_447 = primals_448 = getitem_270 = getitem_271 = None
        getitem_1013 = native_batch_norm_backward_default_67[0]
        getitem_1014 = native_batch_norm_backward_default_67[1]
        getitem_1015 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1013, relu__default_112, primals_452, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1013 = primals_452 = None
        getitem_1016 = convolution_backward_default_113[0]
        getitem_1017 = convolution_backward_default_113[1]
        getitem_1018 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        to_dtype_339 = torch.ops.aten.to.dtype(getitem_1016, torch.float32);  getitem_1016 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu__default_112, torch.float32);  relu__default_112 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_247 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_247, to_dtype_339);  le_scalar_90 = new_zeros_default_247 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_142, primals_444, primals_442, primals_443, getitem_267, getitem_268, True, 1e-05, [True, True, True]);  to_dtype_341 = convolution_default_142 = primals_444 = primals_442 = primals_443 = getitem_267 = getitem_268 = None
        getitem_1019 = native_batch_norm_backward_default_68[0]
        getitem_1020 = native_batch_norm_backward_default_68[1]
        getitem_1021 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1019, relu__default_111, primals_451, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1019 = primals_451 = None
        getitem_1022 = convolution_backward_default_114[0]
        getitem_1023 = convolution_backward_default_114[1]
        getitem_1024 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        to_dtype_342 = torch.ops.aten.to.dtype(getitem_1022, torch.float32);  getitem_1022 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu__default_111, torch.float32);  relu__default_111 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_248 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_248, to_dtype_342);  le_scalar_91 = new_zeros_default_248 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_344, convolution_default_141, primals_439, primals_437, primals_438, getitem_264, getitem_265, True, 1e-05, [True, True, True]);  to_dtype_344 = convolution_default_141 = primals_439 = primals_437 = primals_438 = getitem_264 = getitem_265 = None
        getitem_1025 = native_batch_norm_backward_default_69[0]
        getitem_1026 = native_batch_norm_backward_default_69[1]
        getitem_1027 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1025, relu__default_110, primals_450, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1025 = primals_450 = None
        getitem_1028 = convolution_backward_default_115[0]
        getitem_1029 = convolution_backward_default_115[1]
        getitem_1030 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(to_dtype_332, getitem_1028);  to_dtype_332 = getitem_1028 = None
        to_dtype_345 = torch.ops.aten.to.dtype(add_tensor_45, torch.float32);  add_tensor_45 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_110, torch.float32);  relu__default_110 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_249 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_249, to_dtype_345);  le_scalar_92 = new_zeros_default_249 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_347, getitem_260);  getitem_260 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(to_dtype_347, sigmoid_default_26)
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(mul_tensor_142, [2, 3], True);  mul_tensor_142 = None
        to_dtype_348 = torch.ops.aten.to.dtype(sum_dim_int_list_24, torch.float32);  sum_dim_int_list_24 = None
        to_dtype_349 = torch.ops.aten.to.dtype(sigmoid_default_26, torch.float32);  sigmoid_default_26 = None
        rsub_scalar_23 = torch.ops.aten.rsub.Scalar(to_dtype_349, 1)
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_349, rsub_scalar_23);  to_dtype_349 = rsub_scalar_23 = None
        conj_physical_default_23 = torch.ops.aten.conj_physical.default(mul_tensor_144);  mul_tensor_144 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_348, conj_physical_default_23);  to_dtype_348 = conj_physical_default_23 = None
        to_dtype_350 = torch.ops.aten.to.dtype(mul_tensor_145, torch.float32);  mul_tensor_145 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(to_dtype_350, relu__default_109, primals_434, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_350 = primals_434 = None
        getitem_1031 = convolution_backward_default_116[0]
        getitem_1032 = convolution_backward_default_116[1]
        getitem_1033 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        to_dtype_351 = torch.ops.aten.to.dtype(getitem_1031, torch.float32);  getitem_1031 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_250 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_250, to_dtype_351);  le_scalar_93 = new_zeros_default_250 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(to_dtype_353, mean_dim_26, primals_432, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_353 = mean_dim_26 = primals_432 = None
        getitem_1034 = convolution_backward_default_117[0]
        getitem_1035 = convolution_backward_default_117[1]
        getitem_1036 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        expand_default_24 = torch.ops.aten.expand.default(getitem_1034, [64, 1024, 20, 20]);  getitem_1034 = None
        div_scalar_24 = torch.ops.aten.div.Scalar(expand_default_24, 400);  expand_default_24 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(mul_tensor_143, div_scalar_24);  mul_tensor_143 = div_scalar_24 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_46, convolution_default_138, primals_427, primals_425, primals_426, getitem_261, getitem_262, True, 1e-05, [True, True, True]);  add_tensor_46 = convolution_default_138 = primals_427 = primals_425 = primals_426 = getitem_261 = getitem_262 = None
        getitem_1037 = native_batch_norm_backward_default_70[0]
        getitem_1038 = native_batch_norm_backward_default_70[1]
        getitem_1039 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1037, relu__default_108, primals_430, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1037 = primals_430 = None
        getitem_1040 = convolution_backward_default_118[0]
        getitem_1041 = convolution_backward_default_118[1]
        getitem_1042 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        to_dtype_354 = torch.ops.aten.to.dtype(getitem_1040, torch.float32);  getitem_1040 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_251 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_251, to_dtype_354);  le_scalar_94 = new_zeros_default_251 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_356, convolution_default_137, primals_422, primals_420, primals_421, getitem_258, getitem_259, True, 1e-05, [True, True, True]);  to_dtype_356 = convolution_default_137 = primals_422 = primals_420 = primals_421 = getitem_258 = getitem_259 = None
        getitem_1043 = native_batch_norm_backward_default_71[0]
        getitem_1044 = native_batch_norm_backward_default_71[1]
        getitem_1045 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1043, relu__default_107, primals_429, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1043 = primals_429 = None
        getitem_1046 = convolution_backward_default_119[0]
        getitem_1047 = convolution_backward_default_119[1]
        getitem_1048 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_1046, torch.float32);  getitem_1046 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_252 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_252, to_dtype_357);  le_scalar_95 = new_zeros_default_252 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_136, primals_417, primals_415, primals_416, getitem_255, getitem_256, True, 1e-05, [True, True, True]);  to_dtype_359 = convolution_default_136 = primals_417 = primals_415 = primals_416 = getitem_255 = getitem_256 = None
        getitem_1049 = native_batch_norm_backward_default_72[0]
        getitem_1050 = native_batch_norm_backward_default_72[1]
        getitem_1051 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1049, relu__default_106, primals_428, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1049 = primals_428 = None
        getitem_1052 = convolution_backward_default_120[0]
        getitem_1053 = convolution_backward_default_120[1]
        getitem_1054 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(to_dtype_347, getitem_1052);  to_dtype_347 = getitem_1052 = None
        to_dtype_360 = torch.ops.aten.to.dtype(add_tensor_47, torch.float32);  add_tensor_47 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_253 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_253, to_dtype_360);  le_scalar_96 = new_zeros_default_253 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(to_dtype_362, getitem_251);  getitem_251 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(to_dtype_362, sigmoid_default_25)
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(mul_tensor_146, [2, 3], True);  mul_tensor_146 = None
        to_dtype_363 = torch.ops.aten.to.dtype(sum_dim_int_list_25, torch.float32);  sum_dim_int_list_25 = None
        to_dtype_364 = torch.ops.aten.to.dtype(sigmoid_default_25, torch.float32);  sigmoid_default_25 = None
        rsub_scalar_24 = torch.ops.aten.rsub.Scalar(to_dtype_364, 1)
        mul_tensor_148 = torch.ops.aten.mul.Tensor(to_dtype_364, rsub_scalar_24);  to_dtype_364 = rsub_scalar_24 = None
        conj_physical_default_24 = torch.ops.aten.conj_physical.default(mul_tensor_148);  mul_tensor_148 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_363, conj_physical_default_24);  to_dtype_363 = conj_physical_default_24 = None
        to_dtype_365 = torch.ops.aten.to.dtype(mul_tensor_149, torch.float32);  mul_tensor_149 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(to_dtype_365, relu__default_105, primals_412, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_365 = primals_412 = None
        getitem_1055 = convolution_backward_default_121[0]
        getitem_1056 = convolution_backward_default_121[1]
        getitem_1057 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        to_dtype_366 = torch.ops.aten.to.dtype(getitem_1055, torch.float32);  getitem_1055 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_254 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_254, to_dtype_366);  le_scalar_97 = new_zeros_default_254 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(to_dtype_368, mean_dim_25, primals_410, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_368 = mean_dim_25 = primals_410 = None
        getitem_1058 = convolution_backward_default_122[0]
        getitem_1059 = convolution_backward_default_122[1]
        getitem_1060 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        expand_default_25 = torch.ops.aten.expand.default(getitem_1058, [64, 1024, 20, 20]);  getitem_1058 = None
        div_scalar_25 = torch.ops.aten.div.Scalar(expand_default_25, 400);  expand_default_25 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(mul_tensor_147, div_scalar_25);  mul_tensor_147 = div_scalar_25 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_48, convolution_default_133, primals_405, primals_403, primals_404, getitem_252, getitem_253, True, 1e-05, [True, True, True]);  add_tensor_48 = convolution_default_133 = primals_405 = primals_403 = primals_404 = getitem_252 = getitem_253 = None
        getitem_1061 = native_batch_norm_backward_default_73[0]
        getitem_1062 = native_batch_norm_backward_default_73[1]
        getitem_1063 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1061, relu__default_104, primals_408, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1061 = primals_408 = None
        getitem_1064 = convolution_backward_default_123[0]
        getitem_1065 = convolution_backward_default_123[1]
        getitem_1066 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        to_dtype_369 = torch.ops.aten.to.dtype(getitem_1064, torch.float32);  getitem_1064 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_255 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_255, to_dtype_369);  le_scalar_98 = new_zeros_default_255 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_132, primals_400, primals_398, primals_399, getitem_249, getitem_250, True, 1e-05, [True, True, True]);  to_dtype_371 = convolution_default_132 = primals_400 = primals_398 = primals_399 = getitem_249 = getitem_250 = None
        getitem_1067 = native_batch_norm_backward_default_74[0]
        getitem_1068 = native_batch_norm_backward_default_74[1]
        getitem_1069 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1067, relu__default_103, primals_407, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1067 = primals_407 = None
        getitem_1070 = convolution_backward_default_124[0]
        getitem_1071 = convolution_backward_default_124[1]
        getitem_1072 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        to_dtype_372 = torch.ops.aten.to.dtype(getitem_1070, torch.float32);  getitem_1070 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_256 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_256, to_dtype_372);  le_scalar_99 = new_zeros_default_256 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_374, convolution_default_131, primals_395, primals_393, primals_394, getitem_246, getitem_247, True, 1e-05, [True, True, True]);  to_dtype_374 = convolution_default_131 = primals_395 = primals_393 = primals_394 = getitem_246 = getitem_247 = None
        getitem_1073 = native_batch_norm_backward_default_75[0]
        getitem_1074 = native_batch_norm_backward_default_75[1]
        getitem_1075 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1073, relu__default_102, primals_406, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1073 = primals_406 = None
        getitem_1076 = convolution_backward_default_125[0]
        getitem_1077 = convolution_backward_default_125[1]
        getitem_1078 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(to_dtype_362, getitem_1076);  to_dtype_362 = getitem_1076 = None
        to_dtype_375 = torch.ops.aten.to.dtype(add_tensor_49, torch.float32);  add_tensor_49 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_257 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_257, to_dtype_375);  le_scalar_100 = new_zeros_default_257 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(to_dtype_377, getitem_242);  getitem_242 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(to_dtype_377, sigmoid_default_24)
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(mul_tensor_150, [2, 3], True);  mul_tensor_150 = None
        to_dtype_378 = torch.ops.aten.to.dtype(sum_dim_int_list_26, torch.float32);  sum_dim_int_list_26 = None
        to_dtype_379 = torch.ops.aten.to.dtype(sigmoid_default_24, torch.float32);  sigmoid_default_24 = None
        rsub_scalar_25 = torch.ops.aten.rsub.Scalar(to_dtype_379, 1)
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_379, rsub_scalar_25);  to_dtype_379 = rsub_scalar_25 = None
        conj_physical_default_25 = torch.ops.aten.conj_physical.default(mul_tensor_152);  mul_tensor_152 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_378, conj_physical_default_25);  to_dtype_378 = conj_physical_default_25 = None
        to_dtype_380 = torch.ops.aten.to.dtype(mul_tensor_153, torch.float32);  mul_tensor_153 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(to_dtype_380, relu__default_101, primals_390, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_380 = primals_390 = None
        getitem_1079 = convolution_backward_default_126[0]
        getitem_1080 = convolution_backward_default_126[1]
        getitem_1081 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_1079, torch.float32);  getitem_1079 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_258 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_258, to_dtype_381);  le_scalar_101 = new_zeros_default_258 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(to_dtype_383, mean_dim_24, primals_388, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_383 = mean_dim_24 = primals_388 = None
        getitem_1082 = convolution_backward_default_127[0]
        getitem_1083 = convolution_backward_default_127[1]
        getitem_1084 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        expand_default_26 = torch.ops.aten.expand.default(getitem_1082, [64, 1024, 20, 20]);  getitem_1082 = None
        div_scalar_26 = torch.ops.aten.div.Scalar(expand_default_26, 400);  expand_default_26 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(mul_tensor_151, div_scalar_26);  mul_tensor_151 = div_scalar_26 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_50, convolution_default_128, primals_383, primals_381, primals_382, getitem_243, getitem_244, True, 1e-05, [True, True, True]);  add_tensor_50 = convolution_default_128 = primals_383 = primals_381 = primals_382 = getitem_243 = getitem_244 = None
        getitem_1085 = native_batch_norm_backward_default_76[0]
        getitem_1086 = native_batch_norm_backward_default_76[1]
        getitem_1087 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1085, relu__default_100, primals_386, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1085 = primals_386 = None
        getitem_1088 = convolution_backward_default_128[0]
        getitem_1089 = convolution_backward_default_128[1]
        getitem_1090 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        to_dtype_384 = torch.ops.aten.to.dtype(getitem_1088, torch.float32);  getitem_1088 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_259 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_259, to_dtype_384);  le_scalar_102 = new_zeros_default_259 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_127, primals_378, primals_376, primals_377, getitem_240, getitem_241, True, 1e-05, [True, True, True]);  to_dtype_386 = convolution_default_127 = primals_378 = primals_376 = primals_377 = getitem_240 = getitem_241 = None
        getitem_1091 = native_batch_norm_backward_default_77[0]
        getitem_1092 = native_batch_norm_backward_default_77[1]
        getitem_1093 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1091, relu__default_99, primals_385, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1091 = primals_385 = None
        getitem_1094 = convolution_backward_default_129[0]
        getitem_1095 = convolution_backward_default_129[1]
        getitem_1096 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        to_dtype_387 = torch.ops.aten.to.dtype(getitem_1094, torch.float32);  getitem_1094 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_260 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_260, to_dtype_387);  le_scalar_103 = new_zeros_default_260 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_126, primals_373, primals_371, primals_372, getitem_237, getitem_238, True, 1e-05, [True, True, True]);  to_dtype_389 = convolution_default_126 = primals_373 = primals_371 = primals_372 = getitem_237 = getitem_238 = None
        getitem_1097 = native_batch_norm_backward_default_78[0]
        getitem_1098 = native_batch_norm_backward_default_78[1]
        getitem_1099 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1097, relu__default_98, primals_384, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1097 = primals_384 = None
        getitem_1100 = convolution_backward_default_130[0]
        getitem_1101 = convolution_backward_default_130[1]
        getitem_1102 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(to_dtype_377, getitem_1100);  to_dtype_377 = getitem_1100 = None
        to_dtype_390 = torch.ops.aten.to.dtype(add_tensor_51, torch.float32);  add_tensor_51 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_261 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_261, to_dtype_390);  le_scalar_104 = new_zeros_default_261 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(to_dtype_392, getitem_233);  getitem_233 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(to_dtype_392, sigmoid_default_23)
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(mul_tensor_154, [2, 3], True);  mul_tensor_154 = None
        to_dtype_393 = torch.ops.aten.to.dtype(sum_dim_int_list_27, torch.float32);  sum_dim_int_list_27 = None
        to_dtype_394 = torch.ops.aten.to.dtype(sigmoid_default_23, torch.float32);  sigmoid_default_23 = None
        rsub_scalar_26 = torch.ops.aten.rsub.Scalar(to_dtype_394, 1)
        mul_tensor_156 = torch.ops.aten.mul.Tensor(to_dtype_394, rsub_scalar_26);  to_dtype_394 = rsub_scalar_26 = None
        conj_physical_default_26 = torch.ops.aten.conj_physical.default(mul_tensor_156);  mul_tensor_156 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_393, conj_physical_default_26);  to_dtype_393 = conj_physical_default_26 = None
        to_dtype_395 = torch.ops.aten.to.dtype(mul_tensor_157, torch.float32);  mul_tensor_157 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(to_dtype_395, relu__default_97, primals_368, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_395 = primals_368 = None
        getitem_1103 = convolution_backward_default_131[0]
        getitem_1104 = convolution_backward_default_131[1]
        getitem_1105 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        to_dtype_396 = torch.ops.aten.to.dtype(getitem_1103, torch.float32);  getitem_1103 = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_262 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_262, to_dtype_396);  le_scalar_105 = new_zeros_default_262 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(to_dtype_398, mean_dim_23, primals_366, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_398 = mean_dim_23 = primals_366 = None
        getitem_1106 = convolution_backward_default_132[0]
        getitem_1107 = convolution_backward_default_132[1]
        getitem_1108 = convolution_backward_default_132[2];  convolution_backward_default_132 = None
        expand_default_27 = torch.ops.aten.expand.default(getitem_1106, [64, 1024, 20, 20]);  getitem_1106 = None
        div_scalar_27 = torch.ops.aten.div.Scalar(expand_default_27, 400);  expand_default_27 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(mul_tensor_155, div_scalar_27);  mul_tensor_155 = div_scalar_27 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_52, convolution_default_123, primals_361, primals_359, primals_360, getitem_234, getitem_235, True, 1e-05, [True, True, True]);  add_tensor_52 = convolution_default_123 = primals_361 = primals_359 = primals_360 = getitem_234 = getitem_235 = None
        getitem_1109 = native_batch_norm_backward_default_79[0]
        getitem_1110 = native_batch_norm_backward_default_79[1]
        getitem_1111 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1109, relu__default_96, primals_364, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1109 = primals_364 = None
        getitem_1112 = convolution_backward_default_133[0]
        getitem_1113 = convolution_backward_default_133[1]
        getitem_1114 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_1112, torch.float32);  getitem_1112 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_263 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_263, to_dtype_399);  le_scalar_106 = new_zeros_default_263 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_122, primals_356, primals_354, primals_355, getitem_231, getitem_232, True, 1e-05, [True, True, True]);  to_dtype_401 = convolution_default_122 = primals_356 = primals_354 = primals_355 = getitem_231 = getitem_232 = None
        getitem_1115 = native_batch_norm_backward_default_80[0]
        getitem_1116 = native_batch_norm_backward_default_80[1]
        getitem_1117 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1115, relu__default_95, primals_363, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1115 = primals_363 = None
        getitem_1118 = convolution_backward_default_134[0]
        getitem_1119 = convolution_backward_default_134[1]
        getitem_1120 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        to_dtype_402 = torch.ops.aten.to.dtype(getitem_1118, torch.float32);  getitem_1118 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_264, to_dtype_402);  le_scalar_107 = new_zeros_default_264 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_404, convolution_default_121, primals_351, primals_349, primals_350, getitem_228, getitem_229, True, 1e-05, [True, True, True]);  to_dtype_404 = convolution_default_121 = primals_351 = primals_349 = primals_350 = getitem_228 = getitem_229 = None
        getitem_1121 = native_batch_norm_backward_default_81[0]
        getitem_1122 = native_batch_norm_backward_default_81[1]
        getitem_1123 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1121, relu__default_94, primals_362, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1121 = primals_362 = None
        getitem_1124 = convolution_backward_default_135[0]
        getitem_1125 = convolution_backward_default_135[1]
        getitem_1126 = convolution_backward_default_135[2];  convolution_backward_default_135 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(to_dtype_392, getitem_1124);  to_dtype_392 = getitem_1124 = None
        to_dtype_405 = torch.ops.aten.to.dtype(add_tensor_53, torch.float32);  add_tensor_53 = None
        to_dtype_406 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_406, 0);  to_dtype_406 = None
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(to_dtype_405, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_265, to_dtype_405);  le_scalar_108 = new_zeros_default_265 = to_dtype_405 = None
        to_dtype_407 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(to_dtype_407, getitem_224);  getitem_224 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(to_dtype_407, sigmoid_default_22)
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(mul_tensor_158, [2, 3], True);  mul_tensor_158 = None
        to_dtype_408 = torch.ops.aten.to.dtype(sum_dim_int_list_28, torch.float32);  sum_dim_int_list_28 = None
        to_dtype_409 = torch.ops.aten.to.dtype(sigmoid_default_22, torch.float32);  sigmoid_default_22 = None
        rsub_scalar_27 = torch.ops.aten.rsub.Scalar(to_dtype_409, 1)
        mul_tensor_160 = torch.ops.aten.mul.Tensor(to_dtype_409, rsub_scalar_27);  to_dtype_409 = rsub_scalar_27 = None
        conj_physical_default_27 = torch.ops.aten.conj_physical.default(mul_tensor_160);  mul_tensor_160 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(to_dtype_408, conj_physical_default_27);  to_dtype_408 = conj_physical_default_27 = None
        to_dtype_410 = torch.ops.aten.to.dtype(mul_tensor_161, torch.float32);  mul_tensor_161 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(to_dtype_410, relu__default_93, primals_346, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_410 = primals_346 = None
        getitem_1127 = convolution_backward_default_136[0]
        getitem_1128 = convolution_backward_default_136[1]
        getitem_1129 = convolution_backward_default_136[2];  convolution_backward_default_136 = None
        to_dtype_411 = torch.ops.aten.to.dtype(getitem_1127, torch.float32);  getitem_1127 = None
        to_dtype_412 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_412, 0);  to_dtype_412 = None
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(to_dtype_411, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_266, to_dtype_411);  le_scalar_109 = new_zeros_default_266 = to_dtype_411 = None
        to_dtype_413 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(to_dtype_413, mean_dim_22, primals_344, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_413 = mean_dim_22 = primals_344 = None
        getitem_1130 = convolution_backward_default_137[0]
        getitem_1131 = convolution_backward_default_137[1]
        getitem_1132 = convolution_backward_default_137[2];  convolution_backward_default_137 = None
        expand_default_28 = torch.ops.aten.expand.default(getitem_1130, [64, 1024, 20, 20]);  getitem_1130 = None
        div_scalar_28 = torch.ops.aten.div.Scalar(expand_default_28, 400);  expand_default_28 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(mul_tensor_159, div_scalar_28);  mul_tensor_159 = div_scalar_28 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_54, convolution_default_118, primals_339, primals_337, primals_338, getitem_225, getitem_226, True, 1e-05, [True, True, True]);  add_tensor_54 = convolution_default_118 = primals_339 = primals_337 = primals_338 = getitem_225 = getitem_226 = None
        getitem_1133 = native_batch_norm_backward_default_82[0]
        getitem_1134 = native_batch_norm_backward_default_82[1]
        getitem_1135 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1133, relu__default_92, primals_342, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1133 = primals_342 = None
        getitem_1136 = convolution_backward_default_138[0]
        getitem_1137 = convolution_backward_default_138[1]
        getitem_1138 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        to_dtype_414 = torch.ops.aten.to.dtype(getitem_1136, torch.float32);  getitem_1136 = None
        to_dtype_415 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_415, 0);  to_dtype_415 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(to_dtype_414, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_267, to_dtype_414);  le_scalar_110 = new_zeros_default_267 = to_dtype_414 = None
        to_dtype_416 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_416, convolution_default_117, primals_334, primals_332, primals_333, getitem_222, getitem_223, True, 1e-05, [True, True, True]);  to_dtype_416 = convolution_default_117 = primals_334 = primals_332 = primals_333 = getitem_222 = getitem_223 = None
        getitem_1139 = native_batch_norm_backward_default_83[0]
        getitem_1140 = native_batch_norm_backward_default_83[1]
        getitem_1141 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1139, relu__default_91, primals_341, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1139 = primals_341 = None
        getitem_1142 = convolution_backward_default_139[0]
        getitem_1143 = convolution_backward_default_139[1]
        getitem_1144 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        to_dtype_417 = torch.ops.aten.to.dtype(getitem_1142, torch.float32);  getitem_1142 = None
        to_dtype_418 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_418, 0);  to_dtype_418 = None
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(to_dtype_417, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_268, to_dtype_417);  le_scalar_111 = new_zeros_default_268 = to_dtype_417 = None
        to_dtype_419 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_419, convolution_default_116, primals_329, primals_327, primals_328, getitem_219, getitem_220, True, 1e-05, [True, True, True]);  to_dtype_419 = convolution_default_116 = primals_329 = primals_327 = primals_328 = getitem_219 = getitem_220 = None
        getitem_1145 = native_batch_norm_backward_default_84[0]
        getitem_1146 = native_batch_norm_backward_default_84[1]
        getitem_1147 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1145, relu__default_90, primals_340, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1145 = primals_340 = None
        getitem_1148 = convolution_backward_default_140[0]
        getitem_1149 = convolution_backward_default_140[1]
        getitem_1150 = convolution_backward_default_140[2];  convolution_backward_default_140 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(to_dtype_407, getitem_1148);  to_dtype_407 = getitem_1148 = None
        to_dtype_420 = torch.ops.aten.to.dtype(add_tensor_55, torch.float32);  add_tensor_55 = None
        to_dtype_421 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_421, 0);  to_dtype_421 = None
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(to_dtype_420, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_269, to_dtype_420);  le_scalar_112 = new_zeros_default_269 = to_dtype_420 = None
        to_dtype_422 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        mul_tensor_162 = torch.ops.aten.mul.Tensor(to_dtype_422, getitem_215);  getitem_215 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(to_dtype_422, sigmoid_default_21)
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(mul_tensor_162, [2, 3], True);  mul_tensor_162 = None
        to_dtype_423 = torch.ops.aten.to.dtype(sum_dim_int_list_29, torch.float32);  sum_dim_int_list_29 = None
        to_dtype_424 = torch.ops.aten.to.dtype(sigmoid_default_21, torch.float32);  sigmoid_default_21 = None
        rsub_scalar_28 = torch.ops.aten.rsub.Scalar(to_dtype_424, 1)
        mul_tensor_164 = torch.ops.aten.mul.Tensor(to_dtype_424, rsub_scalar_28);  to_dtype_424 = rsub_scalar_28 = None
        conj_physical_default_28 = torch.ops.aten.conj_physical.default(mul_tensor_164);  mul_tensor_164 = None
        mul_tensor_165 = torch.ops.aten.mul.Tensor(to_dtype_423, conj_physical_default_28);  to_dtype_423 = conj_physical_default_28 = None
        to_dtype_425 = torch.ops.aten.to.dtype(mul_tensor_165, torch.float32);  mul_tensor_165 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(to_dtype_425, relu__default_89, primals_324, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_425 = primals_324 = None
        getitem_1151 = convolution_backward_default_141[0]
        getitem_1152 = convolution_backward_default_141[1]
        getitem_1153 = convolution_backward_default_141[2];  convolution_backward_default_141 = None
        to_dtype_426 = torch.ops.aten.to.dtype(getitem_1151, torch.float32);  getitem_1151 = None
        to_dtype_427 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_427, 0);  to_dtype_427 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(to_dtype_426, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_270, to_dtype_426);  le_scalar_113 = new_zeros_default_270 = to_dtype_426 = None
        to_dtype_428 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(to_dtype_428, mean_dim_21, primals_322, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_428 = mean_dim_21 = primals_322 = None
        getitem_1154 = convolution_backward_default_142[0]
        getitem_1155 = convolution_backward_default_142[1]
        getitem_1156 = convolution_backward_default_142[2];  convolution_backward_default_142 = None
        expand_default_29 = torch.ops.aten.expand.default(getitem_1154, [64, 1024, 20, 20]);  getitem_1154 = None
        div_scalar_29 = torch.ops.aten.div.Scalar(expand_default_29, 400);  expand_default_29 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(mul_tensor_163, div_scalar_29);  mul_tensor_163 = div_scalar_29 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_56, convolution_default_113, primals_317, primals_315, primals_316, getitem_216, getitem_217, True, 1e-05, [True, True, True]);  add_tensor_56 = convolution_default_113 = primals_317 = primals_315 = primals_316 = getitem_216 = getitem_217 = None
        getitem_1157 = native_batch_norm_backward_default_85[0]
        getitem_1158 = native_batch_norm_backward_default_85[1]
        getitem_1159 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(getitem_1157, relu__default_88, primals_320, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1157 = primals_320 = None
        getitem_1160 = convolution_backward_default_143[0]
        getitem_1161 = convolution_backward_default_143[1]
        getitem_1162 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        to_dtype_429 = torch.ops.aten.to.dtype(getitem_1160, torch.float32);  getitem_1160 = None
        to_dtype_430 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_430, 0);  to_dtype_430 = None
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(to_dtype_429, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_271, to_dtype_429);  le_scalar_114 = new_zeros_default_271 = to_dtype_429 = None
        to_dtype_431 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_431, convolution_default_112, primals_312, primals_310, primals_311, getitem_213, getitem_214, True, 1e-05, [True, True, True]);  to_dtype_431 = convolution_default_112 = primals_312 = primals_310 = primals_311 = getitem_213 = getitem_214 = None
        getitem_1163 = native_batch_norm_backward_default_86[0]
        getitem_1164 = native_batch_norm_backward_default_86[1]
        getitem_1165 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1163, relu__default_87, primals_319, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1163 = primals_319 = None
        getitem_1166 = convolution_backward_default_144[0]
        getitem_1167 = convolution_backward_default_144[1]
        getitem_1168 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        to_dtype_432 = torch.ops.aten.to.dtype(getitem_1166, torch.float32);  getitem_1166 = None
        to_dtype_433 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_433, 0);  to_dtype_433 = None
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(to_dtype_432, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_272, to_dtype_432);  le_scalar_115 = new_zeros_default_272 = to_dtype_432 = None
        to_dtype_434 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_434, convolution_default_111, primals_307, primals_305, primals_306, getitem_210, getitem_211, True, 1e-05, [True, True, True]);  to_dtype_434 = convolution_default_111 = primals_307 = primals_305 = primals_306 = getitem_210 = getitem_211 = None
        getitem_1169 = native_batch_norm_backward_default_87[0]
        getitem_1170 = native_batch_norm_backward_default_87[1]
        getitem_1171 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1169, relu__default_86, primals_318, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1169 = primals_318 = None
        getitem_1172 = convolution_backward_default_145[0]
        getitem_1173 = convolution_backward_default_145[1]
        getitem_1174 = convolution_backward_default_145[2];  convolution_backward_default_145 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(to_dtype_422, getitem_1172);  to_dtype_422 = getitem_1172 = None
        to_dtype_435 = torch.ops.aten.to.dtype(add_tensor_57, torch.float32);  add_tensor_57 = None
        to_dtype_436 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_436, 0);  to_dtype_436 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(to_dtype_435, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_273, to_dtype_435);  le_scalar_116 = new_zeros_default_273 = to_dtype_435 = None
        to_dtype_437 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        mul_tensor_166 = torch.ops.aten.mul.Tensor(to_dtype_437, getitem_206);  getitem_206 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(to_dtype_437, sigmoid_default_20)
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(mul_tensor_166, [2, 3], True);  mul_tensor_166 = None
        to_dtype_438 = torch.ops.aten.to.dtype(sum_dim_int_list_30, torch.float32);  sum_dim_int_list_30 = None
        to_dtype_439 = torch.ops.aten.to.dtype(sigmoid_default_20, torch.float32);  sigmoid_default_20 = None
        rsub_scalar_29 = torch.ops.aten.rsub.Scalar(to_dtype_439, 1)
        mul_tensor_168 = torch.ops.aten.mul.Tensor(to_dtype_439, rsub_scalar_29);  to_dtype_439 = rsub_scalar_29 = None
        conj_physical_default_29 = torch.ops.aten.conj_physical.default(mul_tensor_168);  mul_tensor_168 = None
        mul_tensor_169 = torch.ops.aten.mul.Tensor(to_dtype_438, conj_physical_default_29);  to_dtype_438 = conj_physical_default_29 = None
        to_dtype_440 = torch.ops.aten.to.dtype(mul_tensor_169, torch.float32);  mul_tensor_169 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(to_dtype_440, relu__default_85, primals_1072, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_440 = primals_1072 = None
        getitem_1175 = convolution_backward_default_146[0]
        getitem_1176 = convolution_backward_default_146[1]
        getitem_1177 = convolution_backward_default_146[2];  convolution_backward_default_146 = None
        to_dtype_441 = torch.ops.aten.to.dtype(getitem_1175, torch.float32);  getitem_1175 = None
        to_dtype_442 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_442, 0);  to_dtype_442 = None
        new_zeros_default_274 = torch.ops.aten.new_zeros.default(to_dtype_441, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_274, to_dtype_441);  le_scalar_117 = new_zeros_default_274 = to_dtype_441 = None
        to_dtype_443 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(to_dtype_443, mean_dim_20, primals_1070, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_443 = mean_dim_20 = primals_1070 = None
        getitem_1178 = convolution_backward_default_147[0]
        getitem_1179 = convolution_backward_default_147[1]
        getitem_1180 = convolution_backward_default_147[2];  convolution_backward_default_147 = None
        expand_default_30 = torch.ops.aten.expand.default(getitem_1178, [64, 1024, 20, 20]);  getitem_1178 = None
        div_scalar_30 = torch.ops.aten.div.Scalar(expand_default_30, 400);  expand_default_30 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(mul_tensor_167, div_scalar_30);  mul_tensor_167 = div_scalar_30 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_58, convolution_default_108, primals_1065, primals_1063, primals_1064, getitem_207, getitem_208, True, 1e-05, [True, True, True]);  add_tensor_58 = convolution_default_108 = primals_1065 = primals_1063 = primals_1064 = getitem_207 = getitem_208 = None
        getitem_1181 = native_batch_norm_backward_default_88[0]
        getitem_1182 = native_batch_norm_backward_default_88[1]
        getitem_1183 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1181, relu__default_84, primals_1068, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1181 = primals_1068 = None
        getitem_1184 = convolution_backward_default_148[0]
        getitem_1185 = convolution_backward_default_148[1]
        getitem_1186 = convolution_backward_default_148[2];  convolution_backward_default_148 = None
        to_dtype_444 = torch.ops.aten.to.dtype(getitem_1184, torch.float32);  getitem_1184 = None
        to_dtype_445 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_445, 0);  to_dtype_445 = None
        new_zeros_default_275 = torch.ops.aten.new_zeros.default(to_dtype_444, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_275, to_dtype_444);  le_scalar_118 = new_zeros_default_275 = to_dtype_444 = None
        to_dtype_446 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_446, convolution_default_107, primals_1060, primals_1058, primals_1059, getitem_204, getitem_205, True, 1e-05, [True, True, True]);  to_dtype_446 = convolution_default_107 = primals_1060 = primals_1058 = primals_1059 = getitem_204 = getitem_205 = None
        getitem_1187 = native_batch_norm_backward_default_89[0]
        getitem_1188 = native_batch_norm_backward_default_89[1]
        getitem_1189 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(getitem_1187, relu__default_83, primals_1067, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1187 = primals_1067 = None
        getitem_1190 = convolution_backward_default_149[0]
        getitem_1191 = convolution_backward_default_149[1]
        getitem_1192 = convolution_backward_default_149[2];  convolution_backward_default_149 = None
        to_dtype_447 = torch.ops.aten.to.dtype(getitem_1190, torch.float32);  getitem_1190 = None
        to_dtype_448 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_448, 0);  to_dtype_448 = None
        new_zeros_default_276 = torch.ops.aten.new_zeros.default(to_dtype_447, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_276, to_dtype_447);  le_scalar_119 = new_zeros_default_276 = to_dtype_447 = None
        to_dtype_449 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_449, convolution_default_106, primals_1055, primals_1053, primals_1054, getitem_201, getitem_202, True, 1e-05, [True, True, True]);  to_dtype_449 = convolution_default_106 = primals_1055 = primals_1053 = primals_1054 = getitem_201 = getitem_202 = None
        getitem_1193 = native_batch_norm_backward_default_90[0]
        getitem_1194 = native_batch_norm_backward_default_90[1]
        getitem_1195 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(getitem_1193, relu__default_82, primals_1066, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1193 = primals_1066 = None
        getitem_1196 = convolution_backward_default_150[0]
        getitem_1197 = convolution_backward_default_150[1]
        getitem_1198 = convolution_backward_default_150[2];  convolution_backward_default_150 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(to_dtype_437, getitem_1196);  to_dtype_437 = getitem_1196 = None
        to_dtype_450 = torch.ops.aten.to.dtype(add_tensor_59, torch.float32);  add_tensor_59 = None
        to_dtype_451 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_451, 0);  to_dtype_451 = None
        new_zeros_default_277 = torch.ops.aten.new_zeros.default(to_dtype_450, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_277, to_dtype_450);  le_scalar_120 = new_zeros_default_277 = to_dtype_450 = None
        to_dtype_452 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        mul_tensor_170 = torch.ops.aten.mul.Tensor(to_dtype_452, getitem_197);  getitem_197 = None
        mul_tensor_171 = torch.ops.aten.mul.Tensor(to_dtype_452, sigmoid_default_19)
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(mul_tensor_170, [2, 3], True);  mul_tensor_170 = None
        to_dtype_453 = torch.ops.aten.to.dtype(sum_dim_int_list_31, torch.float32);  sum_dim_int_list_31 = None
        to_dtype_454 = torch.ops.aten.to.dtype(sigmoid_default_19, torch.float32);  sigmoid_default_19 = None
        rsub_scalar_30 = torch.ops.aten.rsub.Scalar(to_dtype_454, 1)
        mul_tensor_172 = torch.ops.aten.mul.Tensor(to_dtype_454, rsub_scalar_30);  to_dtype_454 = rsub_scalar_30 = None
        conj_physical_default_30 = torch.ops.aten.conj_physical.default(mul_tensor_172);  mul_tensor_172 = None
        mul_tensor_173 = torch.ops.aten.mul.Tensor(to_dtype_453, conj_physical_default_30);  to_dtype_453 = conj_physical_default_30 = None
        to_dtype_455 = torch.ops.aten.to.dtype(mul_tensor_173, torch.float32);  mul_tensor_173 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(to_dtype_455, relu__default_81, primals_1050, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_455 = primals_1050 = None
        getitem_1199 = convolution_backward_default_151[0]
        getitem_1200 = convolution_backward_default_151[1]
        getitem_1201 = convolution_backward_default_151[2];  convolution_backward_default_151 = None
        to_dtype_456 = torch.ops.aten.to.dtype(getitem_1199, torch.float32);  getitem_1199 = None
        to_dtype_457 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_457, 0);  to_dtype_457 = None
        new_zeros_default_278 = torch.ops.aten.new_zeros.default(to_dtype_456, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_278, to_dtype_456);  le_scalar_121 = new_zeros_default_278 = to_dtype_456 = None
        to_dtype_458 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(to_dtype_458, mean_dim_19, primals_1048, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_458 = mean_dim_19 = primals_1048 = None
        getitem_1202 = convolution_backward_default_152[0]
        getitem_1203 = convolution_backward_default_152[1]
        getitem_1204 = convolution_backward_default_152[2];  convolution_backward_default_152 = None
        expand_default_31 = torch.ops.aten.expand.default(getitem_1202, [64, 1024, 20, 20]);  getitem_1202 = None
        div_scalar_31 = torch.ops.aten.div.Scalar(expand_default_31, 400);  expand_default_31 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(mul_tensor_171, div_scalar_31);  mul_tensor_171 = div_scalar_31 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_60, convolution_default_103, primals_1043, primals_1041, primals_1042, getitem_198, getitem_199, True, 1e-05, [True, True, True]);  add_tensor_60 = convolution_default_103 = primals_1043 = primals_1041 = primals_1042 = getitem_198 = getitem_199 = None
        getitem_1205 = native_batch_norm_backward_default_91[0]
        getitem_1206 = native_batch_norm_backward_default_91[1]
        getitem_1207 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_1205, relu__default_80, primals_1046, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1205 = primals_1046 = None
        getitem_1208 = convolution_backward_default_153[0]
        getitem_1209 = convolution_backward_default_153[1]
        getitem_1210 = convolution_backward_default_153[2];  convolution_backward_default_153 = None
        to_dtype_459 = torch.ops.aten.to.dtype(getitem_1208, torch.float32);  getitem_1208 = None
        to_dtype_460 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_460, 0);  to_dtype_460 = None
        new_zeros_default_279 = torch.ops.aten.new_zeros.default(to_dtype_459, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_279, to_dtype_459);  le_scalar_122 = new_zeros_default_279 = to_dtype_459 = None
        to_dtype_461 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_461, convolution_default_102, primals_1038, primals_1036, primals_1037, getitem_195, getitem_196, True, 1e-05, [True, True, True]);  to_dtype_461 = convolution_default_102 = primals_1038 = primals_1036 = primals_1037 = getitem_195 = getitem_196 = None
        getitem_1211 = native_batch_norm_backward_default_92[0]
        getitem_1212 = native_batch_norm_backward_default_92[1]
        getitem_1213 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(getitem_1211, relu__default_79, primals_1045, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1211 = primals_1045 = None
        getitem_1214 = convolution_backward_default_154[0]
        getitem_1215 = convolution_backward_default_154[1]
        getitem_1216 = convolution_backward_default_154[2];  convolution_backward_default_154 = None
        to_dtype_462 = torch.ops.aten.to.dtype(getitem_1214, torch.float32);  getitem_1214 = None
        to_dtype_463 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_463, 0);  to_dtype_463 = None
        new_zeros_default_280 = torch.ops.aten.new_zeros.default(to_dtype_462, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_280, to_dtype_462);  le_scalar_123 = new_zeros_default_280 = to_dtype_462 = None
        to_dtype_464 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_464, convolution_default_101, primals_1033, primals_1031, primals_1032, getitem_192, getitem_193, True, 1e-05, [True, True, True]);  to_dtype_464 = convolution_default_101 = primals_1033 = primals_1031 = primals_1032 = getitem_192 = getitem_193 = None
        getitem_1217 = native_batch_norm_backward_default_93[0]
        getitem_1218 = native_batch_norm_backward_default_93[1]
        getitem_1219 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_155 = torch.ops.aten.convolution_backward.default(getitem_1217, relu__default_78, primals_1044, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1217 = primals_1044 = None
        getitem_1220 = convolution_backward_default_155[0]
        getitem_1221 = convolution_backward_default_155[1]
        getitem_1222 = convolution_backward_default_155[2];  convolution_backward_default_155 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(to_dtype_452, getitem_1220);  to_dtype_452 = getitem_1220 = None
        to_dtype_465 = torch.ops.aten.to.dtype(add_tensor_61, torch.float32);  add_tensor_61 = None
        to_dtype_466 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_466, 0);  to_dtype_466 = None
        new_zeros_default_281 = torch.ops.aten.new_zeros.default(to_dtype_465, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_281, to_dtype_465);  le_scalar_124 = new_zeros_default_281 = to_dtype_465 = None
        to_dtype_467 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        mul_tensor_174 = torch.ops.aten.mul.Tensor(to_dtype_467, getitem_188);  getitem_188 = None
        mul_tensor_175 = torch.ops.aten.mul.Tensor(to_dtype_467, sigmoid_default_18)
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(mul_tensor_174, [2, 3], True);  mul_tensor_174 = None
        to_dtype_468 = torch.ops.aten.to.dtype(sum_dim_int_list_32, torch.float32);  sum_dim_int_list_32 = None
        to_dtype_469 = torch.ops.aten.to.dtype(sigmoid_default_18, torch.float32);  sigmoid_default_18 = None
        rsub_scalar_31 = torch.ops.aten.rsub.Scalar(to_dtype_469, 1)
        mul_tensor_176 = torch.ops.aten.mul.Tensor(to_dtype_469, rsub_scalar_31);  to_dtype_469 = rsub_scalar_31 = None
        conj_physical_default_31 = torch.ops.aten.conj_physical.default(mul_tensor_176);  mul_tensor_176 = None
        mul_tensor_177 = torch.ops.aten.mul.Tensor(to_dtype_468, conj_physical_default_31);  to_dtype_468 = conj_physical_default_31 = None
        to_dtype_470 = torch.ops.aten.to.dtype(mul_tensor_177, torch.float32);  mul_tensor_177 = None
        convolution_backward_default_156 = torch.ops.aten.convolution_backward.default(to_dtype_470, relu__default_77, primals_1028, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_470 = primals_1028 = None
        getitem_1223 = convolution_backward_default_156[0]
        getitem_1224 = convolution_backward_default_156[1]
        getitem_1225 = convolution_backward_default_156[2];  convolution_backward_default_156 = None
        to_dtype_471 = torch.ops.aten.to.dtype(getitem_1223, torch.float32);  getitem_1223 = None
        to_dtype_472 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_472, 0);  to_dtype_472 = None
        new_zeros_default_282 = torch.ops.aten.new_zeros.default(to_dtype_471, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_282, to_dtype_471);  le_scalar_125 = new_zeros_default_282 = to_dtype_471 = None
        to_dtype_473 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        convolution_backward_default_157 = torch.ops.aten.convolution_backward.default(to_dtype_473, mean_dim_18, primals_1026, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_473 = mean_dim_18 = primals_1026 = None
        getitem_1226 = convolution_backward_default_157[0]
        getitem_1227 = convolution_backward_default_157[1]
        getitem_1228 = convolution_backward_default_157[2];  convolution_backward_default_157 = None
        expand_default_32 = torch.ops.aten.expand.default(getitem_1226, [64, 1024, 20, 20]);  getitem_1226 = None
        div_scalar_32 = torch.ops.aten.div.Scalar(expand_default_32, 400);  expand_default_32 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(mul_tensor_175, div_scalar_32);  mul_tensor_175 = div_scalar_32 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_62, convolution_default_98, primals_1021, primals_1019, primals_1020, getitem_189, getitem_190, True, 1e-05, [True, True, True]);  add_tensor_62 = convolution_default_98 = primals_1021 = primals_1019 = primals_1020 = getitem_189 = getitem_190 = None
        getitem_1229 = native_batch_norm_backward_default_94[0]
        getitem_1230 = native_batch_norm_backward_default_94[1]
        getitem_1231 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_158 = torch.ops.aten.convolution_backward.default(getitem_1229, relu__default_76, primals_1024, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1229 = primals_1024 = None
        getitem_1232 = convolution_backward_default_158[0]
        getitem_1233 = convolution_backward_default_158[1]
        getitem_1234 = convolution_backward_default_158[2];  convolution_backward_default_158 = None
        to_dtype_474 = torch.ops.aten.to.dtype(getitem_1232, torch.float32);  getitem_1232 = None
        to_dtype_475 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_475, 0);  to_dtype_475 = None
        new_zeros_default_283 = torch.ops.aten.new_zeros.default(to_dtype_474, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_283, to_dtype_474);  le_scalar_126 = new_zeros_default_283 = to_dtype_474 = None
        to_dtype_476 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_476, convolution_default_97, primals_1016, primals_1014, primals_1015, getitem_186, getitem_187, True, 1e-05, [True, True, True]);  to_dtype_476 = convolution_default_97 = primals_1016 = primals_1014 = primals_1015 = getitem_186 = getitem_187 = None
        getitem_1235 = native_batch_norm_backward_default_95[0]
        getitem_1236 = native_batch_norm_backward_default_95[1]
        getitem_1237 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_159 = torch.ops.aten.convolution_backward.default(getitem_1235, relu__default_75, primals_1023, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1235 = primals_1023 = None
        getitem_1238 = convolution_backward_default_159[0]
        getitem_1239 = convolution_backward_default_159[1]
        getitem_1240 = convolution_backward_default_159[2];  convolution_backward_default_159 = None
        to_dtype_477 = torch.ops.aten.to.dtype(getitem_1238, torch.float32);  getitem_1238 = None
        to_dtype_478 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_478, 0);  to_dtype_478 = None
        new_zeros_default_284 = torch.ops.aten.new_zeros.default(to_dtype_477, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_284, to_dtype_477);  le_scalar_127 = new_zeros_default_284 = to_dtype_477 = None
        to_dtype_479 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_479, convolution_default_96, primals_1011, primals_1009, primals_1010, getitem_183, getitem_184, True, 1e-05, [True, True, True]);  to_dtype_479 = convolution_default_96 = primals_1011 = primals_1009 = primals_1010 = getitem_183 = getitem_184 = None
        getitem_1241 = native_batch_norm_backward_default_96[0]
        getitem_1242 = native_batch_norm_backward_default_96[1]
        getitem_1243 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_160 = torch.ops.aten.convolution_backward.default(getitem_1241, relu__default_74, primals_1022, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1241 = primals_1022 = None
        getitem_1244 = convolution_backward_default_160[0]
        getitem_1245 = convolution_backward_default_160[1]
        getitem_1246 = convolution_backward_default_160[2];  convolution_backward_default_160 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(to_dtype_467, getitem_1244);  to_dtype_467 = getitem_1244 = None
        to_dtype_480 = torch.ops.aten.to.dtype(add_tensor_63, torch.float32);  add_tensor_63 = None
        to_dtype_481 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_481, 0);  to_dtype_481 = None
        new_zeros_default_285 = torch.ops.aten.new_zeros.default(to_dtype_480, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_285, to_dtype_480);  le_scalar_128 = new_zeros_default_285 = to_dtype_480 = None
        to_dtype_482 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        mul_tensor_178 = torch.ops.aten.mul.Tensor(to_dtype_482, getitem_179);  getitem_179 = None
        mul_tensor_179 = torch.ops.aten.mul.Tensor(to_dtype_482, sigmoid_default_17)
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(mul_tensor_178, [2, 3], True);  mul_tensor_178 = None
        to_dtype_483 = torch.ops.aten.to.dtype(sum_dim_int_list_33, torch.float32);  sum_dim_int_list_33 = None
        to_dtype_484 = torch.ops.aten.to.dtype(sigmoid_default_17, torch.float32);  sigmoid_default_17 = None
        rsub_scalar_32 = torch.ops.aten.rsub.Scalar(to_dtype_484, 1)
        mul_tensor_180 = torch.ops.aten.mul.Tensor(to_dtype_484, rsub_scalar_32);  to_dtype_484 = rsub_scalar_32 = None
        conj_physical_default_32 = torch.ops.aten.conj_physical.default(mul_tensor_180);  mul_tensor_180 = None
        mul_tensor_181 = torch.ops.aten.mul.Tensor(to_dtype_483, conj_physical_default_32);  to_dtype_483 = conj_physical_default_32 = None
        to_dtype_485 = torch.ops.aten.to.dtype(mul_tensor_181, torch.float32);  mul_tensor_181 = None
        convolution_backward_default_161 = torch.ops.aten.convolution_backward.default(to_dtype_485, relu__default_73, primals_1006, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_485 = primals_1006 = None
        getitem_1247 = convolution_backward_default_161[0]
        getitem_1248 = convolution_backward_default_161[1]
        getitem_1249 = convolution_backward_default_161[2];  convolution_backward_default_161 = None
        to_dtype_486 = torch.ops.aten.to.dtype(getitem_1247, torch.float32);  getitem_1247 = None
        to_dtype_487 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_487, 0);  to_dtype_487 = None
        new_zeros_default_286 = torch.ops.aten.new_zeros.default(to_dtype_486, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_286, to_dtype_486);  le_scalar_129 = new_zeros_default_286 = to_dtype_486 = None
        to_dtype_488 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        convolution_backward_default_162 = torch.ops.aten.convolution_backward.default(to_dtype_488, mean_dim_17, primals_1004, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_488 = mean_dim_17 = primals_1004 = None
        getitem_1250 = convolution_backward_default_162[0]
        getitem_1251 = convolution_backward_default_162[1]
        getitem_1252 = convolution_backward_default_162[2];  convolution_backward_default_162 = None
        expand_default_33 = torch.ops.aten.expand.default(getitem_1250, [64, 1024, 20, 20]);  getitem_1250 = None
        div_scalar_33 = torch.ops.aten.div.Scalar(expand_default_33, 400);  expand_default_33 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(mul_tensor_179, div_scalar_33);  mul_tensor_179 = div_scalar_33 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_64, convolution_default_93, primals_999, primals_997, primals_998, getitem_180, getitem_181, True, 1e-05, [True, True, True]);  add_tensor_64 = convolution_default_93 = primals_999 = primals_997 = primals_998 = getitem_180 = getitem_181 = None
        getitem_1253 = native_batch_norm_backward_default_97[0]
        getitem_1254 = native_batch_norm_backward_default_97[1]
        getitem_1255 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_163 = torch.ops.aten.convolution_backward.default(getitem_1253, relu__default_72, primals_1002, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1253 = primals_1002 = None
        getitem_1256 = convolution_backward_default_163[0]
        getitem_1257 = convolution_backward_default_163[1]
        getitem_1258 = convolution_backward_default_163[2];  convolution_backward_default_163 = None
        to_dtype_489 = torch.ops.aten.to.dtype(getitem_1256, torch.float32);  getitem_1256 = None
        to_dtype_490 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_490, 0);  to_dtype_490 = None
        new_zeros_default_287 = torch.ops.aten.new_zeros.default(to_dtype_489, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_287, to_dtype_489);  le_scalar_130 = new_zeros_default_287 = to_dtype_489 = None
        to_dtype_491 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_491, convolution_default_92, primals_994, primals_992, primals_993, getitem_177, getitem_178, True, 1e-05, [True, True, True]);  to_dtype_491 = convolution_default_92 = primals_994 = primals_992 = primals_993 = getitem_177 = getitem_178 = None
        getitem_1259 = native_batch_norm_backward_default_98[0]
        getitem_1260 = native_batch_norm_backward_default_98[1]
        getitem_1261 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_164 = torch.ops.aten.convolution_backward.default(getitem_1259, relu__default_71, primals_1001, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1259 = primals_1001 = None
        getitem_1262 = convolution_backward_default_164[0]
        getitem_1263 = convolution_backward_default_164[1]
        getitem_1264 = convolution_backward_default_164[2];  convolution_backward_default_164 = None
        to_dtype_492 = torch.ops.aten.to.dtype(getitem_1262, torch.float32);  getitem_1262 = None
        to_dtype_493 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_493, 0);  to_dtype_493 = None
        new_zeros_default_288 = torch.ops.aten.new_zeros.default(to_dtype_492, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_288, to_dtype_492);  le_scalar_131 = new_zeros_default_288 = to_dtype_492 = None
        to_dtype_494 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_494, convolution_default_91, primals_989, primals_987, primals_988, getitem_174, getitem_175, True, 1e-05, [True, True, True]);  to_dtype_494 = convolution_default_91 = primals_989 = primals_987 = primals_988 = getitem_174 = getitem_175 = None
        getitem_1265 = native_batch_norm_backward_default_99[0]
        getitem_1266 = native_batch_norm_backward_default_99[1]
        getitem_1267 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_165 = torch.ops.aten.convolution_backward.default(getitem_1265, relu__default_70, primals_1000, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1265 = primals_1000 = None
        getitem_1268 = convolution_backward_default_165[0]
        getitem_1269 = convolution_backward_default_165[1]
        getitem_1270 = convolution_backward_default_165[2];  convolution_backward_default_165 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(to_dtype_482, getitem_1268);  to_dtype_482 = getitem_1268 = None
        to_dtype_495 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_496 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_496, 0);  to_dtype_496 = None
        new_zeros_default_289 = torch.ops.aten.new_zeros.default(to_dtype_495, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_289, to_dtype_495);  le_scalar_132 = new_zeros_default_289 = to_dtype_495 = None
        to_dtype_497 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        mul_tensor_182 = torch.ops.aten.mul.Tensor(to_dtype_497, getitem_170);  getitem_170 = None
        mul_tensor_183 = torch.ops.aten.mul.Tensor(to_dtype_497, sigmoid_default_16)
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(mul_tensor_182, [2, 3], True);  mul_tensor_182 = None
        to_dtype_498 = torch.ops.aten.to.dtype(sum_dim_int_list_34, torch.float32);  sum_dim_int_list_34 = None
        to_dtype_499 = torch.ops.aten.to.dtype(sigmoid_default_16, torch.float32);  sigmoid_default_16 = None
        rsub_scalar_33 = torch.ops.aten.rsub.Scalar(to_dtype_499, 1)
        mul_tensor_184 = torch.ops.aten.mul.Tensor(to_dtype_499, rsub_scalar_33);  to_dtype_499 = rsub_scalar_33 = None
        conj_physical_default_33 = torch.ops.aten.conj_physical.default(mul_tensor_184);  mul_tensor_184 = None
        mul_tensor_185 = torch.ops.aten.mul.Tensor(to_dtype_498, conj_physical_default_33);  to_dtype_498 = conj_physical_default_33 = None
        to_dtype_500 = torch.ops.aten.to.dtype(mul_tensor_185, torch.float32);  mul_tensor_185 = None
        convolution_backward_default_166 = torch.ops.aten.convolution_backward.default(to_dtype_500, relu__default_69, primals_984, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_500 = primals_984 = None
        getitem_1271 = convolution_backward_default_166[0]
        getitem_1272 = convolution_backward_default_166[1]
        getitem_1273 = convolution_backward_default_166[2];  convolution_backward_default_166 = None
        to_dtype_501 = torch.ops.aten.to.dtype(getitem_1271, torch.float32);  getitem_1271 = None
        to_dtype_502 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_133 = torch.ops.aten.le.Scalar(to_dtype_502, 0);  to_dtype_502 = None
        new_zeros_default_290 = torch.ops.aten.new_zeros.default(to_dtype_501, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_133 = torch.ops.aten.where.self(le_scalar_133, new_zeros_default_290, to_dtype_501);  le_scalar_133 = new_zeros_default_290 = to_dtype_501 = None
        to_dtype_503 = torch.ops.aten.to.dtype(where_self_133, torch.float32);  where_self_133 = None
        convolution_backward_default_167 = torch.ops.aten.convolution_backward.default(to_dtype_503, mean_dim_16, primals_982, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_503 = mean_dim_16 = primals_982 = None
        getitem_1274 = convolution_backward_default_167[0]
        getitem_1275 = convolution_backward_default_167[1]
        getitem_1276 = convolution_backward_default_167[2];  convolution_backward_default_167 = None
        expand_default_34 = torch.ops.aten.expand.default(getitem_1274, [64, 1024, 20, 20]);  getitem_1274 = None
        div_scalar_34 = torch.ops.aten.div.Scalar(expand_default_34, 400);  expand_default_34 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(mul_tensor_183, div_scalar_34);  mul_tensor_183 = div_scalar_34 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_66, convolution_default_88, primals_977, primals_975, primals_976, getitem_171, getitem_172, True, 1e-05, [True, True, True]);  add_tensor_66 = convolution_default_88 = primals_977 = primals_975 = primals_976 = getitem_171 = getitem_172 = None
        getitem_1277 = native_batch_norm_backward_default_100[0]
        getitem_1278 = native_batch_norm_backward_default_100[1]
        getitem_1279 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_168 = torch.ops.aten.convolution_backward.default(getitem_1277, relu__default_68, primals_980, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1277 = primals_980 = None
        getitem_1280 = convolution_backward_default_168[0]
        getitem_1281 = convolution_backward_default_168[1]
        getitem_1282 = convolution_backward_default_168[2];  convolution_backward_default_168 = None
        to_dtype_504 = torch.ops.aten.to.dtype(getitem_1280, torch.float32);  getitem_1280 = None
        to_dtype_505 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_134 = torch.ops.aten.le.Scalar(to_dtype_505, 0);  to_dtype_505 = None
        new_zeros_default_291 = torch.ops.aten.new_zeros.default(to_dtype_504, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_134 = torch.ops.aten.where.self(le_scalar_134, new_zeros_default_291, to_dtype_504);  le_scalar_134 = new_zeros_default_291 = to_dtype_504 = None
        to_dtype_506 = torch.ops.aten.to.dtype(where_self_134, torch.float32);  where_self_134 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_506, convolution_default_87, primals_972, primals_970, primals_971, getitem_168, getitem_169, True, 1e-05, [True, True, True]);  to_dtype_506 = convolution_default_87 = primals_972 = primals_970 = primals_971 = getitem_168 = getitem_169 = None
        getitem_1283 = native_batch_norm_backward_default_101[0]
        getitem_1284 = native_batch_norm_backward_default_101[1]
        getitem_1285 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_169 = torch.ops.aten.convolution_backward.default(getitem_1283, relu__default_67, primals_979, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1283 = primals_979 = None
        getitem_1286 = convolution_backward_default_169[0]
        getitem_1287 = convolution_backward_default_169[1]
        getitem_1288 = convolution_backward_default_169[2];  convolution_backward_default_169 = None
        to_dtype_507 = torch.ops.aten.to.dtype(getitem_1286, torch.float32);  getitem_1286 = None
        to_dtype_508 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_135 = torch.ops.aten.le.Scalar(to_dtype_508, 0);  to_dtype_508 = None
        new_zeros_default_292 = torch.ops.aten.new_zeros.default(to_dtype_507, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_135 = torch.ops.aten.where.self(le_scalar_135, new_zeros_default_292, to_dtype_507);  le_scalar_135 = new_zeros_default_292 = to_dtype_507 = None
        to_dtype_509 = torch.ops.aten.to.dtype(where_self_135, torch.float32);  where_self_135 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_509, convolution_default_86, primals_967, primals_965, primals_966, getitem_165, getitem_166, True, 1e-05, [True, True, True]);  to_dtype_509 = convolution_default_86 = primals_967 = primals_965 = primals_966 = getitem_165 = getitem_166 = None
        getitem_1289 = native_batch_norm_backward_default_102[0]
        getitem_1290 = native_batch_norm_backward_default_102[1]
        getitem_1291 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_170 = torch.ops.aten.convolution_backward.default(getitem_1289, relu__default_66, primals_978, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1289 = primals_978 = None
        getitem_1292 = convolution_backward_default_170[0]
        getitem_1293 = convolution_backward_default_170[1]
        getitem_1294 = convolution_backward_default_170[2];  convolution_backward_default_170 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(to_dtype_497, getitem_1292);  to_dtype_497 = getitem_1292 = None
        to_dtype_510 = torch.ops.aten.to.dtype(add_tensor_67, torch.float32);  add_tensor_67 = None
        to_dtype_511 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_136 = torch.ops.aten.le.Scalar(to_dtype_511, 0);  to_dtype_511 = None
        new_zeros_default_293 = torch.ops.aten.new_zeros.default(to_dtype_510, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_136 = torch.ops.aten.where.self(le_scalar_136, new_zeros_default_293, to_dtype_510);  le_scalar_136 = new_zeros_default_293 = to_dtype_510 = None
        to_dtype_512 = torch.ops.aten.to.dtype(where_self_136, torch.float32);  where_self_136 = None
        mul_tensor_186 = torch.ops.aten.mul.Tensor(to_dtype_512, getitem_161);  getitem_161 = None
        mul_tensor_187 = torch.ops.aten.mul.Tensor(to_dtype_512, sigmoid_default_15)
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(mul_tensor_186, [2, 3], True);  mul_tensor_186 = None
        to_dtype_513 = torch.ops.aten.to.dtype(sum_dim_int_list_35, torch.float32);  sum_dim_int_list_35 = None
        to_dtype_514 = torch.ops.aten.to.dtype(sigmoid_default_15, torch.float32);  sigmoid_default_15 = None
        rsub_scalar_34 = torch.ops.aten.rsub.Scalar(to_dtype_514, 1)
        mul_tensor_188 = torch.ops.aten.mul.Tensor(to_dtype_514, rsub_scalar_34);  to_dtype_514 = rsub_scalar_34 = None
        conj_physical_default_34 = torch.ops.aten.conj_physical.default(mul_tensor_188);  mul_tensor_188 = None
        mul_tensor_189 = torch.ops.aten.mul.Tensor(to_dtype_513, conj_physical_default_34);  to_dtype_513 = conj_physical_default_34 = None
        to_dtype_515 = torch.ops.aten.to.dtype(mul_tensor_189, torch.float32);  mul_tensor_189 = None
        convolution_backward_default_171 = torch.ops.aten.convolution_backward.default(to_dtype_515, relu__default_65, primals_962, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_515 = primals_962 = None
        getitem_1295 = convolution_backward_default_171[0]
        getitem_1296 = convolution_backward_default_171[1]
        getitem_1297 = convolution_backward_default_171[2];  convolution_backward_default_171 = None
        to_dtype_516 = torch.ops.aten.to.dtype(getitem_1295, torch.float32);  getitem_1295 = None
        to_dtype_517 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_137 = torch.ops.aten.le.Scalar(to_dtype_517, 0);  to_dtype_517 = None
        new_zeros_default_294 = torch.ops.aten.new_zeros.default(to_dtype_516, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_137 = torch.ops.aten.where.self(le_scalar_137, new_zeros_default_294, to_dtype_516);  le_scalar_137 = new_zeros_default_294 = to_dtype_516 = None
        to_dtype_518 = torch.ops.aten.to.dtype(where_self_137, torch.float32);  where_self_137 = None
        convolution_backward_default_172 = torch.ops.aten.convolution_backward.default(to_dtype_518, mean_dim_15, primals_960, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_518 = mean_dim_15 = primals_960 = None
        getitem_1298 = convolution_backward_default_172[0]
        getitem_1299 = convolution_backward_default_172[1]
        getitem_1300 = convolution_backward_default_172[2];  convolution_backward_default_172 = None
        expand_default_35 = torch.ops.aten.expand.default(getitem_1298, [64, 1024, 20, 20]);  getitem_1298 = None
        div_scalar_35 = torch.ops.aten.div.Scalar(expand_default_35, 400);  expand_default_35 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(mul_tensor_187, div_scalar_35);  mul_tensor_187 = div_scalar_35 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_68, convolution_default_83, primals_955, primals_953, primals_954, getitem_162, getitem_163, True, 1e-05, [True, True, True]);  add_tensor_68 = convolution_default_83 = primals_955 = primals_953 = primals_954 = getitem_162 = getitem_163 = None
        getitem_1301 = native_batch_norm_backward_default_103[0]
        getitem_1302 = native_batch_norm_backward_default_103[1]
        getitem_1303 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_173 = torch.ops.aten.convolution_backward.default(getitem_1301, relu__default_64, primals_958, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1301 = primals_958 = None
        getitem_1304 = convolution_backward_default_173[0]
        getitem_1305 = convolution_backward_default_173[1]
        getitem_1306 = convolution_backward_default_173[2];  convolution_backward_default_173 = None
        to_dtype_519 = torch.ops.aten.to.dtype(getitem_1304, torch.float32);  getitem_1304 = None
        to_dtype_520 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_138 = torch.ops.aten.le.Scalar(to_dtype_520, 0);  to_dtype_520 = None
        new_zeros_default_295 = torch.ops.aten.new_zeros.default(to_dtype_519, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_138 = torch.ops.aten.where.self(le_scalar_138, new_zeros_default_295, to_dtype_519);  le_scalar_138 = new_zeros_default_295 = to_dtype_519 = None
        to_dtype_521 = torch.ops.aten.to.dtype(where_self_138, torch.float32);  where_self_138 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_521, convolution_default_82, primals_950, primals_948, primals_949, getitem_159, getitem_160, True, 1e-05, [True, True, True]);  to_dtype_521 = convolution_default_82 = primals_950 = primals_948 = primals_949 = getitem_159 = getitem_160 = None
        getitem_1307 = native_batch_norm_backward_default_104[0]
        getitem_1308 = native_batch_norm_backward_default_104[1]
        getitem_1309 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_174 = torch.ops.aten.convolution_backward.default(getitem_1307, relu__default_63, primals_957, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1307 = primals_957 = None
        getitem_1310 = convolution_backward_default_174[0]
        getitem_1311 = convolution_backward_default_174[1]
        getitem_1312 = convolution_backward_default_174[2];  convolution_backward_default_174 = None
        to_dtype_522 = torch.ops.aten.to.dtype(getitem_1310, torch.float32);  getitem_1310 = None
        to_dtype_523 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_139 = torch.ops.aten.le.Scalar(to_dtype_523, 0);  to_dtype_523 = None
        new_zeros_default_296 = torch.ops.aten.new_zeros.default(to_dtype_522, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_139 = torch.ops.aten.where.self(le_scalar_139, new_zeros_default_296, to_dtype_522);  le_scalar_139 = new_zeros_default_296 = to_dtype_522 = None
        to_dtype_524 = torch.ops.aten.to.dtype(where_self_139, torch.float32);  where_self_139 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_524, convolution_default_81, primals_945, primals_943, primals_944, getitem_156, getitem_157, True, 1e-05, [True, True, True]);  to_dtype_524 = convolution_default_81 = primals_945 = primals_943 = primals_944 = getitem_156 = getitem_157 = None
        getitem_1313 = native_batch_norm_backward_default_105[0]
        getitem_1314 = native_batch_norm_backward_default_105[1]
        getitem_1315 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_175 = torch.ops.aten.convolution_backward.default(getitem_1313, relu__default_62, primals_956, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1313 = primals_956 = None
        getitem_1316 = convolution_backward_default_175[0]
        getitem_1317 = convolution_backward_default_175[1]
        getitem_1318 = convolution_backward_default_175[2];  convolution_backward_default_175 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(to_dtype_512, getitem_1316);  to_dtype_512 = getitem_1316 = None
        to_dtype_525 = torch.ops.aten.to.dtype(add_tensor_69, torch.float32);  add_tensor_69 = None
        to_dtype_526 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_140 = torch.ops.aten.le.Scalar(to_dtype_526, 0);  to_dtype_526 = None
        new_zeros_default_297 = torch.ops.aten.new_zeros.default(to_dtype_525, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_140 = torch.ops.aten.where.self(le_scalar_140, new_zeros_default_297, to_dtype_525);  le_scalar_140 = new_zeros_default_297 = to_dtype_525 = None
        to_dtype_527 = torch.ops.aten.to.dtype(where_self_140, torch.float32);  where_self_140 = None
        mul_tensor_190 = torch.ops.aten.mul.Tensor(to_dtype_527, getitem_152);  getitem_152 = None
        mul_tensor_191 = torch.ops.aten.mul.Tensor(to_dtype_527, sigmoid_default_14)
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(mul_tensor_190, [2, 3], True);  mul_tensor_190 = None
        to_dtype_528 = torch.ops.aten.to.dtype(sum_dim_int_list_36, torch.float32);  sum_dim_int_list_36 = None
        to_dtype_529 = torch.ops.aten.to.dtype(sigmoid_default_14, torch.float32);  sigmoid_default_14 = None
        rsub_scalar_35 = torch.ops.aten.rsub.Scalar(to_dtype_529, 1)
        mul_tensor_192 = torch.ops.aten.mul.Tensor(to_dtype_529, rsub_scalar_35);  to_dtype_529 = rsub_scalar_35 = None
        conj_physical_default_35 = torch.ops.aten.conj_physical.default(mul_tensor_192);  mul_tensor_192 = None
        mul_tensor_193 = torch.ops.aten.mul.Tensor(to_dtype_528, conj_physical_default_35);  to_dtype_528 = conj_physical_default_35 = None
        to_dtype_530 = torch.ops.aten.to.dtype(mul_tensor_193, torch.float32);  mul_tensor_193 = None
        convolution_backward_default_176 = torch.ops.aten.convolution_backward.default(to_dtype_530, relu__default_61, primals_940, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_530 = primals_940 = None
        getitem_1319 = convolution_backward_default_176[0]
        getitem_1320 = convolution_backward_default_176[1]
        getitem_1321 = convolution_backward_default_176[2];  convolution_backward_default_176 = None
        to_dtype_531 = torch.ops.aten.to.dtype(getitem_1319, torch.float32);  getitem_1319 = None
        to_dtype_532 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_141 = torch.ops.aten.le.Scalar(to_dtype_532, 0);  to_dtype_532 = None
        new_zeros_default_298 = torch.ops.aten.new_zeros.default(to_dtype_531, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_141 = torch.ops.aten.where.self(le_scalar_141, new_zeros_default_298, to_dtype_531);  le_scalar_141 = new_zeros_default_298 = to_dtype_531 = None
        to_dtype_533 = torch.ops.aten.to.dtype(where_self_141, torch.float32);  where_self_141 = None
        convolution_backward_default_177 = torch.ops.aten.convolution_backward.default(to_dtype_533, mean_dim_14, primals_938, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_533 = mean_dim_14 = primals_938 = None
        getitem_1322 = convolution_backward_default_177[0]
        getitem_1323 = convolution_backward_default_177[1]
        getitem_1324 = convolution_backward_default_177[2];  convolution_backward_default_177 = None
        expand_default_36 = torch.ops.aten.expand.default(getitem_1322, [64, 1024, 20, 20]);  getitem_1322 = None
        div_scalar_36 = torch.ops.aten.div.Scalar(expand_default_36, 400);  expand_default_36 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(mul_tensor_191, div_scalar_36);  mul_tensor_191 = div_scalar_36 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_70, convolution_default_78, primals_933, primals_931, primals_932, getitem_153, getitem_154, True, 1e-05, [True, True, True]);  add_tensor_70 = convolution_default_78 = primals_933 = primals_931 = primals_932 = getitem_153 = getitem_154 = None
        getitem_1325 = native_batch_norm_backward_default_106[0]
        getitem_1326 = native_batch_norm_backward_default_106[1]
        getitem_1327 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_178 = torch.ops.aten.convolution_backward.default(getitem_1325, relu__default_60, primals_936, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1325 = primals_936 = None
        getitem_1328 = convolution_backward_default_178[0]
        getitem_1329 = convolution_backward_default_178[1]
        getitem_1330 = convolution_backward_default_178[2];  convolution_backward_default_178 = None
        to_dtype_534 = torch.ops.aten.to.dtype(getitem_1328, torch.float32);  getitem_1328 = None
        to_dtype_535 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_142 = torch.ops.aten.le.Scalar(to_dtype_535, 0);  to_dtype_535 = None
        new_zeros_default_299 = torch.ops.aten.new_zeros.default(to_dtype_534, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_142 = torch.ops.aten.where.self(le_scalar_142, new_zeros_default_299, to_dtype_534);  le_scalar_142 = new_zeros_default_299 = to_dtype_534 = None
        to_dtype_536 = torch.ops.aten.to.dtype(where_self_142, torch.float32);  where_self_142 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_536, convolution_default_77, primals_928, primals_926, primals_927, getitem_150, getitem_151, True, 1e-05, [True, True, True]);  to_dtype_536 = convolution_default_77 = primals_928 = primals_926 = primals_927 = getitem_150 = getitem_151 = None
        getitem_1331 = native_batch_norm_backward_default_107[0]
        getitem_1332 = native_batch_norm_backward_default_107[1]
        getitem_1333 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_179 = torch.ops.aten.convolution_backward.default(getitem_1331, relu__default_59, primals_935, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1331 = primals_935 = None
        getitem_1334 = convolution_backward_default_179[0]
        getitem_1335 = convolution_backward_default_179[1]
        getitem_1336 = convolution_backward_default_179[2];  convolution_backward_default_179 = None
        to_dtype_537 = torch.ops.aten.to.dtype(getitem_1334, torch.float32);  getitem_1334 = None
        to_dtype_538 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_143 = torch.ops.aten.le.Scalar(to_dtype_538, 0);  to_dtype_538 = None
        new_zeros_default_300 = torch.ops.aten.new_zeros.default(to_dtype_537, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_143 = torch.ops.aten.where.self(le_scalar_143, new_zeros_default_300, to_dtype_537);  le_scalar_143 = new_zeros_default_300 = to_dtype_537 = None
        to_dtype_539 = torch.ops.aten.to.dtype(where_self_143, torch.float32);  where_self_143 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_539, convolution_default_76, primals_923, primals_921, primals_922, getitem_147, getitem_148, True, 1e-05, [True, True, True]);  to_dtype_539 = convolution_default_76 = primals_923 = primals_921 = primals_922 = getitem_147 = getitem_148 = None
        getitem_1337 = native_batch_norm_backward_default_108[0]
        getitem_1338 = native_batch_norm_backward_default_108[1]
        getitem_1339 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_180 = torch.ops.aten.convolution_backward.default(getitem_1337, relu__default_58, primals_934, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1337 = primals_934 = None
        getitem_1340 = convolution_backward_default_180[0]
        getitem_1341 = convolution_backward_default_180[1]
        getitem_1342 = convolution_backward_default_180[2];  convolution_backward_default_180 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(to_dtype_527, getitem_1340);  to_dtype_527 = getitem_1340 = None
        to_dtype_540 = torch.ops.aten.to.dtype(add_tensor_71, torch.float32);  add_tensor_71 = None
        to_dtype_541 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_144 = torch.ops.aten.le.Scalar(to_dtype_541, 0);  to_dtype_541 = None
        new_zeros_default_301 = torch.ops.aten.new_zeros.default(to_dtype_540, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_144 = torch.ops.aten.where.self(le_scalar_144, new_zeros_default_301, to_dtype_540);  le_scalar_144 = new_zeros_default_301 = to_dtype_540 = None
        to_dtype_542 = torch.ops.aten.to.dtype(where_self_144, torch.float32);  where_self_144 = None
        mul_tensor_194 = torch.ops.aten.mul.Tensor(to_dtype_542, getitem_143);  getitem_143 = None
        mul_tensor_195 = torch.ops.aten.mul.Tensor(to_dtype_542, sigmoid_default_13)
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(mul_tensor_194, [2, 3], True);  mul_tensor_194 = None
        to_dtype_543 = torch.ops.aten.to.dtype(sum_dim_int_list_37, torch.float32);  sum_dim_int_list_37 = None
        to_dtype_544 = torch.ops.aten.to.dtype(sigmoid_default_13, torch.float32);  sigmoid_default_13 = None
        rsub_scalar_36 = torch.ops.aten.rsub.Scalar(to_dtype_544, 1)
        mul_tensor_196 = torch.ops.aten.mul.Tensor(to_dtype_544, rsub_scalar_36);  to_dtype_544 = rsub_scalar_36 = None
        conj_physical_default_36 = torch.ops.aten.conj_physical.default(mul_tensor_196);  mul_tensor_196 = None
        mul_tensor_197 = torch.ops.aten.mul.Tensor(to_dtype_543, conj_physical_default_36);  to_dtype_543 = conj_physical_default_36 = None
        to_dtype_545 = torch.ops.aten.to.dtype(mul_tensor_197, torch.float32);  mul_tensor_197 = None
        convolution_backward_default_181 = torch.ops.aten.convolution_backward.default(to_dtype_545, relu__default_57, primals_786, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_545 = primals_786 = None
        getitem_1343 = convolution_backward_default_181[0]
        getitem_1344 = convolution_backward_default_181[1]
        getitem_1345 = convolution_backward_default_181[2];  convolution_backward_default_181 = None
        to_dtype_546 = torch.ops.aten.to.dtype(getitem_1343, torch.float32);  getitem_1343 = None
        to_dtype_547 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_145 = torch.ops.aten.le.Scalar(to_dtype_547, 0);  to_dtype_547 = None
        new_zeros_default_302 = torch.ops.aten.new_zeros.default(to_dtype_546, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_145 = torch.ops.aten.where.self(le_scalar_145, new_zeros_default_302, to_dtype_546);  le_scalar_145 = new_zeros_default_302 = to_dtype_546 = None
        to_dtype_548 = torch.ops.aten.to.dtype(where_self_145, torch.float32);  where_self_145 = None
        convolution_backward_default_182 = torch.ops.aten.convolution_backward.default(to_dtype_548, mean_dim_13, primals_784, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_548 = mean_dim_13 = primals_784 = None
        getitem_1346 = convolution_backward_default_182[0]
        getitem_1347 = convolution_backward_default_182[1]
        getitem_1348 = convolution_backward_default_182[2];  convolution_backward_default_182 = None
        expand_default_37 = torch.ops.aten.expand.default(getitem_1346, [64, 1024, 20, 20]);  getitem_1346 = None
        div_scalar_37 = torch.ops.aten.div.Scalar(expand_default_37, 400);  expand_default_37 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(mul_tensor_195, div_scalar_37);  mul_tensor_195 = div_scalar_37 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_72, convolution_default_73, primals_779, primals_777, primals_778, getitem_144, getitem_145, True, 1e-05, [True, True, True]);  add_tensor_72 = convolution_default_73 = primals_779 = primals_777 = primals_778 = getitem_144 = getitem_145 = None
        getitem_1349 = native_batch_norm_backward_default_109[0]
        getitem_1350 = native_batch_norm_backward_default_109[1]
        getitem_1351 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_183 = torch.ops.aten.convolution_backward.default(getitem_1349, relu__default_56, primals_782, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1349 = primals_782 = None
        getitem_1352 = convolution_backward_default_183[0]
        getitem_1353 = convolution_backward_default_183[1]
        getitem_1354 = convolution_backward_default_183[2];  convolution_backward_default_183 = None
        to_dtype_549 = torch.ops.aten.to.dtype(getitem_1352, torch.float32);  getitem_1352 = None
        to_dtype_550 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_146 = torch.ops.aten.le.Scalar(to_dtype_550, 0);  to_dtype_550 = None
        new_zeros_default_303 = torch.ops.aten.new_zeros.default(to_dtype_549, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_146 = torch.ops.aten.where.self(le_scalar_146, new_zeros_default_303, to_dtype_549);  le_scalar_146 = new_zeros_default_303 = to_dtype_549 = None
        to_dtype_551 = torch.ops.aten.to.dtype(where_self_146, torch.float32);  where_self_146 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_551, convolution_default_72, primals_774, primals_772, primals_773, getitem_141, getitem_142, True, 1e-05, [True, True, True]);  to_dtype_551 = convolution_default_72 = primals_774 = primals_772 = primals_773 = getitem_141 = getitem_142 = None
        getitem_1355 = native_batch_norm_backward_default_110[0]
        getitem_1356 = native_batch_norm_backward_default_110[1]
        getitem_1357 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_184 = torch.ops.aten.convolution_backward.default(getitem_1355, relu__default_55, primals_781, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1355 = primals_781 = None
        getitem_1358 = convolution_backward_default_184[0]
        getitem_1359 = convolution_backward_default_184[1]
        getitem_1360 = convolution_backward_default_184[2];  convolution_backward_default_184 = None
        to_dtype_552 = torch.ops.aten.to.dtype(getitem_1358, torch.float32);  getitem_1358 = None
        to_dtype_553 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_147 = torch.ops.aten.le.Scalar(to_dtype_553, 0);  to_dtype_553 = None
        new_zeros_default_304 = torch.ops.aten.new_zeros.default(to_dtype_552, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_147 = torch.ops.aten.where.self(le_scalar_147, new_zeros_default_304, to_dtype_552);  le_scalar_147 = new_zeros_default_304 = to_dtype_552 = None
        to_dtype_554 = torch.ops.aten.to.dtype(where_self_147, torch.float32);  where_self_147 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_554, convolution_default_71, primals_769, primals_767, primals_768, getitem_138, getitem_139, True, 1e-05, [True, True, True]);  to_dtype_554 = convolution_default_71 = primals_769 = primals_767 = primals_768 = getitem_138 = getitem_139 = None
        getitem_1361 = native_batch_norm_backward_default_111[0]
        getitem_1362 = native_batch_norm_backward_default_111[1]
        getitem_1363 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_185 = torch.ops.aten.convolution_backward.default(getitem_1361, relu__default_54, primals_780, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1361 = primals_780 = None
        getitem_1364 = convolution_backward_default_185[0]
        getitem_1365 = convolution_backward_default_185[1]
        getitem_1366 = convolution_backward_default_185[2];  convolution_backward_default_185 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(to_dtype_542, getitem_1364);  to_dtype_542 = getitem_1364 = None
        to_dtype_555 = torch.ops.aten.to.dtype(add_tensor_73, torch.float32);  add_tensor_73 = None
        to_dtype_556 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_148 = torch.ops.aten.le.Scalar(to_dtype_556, 0);  to_dtype_556 = None
        new_zeros_default_305 = torch.ops.aten.new_zeros.default(to_dtype_555, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_148 = torch.ops.aten.where.self(le_scalar_148, new_zeros_default_305, to_dtype_555);  le_scalar_148 = new_zeros_default_305 = to_dtype_555 = None
        to_dtype_557 = torch.ops.aten.to.dtype(where_self_148, torch.float32);  where_self_148 = None
        mul_tensor_198 = torch.ops.aten.mul.Tensor(to_dtype_557, getitem_134);  getitem_134 = None
        mul_tensor_199 = torch.ops.aten.mul.Tensor(to_dtype_557, sigmoid_default_12)
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(mul_tensor_198, [2, 3], True);  mul_tensor_198 = None
        to_dtype_558 = torch.ops.aten.to.dtype(sum_dim_int_list_38, torch.float32);  sum_dim_int_list_38 = None
        to_dtype_559 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar_37 = torch.ops.aten.rsub.Scalar(to_dtype_559, 1)
        mul_tensor_200 = torch.ops.aten.mul.Tensor(to_dtype_559, rsub_scalar_37);  to_dtype_559 = rsub_scalar_37 = None
        conj_physical_default_37 = torch.ops.aten.conj_physical.default(mul_tensor_200);  mul_tensor_200 = None
        mul_tensor_201 = torch.ops.aten.mul.Tensor(to_dtype_558, conj_physical_default_37);  to_dtype_558 = conj_physical_default_37 = None
        to_dtype_560 = torch.ops.aten.to.dtype(mul_tensor_201, torch.float32);  mul_tensor_201 = None
        convolution_backward_default_186 = torch.ops.aten.convolution_backward.default(to_dtype_560, relu__default_53, primals_544, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_560 = primals_544 = None
        getitem_1367 = convolution_backward_default_186[0]
        getitem_1368 = convolution_backward_default_186[1]
        getitem_1369 = convolution_backward_default_186[2];  convolution_backward_default_186 = None
        to_dtype_561 = torch.ops.aten.to.dtype(getitem_1367, torch.float32);  getitem_1367 = None
        to_dtype_562 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_149 = torch.ops.aten.le.Scalar(to_dtype_562, 0);  to_dtype_562 = None
        new_zeros_default_306 = torch.ops.aten.new_zeros.default(to_dtype_561, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_149 = torch.ops.aten.where.self(le_scalar_149, new_zeros_default_306, to_dtype_561);  le_scalar_149 = new_zeros_default_306 = to_dtype_561 = None
        to_dtype_563 = torch.ops.aten.to.dtype(where_self_149, torch.float32);  where_self_149 = None
        convolution_backward_default_187 = torch.ops.aten.convolution_backward.default(to_dtype_563, mean_dim_12, primals_542, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_563 = mean_dim_12 = primals_542 = None
        getitem_1370 = convolution_backward_default_187[0]
        getitem_1371 = convolution_backward_default_187[1]
        getitem_1372 = convolution_backward_default_187[2];  convolution_backward_default_187 = None
        expand_default_38 = torch.ops.aten.expand.default(getitem_1370, [64, 1024, 20, 20]);  getitem_1370 = None
        div_scalar_38 = torch.ops.aten.div.Scalar(expand_default_38, 400);  expand_default_38 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(mul_tensor_199, div_scalar_38);  mul_tensor_199 = div_scalar_38 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_74, convolution_default_68, primals_537, primals_535, primals_536, getitem_135, getitem_136, True, 1e-05, [True, True, True]);  add_tensor_74 = convolution_default_68 = primals_537 = primals_535 = primals_536 = getitem_135 = getitem_136 = None
        getitem_1373 = native_batch_norm_backward_default_112[0]
        getitem_1374 = native_batch_norm_backward_default_112[1]
        getitem_1375 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_188 = torch.ops.aten.convolution_backward.default(getitem_1373, relu__default_52, primals_540, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1373 = primals_540 = None
        getitem_1376 = convolution_backward_default_188[0]
        getitem_1377 = convolution_backward_default_188[1]
        getitem_1378 = convolution_backward_default_188[2];  convolution_backward_default_188 = None
        to_dtype_564 = torch.ops.aten.to.dtype(getitem_1376, torch.float32);  getitem_1376 = None
        to_dtype_565 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_150 = torch.ops.aten.le.Scalar(to_dtype_565, 0);  to_dtype_565 = None
        new_zeros_default_307 = torch.ops.aten.new_zeros.default(to_dtype_564, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_150 = torch.ops.aten.where.self(le_scalar_150, new_zeros_default_307, to_dtype_564);  le_scalar_150 = new_zeros_default_307 = to_dtype_564 = None
        to_dtype_566 = torch.ops.aten.to.dtype(where_self_150, torch.float32);  where_self_150 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_566, convolution_default_67, primals_532, primals_530, primals_531, getitem_132, getitem_133, True, 1e-05, [True, True, True]);  to_dtype_566 = convolution_default_67 = primals_532 = primals_530 = primals_531 = getitem_132 = getitem_133 = None
        getitem_1379 = native_batch_norm_backward_default_113[0]
        getitem_1380 = native_batch_norm_backward_default_113[1]
        getitem_1381 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_189 = torch.ops.aten.convolution_backward.default(getitem_1379, relu__default_51, primals_539, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1379 = primals_539 = None
        getitem_1382 = convolution_backward_default_189[0]
        getitem_1383 = convolution_backward_default_189[1]
        getitem_1384 = convolution_backward_default_189[2];  convolution_backward_default_189 = None
        to_dtype_567 = torch.ops.aten.to.dtype(getitem_1382, torch.float32);  getitem_1382 = None
        to_dtype_568 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_151 = torch.ops.aten.le.Scalar(to_dtype_568, 0);  to_dtype_568 = None
        new_zeros_default_308 = torch.ops.aten.new_zeros.default(to_dtype_567, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_151 = torch.ops.aten.where.self(le_scalar_151, new_zeros_default_308, to_dtype_567);  le_scalar_151 = new_zeros_default_308 = to_dtype_567 = None
        to_dtype_569 = torch.ops.aten.to.dtype(where_self_151, torch.float32);  where_self_151 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_569, convolution_default_66, primals_527, primals_525, primals_526, getitem_129, getitem_130, True, 1e-05, [True, True, True]);  to_dtype_569 = convolution_default_66 = primals_527 = primals_525 = primals_526 = getitem_129 = getitem_130 = None
        getitem_1385 = native_batch_norm_backward_default_114[0]
        getitem_1386 = native_batch_norm_backward_default_114[1]
        getitem_1387 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_190 = torch.ops.aten.convolution_backward.default(getitem_1385, relu__default_50, primals_538, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1385 = primals_538 = None
        getitem_1388 = convolution_backward_default_190[0]
        getitem_1389 = convolution_backward_default_190[1]
        getitem_1390 = convolution_backward_default_190[2];  convolution_backward_default_190 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(to_dtype_557, getitem_1388);  to_dtype_557 = getitem_1388 = None
        to_dtype_570 = torch.ops.aten.to.dtype(add_tensor_75, torch.float32);  add_tensor_75 = None
        to_dtype_571 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_152 = torch.ops.aten.le.Scalar(to_dtype_571, 0);  to_dtype_571 = None
        new_zeros_default_309 = torch.ops.aten.new_zeros.default(to_dtype_570, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_152 = torch.ops.aten.where.self(le_scalar_152, new_zeros_default_309, to_dtype_570);  le_scalar_152 = new_zeros_default_309 = to_dtype_570 = None
        to_dtype_572 = torch.ops.aten.to.dtype(where_self_152, torch.float32);  where_self_152 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_572, convolution_default_65, primals_298, primals_296, primals_297, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  convolution_default_65 = primals_298 = primals_296 = primals_297 = getitem_126 = getitem_127 = None
        getitem_1391 = native_batch_norm_backward_default_115[0]
        getitem_1392 = native_batch_norm_backward_default_115[1]
        getitem_1393 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_191 = torch.ops.aten.convolution_backward.default(getitem_1391, avg_pool2d_default_1, primals_293, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1391 = avg_pool2d_default_1 = primals_293 = None
        getitem_1394 = convolution_backward_default_191[0]
        getitem_1395 = convolution_backward_default_191[1]
        getitem_1396 = convolution_backward_default_191[2];  convolution_backward_default_191 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_1394, relu__default_46, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_1394 = None
        mul_tensor_202 = torch.ops.aten.mul.Tensor(to_dtype_572, getitem_122);  getitem_122 = None
        mul_tensor_203 = torch.ops.aten.mul.Tensor(to_dtype_572, sigmoid_default_11);  to_dtype_572 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(mul_tensor_202, [2, 3], True);  mul_tensor_202 = None
        to_dtype_573 = torch.ops.aten.to.dtype(sum_dim_int_list_39, torch.float32);  sum_dim_int_list_39 = None
        to_dtype_574 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_38 = torch.ops.aten.rsub.Scalar(to_dtype_574, 1)
        mul_tensor_204 = torch.ops.aten.mul.Tensor(to_dtype_574, rsub_scalar_38);  to_dtype_574 = rsub_scalar_38 = None
        conj_physical_default_38 = torch.ops.aten.conj_physical.default(mul_tensor_204);  mul_tensor_204 = None
        mul_tensor_205 = torch.ops.aten.mul.Tensor(to_dtype_573, conj_physical_default_38);  to_dtype_573 = conj_physical_default_38 = None
        to_dtype_575 = torch.ops.aten.to.dtype(mul_tensor_205, torch.float32);  mul_tensor_205 = None
        convolution_backward_default_192 = torch.ops.aten.convolution_backward.default(to_dtype_575, relu__default_49, primals_302, [1024], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_575 = primals_302 = None
        getitem_1397 = convolution_backward_default_192[0]
        getitem_1398 = convolution_backward_default_192[1]
        getitem_1399 = convolution_backward_default_192[2];  convolution_backward_default_192 = None
        to_dtype_576 = torch.ops.aten.to.dtype(getitem_1397, torch.float32);  getitem_1397 = None
        to_dtype_577 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_153 = torch.ops.aten.le.Scalar(to_dtype_577, 0);  to_dtype_577 = None
        new_zeros_default_310 = torch.ops.aten.new_zeros.default(to_dtype_576, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_153 = torch.ops.aten.where.self(le_scalar_153, new_zeros_default_310, to_dtype_576);  le_scalar_153 = new_zeros_default_310 = to_dtype_576 = None
        to_dtype_578 = torch.ops.aten.to.dtype(where_self_153, torch.float32);  where_self_153 = None
        convolution_backward_default_193 = torch.ops.aten.convolution_backward.default(to_dtype_578, mean_dim_11, primals_300, [64], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_578 = mean_dim_11 = primals_300 = None
        getitem_1400 = convolution_backward_default_193[0]
        getitem_1401 = convolution_backward_default_193[1]
        getitem_1402 = convolution_backward_default_193[2];  convolution_backward_default_193 = None
        expand_default_39 = torch.ops.aten.expand.default(getitem_1400, [64, 1024, 20, 20]);  getitem_1400 = None
        div_scalar_39 = torch.ops.aten.div.Scalar(expand_default_39, 400);  expand_default_39 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(mul_tensor_203, div_scalar_39);  mul_tensor_203 = div_scalar_39 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_76, convolution_default_62, primals_289, primals_287, primals_288, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  add_tensor_76 = convolution_default_62 = primals_289 = primals_287 = primals_288 = getitem_123 = getitem_124 = None
        getitem_1403 = native_batch_norm_backward_default_116[0]
        getitem_1404 = native_batch_norm_backward_default_116[1]
        getitem_1405 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_194 = torch.ops.aten.convolution_backward.default(getitem_1403, relu__default_48, primals_292, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1403 = primals_292 = None
        getitem_1406 = convolution_backward_default_194[0]
        getitem_1407 = convolution_backward_default_194[1]
        getitem_1408 = convolution_backward_default_194[2];  convolution_backward_default_194 = None
        to_dtype_579 = torch.ops.aten.to.dtype(getitem_1406, torch.float32);  getitem_1406 = None
        to_dtype_580 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_154 = torch.ops.aten.le.Scalar(to_dtype_580, 0);  to_dtype_580 = None
        new_zeros_default_311 = torch.ops.aten.new_zeros.default(to_dtype_579, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_154 = torch.ops.aten.where.self(le_scalar_154, new_zeros_default_311, to_dtype_579);  le_scalar_154 = new_zeros_default_311 = to_dtype_579 = None
        to_dtype_581 = torch.ops.aten.to.dtype(where_self_154, torch.float32);  where_self_154 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_581, convolution_default_61, primals_284, primals_282, primals_283, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  to_dtype_581 = convolution_default_61 = primals_284 = primals_282 = primals_283 = getitem_120 = getitem_121 = None
        getitem_1409 = native_batch_norm_backward_default_117[0]
        getitem_1410 = native_batch_norm_backward_default_117[1]
        getitem_1411 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_195 = torch.ops.aten.convolution_backward.default(getitem_1409, relu__default_47, primals_291, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1409 = primals_291 = None
        getitem_1412 = convolution_backward_default_195[0]
        getitem_1413 = convolution_backward_default_195[1]
        getitem_1414 = convolution_backward_default_195[2];  convolution_backward_default_195 = None
        to_dtype_582 = torch.ops.aten.to.dtype(getitem_1412, torch.float32);  getitem_1412 = None
        to_dtype_583 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_155 = torch.ops.aten.le.Scalar(to_dtype_583, 0);  to_dtype_583 = None
        new_zeros_default_312 = torch.ops.aten.new_zeros.default(to_dtype_582, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_155 = torch.ops.aten.where.self(le_scalar_155, new_zeros_default_312, to_dtype_582);  le_scalar_155 = new_zeros_default_312 = to_dtype_582 = None
        to_dtype_584 = torch.ops.aten.to.dtype(where_self_155, torch.float32);  where_self_155 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_584, convolution_default_60, primals_279, primals_277, primals_278, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  to_dtype_584 = convolution_default_60 = primals_279 = primals_277 = primals_278 = getitem_117 = getitem_118 = None
        getitem_1415 = native_batch_norm_backward_default_118[0]
        getitem_1416 = native_batch_norm_backward_default_118[1]
        getitem_1417 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_196 = torch.ops.aten.convolution_backward.default(getitem_1415, relu__default_46, primals_290, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1415 = primals_290 = None
        getitem_1418 = convolution_backward_default_196[0]
        getitem_1419 = convolution_backward_default_196[1]
        getitem_1420 = convolution_backward_default_196[2];  convolution_backward_default_196 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_1, getitem_1418);  avg_pool2d_backward_default_1 = getitem_1418 = None
        to_dtype_585 = torch.ops.aten.to.dtype(add_tensor_77, torch.float32);  add_tensor_77 = None
        to_dtype_586 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_156 = torch.ops.aten.le.Scalar(to_dtype_586, 0);  to_dtype_586 = None
        new_zeros_default_313 = torch.ops.aten.new_zeros.default(to_dtype_585, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_156 = torch.ops.aten.where.self(le_scalar_156, new_zeros_default_313, to_dtype_585);  le_scalar_156 = new_zeros_default_313 = to_dtype_585 = None
        to_dtype_587 = torch.ops.aten.to.dtype(where_self_156, torch.float32);  where_self_156 = None
        mul_tensor_206 = torch.ops.aten.mul.Tensor(to_dtype_587, getitem_113);  getitem_113 = None
        mul_tensor_207 = torch.ops.aten.mul.Tensor(to_dtype_587, sigmoid_default_10)
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(mul_tensor_206, [2, 3], True);  mul_tensor_206 = None
        to_dtype_588 = torch.ops.aten.to.dtype(sum_dim_int_list_40, torch.float32);  sum_dim_int_list_40 = None
        to_dtype_589 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_39 = torch.ops.aten.rsub.Scalar(to_dtype_589, 1)
        mul_tensor_208 = torch.ops.aten.mul.Tensor(to_dtype_589, rsub_scalar_39);  to_dtype_589 = rsub_scalar_39 = None
        conj_physical_default_39 = torch.ops.aten.conj_physical.default(mul_tensor_208);  mul_tensor_208 = None
        mul_tensor_209 = torch.ops.aten.mul.Tensor(to_dtype_588, conj_physical_default_39);  to_dtype_588 = conj_physical_default_39 = None
        to_dtype_590 = torch.ops.aten.to.dtype(mul_tensor_209, torch.float32);  mul_tensor_209 = None
        convolution_backward_default_197 = torch.ops.aten.convolution_backward.default(to_dtype_590, relu__default_45, primals_274, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_590 = primals_274 = None
        getitem_1421 = convolution_backward_default_197[0]
        getitem_1422 = convolution_backward_default_197[1]
        getitem_1423 = convolution_backward_default_197[2];  convolution_backward_default_197 = None
        to_dtype_591 = torch.ops.aten.to.dtype(getitem_1421, torch.float32);  getitem_1421 = None
        to_dtype_592 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_157 = torch.ops.aten.le.Scalar(to_dtype_592, 0);  to_dtype_592 = None
        new_zeros_default_314 = torch.ops.aten.new_zeros.default(to_dtype_591, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_157 = torch.ops.aten.where.self(le_scalar_157, new_zeros_default_314, to_dtype_591);  le_scalar_157 = new_zeros_default_314 = to_dtype_591 = None
        to_dtype_593 = torch.ops.aten.to.dtype(where_self_157, torch.float32);  where_self_157 = None
        convolution_backward_default_198 = torch.ops.aten.convolution_backward.default(to_dtype_593, mean_dim_10, primals_272, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_593 = mean_dim_10 = primals_272 = None
        getitem_1424 = convolution_backward_default_198[0]
        getitem_1425 = convolution_backward_default_198[1]
        getitem_1426 = convolution_backward_default_198[2];  convolution_backward_default_198 = None
        expand_default_40 = torch.ops.aten.expand.default(getitem_1424, [64, 512, 40, 40]);  getitem_1424 = None
        div_scalar_40 = torch.ops.aten.div.Scalar(expand_default_40, 1600);  expand_default_40 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(mul_tensor_207, div_scalar_40);  mul_tensor_207 = div_scalar_40 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_78, convolution_default_57, primals_267, primals_265, primals_266, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  add_tensor_78 = convolution_default_57 = primals_267 = primals_265 = primals_266 = getitem_114 = getitem_115 = None
        getitem_1427 = native_batch_norm_backward_default_119[0]
        getitem_1428 = native_batch_norm_backward_default_119[1]
        getitem_1429 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_199 = torch.ops.aten.convolution_backward.default(getitem_1427, relu__default_44, primals_270, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1427 = primals_270 = None
        getitem_1430 = convolution_backward_default_199[0]
        getitem_1431 = convolution_backward_default_199[1]
        getitem_1432 = convolution_backward_default_199[2];  convolution_backward_default_199 = None
        to_dtype_594 = torch.ops.aten.to.dtype(getitem_1430, torch.float32);  getitem_1430 = None
        to_dtype_595 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_158 = torch.ops.aten.le.Scalar(to_dtype_595, 0);  to_dtype_595 = None
        new_zeros_default_315 = torch.ops.aten.new_zeros.default(to_dtype_594, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_158 = torch.ops.aten.where.self(le_scalar_158, new_zeros_default_315, to_dtype_594);  le_scalar_158 = new_zeros_default_315 = to_dtype_594 = None
        to_dtype_596 = torch.ops.aten.to.dtype(where_self_158, torch.float32);  where_self_158 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_596, convolution_default_56, primals_262, primals_260, primals_261, getitem_111, getitem_112, True, 1e-05, [True, True, True]);  to_dtype_596 = convolution_default_56 = primals_262 = primals_260 = primals_261 = getitem_111 = getitem_112 = None
        getitem_1433 = native_batch_norm_backward_default_120[0]
        getitem_1434 = native_batch_norm_backward_default_120[1]
        getitem_1435 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_200 = torch.ops.aten.convolution_backward.default(getitem_1433, relu__default_43, primals_269, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1433 = primals_269 = None
        getitem_1436 = convolution_backward_default_200[0]
        getitem_1437 = convolution_backward_default_200[1]
        getitem_1438 = convolution_backward_default_200[2];  convolution_backward_default_200 = None
        to_dtype_597 = torch.ops.aten.to.dtype(getitem_1436, torch.float32);  getitem_1436 = None
        to_dtype_598 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_159 = torch.ops.aten.le.Scalar(to_dtype_598, 0);  to_dtype_598 = None
        new_zeros_default_316 = torch.ops.aten.new_zeros.default(to_dtype_597, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_159 = torch.ops.aten.where.self(le_scalar_159, new_zeros_default_316, to_dtype_597);  le_scalar_159 = new_zeros_default_316 = to_dtype_597 = None
        to_dtype_599 = torch.ops.aten.to.dtype(where_self_159, torch.float32);  where_self_159 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_599, convolution_default_55, primals_257, primals_255, primals_256, getitem_108, getitem_109, True, 1e-05, [True, True, True]);  to_dtype_599 = convolution_default_55 = primals_257 = primals_255 = primals_256 = getitem_108 = getitem_109 = None
        getitem_1439 = native_batch_norm_backward_default_121[0]
        getitem_1440 = native_batch_norm_backward_default_121[1]
        getitem_1441 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_201 = torch.ops.aten.convolution_backward.default(getitem_1439, relu__default_42, primals_268, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1439 = primals_268 = None
        getitem_1442 = convolution_backward_default_201[0]
        getitem_1443 = convolution_backward_default_201[1]
        getitem_1444 = convolution_backward_default_201[2];  convolution_backward_default_201 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(to_dtype_587, getitem_1442);  to_dtype_587 = getitem_1442 = None
        to_dtype_600 = torch.ops.aten.to.dtype(add_tensor_79, torch.float32);  add_tensor_79 = None
        to_dtype_601 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_160 = torch.ops.aten.le.Scalar(to_dtype_601, 0);  to_dtype_601 = None
        new_zeros_default_317 = torch.ops.aten.new_zeros.default(to_dtype_600, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_160 = torch.ops.aten.where.self(le_scalar_160, new_zeros_default_317, to_dtype_600);  le_scalar_160 = new_zeros_default_317 = to_dtype_600 = None
        to_dtype_602 = torch.ops.aten.to.dtype(where_self_160, torch.float32);  where_self_160 = None
        mul_tensor_210 = torch.ops.aten.mul.Tensor(to_dtype_602, getitem_104);  getitem_104 = None
        mul_tensor_211 = torch.ops.aten.mul.Tensor(to_dtype_602, sigmoid_default_9)
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(mul_tensor_210, [2, 3], True);  mul_tensor_210 = None
        to_dtype_603 = torch.ops.aten.to.dtype(sum_dim_int_list_41, torch.float32);  sum_dim_int_list_41 = None
        to_dtype_604 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_40 = torch.ops.aten.rsub.Scalar(to_dtype_604, 1)
        mul_tensor_212 = torch.ops.aten.mul.Tensor(to_dtype_604, rsub_scalar_40);  to_dtype_604 = rsub_scalar_40 = None
        conj_physical_default_40 = torch.ops.aten.conj_physical.default(mul_tensor_212);  mul_tensor_212 = None
        mul_tensor_213 = torch.ops.aten.mul.Tensor(to_dtype_603, conj_physical_default_40);  to_dtype_603 = conj_physical_default_40 = None
        to_dtype_605 = torch.ops.aten.to.dtype(mul_tensor_213, torch.float32);  mul_tensor_213 = None
        convolution_backward_default_202 = torch.ops.aten.convolution_backward.default(to_dtype_605, relu__default_41, primals_252, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_605 = primals_252 = None
        getitem_1445 = convolution_backward_default_202[0]
        getitem_1446 = convolution_backward_default_202[1]
        getitem_1447 = convolution_backward_default_202[2];  convolution_backward_default_202 = None
        to_dtype_606 = torch.ops.aten.to.dtype(getitem_1445, torch.float32);  getitem_1445 = None
        to_dtype_607 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_161 = torch.ops.aten.le.Scalar(to_dtype_607, 0);  to_dtype_607 = None
        new_zeros_default_318 = torch.ops.aten.new_zeros.default(to_dtype_606, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_161 = torch.ops.aten.where.self(le_scalar_161, new_zeros_default_318, to_dtype_606);  le_scalar_161 = new_zeros_default_318 = to_dtype_606 = None
        to_dtype_608 = torch.ops.aten.to.dtype(where_self_161, torch.float32);  where_self_161 = None
        convolution_backward_default_203 = torch.ops.aten.convolution_backward.default(to_dtype_608, mean_dim_9, primals_250, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_608 = mean_dim_9 = primals_250 = None
        getitem_1448 = convolution_backward_default_203[0]
        getitem_1449 = convolution_backward_default_203[1]
        getitem_1450 = convolution_backward_default_203[2];  convolution_backward_default_203 = None
        expand_default_41 = torch.ops.aten.expand.default(getitem_1448, [64, 512, 40, 40]);  getitem_1448 = None
        div_scalar_41 = torch.ops.aten.div.Scalar(expand_default_41, 1600);  expand_default_41 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(mul_tensor_211, div_scalar_41);  mul_tensor_211 = div_scalar_41 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_80, convolution_default_52, primals_245, primals_243, primals_244, getitem_105, getitem_106, True, 1e-05, [True, True, True]);  add_tensor_80 = convolution_default_52 = primals_245 = primals_243 = primals_244 = getitem_105 = getitem_106 = None
        getitem_1451 = native_batch_norm_backward_default_122[0]
        getitem_1452 = native_batch_norm_backward_default_122[1]
        getitem_1453 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_204 = torch.ops.aten.convolution_backward.default(getitem_1451, relu__default_40, primals_248, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1451 = primals_248 = None
        getitem_1454 = convolution_backward_default_204[0]
        getitem_1455 = convolution_backward_default_204[1]
        getitem_1456 = convolution_backward_default_204[2];  convolution_backward_default_204 = None
        to_dtype_609 = torch.ops.aten.to.dtype(getitem_1454, torch.float32);  getitem_1454 = None
        to_dtype_610 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_162 = torch.ops.aten.le.Scalar(to_dtype_610, 0);  to_dtype_610 = None
        new_zeros_default_319 = torch.ops.aten.new_zeros.default(to_dtype_609, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_162 = torch.ops.aten.where.self(le_scalar_162, new_zeros_default_319, to_dtype_609);  le_scalar_162 = new_zeros_default_319 = to_dtype_609 = None
        to_dtype_611 = torch.ops.aten.to.dtype(where_self_162, torch.float32);  where_self_162 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_611, convolution_default_51, primals_240, primals_238, primals_239, getitem_102, getitem_103, True, 1e-05, [True, True, True]);  to_dtype_611 = convolution_default_51 = primals_240 = primals_238 = primals_239 = getitem_102 = getitem_103 = None
        getitem_1457 = native_batch_norm_backward_default_123[0]
        getitem_1458 = native_batch_norm_backward_default_123[1]
        getitem_1459 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_205 = torch.ops.aten.convolution_backward.default(getitem_1457, relu__default_39, primals_247, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1457 = primals_247 = None
        getitem_1460 = convolution_backward_default_205[0]
        getitem_1461 = convolution_backward_default_205[1]
        getitem_1462 = convolution_backward_default_205[2];  convolution_backward_default_205 = None
        to_dtype_612 = torch.ops.aten.to.dtype(getitem_1460, torch.float32);  getitem_1460 = None
        to_dtype_613 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_163 = torch.ops.aten.le.Scalar(to_dtype_613, 0);  to_dtype_613 = None
        new_zeros_default_320 = torch.ops.aten.new_zeros.default(to_dtype_612, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_163 = torch.ops.aten.where.self(le_scalar_163, new_zeros_default_320, to_dtype_612);  le_scalar_163 = new_zeros_default_320 = to_dtype_612 = None
        to_dtype_614 = torch.ops.aten.to.dtype(where_self_163, torch.float32);  where_self_163 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_614, convolution_default_50, primals_235, primals_233, primals_234, getitem_99, getitem_100, True, 1e-05, [True, True, True]);  to_dtype_614 = convolution_default_50 = primals_235 = primals_233 = primals_234 = getitem_99 = getitem_100 = None
        getitem_1463 = native_batch_norm_backward_default_124[0]
        getitem_1464 = native_batch_norm_backward_default_124[1]
        getitem_1465 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_206 = torch.ops.aten.convolution_backward.default(getitem_1463, relu__default_38, primals_246, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1463 = primals_246 = None
        getitem_1466 = convolution_backward_default_206[0]
        getitem_1467 = convolution_backward_default_206[1]
        getitem_1468 = convolution_backward_default_206[2];  convolution_backward_default_206 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(to_dtype_602, getitem_1466);  to_dtype_602 = getitem_1466 = None
        to_dtype_615 = torch.ops.aten.to.dtype(add_tensor_81, torch.float32);  add_tensor_81 = None
        to_dtype_616 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_164 = torch.ops.aten.le.Scalar(to_dtype_616, 0);  to_dtype_616 = None
        new_zeros_default_321 = torch.ops.aten.new_zeros.default(to_dtype_615, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_164 = torch.ops.aten.where.self(le_scalar_164, new_zeros_default_321, to_dtype_615);  le_scalar_164 = new_zeros_default_321 = to_dtype_615 = None
        to_dtype_617 = torch.ops.aten.to.dtype(where_self_164, torch.float32);  where_self_164 = None
        mul_tensor_214 = torch.ops.aten.mul.Tensor(to_dtype_617, getitem_95);  getitem_95 = None
        mul_tensor_215 = torch.ops.aten.mul.Tensor(to_dtype_617, sigmoid_default_8)
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(mul_tensor_214, [2, 3], True);  mul_tensor_214 = None
        to_dtype_618 = torch.ops.aten.to.dtype(sum_dim_int_list_42, torch.float32);  sum_dim_int_list_42 = None
        to_dtype_619 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_41 = torch.ops.aten.rsub.Scalar(to_dtype_619, 1)
        mul_tensor_216 = torch.ops.aten.mul.Tensor(to_dtype_619, rsub_scalar_41);  to_dtype_619 = rsub_scalar_41 = None
        conj_physical_default_41 = torch.ops.aten.conj_physical.default(mul_tensor_216);  mul_tensor_216 = None
        mul_tensor_217 = torch.ops.aten.mul.Tensor(to_dtype_618, conj_physical_default_41);  to_dtype_618 = conj_physical_default_41 = None
        to_dtype_620 = torch.ops.aten.to.dtype(mul_tensor_217, torch.float32);  mul_tensor_217 = None
        convolution_backward_default_207 = torch.ops.aten.convolution_backward.default(to_dtype_620, relu__default_37, primals_230, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_620 = primals_230 = None
        getitem_1469 = convolution_backward_default_207[0]
        getitem_1470 = convolution_backward_default_207[1]
        getitem_1471 = convolution_backward_default_207[2];  convolution_backward_default_207 = None
        to_dtype_621 = torch.ops.aten.to.dtype(getitem_1469, torch.float32);  getitem_1469 = None
        to_dtype_622 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_165 = torch.ops.aten.le.Scalar(to_dtype_622, 0);  to_dtype_622 = None
        new_zeros_default_322 = torch.ops.aten.new_zeros.default(to_dtype_621, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_165 = torch.ops.aten.where.self(le_scalar_165, new_zeros_default_322, to_dtype_621);  le_scalar_165 = new_zeros_default_322 = to_dtype_621 = None
        to_dtype_623 = torch.ops.aten.to.dtype(where_self_165, torch.float32);  where_self_165 = None
        convolution_backward_default_208 = torch.ops.aten.convolution_backward.default(to_dtype_623, mean_dim_8, primals_228, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_623 = mean_dim_8 = primals_228 = None
        getitem_1472 = convolution_backward_default_208[0]
        getitem_1473 = convolution_backward_default_208[1]
        getitem_1474 = convolution_backward_default_208[2];  convolution_backward_default_208 = None
        expand_default_42 = torch.ops.aten.expand.default(getitem_1472, [64, 512, 40, 40]);  getitem_1472 = None
        div_scalar_42 = torch.ops.aten.div.Scalar(expand_default_42, 1600);  expand_default_42 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(mul_tensor_215, div_scalar_42);  mul_tensor_215 = div_scalar_42 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_82, convolution_default_47, primals_223, primals_221, primals_222, getitem_96, getitem_97, True, 1e-05, [True, True, True]);  add_tensor_82 = convolution_default_47 = primals_223 = primals_221 = primals_222 = getitem_96 = getitem_97 = None
        getitem_1475 = native_batch_norm_backward_default_125[0]
        getitem_1476 = native_batch_norm_backward_default_125[1]
        getitem_1477 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_209 = torch.ops.aten.convolution_backward.default(getitem_1475, relu__default_36, primals_226, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1475 = primals_226 = None
        getitem_1478 = convolution_backward_default_209[0]
        getitem_1479 = convolution_backward_default_209[1]
        getitem_1480 = convolution_backward_default_209[2];  convolution_backward_default_209 = None
        to_dtype_624 = torch.ops.aten.to.dtype(getitem_1478, torch.float32);  getitem_1478 = None
        to_dtype_625 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_166 = torch.ops.aten.le.Scalar(to_dtype_625, 0);  to_dtype_625 = None
        new_zeros_default_323 = torch.ops.aten.new_zeros.default(to_dtype_624, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_166 = torch.ops.aten.where.self(le_scalar_166, new_zeros_default_323, to_dtype_624);  le_scalar_166 = new_zeros_default_323 = to_dtype_624 = None
        to_dtype_626 = torch.ops.aten.to.dtype(where_self_166, torch.float32);  where_self_166 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_626, convolution_default_46, primals_218, primals_216, primals_217, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  to_dtype_626 = convolution_default_46 = primals_218 = primals_216 = primals_217 = getitem_93 = getitem_94 = None
        getitem_1481 = native_batch_norm_backward_default_126[0]
        getitem_1482 = native_batch_norm_backward_default_126[1]
        getitem_1483 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_210 = torch.ops.aten.convolution_backward.default(getitem_1481, relu__default_35, primals_225, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1481 = primals_225 = None
        getitem_1484 = convolution_backward_default_210[0]
        getitem_1485 = convolution_backward_default_210[1]
        getitem_1486 = convolution_backward_default_210[2];  convolution_backward_default_210 = None
        to_dtype_627 = torch.ops.aten.to.dtype(getitem_1484, torch.float32);  getitem_1484 = None
        to_dtype_628 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_167 = torch.ops.aten.le.Scalar(to_dtype_628, 0);  to_dtype_628 = None
        new_zeros_default_324 = torch.ops.aten.new_zeros.default(to_dtype_627, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_167 = torch.ops.aten.where.self(le_scalar_167, new_zeros_default_324, to_dtype_627);  le_scalar_167 = new_zeros_default_324 = to_dtype_627 = None
        to_dtype_629 = torch.ops.aten.to.dtype(where_self_167, torch.float32);  where_self_167 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_629, convolution_default_45, primals_213, primals_211, primals_212, getitem_90, getitem_91, True, 1e-05, [True, True, True]);  to_dtype_629 = convolution_default_45 = primals_213 = primals_211 = primals_212 = getitem_90 = getitem_91 = None
        getitem_1487 = native_batch_norm_backward_default_127[0]
        getitem_1488 = native_batch_norm_backward_default_127[1]
        getitem_1489 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_211 = torch.ops.aten.convolution_backward.default(getitem_1487, relu__default_34, primals_224, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1487 = primals_224 = None
        getitem_1490 = convolution_backward_default_211[0]
        getitem_1491 = convolution_backward_default_211[1]
        getitem_1492 = convolution_backward_default_211[2];  convolution_backward_default_211 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(to_dtype_617, getitem_1490);  to_dtype_617 = getitem_1490 = None
        to_dtype_630 = torch.ops.aten.to.dtype(add_tensor_83, torch.float32);  add_tensor_83 = None
        to_dtype_631 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_168 = torch.ops.aten.le.Scalar(to_dtype_631, 0);  to_dtype_631 = None
        new_zeros_default_325 = torch.ops.aten.new_zeros.default(to_dtype_630, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_168 = torch.ops.aten.where.self(le_scalar_168, new_zeros_default_325, to_dtype_630);  le_scalar_168 = new_zeros_default_325 = to_dtype_630 = None
        to_dtype_632 = torch.ops.aten.to.dtype(where_self_168, torch.float32);  where_self_168 = None
        mul_tensor_218 = torch.ops.aten.mul.Tensor(to_dtype_632, getitem_86);  getitem_86 = None
        mul_tensor_219 = torch.ops.aten.mul.Tensor(to_dtype_632, sigmoid_default_7)
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(mul_tensor_218, [2, 3], True);  mul_tensor_218 = None
        to_dtype_633 = torch.ops.aten.to.dtype(sum_dim_int_list_43, torch.float32);  sum_dim_int_list_43 = None
        to_dtype_634 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_42 = torch.ops.aten.rsub.Scalar(to_dtype_634, 1)
        mul_tensor_220 = torch.ops.aten.mul.Tensor(to_dtype_634, rsub_scalar_42);  to_dtype_634 = rsub_scalar_42 = None
        conj_physical_default_42 = torch.ops.aten.conj_physical.default(mul_tensor_220);  mul_tensor_220 = None
        mul_tensor_221 = torch.ops.aten.mul.Tensor(to_dtype_633, conj_physical_default_42);  to_dtype_633 = conj_physical_default_42 = None
        to_dtype_635 = torch.ops.aten.to.dtype(mul_tensor_221, torch.float32);  mul_tensor_221 = None
        convolution_backward_default_212 = torch.ops.aten.convolution_backward.default(to_dtype_635, relu__default_33, primals_208, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_635 = primals_208 = None
        getitem_1493 = convolution_backward_default_212[0]
        getitem_1494 = convolution_backward_default_212[1]
        getitem_1495 = convolution_backward_default_212[2];  convolution_backward_default_212 = None
        to_dtype_636 = torch.ops.aten.to.dtype(getitem_1493, torch.float32);  getitem_1493 = None
        to_dtype_637 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_169 = torch.ops.aten.le.Scalar(to_dtype_637, 0);  to_dtype_637 = None
        new_zeros_default_326 = torch.ops.aten.new_zeros.default(to_dtype_636, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_169 = torch.ops.aten.where.self(le_scalar_169, new_zeros_default_326, to_dtype_636);  le_scalar_169 = new_zeros_default_326 = to_dtype_636 = None
        to_dtype_638 = torch.ops.aten.to.dtype(where_self_169, torch.float32);  where_self_169 = None
        convolution_backward_default_213 = torch.ops.aten.convolution_backward.default(to_dtype_638, mean_dim_7, primals_206, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_638 = mean_dim_7 = primals_206 = None
        getitem_1496 = convolution_backward_default_213[0]
        getitem_1497 = convolution_backward_default_213[1]
        getitem_1498 = convolution_backward_default_213[2];  convolution_backward_default_213 = None
        expand_default_43 = torch.ops.aten.expand.default(getitem_1496, [64, 512, 40, 40]);  getitem_1496 = None
        div_scalar_43 = torch.ops.aten.div.Scalar(expand_default_43, 1600);  expand_default_43 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(mul_tensor_219, div_scalar_43);  mul_tensor_219 = div_scalar_43 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_84, convolution_default_42, primals_201, primals_199, primals_200, getitem_87, getitem_88, True, 1e-05, [True, True, True]);  add_tensor_84 = convolution_default_42 = primals_201 = primals_199 = primals_200 = getitem_87 = getitem_88 = None
        getitem_1499 = native_batch_norm_backward_default_128[0]
        getitem_1500 = native_batch_norm_backward_default_128[1]
        getitem_1501 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_214 = torch.ops.aten.convolution_backward.default(getitem_1499, relu__default_32, primals_204, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1499 = primals_204 = None
        getitem_1502 = convolution_backward_default_214[0]
        getitem_1503 = convolution_backward_default_214[1]
        getitem_1504 = convolution_backward_default_214[2];  convolution_backward_default_214 = None
        to_dtype_639 = torch.ops.aten.to.dtype(getitem_1502, torch.float32);  getitem_1502 = None
        to_dtype_640 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_170 = torch.ops.aten.le.Scalar(to_dtype_640, 0);  to_dtype_640 = None
        new_zeros_default_327 = torch.ops.aten.new_zeros.default(to_dtype_639, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_170 = torch.ops.aten.where.self(le_scalar_170, new_zeros_default_327, to_dtype_639);  le_scalar_170 = new_zeros_default_327 = to_dtype_639 = None
        to_dtype_641 = torch.ops.aten.to.dtype(where_self_170, torch.float32);  where_self_170 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_641, convolution_default_41, primals_196, primals_194, primals_195, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  to_dtype_641 = convolution_default_41 = primals_196 = primals_194 = primals_195 = getitem_84 = getitem_85 = None
        getitem_1505 = native_batch_norm_backward_default_129[0]
        getitem_1506 = native_batch_norm_backward_default_129[1]
        getitem_1507 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_215 = torch.ops.aten.convolution_backward.default(getitem_1505, relu__default_31, primals_203, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1505 = primals_203 = None
        getitem_1508 = convolution_backward_default_215[0]
        getitem_1509 = convolution_backward_default_215[1]
        getitem_1510 = convolution_backward_default_215[2];  convolution_backward_default_215 = None
        to_dtype_642 = torch.ops.aten.to.dtype(getitem_1508, torch.float32);  getitem_1508 = None
        to_dtype_643 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_171 = torch.ops.aten.le.Scalar(to_dtype_643, 0);  to_dtype_643 = None
        new_zeros_default_328 = torch.ops.aten.new_zeros.default(to_dtype_642, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_171 = torch.ops.aten.where.self(le_scalar_171, new_zeros_default_328, to_dtype_642);  le_scalar_171 = new_zeros_default_328 = to_dtype_642 = None
        to_dtype_644 = torch.ops.aten.to.dtype(where_self_171, torch.float32);  where_self_171 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_644, convolution_default_40, primals_191, primals_189, primals_190, getitem_81, getitem_82, True, 1e-05, [True, True, True]);  to_dtype_644 = convolution_default_40 = primals_191 = primals_189 = primals_190 = getitem_81 = getitem_82 = None
        getitem_1511 = native_batch_norm_backward_default_130[0]
        getitem_1512 = native_batch_norm_backward_default_130[1]
        getitem_1513 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_216 = torch.ops.aten.convolution_backward.default(getitem_1511, relu__default_30, primals_202, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1511 = primals_202 = None
        getitem_1514 = convolution_backward_default_216[0]
        getitem_1515 = convolution_backward_default_216[1]
        getitem_1516 = convolution_backward_default_216[2];  convolution_backward_default_216 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(to_dtype_632, getitem_1514);  to_dtype_632 = getitem_1514 = None
        to_dtype_645 = torch.ops.aten.to.dtype(add_tensor_85, torch.float32);  add_tensor_85 = None
        to_dtype_646 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_172 = torch.ops.aten.le.Scalar(to_dtype_646, 0);  to_dtype_646 = None
        new_zeros_default_329 = torch.ops.aten.new_zeros.default(to_dtype_645, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_172 = torch.ops.aten.where.self(le_scalar_172, new_zeros_default_329, to_dtype_645);  le_scalar_172 = new_zeros_default_329 = to_dtype_645 = None
        to_dtype_647 = torch.ops.aten.to.dtype(where_self_172, torch.float32);  where_self_172 = None
        mul_tensor_222 = torch.ops.aten.mul.Tensor(to_dtype_647, getitem_77);  getitem_77 = None
        mul_tensor_223 = torch.ops.aten.mul.Tensor(to_dtype_647, sigmoid_default_6)
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(mul_tensor_222, [2, 3], True);  mul_tensor_222 = None
        to_dtype_648 = torch.ops.aten.to.dtype(sum_dim_int_list_44, torch.float32);  sum_dim_int_list_44 = None
        to_dtype_649 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_43 = torch.ops.aten.rsub.Scalar(to_dtype_649, 1)
        mul_tensor_224 = torch.ops.aten.mul.Tensor(to_dtype_649, rsub_scalar_43);  to_dtype_649 = rsub_scalar_43 = None
        conj_physical_default_43 = torch.ops.aten.conj_physical.default(mul_tensor_224);  mul_tensor_224 = None
        mul_tensor_225 = torch.ops.aten.mul.Tensor(to_dtype_648, conj_physical_default_43);  to_dtype_648 = conj_physical_default_43 = None
        to_dtype_650 = torch.ops.aten.to.dtype(mul_tensor_225, torch.float32);  mul_tensor_225 = None
        convolution_backward_default_217 = torch.ops.aten.convolution_backward.default(to_dtype_650, relu__default_29, primals_186, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_650 = primals_186 = None
        getitem_1517 = convolution_backward_default_217[0]
        getitem_1518 = convolution_backward_default_217[1]
        getitem_1519 = convolution_backward_default_217[2];  convolution_backward_default_217 = None
        to_dtype_651 = torch.ops.aten.to.dtype(getitem_1517, torch.float32);  getitem_1517 = None
        to_dtype_652 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_173 = torch.ops.aten.le.Scalar(to_dtype_652, 0);  to_dtype_652 = None
        new_zeros_default_330 = torch.ops.aten.new_zeros.default(to_dtype_651, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_173 = torch.ops.aten.where.self(le_scalar_173, new_zeros_default_330, to_dtype_651);  le_scalar_173 = new_zeros_default_330 = to_dtype_651 = None
        to_dtype_653 = torch.ops.aten.to.dtype(where_self_173, torch.float32);  where_self_173 = None
        convolution_backward_default_218 = torch.ops.aten.convolution_backward.default(to_dtype_653, mean_dim_6, primals_184, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_653 = mean_dim_6 = primals_184 = None
        getitem_1520 = convolution_backward_default_218[0]
        getitem_1521 = convolution_backward_default_218[1]
        getitem_1522 = convolution_backward_default_218[2];  convolution_backward_default_218 = None
        expand_default_44 = torch.ops.aten.expand.default(getitem_1520, [64, 512, 40, 40]);  getitem_1520 = None
        div_scalar_44 = torch.ops.aten.div.Scalar(expand_default_44, 1600);  expand_default_44 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(mul_tensor_223, div_scalar_44);  mul_tensor_223 = div_scalar_44 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_86, convolution_default_37, primals_179, primals_177, primals_178, getitem_78, getitem_79, True, 1e-05, [True, True, True]);  add_tensor_86 = convolution_default_37 = primals_179 = primals_177 = primals_178 = getitem_78 = getitem_79 = None
        getitem_1523 = native_batch_norm_backward_default_131[0]
        getitem_1524 = native_batch_norm_backward_default_131[1]
        getitem_1525 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_219 = torch.ops.aten.convolution_backward.default(getitem_1523, relu__default_28, primals_182, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1523 = primals_182 = None
        getitem_1526 = convolution_backward_default_219[0]
        getitem_1527 = convolution_backward_default_219[1]
        getitem_1528 = convolution_backward_default_219[2];  convolution_backward_default_219 = None
        to_dtype_654 = torch.ops.aten.to.dtype(getitem_1526, torch.float32);  getitem_1526 = None
        to_dtype_655 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_174 = torch.ops.aten.le.Scalar(to_dtype_655, 0);  to_dtype_655 = None
        new_zeros_default_331 = torch.ops.aten.new_zeros.default(to_dtype_654, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_174 = torch.ops.aten.where.self(le_scalar_174, new_zeros_default_331, to_dtype_654);  le_scalar_174 = new_zeros_default_331 = to_dtype_654 = None
        to_dtype_656 = torch.ops.aten.to.dtype(where_self_174, torch.float32);  where_self_174 = None
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_656, convolution_default_36, primals_174, primals_172, primals_173, getitem_75, getitem_76, True, 1e-05, [True, True, True]);  to_dtype_656 = convolution_default_36 = primals_174 = primals_172 = primals_173 = getitem_75 = getitem_76 = None
        getitem_1529 = native_batch_norm_backward_default_132[0]
        getitem_1530 = native_batch_norm_backward_default_132[1]
        getitem_1531 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_220 = torch.ops.aten.convolution_backward.default(getitem_1529, relu__default_27, primals_181, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1529 = primals_181 = None
        getitem_1532 = convolution_backward_default_220[0]
        getitem_1533 = convolution_backward_default_220[1]
        getitem_1534 = convolution_backward_default_220[2];  convolution_backward_default_220 = None
        to_dtype_657 = torch.ops.aten.to.dtype(getitem_1532, torch.float32);  getitem_1532 = None
        to_dtype_658 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_175 = torch.ops.aten.le.Scalar(to_dtype_658, 0);  to_dtype_658 = None
        new_zeros_default_332 = torch.ops.aten.new_zeros.default(to_dtype_657, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_175 = torch.ops.aten.where.self(le_scalar_175, new_zeros_default_332, to_dtype_657);  le_scalar_175 = new_zeros_default_332 = to_dtype_657 = None
        to_dtype_659 = torch.ops.aten.to.dtype(where_self_175, torch.float32);  where_self_175 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_659, convolution_default_35, primals_169, primals_167, primals_168, getitem_72, getitem_73, True, 1e-05, [True, True, True]);  to_dtype_659 = convolution_default_35 = primals_169 = primals_167 = primals_168 = getitem_72 = getitem_73 = None
        getitem_1535 = native_batch_norm_backward_default_133[0]
        getitem_1536 = native_batch_norm_backward_default_133[1]
        getitem_1537 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_221 = torch.ops.aten.convolution_backward.default(getitem_1535, relu__default_26, primals_180, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1535 = primals_180 = None
        getitem_1538 = convolution_backward_default_221[0]
        getitem_1539 = convolution_backward_default_221[1]
        getitem_1540 = convolution_backward_default_221[2];  convolution_backward_default_221 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(to_dtype_647, getitem_1538);  to_dtype_647 = getitem_1538 = None
        to_dtype_660 = torch.ops.aten.to.dtype(add_tensor_87, torch.float32);  add_tensor_87 = None
        to_dtype_661 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_176 = torch.ops.aten.le.Scalar(to_dtype_661, 0);  to_dtype_661 = None
        new_zeros_default_333 = torch.ops.aten.new_zeros.default(to_dtype_660, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_176 = torch.ops.aten.where.self(le_scalar_176, new_zeros_default_333, to_dtype_660);  le_scalar_176 = new_zeros_default_333 = to_dtype_660 = None
        to_dtype_662 = torch.ops.aten.to.dtype(where_self_176, torch.float32);  where_self_176 = None
        mul_tensor_226 = torch.ops.aten.mul.Tensor(to_dtype_662, getitem_68);  getitem_68 = None
        mul_tensor_227 = torch.ops.aten.mul.Tensor(to_dtype_662, sigmoid_default_5)
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(mul_tensor_226, [2, 3], True);  mul_tensor_226 = None
        to_dtype_663 = torch.ops.aten.to.dtype(sum_dim_int_list_45, torch.float32);  sum_dim_int_list_45 = None
        to_dtype_664 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_44 = torch.ops.aten.rsub.Scalar(to_dtype_664, 1)
        mul_tensor_228 = torch.ops.aten.mul.Tensor(to_dtype_664, rsub_scalar_44);  to_dtype_664 = rsub_scalar_44 = None
        conj_physical_default_44 = torch.ops.aten.conj_physical.default(mul_tensor_228);  mul_tensor_228 = None
        mul_tensor_229 = torch.ops.aten.mul.Tensor(to_dtype_663, conj_physical_default_44);  to_dtype_663 = conj_physical_default_44 = None
        to_dtype_665 = torch.ops.aten.to.dtype(mul_tensor_229, torch.float32);  mul_tensor_229 = None
        convolution_backward_default_222 = torch.ops.aten.convolution_backward.default(to_dtype_665, relu__default_25, primals_164, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_665 = primals_164 = None
        getitem_1541 = convolution_backward_default_222[0]
        getitem_1542 = convolution_backward_default_222[1]
        getitem_1543 = convolution_backward_default_222[2];  convolution_backward_default_222 = None
        to_dtype_666 = torch.ops.aten.to.dtype(getitem_1541, torch.float32);  getitem_1541 = None
        to_dtype_667 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_177 = torch.ops.aten.le.Scalar(to_dtype_667, 0);  to_dtype_667 = None
        new_zeros_default_334 = torch.ops.aten.new_zeros.default(to_dtype_666, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_177 = torch.ops.aten.where.self(le_scalar_177, new_zeros_default_334, to_dtype_666);  le_scalar_177 = new_zeros_default_334 = to_dtype_666 = None
        to_dtype_668 = torch.ops.aten.to.dtype(where_self_177, torch.float32);  where_self_177 = None
        convolution_backward_default_223 = torch.ops.aten.convolution_backward.default(to_dtype_668, mean_dim_5, primals_162, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_668 = mean_dim_5 = primals_162 = None
        getitem_1544 = convolution_backward_default_223[0]
        getitem_1545 = convolution_backward_default_223[1]
        getitem_1546 = convolution_backward_default_223[2];  convolution_backward_default_223 = None
        expand_default_45 = torch.ops.aten.expand.default(getitem_1544, [64, 512, 40, 40]);  getitem_1544 = None
        div_scalar_45 = torch.ops.aten.div.Scalar(expand_default_45, 1600);  expand_default_45 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(mul_tensor_227, div_scalar_45);  mul_tensor_227 = div_scalar_45 = None
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_88, convolution_default_32, primals_157, primals_155, primals_156, getitem_69, getitem_70, True, 1e-05, [True, True, True]);  add_tensor_88 = convolution_default_32 = primals_157 = primals_155 = primals_156 = getitem_69 = getitem_70 = None
        getitem_1547 = native_batch_norm_backward_default_134[0]
        getitem_1548 = native_batch_norm_backward_default_134[1]
        getitem_1549 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_224 = torch.ops.aten.convolution_backward.default(getitem_1547, relu__default_24, primals_160, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1547 = primals_160 = None
        getitem_1550 = convolution_backward_default_224[0]
        getitem_1551 = convolution_backward_default_224[1]
        getitem_1552 = convolution_backward_default_224[2];  convolution_backward_default_224 = None
        to_dtype_669 = torch.ops.aten.to.dtype(getitem_1550, torch.float32);  getitem_1550 = None
        to_dtype_670 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_178 = torch.ops.aten.le.Scalar(to_dtype_670, 0);  to_dtype_670 = None
        new_zeros_default_335 = torch.ops.aten.new_zeros.default(to_dtype_669, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_178 = torch.ops.aten.where.self(le_scalar_178, new_zeros_default_335, to_dtype_669);  le_scalar_178 = new_zeros_default_335 = to_dtype_669 = None
        to_dtype_671 = torch.ops.aten.to.dtype(where_self_178, torch.float32);  where_self_178 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_671, convolution_default_31, primals_152, primals_150, primals_151, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_671 = convolution_default_31 = primals_152 = primals_150 = primals_151 = getitem_66 = getitem_67 = None
        getitem_1553 = native_batch_norm_backward_default_135[0]
        getitem_1554 = native_batch_norm_backward_default_135[1]
        getitem_1555 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_225 = torch.ops.aten.convolution_backward.default(getitem_1553, relu__default_23, primals_159, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1553 = primals_159 = None
        getitem_1556 = convolution_backward_default_225[0]
        getitem_1557 = convolution_backward_default_225[1]
        getitem_1558 = convolution_backward_default_225[2];  convolution_backward_default_225 = None
        to_dtype_672 = torch.ops.aten.to.dtype(getitem_1556, torch.float32);  getitem_1556 = None
        to_dtype_673 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_179 = torch.ops.aten.le.Scalar(to_dtype_673, 0);  to_dtype_673 = None
        new_zeros_default_336 = torch.ops.aten.new_zeros.default(to_dtype_672, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_179 = torch.ops.aten.where.self(le_scalar_179, new_zeros_default_336, to_dtype_672);  le_scalar_179 = new_zeros_default_336 = to_dtype_672 = None
        to_dtype_674 = torch.ops.aten.to.dtype(where_self_179, torch.float32);  where_self_179 = None
        native_batch_norm_backward_default_136 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_674, convolution_default_30, primals_147, primals_145, primals_146, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  to_dtype_674 = convolution_default_30 = primals_147 = primals_145 = primals_146 = getitem_63 = getitem_64 = None
        getitem_1559 = native_batch_norm_backward_default_136[0]
        getitem_1560 = native_batch_norm_backward_default_136[1]
        getitem_1561 = native_batch_norm_backward_default_136[2];  native_batch_norm_backward_default_136 = None
        convolution_backward_default_226 = torch.ops.aten.convolution_backward.default(getitem_1559, relu__default_22, primals_158, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1559 = primals_158 = None
        getitem_1562 = convolution_backward_default_226[0]
        getitem_1563 = convolution_backward_default_226[1]
        getitem_1564 = convolution_backward_default_226[2];  convolution_backward_default_226 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(to_dtype_662, getitem_1562);  to_dtype_662 = getitem_1562 = None
        to_dtype_675 = torch.ops.aten.to.dtype(add_tensor_89, torch.float32);  add_tensor_89 = None
        to_dtype_676 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_180 = torch.ops.aten.le.Scalar(to_dtype_676, 0);  to_dtype_676 = None
        new_zeros_default_337 = torch.ops.aten.new_zeros.default(to_dtype_675, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_180 = torch.ops.aten.where.self(le_scalar_180, new_zeros_default_337, to_dtype_675);  le_scalar_180 = new_zeros_default_337 = to_dtype_675 = None
        to_dtype_677 = torch.ops.aten.to.dtype(where_self_180, torch.float32);  where_self_180 = None
        mul_tensor_230 = torch.ops.aten.mul.Tensor(to_dtype_677, getitem_59);  getitem_59 = None
        mul_tensor_231 = torch.ops.aten.mul.Tensor(to_dtype_677, sigmoid_default_4)
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(mul_tensor_230, [2, 3], True);  mul_tensor_230 = None
        to_dtype_678 = torch.ops.aten.to.dtype(sum_dim_int_list_46, torch.float32);  sum_dim_int_list_46 = None
        to_dtype_679 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_45 = torch.ops.aten.rsub.Scalar(to_dtype_679, 1)
        mul_tensor_232 = torch.ops.aten.mul.Tensor(to_dtype_679, rsub_scalar_45);  to_dtype_679 = rsub_scalar_45 = None
        conj_physical_default_45 = torch.ops.aten.conj_physical.default(mul_tensor_232);  mul_tensor_232 = None
        mul_tensor_233 = torch.ops.aten.mul.Tensor(to_dtype_678, conj_physical_default_45);  to_dtype_678 = conj_physical_default_45 = None
        to_dtype_680 = torch.ops.aten.to.dtype(mul_tensor_233, torch.float32);  mul_tensor_233 = None
        convolution_backward_default_227 = torch.ops.aten.convolution_backward.default(to_dtype_680, relu__default_21, primals_142, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_680 = primals_142 = None
        getitem_1565 = convolution_backward_default_227[0]
        getitem_1566 = convolution_backward_default_227[1]
        getitem_1567 = convolution_backward_default_227[2];  convolution_backward_default_227 = None
        to_dtype_681 = torch.ops.aten.to.dtype(getitem_1565, torch.float32);  getitem_1565 = None
        to_dtype_682 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_181 = torch.ops.aten.le.Scalar(to_dtype_682, 0);  to_dtype_682 = None
        new_zeros_default_338 = torch.ops.aten.new_zeros.default(to_dtype_681, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_181 = torch.ops.aten.where.self(le_scalar_181, new_zeros_default_338, to_dtype_681);  le_scalar_181 = new_zeros_default_338 = to_dtype_681 = None
        to_dtype_683 = torch.ops.aten.to.dtype(where_self_181, torch.float32);  where_self_181 = None
        convolution_backward_default_228 = torch.ops.aten.convolution_backward.default(to_dtype_683, mean_dim_4, primals_140, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_683 = mean_dim_4 = primals_140 = None
        getitem_1568 = convolution_backward_default_228[0]
        getitem_1569 = convolution_backward_default_228[1]
        getitem_1570 = convolution_backward_default_228[2];  convolution_backward_default_228 = None
        expand_default_46 = torch.ops.aten.expand.default(getitem_1568, [64, 512, 40, 40]);  getitem_1568 = None
        div_scalar_46 = torch.ops.aten.div.Scalar(expand_default_46, 1600);  expand_default_46 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(mul_tensor_231, div_scalar_46);  mul_tensor_231 = div_scalar_46 = None
        native_batch_norm_backward_default_137 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_90, convolution_default_27, primals_135, primals_133, primals_134, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  add_tensor_90 = convolution_default_27 = primals_135 = primals_133 = primals_134 = getitem_60 = getitem_61 = None
        getitem_1571 = native_batch_norm_backward_default_137[0]
        getitem_1572 = native_batch_norm_backward_default_137[1]
        getitem_1573 = native_batch_norm_backward_default_137[2];  native_batch_norm_backward_default_137 = None
        convolution_backward_default_229 = torch.ops.aten.convolution_backward.default(getitem_1571, relu__default_20, primals_138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1571 = primals_138 = None
        getitem_1574 = convolution_backward_default_229[0]
        getitem_1575 = convolution_backward_default_229[1]
        getitem_1576 = convolution_backward_default_229[2];  convolution_backward_default_229 = None
        to_dtype_684 = torch.ops.aten.to.dtype(getitem_1574, torch.float32);  getitem_1574 = None
        to_dtype_685 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_182 = torch.ops.aten.le.Scalar(to_dtype_685, 0);  to_dtype_685 = None
        new_zeros_default_339 = torch.ops.aten.new_zeros.default(to_dtype_684, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_182 = torch.ops.aten.where.self(le_scalar_182, new_zeros_default_339, to_dtype_684);  le_scalar_182 = new_zeros_default_339 = to_dtype_684 = None
        to_dtype_686 = torch.ops.aten.to.dtype(where_self_182, torch.float32);  where_self_182 = None
        native_batch_norm_backward_default_138 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_686, convolution_default_26, primals_130, primals_128, primals_129, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_686 = convolution_default_26 = primals_130 = primals_128 = primals_129 = getitem_57 = getitem_58 = None
        getitem_1577 = native_batch_norm_backward_default_138[0]
        getitem_1578 = native_batch_norm_backward_default_138[1]
        getitem_1579 = native_batch_norm_backward_default_138[2];  native_batch_norm_backward_default_138 = None
        convolution_backward_default_230 = torch.ops.aten.convolution_backward.default(getitem_1577, relu__default_19, primals_137, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1577 = primals_137 = None
        getitem_1580 = convolution_backward_default_230[0]
        getitem_1581 = convolution_backward_default_230[1]
        getitem_1582 = convolution_backward_default_230[2];  convolution_backward_default_230 = None
        to_dtype_687 = torch.ops.aten.to.dtype(getitem_1580, torch.float32);  getitem_1580 = None
        to_dtype_688 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_183 = torch.ops.aten.le.Scalar(to_dtype_688, 0);  to_dtype_688 = None
        new_zeros_default_340 = torch.ops.aten.new_zeros.default(to_dtype_687, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_183 = torch.ops.aten.where.self(le_scalar_183, new_zeros_default_340, to_dtype_687);  le_scalar_183 = new_zeros_default_340 = to_dtype_687 = None
        to_dtype_689 = torch.ops.aten.to.dtype(where_self_183, torch.float32);  where_self_183 = None
        native_batch_norm_backward_default_139 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_689, convolution_default_25, primals_125, primals_123, primals_124, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_689 = convolution_default_25 = primals_125 = primals_123 = primals_124 = getitem_54 = getitem_55 = None
        getitem_1583 = native_batch_norm_backward_default_139[0]
        getitem_1584 = native_batch_norm_backward_default_139[1]
        getitem_1585 = native_batch_norm_backward_default_139[2];  native_batch_norm_backward_default_139 = None
        convolution_backward_default_231 = torch.ops.aten.convolution_backward.default(getitem_1583, relu__default_18, primals_136, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1583 = primals_136 = None
        getitem_1586 = convolution_backward_default_231[0]
        getitem_1587 = convolution_backward_default_231[1]
        getitem_1588 = convolution_backward_default_231[2];  convolution_backward_default_231 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(to_dtype_677, getitem_1586);  to_dtype_677 = getitem_1586 = None
        to_dtype_690 = torch.ops.aten.to.dtype(add_tensor_91, torch.float32);  add_tensor_91 = None
        to_dtype_691 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_184 = torch.ops.aten.le.Scalar(to_dtype_691, 0);  to_dtype_691 = None
        new_zeros_default_341 = torch.ops.aten.new_zeros.default(to_dtype_690, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_184 = torch.ops.aten.where.self(le_scalar_184, new_zeros_default_341, to_dtype_690);  le_scalar_184 = new_zeros_default_341 = to_dtype_690 = None
        to_dtype_692 = torch.ops.aten.to.dtype(where_self_184, torch.float32);  where_self_184 = None
        native_batch_norm_backward_default_140 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_692, convolution_default_24, primals_116, primals_114, primals_115, getitem_51, getitem_52, True, 1e-05, [True, True, True]);  convolution_default_24 = primals_116 = primals_114 = primals_115 = getitem_51 = getitem_52 = None
        getitem_1589 = native_batch_norm_backward_default_140[0]
        getitem_1590 = native_batch_norm_backward_default_140[1]
        getitem_1591 = native_batch_norm_backward_default_140[2];  native_batch_norm_backward_default_140 = None
        convolution_backward_default_232 = torch.ops.aten.convolution_backward.default(getitem_1589, avg_pool2d_default, primals_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1589 = avg_pool2d_default = primals_111 = None
        getitem_1592 = convolution_backward_default_232[0]
        getitem_1593 = convolution_backward_default_232[1]
        getitem_1594 = convolution_backward_default_232[2];  convolution_backward_default_232 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_1592, relu__default_14, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_1592 = None
        mul_tensor_234 = torch.ops.aten.mul.Tensor(to_dtype_692, getitem_47);  getitem_47 = None
        mul_tensor_235 = torch.ops.aten.mul.Tensor(to_dtype_692, sigmoid_default_3);  to_dtype_692 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(mul_tensor_234, [2, 3], True);  mul_tensor_234 = None
        to_dtype_693 = torch.ops.aten.to.dtype(sum_dim_int_list_47, torch.float32);  sum_dim_int_list_47 = None
        to_dtype_694 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_46 = torch.ops.aten.rsub.Scalar(to_dtype_694, 1)
        mul_tensor_236 = torch.ops.aten.mul.Tensor(to_dtype_694, rsub_scalar_46);  to_dtype_694 = rsub_scalar_46 = None
        conj_physical_default_46 = torch.ops.aten.conj_physical.default(mul_tensor_236);  mul_tensor_236 = None
        mul_tensor_237 = torch.ops.aten.mul.Tensor(to_dtype_693, conj_physical_default_46);  to_dtype_693 = conj_physical_default_46 = None
        to_dtype_695 = torch.ops.aten.to.dtype(mul_tensor_237, torch.float32);  mul_tensor_237 = None
        convolution_backward_default_233 = torch.ops.aten.convolution_backward.default(to_dtype_695, relu__default_17, primals_120, [512], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_695 = primals_120 = None
        getitem_1595 = convolution_backward_default_233[0]
        getitem_1596 = convolution_backward_default_233[1]
        getitem_1597 = convolution_backward_default_233[2];  convolution_backward_default_233 = None
        to_dtype_696 = torch.ops.aten.to.dtype(getitem_1595, torch.float32);  getitem_1595 = None
        to_dtype_697 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_185 = torch.ops.aten.le.Scalar(to_dtype_697, 0);  to_dtype_697 = None
        new_zeros_default_342 = torch.ops.aten.new_zeros.default(to_dtype_696, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_185 = torch.ops.aten.where.self(le_scalar_185, new_zeros_default_342, to_dtype_696);  le_scalar_185 = new_zeros_default_342 = to_dtype_696 = None
        to_dtype_698 = torch.ops.aten.to.dtype(where_self_185, torch.float32);  where_self_185 = None
        convolution_backward_default_234 = torch.ops.aten.convolution_backward.default(to_dtype_698, mean_dim_3, primals_118, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_698 = mean_dim_3 = primals_118 = None
        getitem_1598 = convolution_backward_default_234[0]
        getitem_1599 = convolution_backward_default_234[1]
        getitem_1600 = convolution_backward_default_234[2];  convolution_backward_default_234 = None
        expand_default_47 = torch.ops.aten.expand.default(getitem_1598, [64, 512, 40, 40]);  getitem_1598 = None
        div_scalar_47 = torch.ops.aten.div.Scalar(expand_default_47, 1600);  expand_default_47 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(mul_tensor_235, div_scalar_47);  mul_tensor_235 = div_scalar_47 = None
        native_batch_norm_backward_default_141 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_92, convolution_default_21, primals_107, primals_105, primals_106, getitem_48, getitem_49, True, 1e-05, [True, True, True]);  add_tensor_92 = convolution_default_21 = primals_107 = primals_105 = primals_106 = getitem_48 = getitem_49 = None
        getitem_1601 = native_batch_norm_backward_default_141[0]
        getitem_1602 = native_batch_norm_backward_default_141[1]
        getitem_1603 = native_batch_norm_backward_default_141[2];  native_batch_norm_backward_default_141 = None
        convolution_backward_default_235 = torch.ops.aten.convolution_backward.default(getitem_1601, relu__default_16, primals_110, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1601 = primals_110 = None
        getitem_1604 = convolution_backward_default_235[0]
        getitem_1605 = convolution_backward_default_235[1]
        getitem_1606 = convolution_backward_default_235[2];  convolution_backward_default_235 = None
        to_dtype_699 = torch.ops.aten.to.dtype(getitem_1604, torch.float32);  getitem_1604 = None
        to_dtype_700 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_186 = torch.ops.aten.le.Scalar(to_dtype_700, 0);  to_dtype_700 = None
        new_zeros_default_343 = torch.ops.aten.new_zeros.default(to_dtype_699, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_186 = torch.ops.aten.where.self(le_scalar_186, new_zeros_default_343, to_dtype_699);  le_scalar_186 = new_zeros_default_343 = to_dtype_699 = None
        to_dtype_701 = torch.ops.aten.to.dtype(where_self_186, torch.float32);  where_self_186 = None
        native_batch_norm_backward_default_142 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_701, convolution_default_20, primals_102, primals_100, primals_101, getitem_45, getitem_46, True, 1e-05, [True, True, True]);  to_dtype_701 = convolution_default_20 = primals_102 = primals_100 = primals_101 = getitem_45 = getitem_46 = None
        getitem_1607 = native_batch_norm_backward_default_142[0]
        getitem_1608 = native_batch_norm_backward_default_142[1]
        getitem_1609 = native_batch_norm_backward_default_142[2];  native_batch_norm_backward_default_142 = None
        convolution_backward_default_236 = torch.ops.aten.convolution_backward.default(getitem_1607, relu__default_15, primals_109, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1607 = primals_109 = None
        getitem_1610 = convolution_backward_default_236[0]
        getitem_1611 = convolution_backward_default_236[1]
        getitem_1612 = convolution_backward_default_236[2];  convolution_backward_default_236 = None
        to_dtype_702 = torch.ops.aten.to.dtype(getitem_1610, torch.float32);  getitem_1610 = None
        to_dtype_703 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_187 = torch.ops.aten.le.Scalar(to_dtype_703, 0);  to_dtype_703 = None
        new_zeros_default_344 = torch.ops.aten.new_zeros.default(to_dtype_702, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_187 = torch.ops.aten.where.self(le_scalar_187, new_zeros_default_344, to_dtype_702);  le_scalar_187 = new_zeros_default_344 = to_dtype_702 = None
        to_dtype_704 = torch.ops.aten.to.dtype(where_self_187, torch.float32);  where_self_187 = None
        native_batch_norm_backward_default_143 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_704, convolution_default_19, primals_97, primals_95, primals_96, getitem_42, getitem_43, True, 1e-05, [True, True, True]);  to_dtype_704 = convolution_default_19 = primals_97 = primals_95 = primals_96 = getitem_42 = getitem_43 = None
        getitem_1613 = native_batch_norm_backward_default_143[0]
        getitem_1614 = native_batch_norm_backward_default_143[1]
        getitem_1615 = native_batch_norm_backward_default_143[2];  native_batch_norm_backward_default_143 = None
        convolution_backward_default_237 = torch.ops.aten.convolution_backward.default(getitem_1613, relu__default_14, primals_108, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1613 = primals_108 = None
        getitem_1616 = convolution_backward_default_237[0]
        getitem_1617 = convolution_backward_default_237[1]
        getitem_1618 = convolution_backward_default_237[2];  convolution_backward_default_237 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_2, getitem_1616);  avg_pool2d_backward_default_2 = getitem_1616 = None
        to_dtype_705 = torch.ops.aten.to.dtype(add_tensor_93, torch.float32);  add_tensor_93 = None
        to_dtype_706 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_188 = torch.ops.aten.le.Scalar(to_dtype_706, 0);  to_dtype_706 = None
        new_zeros_default_345 = torch.ops.aten.new_zeros.default(to_dtype_705, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_188 = torch.ops.aten.where.self(le_scalar_188, new_zeros_default_345, to_dtype_705);  le_scalar_188 = new_zeros_default_345 = to_dtype_705 = None
        to_dtype_707 = torch.ops.aten.to.dtype(where_self_188, torch.float32);  where_self_188 = None
        mul_tensor_238 = torch.ops.aten.mul.Tensor(to_dtype_707, getitem_38);  getitem_38 = None
        mul_tensor_239 = torch.ops.aten.mul.Tensor(to_dtype_707, sigmoid_default_2)
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(mul_tensor_238, [2, 3], True);  mul_tensor_238 = None
        to_dtype_708 = torch.ops.aten.to.dtype(sum_dim_int_list_48, torch.float32);  sum_dim_int_list_48 = None
        to_dtype_709 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_47 = torch.ops.aten.rsub.Scalar(to_dtype_709, 1)
        mul_tensor_240 = torch.ops.aten.mul.Tensor(to_dtype_709, rsub_scalar_47);  to_dtype_709 = rsub_scalar_47 = None
        conj_physical_default_47 = torch.ops.aten.conj_physical.default(mul_tensor_240);  mul_tensor_240 = None
        mul_tensor_241 = torch.ops.aten.mul.Tensor(to_dtype_708, conj_physical_default_47);  to_dtype_708 = conj_physical_default_47 = None
        to_dtype_710 = torch.ops.aten.to.dtype(mul_tensor_241, torch.float32);  mul_tensor_241 = None
        convolution_backward_default_238 = torch.ops.aten.convolution_backward.default(to_dtype_710, relu__default_13, primals_92, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_710 = primals_92 = None
        getitem_1619 = convolution_backward_default_238[0]
        getitem_1620 = convolution_backward_default_238[1]
        getitem_1621 = convolution_backward_default_238[2];  convolution_backward_default_238 = None
        to_dtype_711 = torch.ops.aten.to.dtype(getitem_1619, torch.float32);  getitem_1619 = None
        to_dtype_712 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_189 = torch.ops.aten.le.Scalar(to_dtype_712, 0);  to_dtype_712 = None
        new_zeros_default_346 = torch.ops.aten.new_zeros.default(to_dtype_711, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_189 = torch.ops.aten.where.self(le_scalar_189, new_zeros_default_346, to_dtype_711);  le_scalar_189 = new_zeros_default_346 = to_dtype_711 = None
        to_dtype_713 = torch.ops.aten.to.dtype(where_self_189, torch.float32);  where_self_189 = None
        convolution_backward_default_239 = torch.ops.aten.convolution_backward.default(to_dtype_713, mean_dim_2, primals_90, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_713 = mean_dim_2 = primals_90 = None
        getitem_1622 = convolution_backward_default_239[0]
        getitem_1623 = convolution_backward_default_239[1]
        getitem_1624 = convolution_backward_default_239[2];  convolution_backward_default_239 = None
        expand_default_48 = torch.ops.aten.expand.default(getitem_1622, [64, 256, 80, 80]);  getitem_1622 = None
        div_scalar_48 = torch.ops.aten.div.Scalar(expand_default_48, 6400);  expand_default_48 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(mul_tensor_239, div_scalar_48);  mul_tensor_239 = div_scalar_48 = None
        native_batch_norm_backward_default_144 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_94, convolution_default_16, primals_85, primals_83, primals_84, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  add_tensor_94 = convolution_default_16 = primals_85 = primals_83 = primals_84 = getitem_39 = getitem_40 = None
        getitem_1625 = native_batch_norm_backward_default_144[0]
        getitem_1626 = native_batch_norm_backward_default_144[1]
        getitem_1627 = native_batch_norm_backward_default_144[2];  native_batch_norm_backward_default_144 = None
        convolution_backward_default_240 = torch.ops.aten.convolution_backward.default(getitem_1625, relu__default_12, primals_88, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1625 = primals_88 = None
        getitem_1628 = convolution_backward_default_240[0]
        getitem_1629 = convolution_backward_default_240[1]
        getitem_1630 = convolution_backward_default_240[2];  convolution_backward_default_240 = None
        to_dtype_714 = torch.ops.aten.to.dtype(getitem_1628, torch.float32);  getitem_1628 = None
        to_dtype_715 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_190 = torch.ops.aten.le.Scalar(to_dtype_715, 0);  to_dtype_715 = None
        new_zeros_default_347 = torch.ops.aten.new_zeros.default(to_dtype_714, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_190 = torch.ops.aten.where.self(le_scalar_190, new_zeros_default_347, to_dtype_714);  le_scalar_190 = new_zeros_default_347 = to_dtype_714 = None
        to_dtype_716 = torch.ops.aten.to.dtype(where_self_190, torch.float32);  where_self_190 = None
        native_batch_norm_backward_default_145 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_716, convolution_default_15, primals_80, primals_78, primals_79, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  to_dtype_716 = convolution_default_15 = primals_80 = primals_78 = primals_79 = getitem_36 = getitem_37 = None
        getitem_1631 = native_batch_norm_backward_default_145[0]
        getitem_1632 = native_batch_norm_backward_default_145[1]
        getitem_1633 = native_batch_norm_backward_default_145[2];  native_batch_norm_backward_default_145 = None
        convolution_backward_default_241 = torch.ops.aten.convolution_backward.default(getitem_1631, relu__default_11, primals_87, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1631 = primals_87 = None
        getitem_1634 = convolution_backward_default_241[0]
        getitem_1635 = convolution_backward_default_241[1]
        getitem_1636 = convolution_backward_default_241[2];  convolution_backward_default_241 = None
        to_dtype_717 = torch.ops.aten.to.dtype(getitem_1634, torch.float32);  getitem_1634 = None
        to_dtype_718 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_191 = torch.ops.aten.le.Scalar(to_dtype_718, 0);  to_dtype_718 = None
        new_zeros_default_348 = torch.ops.aten.new_zeros.default(to_dtype_717, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_191 = torch.ops.aten.where.self(le_scalar_191, new_zeros_default_348, to_dtype_717);  le_scalar_191 = new_zeros_default_348 = to_dtype_717 = None
        to_dtype_719 = torch.ops.aten.to.dtype(where_self_191, torch.float32);  where_self_191 = None
        native_batch_norm_backward_default_146 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_719, convolution_default_14, primals_75, primals_73, primals_74, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  to_dtype_719 = convolution_default_14 = primals_75 = primals_73 = primals_74 = getitem_33 = getitem_34 = None
        getitem_1637 = native_batch_norm_backward_default_146[0]
        getitem_1638 = native_batch_norm_backward_default_146[1]
        getitem_1639 = native_batch_norm_backward_default_146[2];  native_batch_norm_backward_default_146 = None
        convolution_backward_default_242 = torch.ops.aten.convolution_backward.default(getitem_1637, relu__default_10, primals_86, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1637 = primals_86 = None
        getitem_1640 = convolution_backward_default_242[0]
        getitem_1641 = convolution_backward_default_242[1]
        getitem_1642 = convolution_backward_default_242[2];  convolution_backward_default_242 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(to_dtype_707, getitem_1640);  to_dtype_707 = getitem_1640 = None
        to_dtype_720 = torch.ops.aten.to.dtype(add_tensor_95, torch.float32);  add_tensor_95 = None
        to_dtype_721 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_192 = torch.ops.aten.le.Scalar(to_dtype_721, 0);  to_dtype_721 = None
        new_zeros_default_349 = torch.ops.aten.new_zeros.default(to_dtype_720, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_192 = torch.ops.aten.where.self(le_scalar_192, new_zeros_default_349, to_dtype_720);  le_scalar_192 = new_zeros_default_349 = to_dtype_720 = None
        to_dtype_722 = torch.ops.aten.to.dtype(where_self_192, torch.float32);  where_self_192 = None
        mul_tensor_242 = torch.ops.aten.mul.Tensor(to_dtype_722, getitem_29);  getitem_29 = None
        mul_tensor_243 = torch.ops.aten.mul.Tensor(to_dtype_722, sigmoid_default_1)
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(mul_tensor_242, [2, 3], True);  mul_tensor_242 = None
        to_dtype_723 = torch.ops.aten.to.dtype(sum_dim_int_list_49, torch.float32);  sum_dim_int_list_49 = None
        to_dtype_724 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_48 = torch.ops.aten.rsub.Scalar(to_dtype_724, 1)
        mul_tensor_244 = torch.ops.aten.mul.Tensor(to_dtype_724, rsub_scalar_48);  to_dtype_724 = rsub_scalar_48 = None
        conj_physical_default_48 = torch.ops.aten.conj_physical.default(mul_tensor_244);  mul_tensor_244 = None
        mul_tensor_245 = torch.ops.aten.mul.Tensor(to_dtype_723, conj_physical_default_48);  to_dtype_723 = conj_physical_default_48 = None
        to_dtype_725 = torch.ops.aten.to.dtype(mul_tensor_245, torch.float32);  mul_tensor_245 = None
        convolution_backward_default_243 = torch.ops.aten.convolution_backward.default(to_dtype_725, relu__default_9, primals_70, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_725 = primals_70 = None
        getitem_1643 = convolution_backward_default_243[0]
        getitem_1644 = convolution_backward_default_243[1]
        getitem_1645 = convolution_backward_default_243[2];  convolution_backward_default_243 = None
        to_dtype_726 = torch.ops.aten.to.dtype(getitem_1643, torch.float32);  getitem_1643 = None
        to_dtype_727 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_193 = torch.ops.aten.le.Scalar(to_dtype_727, 0);  to_dtype_727 = None
        new_zeros_default_350 = torch.ops.aten.new_zeros.default(to_dtype_726, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_193 = torch.ops.aten.where.self(le_scalar_193, new_zeros_default_350, to_dtype_726);  le_scalar_193 = new_zeros_default_350 = to_dtype_726 = None
        to_dtype_728 = torch.ops.aten.to.dtype(where_self_193, torch.float32);  where_self_193 = None
        convolution_backward_default_244 = torch.ops.aten.convolution_backward.default(to_dtype_728, mean_dim_1, primals_68, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_728 = mean_dim_1 = primals_68 = None
        getitem_1646 = convolution_backward_default_244[0]
        getitem_1647 = convolution_backward_default_244[1]
        getitem_1648 = convolution_backward_default_244[2];  convolution_backward_default_244 = None
        expand_default_49 = torch.ops.aten.expand.default(getitem_1646, [64, 256, 80, 80]);  getitem_1646 = None
        div_scalar_49 = torch.ops.aten.div.Scalar(expand_default_49, 6400);  expand_default_49 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(mul_tensor_243, div_scalar_49);  mul_tensor_243 = div_scalar_49 = None
        native_batch_norm_backward_default_147 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_96, convolution_default_11, primals_63, primals_61, primals_62, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  add_tensor_96 = convolution_default_11 = primals_63 = primals_61 = primals_62 = getitem_30 = getitem_31 = None
        getitem_1649 = native_batch_norm_backward_default_147[0]
        getitem_1650 = native_batch_norm_backward_default_147[1]
        getitem_1651 = native_batch_norm_backward_default_147[2];  native_batch_norm_backward_default_147 = None
        convolution_backward_default_245 = torch.ops.aten.convolution_backward.default(getitem_1649, relu__default_8, primals_66, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1649 = primals_66 = None
        getitem_1652 = convolution_backward_default_245[0]
        getitem_1653 = convolution_backward_default_245[1]
        getitem_1654 = convolution_backward_default_245[2];  convolution_backward_default_245 = None
        to_dtype_729 = torch.ops.aten.to.dtype(getitem_1652, torch.float32);  getitem_1652 = None
        to_dtype_730 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_194 = torch.ops.aten.le.Scalar(to_dtype_730, 0);  to_dtype_730 = None
        new_zeros_default_351 = torch.ops.aten.new_zeros.default(to_dtype_729, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_194 = torch.ops.aten.where.self(le_scalar_194, new_zeros_default_351, to_dtype_729);  le_scalar_194 = new_zeros_default_351 = to_dtype_729 = None
        to_dtype_731 = torch.ops.aten.to.dtype(where_self_194, torch.float32);  where_self_194 = None
        native_batch_norm_backward_default_148 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_731, convolution_default_10, primals_58, primals_56, primals_57, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_731 = convolution_default_10 = primals_58 = primals_56 = primals_57 = getitem_27 = getitem_28 = None
        getitem_1655 = native_batch_norm_backward_default_148[0]
        getitem_1656 = native_batch_norm_backward_default_148[1]
        getitem_1657 = native_batch_norm_backward_default_148[2];  native_batch_norm_backward_default_148 = None
        convolution_backward_default_246 = torch.ops.aten.convolution_backward.default(getitem_1655, relu__default_7, primals_65, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1655 = primals_65 = None
        getitem_1658 = convolution_backward_default_246[0]
        getitem_1659 = convolution_backward_default_246[1]
        getitem_1660 = convolution_backward_default_246[2];  convolution_backward_default_246 = None
        to_dtype_732 = torch.ops.aten.to.dtype(getitem_1658, torch.float32);  getitem_1658 = None
        to_dtype_733 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_195 = torch.ops.aten.le.Scalar(to_dtype_733, 0);  to_dtype_733 = None
        new_zeros_default_352 = torch.ops.aten.new_zeros.default(to_dtype_732, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_195 = torch.ops.aten.where.self(le_scalar_195, new_zeros_default_352, to_dtype_732);  le_scalar_195 = new_zeros_default_352 = to_dtype_732 = None
        to_dtype_734 = torch.ops.aten.to.dtype(where_self_195, torch.float32);  where_self_195 = None
        native_batch_norm_backward_default_149 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_734, convolution_default_9, primals_53, primals_51, primals_52, getitem_24, getitem_25, True, 1e-05, [True, True, True]);  to_dtype_734 = convolution_default_9 = primals_53 = primals_51 = primals_52 = getitem_24 = getitem_25 = None
        getitem_1661 = native_batch_norm_backward_default_149[0]
        getitem_1662 = native_batch_norm_backward_default_149[1]
        getitem_1663 = native_batch_norm_backward_default_149[2];  native_batch_norm_backward_default_149 = None
        convolution_backward_default_247 = torch.ops.aten.convolution_backward.default(getitem_1661, relu__default_6, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1661 = primals_64 = None
        getitem_1664 = convolution_backward_default_247[0]
        getitem_1665 = convolution_backward_default_247[1]
        getitem_1666 = convolution_backward_default_247[2];  convolution_backward_default_247 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(to_dtype_722, getitem_1664);  to_dtype_722 = getitem_1664 = None
        to_dtype_735 = torch.ops.aten.to.dtype(add_tensor_97, torch.float32);  add_tensor_97 = None
        to_dtype_736 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_196 = torch.ops.aten.le.Scalar(to_dtype_736, 0);  to_dtype_736 = None
        new_zeros_default_353 = torch.ops.aten.new_zeros.default(to_dtype_735, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_196 = torch.ops.aten.where.self(le_scalar_196, new_zeros_default_353, to_dtype_735);  le_scalar_196 = new_zeros_default_353 = to_dtype_735 = None
        to_dtype_737 = torch.ops.aten.to.dtype(where_self_196, torch.float32);  where_self_196 = None
        native_batch_norm_backward_default_150 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_737, convolution_default_8, primals_44, primals_42, primals_43, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  convolution_default_8 = primals_44 = primals_42 = primals_43 = getitem_21 = getitem_22 = None
        getitem_1667 = native_batch_norm_backward_default_150[0]
        getitem_1668 = native_batch_norm_backward_default_150[1]
        getitem_1669 = native_batch_norm_backward_default_150[2];  native_batch_norm_backward_default_150 = None
        convolution_backward_default_248 = torch.ops.aten.convolution_backward.default(getitem_1667, getitem_9, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1667 = primals_39 = None
        getitem_1670 = convolution_backward_default_248[0]
        getitem_1671 = convolution_backward_default_248[1]
        getitem_1672 = convolution_backward_default_248[2];  convolution_backward_default_248 = None
        mul_tensor_246 = torch.ops.aten.mul.Tensor(to_dtype_737, getitem_17);  getitem_17 = None
        mul_tensor_247 = torch.ops.aten.mul.Tensor(to_dtype_737, sigmoid_default);  to_dtype_737 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(mul_tensor_246, [2, 3], True);  mul_tensor_246 = None
        to_dtype_738 = torch.ops.aten.to.dtype(sum_dim_int_list_50, torch.float32);  sum_dim_int_list_50 = None
        to_dtype_739 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_49 = torch.ops.aten.rsub.Scalar(to_dtype_739, 1)
        mul_tensor_248 = torch.ops.aten.mul.Tensor(to_dtype_739, rsub_scalar_49);  to_dtype_739 = rsub_scalar_49 = None
        conj_physical_default_49 = torch.ops.aten.conj_physical.default(mul_tensor_248);  mul_tensor_248 = None
        mul_tensor_249 = torch.ops.aten.mul.Tensor(to_dtype_738, conj_physical_default_49);  to_dtype_738 = conj_physical_default_49 = None
        to_dtype_740 = torch.ops.aten.to.dtype(mul_tensor_249, torch.float32);  mul_tensor_249 = None
        convolution_backward_default_249 = torch.ops.aten.convolution_backward.default(to_dtype_740, relu__default_5, primals_48, [256], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_740 = primals_48 = None
        getitem_1673 = convolution_backward_default_249[0]
        getitem_1674 = convolution_backward_default_249[1]
        getitem_1675 = convolution_backward_default_249[2];  convolution_backward_default_249 = None
        to_dtype_741 = torch.ops.aten.to.dtype(getitem_1673, torch.float32);  getitem_1673 = None
        to_dtype_742 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_197 = torch.ops.aten.le.Scalar(to_dtype_742, 0);  to_dtype_742 = None
        new_zeros_default_354 = torch.ops.aten.new_zeros.default(to_dtype_741, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_197 = torch.ops.aten.where.self(le_scalar_197, new_zeros_default_354, to_dtype_741);  le_scalar_197 = new_zeros_default_354 = to_dtype_741 = None
        to_dtype_743 = torch.ops.aten.to.dtype(where_self_197, torch.float32);  where_self_197 = None
        convolution_backward_default_250 = torch.ops.aten.convolution_backward.default(to_dtype_743, mean_dim, primals_46, [16], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_743 = mean_dim = primals_46 = None
        getitem_1676 = convolution_backward_default_250[0]
        getitem_1677 = convolution_backward_default_250[1]
        getitem_1678 = convolution_backward_default_250[2];  convolution_backward_default_250 = None
        expand_default_50 = torch.ops.aten.expand.default(getitem_1676, [64, 256, 80, 80]);  getitem_1676 = None
        div_scalar_50 = torch.ops.aten.div.Scalar(expand_default_50, 6400);  expand_default_50 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(mul_tensor_247, div_scalar_50);  mul_tensor_247 = div_scalar_50 = None
        native_batch_norm_backward_default_151 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_98, convolution_default_5, primals_35, primals_33, primals_34, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  add_tensor_98 = convolution_default_5 = primals_35 = primals_33 = primals_34 = getitem_18 = getitem_19 = None
        getitem_1679 = native_batch_norm_backward_default_151[0]
        getitem_1680 = native_batch_norm_backward_default_151[1]
        getitem_1681 = native_batch_norm_backward_default_151[2];  native_batch_norm_backward_default_151 = None
        convolution_backward_default_251 = torch.ops.aten.convolution_backward.default(getitem_1679, relu__default_4, primals_38, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1679 = primals_38 = None
        getitem_1682 = convolution_backward_default_251[0]
        getitem_1683 = convolution_backward_default_251[1]
        getitem_1684 = convolution_backward_default_251[2];  convolution_backward_default_251 = None
        to_dtype_744 = torch.ops.aten.to.dtype(getitem_1682, torch.float32);  getitem_1682 = None
        to_dtype_745 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_198 = torch.ops.aten.le.Scalar(to_dtype_745, 0);  to_dtype_745 = None
        new_zeros_default_355 = torch.ops.aten.new_zeros.default(to_dtype_744, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_198 = torch.ops.aten.where.self(le_scalar_198, new_zeros_default_355, to_dtype_744);  le_scalar_198 = new_zeros_default_355 = to_dtype_744 = None
        to_dtype_746 = torch.ops.aten.to.dtype(where_self_198, torch.float32);  where_self_198 = None
        native_batch_norm_backward_default_152 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_746, convolution_default_4, primals_30, primals_28, primals_29, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  to_dtype_746 = convolution_default_4 = primals_30 = primals_28 = primals_29 = getitem_15 = getitem_16 = None
        getitem_1685 = native_batch_norm_backward_default_152[0]
        getitem_1686 = native_batch_norm_backward_default_152[1]
        getitem_1687 = native_batch_norm_backward_default_152[2];  native_batch_norm_backward_default_152 = None
        convolution_backward_default_252 = torch.ops.aten.convolution_backward.default(getitem_1685, relu__default_3, primals_37, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1685 = primals_37 = None
        getitem_1688 = convolution_backward_default_252[0]
        getitem_1689 = convolution_backward_default_252[1]
        getitem_1690 = convolution_backward_default_252[2];  convolution_backward_default_252 = None
        to_dtype_747 = torch.ops.aten.to.dtype(getitem_1688, torch.float32);  getitem_1688 = None
        to_dtype_748 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_199 = torch.ops.aten.le.Scalar(to_dtype_748, 0);  to_dtype_748 = None
        new_zeros_default_356 = torch.ops.aten.new_zeros.default(to_dtype_747, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_199 = torch.ops.aten.where.self(le_scalar_199, new_zeros_default_356, to_dtype_747);  le_scalar_199 = new_zeros_default_356 = to_dtype_747 = None
        to_dtype_749 = torch.ops.aten.to.dtype(where_self_199, torch.float32);  where_self_199 = None
        native_batch_norm_backward_default_153 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_749, convolution_default_3, primals_25, primals_23, primals_24, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  to_dtype_749 = convolution_default_3 = primals_25 = primals_23 = primals_24 = getitem_12 = getitem_13 = None
        getitem_1691 = native_batch_norm_backward_default_153[0]
        getitem_1692 = native_batch_norm_backward_default_153[1]
        getitem_1693 = native_batch_norm_backward_default_153[2];  native_batch_norm_backward_default_153 = None
        convolution_backward_default_253 = torch.ops.aten.convolution_backward.default(getitem_1691, getitem_9, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1691 = getitem_9 = primals_36 = None
        getitem_1694 = convolution_backward_default_253[0]
        getitem_1695 = convolution_backward_default_253[1]
        getitem_1696 = convolution_backward_default_253[2];  convolution_backward_default_253 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(getitem_1670, getitem_1694);  getitem_1670 = getitem_1694 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_99, relu__default_2, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_10);  add_tensor_99 = getitem_10 = None
        to_dtype_750 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_751 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_200 = torch.ops.aten.le.Scalar(to_dtype_751, 0);  to_dtype_751 = None
        new_zeros_default_357 = torch.ops.aten.new_zeros.default(to_dtype_750, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_200 = torch.ops.aten.where.self(le_scalar_200, new_zeros_default_357, to_dtype_750);  le_scalar_200 = new_zeros_default_357 = to_dtype_750 = None
        to_dtype_752 = torch.ops.aten.to.dtype(where_self_200, torch.float32);  where_self_200 = None
        native_batch_norm_backward_default_154 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_752, convolution_default_2, primals_5, primals_3, primals_4, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_752 = convolution_default_2 = primals_5 = primals_3 = primals_4 = getitem_7 = getitem_8 = None
        getitem_1697 = native_batch_norm_backward_default_154[0]
        getitem_1698 = native_batch_norm_backward_default_154[1]
        getitem_1699 = native_batch_norm_backward_default_154[2];  native_batch_norm_backward_default_154 = None
        convolution_backward_default_254 = torch.ops.aten.convolution_backward.default(getitem_1697, relu__default_1, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1697 = primals_18 = None
        getitem_1700 = convolution_backward_default_254[0]
        getitem_1701 = convolution_backward_default_254[1]
        getitem_1702 = convolution_backward_default_254[2];  convolution_backward_default_254 = None
        to_dtype_753 = torch.ops.aten.to.dtype(getitem_1700, torch.float32);  getitem_1700 = None
        to_dtype_754 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_201 = torch.ops.aten.le.Scalar(to_dtype_754, 0);  to_dtype_754 = None
        new_zeros_default_358 = torch.ops.aten.new_zeros.default(to_dtype_753, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_201 = torch.ops.aten.where.self(le_scalar_201, new_zeros_default_358, to_dtype_753);  le_scalar_201 = new_zeros_default_358 = to_dtype_753 = None
        to_dtype_755 = torch.ops.aten.to.dtype(where_self_201, torch.float32);  where_self_201 = None
        native_batch_norm_backward_default_155 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_755, convolution_default_1, primals_17, primals_15, primals_16, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_755 = convolution_default_1 = primals_17 = primals_15 = primals_16 = getitem_4 = getitem_5 = None
        getitem_1703 = native_batch_norm_backward_default_155[0]
        getitem_1704 = native_batch_norm_backward_default_155[1]
        getitem_1705 = native_batch_norm_backward_default_155[2];  native_batch_norm_backward_default_155 = None
        convolution_backward_default_255 = torch.ops.aten.convolution_backward.default(getitem_1703, relu__default, primals_12, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1703 = primals_12 = None
        getitem_1706 = convolution_backward_default_255[0]
        getitem_1707 = convolution_backward_default_255[1]
        getitem_1708 = convolution_backward_default_255[2];  convolution_backward_default_255 = None
        to_dtype_756 = torch.ops.aten.to.dtype(getitem_1706, torch.float32);  getitem_1706 = None
        to_dtype_757 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_202 = torch.ops.aten.le.Scalar(to_dtype_757, 0);  to_dtype_757 = None
        new_zeros_default_359 = torch.ops.aten.new_zeros.default(to_dtype_756, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_202 = torch.ops.aten.where.self(le_scalar_202, new_zeros_default_359, to_dtype_756);  le_scalar_202 = new_zeros_default_359 = to_dtype_756 = None
        to_dtype_758 = torch.ops.aten.to.dtype(where_self_202, torch.float32);  where_self_202 = None
        native_batch_norm_backward_default_156 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_758, convolution_default, primals_11, primals_9, primals_10, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_758 = convolution_default = primals_11 = primals_9 = primals_10 = getitem_1 = getitem_2 = None
        getitem_1709 = native_batch_norm_backward_default_156[0]
        getitem_1710 = native_batch_norm_backward_default_156[1]
        getitem_1711 = native_batch_norm_backward_default_156[2];  native_batch_norm_backward_default_156 = None
        convolution_backward_default_256 = torch.ops.aten.convolution_backward.default(getitem_1709, primals_1145, primals_6, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1709 = primals_1145 = primals_6 = None
        getitem_1712 = convolution_backward_default_256[0]
        getitem_1713 = convolution_backward_default_256[1]
        getitem_1714 = convolution_backward_default_256[2];  convolution_backward_default_256 = None
        return [addmm_default, getitem_1699, None, None, None, getitem_1698, getitem_1713, getitem_1711, None, None, None, getitem_1710, getitem_1707, getitem_1705, None, None, None, getitem_1704, getitem_1701, view_default_1, t_default_4, getitem_1693, None, None, None, getitem_1692, getitem_1687, None, None, None, getitem_1686, getitem_1681, None, None, None, getitem_1680, getitem_1695, getitem_1689, getitem_1683, getitem_1671, getitem_1669, None, None, None, getitem_1668, getitem_1678, getitem_1677, getitem_1675, getitem_1674, getitem_1663, None, None, None, getitem_1662, getitem_1657, None, None, None, getitem_1656, getitem_1651, None, None, None, getitem_1650, getitem_1665, getitem_1659, getitem_1653, getitem_1648, getitem_1647, getitem_1645, getitem_1644, getitem_1639, None, None, None, getitem_1638, getitem_1633, None, None, None, getitem_1632, getitem_1627, None, None, None, getitem_1626, getitem_1641, getitem_1635, getitem_1629, getitem_1624, getitem_1623, getitem_1621, getitem_1620, getitem_1615, None, None, None, getitem_1614, getitem_1609, None, None, None, getitem_1608, getitem_1603, None, None, None, getitem_1602, getitem_1617, getitem_1611, getitem_1605, getitem_1593, getitem_1591, None, None, None, getitem_1590, getitem_1600, getitem_1599, getitem_1597, getitem_1596, getitem_1585, None, None, None, getitem_1584, getitem_1579, None, None, None, getitem_1578, getitem_1573, None, None, None, getitem_1572, getitem_1587, getitem_1581, getitem_1575, getitem_1570, getitem_1569, getitem_1567, getitem_1566, getitem_1561, None, None, None, getitem_1560, getitem_1555, None, None, None, getitem_1554, getitem_1549, None, None, None, getitem_1548, getitem_1563, getitem_1557, getitem_1551, getitem_1546, getitem_1545, getitem_1543, getitem_1542, getitem_1537, None, None, None, getitem_1536, getitem_1531, None, None, None, getitem_1530, getitem_1525, None, None, None, getitem_1524, getitem_1539, getitem_1533, getitem_1527, getitem_1522, getitem_1521, getitem_1519, getitem_1518, getitem_1513, None, None, None, getitem_1512, getitem_1507, None, None, None, getitem_1506, getitem_1501, None, None, None, getitem_1500, getitem_1515, getitem_1509, getitem_1503, getitem_1498, getitem_1497, getitem_1495, getitem_1494, getitem_1489, None, None, None, getitem_1488, getitem_1483, None, None, None, getitem_1482, getitem_1477, None, None, None, getitem_1476, getitem_1491, getitem_1485, getitem_1479, getitem_1474, getitem_1473, getitem_1471, getitem_1470, getitem_1465, None, None, None, getitem_1464, getitem_1459, None, None, None, getitem_1458, getitem_1453, None, None, None, getitem_1452, getitem_1467, getitem_1461, getitem_1455, getitem_1450, getitem_1449, getitem_1447, getitem_1446, getitem_1441, None, None, None, getitem_1440, getitem_1435, None, None, None, getitem_1434, getitem_1429, None, None, None, getitem_1428, getitem_1443, getitem_1437, getitem_1431, getitem_1426, getitem_1425, getitem_1423, getitem_1422, getitem_1417, None, None, None, getitem_1416, getitem_1411, None, None, None, getitem_1410, getitem_1405, None, None, None, getitem_1404, getitem_1419, getitem_1413, getitem_1407, getitem_1395, getitem_1393, None, None, None, getitem_1392, getitem_1402, getitem_1401, getitem_1399, getitem_1398, getitem_1171, None, None, None, getitem_1170, getitem_1165, None, None, None, getitem_1164, getitem_1159, None, None, None, getitem_1158, getitem_1173, getitem_1167, getitem_1161, getitem_1156, getitem_1155, getitem_1153, getitem_1152, getitem_1147, None, None, None, getitem_1146, getitem_1141, None, None, None, getitem_1140, getitem_1135, None, None, None, getitem_1134, getitem_1149, getitem_1143, getitem_1137, getitem_1132, getitem_1131, getitem_1129, getitem_1128, getitem_1123, None, None, None, getitem_1122, getitem_1117, None, None, None, getitem_1116, getitem_1111, None, None, None, getitem_1110, getitem_1125, getitem_1119, getitem_1113, getitem_1108, getitem_1107, getitem_1105, getitem_1104, getitem_1099, None, None, None, getitem_1098, getitem_1093, None, None, None, getitem_1092, getitem_1087, None, None, None, getitem_1086, getitem_1101, getitem_1095, getitem_1089, getitem_1084, getitem_1083, getitem_1081, getitem_1080, getitem_1075, None, None, None, getitem_1074, getitem_1069, None, None, None, getitem_1068, getitem_1063, None, None, None, getitem_1062, getitem_1077, getitem_1071, getitem_1065, getitem_1060, getitem_1059, getitem_1057, getitem_1056, getitem_1051, None, None, None, getitem_1050, getitem_1045, None, None, None, getitem_1044, getitem_1039, None, None, None, getitem_1038, getitem_1053, getitem_1047, getitem_1041, getitem_1036, getitem_1035, getitem_1033, getitem_1032, getitem_1027, None, None, None, getitem_1026, getitem_1021, None, None, None, getitem_1020, getitem_1015, None, None, None, getitem_1014, getitem_1029, getitem_1023, getitem_1017, getitem_1012, getitem_1011, getitem_1009, getitem_1008, getitem_1003, None, None, None, getitem_1002, getitem_997, None, None, None, getitem_996, getitem_991, None, None, None, getitem_990, getitem_1005, getitem_999, getitem_993, getitem_988, getitem_987, getitem_985, getitem_984, getitem_979, None, None, None, getitem_978, getitem_973, None, None, None, getitem_972, getitem_967, None, None, None, getitem_966, getitem_981, getitem_975, getitem_969, getitem_964, getitem_963, getitem_961, getitem_960, getitem_955, None, None, None, getitem_954, getitem_949, None, None, None, getitem_948, getitem_943, None, None, None, getitem_942, getitem_957, getitem_951, getitem_945, getitem_940, getitem_939, getitem_937, getitem_936, getitem_1387, None, None, None, getitem_1386, getitem_1381, None, None, None, getitem_1380, getitem_1375, None, None, None, getitem_1374, getitem_1389, getitem_1383, getitem_1377, getitem_1372, getitem_1371, getitem_1369, getitem_1368, getitem_931, None, None, None, getitem_930, getitem_925, None, None, None, getitem_924, getitem_919, None, None, None, getitem_918, getitem_933, getitem_927, getitem_921, getitem_916, getitem_915, getitem_913, getitem_912, getitem_907, None, None, None, getitem_906, getitem_901, None, None, None, getitem_900, getitem_895, None, None, None, getitem_894, getitem_909, getitem_903, getitem_897, getitem_892, getitem_891, getitem_889, getitem_888, getitem_883, None, None, None, getitem_882, getitem_877, None, None, None, getitem_876, getitem_871, None, None, None, getitem_870, getitem_885, getitem_879, getitem_873, getitem_868, getitem_867, getitem_865, getitem_864, getitem_859, None, None, None, getitem_858, getitem_853, None, None, None, getitem_852, getitem_847, None, None, None, getitem_846, getitem_861, getitem_855, getitem_849, getitem_844, getitem_843, getitem_841, getitem_840, getitem_835, None, None, None, getitem_834, getitem_829, None, None, None, getitem_828, getitem_823, None, None, None, getitem_822, getitem_837, getitem_831, getitem_825, getitem_820, getitem_819, getitem_817, getitem_816, getitem_811, None, None, None, getitem_810, getitem_805, None, None, None, getitem_804, getitem_799, None, None, None, getitem_798, getitem_813, getitem_807, getitem_801, getitem_796, getitem_795, getitem_793, getitem_792, getitem_787, None, None, None, getitem_786, getitem_781, None, None, None, getitem_780, getitem_775, None, None, None, getitem_774, getitem_789, getitem_783, getitem_777, getitem_772, getitem_771, getitem_769, getitem_768, getitem_763, None, None, None, getitem_762, getitem_757, None, None, None, getitem_756, getitem_751, None, None, None, getitem_750, getitem_765, getitem_759, getitem_753, getitem_748, getitem_747, getitem_745, getitem_744, getitem_739, None, None, None, getitem_738, getitem_733, None, None, None, getitem_732, getitem_727, None, None, None, getitem_726, getitem_741, getitem_735, getitem_729, getitem_724, getitem_723, getitem_721, getitem_720, getitem_715, None, None, None, getitem_714, getitem_709, None, None, None, getitem_708, getitem_703, None, None, None, getitem_702, getitem_717, getitem_711, getitem_705, getitem_700, getitem_699, getitem_697, getitem_696, getitem_1363, None, None, None, getitem_1362, getitem_1357, None, None, None, getitem_1356, getitem_1351, None, None, None, getitem_1350, getitem_1365, getitem_1359, getitem_1353, getitem_1348, getitem_1347, getitem_1345, getitem_1344, getitem_691, None, None, None, getitem_690, getitem_685, None, None, None, getitem_684, getitem_679, None, None, None, getitem_678, getitem_693, getitem_687, getitem_681, getitem_676, getitem_675, getitem_673, getitem_672, getitem_667, None, None, None, getitem_666, getitem_661, None, None, None, getitem_660, getitem_655, None, None, None, getitem_654, getitem_669, getitem_663, getitem_657, getitem_652, getitem_651, getitem_649, getitem_648, getitem_643, None, None, None, getitem_642, getitem_637, None, None, None, getitem_636, getitem_631, None, None, None, getitem_630, getitem_645, getitem_639, getitem_633, getitem_628, getitem_627, getitem_625, getitem_624, getitem_619, None, None, None, getitem_618, getitem_613, None, None, None, getitem_612, getitem_607, None, None, None, getitem_606, getitem_621, getitem_615, getitem_609, getitem_604, getitem_603, getitem_601, getitem_600, getitem_595, None, None, None, getitem_594, getitem_589, None, None, None, getitem_588, getitem_583, None, None, None, getitem_582, getitem_597, getitem_591, getitem_585, getitem_580, getitem_579, getitem_577, getitem_576, getitem_571, None, None, None, getitem_570, getitem_565, None, None, None, getitem_564, getitem_559, None, None, None, getitem_558, getitem_573, getitem_567, getitem_561, getitem_556, getitem_555, getitem_553, getitem_552, getitem_1339, None, None, None, getitem_1338, getitem_1333, None, None, None, getitem_1332, getitem_1327, None, None, None, getitem_1326, getitem_1341, getitem_1335, getitem_1329, getitem_1324, getitem_1323, getitem_1321, getitem_1320, getitem_1315, None, None, None, getitem_1314, getitem_1309, None, None, None, getitem_1308, getitem_1303, None, None, None, getitem_1302, getitem_1317, getitem_1311, getitem_1305, getitem_1300, getitem_1299, getitem_1297, getitem_1296, getitem_1291, None, None, None, getitem_1290, getitem_1285, None, None, None, getitem_1284, getitem_1279, None, None, None, getitem_1278, getitem_1293, getitem_1287, getitem_1281, getitem_1276, getitem_1275, getitem_1273, getitem_1272, getitem_1267, None, None, None, getitem_1266, getitem_1261, None, None, None, getitem_1260, getitem_1255, None, None, None, getitem_1254, getitem_1269, getitem_1263, getitem_1257, getitem_1252, getitem_1251, getitem_1249, getitem_1248, getitem_1243, None, None, None, getitem_1242, getitem_1237, None, None, None, getitem_1236, getitem_1231, None, None, None, getitem_1230, getitem_1245, getitem_1239, getitem_1233, getitem_1228, getitem_1227, getitem_1225, getitem_1224, getitem_1219, None, None, None, getitem_1218, getitem_1213, None, None, None, getitem_1212, getitem_1207, None, None, None, getitem_1206, getitem_1221, getitem_1215, getitem_1209, getitem_1204, getitem_1203, getitem_1201, getitem_1200, getitem_1195, None, None, None, getitem_1194, getitem_1189, None, None, None, getitem_1188, getitem_1183, None, None, None, getitem_1182, getitem_1197, getitem_1191, getitem_1185, getitem_1180, getitem_1179, getitem_1177, getitem_1176, getitem_547, None, None, None, getitem_546, getitem_541, None, None, None, getitem_540, getitem_535, None, None, None, getitem_534, getitem_549, getitem_543, getitem_537, getitem_525, getitem_523, None, None, None, getitem_522, getitem_532, getitem_531, getitem_529, getitem_528, getitem_517, None, None, None, getitem_516, getitem_511, None, None, None, getitem_510, getitem_505, None, None, None, getitem_504, getitem_519, getitem_513, getitem_507, getitem_502, getitem_501, getitem_499, getitem_498, getitem_493, None, None, None, getitem_492, getitem_487, None, None, None, getitem_486, getitem_481, None, None, None, getitem_480, getitem_495, getitem_489, getitem_483, getitem_478, getitem_477, getitem_475, getitem_474, None]
        
