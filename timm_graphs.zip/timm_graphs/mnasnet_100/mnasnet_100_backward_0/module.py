
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/mnasnet_100/mnasnet_100_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_97, primals_92, getitem_68, getitem_69, getitem_67, primals_134, primals_88, primals_132, primals_87, primals_133, relu__default_15, primals_98, primals_6, primals_84, convolution_default_23, primals_222, primals_93, primals_219, getitem_71, primals_89, getitem_70, primals_217, primals_218, primals_82, convolution_default_24, primals_79, primals_94, primals_78, primals_5, primals_213, primals_77, primals_214, primals_7, primals_83, primals_212, primals_152, getitem_73, primals_103, getitem_134, getitem_14, relu__default_3, getitem_133, convolution_default, getitem_53, convolution_default_18, convolution_default_5, getitem_15, getitem_52, add_tensor_53, getitem_17, getitem_16, add_tensor_20, getitem_137, convolution_default_45, getitem_139, getitem_136, getitem_56, convolution_default_6, getitem_19, getitem_55, primals_174, relu__default_30, primals_154, primals_143, primals_102, primals_99, convolution_default_46, getitem_20, relu__default_12, convolution_default_19, primals_153, relu__default_4, getitem_140, convolution_default_7, primals_159, primals_244, getitem_6, getitem_38, primals_182, getitem_23, getitem_37, getitem_8, primals_9, primals_247, getitem_7, getitem_22, primals_183, primals_248, primals_149, primals_249, primals_118, relu__default_5, relu__default_8, convolution_default_3, primals_122, primals_252, convolution_default_8, convolution_default_13, primals_253, primals_114, getitem_11, primals_254, getitem_26, getitem_10, getitem_41, getitem_42, getitem_25, getitem_40, primals_144, primals_10, primals_124, primals_257, primals_11, primals_258, primals_8, primals_123, relu__default_2, primals_117, primals_259, convolution_default_9, add_tensor_9, relu__default_9, primals_127, convolution_default_4, primals_119, primals_12, convolution_default_14, primals_262, primals_263, getitem_28, primals_264, getitem_13, getitem_29, primals_57, getitem_59, getitem_74, primals_287, primals_64, primals_13, primals_288, getitem_58, relu__default_13, primals_289, relu__default_16, primals_18, primals_16, convolution_default_25, primals_58, primals_179, convolution_default_20, primals_292, primals_59, primals_68, primals_293, getitem_77, getitem_62, convolution_default_21, getitem_76, primals_294, getitem_61, primals_108, primals_14, primals_297, getitem_64, relu__default_17, primals_298, add_tensor_24, primals_107, primals_299, primals_63, convolution_default_26, primals_15, primals_17, getitem_79, primals_67, primals_302, getitem_65, primals_109, primals_303, convolution_default_27, primals_304, primals_184, relu__default_14, getitem_80, primals_62, convolution_default_22, add_tensor_31, primals_223, primals_307, getitem_44, relu__default_34, primals_224, primals_308, relu__default_31, convolution_default_47, primals_309, convolution_default_15, getitem_43, view_default, primals_45, getitem_113, getitem_98, getitem_114, primals_157, primals_227, getitem_112, primals_158, getitem_97, primals_312, getitem_143, primals_228, convolution_default_48, primals_49, getitem_47, primals_188, getitem_142, primals_229, primals_313, primals_187, getitem_46, primals_314, t_default, primals_48, convolution_default_33, relu__default_25, primals_112, primals_232, getitem_96, add_tensor_57, primals_113, primals_233, relu__default_10, convolution_default_38, getitem_101, primals_234, primals_44, primals_43, getitem_49, getitem_100, getitem_146, convolution_default_16, getitem_116, getitem_145, getitem_115, primals_47, primals_237, primals_238, primals_239, relu__default_22, getitem_50, primals_189, relu__default_32, convolution_default_34, convolution_default_39, relu__default_11, convolution_default_49, primals_242, convolution_default_17, primals_42, primals_243, primals_46, primals_74, primals_267, getitem_83, getitem_5, primals_268, getitem_82, getitem_128, primals_167, primals_269, getitem_127, primals_50, primals_163, primals_25, primals_53, getitem_2, primals_19, primals_162, primals_272, getitem_1, relu__default_18, primals_169, primals_22, primals_273, relu__default_28, primals_164, primals_274, convolution_default_28, relu__default, convolution_default_43, primals_20, getitem_4, getitem_86, convolution_default_1, primals_277, getitem_85, primals_129, getitem_131, primals_278, getitem_130, primals_23, primals_279, primals_173, convolution_default_2, primals_172, relu__default_19, primals_21, primals_282, primals_24, primals_54, relu__default_29, convolution_default_29, relu__default_1, primals_283, primals_55, convolution_default_44, primals_168, primals_284, primals_27, primals_193, primals_28, primals_192, primals_30, primals_147, relu__default_6, primals_40, convolution_default_10, primals_194, primals_178, getitem_32, primals_41, primals_197, getitem_31, primals_31, primals_198, primals_39, primals_199, primals_26, primals_34, primals_128, primals_37, relu__default_7, primals_202, primals_104, getitem_34, primals_203, convolution_default_11, primals_38, primals_204, primals_36, primals_138, primals_35, primals_137, primals_139, primals_177, getitem_35, add_tensor_13, primals_207, primals_29, primals_142, convolution_default_12, primals_208, primals_32, primals_209, primals_33, getitem_88, primals_73, getitem_103, getitem_119, getitem_149, getitem_148, getitem_104, primals_3, relu__default_26, add_tensor_35, relu__default_23, getitem_89, convolution_default_35, relu__default_33, convolution_default_40, getitem_118, getitem_92, convolution_default_30, convolution_default_50, getitem_91, getitem_122, getitem_150, getitem_107, getitem_124, getitem_121, getitem_106, primals_69, getitem_152, primals_2, getitem_109, getitem_151, relu__default_20, convolution_default_36, relu__default_27, primals_148, add_tensor_42, convolution_default_31, getitem_94, convolution_default_41, convolution_default_51, getitem_154, primals_1, convolution_default_42, relu__default_24, relu__default_21, primals_72, getitem_110, getitem_125, getitem_95, convolution_default_37, convolution_default_32, primals_4, getitem_155, add_tensor_49, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50, tangents_51, tangents_52, tangents_53):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1280, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1280, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_52, to_dtype);  le_scalar = new_zeros_default_52 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_51, primals_314, primals_312, primals_313, getitem_154, getitem_155, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_51 = primals_314 = primals_312 = primals_313 = getitem_154 = getitem_155 = None
        getitem_156 = native_batch_norm_backward_default[0]
        getitem_157 = native_batch_norm_backward_default[1]
        getitem_158 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_156, getitem_150, primals_53, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_156 = getitem_150 = primals_53 = None
        getitem_159 = convolution_backward_default[0]
        getitem_160 = convolution_backward_default[1];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_159, convolution_default_50, primals_309, primals_307, primals_308, getitem_151, getitem_152, True, 1e-05, [True, True, True]);  getitem_159 = convolution_default_50 = primals_309 = primals_307 = primals_308 = getitem_151 = getitem_152 = None
        getitem_162 = native_batch_norm_backward_default_1[0]
        getitem_163 = native_batch_norm_backward_default_1[1]
        getitem_164 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_162, relu__default_33, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_162 = primals_50 = None
        getitem_165 = convolution_backward_default_1[0]
        getitem_166 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_165, torch.float32);  getitem_165 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_53, to_dtype_3);  le_scalar_1 = new_zeros_default_53 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_49, primals_304, primals_302, primals_303, getitem_148, getitem_149, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_49 = primals_304 = primals_302 = primals_303 = getitem_148 = getitem_149 = None
        getitem_168 = native_batch_norm_backward_default_2[0]
        getitem_169 = native_batch_norm_backward_default_2[1]
        getitem_170 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_168, relu__default_32, primals_48, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_168 = primals_48 = None
        getitem_171 = convolution_backward_default_2[0]
        getitem_172 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_171, torch.float32);  getitem_171 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_54, to_dtype_6);  le_scalar_2 = new_zeros_default_54 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_48, primals_299, primals_297, primals_298, getitem_145, getitem_146, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_48 = primals_299 = primals_297 = primals_298 = getitem_145 = getitem_146 = None
        getitem_174 = native_batch_norm_backward_default_3[0]
        getitem_175 = native_batch_norm_backward_default_3[1]
        getitem_176 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_174, add_tensor_57, primals_49, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_174 = add_tensor_57 = primals_49 = None
        getitem_177 = convolution_backward_default_3[0]
        getitem_178 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(getitem_177, convolution_default_47, primals_294, primals_292, primals_293, getitem_142, getitem_143, True, 1e-05, [True, True, True]);  convolution_default_47 = primals_294 = primals_292 = primals_293 = getitem_142 = getitem_143 = None
        getitem_180 = native_batch_norm_backward_default_4[0]
        getitem_181 = native_batch_norm_backward_default_4[1]
        getitem_182 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_180, relu__default_31, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_180 = primals_47 = None
        getitem_183 = convolution_backward_default_4[0]
        getitem_184 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_183, torch.float32);  getitem_183 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_55, to_dtype_9);  le_scalar_3 = new_zeros_default_55 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_46, primals_289, primals_287, primals_288, getitem_139, getitem_140, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_46 = primals_289 = primals_287 = primals_288 = getitem_139 = getitem_140 = None
        getitem_186 = native_batch_norm_backward_default_5[0]
        getitem_187 = native_batch_norm_backward_default_5[1]
        getitem_188 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_186, relu__default_30, primals_45, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_186 = primals_45 = None
        getitem_189 = convolution_backward_default_5[0]
        getitem_190 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_189, torch.float32);  getitem_189 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_56, to_dtype_12);  le_scalar_4 = new_zeros_default_56 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_45, primals_284, primals_282, primals_283, getitem_136, getitem_137, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_45 = primals_284 = primals_282 = primals_283 = getitem_136 = getitem_137 = None
        getitem_192 = native_batch_norm_backward_default_6[0]
        getitem_193 = native_batch_norm_backward_default_6[1]
        getitem_194 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_192, add_tensor_53, primals_46, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_192 = add_tensor_53 = primals_46 = None
        getitem_195 = convolution_backward_default_6[0]
        getitem_196 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_177, getitem_195);  getitem_177 = getitem_195 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_62, convolution_default_44, primals_279, primals_277, primals_278, getitem_133, getitem_134, True, 1e-05, [True, True, True]);  convolution_default_44 = primals_279 = primals_277 = primals_278 = getitem_133 = getitem_134 = None
        getitem_198 = native_batch_norm_backward_default_7[0]
        getitem_199 = native_batch_norm_backward_default_7[1]
        getitem_200 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_198, relu__default_29, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_198 = primals_44 = None
        getitem_201 = convolution_backward_default_7[0]
        getitem_202 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_201, torch.float32);  getitem_201 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_57, to_dtype_15);  le_scalar_5 = new_zeros_default_57 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_43, primals_274, primals_272, primals_273, getitem_130, getitem_131, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_43 = primals_274 = primals_272 = primals_273 = getitem_130 = getitem_131 = None
        getitem_204 = native_batch_norm_backward_default_8[0]
        getitem_205 = native_batch_norm_backward_default_8[1]
        getitem_206 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_204, relu__default_28, primals_42, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_204 = primals_42 = None
        getitem_207 = convolution_backward_default_8[0]
        getitem_208 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_207, torch.float32);  getitem_207 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_58, to_dtype_18);  le_scalar_6 = new_zeros_default_58 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_42, primals_269, primals_267, primals_268, getitem_127, getitem_128, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_42 = primals_269 = primals_267 = primals_268 = getitem_127 = getitem_128 = None
        getitem_210 = native_batch_norm_backward_default_9[0]
        getitem_211 = native_batch_norm_backward_default_9[1]
        getitem_212 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_210, add_tensor_49, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_210 = add_tensor_49 = primals_43 = None
        getitem_213 = convolution_backward_default_9[0]
        getitem_214 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(add_tensor_62, getitem_213);  add_tensor_62 = getitem_213 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_63, convolution_default_41, primals_264, primals_262, primals_263, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  convolution_default_41 = primals_264 = primals_262 = primals_263 = getitem_124 = getitem_125 = None
        getitem_216 = native_batch_norm_backward_default_10[0]
        getitem_217 = native_batch_norm_backward_default_10[1]
        getitem_218 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_216, relu__default_27, primals_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_216 = primals_41 = None
        getitem_219 = convolution_backward_default_10[0]
        getitem_220 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_219, torch.float32);  getitem_219 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_59, to_dtype_21);  le_scalar_7 = new_zeros_default_59 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_40, primals_259, primals_257, primals_258, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_40 = primals_259 = primals_257 = primals_258 = getitem_121 = getitem_122 = None
        getitem_222 = native_batch_norm_backward_default_11[0]
        getitem_223 = native_batch_norm_backward_default_11[1]
        getitem_224 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_222, relu__default_26, primals_39, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1152, [True, True, False]);  getitem_222 = primals_39 = None
        getitem_225 = convolution_backward_default_11[0]
        getitem_226 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_225, torch.float32);  getitem_225 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_60, to_dtype_24);  le_scalar_8 = new_zeros_default_60 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_39, primals_254, primals_252, primals_253, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_39 = primals_254 = primals_252 = primals_253 = getitem_118 = getitem_119 = None
        getitem_228 = native_batch_norm_backward_default_12[0]
        getitem_229 = native_batch_norm_backward_default_12[1]
        getitem_230 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_228, getitem_114, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_228 = getitem_114 = primals_40 = None
        getitem_231 = convolution_backward_default_12[0]
        getitem_232 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_63, getitem_231);  add_tensor_63 = getitem_231 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_64, convolution_default_38, primals_249, primals_247, primals_248, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  add_tensor_64 = convolution_default_38 = primals_249 = primals_247 = primals_248 = getitem_115 = getitem_116 = None
        getitem_234 = native_batch_norm_backward_default_13[0]
        getitem_235 = native_batch_norm_backward_default_13[1]
        getitem_236 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_234, relu__default_25, primals_38, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_234 = primals_38 = None
        getitem_237 = convolution_backward_default_13[0]
        getitem_238 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_237, torch.float32);  getitem_237 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_61, to_dtype_27);  le_scalar_9 = new_zeros_default_61 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_37, primals_244, primals_242, primals_243, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_37 = primals_244 = primals_242 = primals_243 = getitem_112 = getitem_113 = None
        getitem_240 = native_batch_norm_backward_default_14[0]
        getitem_241 = native_batch_norm_backward_default_14[1]
        getitem_242 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_240, relu__default_24, primals_36, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 576, [True, True, False]);  getitem_240 = primals_36 = None
        getitem_243 = convolution_backward_default_14[0]
        getitem_244 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_243, torch.float32);  getitem_243 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_62, to_dtype_30);  le_scalar_10 = new_zeros_default_62 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_36, primals_239, primals_237, primals_238, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_36 = primals_239 = primals_237 = primals_238 = getitem_109 = getitem_110 = None
        getitem_246 = native_batch_norm_backward_default_15[0]
        getitem_247 = native_batch_norm_backward_default_15[1]
        getitem_248 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_246, add_tensor_42, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_246 = add_tensor_42 = primals_37 = None
        getitem_249 = convolution_backward_default_15[0]
        getitem_250 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_249, convolution_default_35, primals_234, primals_232, primals_233, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  convolution_default_35 = primals_234 = primals_232 = primals_233 = getitem_106 = getitem_107 = None
        getitem_252 = native_batch_norm_backward_default_16[0]
        getitem_253 = native_batch_norm_backward_default_16[1]
        getitem_254 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_252, relu__default_23, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_252 = primals_35 = None
        getitem_255 = convolution_backward_default_16[0]
        getitem_256 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_255, torch.float32);  getitem_255 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_63, to_dtype_33);  le_scalar_11 = new_zeros_default_63 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_34, primals_229, primals_227, primals_228, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_34 = primals_229 = primals_227 = primals_228 = getitem_103 = getitem_104 = None
        getitem_258 = native_batch_norm_backward_default_17[0]
        getitem_259 = native_batch_norm_backward_default_17[1]
        getitem_260 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_258, relu__default_22, primals_33, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 576, [True, True, False]);  getitem_258 = primals_33 = None
        getitem_261 = convolution_backward_default_17[0]
        getitem_262 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_261, torch.float32);  getitem_261 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_64, to_dtype_36);  le_scalar_12 = new_zeros_default_64 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_33, primals_224, primals_222, primals_223, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_33 = primals_224 = primals_222 = primals_223 = getitem_100 = getitem_101 = None
        getitem_264 = native_batch_norm_backward_default_18[0]
        getitem_265 = native_batch_norm_backward_default_18[1]
        getitem_266 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_264, getitem_96, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_264 = getitem_96 = primals_34 = None
        getitem_267 = convolution_backward_default_18[0]
        getitem_268 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_249, getitem_267);  getitem_249 = getitem_267 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_65, convolution_default_32, primals_219, primals_217, primals_218, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  add_tensor_65 = convolution_default_32 = primals_219 = primals_217 = primals_218 = getitem_97 = getitem_98 = None
        getitem_270 = native_batch_norm_backward_default_19[0]
        getitem_271 = native_batch_norm_backward_default_19[1]
        getitem_272 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_270, relu__default_21, primals_32, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_270 = primals_32 = None
        getitem_273 = convolution_backward_default_19[0]
        getitem_274 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_273, torch.float32);  getitem_273 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_65, to_dtype_39);  le_scalar_13 = new_zeros_default_65 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_31, primals_214, primals_212, primals_213, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_31 = primals_214 = primals_212 = primals_213 = getitem_94 = getitem_95 = None
        getitem_276 = native_batch_norm_backward_default_20[0]
        getitem_277 = native_batch_norm_backward_default_20[1]
        getitem_278 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_276, relu__default_20, primals_30, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_276 = primals_30 = None
        getitem_279 = convolution_backward_default_20[0]
        getitem_280 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_279, torch.float32);  getitem_279 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_66, to_dtype_42);  le_scalar_14 = new_zeros_default_66 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_30, primals_209, primals_207, primals_208, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_30 = primals_209 = primals_207 = primals_208 = getitem_91 = getitem_92 = None
        getitem_282 = native_batch_norm_backward_default_21[0]
        getitem_283 = native_batch_norm_backward_default_21[1]
        getitem_284 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_282, add_tensor_35, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_282 = add_tensor_35 = primals_31 = None
        getitem_285 = convolution_backward_default_21[0]
        getitem_286 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(getitem_285, convolution_default_29, primals_204, primals_202, primals_203, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  convolution_default_29 = primals_204 = primals_202 = primals_203 = getitem_88 = getitem_89 = None
        getitem_288 = native_batch_norm_backward_default_22[0]
        getitem_289 = native_batch_norm_backward_default_22[1]
        getitem_290 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_288, relu__default_19, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_288 = primals_29 = None
        getitem_291 = convolution_backward_default_22[0]
        getitem_292 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_291, torch.float32);  getitem_291 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_67, to_dtype_45);  le_scalar_15 = new_zeros_default_67 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_28, primals_199, primals_197, primals_198, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_28 = primals_199 = primals_197 = primals_198 = getitem_85 = getitem_86 = None
        getitem_294 = native_batch_norm_backward_default_23[0]
        getitem_295 = native_batch_norm_backward_default_23[1]
        getitem_296 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_294, relu__default_18, primals_27, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_294 = primals_27 = None
        getitem_297 = convolution_backward_default_23[0]
        getitem_298 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_297, torch.float32);  getitem_297 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_68, to_dtype_48);  le_scalar_16 = new_zeros_default_68 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_27, primals_194, primals_192, primals_193, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_27 = primals_194 = primals_192 = primals_193 = getitem_82 = getitem_83 = None
        getitem_300 = native_batch_norm_backward_default_24[0]
        getitem_301 = native_batch_norm_backward_default_24[1]
        getitem_302 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_300, add_tensor_31, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_300 = add_tensor_31 = primals_28 = None
        getitem_303 = convolution_backward_default_24[0]
        getitem_304 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(getitem_285, getitem_303);  getitem_285 = getitem_303 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_66, convolution_default_26, primals_189, primals_187, primals_188, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  convolution_default_26 = primals_189 = primals_187 = primals_188 = getitem_79 = getitem_80 = None
        getitem_306 = native_batch_norm_backward_default_25[0]
        getitem_307 = native_batch_norm_backward_default_25[1]
        getitem_308 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_306, relu__default_17, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_306 = primals_26 = None
        getitem_309 = convolution_backward_default_25[0]
        getitem_310 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_309, torch.float32);  getitem_309 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_69, to_dtype_51);  le_scalar_17 = new_zeros_default_69 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_25, primals_184, primals_182, primals_183, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_25 = primals_184 = primals_182 = primals_183 = getitem_76 = getitem_77 = None
        getitem_312 = native_batch_norm_backward_default_26[0]
        getitem_313 = native_batch_norm_backward_default_26[1]
        getitem_314 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_312, relu__default_16, primals_24, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_312 = primals_24 = None
        getitem_315 = convolution_backward_default_26[0]
        getitem_316 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_315, torch.float32);  getitem_315 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_70, to_dtype_54);  le_scalar_18 = new_zeros_default_70 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_24, primals_179, primals_177, primals_178, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_24 = primals_179 = primals_177 = primals_178 = getitem_73 = getitem_74 = None
        getitem_318 = native_batch_norm_backward_default_27[0]
        getitem_319 = native_batch_norm_backward_default_27[1]
        getitem_320 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_318, getitem_69, primals_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_318 = getitem_69 = primals_25 = None
        getitem_321 = convolution_backward_default_27[0]
        getitem_322 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(add_tensor_66, getitem_321);  add_tensor_66 = getitem_321 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_67, convolution_default_23, primals_174, primals_172, primals_173, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  add_tensor_67 = convolution_default_23 = primals_174 = primals_172 = primals_173 = getitem_70 = getitem_71 = None
        getitem_324 = native_batch_norm_backward_default_28[0]
        getitem_325 = native_batch_norm_backward_default_28[1]
        getitem_326 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_324, relu__default_15, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_324 = primals_23 = None
        getitem_327 = convolution_backward_default_28[0]
        getitem_328 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_327, torch.float32);  getitem_327 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_71, to_dtype_57);  le_scalar_19 = new_zeros_default_71 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_22, primals_169, primals_167, primals_168, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_22 = primals_169 = primals_167 = primals_168 = getitem_67 = getitem_68 = None
        getitem_330 = native_batch_norm_backward_default_29[0]
        getitem_331 = native_batch_norm_backward_default_29[1]
        getitem_332 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_330, relu__default_14, primals_21, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_330 = primals_21 = None
        getitem_333 = convolution_backward_default_29[0]
        getitem_334 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_333, torch.float32);  getitem_333 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_72, to_dtype_60);  le_scalar_20 = new_zeros_default_72 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_21, primals_164, primals_162, primals_163, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_21 = primals_164 = primals_162 = primals_163 = getitem_64 = getitem_65 = None
        getitem_336 = native_batch_norm_backward_default_30[0]
        getitem_337 = native_batch_norm_backward_default_30[1]
        getitem_338 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_336, add_tensor_24, primals_22, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_336 = add_tensor_24 = primals_22 = None
        getitem_339 = convolution_backward_default_30[0]
        getitem_340 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(getitem_339, convolution_default_20, primals_159, primals_157, primals_158, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  convolution_default_20 = primals_159 = primals_157 = primals_158 = getitem_61 = getitem_62 = None
        getitem_342 = native_batch_norm_backward_default_31[0]
        getitem_343 = native_batch_norm_backward_default_31[1]
        getitem_344 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_342, relu__default_13, primals_20, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_342 = primals_20 = None
        getitem_345 = convolution_backward_default_31[0]
        getitem_346 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_345, torch.float32);  getitem_345 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_73, to_dtype_63);  le_scalar_21 = new_zeros_default_73 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_19, primals_154, primals_152, primals_153, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_19 = primals_154 = primals_152 = primals_153 = getitem_58 = getitem_59 = None
        getitem_348 = native_batch_norm_backward_default_32[0]
        getitem_349 = native_batch_norm_backward_default_32[1]
        getitem_350 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_348, relu__default_12, primals_18, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 120, [True, True, False]);  getitem_348 = primals_18 = None
        getitem_351 = convolution_backward_default_32[0]
        getitem_352 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_351, torch.float32);  getitem_351 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_74, to_dtype_66);  le_scalar_22 = new_zeros_default_74 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_18, primals_149, primals_147, primals_148, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_18 = primals_149 = primals_147 = primals_148 = getitem_55 = getitem_56 = None
        getitem_354 = native_batch_norm_backward_default_33[0]
        getitem_355 = native_batch_norm_backward_default_33[1]
        getitem_356 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_354, add_tensor_20, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_354 = add_tensor_20 = primals_19 = None
        getitem_357 = convolution_backward_default_33[0]
        getitem_358 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_339, getitem_357);  getitem_339 = getitem_357 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_68, convolution_default_17, primals_144, primals_142, primals_143, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  convolution_default_17 = primals_144 = primals_142 = primals_143 = getitem_52 = getitem_53 = None
        getitem_360 = native_batch_norm_backward_default_34[0]
        getitem_361 = native_batch_norm_backward_default_34[1]
        getitem_362 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_360, relu__default_11, primals_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_360 = primals_17 = None
        getitem_363 = convolution_backward_default_34[0]
        getitem_364 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_363, torch.float32);  getitem_363 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_75, to_dtype_69);  le_scalar_23 = new_zeros_default_75 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_16, primals_139, primals_137, primals_138, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_16 = primals_139 = primals_137 = primals_138 = getitem_49 = getitem_50 = None
        getitem_366 = native_batch_norm_backward_default_35[0]
        getitem_367 = native_batch_norm_backward_default_35[1]
        getitem_368 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_366, relu__default_10, primals_15, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 120, [True, True, False]);  getitem_366 = primals_15 = None
        getitem_369 = convolution_backward_default_35[0]
        getitem_370 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_369, torch.float32);  getitem_369 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_76, to_dtype_72);  le_scalar_24 = new_zeros_default_76 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_15, primals_134, primals_132, primals_133, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_15 = primals_134 = primals_132 = primals_133 = getitem_46 = getitem_47 = None
        getitem_372 = native_batch_norm_backward_default_36[0]
        getitem_373 = native_batch_norm_backward_default_36[1]
        getitem_374 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_372, getitem_42, primals_16, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_372 = getitem_42 = primals_16 = None
        getitem_375 = convolution_backward_default_36[0]
        getitem_376 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(add_tensor_68, getitem_375);  add_tensor_68 = getitem_375 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_69, convolution_default_14, primals_129, primals_127, primals_128, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  add_tensor_69 = convolution_default_14 = primals_129 = primals_127 = primals_128 = getitem_43 = getitem_44 = None
        getitem_378 = native_batch_norm_backward_default_37[0]
        getitem_379 = native_batch_norm_backward_default_37[1]
        getitem_380 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_378, relu__default_9, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_378 = primals_14 = None
        getitem_381 = convolution_backward_default_37[0]
        getitem_382 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_381, torch.float32);  getitem_381 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_77, to_dtype_75);  le_scalar_25 = new_zeros_default_77 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_13, primals_124, primals_122, primals_123, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_13 = primals_124 = primals_122 = primals_123 = getitem_40 = getitem_41 = None
        getitem_384 = native_batch_norm_backward_default_38[0]
        getitem_385 = native_batch_norm_backward_default_38[1]
        getitem_386 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_384, relu__default_8, primals_12, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 72, [True, True, False]);  getitem_384 = primals_12 = None
        getitem_387 = convolution_backward_default_38[0]
        getitem_388 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_387, torch.float32);  getitem_387 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_78, to_dtype_78);  le_scalar_26 = new_zeros_default_78 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_12, primals_119, primals_117, primals_118, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_12 = primals_119 = primals_117 = primals_118 = getitem_37 = getitem_38 = None
        getitem_390 = native_batch_norm_backward_default_39[0]
        getitem_391 = native_batch_norm_backward_default_39[1]
        getitem_392 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_390, add_tensor_13, primals_13, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_390 = add_tensor_13 = primals_13 = None
        getitem_393 = convolution_backward_default_39[0]
        getitem_394 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(getitem_393, convolution_default_11, primals_114, primals_112, primals_113, getitem_34, getitem_35, True, 1e-05, [True, True, True]);  convolution_default_11 = primals_114 = primals_112 = primals_113 = getitem_34 = getitem_35 = None
        getitem_396 = native_batch_norm_backward_default_40[0]
        getitem_397 = native_batch_norm_backward_default_40[1]
        getitem_398 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_396, relu__default_7, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_396 = primals_11 = None
        getitem_399 = convolution_backward_default_40[0]
        getitem_400 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_399, torch.float32);  getitem_399 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_79, to_dtype_81);  le_scalar_27 = new_zeros_default_79 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_10, primals_109, primals_107, primals_108, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_10 = primals_109 = primals_107 = primals_108 = getitem_31 = getitem_32 = None
        getitem_402 = native_batch_norm_backward_default_41[0]
        getitem_403 = native_batch_norm_backward_default_41[1]
        getitem_404 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_402, relu__default_6, primals_9, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 72, [True, True, False]);  getitem_402 = primals_9 = None
        getitem_405 = convolution_backward_default_41[0]
        getitem_406 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_405, torch.float32);  getitem_405 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_80, to_dtype_84);  le_scalar_28 = new_zeros_default_80 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_9, primals_104, primals_102, primals_103, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_9 = primals_104 = primals_102 = primals_103 = getitem_28 = getitem_29 = None
        getitem_408 = native_batch_norm_backward_default_42[0]
        getitem_409 = native_batch_norm_backward_default_42[1]
        getitem_410 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_408, add_tensor_9, primals_10, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_408 = add_tensor_9 = primals_10 = None
        getitem_411 = convolution_backward_default_42[0]
        getitem_412 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_393, getitem_411);  getitem_393 = getitem_411 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_70, convolution_default_8, primals_99, primals_97, primals_98, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  convolution_default_8 = primals_99 = primals_97 = primals_98 = getitem_25 = getitem_26 = None
        getitem_414 = native_batch_norm_backward_default_43[0]
        getitem_415 = native_batch_norm_backward_default_43[1]
        getitem_416 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_414, relu__default_5, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_414 = primals_8 = None
        getitem_417 = convolution_backward_default_43[0]
        getitem_418 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_417, torch.float32);  getitem_417 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_81, to_dtype_87);  le_scalar_29 = new_zeros_default_81 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_7, primals_94, primals_92, primals_93, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_7 = primals_94 = primals_92 = primals_93 = getitem_22 = getitem_23 = None
        getitem_420 = native_batch_norm_backward_default_44[0]
        getitem_421 = native_batch_norm_backward_default_44[1]
        getitem_422 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_420, relu__default_4, primals_6, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 72, [True, True, False]);  getitem_420 = primals_6 = None
        getitem_423 = convolution_backward_default_44[0]
        getitem_424 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_423, torch.float32);  getitem_423 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_82, to_dtype_90);  le_scalar_30 = new_zeros_default_82 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_6, primals_89, primals_87, primals_88, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_6 = primals_89 = primals_87 = primals_88 = getitem_19 = getitem_20 = None
        getitem_426 = native_batch_norm_backward_default_45[0]
        getitem_427 = native_batch_norm_backward_default_45[1]
        getitem_428 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_426, getitem_15, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_426 = getitem_15 = primals_7 = None
        getitem_429 = convolution_backward_default_45[0]
        getitem_430 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(add_tensor_70, getitem_429);  add_tensor_70 = getitem_429 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_71, convolution_default_5, primals_84, primals_82, primals_83, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  add_tensor_71 = convolution_default_5 = primals_84 = primals_82 = primals_83 = getitem_16 = getitem_17 = None
        getitem_432 = native_batch_norm_backward_default_46[0]
        getitem_433 = native_batch_norm_backward_default_46[1]
        getitem_434 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_432, relu__default_3, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_432 = primals_5 = None
        getitem_435 = convolution_backward_default_46[0]
        getitem_436 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_435, torch.float32);  getitem_435 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_83, to_dtype_93);  le_scalar_31 = new_zeros_default_83 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_4, primals_79, primals_77, primals_78, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_4 = primals_79 = primals_77 = primals_78 = getitem_13 = getitem_14 = None
        getitem_438 = native_batch_norm_backward_default_47[0]
        getitem_439 = native_batch_norm_backward_default_47[1]
        getitem_440 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_438, relu__default_2, primals_3, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 48, [True, True, False]);  getitem_438 = primals_3 = None
        getitem_441 = convolution_backward_default_47[0]
        getitem_442 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_441, torch.float32);  getitem_441 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_84, to_dtype_96);  le_scalar_32 = new_zeros_default_84 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_3, primals_74, primals_72, primals_73, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_3 = primals_74 = primals_72 = primals_73 = getitem_10 = getitem_11 = None
        getitem_444 = native_batch_norm_backward_default_48[0]
        getitem_445 = native_batch_norm_backward_default_48[1]
        getitem_446 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_444, getitem_6, primals_4, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_444 = getitem_6 = primals_4 = None
        getitem_447 = convolution_backward_default_48[0]
        getitem_448 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(getitem_447, convolution_default_2, primals_69, primals_67, primals_68, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  getitem_447 = convolution_default_2 = primals_69 = primals_67 = primals_68 = getitem_7 = getitem_8 = None
        getitem_450 = native_batch_norm_backward_default_49[0]
        getitem_451 = native_batch_norm_backward_default_49[1]
        getitem_452 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_450, relu__default_1, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_450 = primals_2 = None
        getitem_453 = convolution_backward_default_49[0]
        getitem_454 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_453, torch.float32);  getitem_453 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_85, to_dtype_99);  le_scalar_33 = new_zeros_default_85 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_1, primals_64, primals_62, primals_63, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_1 = primals_64 = primals_62 = primals_63 = getitem_4 = getitem_5 = None
        getitem_456 = native_batch_norm_backward_default_50[0]
        getitem_457 = native_batch_norm_backward_default_50[1]
        getitem_458 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_456, relu__default, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_456 = primals_1 = None
        getitem_459 = convolution_backward_default_50[0]
        getitem_460 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_459, torch.float32);  getitem_459 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_86, to_dtype_102);  le_scalar_34 = new_zeros_default_86 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default, primals_59, primals_57, primals_58, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default = primals_59 = primals_57 = primals_58 = getitem_1 = getitem_2 = None
        getitem_462 = native_batch_norm_backward_default_51[0]
        getitem_463 = native_batch_norm_backward_default_51[1]
        getitem_464 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_462, primals_55, primals_54, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_462 = primals_55 = primals_54 = None
        getitem_466 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        return [getitem_460, getitem_454, getitem_442, getitem_448, getitem_436, getitem_424, getitem_430, getitem_418, getitem_406, getitem_412, getitem_400, getitem_388, getitem_394, getitem_382, getitem_370, getitem_376, getitem_364, getitem_352, getitem_358, getitem_346, getitem_334, getitem_340, getitem_328, getitem_316, getitem_322, getitem_310, getitem_298, getitem_304, getitem_292, getitem_280, getitem_286, getitem_274, getitem_262, getitem_268, getitem_256, getitem_244, getitem_250, getitem_238, getitem_226, getitem_232, getitem_220, getitem_208, getitem_214, getitem_202, getitem_190, getitem_196, getitem_184, getitem_172, getitem_178, getitem_166, view_default_1, t_default_4, getitem_160, getitem_466, None, None, None, None, getitem_463, getitem_464, None, None, None, getitem_457, getitem_458, None, None, None, getitem_451, getitem_452, None, None, None, getitem_445, getitem_446, None, None, None, getitem_439, getitem_440, None, None, None, getitem_433, getitem_434, None, None, None, getitem_427, getitem_428, None, None, None, getitem_421, getitem_422, None, None, None, getitem_415, getitem_416, None, None, None, getitem_409, getitem_410, None, None, None, getitem_403, getitem_404, None, None, None, getitem_397, getitem_398, None, None, None, getitem_391, getitem_392, None, None, None, getitem_385, getitem_386, None, None, None, getitem_379, getitem_380, None, None, None, getitem_373, getitem_374, None, None, None, getitem_367, getitem_368, None, None, None, getitem_361, getitem_362, None, None, None, getitem_355, getitem_356, None, None, None, getitem_349, getitem_350, None, None, None, getitem_343, getitem_344, None, None, None, getitem_337, getitem_338, None, None, None, getitem_331, getitem_332, None, None, None, getitem_325, getitem_326, None, None, None, getitem_319, getitem_320, None, None, None, getitem_313, getitem_314, None, None, None, getitem_307, getitem_308, None, None, None, getitem_301, getitem_302, None, None, None, getitem_295, getitem_296, None, None, None, getitem_289, getitem_290, None, None, None, getitem_283, getitem_284, None, None, None, getitem_277, getitem_278, None, None, None, getitem_271, getitem_272, None, None, None, getitem_265, getitem_266, None, None, None, getitem_259, getitem_260, None, None, None, getitem_253, getitem_254, None, None, None, getitem_247, getitem_248, None, None, None, getitem_241, getitem_242, None, None, None, getitem_235, getitem_236, None, None, None, getitem_229, getitem_230, None, None, None, getitem_223, getitem_224, None, None, None, getitem_217, getitem_218, None, None, None, getitem_211, getitem_212, None, None, None, getitem_205, getitem_206, None, None, None, getitem_199, getitem_200, None, None, None, getitem_193, getitem_194, None, None, None, getitem_187, getitem_188, None, None, None, getitem_181, getitem_182, None, None, None, getitem_175, getitem_176, None, None, None, getitem_169, getitem_170, None, None, None, getitem_163, getitem_164, None, None, None, getitem_157, getitem_158]
        
