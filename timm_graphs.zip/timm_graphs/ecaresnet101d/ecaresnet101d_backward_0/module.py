
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/ecaresnet101d/ecaresnet101d_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_61, getitem_295, view_default_28, getitem_294, sigmoid_default_14, relu__default_94, convolution_default_128, convolution_default_66, relu__default_47, expand_default_14, primals_59, primals_58, getitem_157, getitem_156, primals_60, primals_55, relu__default_48, convolution_default_67, primals_627, primals_626, primals_632, view_default_60, primals_625, getitem_297, primals_636, getitem_298, primals_637, getitem_296, primals_633, primals_631, primals_630, primals_638, primals_641, primals_643, primals_642, primals_365, primals_262, getitem_270, primals_490, primals_492, primals_263, getitem_64, primals_491, primals_493, getitem_269, primals_270, getitem_63, relu__default_41, primals_371, primals_264, primals_484, convolution_default_58, relu__default_18, primals_355, expand_default_12, primals_357, primals_479, primals_366, primals_483, primals_360, primals_269, primals_369, primals_361, convolution_default_26, primals_261, getitem_139, getitem_141, getitem_138, primals_260, primals_370, getitem_67, getitem_271, getitem_66, primals_488, relu__default_42, primals_359, primals_485, primals_480, primals_364, relu__default_19, primals_271, convolution_default_59, primals_257, sigmoid_default_31, primals_255, convolution_default_60, primals_256, primals_478, convolution_default_27, primals_489, view_default_62, getitem_315, primals_266, primals_358, primals_356, getitem_142, getitem_69, primals_265, getitem_68, primals_181, primals_408, getitem_2, relu__default_13, relu__default_65, primals_279, primals_414, relu__default, convolution_default_18, convolution_default_1, convolution_default_90, primals_276, convolution_default_133, primals_175, primals_281, expand_default_20, getitem_301, primals_173, primals_282, primals_415, primals_416, getitem_49, getitem_48, getitem_5, getitem_47, primals_275, getitem_4, getitem_211, getitem_210, primals_407, relu__default_84, primals_170, relu__default_1, convolution_default_107, sigmoid_default_32, relu__default_66, view_default_6, primals_179, sigmoid_default_3, getitem_246, primals_178, convolution_default_2, primals_413, primals_274, convolution_default_91, relu__default_78, primals_409, primals_180, primals_174, getitem_247, getitem_7, expand_default_3, getitem_8, convolution_default_92, getitem_213, getitem_214, primals_280, convolution_default_20, relu__default_2, relu__default_67, primals_412, primals_417, avg_pool2d_default, primals_122, getitem_31, primals_124, getitem_29, getitem_30, getitem_304, relu__default_82, getitem_303, primals_123, getitem_258, view_default_2, relu__default_89, sigmoid_default_1, convolution_default_122, sigmoid_default_30, sigmoid_default_28, relu__default_96, getitem_300, view_default_56, primals_121, relu__default_8, expand_default_28, expand_default_1, convolution_default_127, convolution_default_132, relu__default_95, convolution_default_12, convolution_default_130, expand_default_30, primals_125, avg_pool2d_default_2, primals_127, convolution_default_112, getitem_33, getitem_34, relu__default_93, primals_126, convolution_default_131, getitem_259, primals_183, primals_333, primals_331, primals_182, primals_326, primals_328, primals_338, getitem_121, primals_190, getitem_120, primals_332, relu__default_36, primals_188, convolution_default_51, getitem_124, getitem_123, primals_189, primals_187, relu__default_37, primals_327, primals_193, primals_184, relu__default_99, primals_337, convolution_default_52, primals_194, primals_195, primals_336, primals_339, primals_589, convolution_default_83, getitem_193, getitem_192, relu__default_60, primals_62, primals_588, primals_586, primals_585, convolution_default_106, primals_63, getitem_196, getitem_197, primals_575, getitem_195, primals_578, primals_587, relu__default_61, primals_64, primals_573, primals_583, primals_580, sigmoid_default_24, primals_584, primals_579, convolution_default_84, primals_574, view_default_48, getitem_103, relu__default_30, getitem_102, convolution_default_43, getitem_291, getitem_106, getitem_105, relu__default_31, convolution_default_44, getitem_107, view_default_18, getitem_108, getitem_109, getitem_292, getitem_175, primals_38, relu__default_54, convolution_default_75, getitem_88, convolution_default_76, primals_39, getitem_87, getitem_86, primals_33, getitem_178, primals_35, getitem_177, view_default_14, primals_34, sigmoid_default_7, relu__default_55, relu__default_26, getitem_179, avg_pool2d_default_1, primals_37, expand_default_7, getitem_180, primals_36, getitem_181, convolution_default_37, view_default_34, view_default_44, getitem_90, primals_388, convolution_default_4, primals_555, primals_560, convolution_default_3, primals_385, primals_377, relu__default_79, primals_376, primals_559, getitem_9, getitem_10, getitem_13, getitem_12, primals_554, primals_375, primals_564, primals_565, relu__default_3, getitem_250, primals_389, primals_566, primals_384, primals_3, primals_567, getitem_309, primals_374, primals_379, primals_570, primals_569, getitem_15, primals_4, primals_568, getitem_308, getitem_16, primals_383, getitem_249, primals_380, t_default, primals_556, relu__default_4, convolution_default_5, convolution_default_108, primals_378, primals_561, expand_default_24, relu__default_14, getitem_52, getitem_51, convolution_default_21, getitem_55, getitem_54, relu__default_15, convolution_default_22, getitem_57, getitem_58, convolution_default_68, view_default_30, getitem_70, relu__default_43, getitem_313, getitem_160, getitem_159, view_default_10, sigmoid_default_5, getitem_145, relu__default_49, convolution_default_29, getitem_144, getitem_143, relu__default_20, expand_default_5, view_default_26, getitem_163, getitem_162, getitem_161, sigmoid_default_13, convolution_default_30, getitem_72, relu__default_44, getitem_73, expand_default_13, getitem_312, relu__default_21, sigmoid_default_15, convolution_default_62, expand_default_15, primals_346, primals_42, primals_352, primals_350, getitem_217, getitem_216, getitem_215, primals_347, primals_351, primals_44, primals_43, view_default_42, view_default_66, sigmoid_default_21, relu__default_68, primals_45, expand_default_21, convolution_default_94, sigmoid_default_22, primals_395, expand_default_23, primals_397, primals_403, primals_399, convolution_default_102, primals_396, primals_404, primals_394, primals_398, relu__default_74, primals_393, primals_402, primals_390, getitem_198, relu__default_9, getitem_126, getitem_199, convolution_default_13, convolution_default_14, getitem_19, getitem_125, getitem_18, primals_529, getitem_17, primals_516, view_default_38, view_default_22, getitem_37, getitem_127, sigmoid_default_19, getitem_36, view_default_64, sigmoid_default_11, primals_530, primals_526, view_default, relu__default_10, sigmoid_default, primals_532, relu__default_62, relu__default_38, expand_default_19, getitem_38, expand_default_11, primals_527, convolution_default_86, primals_523, convolution_default_54, expand_default, getitem_21, getitem_39, primals_531, convolution_default_7, primals_518, primals_522, getitem_40, primals_521, getitem_129, getitem_201, relu__default_5, primals_513, getitem_202, primals_517, getitem_22, convolution_default_87, getitem_130, relu__default_63, view_default_4, convolution_default_55, primals_528, relu__default_39, primals_672, primals_116, primals_105, primals_667, relu__default_72, getitem_261, primals_117, primals_69, primals_669, primals_106, primals_666, sigmoid_default_26, primals_118, primals_108, primals_670, primals_107, view_default_52, primals_112, primals_113, convolution_default_99, primals_668, getitem_282, primals_111, primals_671, getitem_228, getitem_260, getitem_262, getitem_229, sigmoid_default_9, convolution_default_46, view_default_58, relu__default_32, expand_default_9, getitem_112, getitem_111, primals_304, relu__default_33, primals_307, primals_309, expand_default_31, convolution_default_47, primals_308, getitem_318, primals_11, relu__default_50, getitem_91, convolution_default_70, primals_149, convolution_default_78, sigmoid_default_25, sigmoid_default_17, convolution_default_135, primals_12, primals_299, primals_10, primals_284, primals_288, convolution_default_71, convolution_default_38, primals_9, convolution_default_39, expand_default_26, relu__default_56, getitem_253, getitem_278, primals_303, getitem_166, expand_default_17, primals_5, getitem_165, primals_137, getitem_94, primals_145, expand_default_32, getitem_93, primals_146, convolution_default_114, primals_285, relu__default_51, getitem_280, primals_6, primals_290, relu__default_27, getitem_317, getitem_184, primals_144, primals_289, getitem_183, relu__default_98, primals_140, primals_142, primals_293, primals_294, relu__default_57, primals_295, getitem_168, primals_300, getitem_169, primals_298, getitem_96, convolution_default_79, primals_302, getitem_97, view_default_50, relu__default_52, getitem_251, getitem_279, primals_141, relu__default_83, relu__default_28, primals_143, getitem_319, primals_301, convolution_default_40, primals_283, convolution_default_72, getitem_186, getitem_252, primals_460, primals_213, primals_156, primals_198, primals_470, primals_50, primals_200, primals_48, primals_168, primals_469, primals_155, primals_150, primals_214, primals_461, primals_342, primals_204, primals_49, primals_165, primals_199, primals_169, primals_162, primals_203, primals_163, primals_208, primals_465, primals_161, primals_207, primals_206, primals_475, primals_160, primals_459, primals_164, primals_345, primals_154, primals_159, primals_464, primals_151, primals_472, primals_212, primals_473, primals_205, primals_474, primals_471, primals_209, primals_341, primals_340, primals_466, primals_67, convolution_default_31, getitem_237, primals_238, convolution_default_103, primals_241, getitem_76, getitem_75, primals_93, primals_237, view_default_12, primals_87, getitem_274, primals_246, primals_251, relu__default_22, relu__default_87, convolution_default_119, primals_243, primals_245, getitem_238, getitem_273, primals_247, getitem_79, primals_91, primals_242, getitem_78, primals_252, getitem_77, primals_250, primals_88, primals_244, relu__default_75, convolution_default_136, primals_92, primals_68, sigmoid_default_6, primals_86, expand_default_6, relu__default_101, getitem_148, getitem_219, getitem_147, relu__default_16, getitem_220, primals_136, convolution_default_23, relu__default_69, convolution_default_95, relu__default_45, convolution_default_123, relu__default_100, convolution_default_63, relu__default_92, getitem_61, getitem_60, getitem_59, sigmoid_default_29, expand_default_29, getitem_223, primals_135, getitem_222, getitem_151, primals_130, getitem_150, convolution_default_126, primals_132, getitem_283, view_default_8, relu__default_70, sigmoid_default_4, relu__default_46, convolution_default_96, getitem_285, convolution_default_64, getitem_224, relu__default_90, primals_131, relu__default_17, getitem_225, expand_default_4, relu__default_97, getitem_153, sigmoid_default_23, convolution_default_25, getitem_154, getitem_226, getitem_152, primals_72, primals_511, primals_602, relu__default_88, primals_507, primals_624, primals_499, primals_607, primals_102, primals_617, primals_503, primals_618, primals_606, primals_509, primals_621, primals_101, primals_494, primals_603, relu__default_76, primals_622, relu__default_81, primals_96, primals_592, getitem_243, getitem_277, convolution_default_120, primals_100, primals_612, expand_default_25, primals_611, primals_608, getitem_242, primals_498, primals_623, primals_508, primals_594, primals_604, primals_510, getitem_241, primals_593, getitem_276, primals_97, primals_605, primals_616, getitem_244, primals_512, primals_99, getitem_240, primals_597, convolution_default_110, relu__default_80, primals_502, primals_598, convolution_default_104, primals_98, primals_497, primals_504, primals_613, primals_599, sigmoid_default_2, convolution_default_111, relu__default_11, getitem_133, view_default_24, expand_default_2, getitem_132, convolution_default_16, getitem_234, relu__default_40, getitem_264, getitem_43, convolution_default_56, getitem_42, getitem_265, relu__default_12, getitem_233, getitem_136, getitem_135, getitem_134, getitem_256, convolution_default_115, convolution_default_17, convolution_default, getitem_255, getitem_45, sigmoid_default_12, getitem_46, primals_79, primals_73, getitem_205, view_default_40, getitem_204, primals_74, convolution_default_118, primals_81, relu__default_64, convolution_default_88, primals_82, relu__default_86, primals_77, getitem_208, getitem_207, getitem_206, primals_78, primals_83, sigmoid_default_20, primals_80, primals_317, primals_319, primals_313, primals_314, primals_312, relu__default_77, primals_322, primals_318, primals_323, primals_320, primals_321, getitem_268, getitem_307, convolution_default_8, convolution_default_9, primals_54, primals_53, getitem_25, getitem_24, relu__default_85, relu__default_6, sigmoid_default_27, convolution_default_116, getitem_28, getitem_27, getitem_306, relu__default_7, convolution_default_10, getitem_267, view_default_54, view_default_20, expand_default_27, getitem_114, getitem_187, getitem_115, primals_447, primals_649, relu__default_58, relu__default_34, primals_650, convolution_default_80, convolution_default_48, primals_455, primals_656, primals_456, primals_657, primals_453, getitem_190, getitem_189, getitem_188, primals_660, getitem_118, primals_437, getitem_117, primals_451, getitem_116, primals_452, primals_665, primals_647, primals_662, primals_450, view_default_36, sigmoid_default_10, primals_661, primals_652, sigmoid_default_18, primals_440, primals_646, primals_441, convolution_default_50, primals_445, primals_454, primals_446, primals_651, primals_442, convolution_default_137, relu__default_59, relu__default_35, expand_default_18, primals_648, expand_default_10, primals_655, convolution_default_82, primals_29, primals_541, primals_548, primals_535, expand_default_22, getitem_289, primals_550, getitem_286, primals_549, primals_16, primals_545, getitem_288, primals_17, primals_540, primals_547, getitem_287, view_default_46, primals_537, primals_18, primals_23, primals_30, primals_536, primals_25, convolution_default_124, primals_24, primals_546, primals_15, primals_551, getitem_235, primals_28, relu__default_91, convolution_default_98, primals_542, relu__default_71, primals_418, primals_217, primals_218, getitem_232, primals_433, primals_222, getitem_100, getitem_99, primals_219, getitem_98, getitem_231, primals_436, primals_224, primals_435, primals_223, primals_432, view_default_16, primals_427, sigmoid_default_8, primals_236, primals_422, primals_426, primals_233, primals_232, relu__default_73, relu__default_29, primals_428, expand_default_8, convolution_default_100, primals_228, primals_434, primals_421, primals_231, primals_227, convolution_default_42, primals_226, primals_431, primals_225, getitem_1, primals_423, getitem_310, getitem_172, convolution_default_33, getitem_170, relu__default_23, getitem_171, convolution_default_34, getitem_82, getitem_81, view_default_32, getitem_316, sigmoid_default_16, relu__default_24, relu__default_53, expand_default_16, getitem_84, convolution_default_74, getitem_85, relu__default_25, convolution_default_35, getitem_174, tangents_1):
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default_66);  t_default_2 = view_default_66 = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_67 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_68 = torch.ops.aten.view.default(mm_default, [128, 2048, 1, 1]);  mm_default = None
        expand_default_33 = torch.ops.aten.expand.default(view_default_68, [128, 2048, 7, 7]);  view_default_68 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default_33, 49);  expand_default_33 = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_106, to_dtype);  le_scalar = new_zeros_default_106 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_2, getitem_317);  getitem_317 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_2, expand_default_32);  expand_default_32 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_33, [2, 3], True);  mul_tensor_33 = None
        view_default_69 = torch.ops.aten.view.default(sum_dim_int_list_1, [128, 1, 2048]);  sum_dim_int_list_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_69, torch.float32);  view_default_69 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_32, torch.float32);  sigmoid_default_32 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar);  to_dtype_4 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_35);  mul_tensor_35 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_36, torch.float32);  mul_tensor_36 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_5, view_default_64, primals_671, [0], [1], [3], [1], False, [0], 1, [True, True, False]);  to_dtype_5 = view_default_64 = primals_671 = None
        getitem_320 = convolution_backward_default[0]
        getitem_321 = convolution_backward_default[1];  convolution_backward_default = None
        view_default_70 = torch.ops.aten.view.default(getitem_320, [128, 2048]);  getitem_320 = None
        unsqueeze_default = torch.ops.aten.unsqueeze.default(view_default_70, 2);  view_default_70 = None
        unsqueeze_default_1 = torch.ops.aten.unsqueeze.default(unsqueeze_default, 3);  unsqueeze_default = None
        expand_default_34 = torch.ops.aten.expand.default(unsqueeze_default_1, [128, 2048, 7, 7]);  unsqueeze_default_1 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_34, 49);  expand_default_34 = None
        add_tensor = torch.ops.aten.add.Tensor(mul_tensor_34, div_scalar_1);  mul_tensor_34 = div_scalar_1 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(add_tensor, convolution_default_137, primals_667, primals_665, primals_666, getitem_318, getitem_319, True, 1e-05, [True, True, True]);  add_tensor = convolution_default_137 = primals_667 = primals_665 = primals_666 = getitem_318 = getitem_319 = None
        getitem_323 = native_batch_norm_backward_default[0]
        getitem_324 = native_batch_norm_backward_default[1]
        getitem_325 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_323, relu__default_100, primals_670, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_323 = primals_670 = None
        getitem_326 = convolution_backward_default_1[0]
        getitem_327 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_326, torch.float32);  getitem_326 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_107, to_dtype_6);  le_scalar_1 = new_zeros_default_107 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_136, primals_662, primals_660, primals_661, getitem_315, getitem_316, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_136 = primals_662 = primals_660 = primals_661 = getitem_315 = getitem_316 = None
        getitem_329 = native_batch_norm_backward_default_1[0]
        getitem_330 = native_batch_norm_backward_default_1[1]
        getitem_331 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_329, relu__default_99, primals_669, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_329 = primals_669 = None
        getitem_332 = convolution_backward_default_2[0]
        getitem_333 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_332, torch.float32);  getitem_332 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_108, to_dtype_9);  le_scalar_2 = new_zeros_default_108 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_135, primals_657, primals_655, primals_656, getitem_312, getitem_313, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_135 = primals_657 = primals_655 = primals_656 = getitem_312 = getitem_313 = None
        getitem_335 = native_batch_norm_backward_default_2[0]
        getitem_336 = native_batch_norm_backward_default_2[1]
        getitem_337 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_335, relu__default_98, primals_668, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_335 = primals_668 = None
        getitem_338 = convolution_backward_default_3[0]
        getitem_339 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(to_dtype_2, getitem_338);  to_dtype_2 = getitem_338 = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_1, torch.float32);  add_tensor_1 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_109, to_dtype_12);  le_scalar_3 = new_zeros_default_109 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_14, getitem_308);  getitem_308 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_14, expand_default_31);  expand_default_31 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_37, [2, 3], True);  mul_tensor_37 = None
        view_default_71 = torch.ops.aten.view.default(sum_dim_int_list_2, [128, 1, 2048]);  sum_dim_int_list_2 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_71, torch.float32);  view_default_71 = None
        to_dtype_16 = torch.ops.aten.to.dtype(sigmoid_default_31, torch.float32);  sigmoid_default_31 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_16, 1)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_16, rsub_scalar_1);  to_dtype_16 = rsub_scalar_1 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_39);  mul_tensor_39 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_15, conj_physical_default_1);  to_dtype_15 = conj_physical_default_1 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_40, torch.float32);  mul_tensor_40 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(to_dtype_17, view_default_62, primals_652, [0], [1], [3], [1], False, [0], 1, [True, True, False]);  to_dtype_17 = view_default_62 = primals_652 = None
        getitem_341 = convolution_backward_default_4[0]
        getitem_342 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        view_default_72 = torch.ops.aten.view.default(getitem_341, [128, 2048]);  getitem_341 = None
        unsqueeze_default_2 = torch.ops.aten.unsqueeze.default(view_default_72, 2);  view_default_72 = None
        unsqueeze_default_3 = torch.ops.aten.unsqueeze.default(unsqueeze_default_2, 3);  unsqueeze_default_2 = None
        expand_default_35 = torch.ops.aten.expand.default(unsqueeze_default_3, [128, 2048, 7, 7]);  unsqueeze_default_3 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_35, 49);  expand_default_35 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(mul_tensor_38, div_scalar_2);  mul_tensor_38 = div_scalar_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_2, convolution_default_133, primals_648, primals_646, primals_647, getitem_309, getitem_310, True, 1e-05, [True, True, True]);  add_tensor_2 = convolution_default_133 = primals_648 = primals_646 = primals_647 = getitem_309 = getitem_310 = None
        getitem_344 = native_batch_norm_backward_default_3[0]
        getitem_345 = native_batch_norm_backward_default_3[1]
        getitem_346 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_344, relu__default_97, primals_651, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_344 = primals_651 = None
        getitem_347 = convolution_backward_default_5[0]
        getitem_348 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_347, torch.float32);  getitem_347 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_110, to_dtype_18);  le_scalar_4 = new_zeros_default_110 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_132, primals_643, primals_641, primals_642, getitem_306, getitem_307, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_132 = primals_643 = primals_641 = primals_642 = getitem_306 = getitem_307 = None
        getitem_350 = native_batch_norm_backward_default_4[0]
        getitem_351 = native_batch_norm_backward_default_4[1]
        getitem_352 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_350, relu__default_96, primals_650, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_350 = primals_650 = None
        getitem_353 = convolution_backward_default_6[0]
        getitem_354 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_353, torch.float32);  getitem_353 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_111, to_dtype_21);  le_scalar_5 = new_zeros_default_111 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_131, primals_638, primals_636, primals_637, getitem_303, getitem_304, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_131 = primals_638 = primals_636 = primals_637 = getitem_303 = getitem_304 = None
        getitem_356 = native_batch_norm_backward_default_5[0]
        getitem_357 = native_batch_norm_backward_default_5[1]
        getitem_358 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_356, relu__default_95, primals_649, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_356 = primals_649 = None
        getitem_359 = convolution_backward_default_7[0]
        getitem_360 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(to_dtype_14, getitem_359);  to_dtype_14 = getitem_359 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_3, torch.float32);  add_tensor_3 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_112, to_dtype_24);  le_scalar_6 = new_zeros_default_112 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_130, primals_632, primals_630, primals_631, getitem_300, getitem_301, True, 1e-05, [True, True, True]);  convolution_default_130 = primals_632 = primals_630 = primals_631 = getitem_300 = getitem_301 = None
        getitem_362 = native_batch_norm_backward_default_6[0]
        getitem_363 = native_batch_norm_backward_default_6[1]
        getitem_364 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_362, avg_pool2d_default_2, primals_627, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_362 = avg_pool2d_default_2 = primals_627 = None
        getitem_365 = convolution_backward_default_8[0]
        getitem_366 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_365, relu__default_92, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_365 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_26, getitem_296);  getitem_296 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_26, expand_default_30);  to_dtype_26 = expand_default_30 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_41, [2, 3], True);  mul_tensor_41 = None
        view_default_73 = torch.ops.aten.view.default(sum_dim_int_list_3, [128, 1, 2048]);  sum_dim_int_list_3 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_73, torch.float32);  view_default_73 = None
        to_dtype_28 = torch.ops.aten.to.dtype(sigmoid_default_30, torch.float32);  sigmoid_default_30 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(to_dtype_28, 1)
        mul_tensor_43 = torch.ops.aten.mul.Tensor(to_dtype_28, rsub_scalar_2);  to_dtype_28 = rsub_scalar_2 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_43);  mul_tensor_43 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_27, conj_physical_default_2);  to_dtype_27 = conj_physical_default_2 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_44, torch.float32);  mul_tensor_44 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(to_dtype_29, view_default_60, primals_633, [0], [1], [3], [1], False, [0], 1, [True, True, False]);  to_dtype_29 = view_default_60 = primals_633 = None
        getitem_368 = convolution_backward_default_9[0]
        getitem_369 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        view_default_74 = torch.ops.aten.view.default(getitem_368, [128, 2048]);  getitem_368 = None
        unsqueeze_default_4 = torch.ops.aten.unsqueeze.default(view_default_74, 2);  view_default_74 = None
        unsqueeze_default_5 = torch.ops.aten.unsqueeze.default(unsqueeze_default_4, 3);  unsqueeze_default_4 = None
        expand_default_36 = torch.ops.aten.expand.default(unsqueeze_default_5, [128, 2048, 7, 7]);  unsqueeze_default_5 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_36, 49);  expand_default_36 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(mul_tensor_42, div_scalar_3);  mul_tensor_42 = div_scalar_3 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_4, convolution_default_128, primals_623, primals_621, primals_622, getitem_297, getitem_298, True, 1e-05, [True, True, True]);  add_tensor_4 = convolution_default_128 = primals_623 = primals_621 = primals_622 = getitem_297 = getitem_298 = None
        getitem_371 = native_batch_norm_backward_default_7[0]
        getitem_372 = native_batch_norm_backward_default_7[1]
        getitem_373 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_371, relu__default_94, primals_626, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_371 = primals_626 = None
        getitem_374 = convolution_backward_default_10[0]
        getitem_375 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_374, torch.float32);  getitem_374 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_113, to_dtype_30);  le_scalar_7 = new_zeros_default_113 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_127, primals_618, primals_616, primals_617, getitem_294, getitem_295, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_127 = primals_618 = primals_616 = primals_617 = getitem_294 = getitem_295 = None
        getitem_377 = native_batch_norm_backward_default_8[0]
        getitem_378 = native_batch_norm_backward_default_8[1]
        getitem_379 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_377, relu__default_93, primals_625, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_377 = primals_625 = None
        getitem_380 = convolution_backward_default_11[0]
        getitem_381 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_380, torch.float32);  getitem_380 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_114, to_dtype_33);  le_scalar_8 = new_zeros_default_114 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_126, primals_613, primals_611, primals_612, getitem_291, getitem_292, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_126 = primals_613 = primals_611 = primals_612 = getitem_291 = getitem_292 = None
        getitem_383 = native_batch_norm_backward_default_9[0]
        getitem_384 = native_batch_norm_backward_default_9[1]
        getitem_385 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_383, relu__default_92, primals_624, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_383 = primals_624 = None
        getitem_386 = convolution_backward_default_12[0]
        getitem_387 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default, getitem_386);  avg_pool2d_backward_default = getitem_386 = None
        to_dtype_36 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_115, to_dtype_36);  le_scalar_9 = new_zeros_default_115 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_38, getitem_287);  getitem_287 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_38, expand_default_29);  expand_default_29 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_45, [2, 3], True);  mul_tensor_45 = None
        view_default_75 = torch.ops.aten.view.default(sum_dim_int_list_4, [128, 1, 1024]);  sum_dim_int_list_4 = None
        to_dtype_39 = torch.ops.aten.to.dtype(view_default_75, torch.float32);  view_default_75 = None
        to_dtype_40 = torch.ops.aten.to.dtype(sigmoid_default_29, torch.float32);  sigmoid_default_29 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(to_dtype_40, 1)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_40, rsub_scalar_3);  to_dtype_40 = rsub_scalar_3 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_47);  mul_tensor_47 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_39, conj_physical_default_3);  to_dtype_39 = conj_physical_default_3 = None
        to_dtype_41 = torch.ops.aten.to.dtype(mul_tensor_48, torch.float32);  mul_tensor_48 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_41, view_default_58, primals_456, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_41 = view_default_58 = primals_456 = None
        getitem_389 = convolution_backward_default_13[0]
        getitem_390 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        view_default_76 = torch.ops.aten.view.default(getitem_389, [128, 1024]);  getitem_389 = None
        unsqueeze_default_6 = torch.ops.aten.unsqueeze.default(view_default_76, 2);  view_default_76 = None
        unsqueeze_default_7 = torch.ops.aten.unsqueeze.default(unsqueeze_default_6, 3);  unsqueeze_default_6 = None
        expand_default_37 = torch.ops.aten.expand.default(unsqueeze_default_7, [128, 1024, 14, 14]);  unsqueeze_default_7 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_37, 196);  expand_default_37 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(mul_tensor_46, div_scalar_4);  mul_tensor_46 = div_scalar_4 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_6, convolution_default_124, primals_452, primals_450, primals_451, getitem_288, getitem_289, True, 1e-05, [True, True, True]);  add_tensor_6 = convolution_default_124 = primals_452 = primals_450 = primals_451 = getitem_288 = getitem_289 = None
        getitem_392 = native_batch_norm_backward_default_10[0]
        getitem_393 = native_batch_norm_backward_default_10[1]
        getitem_394 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_392, relu__default_91, primals_455, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_392 = primals_455 = None
        getitem_395 = convolution_backward_default_14[0]
        getitem_396 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_395, torch.float32);  getitem_395 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_116, to_dtype_42);  le_scalar_10 = new_zeros_default_116 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_123, primals_447, primals_445, primals_446, getitem_285, getitem_286, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_123 = primals_447 = primals_445 = primals_446 = getitem_285 = getitem_286 = None
        getitem_398 = native_batch_norm_backward_default_11[0]
        getitem_399 = native_batch_norm_backward_default_11[1]
        getitem_400 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_398, relu__default_90, primals_454, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_398 = primals_454 = None
        getitem_401 = convolution_backward_default_15[0]
        getitem_402 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_401, torch.float32);  getitem_401 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_117, to_dtype_45);  le_scalar_11 = new_zeros_default_117 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_122, primals_442, primals_440, primals_441, getitem_282, getitem_283, True, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_122 = primals_442 = primals_440 = primals_441 = getitem_282 = getitem_283 = None
        getitem_404 = native_batch_norm_backward_default_12[0]
        getitem_405 = native_batch_norm_backward_default_12[1]
        getitem_406 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_404, relu__default_89, primals_453, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_404 = primals_453 = None
        getitem_407 = convolution_backward_default_16[0]
        getitem_408 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(to_dtype_38, getitem_407);  to_dtype_38 = getitem_407 = None
        to_dtype_48 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_118, to_dtype_48);  le_scalar_12 = new_zeros_default_118 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_50, getitem_278);  getitem_278 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(to_dtype_50, expand_default_28);  expand_default_28 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_49, [2, 3], True);  mul_tensor_49 = None
        view_default_77 = torch.ops.aten.view.default(sum_dim_int_list_5, [128, 1, 1024]);  sum_dim_int_list_5 = None
        to_dtype_51 = torch.ops.aten.to.dtype(view_default_77, torch.float32);  view_default_77 = None
        to_dtype_52 = torch.ops.aten.to.dtype(sigmoid_default_28, torch.float32);  sigmoid_default_28 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(to_dtype_52, 1)
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_52, rsub_scalar_4);  to_dtype_52 = rsub_scalar_4 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_51);  mul_tensor_51 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_51, conj_physical_default_4);  to_dtype_51 = conj_physical_default_4 = None
        to_dtype_53 = torch.ops.aten.to.dtype(mul_tensor_52, torch.float32);  mul_tensor_52 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_53, view_default_56, primals_437, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_53 = view_default_56 = primals_437 = None
        getitem_410 = convolution_backward_default_17[0]
        getitem_411 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        view_default_78 = torch.ops.aten.view.default(getitem_410, [128, 1024]);  getitem_410 = None
        unsqueeze_default_8 = torch.ops.aten.unsqueeze.default(view_default_78, 2);  view_default_78 = None
        unsqueeze_default_9 = torch.ops.aten.unsqueeze.default(unsqueeze_default_8, 3);  unsqueeze_default_8 = None
        expand_default_38 = torch.ops.aten.expand.default(unsqueeze_default_9, [128, 1024, 14, 14]);  unsqueeze_default_9 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_38, 196);  expand_default_38 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(mul_tensor_50, div_scalar_5);  mul_tensor_50 = div_scalar_5 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_8, convolution_default_120, primals_433, primals_431, primals_432, getitem_279, getitem_280, True, 1e-05, [True, True, True]);  add_tensor_8 = convolution_default_120 = primals_433 = primals_431 = primals_432 = getitem_279 = getitem_280 = None
        getitem_413 = native_batch_norm_backward_default_13[0]
        getitem_414 = native_batch_norm_backward_default_13[1]
        getitem_415 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_413, relu__default_88, primals_436, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_413 = primals_436 = None
        getitem_416 = convolution_backward_default_18[0]
        getitem_417 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_416, torch.float32);  getitem_416 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_119, to_dtype_54);  le_scalar_13 = new_zeros_default_119 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_119, primals_428, primals_426, primals_427, getitem_276, getitem_277, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_119 = primals_428 = primals_426 = primals_427 = getitem_276 = getitem_277 = None
        getitem_419 = native_batch_norm_backward_default_14[0]
        getitem_420 = native_batch_norm_backward_default_14[1]
        getitem_421 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_419, relu__default_87, primals_435, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_419 = primals_435 = None
        getitem_422 = convolution_backward_default_19[0]
        getitem_423 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_422, torch.float32);  getitem_422 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_120, to_dtype_57);  le_scalar_14 = new_zeros_default_120 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_118, primals_423, primals_421, primals_422, getitem_273, getitem_274, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_118 = primals_423 = primals_421 = primals_422 = getitem_273 = getitem_274 = None
        getitem_425 = native_batch_norm_backward_default_15[0]
        getitem_426 = native_batch_norm_backward_default_15[1]
        getitem_427 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_425, relu__default_86, primals_434, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_425 = primals_434 = None
        getitem_428 = convolution_backward_default_20[0]
        getitem_429 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(to_dtype_50, getitem_428);  to_dtype_50 = getitem_428 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_9, torch.float32);  add_tensor_9 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_121, to_dtype_60);  le_scalar_15 = new_zeros_default_121 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_62, getitem_269);  getitem_269 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_62, expand_default_27);  expand_default_27 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_53, [2, 3], True);  mul_tensor_53 = None
        view_default_79 = torch.ops.aten.view.default(sum_dim_int_list_6, [128, 1, 1024]);  sum_dim_int_list_6 = None
        to_dtype_63 = torch.ops.aten.to.dtype(view_default_79, torch.float32);  view_default_79 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_27, torch.float32);  sigmoid_default_27 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_5);  to_dtype_64 = rsub_scalar_5 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_55);  mul_tensor_55 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_5);  to_dtype_63 = conj_physical_default_5 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_56, torch.float32);  mul_tensor_56 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(to_dtype_65, view_default_54, primals_418, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_65 = view_default_54 = primals_418 = None
        getitem_431 = convolution_backward_default_21[0]
        getitem_432 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        view_default_80 = torch.ops.aten.view.default(getitem_431, [128, 1024]);  getitem_431 = None
        unsqueeze_default_10 = torch.ops.aten.unsqueeze.default(view_default_80, 2);  view_default_80 = None
        unsqueeze_default_11 = torch.ops.aten.unsqueeze.default(unsqueeze_default_10, 3);  unsqueeze_default_10 = None
        expand_default_39 = torch.ops.aten.expand.default(unsqueeze_default_11, [128, 1024, 14, 14]);  unsqueeze_default_11 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_39, 196);  expand_default_39 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(mul_tensor_54, div_scalar_6);  mul_tensor_54 = div_scalar_6 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_10, convolution_default_116, primals_414, primals_412, primals_413, getitem_270, getitem_271, True, 1e-05, [True, True, True]);  add_tensor_10 = convolution_default_116 = primals_414 = primals_412 = primals_413 = getitem_270 = getitem_271 = None
        getitem_434 = native_batch_norm_backward_default_16[0]
        getitem_435 = native_batch_norm_backward_default_16[1]
        getitem_436 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_434, relu__default_85, primals_417, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_434 = primals_417 = None
        getitem_437 = convolution_backward_default_22[0]
        getitem_438 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_437, torch.float32);  getitem_437 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_122, to_dtype_66);  le_scalar_16 = new_zeros_default_122 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_115, primals_409, primals_407, primals_408, getitem_267, getitem_268, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_115 = primals_409 = primals_407 = primals_408 = getitem_267 = getitem_268 = None
        getitem_440 = native_batch_norm_backward_default_17[0]
        getitem_441 = native_batch_norm_backward_default_17[1]
        getitem_442 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_440, relu__default_84, primals_416, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_440 = primals_416 = None
        getitem_443 = convolution_backward_default_23[0]
        getitem_444 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_443, torch.float32);  getitem_443 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_123, to_dtype_69);  le_scalar_17 = new_zeros_default_123 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_114, primals_404, primals_402, primals_403, getitem_264, getitem_265, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_114 = primals_404 = primals_402 = primals_403 = getitem_264 = getitem_265 = None
        getitem_446 = native_batch_norm_backward_default_18[0]
        getitem_447 = native_batch_norm_backward_default_18[1]
        getitem_448 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_446, relu__default_83, primals_415, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_446 = primals_415 = None
        getitem_449 = convolution_backward_default_24[0]
        getitem_450 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(to_dtype_62, getitem_449);  to_dtype_62 = getitem_449 = None
        to_dtype_72 = torch.ops.aten.to.dtype(add_tensor_11, torch.float32);  add_tensor_11 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_124, to_dtype_72);  le_scalar_18 = new_zeros_default_124 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_74, getitem_260);  getitem_260 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_74, expand_default_26);  expand_default_26 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_57, [2, 3], True);  mul_tensor_57 = None
        view_default_81 = torch.ops.aten.view.default(sum_dim_int_list_7, [128, 1, 1024]);  sum_dim_int_list_7 = None
        to_dtype_75 = torch.ops.aten.to.dtype(view_default_81, torch.float32);  view_default_81 = None
        to_dtype_76 = torch.ops.aten.to.dtype(sigmoid_default_26, torch.float32);  sigmoid_default_26 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(to_dtype_76, 1)
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_76, rsub_scalar_6);  to_dtype_76 = rsub_scalar_6 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_59);  mul_tensor_59 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_75, conj_physical_default_6);  to_dtype_75 = conj_physical_default_6 = None
        to_dtype_77 = torch.ops.aten.to.dtype(mul_tensor_60, torch.float32);  mul_tensor_60 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(to_dtype_77, view_default_52, primals_380, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_77 = view_default_52 = primals_380 = None
        getitem_452 = convolution_backward_default_25[0]
        getitem_453 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        view_default_82 = torch.ops.aten.view.default(getitem_452, [128, 1024]);  getitem_452 = None
        unsqueeze_default_12 = torch.ops.aten.unsqueeze.default(view_default_82, 2);  view_default_82 = None
        unsqueeze_default_13 = torch.ops.aten.unsqueeze.default(unsqueeze_default_12, 3);  unsqueeze_default_12 = None
        expand_default_40 = torch.ops.aten.expand.default(unsqueeze_default_13, [128, 1024, 14, 14]);  unsqueeze_default_13 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_40, 196);  expand_default_40 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(mul_tensor_58, div_scalar_7);  mul_tensor_58 = div_scalar_7 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_12, convolution_default_112, primals_376, primals_374, primals_375, getitem_261, getitem_262, True, 1e-05, [True, True, True]);  add_tensor_12 = convolution_default_112 = primals_376 = primals_374 = primals_375 = getitem_261 = getitem_262 = None
        getitem_455 = native_batch_norm_backward_default_19[0]
        getitem_456 = native_batch_norm_backward_default_19[1]
        getitem_457 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_455, relu__default_82, primals_379, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_455 = primals_379 = None
        getitem_458 = convolution_backward_default_26[0]
        getitem_459 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_458, torch.float32);  getitem_458 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_125, to_dtype_78);  le_scalar_19 = new_zeros_default_125 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_111, primals_371, primals_369, primals_370, getitem_258, getitem_259, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_111 = primals_371 = primals_369 = primals_370 = getitem_258 = getitem_259 = None
        getitem_461 = native_batch_norm_backward_default_20[0]
        getitem_462 = native_batch_norm_backward_default_20[1]
        getitem_463 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_461, relu__default_81, primals_378, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_461 = primals_378 = None
        getitem_464 = convolution_backward_default_27[0]
        getitem_465 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_464, torch.float32);  getitem_464 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_126, to_dtype_81);  le_scalar_20 = new_zeros_default_126 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_110, primals_366, primals_364, primals_365, getitem_255, getitem_256, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_110 = primals_366 = primals_364 = primals_365 = getitem_255 = getitem_256 = None
        getitem_467 = native_batch_norm_backward_default_21[0]
        getitem_468 = native_batch_norm_backward_default_21[1]
        getitem_469 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_467, relu__default_80, primals_377, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_467 = primals_377 = None
        getitem_470 = convolution_backward_default_28[0]
        getitem_471 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(to_dtype_74, getitem_470);  to_dtype_74 = getitem_470 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_13, torch.float32);  add_tensor_13 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_127, to_dtype_84);  le_scalar_21 = new_zeros_default_127 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_86, getitem_251);  getitem_251 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_86, expand_default_25);  expand_default_25 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_61, [2, 3], True);  mul_tensor_61 = None
        view_default_83 = torch.ops.aten.view.default(sum_dim_int_list_8, [128, 1, 1024]);  sum_dim_int_list_8 = None
        to_dtype_87 = torch.ops.aten.to.dtype(view_default_83, torch.float32);  view_default_83 = None
        to_dtype_88 = torch.ops.aten.to.dtype(sigmoid_default_25, torch.float32);  sigmoid_default_25 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(to_dtype_88, 1)
        mul_tensor_63 = torch.ops.aten.mul.Tensor(to_dtype_88, rsub_scalar_7);  to_dtype_88 = rsub_scalar_7 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_63);  mul_tensor_63 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(to_dtype_87, conj_physical_default_7);  to_dtype_87 = conj_physical_default_7 = None
        to_dtype_89 = torch.ops.aten.to.dtype(mul_tensor_64, torch.float32);  mul_tensor_64 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(to_dtype_89, view_default_50, primals_361, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_89 = view_default_50 = primals_361 = None
        getitem_473 = convolution_backward_default_29[0]
        getitem_474 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        view_default_84 = torch.ops.aten.view.default(getitem_473, [128, 1024]);  getitem_473 = None
        unsqueeze_default_14 = torch.ops.aten.unsqueeze.default(view_default_84, 2);  view_default_84 = None
        unsqueeze_default_15 = torch.ops.aten.unsqueeze.default(unsqueeze_default_14, 3);  unsqueeze_default_14 = None
        expand_default_41 = torch.ops.aten.expand.default(unsqueeze_default_15, [128, 1024, 14, 14]);  unsqueeze_default_15 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_41, 196);  expand_default_41 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(mul_tensor_62, div_scalar_8);  mul_tensor_62 = div_scalar_8 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_14, convolution_default_108, primals_357, primals_355, primals_356, getitem_252, getitem_253, True, 1e-05, [True, True, True]);  add_tensor_14 = convolution_default_108 = primals_357 = primals_355 = primals_356 = getitem_252 = getitem_253 = None
        getitem_476 = native_batch_norm_backward_default_22[0]
        getitem_477 = native_batch_norm_backward_default_22[1]
        getitem_478 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_476, relu__default_79, primals_360, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_476 = primals_360 = None
        getitem_479 = convolution_backward_default_30[0]
        getitem_480 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_479, torch.float32);  getitem_479 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_128, to_dtype_90);  le_scalar_22 = new_zeros_default_128 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_107, primals_352, primals_350, primals_351, getitem_249, getitem_250, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_107 = primals_352 = primals_350 = primals_351 = getitem_249 = getitem_250 = None
        getitem_482 = native_batch_norm_backward_default_23[0]
        getitem_483 = native_batch_norm_backward_default_23[1]
        getitem_484 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_482, relu__default_78, primals_359, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_482 = primals_359 = None
        getitem_485 = convolution_backward_default_31[0]
        getitem_486 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_485, torch.float32);  getitem_485 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_129, to_dtype_93);  le_scalar_23 = new_zeros_default_129 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_106, primals_347, primals_345, primals_346, getitem_246, getitem_247, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_106 = primals_347 = primals_345 = primals_346 = getitem_246 = getitem_247 = None
        getitem_488 = native_batch_norm_backward_default_24[0]
        getitem_489 = native_batch_norm_backward_default_24[1]
        getitem_490 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_488, relu__default_77, primals_358, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_488 = primals_358 = None
        getitem_491 = convolution_backward_default_32[0]
        getitem_492 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(to_dtype_86, getitem_491);  to_dtype_86 = getitem_491 = None
        to_dtype_96 = torch.ops.aten.to.dtype(add_tensor_15, torch.float32);  add_tensor_15 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_130, to_dtype_96);  le_scalar_24 = new_zeros_default_130 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_98, getitem_242);  getitem_242 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_98, expand_default_24);  expand_default_24 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_65, [2, 3], True);  mul_tensor_65 = None
        view_default_85 = torch.ops.aten.view.default(sum_dim_int_list_9, [128, 1, 1024]);  sum_dim_int_list_9 = None
        to_dtype_99 = torch.ops.aten.to.dtype(view_default_85, torch.float32);  view_default_85 = None
        to_dtype_100 = torch.ops.aten.to.dtype(sigmoid_default_24, torch.float32);  sigmoid_default_24 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(to_dtype_100, 1)
        mul_tensor_67 = torch.ops.aten.mul.Tensor(to_dtype_100, rsub_scalar_8);  to_dtype_100 = rsub_scalar_8 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_67);  mul_tensor_67 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_99, conj_physical_default_8);  to_dtype_99 = conj_physical_default_8 = None
        to_dtype_101 = torch.ops.aten.to.dtype(mul_tensor_68, torch.float32);  mul_tensor_68 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(to_dtype_101, view_default_48, primals_342, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_101 = view_default_48 = primals_342 = None
        getitem_494 = convolution_backward_default_33[0]
        getitem_495 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        view_default_86 = torch.ops.aten.view.default(getitem_494, [128, 1024]);  getitem_494 = None
        unsqueeze_default_16 = torch.ops.aten.unsqueeze.default(view_default_86, 2);  view_default_86 = None
        unsqueeze_default_17 = torch.ops.aten.unsqueeze.default(unsqueeze_default_16, 3);  unsqueeze_default_16 = None
        expand_default_42 = torch.ops.aten.expand.default(unsqueeze_default_17, [128, 1024, 14, 14]);  unsqueeze_default_17 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_42, 196);  expand_default_42 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(mul_tensor_66, div_scalar_9);  mul_tensor_66 = div_scalar_9 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_16, convolution_default_104, primals_338, primals_336, primals_337, getitem_243, getitem_244, True, 1e-05, [True, True, True]);  add_tensor_16 = convolution_default_104 = primals_338 = primals_336 = primals_337 = getitem_243 = getitem_244 = None
        getitem_497 = native_batch_norm_backward_default_25[0]
        getitem_498 = native_batch_norm_backward_default_25[1]
        getitem_499 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_497, relu__default_76, primals_341, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_497 = primals_341 = None
        getitem_500 = convolution_backward_default_34[0]
        getitem_501 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_500, torch.float32);  getitem_500 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_131, to_dtype_102);  le_scalar_25 = new_zeros_default_131 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_103, primals_333, primals_331, primals_332, getitem_240, getitem_241, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_103 = primals_333 = primals_331 = primals_332 = getitem_240 = getitem_241 = None
        getitem_503 = native_batch_norm_backward_default_26[0]
        getitem_504 = native_batch_norm_backward_default_26[1]
        getitem_505 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_503, relu__default_75, primals_340, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_503 = primals_340 = None
        getitem_506 = convolution_backward_default_35[0]
        getitem_507 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_506, torch.float32);  getitem_506 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_132, to_dtype_105);  le_scalar_26 = new_zeros_default_132 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_102, primals_328, primals_326, primals_327, getitem_237, getitem_238, True, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_102 = primals_328 = primals_326 = primals_327 = getitem_237 = getitem_238 = None
        getitem_509 = native_batch_norm_backward_default_27[0]
        getitem_510 = native_batch_norm_backward_default_27[1]
        getitem_511 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_509, relu__default_74, primals_339, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_509 = primals_339 = None
        getitem_512 = convolution_backward_default_36[0]
        getitem_513 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(to_dtype_98, getitem_512);  to_dtype_98 = getitem_512 = None
        to_dtype_108 = torch.ops.aten.to.dtype(add_tensor_17, torch.float32);  add_tensor_17 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_133, to_dtype_108);  le_scalar_27 = new_zeros_default_133 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_110, getitem_233);  getitem_233 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_110, expand_default_23);  expand_default_23 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_69, [2, 3], True);  mul_tensor_69 = None
        view_default_87 = torch.ops.aten.view.default(sum_dim_int_list_10, [128, 1, 1024]);  sum_dim_int_list_10 = None
        to_dtype_111 = torch.ops.aten.to.dtype(view_default_87, torch.float32);  view_default_87 = None
        to_dtype_112 = torch.ops.aten.to.dtype(sigmoid_default_23, torch.float32);  sigmoid_default_23 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(to_dtype_112, 1)
        mul_tensor_71 = torch.ops.aten.mul.Tensor(to_dtype_112, rsub_scalar_9);  to_dtype_112 = rsub_scalar_9 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_71);  mul_tensor_71 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(to_dtype_111, conj_physical_default_9);  to_dtype_111 = conj_physical_default_9 = None
        to_dtype_113 = torch.ops.aten.to.dtype(mul_tensor_72, torch.float32);  mul_tensor_72 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_113, view_default_46, primals_323, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_113 = view_default_46 = primals_323 = None
        getitem_515 = convolution_backward_default_37[0]
        getitem_516 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        view_default_88 = torch.ops.aten.view.default(getitem_515, [128, 1024]);  getitem_515 = None
        unsqueeze_default_18 = torch.ops.aten.unsqueeze.default(view_default_88, 2);  view_default_88 = None
        unsqueeze_default_19 = torch.ops.aten.unsqueeze.default(unsqueeze_default_18, 3);  unsqueeze_default_18 = None
        expand_default_43 = torch.ops.aten.expand.default(unsqueeze_default_19, [128, 1024, 14, 14]);  unsqueeze_default_19 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_43, 196);  expand_default_43 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(mul_tensor_70, div_scalar_10);  mul_tensor_70 = div_scalar_10 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_18, convolution_default_100, primals_319, primals_317, primals_318, getitem_234, getitem_235, True, 1e-05, [True, True, True]);  add_tensor_18 = convolution_default_100 = primals_319 = primals_317 = primals_318 = getitem_234 = getitem_235 = None
        getitem_518 = native_batch_norm_backward_default_28[0]
        getitem_519 = native_batch_norm_backward_default_28[1]
        getitem_520 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_518, relu__default_73, primals_322, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_518 = primals_322 = None
        getitem_521 = convolution_backward_default_38[0]
        getitem_522 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_521, torch.float32);  getitem_521 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_134, to_dtype_114);  le_scalar_28 = new_zeros_default_134 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_99, primals_314, primals_312, primals_313, getitem_231, getitem_232, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_99 = primals_314 = primals_312 = primals_313 = getitem_231 = getitem_232 = None
        getitem_524 = native_batch_norm_backward_default_29[0]
        getitem_525 = native_batch_norm_backward_default_29[1]
        getitem_526 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_524, relu__default_72, primals_321, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_524 = primals_321 = None
        getitem_527 = convolution_backward_default_39[0]
        getitem_528 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_527, torch.float32);  getitem_527 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_135, to_dtype_117);  le_scalar_29 = new_zeros_default_135 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_98, primals_309, primals_307, primals_308, getitem_228, getitem_229, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_98 = primals_309 = primals_307 = primals_308 = getitem_228 = getitem_229 = None
        getitem_530 = native_batch_norm_backward_default_30[0]
        getitem_531 = native_batch_norm_backward_default_30[1]
        getitem_532 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_530, relu__default_71, primals_320, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_530 = primals_320 = None
        getitem_533 = convolution_backward_default_40[0]
        getitem_534 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(to_dtype_110, getitem_533);  to_dtype_110 = getitem_533 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_19, torch.float32);  add_tensor_19 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_136, to_dtype_120);  le_scalar_30 = new_zeros_default_136 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_122, getitem_224);  getitem_224 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_122, expand_default_22);  expand_default_22 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_73, [2, 3], True);  mul_tensor_73 = None
        view_default_89 = torch.ops.aten.view.default(sum_dim_int_list_11, [128, 1, 1024]);  sum_dim_int_list_11 = None
        to_dtype_123 = torch.ops.aten.to.dtype(view_default_89, torch.float32);  view_default_89 = None
        to_dtype_124 = torch.ops.aten.to.dtype(sigmoid_default_22, torch.float32);  sigmoid_default_22 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(to_dtype_124, 1)
        mul_tensor_75 = torch.ops.aten.mul.Tensor(to_dtype_124, rsub_scalar_10);  to_dtype_124 = rsub_scalar_10 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_75);  mul_tensor_75 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_123, conj_physical_default_10);  to_dtype_123 = conj_physical_default_10 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_76, torch.float32);  mul_tensor_76 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(to_dtype_125, view_default_44, primals_304, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_125 = view_default_44 = primals_304 = None
        getitem_536 = convolution_backward_default_41[0]
        getitem_537 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        view_default_90 = torch.ops.aten.view.default(getitem_536, [128, 1024]);  getitem_536 = None
        unsqueeze_default_20 = torch.ops.aten.unsqueeze.default(view_default_90, 2);  view_default_90 = None
        unsqueeze_default_21 = torch.ops.aten.unsqueeze.default(unsqueeze_default_20, 3);  unsqueeze_default_20 = None
        expand_default_44 = torch.ops.aten.expand.default(unsqueeze_default_21, [128, 1024, 14, 14]);  unsqueeze_default_21 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_44, 196);  expand_default_44 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(mul_tensor_74, div_scalar_11);  mul_tensor_74 = div_scalar_11 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_20, convolution_default_96, primals_300, primals_298, primals_299, getitem_225, getitem_226, True, 1e-05, [True, True, True]);  add_tensor_20 = convolution_default_96 = primals_300 = primals_298 = primals_299 = getitem_225 = getitem_226 = None
        getitem_539 = native_batch_norm_backward_default_31[0]
        getitem_540 = native_batch_norm_backward_default_31[1]
        getitem_541 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_539, relu__default_70, primals_303, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_539 = primals_303 = None
        getitem_542 = convolution_backward_default_42[0]
        getitem_543 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_542, torch.float32);  getitem_542 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_137, to_dtype_126);  le_scalar_31 = new_zeros_default_137 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_95, primals_295, primals_293, primals_294, getitem_222, getitem_223, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default_95 = primals_295 = primals_293 = primals_294 = getitem_222 = getitem_223 = None
        getitem_545 = native_batch_norm_backward_default_32[0]
        getitem_546 = native_batch_norm_backward_default_32[1]
        getitem_547 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_545, relu__default_69, primals_302, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_545 = primals_302 = None
        getitem_548 = convolution_backward_default_43[0]
        getitem_549 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_548, torch.float32);  getitem_548 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_138, to_dtype_129);  le_scalar_32 = new_zeros_default_138 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_94, primals_290, primals_288, primals_289, getitem_219, getitem_220, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_94 = primals_290 = primals_288 = primals_289 = getitem_219 = getitem_220 = None
        getitem_551 = native_batch_norm_backward_default_33[0]
        getitem_552 = native_batch_norm_backward_default_33[1]
        getitem_553 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_551, relu__default_68, primals_301, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_551 = primals_301 = None
        getitem_554 = convolution_backward_default_44[0]
        getitem_555 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(to_dtype_122, getitem_554);  to_dtype_122 = getitem_554 = None
        to_dtype_132 = torch.ops.aten.to.dtype(add_tensor_21, torch.float32);  add_tensor_21 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_139, to_dtype_132);  le_scalar_33 = new_zeros_default_139 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_134, getitem_215);  getitem_215 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(to_dtype_134, expand_default_21);  expand_default_21 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_77, [2, 3], True);  mul_tensor_77 = None
        view_default_91 = torch.ops.aten.view.default(sum_dim_int_list_12, [128, 1, 1024]);  sum_dim_int_list_12 = None
        to_dtype_135 = torch.ops.aten.to.dtype(view_default_91, torch.float32);  view_default_91 = None
        to_dtype_136 = torch.ops.aten.to.dtype(sigmoid_default_21, torch.float32);  sigmoid_default_21 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(to_dtype_136, 1)
        mul_tensor_79 = torch.ops.aten.mul.Tensor(to_dtype_136, rsub_scalar_11);  to_dtype_136 = rsub_scalar_11 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_79);  mul_tensor_79 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(to_dtype_135, conj_physical_default_11);  to_dtype_135 = conj_physical_default_11 = None
        to_dtype_137 = torch.ops.aten.to.dtype(mul_tensor_80, torch.float32);  mul_tensor_80 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(to_dtype_137, view_default_42, primals_285, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_137 = view_default_42 = primals_285 = None
        getitem_557 = convolution_backward_default_45[0]
        getitem_558 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        view_default_92 = torch.ops.aten.view.default(getitem_557, [128, 1024]);  getitem_557 = None
        unsqueeze_default_22 = torch.ops.aten.unsqueeze.default(view_default_92, 2);  view_default_92 = None
        unsqueeze_default_23 = torch.ops.aten.unsqueeze.default(unsqueeze_default_22, 3);  unsqueeze_default_22 = None
        expand_default_45 = torch.ops.aten.expand.default(unsqueeze_default_23, [128, 1024, 14, 14]);  unsqueeze_default_23 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_45, 196);  expand_default_45 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(mul_tensor_78, div_scalar_12);  mul_tensor_78 = div_scalar_12 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_22, convolution_default_92, primals_281, primals_279, primals_280, getitem_216, getitem_217, True, 1e-05, [True, True, True]);  add_tensor_22 = convolution_default_92 = primals_281 = primals_279 = primals_280 = getitem_216 = getitem_217 = None
        getitem_560 = native_batch_norm_backward_default_34[0]
        getitem_561 = native_batch_norm_backward_default_34[1]
        getitem_562 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_560, relu__default_67, primals_284, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_560 = primals_284 = None
        getitem_563 = convolution_backward_default_46[0]
        getitem_564 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_563, torch.float32);  getitem_563 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_140, to_dtype_138);  le_scalar_34 = new_zeros_default_140 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_91, primals_276, primals_274, primals_275, getitem_213, getitem_214, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_91 = primals_276 = primals_274 = primals_275 = getitem_213 = getitem_214 = None
        getitem_566 = native_batch_norm_backward_default_35[0]
        getitem_567 = native_batch_norm_backward_default_35[1]
        getitem_568 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_566, relu__default_66, primals_283, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_566 = primals_283 = None
        getitem_569 = convolution_backward_default_47[0]
        getitem_570 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_569, torch.float32);  getitem_569 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_141, to_dtype_141);  le_scalar_35 = new_zeros_default_141 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_90, primals_271, primals_269, primals_270, getitem_210, getitem_211, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_90 = primals_271 = primals_269 = primals_270 = getitem_210 = getitem_211 = None
        getitem_572 = native_batch_norm_backward_default_36[0]
        getitem_573 = native_batch_norm_backward_default_36[1]
        getitem_574 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_572, relu__default_65, primals_282, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_572 = primals_282 = None
        getitem_575 = convolution_backward_default_48[0]
        getitem_576 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(to_dtype_134, getitem_575);  to_dtype_134 = getitem_575 = None
        to_dtype_144 = torch.ops.aten.to.dtype(add_tensor_23, torch.float32);  add_tensor_23 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_142, to_dtype_144);  le_scalar_36 = new_zeros_default_142 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_146, getitem_206);  getitem_206 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_146, expand_default_20);  expand_default_20 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_81, [2, 3], True);  mul_tensor_81 = None
        view_default_93 = torch.ops.aten.view.default(sum_dim_int_list_13, [128, 1, 1024]);  sum_dim_int_list_13 = None
        to_dtype_147 = torch.ops.aten.to.dtype(view_default_93, torch.float32);  view_default_93 = None
        to_dtype_148 = torch.ops.aten.to.dtype(sigmoid_default_20, torch.float32);  sigmoid_default_20 = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(to_dtype_148, 1)
        mul_tensor_83 = torch.ops.aten.mul.Tensor(to_dtype_148, rsub_scalar_12);  to_dtype_148 = rsub_scalar_12 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_83);  mul_tensor_83 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_147, conj_physical_default_12);  to_dtype_147 = conj_physical_default_12 = None
        to_dtype_149 = torch.ops.aten.to.dtype(mul_tensor_84, torch.float32);  mul_tensor_84 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(to_dtype_149, view_default_40, primals_266, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_149 = view_default_40 = primals_266 = None
        getitem_578 = convolution_backward_default_49[0]
        getitem_579 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        view_default_94 = torch.ops.aten.view.default(getitem_578, [128, 1024]);  getitem_578 = None
        unsqueeze_default_24 = torch.ops.aten.unsqueeze.default(view_default_94, 2);  view_default_94 = None
        unsqueeze_default_25 = torch.ops.aten.unsqueeze.default(unsqueeze_default_24, 3);  unsqueeze_default_24 = None
        expand_default_46 = torch.ops.aten.expand.default(unsqueeze_default_25, [128, 1024, 14, 14]);  unsqueeze_default_25 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_46, 196);  expand_default_46 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(mul_tensor_82, div_scalar_13);  mul_tensor_82 = div_scalar_13 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_24, convolution_default_88, primals_262, primals_260, primals_261, getitem_207, getitem_208, True, 1e-05, [True, True, True]);  add_tensor_24 = convolution_default_88 = primals_262 = primals_260 = primals_261 = getitem_207 = getitem_208 = None
        getitem_581 = native_batch_norm_backward_default_37[0]
        getitem_582 = native_batch_norm_backward_default_37[1]
        getitem_583 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_581, relu__default_64, primals_265, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_581 = primals_265 = None
        getitem_584 = convolution_backward_default_50[0]
        getitem_585 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_584, torch.float32);  getitem_584 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_143, to_dtype_150);  le_scalar_37 = new_zeros_default_143 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_87, primals_257, primals_255, primals_256, getitem_204, getitem_205, True, 1e-05, [True, True, True]);  to_dtype_152 = convolution_default_87 = primals_257 = primals_255 = primals_256 = getitem_204 = getitem_205 = None
        getitem_587 = native_batch_norm_backward_default_38[0]
        getitem_588 = native_batch_norm_backward_default_38[1]
        getitem_589 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_587, relu__default_63, primals_264, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_587 = primals_264 = None
        getitem_590 = convolution_backward_default_51[0]
        getitem_591 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_590, torch.float32);  getitem_590 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_144, to_dtype_153);  le_scalar_38 = new_zeros_default_144 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_86, primals_252, primals_250, primals_251, getitem_201, getitem_202, True, 1e-05, [True, True, True]);  to_dtype_155 = convolution_default_86 = primals_252 = primals_250 = primals_251 = getitem_201 = getitem_202 = None
        getitem_593 = native_batch_norm_backward_default_39[0]
        getitem_594 = native_batch_norm_backward_default_39[1]
        getitem_595 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_593, relu__default_62, primals_263, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_593 = primals_263 = None
        getitem_596 = convolution_backward_default_52[0]
        getitem_597 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(to_dtype_146, getitem_596);  to_dtype_146 = getitem_596 = None
        to_dtype_156 = torch.ops.aten.to.dtype(add_tensor_25, torch.float32);  add_tensor_25 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_145, to_dtype_156);  le_scalar_39 = new_zeros_default_145 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(to_dtype_158, getitem_197);  getitem_197 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_158, expand_default_19);  expand_default_19 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(mul_tensor_85, [2, 3], True);  mul_tensor_85 = None
        view_default_95 = torch.ops.aten.view.default(sum_dim_int_list_14, [128, 1, 1024]);  sum_dim_int_list_14 = None
        to_dtype_159 = torch.ops.aten.to.dtype(view_default_95, torch.float32);  view_default_95 = None
        to_dtype_160 = torch.ops.aten.to.dtype(sigmoid_default_19, torch.float32);  sigmoid_default_19 = None
        rsub_scalar_13 = torch.ops.aten.rsub.Scalar(to_dtype_160, 1)
        mul_tensor_87 = torch.ops.aten.mul.Tensor(to_dtype_160, rsub_scalar_13);  to_dtype_160 = rsub_scalar_13 = None
        conj_physical_default_13 = torch.ops.aten.conj_physical.default(mul_tensor_87);  mul_tensor_87 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(to_dtype_159, conj_physical_default_13);  to_dtype_159 = conj_physical_default_13 = None
        to_dtype_161 = torch.ops.aten.to.dtype(mul_tensor_88, torch.float32);  mul_tensor_88 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(to_dtype_161, view_default_38, primals_247, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_161 = view_default_38 = primals_247 = None
        getitem_599 = convolution_backward_default_53[0]
        getitem_600 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        view_default_96 = torch.ops.aten.view.default(getitem_599, [128, 1024]);  getitem_599 = None
        unsqueeze_default_26 = torch.ops.aten.unsqueeze.default(view_default_96, 2);  view_default_96 = None
        unsqueeze_default_27 = torch.ops.aten.unsqueeze.default(unsqueeze_default_26, 3);  unsqueeze_default_26 = None
        expand_default_47 = torch.ops.aten.expand.default(unsqueeze_default_27, [128, 1024, 14, 14]);  unsqueeze_default_27 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_47, 196);  expand_default_47 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_86, div_scalar_14);  mul_tensor_86 = div_scalar_14 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_26, convolution_default_84, primals_243, primals_241, primals_242, getitem_198, getitem_199, True, 1e-05, [True, True, True]);  add_tensor_26 = convolution_default_84 = primals_243 = primals_241 = primals_242 = getitem_198 = getitem_199 = None
        getitem_602 = native_batch_norm_backward_default_40[0]
        getitem_603 = native_batch_norm_backward_default_40[1]
        getitem_604 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_602, relu__default_61, primals_246, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_602 = primals_246 = None
        getitem_605 = convolution_backward_default_54[0]
        getitem_606 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_605, torch.float32);  getitem_605 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_146, to_dtype_162);  le_scalar_40 = new_zeros_default_146 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_83, primals_238, primals_236, primals_237, getitem_195, getitem_196, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_83 = primals_238 = primals_236 = primals_237 = getitem_195 = getitem_196 = None
        getitem_608 = native_batch_norm_backward_default_41[0]
        getitem_609 = native_batch_norm_backward_default_41[1]
        getitem_610 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_608, relu__default_60, primals_245, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_608 = primals_245 = None
        getitem_611 = convolution_backward_default_55[0]
        getitem_612 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_611, torch.float32);  getitem_611 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_147, to_dtype_165);  le_scalar_41 = new_zeros_default_147 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_82, primals_233, primals_231, primals_232, getitem_192, getitem_193, True, 1e-05, [True, True, True]);  to_dtype_167 = convolution_default_82 = primals_233 = primals_231 = primals_232 = getitem_192 = getitem_193 = None
        getitem_614 = native_batch_norm_backward_default_42[0]
        getitem_615 = native_batch_norm_backward_default_42[1]
        getitem_616 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_614, relu__default_59, primals_244, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_614 = primals_244 = None
        getitem_617 = convolution_backward_default_56[0]
        getitem_618 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(to_dtype_158, getitem_617);  to_dtype_158 = getitem_617 = None
        to_dtype_168 = torch.ops.aten.to.dtype(add_tensor_27, torch.float32);  add_tensor_27 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_148, to_dtype_168);  le_scalar_42 = new_zeros_default_148 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_170, getitem_188);  getitem_188 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_170, expand_default_18);  expand_default_18 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_89, [2, 3], True);  mul_tensor_89 = None
        view_default_97 = torch.ops.aten.view.default(sum_dim_int_list_15, [128, 1, 1024]);  sum_dim_int_list_15 = None
        to_dtype_171 = torch.ops.aten.to.dtype(view_default_97, torch.float32);  view_default_97 = None
        to_dtype_172 = torch.ops.aten.to.dtype(sigmoid_default_18, torch.float32);  sigmoid_default_18 = None
        rsub_scalar_14 = torch.ops.aten.rsub.Scalar(to_dtype_172, 1)
        mul_tensor_91 = torch.ops.aten.mul.Tensor(to_dtype_172, rsub_scalar_14);  to_dtype_172 = rsub_scalar_14 = None
        conj_physical_default_14 = torch.ops.aten.conj_physical.default(mul_tensor_91);  mul_tensor_91 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(to_dtype_171, conj_physical_default_14);  to_dtype_171 = conj_physical_default_14 = None
        to_dtype_173 = torch.ops.aten.to.dtype(mul_tensor_92, torch.float32);  mul_tensor_92 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(to_dtype_173, view_default_36, primals_228, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_173 = view_default_36 = primals_228 = None
        getitem_620 = convolution_backward_default_57[0]
        getitem_621 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        view_default_98 = torch.ops.aten.view.default(getitem_620, [128, 1024]);  getitem_620 = None
        unsqueeze_default_28 = torch.ops.aten.unsqueeze.default(view_default_98, 2);  view_default_98 = None
        unsqueeze_default_29 = torch.ops.aten.unsqueeze.default(unsqueeze_default_28, 3);  unsqueeze_default_28 = None
        expand_default_48 = torch.ops.aten.expand.default(unsqueeze_default_29, [128, 1024, 14, 14]);  unsqueeze_default_29 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_48, 196);  expand_default_48 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(mul_tensor_90, div_scalar_15);  mul_tensor_90 = div_scalar_15 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_28, convolution_default_80, primals_224, primals_222, primals_223, getitem_189, getitem_190, True, 1e-05, [True, True, True]);  add_tensor_28 = convolution_default_80 = primals_224 = primals_222 = primals_223 = getitem_189 = getitem_190 = None
        getitem_623 = native_batch_norm_backward_default_43[0]
        getitem_624 = native_batch_norm_backward_default_43[1]
        getitem_625 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_623, relu__default_58, primals_227, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_623 = primals_227 = None
        getitem_626 = convolution_backward_default_58[0]
        getitem_627 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_626, torch.float32);  getitem_626 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_149, to_dtype_174);  le_scalar_43 = new_zeros_default_149 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_79, primals_219, primals_217, primals_218, getitem_186, getitem_187, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_79 = primals_219 = primals_217 = primals_218 = getitem_186 = getitem_187 = None
        getitem_629 = native_batch_norm_backward_default_44[0]
        getitem_630 = native_batch_norm_backward_default_44[1]
        getitem_631 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_629, relu__default_57, primals_226, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_629 = primals_226 = None
        getitem_632 = convolution_backward_default_59[0]
        getitem_633 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_632, torch.float32);  getitem_632 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_150, to_dtype_177);  le_scalar_44 = new_zeros_default_150 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_78, primals_214, primals_212, primals_213, getitem_183, getitem_184, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_78 = primals_214 = primals_212 = primals_213 = getitem_183 = getitem_184 = None
        getitem_635 = native_batch_norm_backward_default_45[0]
        getitem_636 = native_batch_norm_backward_default_45[1]
        getitem_637 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_635, relu__default_56, primals_225, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_635 = primals_225 = None
        getitem_638 = convolution_backward_default_60[0]
        getitem_639 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(to_dtype_170, getitem_638);  to_dtype_170 = getitem_638 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_29, torch.float32);  add_tensor_29 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_151, to_dtype_180);  le_scalar_45 = new_zeros_default_151 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_182, getitem_179);  getitem_179 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_182, expand_default_17);  expand_default_17 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(mul_tensor_93, [2, 3], True);  mul_tensor_93 = None
        view_default_99 = torch.ops.aten.view.default(sum_dim_int_list_16, [128, 1, 1024]);  sum_dim_int_list_16 = None
        to_dtype_183 = torch.ops.aten.to.dtype(view_default_99, torch.float32);  view_default_99 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default_17, torch.float32);  sigmoid_default_17 = None
        rsub_scalar_15 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_95 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_15);  to_dtype_184 = rsub_scalar_15 = None
        conj_physical_default_15 = torch.ops.aten.conj_physical.default(mul_tensor_95);  mul_tensor_95 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_15);  to_dtype_183 = conj_physical_default_15 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_96, torch.float32);  mul_tensor_96 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(to_dtype_185, view_default_34, primals_209, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_185 = view_default_34 = primals_209 = None
        getitem_641 = convolution_backward_default_61[0]
        getitem_642 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        view_default_100 = torch.ops.aten.view.default(getitem_641, [128, 1024]);  getitem_641 = None
        unsqueeze_default_30 = torch.ops.aten.unsqueeze.default(view_default_100, 2);  view_default_100 = None
        unsqueeze_default_31 = torch.ops.aten.unsqueeze.default(unsqueeze_default_30, 3);  unsqueeze_default_30 = None
        expand_default_49 = torch.ops.aten.expand.default(unsqueeze_default_31, [128, 1024, 14, 14]);  unsqueeze_default_31 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_49, 196);  expand_default_49 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_94, div_scalar_16);  mul_tensor_94 = div_scalar_16 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_30, convolution_default_76, primals_205, primals_203, primals_204, getitem_180, getitem_181, True, 1e-05, [True, True, True]);  add_tensor_30 = convolution_default_76 = primals_205 = primals_203 = primals_204 = getitem_180 = getitem_181 = None
        getitem_644 = native_batch_norm_backward_default_46[0]
        getitem_645 = native_batch_norm_backward_default_46[1]
        getitem_646 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_644, relu__default_55, primals_208, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_644 = primals_208 = None
        getitem_647 = convolution_backward_default_62[0]
        getitem_648 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_647, torch.float32);  getitem_647 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_152, to_dtype_186);  le_scalar_46 = new_zeros_default_152 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_75, primals_200, primals_198, primals_199, getitem_177, getitem_178, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_75 = primals_200 = primals_198 = primals_199 = getitem_177 = getitem_178 = None
        getitem_650 = native_batch_norm_backward_default_47[0]
        getitem_651 = native_batch_norm_backward_default_47[1]
        getitem_652 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_650, relu__default_54, primals_207, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_650 = primals_207 = None
        getitem_653 = convolution_backward_default_63[0]
        getitem_654 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_653, torch.float32);  getitem_653 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_153, to_dtype_189);  le_scalar_47 = new_zeros_default_153 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_74, primals_195, primals_193, primals_194, getitem_174, getitem_175, True, 1e-05, [True, True, True]);  to_dtype_191 = convolution_default_74 = primals_195 = primals_193 = primals_194 = getitem_174 = getitem_175 = None
        getitem_656 = native_batch_norm_backward_default_48[0]
        getitem_657 = native_batch_norm_backward_default_48[1]
        getitem_658 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_656, relu__default_53, primals_206, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_656 = primals_206 = None
        getitem_659 = convolution_backward_default_64[0]
        getitem_660 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(to_dtype_182, getitem_659);  to_dtype_182 = getitem_659 = None
        to_dtype_192 = torch.ops.aten.to.dtype(add_tensor_31, torch.float32);  add_tensor_31 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_154, to_dtype_192);  le_scalar_48 = new_zeros_default_154 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_194, getitem_170);  getitem_170 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_194, expand_default_16);  expand_default_16 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_97, [2, 3], True);  mul_tensor_97 = None
        view_default_101 = torch.ops.aten.view.default(sum_dim_int_list_17, [128, 1, 1024]);  sum_dim_int_list_17 = None
        to_dtype_195 = torch.ops.aten.to.dtype(view_default_101, torch.float32);  view_default_101 = None
        to_dtype_196 = torch.ops.aten.to.dtype(sigmoid_default_16, torch.float32);  sigmoid_default_16 = None
        rsub_scalar_16 = torch.ops.aten.rsub.Scalar(to_dtype_196, 1)
        mul_tensor_99 = torch.ops.aten.mul.Tensor(to_dtype_196, rsub_scalar_16);  to_dtype_196 = rsub_scalar_16 = None
        conj_physical_default_16 = torch.ops.aten.conj_physical.default(mul_tensor_99);  mul_tensor_99 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(to_dtype_195, conj_physical_default_16);  to_dtype_195 = conj_physical_default_16 = None
        to_dtype_197 = torch.ops.aten.to.dtype(mul_tensor_100, torch.float32);  mul_tensor_100 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(to_dtype_197, view_default_32, primals_608, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_197 = view_default_32 = primals_608 = None
        getitem_662 = convolution_backward_default_65[0]
        getitem_663 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        view_default_102 = torch.ops.aten.view.default(getitem_662, [128, 1024]);  getitem_662 = None
        unsqueeze_default_32 = torch.ops.aten.unsqueeze.default(view_default_102, 2);  view_default_102 = None
        unsqueeze_default_33 = torch.ops.aten.unsqueeze.default(unsqueeze_default_32, 3);  unsqueeze_default_32 = None
        expand_default_50 = torch.ops.aten.expand.default(unsqueeze_default_33, [128, 1024, 14, 14]);  unsqueeze_default_33 = None
        div_scalar_17 = torch.ops.aten.div.Scalar(expand_default_50, 196);  expand_default_50 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(mul_tensor_98, div_scalar_17);  mul_tensor_98 = div_scalar_17 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_32, convolution_default_72, primals_604, primals_602, primals_603, getitem_171, getitem_172, True, 1e-05, [True, True, True]);  add_tensor_32 = convolution_default_72 = primals_604 = primals_602 = primals_603 = getitem_171 = getitem_172 = None
        getitem_665 = native_batch_norm_backward_default_49[0]
        getitem_666 = native_batch_norm_backward_default_49[1]
        getitem_667 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_665, relu__default_52, primals_607, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_665 = primals_607 = None
        getitem_668 = convolution_backward_default_66[0]
        getitem_669 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_668, torch.float32);  getitem_668 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_155, to_dtype_198);  le_scalar_49 = new_zeros_default_155 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_71, primals_599, primals_597, primals_598, getitem_168, getitem_169, True, 1e-05, [True, True, True]);  to_dtype_200 = convolution_default_71 = primals_599 = primals_597 = primals_598 = getitem_168 = getitem_169 = None
        getitem_671 = native_batch_norm_backward_default_50[0]
        getitem_672 = native_batch_norm_backward_default_50[1]
        getitem_673 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_671, relu__default_51, primals_606, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_671 = primals_606 = None
        getitem_674 = convolution_backward_default_67[0]
        getitem_675 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_674, torch.float32);  getitem_674 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_156, to_dtype_201);  le_scalar_50 = new_zeros_default_156 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_70, primals_594, primals_592, primals_593, getitem_165, getitem_166, True, 1e-05, [True, True, True]);  to_dtype_203 = convolution_default_70 = primals_594 = primals_592 = primals_593 = getitem_165 = getitem_166 = None
        getitem_677 = native_batch_norm_backward_default_51[0]
        getitem_678 = native_batch_norm_backward_default_51[1]
        getitem_679 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_677, relu__default_50, primals_605, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_677 = primals_605 = None
        getitem_680 = convolution_backward_default_68[0]
        getitem_681 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(to_dtype_194, getitem_680);  to_dtype_194 = getitem_680 = None
        to_dtype_204 = torch.ops.aten.to.dtype(add_tensor_33, torch.float32);  add_tensor_33 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_157, to_dtype_204);  le_scalar_51 = new_zeros_default_157 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_206, getitem_161);  getitem_161 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_206, expand_default_15);  expand_default_15 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(mul_tensor_101, [2, 3], True);  mul_tensor_101 = None
        view_default_103 = torch.ops.aten.view.default(sum_dim_int_list_18, [128, 1, 1024]);  sum_dim_int_list_18 = None
        to_dtype_207 = torch.ops.aten.to.dtype(view_default_103, torch.float32);  view_default_103 = None
        to_dtype_208 = torch.ops.aten.to.dtype(sigmoid_default_15, torch.float32);  sigmoid_default_15 = None
        rsub_scalar_17 = torch.ops.aten.rsub.Scalar(to_dtype_208, 1)
        mul_tensor_103 = torch.ops.aten.mul.Tensor(to_dtype_208, rsub_scalar_17);  to_dtype_208 = rsub_scalar_17 = None
        conj_physical_default_17 = torch.ops.aten.conj_physical.default(mul_tensor_103);  mul_tensor_103 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(to_dtype_207, conj_physical_default_17);  to_dtype_207 = conj_physical_default_17 = None
        to_dtype_209 = torch.ops.aten.to.dtype(mul_tensor_104, torch.float32);  mul_tensor_104 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(to_dtype_209, view_default_30, primals_589, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_209 = view_default_30 = primals_589 = None
        getitem_683 = convolution_backward_default_69[0]
        getitem_684 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        view_default_104 = torch.ops.aten.view.default(getitem_683, [128, 1024]);  getitem_683 = None
        unsqueeze_default_34 = torch.ops.aten.unsqueeze.default(view_default_104, 2);  view_default_104 = None
        unsqueeze_default_35 = torch.ops.aten.unsqueeze.default(unsqueeze_default_34, 3);  unsqueeze_default_34 = None
        expand_default_51 = torch.ops.aten.expand.default(unsqueeze_default_35, [128, 1024, 14, 14]);  unsqueeze_default_35 = None
        div_scalar_18 = torch.ops.aten.div.Scalar(expand_default_51, 196);  expand_default_51 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(mul_tensor_102, div_scalar_18);  mul_tensor_102 = div_scalar_18 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_34, convolution_default_68, primals_585, primals_583, primals_584, getitem_162, getitem_163, True, 1e-05, [True, True, True]);  add_tensor_34 = convolution_default_68 = primals_585 = primals_583 = primals_584 = getitem_162 = getitem_163 = None
        getitem_686 = native_batch_norm_backward_default_52[0]
        getitem_687 = native_batch_norm_backward_default_52[1]
        getitem_688 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_686, relu__default_49, primals_588, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_686 = primals_588 = None
        getitem_689 = convolution_backward_default_70[0]
        getitem_690 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_689, torch.float32);  getitem_689 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_158, to_dtype_210);  le_scalar_52 = new_zeros_default_158 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_67, primals_580, primals_578, primals_579, getitem_159, getitem_160, True, 1e-05, [True, True, True]);  to_dtype_212 = convolution_default_67 = primals_580 = primals_578 = primals_579 = getitem_159 = getitem_160 = None
        getitem_692 = native_batch_norm_backward_default_53[0]
        getitem_693 = native_batch_norm_backward_default_53[1]
        getitem_694 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_692, relu__default_48, primals_587, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_692 = primals_587 = None
        getitem_695 = convolution_backward_default_71[0]
        getitem_696 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_695, torch.float32);  getitem_695 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_159, to_dtype_213);  le_scalar_53 = new_zeros_default_159 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_66, primals_575, primals_573, primals_574, getitem_156, getitem_157, True, 1e-05, [True, True, True]);  to_dtype_215 = convolution_default_66 = primals_575 = primals_573 = primals_574 = getitem_156 = getitem_157 = None
        getitem_698 = native_batch_norm_backward_default_54[0]
        getitem_699 = native_batch_norm_backward_default_54[1]
        getitem_700 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_698, relu__default_47, primals_586, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_698 = primals_586 = None
        getitem_701 = convolution_backward_default_72[0]
        getitem_702 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(to_dtype_206, getitem_701);  to_dtype_206 = getitem_701 = None
        to_dtype_216 = torch.ops.aten.to.dtype(add_tensor_35, torch.float32);  add_tensor_35 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_160, to_dtype_216);  le_scalar_54 = new_zeros_default_160 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_218, getitem_152);  getitem_152 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_218, expand_default_14);  expand_default_14 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(mul_tensor_105, [2, 3], True);  mul_tensor_105 = None
        view_default_105 = torch.ops.aten.view.default(sum_dim_int_list_19, [128, 1, 1024]);  sum_dim_int_list_19 = None
        to_dtype_219 = torch.ops.aten.to.dtype(view_default_105, torch.float32);  view_default_105 = None
        to_dtype_220 = torch.ops.aten.to.dtype(sigmoid_default_14, torch.float32);  sigmoid_default_14 = None
        rsub_scalar_18 = torch.ops.aten.rsub.Scalar(to_dtype_220, 1)
        mul_tensor_107 = torch.ops.aten.mul.Tensor(to_dtype_220, rsub_scalar_18);  to_dtype_220 = rsub_scalar_18 = None
        conj_physical_default_18 = torch.ops.aten.conj_physical.default(mul_tensor_107);  mul_tensor_107 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(to_dtype_219, conj_physical_default_18);  to_dtype_219 = conj_physical_default_18 = None
        to_dtype_221 = torch.ops.aten.to.dtype(mul_tensor_108, torch.float32);  mul_tensor_108 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(to_dtype_221, view_default_28, primals_570, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_221 = view_default_28 = primals_570 = None
        getitem_704 = convolution_backward_default_73[0]
        getitem_705 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        view_default_106 = torch.ops.aten.view.default(getitem_704, [128, 1024]);  getitem_704 = None
        unsqueeze_default_36 = torch.ops.aten.unsqueeze.default(view_default_106, 2);  view_default_106 = None
        unsqueeze_default_37 = torch.ops.aten.unsqueeze.default(unsqueeze_default_36, 3);  unsqueeze_default_36 = None
        expand_default_52 = torch.ops.aten.expand.default(unsqueeze_default_37, [128, 1024, 14, 14]);  unsqueeze_default_37 = None
        div_scalar_19 = torch.ops.aten.div.Scalar(expand_default_52, 196);  expand_default_52 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(mul_tensor_106, div_scalar_19);  mul_tensor_106 = div_scalar_19 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_36, convolution_default_64, primals_566, primals_564, primals_565, getitem_153, getitem_154, True, 1e-05, [True, True, True]);  add_tensor_36 = convolution_default_64 = primals_566 = primals_564 = primals_565 = getitem_153 = getitem_154 = None
        getitem_707 = native_batch_norm_backward_default_55[0]
        getitem_708 = native_batch_norm_backward_default_55[1]
        getitem_709 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_707, relu__default_46, primals_569, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_707 = primals_569 = None
        getitem_710 = convolution_backward_default_74[0]
        getitem_711 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_710, torch.float32);  getitem_710 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_161, to_dtype_222);  le_scalar_55 = new_zeros_default_161 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_63, primals_561, primals_559, primals_560, getitem_150, getitem_151, True, 1e-05, [True, True, True]);  to_dtype_224 = convolution_default_63 = primals_561 = primals_559 = primals_560 = getitem_150 = getitem_151 = None
        getitem_713 = native_batch_norm_backward_default_56[0]
        getitem_714 = native_batch_norm_backward_default_56[1]
        getitem_715 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_713, relu__default_45, primals_568, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_713 = primals_568 = None
        getitem_716 = convolution_backward_default_75[0]
        getitem_717 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        to_dtype_225 = torch.ops.aten.to.dtype(getitem_716, torch.float32);  getitem_716 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_162, to_dtype_225);  le_scalar_56 = new_zeros_default_162 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_62, primals_556, primals_554, primals_555, getitem_147, getitem_148, True, 1e-05, [True, True, True]);  to_dtype_227 = convolution_default_62 = primals_556 = primals_554 = primals_555 = getitem_147 = getitem_148 = None
        getitem_719 = native_batch_norm_backward_default_57[0]
        getitem_720 = native_batch_norm_backward_default_57[1]
        getitem_721 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_719, relu__default_44, primals_567, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_719 = primals_567 = None
        getitem_722 = convolution_backward_default_76[0]
        getitem_723 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(to_dtype_218, getitem_722);  to_dtype_218 = getitem_722 = None
        to_dtype_228 = torch.ops.aten.to.dtype(add_tensor_37, torch.float32);  add_tensor_37 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_163, to_dtype_228);  le_scalar_57 = new_zeros_default_163 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_230, getitem_143);  getitem_143 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(to_dtype_230, expand_default_13);  expand_default_13 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(mul_tensor_109, [2, 3], True);  mul_tensor_109 = None
        view_default_107 = torch.ops.aten.view.default(sum_dim_int_list_20, [128, 1, 1024]);  sum_dim_int_list_20 = None
        to_dtype_231 = torch.ops.aten.to.dtype(view_default_107, torch.float32);  view_default_107 = None
        to_dtype_232 = torch.ops.aten.to.dtype(sigmoid_default_13, torch.float32);  sigmoid_default_13 = None
        rsub_scalar_19 = torch.ops.aten.rsub.Scalar(to_dtype_232, 1)
        mul_tensor_111 = torch.ops.aten.mul.Tensor(to_dtype_232, rsub_scalar_19);  to_dtype_232 = rsub_scalar_19 = None
        conj_physical_default_19 = torch.ops.aten.conj_physical.default(mul_tensor_111);  mul_tensor_111 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_231, conj_physical_default_19);  to_dtype_231 = conj_physical_default_19 = None
        to_dtype_233 = torch.ops.aten.to.dtype(mul_tensor_112, torch.float32);  mul_tensor_112 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(to_dtype_233, view_default_26, primals_551, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_233 = view_default_26 = primals_551 = None
        getitem_725 = convolution_backward_default_77[0]
        getitem_726 = convolution_backward_default_77[1];  convolution_backward_default_77 = None
        view_default_108 = torch.ops.aten.view.default(getitem_725, [128, 1024]);  getitem_725 = None
        unsqueeze_default_38 = torch.ops.aten.unsqueeze.default(view_default_108, 2);  view_default_108 = None
        unsqueeze_default_39 = torch.ops.aten.unsqueeze.default(unsqueeze_default_38, 3);  unsqueeze_default_38 = None
        expand_default_53 = torch.ops.aten.expand.default(unsqueeze_default_39, [128, 1024, 14, 14]);  unsqueeze_default_39 = None
        div_scalar_20 = torch.ops.aten.div.Scalar(expand_default_53, 196);  expand_default_53 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_110, div_scalar_20);  mul_tensor_110 = div_scalar_20 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_38, convolution_default_60, primals_547, primals_545, primals_546, getitem_144, getitem_145, True, 1e-05, [True, True, True]);  add_tensor_38 = convolution_default_60 = primals_547 = primals_545 = primals_546 = getitem_144 = getitem_145 = None
        getitem_728 = native_batch_norm_backward_default_58[0]
        getitem_729 = native_batch_norm_backward_default_58[1]
        getitem_730 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_728, relu__default_43, primals_550, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_728 = primals_550 = None
        getitem_731 = convolution_backward_default_78[0]
        getitem_732 = convolution_backward_default_78[1];  convolution_backward_default_78 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_731, torch.float32);  getitem_731 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_164, to_dtype_234);  le_scalar_58 = new_zeros_default_164 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_59, primals_542, primals_540, primals_541, getitem_141, getitem_142, True, 1e-05, [True, True, True]);  to_dtype_236 = convolution_default_59 = primals_542 = primals_540 = primals_541 = getitem_141 = getitem_142 = None
        getitem_734 = native_batch_norm_backward_default_59[0]
        getitem_735 = native_batch_norm_backward_default_59[1]
        getitem_736 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_734, relu__default_42, primals_549, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_734 = primals_549 = None
        getitem_737 = convolution_backward_default_79[0]
        getitem_738 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_737, torch.float32);  getitem_737 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_165, to_dtype_237);  le_scalar_59 = new_zeros_default_165 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_58, primals_537, primals_535, primals_536, getitem_138, getitem_139, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_58 = primals_537 = primals_535 = primals_536 = getitem_138 = getitem_139 = None
        getitem_740 = native_batch_norm_backward_default_60[0]
        getitem_741 = native_batch_norm_backward_default_60[1]
        getitem_742 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_740, relu__default_41, primals_548, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_740 = primals_548 = None
        getitem_743 = convolution_backward_default_80[0]
        getitem_744 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(to_dtype_230, getitem_743);  to_dtype_230 = getitem_743 = None
        to_dtype_240 = torch.ops.aten.to.dtype(add_tensor_39, torch.float32);  add_tensor_39 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_166, to_dtype_240);  le_scalar_60 = new_zeros_default_166 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(to_dtype_242, getitem_134);  getitem_134 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(to_dtype_242, expand_default_12);  expand_default_12 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(mul_tensor_113, [2, 3], True);  mul_tensor_113 = None
        view_default_109 = torch.ops.aten.view.default(sum_dim_int_list_21, [128, 1, 1024]);  sum_dim_int_list_21 = None
        to_dtype_243 = torch.ops.aten.to.dtype(view_default_109, torch.float32);  view_default_109 = None
        to_dtype_244 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar_20 = torch.ops.aten.rsub.Scalar(to_dtype_244, 1)
        mul_tensor_115 = torch.ops.aten.mul.Tensor(to_dtype_244, rsub_scalar_20);  to_dtype_244 = rsub_scalar_20 = None
        conj_physical_default_20 = torch.ops.aten.conj_physical.default(mul_tensor_115);  mul_tensor_115 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(to_dtype_243, conj_physical_default_20);  to_dtype_243 = conj_physical_default_20 = None
        to_dtype_245 = torch.ops.aten.to.dtype(mul_tensor_116, torch.float32);  mul_tensor_116 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(to_dtype_245, view_default_24, primals_532, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_245 = view_default_24 = primals_532 = None
        getitem_746 = convolution_backward_default_81[0]
        getitem_747 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        view_default_110 = torch.ops.aten.view.default(getitem_746, [128, 1024]);  getitem_746 = None
        unsqueeze_default_40 = torch.ops.aten.unsqueeze.default(view_default_110, 2);  view_default_110 = None
        unsqueeze_default_41 = torch.ops.aten.unsqueeze.default(unsqueeze_default_40, 3);  unsqueeze_default_40 = None
        expand_default_54 = torch.ops.aten.expand.default(unsqueeze_default_41, [128, 1024, 14, 14]);  unsqueeze_default_41 = None
        div_scalar_21 = torch.ops.aten.div.Scalar(expand_default_54, 196);  expand_default_54 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(mul_tensor_114, div_scalar_21);  mul_tensor_114 = div_scalar_21 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_40, convolution_default_56, primals_528, primals_526, primals_527, getitem_135, getitem_136, True, 1e-05, [True, True, True]);  add_tensor_40 = convolution_default_56 = primals_528 = primals_526 = primals_527 = getitem_135 = getitem_136 = None
        getitem_749 = native_batch_norm_backward_default_61[0]
        getitem_750 = native_batch_norm_backward_default_61[1]
        getitem_751 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_749, relu__default_40, primals_531, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_749 = primals_531 = None
        getitem_752 = convolution_backward_default_82[0]
        getitem_753 = convolution_backward_default_82[1];  convolution_backward_default_82 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_752, torch.float32);  getitem_752 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_167, to_dtype_246);  le_scalar_61 = new_zeros_default_167 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_55, primals_523, primals_521, primals_522, getitem_132, getitem_133, True, 1e-05, [True, True, True]);  to_dtype_248 = convolution_default_55 = primals_523 = primals_521 = primals_522 = getitem_132 = getitem_133 = None
        getitem_755 = native_batch_norm_backward_default_62[0]
        getitem_756 = native_batch_norm_backward_default_62[1]
        getitem_757 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_755, relu__default_39, primals_530, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_755 = primals_530 = None
        getitem_758 = convolution_backward_default_83[0]
        getitem_759 = convolution_backward_default_83[1];  convolution_backward_default_83 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_758, torch.float32);  getitem_758 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_168, to_dtype_249);  le_scalar_62 = new_zeros_default_168 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_54, primals_518, primals_516, primals_517, getitem_129, getitem_130, True, 1e-05, [True, True, True]);  to_dtype_251 = convolution_default_54 = primals_518 = primals_516 = primals_517 = getitem_129 = getitem_130 = None
        getitem_761 = native_batch_norm_backward_default_63[0]
        getitem_762 = native_batch_norm_backward_default_63[1]
        getitem_763 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_761, relu__default_38, primals_529, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_761 = primals_529 = None
        getitem_764 = convolution_backward_default_84[0]
        getitem_765 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(to_dtype_242, getitem_764);  to_dtype_242 = getitem_764 = None
        to_dtype_252 = torch.ops.aten.to.dtype(add_tensor_41, torch.float32);  add_tensor_41 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_169, to_dtype_252);  le_scalar_63 = new_zeros_default_169 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_254, getitem_125);  getitem_125 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(to_dtype_254, expand_default_11);  expand_default_11 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(mul_tensor_117, [2, 3], True);  mul_tensor_117 = None
        view_default_111 = torch.ops.aten.view.default(sum_dim_int_list_22, [128, 1, 1024]);  sum_dim_int_list_22 = None
        to_dtype_255 = torch.ops.aten.to.dtype(view_default_111, torch.float32);  view_default_111 = None
        to_dtype_256 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_21 = torch.ops.aten.rsub.Scalar(to_dtype_256, 1)
        mul_tensor_119 = torch.ops.aten.mul.Tensor(to_dtype_256, rsub_scalar_21);  to_dtype_256 = rsub_scalar_21 = None
        conj_physical_default_21 = torch.ops.aten.conj_physical.default(mul_tensor_119);  mul_tensor_119 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_255, conj_physical_default_21);  to_dtype_255 = conj_physical_default_21 = None
        to_dtype_257 = torch.ops.aten.to.dtype(mul_tensor_120, torch.float32);  mul_tensor_120 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(to_dtype_257, view_default_22, primals_513, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_257 = view_default_22 = primals_513 = None
        getitem_767 = convolution_backward_default_85[0]
        getitem_768 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        view_default_112 = torch.ops.aten.view.default(getitem_767, [128, 1024]);  getitem_767 = None
        unsqueeze_default_42 = torch.ops.aten.unsqueeze.default(view_default_112, 2);  view_default_112 = None
        unsqueeze_default_43 = torch.ops.aten.unsqueeze.default(unsqueeze_default_42, 3);  unsqueeze_default_42 = None
        expand_default_55 = torch.ops.aten.expand.default(unsqueeze_default_43, [128, 1024, 14, 14]);  unsqueeze_default_43 = None
        div_scalar_22 = torch.ops.aten.div.Scalar(expand_default_55, 196);  expand_default_55 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(mul_tensor_118, div_scalar_22);  mul_tensor_118 = div_scalar_22 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_42, convolution_default_52, primals_509, primals_507, primals_508, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  add_tensor_42 = convolution_default_52 = primals_509 = primals_507 = primals_508 = getitem_126 = getitem_127 = None
        getitem_770 = native_batch_norm_backward_default_64[0]
        getitem_771 = native_batch_norm_backward_default_64[1]
        getitem_772 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_770, relu__default_37, primals_512, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_770 = primals_512 = None
        getitem_773 = convolution_backward_default_86[0]
        getitem_774 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        to_dtype_258 = torch.ops.aten.to.dtype(getitem_773, torch.float32);  getitem_773 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_170, to_dtype_258);  le_scalar_64 = new_zeros_default_170 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_51, primals_504, primals_502, primals_503, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  to_dtype_260 = convolution_default_51 = primals_504 = primals_502 = primals_503 = getitem_123 = getitem_124 = None
        getitem_776 = native_batch_norm_backward_default_65[0]
        getitem_777 = native_batch_norm_backward_default_65[1]
        getitem_778 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_776, relu__default_36, primals_511, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_776 = primals_511 = None
        getitem_779 = convolution_backward_default_87[0]
        getitem_780 = convolution_backward_default_87[1];  convolution_backward_default_87 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_779, torch.float32);  getitem_779 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_171, to_dtype_261);  le_scalar_65 = new_zeros_default_171 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_50, primals_499, primals_497, primals_498, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  to_dtype_263 = convolution_default_50 = primals_499 = primals_497 = primals_498 = getitem_120 = getitem_121 = None
        getitem_782 = native_batch_norm_backward_default_66[0]
        getitem_783 = native_batch_norm_backward_default_66[1]
        getitem_784 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_782, relu__default_35, primals_510, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_782 = primals_510 = None
        getitem_785 = convolution_backward_default_88[0]
        getitem_786 = convolution_backward_default_88[1];  convolution_backward_default_88 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(to_dtype_254, getitem_785);  to_dtype_254 = getitem_785 = None
        to_dtype_264 = torch.ops.aten.to.dtype(add_tensor_43, torch.float32);  add_tensor_43 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_172, to_dtype_264);  le_scalar_66 = new_zeros_default_172 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_266, getitem_116);  getitem_116 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(to_dtype_266, expand_default_10);  expand_default_10 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(mul_tensor_121, [2, 3], True);  mul_tensor_121 = None
        view_default_113 = torch.ops.aten.view.default(sum_dim_int_list_23, [128, 1, 1024]);  sum_dim_int_list_23 = None
        to_dtype_267 = torch.ops.aten.to.dtype(view_default_113, torch.float32);  view_default_113 = None
        to_dtype_268 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_22 = torch.ops.aten.rsub.Scalar(to_dtype_268, 1)
        mul_tensor_123 = torch.ops.aten.mul.Tensor(to_dtype_268, rsub_scalar_22);  to_dtype_268 = rsub_scalar_22 = None
        conj_physical_default_22 = torch.ops.aten.conj_physical.default(mul_tensor_123);  mul_tensor_123 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_267, conj_physical_default_22);  to_dtype_267 = conj_physical_default_22 = None
        to_dtype_269 = torch.ops.aten.to.dtype(mul_tensor_124, torch.float32);  mul_tensor_124 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(to_dtype_269, view_default_20, primals_494, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_269 = view_default_20 = primals_494 = None
        getitem_788 = convolution_backward_default_89[0]
        getitem_789 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        view_default_114 = torch.ops.aten.view.default(getitem_788, [128, 1024]);  getitem_788 = None
        unsqueeze_default_44 = torch.ops.aten.unsqueeze.default(view_default_114, 2);  view_default_114 = None
        unsqueeze_default_45 = torch.ops.aten.unsqueeze.default(unsqueeze_default_44, 3);  unsqueeze_default_44 = None
        expand_default_56 = torch.ops.aten.expand.default(unsqueeze_default_45, [128, 1024, 14, 14]);  unsqueeze_default_45 = None
        div_scalar_23 = torch.ops.aten.div.Scalar(expand_default_56, 196);  expand_default_56 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(mul_tensor_122, div_scalar_23);  mul_tensor_122 = div_scalar_23 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_44, convolution_default_48, primals_490, primals_488, primals_489, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  add_tensor_44 = convolution_default_48 = primals_490 = primals_488 = primals_489 = getitem_117 = getitem_118 = None
        getitem_791 = native_batch_norm_backward_default_67[0]
        getitem_792 = native_batch_norm_backward_default_67[1]
        getitem_793 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_791, relu__default_34, primals_493, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_791 = primals_493 = None
        getitem_794 = convolution_backward_default_90[0]
        getitem_795 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        to_dtype_270 = torch.ops.aten.to.dtype(getitem_794, torch.float32);  getitem_794 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_173, to_dtype_270);  le_scalar_67 = new_zeros_default_173 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_47, primals_485, primals_483, primals_484, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  to_dtype_272 = convolution_default_47 = primals_485 = primals_483 = primals_484 = getitem_114 = getitem_115 = None
        getitem_797 = native_batch_norm_backward_default_68[0]
        getitem_798 = native_batch_norm_backward_default_68[1]
        getitem_799 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_797, relu__default_33, primals_492, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_797 = primals_492 = None
        getitem_800 = convolution_backward_default_91[0]
        getitem_801 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_800, torch.float32);  getitem_800 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_174, to_dtype_273);  le_scalar_68 = new_zeros_default_174 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_46, primals_480, primals_478, primals_479, getitem_111, getitem_112, True, 1e-05, [True, True, True]);  to_dtype_275 = convolution_default_46 = primals_480 = primals_478 = primals_479 = getitem_111 = getitem_112 = None
        getitem_803 = native_batch_norm_backward_default_69[0]
        getitem_804 = native_batch_norm_backward_default_69[1]
        getitem_805 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_803, relu__default_32, primals_491, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_803 = primals_491 = None
        getitem_806 = convolution_backward_default_92[0]
        getitem_807 = convolution_backward_default_92[1];  convolution_backward_default_92 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(to_dtype_266, getitem_806);  to_dtype_266 = getitem_806 = None
        to_dtype_276 = torch.ops.aten.to.dtype(add_tensor_45, torch.float32);  add_tensor_45 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_175, to_dtype_276);  le_scalar_69 = new_zeros_default_175 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_278, getitem_107);  getitem_107 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_278, expand_default_9);  expand_default_9 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(mul_tensor_125, [2, 3], True);  mul_tensor_125 = None
        view_default_115 = torch.ops.aten.view.default(sum_dim_int_list_24, [128, 1, 1024]);  sum_dim_int_list_24 = None
        to_dtype_279 = torch.ops.aten.to.dtype(view_default_115, torch.float32);  view_default_115 = None
        to_dtype_280 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_23 = torch.ops.aten.rsub.Scalar(to_dtype_280, 1)
        mul_tensor_127 = torch.ops.aten.mul.Tensor(to_dtype_280, rsub_scalar_23);  to_dtype_280 = rsub_scalar_23 = None
        conj_physical_default_23 = torch.ops.aten.conj_physical.default(mul_tensor_127);  mul_tensor_127 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(to_dtype_279, conj_physical_default_23);  to_dtype_279 = conj_physical_default_23 = None
        to_dtype_281 = torch.ops.aten.to.dtype(mul_tensor_128, torch.float32);  mul_tensor_128 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(to_dtype_281, view_default_18, primals_475, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_281 = view_default_18 = primals_475 = None
        getitem_809 = convolution_backward_default_93[0]
        getitem_810 = convolution_backward_default_93[1];  convolution_backward_default_93 = None
        view_default_116 = torch.ops.aten.view.default(getitem_809, [128, 1024]);  getitem_809 = None
        unsqueeze_default_46 = torch.ops.aten.unsqueeze.default(view_default_116, 2);  view_default_116 = None
        unsqueeze_default_47 = torch.ops.aten.unsqueeze.default(unsqueeze_default_46, 3);  unsqueeze_default_46 = None
        expand_default_57 = torch.ops.aten.expand.default(unsqueeze_default_47, [128, 1024, 14, 14]);  unsqueeze_default_47 = None
        div_scalar_24 = torch.ops.aten.div.Scalar(expand_default_57, 196);  expand_default_57 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(mul_tensor_126, div_scalar_24);  mul_tensor_126 = div_scalar_24 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_46, convolution_default_44, primals_471, primals_469, primals_470, getitem_108, getitem_109, True, 1e-05, [True, True, True]);  add_tensor_46 = convolution_default_44 = primals_471 = primals_469 = primals_470 = getitem_108 = getitem_109 = None
        getitem_812 = native_batch_norm_backward_default_70[0]
        getitem_813 = native_batch_norm_backward_default_70[1]
        getitem_814 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_812, relu__default_31, primals_474, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_812 = primals_474 = None
        getitem_815 = convolution_backward_default_94[0]
        getitem_816 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_815, torch.float32);  getitem_815 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_176, to_dtype_282);  le_scalar_70 = new_zeros_default_176 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_43, primals_466, primals_464, primals_465, getitem_105, getitem_106, True, 1e-05, [True, True, True]);  to_dtype_284 = convolution_default_43 = primals_466 = primals_464 = primals_465 = getitem_105 = getitem_106 = None
        getitem_818 = native_batch_norm_backward_default_71[0]
        getitem_819 = native_batch_norm_backward_default_71[1]
        getitem_820 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_818, relu__default_30, primals_473, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_818 = primals_473 = None
        getitem_821 = convolution_backward_default_95[0]
        getitem_822 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        to_dtype_285 = torch.ops.aten.to.dtype(getitem_821, torch.float32);  getitem_821 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_177, to_dtype_285);  le_scalar_71 = new_zeros_default_177 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_287, convolution_default_42, primals_461, primals_459, primals_460, getitem_102, getitem_103, True, 1e-05, [True, True, True]);  to_dtype_287 = convolution_default_42 = primals_461 = primals_459 = primals_460 = getitem_102 = getitem_103 = None
        getitem_824 = native_batch_norm_backward_default_72[0]
        getitem_825 = native_batch_norm_backward_default_72[1]
        getitem_826 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_824, relu__default_29, primals_472, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_824 = primals_472 = None
        getitem_827 = convolution_backward_default_96[0]
        getitem_828 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(to_dtype_278, getitem_827);  to_dtype_278 = getitem_827 = None
        to_dtype_288 = torch.ops.aten.to.dtype(add_tensor_47, torch.float32);  add_tensor_47 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_178, to_dtype_288);  le_scalar_72 = new_zeros_default_178 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(to_dtype_290, getitem_98);  getitem_98 = None
        mul_tensor_130 = torch.ops.aten.mul.Tensor(to_dtype_290, expand_default_8);  expand_default_8 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(mul_tensor_129, [2, 3], True);  mul_tensor_129 = None
        view_default_117 = torch.ops.aten.view.default(sum_dim_int_list_25, [128, 1, 1024]);  sum_dim_int_list_25 = None
        to_dtype_291 = torch.ops.aten.to.dtype(view_default_117, torch.float32);  view_default_117 = None
        to_dtype_292 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_24 = torch.ops.aten.rsub.Scalar(to_dtype_292, 1)
        mul_tensor_131 = torch.ops.aten.mul.Tensor(to_dtype_292, rsub_scalar_24);  to_dtype_292 = rsub_scalar_24 = None
        conj_physical_default_24 = torch.ops.aten.conj_physical.default(mul_tensor_131);  mul_tensor_131 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(to_dtype_291, conj_physical_default_24);  to_dtype_291 = conj_physical_default_24 = None
        to_dtype_293 = torch.ops.aten.to.dtype(mul_tensor_132, torch.float32);  mul_tensor_132 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(to_dtype_293, view_default_16, primals_399, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_293 = view_default_16 = primals_399 = None
        getitem_830 = convolution_backward_default_97[0]
        getitem_831 = convolution_backward_default_97[1];  convolution_backward_default_97 = None
        view_default_118 = torch.ops.aten.view.default(getitem_830, [128, 1024]);  getitem_830 = None
        unsqueeze_default_48 = torch.ops.aten.unsqueeze.default(view_default_118, 2);  view_default_118 = None
        unsqueeze_default_49 = torch.ops.aten.unsqueeze.default(unsqueeze_default_48, 3);  unsqueeze_default_48 = None
        expand_default_58 = torch.ops.aten.expand.default(unsqueeze_default_49, [128, 1024, 14, 14]);  unsqueeze_default_49 = None
        div_scalar_25 = torch.ops.aten.div.Scalar(expand_default_58, 196);  expand_default_58 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(mul_tensor_130, div_scalar_25);  mul_tensor_130 = div_scalar_25 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_48, convolution_default_40, primals_395, primals_393, primals_394, getitem_99, getitem_100, True, 1e-05, [True, True, True]);  add_tensor_48 = convolution_default_40 = primals_395 = primals_393 = primals_394 = getitem_99 = getitem_100 = None
        getitem_833 = native_batch_norm_backward_default_73[0]
        getitem_834 = native_batch_norm_backward_default_73[1]
        getitem_835 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_833, relu__default_28, primals_398, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_833 = primals_398 = None
        getitem_836 = convolution_backward_default_98[0]
        getitem_837 = convolution_backward_default_98[1];  convolution_backward_default_98 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_836, torch.float32);  getitem_836 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_179, to_dtype_294);  le_scalar_73 = new_zeros_default_179 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_39, primals_390, primals_388, primals_389, getitem_96, getitem_97, True, 1e-05, [True, True, True]);  to_dtype_296 = convolution_default_39 = primals_390 = primals_388 = primals_389 = getitem_96 = getitem_97 = None
        getitem_839 = native_batch_norm_backward_default_74[0]
        getitem_840 = native_batch_norm_backward_default_74[1]
        getitem_841 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_839, relu__default_27, primals_397, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_839 = primals_397 = None
        getitem_842 = convolution_backward_default_99[0]
        getitem_843 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_842, torch.float32);  getitem_842 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_180, to_dtype_297);  le_scalar_74 = new_zeros_default_180 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_38, primals_385, primals_383, primals_384, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  to_dtype_299 = convolution_default_38 = primals_385 = primals_383 = primals_384 = getitem_93 = getitem_94 = None
        getitem_845 = native_batch_norm_backward_default_75[0]
        getitem_846 = native_batch_norm_backward_default_75[1]
        getitem_847 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_845, relu__default_26, primals_396, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_845 = primals_396 = None
        getitem_848 = convolution_backward_default_100[0]
        getitem_849 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(to_dtype_290, getitem_848);  to_dtype_290 = getitem_848 = None
        to_dtype_300 = torch.ops.aten.to.dtype(add_tensor_49, torch.float32);  add_tensor_49 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_181, to_dtype_300);  le_scalar_75 = new_zeros_default_181 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_37, primals_189, primals_187, primals_188, getitem_90, getitem_91, True, 1e-05, [True, True, True]);  convolution_default_37 = primals_189 = primals_187 = primals_188 = getitem_90 = getitem_91 = None
        getitem_851 = native_batch_norm_backward_default_76[0]
        getitem_852 = native_batch_norm_backward_default_76[1]
        getitem_853 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_851, avg_pool2d_default_1, primals_184, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_851 = avg_pool2d_default_1 = primals_184 = None
        getitem_854 = convolution_backward_default_101[0]
        getitem_855 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_854, relu__default_23, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_854 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_302, getitem_86);  getitem_86 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(to_dtype_302, expand_default_7);  to_dtype_302 = expand_default_7 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(mul_tensor_133, [2, 3], True);  mul_tensor_133 = None
        view_default_119 = torch.ops.aten.view.default(sum_dim_int_list_26, [128, 1, 1024]);  sum_dim_int_list_26 = None
        to_dtype_303 = torch.ops.aten.to.dtype(view_default_119, torch.float32);  view_default_119 = None
        to_dtype_304 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_25 = torch.ops.aten.rsub.Scalar(to_dtype_304, 1)
        mul_tensor_135 = torch.ops.aten.mul.Tensor(to_dtype_304, rsub_scalar_25);  to_dtype_304 = rsub_scalar_25 = None
        conj_physical_default_25 = torch.ops.aten.conj_physical.default(mul_tensor_135);  mul_tensor_135 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(to_dtype_303, conj_physical_default_25);  to_dtype_303 = conj_physical_default_25 = None
        to_dtype_305 = torch.ops.aten.to.dtype(mul_tensor_136, torch.float32);  mul_tensor_136 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(to_dtype_305, view_default_14, primals_190, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_305 = view_default_14 = primals_190 = None
        getitem_857 = convolution_backward_default_102[0]
        getitem_858 = convolution_backward_default_102[1];  convolution_backward_default_102 = None
        view_default_120 = torch.ops.aten.view.default(getitem_857, [128, 1024]);  getitem_857 = None
        unsqueeze_default_50 = torch.ops.aten.unsqueeze.default(view_default_120, 2);  view_default_120 = None
        unsqueeze_default_51 = torch.ops.aten.unsqueeze.default(unsqueeze_default_50, 3);  unsqueeze_default_50 = None
        expand_default_59 = torch.ops.aten.expand.default(unsqueeze_default_51, [128, 1024, 14, 14]);  unsqueeze_default_51 = None
        div_scalar_26 = torch.ops.aten.div.Scalar(expand_default_59, 196);  expand_default_59 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(mul_tensor_134, div_scalar_26);  mul_tensor_134 = div_scalar_26 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_50, convolution_default_35, primals_180, primals_178, primals_179, getitem_87, getitem_88, True, 1e-05, [True, True, True]);  add_tensor_50 = convolution_default_35 = primals_180 = primals_178 = primals_179 = getitem_87 = getitem_88 = None
        getitem_860 = native_batch_norm_backward_default_77[0]
        getitem_861 = native_batch_norm_backward_default_77[1]
        getitem_862 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_860, relu__default_25, primals_183, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_860 = primals_183 = None
        getitem_863 = convolution_backward_default_103[0]
        getitem_864 = convolution_backward_default_103[1];  convolution_backward_default_103 = None
        to_dtype_306 = torch.ops.aten.to.dtype(getitem_863, torch.float32);  getitem_863 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_182, to_dtype_306);  le_scalar_76 = new_zeros_default_182 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_308, convolution_default_34, primals_175, primals_173, primals_174, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  to_dtype_308 = convolution_default_34 = primals_175 = primals_173 = primals_174 = getitem_84 = getitem_85 = None
        getitem_866 = native_batch_norm_backward_default_78[0]
        getitem_867 = native_batch_norm_backward_default_78[1]
        getitem_868 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_866, relu__default_24, primals_182, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_866 = primals_182 = None
        getitem_869 = convolution_backward_default_104[0]
        getitem_870 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        to_dtype_309 = torch.ops.aten.to.dtype(getitem_869, torch.float32);  getitem_869 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_183, to_dtype_309);  le_scalar_77 = new_zeros_default_183 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_33, primals_170, primals_168, primals_169, getitem_81, getitem_82, True, 1e-05, [True, True, True]);  to_dtype_311 = convolution_default_33 = primals_170 = primals_168 = primals_169 = getitem_81 = getitem_82 = None
        getitem_872 = native_batch_norm_backward_default_79[0]
        getitem_873 = native_batch_norm_backward_default_79[1]
        getitem_874 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_872, relu__default_23, primals_181, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_872 = primals_181 = None
        getitem_875 = convolution_backward_default_105[0]
        getitem_876 = convolution_backward_default_105[1];  convolution_backward_default_105 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_1, getitem_875);  avg_pool2d_backward_default_1 = getitem_875 = None
        to_dtype_312 = torch.ops.aten.to.dtype(add_tensor_51, torch.float32);  add_tensor_51 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_184, to_dtype_312);  le_scalar_78 = new_zeros_default_184 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_314, getitem_77);  getitem_77 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_314, expand_default_6);  expand_default_6 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(mul_tensor_137, [2, 3], True);  mul_tensor_137 = None
        view_default_121 = torch.ops.aten.view.default(sum_dim_int_list_27, [128, 1, 512]);  sum_dim_int_list_27 = None
        to_dtype_315 = torch.ops.aten.to.dtype(view_default_121, torch.float32);  view_default_121 = None
        to_dtype_316 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_26 = torch.ops.aten.rsub.Scalar(to_dtype_316, 1)
        mul_tensor_139 = torch.ops.aten.mul.Tensor(to_dtype_316, rsub_scalar_26);  to_dtype_316 = rsub_scalar_26 = None
        conj_physical_default_26 = torch.ops.aten.conj_physical.default(mul_tensor_139);  mul_tensor_139 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(to_dtype_315, conj_physical_default_26);  to_dtype_315 = conj_physical_default_26 = None
        to_dtype_317 = torch.ops.aten.to.dtype(mul_tensor_140, torch.float32);  mul_tensor_140 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(to_dtype_317, view_default_12, primals_165, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_317 = view_default_12 = primals_165 = None
        getitem_878 = convolution_backward_default_106[0]
        getitem_879 = convolution_backward_default_106[1];  convolution_backward_default_106 = None
        view_default_122 = torch.ops.aten.view.default(getitem_878, [128, 512]);  getitem_878 = None
        unsqueeze_default_52 = torch.ops.aten.unsqueeze.default(view_default_122, 2);  view_default_122 = None
        unsqueeze_default_53 = torch.ops.aten.unsqueeze.default(unsqueeze_default_52, 3);  unsqueeze_default_52 = None
        expand_default_60 = torch.ops.aten.expand.default(unsqueeze_default_53, [128, 512, 28, 28]);  unsqueeze_default_53 = None
        div_scalar_27 = torch.ops.aten.div.Scalar(expand_default_60, 784);  expand_default_60 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(mul_tensor_138, div_scalar_27);  mul_tensor_138 = div_scalar_27 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_52, convolution_default_31, primals_161, primals_159, primals_160, getitem_78, getitem_79, True, 1e-05, [True, True, True]);  add_tensor_52 = convolution_default_31 = primals_161 = primals_159 = primals_160 = getitem_78 = getitem_79 = None
        getitem_881 = native_batch_norm_backward_default_80[0]
        getitem_882 = native_batch_norm_backward_default_80[1]
        getitem_883 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_881, relu__default_22, primals_164, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_881 = primals_164 = None
        getitem_884 = convolution_backward_default_107[0]
        getitem_885 = convolution_backward_default_107[1];  convolution_backward_default_107 = None
        to_dtype_318 = torch.ops.aten.to.dtype(getitem_884, torch.float32);  getitem_884 = None
        to_dtype_319 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_319, 0);  to_dtype_319 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_318, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_185, to_dtype_318);  le_scalar_79 = new_zeros_default_185 = to_dtype_318 = None
        to_dtype_320 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_320, convolution_default_30, primals_156, primals_154, primals_155, getitem_75, getitem_76, True, 1e-05, [True, True, True]);  to_dtype_320 = convolution_default_30 = primals_156 = primals_154 = primals_155 = getitem_75 = getitem_76 = None
        getitem_887 = native_batch_norm_backward_default_81[0]
        getitem_888 = native_batch_norm_backward_default_81[1]
        getitem_889 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_887, relu__default_21, primals_163, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_887 = primals_163 = None
        getitem_890 = convolution_backward_default_108[0]
        getitem_891 = convolution_backward_default_108[1];  convolution_backward_default_108 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_890, torch.float32);  getitem_890 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_186, to_dtype_321);  le_scalar_80 = new_zeros_default_186 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_323, convolution_default_29, primals_151, primals_149, primals_150, getitem_72, getitem_73, True, 1e-05, [True, True, True]);  to_dtype_323 = convolution_default_29 = primals_151 = primals_149 = primals_150 = getitem_72 = getitem_73 = None
        getitem_893 = native_batch_norm_backward_default_82[0]
        getitem_894 = native_batch_norm_backward_default_82[1]
        getitem_895 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_893, relu__default_20, primals_162, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_893 = primals_162 = None
        getitem_896 = convolution_backward_default_109[0]
        getitem_897 = convolution_backward_default_109[1];  convolution_backward_default_109 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(to_dtype_314, getitem_896);  to_dtype_314 = getitem_896 = None
        to_dtype_324 = torch.ops.aten.to.dtype(add_tensor_53, torch.float32);  add_tensor_53 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_187, to_dtype_324);  le_scalar_81 = new_zeros_default_187 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_326, getitem_68);  getitem_68 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_326, expand_default_5);  expand_default_5 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(mul_tensor_141, [2, 3], True);  mul_tensor_141 = None
        view_default_123 = torch.ops.aten.view.default(sum_dim_int_list_28, [128, 1, 512]);  sum_dim_int_list_28 = None
        to_dtype_327 = torch.ops.aten.to.dtype(view_default_123, torch.float32);  view_default_123 = None
        to_dtype_328 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_27 = torch.ops.aten.rsub.Scalar(to_dtype_328, 1)
        mul_tensor_143 = torch.ops.aten.mul.Tensor(to_dtype_328, rsub_scalar_27);  to_dtype_328 = rsub_scalar_27 = None
        conj_physical_default_27 = torch.ops.aten.conj_physical.default(mul_tensor_143);  mul_tensor_143 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_327, conj_physical_default_27);  to_dtype_327 = conj_physical_default_27 = None
        to_dtype_329 = torch.ops.aten.to.dtype(mul_tensor_144, torch.float32);  mul_tensor_144 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(to_dtype_329, view_default_10, primals_146, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_329 = view_default_10 = primals_146 = None
        getitem_899 = convolution_backward_default_110[0]
        getitem_900 = convolution_backward_default_110[1];  convolution_backward_default_110 = None
        view_default_124 = torch.ops.aten.view.default(getitem_899, [128, 512]);  getitem_899 = None
        unsqueeze_default_54 = torch.ops.aten.unsqueeze.default(view_default_124, 2);  view_default_124 = None
        unsqueeze_default_55 = torch.ops.aten.unsqueeze.default(unsqueeze_default_54, 3);  unsqueeze_default_54 = None
        expand_default_61 = torch.ops.aten.expand.default(unsqueeze_default_55, [128, 512, 28, 28]);  unsqueeze_default_55 = None
        div_scalar_28 = torch.ops.aten.div.Scalar(expand_default_61, 784);  expand_default_61 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(mul_tensor_142, div_scalar_28);  mul_tensor_142 = div_scalar_28 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_54, convolution_default_27, primals_142, primals_140, primals_141, getitem_69, getitem_70, True, 1e-05, [True, True, True]);  add_tensor_54 = convolution_default_27 = primals_142 = primals_140 = primals_141 = getitem_69 = getitem_70 = None
        getitem_902 = native_batch_norm_backward_default_83[0]
        getitem_903 = native_batch_norm_backward_default_83[1]
        getitem_904 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_902, relu__default_19, primals_145, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_902 = primals_145 = None
        getitem_905 = convolution_backward_default_111[0]
        getitem_906 = convolution_backward_default_111[1];  convolution_backward_default_111 = None
        to_dtype_330 = torch.ops.aten.to.dtype(getitem_905, torch.float32);  getitem_905 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_188, to_dtype_330);  le_scalar_82 = new_zeros_default_188 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_332, convolution_default_26, primals_137, primals_135, primals_136, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_332 = convolution_default_26 = primals_137 = primals_135 = primals_136 = getitem_66 = getitem_67 = None
        getitem_908 = native_batch_norm_backward_default_84[0]
        getitem_909 = native_batch_norm_backward_default_84[1]
        getitem_910 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_908, relu__default_18, primals_144, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_908 = primals_144 = None
        getitem_911 = convolution_backward_default_112[0]
        getitem_912 = convolution_backward_default_112[1];  convolution_backward_default_112 = None
        to_dtype_333 = torch.ops.aten.to.dtype(getitem_911, torch.float32);  getitem_911 = None
        to_dtype_334 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_334, 0);  to_dtype_334 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_333, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_189, to_dtype_333);  le_scalar_83 = new_zeros_default_189 = to_dtype_333 = None
        to_dtype_335 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_335, convolution_default_25, primals_132, primals_130, primals_131, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  to_dtype_335 = convolution_default_25 = primals_132 = primals_130 = primals_131 = getitem_63 = getitem_64 = None
        getitem_914 = native_batch_norm_backward_default_85[0]
        getitem_915 = native_batch_norm_backward_default_85[1]
        getitem_916 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_914, relu__default_17, primals_143, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_914 = primals_143 = None
        getitem_917 = convolution_backward_default_113[0]
        getitem_918 = convolution_backward_default_113[1];  convolution_backward_default_113 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(to_dtype_326, getitem_917);  to_dtype_326 = getitem_917 = None
        to_dtype_336 = torch.ops.aten.to.dtype(add_tensor_55, torch.float32);  add_tensor_55 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_190, to_dtype_336);  le_scalar_84 = new_zeros_default_190 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_338, getitem_59);  getitem_59 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(to_dtype_338, expand_default_4);  expand_default_4 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(mul_tensor_145, [2, 3], True);  mul_tensor_145 = None
        view_default_125 = torch.ops.aten.view.default(sum_dim_int_list_29, [128, 1, 512]);  sum_dim_int_list_29 = None
        to_dtype_339 = torch.ops.aten.to.dtype(view_default_125, torch.float32);  view_default_125 = None
        to_dtype_340 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_28 = torch.ops.aten.rsub.Scalar(to_dtype_340, 1)
        mul_tensor_147 = torch.ops.aten.mul.Tensor(to_dtype_340, rsub_scalar_28);  to_dtype_340 = rsub_scalar_28 = None
        conj_physical_default_28 = torch.ops.aten.conj_physical.default(mul_tensor_147);  mul_tensor_147 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(to_dtype_339, conj_physical_default_28);  to_dtype_339 = conj_physical_default_28 = None
        to_dtype_341 = torch.ops.aten.to.dtype(mul_tensor_148, torch.float32);  mul_tensor_148 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(to_dtype_341, view_default_8, primals_127, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_341 = view_default_8 = primals_127 = None
        getitem_920 = convolution_backward_default_114[0]
        getitem_921 = convolution_backward_default_114[1];  convolution_backward_default_114 = None
        view_default_126 = torch.ops.aten.view.default(getitem_920, [128, 512]);  getitem_920 = None
        unsqueeze_default_56 = torch.ops.aten.unsqueeze.default(view_default_126, 2);  view_default_126 = None
        unsqueeze_default_57 = torch.ops.aten.unsqueeze.default(unsqueeze_default_56, 3);  unsqueeze_default_56 = None
        expand_default_62 = torch.ops.aten.expand.default(unsqueeze_default_57, [128, 512, 28, 28]);  unsqueeze_default_57 = None
        div_scalar_29 = torch.ops.aten.div.Scalar(expand_default_62, 784);  expand_default_62 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(mul_tensor_146, div_scalar_29);  mul_tensor_146 = div_scalar_29 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_56, convolution_default_23, primals_123, primals_121, primals_122, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  add_tensor_56 = convolution_default_23 = primals_123 = primals_121 = primals_122 = getitem_60 = getitem_61 = None
        getitem_923 = native_batch_norm_backward_default_86[0]
        getitem_924 = native_batch_norm_backward_default_86[1]
        getitem_925 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_923, relu__default_16, primals_126, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_923 = primals_126 = None
        getitem_926 = convolution_backward_default_115[0]
        getitem_927 = convolution_backward_default_115[1];  convolution_backward_default_115 = None
        to_dtype_342 = torch.ops.aten.to.dtype(getitem_926, torch.float32);  getitem_926 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_191, to_dtype_342);  le_scalar_85 = new_zeros_default_191 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_344, convolution_default_22, primals_118, primals_116, primals_117, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_344 = convolution_default_22 = primals_118 = primals_116 = primals_117 = getitem_57 = getitem_58 = None
        getitem_929 = native_batch_norm_backward_default_87[0]
        getitem_930 = native_batch_norm_backward_default_87[1]
        getitem_931 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_929, relu__default_15, primals_125, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_929 = primals_125 = None
        getitem_932 = convolution_backward_default_116[0]
        getitem_933 = convolution_backward_default_116[1];  convolution_backward_default_116 = None
        to_dtype_345 = torch.ops.aten.to.dtype(getitem_932, torch.float32);  getitem_932 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_192, to_dtype_345);  le_scalar_86 = new_zeros_default_192 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_347, convolution_default_21, primals_113, primals_111, primals_112, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_347 = convolution_default_21 = primals_113 = primals_111 = primals_112 = getitem_54 = getitem_55 = None
        getitem_935 = native_batch_norm_backward_default_88[0]
        getitem_936 = native_batch_norm_backward_default_88[1]
        getitem_937 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_935, relu__default_14, primals_124, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_935 = primals_124 = None
        getitem_938 = convolution_backward_default_117[0]
        getitem_939 = convolution_backward_default_117[1];  convolution_backward_default_117 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(to_dtype_338, getitem_938);  to_dtype_338 = getitem_938 = None
        to_dtype_348 = torch.ops.aten.to.dtype(add_tensor_57, torch.float32);  add_tensor_57 = None
        to_dtype_349 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_349, 0);  to_dtype_349 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_348, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_193, to_dtype_348);  le_scalar_87 = new_zeros_default_193 = to_dtype_348 = None
        to_dtype_350 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_350, convolution_default_20, primals_107, primals_105, primals_106, getitem_51, getitem_52, True, 1e-05, [True, True, True]);  convolution_default_20 = primals_107 = primals_105 = primals_106 = getitem_51 = getitem_52 = None
        getitem_941 = native_batch_norm_backward_default_89[0]
        getitem_942 = native_batch_norm_backward_default_89[1]
        getitem_943 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_941, avg_pool2d_default, primals_102, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_941 = avg_pool2d_default = primals_102 = None
        getitem_944 = convolution_backward_default_118[0]
        getitem_945 = convolution_backward_default_118[1];  convolution_backward_default_118 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_944, relu__default_11, [2, 2], [2, 2], [0, 0], True, False, None);  getitem_944 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_350, getitem_47);  getitem_47 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(to_dtype_350, expand_default_3);  to_dtype_350 = expand_default_3 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(mul_tensor_149, [2, 3], True);  mul_tensor_149 = None
        view_default_127 = torch.ops.aten.view.default(sum_dim_int_list_30, [128, 1, 512]);  sum_dim_int_list_30 = None
        to_dtype_351 = torch.ops.aten.to.dtype(view_default_127, torch.float32);  view_default_127 = None
        to_dtype_352 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_29 = torch.ops.aten.rsub.Scalar(to_dtype_352, 1)
        mul_tensor_151 = torch.ops.aten.mul.Tensor(to_dtype_352, rsub_scalar_29);  to_dtype_352 = rsub_scalar_29 = None
        conj_physical_default_29 = torch.ops.aten.conj_physical.default(mul_tensor_151);  mul_tensor_151 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_351, conj_physical_default_29);  to_dtype_351 = conj_physical_default_29 = None
        to_dtype_353 = torch.ops.aten.to.dtype(mul_tensor_152, torch.float32);  mul_tensor_152 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(to_dtype_353, view_default_6, primals_108, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_353 = view_default_6 = primals_108 = None
        getitem_947 = convolution_backward_default_119[0]
        getitem_948 = convolution_backward_default_119[1];  convolution_backward_default_119 = None
        view_default_128 = torch.ops.aten.view.default(getitem_947, [128, 512]);  getitem_947 = None
        unsqueeze_default_58 = torch.ops.aten.unsqueeze.default(view_default_128, 2);  view_default_128 = None
        unsqueeze_default_59 = torch.ops.aten.unsqueeze.default(unsqueeze_default_58, 3);  unsqueeze_default_58 = None
        expand_default_63 = torch.ops.aten.expand.default(unsqueeze_default_59, [128, 512, 28, 28]);  unsqueeze_default_59 = None
        div_scalar_30 = torch.ops.aten.div.Scalar(expand_default_63, 784);  expand_default_63 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(mul_tensor_150, div_scalar_30);  mul_tensor_150 = div_scalar_30 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_58, convolution_default_18, primals_98, primals_96, primals_97, getitem_48, getitem_49, True, 1e-05, [True, True, True]);  add_tensor_58 = convolution_default_18 = primals_98 = primals_96 = primals_97 = getitem_48 = getitem_49 = None
        getitem_950 = native_batch_norm_backward_default_90[0]
        getitem_951 = native_batch_norm_backward_default_90[1]
        getitem_952 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_950, relu__default_13, primals_101, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_950 = primals_101 = None
        getitem_953 = convolution_backward_default_120[0]
        getitem_954 = convolution_backward_default_120[1];  convolution_backward_default_120 = None
        to_dtype_354 = torch.ops.aten.to.dtype(getitem_953, torch.float32);  getitem_953 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_194, to_dtype_354);  le_scalar_88 = new_zeros_default_194 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_356, convolution_default_17, primals_93, primals_91, primals_92, getitem_45, getitem_46, True, 1e-05, [True, True, True]);  to_dtype_356 = convolution_default_17 = primals_93 = primals_91 = primals_92 = getitem_45 = getitem_46 = None
        getitem_956 = native_batch_norm_backward_default_91[0]
        getitem_957 = native_batch_norm_backward_default_91[1]
        getitem_958 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_956, relu__default_12, primals_100, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_956 = primals_100 = None
        getitem_959 = convolution_backward_default_121[0]
        getitem_960 = convolution_backward_default_121[1];  convolution_backward_default_121 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_959, torch.float32);  getitem_959 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_195, to_dtype_357);  le_scalar_89 = new_zeros_default_195 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_16, primals_88, primals_86, primals_87, getitem_42, getitem_43, True, 1e-05, [True, True, True]);  to_dtype_359 = convolution_default_16 = primals_88 = primals_86 = primals_87 = getitem_42 = getitem_43 = None
        getitem_962 = native_batch_norm_backward_default_92[0]
        getitem_963 = native_batch_norm_backward_default_92[1]
        getitem_964 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_962, relu__default_11, primals_99, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_962 = primals_99 = None
        getitem_965 = convolution_backward_default_122[0]
        getitem_966 = convolution_backward_default_122[1];  convolution_backward_default_122 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_2, getitem_965);  avg_pool2d_backward_default_2 = getitem_965 = None
        to_dtype_360 = torch.ops.aten.to.dtype(add_tensor_59, torch.float32);  add_tensor_59 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_196, to_dtype_360);  le_scalar_90 = new_zeros_default_196 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_362, getitem_38);  getitem_38 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(to_dtype_362, expand_default_2);  expand_default_2 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(mul_tensor_153, [2, 3], True);  mul_tensor_153 = None
        view_default_129 = torch.ops.aten.view.default(sum_dim_int_list_31, [128, 1, 256]);  sum_dim_int_list_31 = None
        to_dtype_363 = torch.ops.aten.to.dtype(view_default_129, torch.float32);  view_default_129 = None
        to_dtype_364 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_30 = torch.ops.aten.rsub.Scalar(to_dtype_364, 1)
        mul_tensor_155 = torch.ops.aten.mul.Tensor(to_dtype_364, rsub_scalar_30);  to_dtype_364 = rsub_scalar_30 = None
        conj_physical_default_30 = torch.ops.aten.conj_physical.default(mul_tensor_155);  mul_tensor_155 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(to_dtype_363, conj_physical_default_30);  to_dtype_363 = conj_physical_default_30 = None
        to_dtype_365 = torch.ops.aten.to.dtype(mul_tensor_156, torch.float32);  mul_tensor_156 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(to_dtype_365, view_default_4, primals_83, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_365 = view_default_4 = primals_83 = None
        getitem_968 = convolution_backward_default_123[0]
        getitem_969 = convolution_backward_default_123[1];  convolution_backward_default_123 = None
        view_default_130 = torch.ops.aten.view.default(getitem_968, [128, 256]);  getitem_968 = None
        unsqueeze_default_60 = torch.ops.aten.unsqueeze.default(view_default_130, 2);  view_default_130 = None
        unsqueeze_default_61 = torch.ops.aten.unsqueeze.default(unsqueeze_default_60, 3);  unsqueeze_default_60 = None
        expand_default_64 = torch.ops.aten.expand.default(unsqueeze_default_61, [128, 256, 56, 56]);  unsqueeze_default_61 = None
        div_scalar_31 = torch.ops.aten.div.Scalar(expand_default_64, 3136);  expand_default_64 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(mul_tensor_154, div_scalar_31);  mul_tensor_154 = div_scalar_31 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_60, convolution_default_14, primals_79, primals_77, primals_78, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  add_tensor_60 = convolution_default_14 = primals_79 = primals_77 = primals_78 = getitem_39 = getitem_40 = None
        getitem_971 = native_batch_norm_backward_default_93[0]
        getitem_972 = native_batch_norm_backward_default_93[1]
        getitem_973 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_971, relu__default_10, primals_82, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_971 = primals_82 = None
        getitem_974 = convolution_backward_default_124[0]
        getitem_975 = convolution_backward_default_124[1];  convolution_backward_default_124 = None
        to_dtype_366 = torch.ops.aten.to.dtype(getitem_974, torch.float32);  getitem_974 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_197, to_dtype_366);  le_scalar_91 = new_zeros_default_197 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_368, convolution_default_13, primals_74, primals_72, primals_73, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  to_dtype_368 = convolution_default_13 = primals_74 = primals_72 = primals_73 = getitem_36 = getitem_37 = None
        getitem_977 = native_batch_norm_backward_default_94[0]
        getitem_978 = native_batch_norm_backward_default_94[1]
        getitem_979 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_977, relu__default_9, primals_81, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_977 = primals_81 = None
        getitem_980 = convolution_backward_default_125[0]
        getitem_981 = convolution_backward_default_125[1];  convolution_backward_default_125 = None
        to_dtype_369 = torch.ops.aten.to.dtype(getitem_980, torch.float32);  getitem_980 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_198, to_dtype_369);  le_scalar_92 = new_zeros_default_198 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_12, primals_69, primals_67, primals_68, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  to_dtype_371 = convolution_default_12 = primals_69 = primals_67 = primals_68 = getitem_33 = getitem_34 = None
        getitem_983 = native_batch_norm_backward_default_95[0]
        getitem_984 = native_batch_norm_backward_default_95[1]
        getitem_985 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_983, relu__default_8, primals_80, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_983 = primals_80 = None
        getitem_986 = convolution_backward_default_126[0]
        getitem_987 = convolution_backward_default_126[1];  convolution_backward_default_126 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(to_dtype_362, getitem_986);  to_dtype_362 = getitem_986 = None
        to_dtype_372 = torch.ops.aten.to.dtype(add_tensor_61, torch.float32);  add_tensor_61 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_199, to_dtype_372);  le_scalar_93 = new_zeros_default_199 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_374, getitem_29);  getitem_29 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(to_dtype_374, expand_default_1);  expand_default_1 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(mul_tensor_157, [2, 3], True);  mul_tensor_157 = None
        view_default_131 = torch.ops.aten.view.default(sum_dim_int_list_32, [128, 1, 256]);  sum_dim_int_list_32 = None
        to_dtype_375 = torch.ops.aten.to.dtype(view_default_131, torch.float32);  view_default_131 = None
        to_dtype_376 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_31 = torch.ops.aten.rsub.Scalar(to_dtype_376, 1)
        mul_tensor_159 = torch.ops.aten.mul.Tensor(to_dtype_376, rsub_scalar_31);  to_dtype_376 = rsub_scalar_31 = None
        conj_physical_default_31 = torch.ops.aten.conj_physical.default(mul_tensor_159);  mul_tensor_159 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(to_dtype_375, conj_physical_default_31);  to_dtype_375 = conj_physical_default_31 = None
        to_dtype_377 = torch.ops.aten.to.dtype(mul_tensor_160, torch.float32);  mul_tensor_160 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(to_dtype_377, view_default_2, primals_64, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_377 = view_default_2 = primals_64 = None
        getitem_989 = convolution_backward_default_127[0]
        getitem_990 = convolution_backward_default_127[1];  convolution_backward_default_127 = None
        view_default_132 = torch.ops.aten.view.default(getitem_989, [128, 256]);  getitem_989 = None
        unsqueeze_default_62 = torch.ops.aten.unsqueeze.default(view_default_132, 2);  view_default_132 = None
        unsqueeze_default_63 = torch.ops.aten.unsqueeze.default(unsqueeze_default_62, 3);  unsqueeze_default_62 = None
        expand_default_65 = torch.ops.aten.expand.default(unsqueeze_default_63, [128, 256, 56, 56]);  unsqueeze_default_63 = None
        div_scalar_32 = torch.ops.aten.div.Scalar(expand_default_65, 3136);  expand_default_65 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(mul_tensor_158, div_scalar_32);  mul_tensor_158 = div_scalar_32 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_62, convolution_default_10, primals_60, primals_58, primals_59, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  add_tensor_62 = convolution_default_10 = primals_60 = primals_58 = primals_59 = getitem_30 = getitem_31 = None
        getitem_992 = native_batch_norm_backward_default_96[0]
        getitem_993 = native_batch_norm_backward_default_96[1]
        getitem_994 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_992, relu__default_7, primals_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_992 = primals_63 = None
        getitem_995 = convolution_backward_default_128[0]
        getitem_996 = convolution_backward_default_128[1];  convolution_backward_default_128 = None
        to_dtype_378 = torch.ops.aten.to.dtype(getitem_995, torch.float32);  getitem_995 = None
        to_dtype_379 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_379, 0);  to_dtype_379 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_378, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_200, to_dtype_378);  le_scalar_94 = new_zeros_default_200 = to_dtype_378 = None
        to_dtype_380 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_380, convolution_default_9, primals_55, primals_53, primals_54, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_380 = convolution_default_9 = primals_55 = primals_53 = primals_54 = getitem_27 = getitem_28 = None
        getitem_998 = native_batch_norm_backward_default_97[0]
        getitem_999 = native_batch_norm_backward_default_97[1]
        getitem_1000 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_998, relu__default_6, primals_62, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_998 = primals_62 = None
        getitem_1001 = convolution_backward_default_129[0]
        getitem_1002 = convolution_backward_default_129[1];  convolution_backward_default_129 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_1001, torch.float32);  getitem_1001 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_201, to_dtype_381);  le_scalar_95 = new_zeros_default_201 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_383, convolution_default_8, primals_50, primals_48, primals_49, getitem_24, getitem_25, True, 1e-05, [True, True, True]);  to_dtype_383 = convolution_default_8 = primals_50 = primals_48 = primals_49 = getitem_24 = getitem_25 = None
        getitem_1004 = native_batch_norm_backward_default_98[0]
        getitem_1005 = native_batch_norm_backward_default_98[1]
        getitem_1006 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1004, relu__default_5, primals_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1004 = primals_61 = None
        getitem_1007 = convolution_backward_default_130[0]
        getitem_1008 = convolution_backward_default_130[1];  convolution_backward_default_130 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(to_dtype_374, getitem_1007);  to_dtype_374 = getitem_1007 = None
        to_dtype_384 = torch.ops.aten.to.dtype(add_tensor_63, torch.float32);  add_tensor_63 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_202, to_dtype_384);  le_scalar_96 = new_zeros_default_202 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_7, primals_44, primals_42, primals_43, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  convolution_default_7 = primals_44 = primals_42 = primals_43 = getitem_21 = getitem_22 = None
        getitem_1010 = native_batch_norm_backward_default_99[0]
        getitem_1011 = native_batch_norm_backward_default_99[1]
        getitem_1012 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1010, getitem_9, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1010 = primals_39 = None
        getitem_1013 = convolution_backward_default_131[0]
        getitem_1014 = convolution_backward_default_131[1];  convolution_backward_default_131 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(to_dtype_386, getitem_17);  getitem_17 = None
        mul_tensor_162 = torch.ops.aten.mul.Tensor(to_dtype_386, expand_default);  to_dtype_386 = expand_default = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(mul_tensor_161, [2, 3], True);  mul_tensor_161 = None
        view_default_133 = torch.ops.aten.view.default(sum_dim_int_list_33, [128, 1, 256]);  sum_dim_int_list_33 = None
        to_dtype_387 = torch.ops.aten.to.dtype(view_default_133, torch.float32);  view_default_133 = None
        to_dtype_388 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_32 = torch.ops.aten.rsub.Scalar(to_dtype_388, 1)
        mul_tensor_163 = torch.ops.aten.mul.Tensor(to_dtype_388, rsub_scalar_32);  to_dtype_388 = rsub_scalar_32 = None
        conj_physical_default_32 = torch.ops.aten.conj_physical.default(mul_tensor_163);  mul_tensor_163 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(to_dtype_387, conj_physical_default_32);  to_dtype_387 = conj_physical_default_32 = None
        to_dtype_389 = torch.ops.aten.to.dtype(mul_tensor_164, torch.float32);  mul_tensor_164 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(to_dtype_389, view_default, primals_45, [0], [1], [2], [1], False, [0], 1, [True, True, False]);  to_dtype_389 = view_default = primals_45 = None
        getitem_1016 = convolution_backward_default_132[0]
        getitem_1017 = convolution_backward_default_132[1];  convolution_backward_default_132 = None
        view_default_134 = torch.ops.aten.view.default(getitem_1016, [128, 256]);  getitem_1016 = None
        unsqueeze_default_64 = torch.ops.aten.unsqueeze.default(view_default_134, 2);  view_default_134 = None
        unsqueeze_default_65 = torch.ops.aten.unsqueeze.default(unsqueeze_default_64, 3);  unsqueeze_default_64 = None
        expand_default_66 = torch.ops.aten.expand.default(unsqueeze_default_65, [128, 256, 56, 56]);  unsqueeze_default_65 = None
        div_scalar_33 = torch.ops.aten.div.Scalar(expand_default_66, 3136);  expand_default_66 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(mul_tensor_162, div_scalar_33);  mul_tensor_162 = div_scalar_33 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_64, convolution_default_5, primals_35, primals_33, primals_34, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  add_tensor_64 = convolution_default_5 = primals_35 = primals_33 = primals_34 = getitem_18 = getitem_19 = None
        getitem_1019 = native_batch_norm_backward_default_100[0]
        getitem_1020 = native_batch_norm_backward_default_100[1]
        getitem_1021 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1019, relu__default_4, primals_38, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1019 = primals_38 = None
        getitem_1022 = convolution_backward_default_133[0]
        getitem_1023 = convolution_backward_default_133[1];  convolution_backward_default_133 = None
        to_dtype_390 = torch.ops.aten.to.dtype(getitem_1022, torch.float32);  getitem_1022 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_203, to_dtype_390);  le_scalar_97 = new_zeros_default_203 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_392, convolution_default_4, primals_30, primals_28, primals_29, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  to_dtype_392 = convolution_default_4 = primals_30 = primals_28 = primals_29 = getitem_15 = getitem_16 = None
        getitem_1025 = native_batch_norm_backward_default_101[0]
        getitem_1026 = native_batch_norm_backward_default_101[1]
        getitem_1027 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1025, relu__default_3, primals_37, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1025 = primals_37 = None
        getitem_1028 = convolution_backward_default_134[0]
        getitem_1029 = convolution_backward_default_134[1];  convolution_backward_default_134 = None
        to_dtype_393 = torch.ops.aten.to.dtype(getitem_1028, torch.float32);  getitem_1028 = None
        to_dtype_394 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_394, 0);  to_dtype_394 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_393, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_204, to_dtype_393);  le_scalar_98 = new_zeros_default_204 = to_dtype_393 = None
        to_dtype_395 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_395, convolution_default_3, primals_25, primals_23, primals_24, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  to_dtype_395 = convolution_default_3 = primals_25 = primals_23 = primals_24 = getitem_12 = getitem_13 = None
        getitem_1031 = native_batch_norm_backward_default_102[0]
        getitem_1032 = native_batch_norm_backward_default_102[1]
        getitem_1033 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1031, getitem_9, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1031 = getitem_9 = primals_36 = None
        getitem_1034 = convolution_backward_default_135[0]
        getitem_1035 = convolution_backward_default_135[1];  convolution_backward_default_135 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_1013, getitem_1034);  getitem_1013 = getitem_1034 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_65, relu__default_2, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_10);  add_tensor_65 = getitem_10 = None
        to_dtype_396 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_205, to_dtype_396);  le_scalar_99 = new_zeros_default_205 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_398, convolution_default_2, primals_5, primals_3, primals_4, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_398 = convolution_default_2 = primals_5 = primals_3 = primals_4 = getitem_7 = getitem_8 = None
        getitem_1037 = native_batch_norm_backward_default_103[0]
        getitem_1038 = native_batch_norm_backward_default_103[1]
        getitem_1039 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1037, relu__default_1, primals_18, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1037 = primals_18 = None
        getitem_1040 = convolution_backward_default_136[0]
        getitem_1041 = convolution_backward_default_136[1];  convolution_backward_default_136 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_1040, torch.float32);  getitem_1040 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_206, to_dtype_399);  le_scalar_100 = new_zeros_default_206 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_1, primals_17, primals_15, primals_16, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_401 = convolution_default_1 = primals_17 = primals_15 = primals_16 = getitem_4 = getitem_5 = None
        getitem_1043 = native_batch_norm_backward_default_104[0]
        getitem_1044 = native_batch_norm_backward_default_104[1]
        getitem_1045 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1043, relu__default, primals_12, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1043 = primals_12 = None
        getitem_1046 = convolution_backward_default_137[0]
        getitem_1047 = convolution_backward_default_137[1];  convolution_backward_default_137 = None
        to_dtype_402 = torch.ops.aten.to.dtype(getitem_1046, torch.float32);  getitem_1046 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_207, to_dtype_402);  le_scalar_101 = new_zeros_default_207 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_404, convolution_default, primals_11, primals_9, primals_10, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_404 = convolution_default = primals_11 = primals_9 = primals_10 = getitem_1 = getitem_2 = None
        getitem_1049 = native_batch_norm_backward_default_105[0]
        getitem_1050 = native_batch_norm_backward_default_105[1]
        getitem_1051 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1049, primals_672, primals_6, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1049 = primals_672 = primals_6 = None
        getitem_1053 = convolution_backward_default_138[1];  convolution_backward_default_138 = None
        return [getitem_1039, None, None, None, getitem_1038, getitem_1053, getitem_1051, None, None, None, getitem_1050, getitem_1047, getitem_1045, None, None, None, getitem_1044, getitem_1041, view_default_67, t_default_4, getitem_1033, None, None, None, getitem_1032, getitem_1027, None, None, None, getitem_1026, getitem_1021, None, None, None, getitem_1020, getitem_1035, getitem_1029, getitem_1023, getitem_1014, getitem_1012, None, None, None, getitem_1011, getitem_1017, getitem_1006, None, None, None, getitem_1005, getitem_1000, None, None, None, getitem_999, getitem_994, None, None, None, getitem_993, getitem_1008, getitem_1002, getitem_996, getitem_990, getitem_985, None, None, None, getitem_984, getitem_979, None, None, None, getitem_978, getitem_973, None, None, None, getitem_972, getitem_987, getitem_981, getitem_975, getitem_969, getitem_964, None, None, None, getitem_963, getitem_958, None, None, None, getitem_957, getitem_952, None, None, None, getitem_951, getitem_966, getitem_960, getitem_954, getitem_945, getitem_943, None, None, None, getitem_942, getitem_948, getitem_937, None, None, None, getitem_936, getitem_931, None, None, None, getitem_930, getitem_925, None, None, None, getitem_924, getitem_939, getitem_933, getitem_927, getitem_921, getitem_916, None, None, None, getitem_915, getitem_910, None, None, None, getitem_909, getitem_904, None, None, None, getitem_903, getitem_918, getitem_912, getitem_906, getitem_900, getitem_895, None, None, None, getitem_894, getitem_889, None, None, None, getitem_888, getitem_883, None, None, None, getitem_882, getitem_897, getitem_891, getitem_885, getitem_879, getitem_874, None, None, None, getitem_873, getitem_868, None, None, None, getitem_867, getitem_862, None, None, None, getitem_861, getitem_876, getitem_870, getitem_864, getitem_855, getitem_853, None, None, None, getitem_852, getitem_858, getitem_658, None, None, None, getitem_657, getitem_652, None, None, None, getitem_651, getitem_646, None, None, None, getitem_645, getitem_660, getitem_654, getitem_648, getitem_642, getitem_637, None, None, None, getitem_636, getitem_631, None, None, None, getitem_630, getitem_625, None, None, None, getitem_624, getitem_639, getitem_633, getitem_627, getitem_621, getitem_616, None, None, None, getitem_615, getitem_610, None, None, None, getitem_609, getitem_604, None, None, None, getitem_603, getitem_618, getitem_612, getitem_606, getitem_600, getitem_595, None, None, None, getitem_594, getitem_589, None, None, None, getitem_588, getitem_583, None, None, None, getitem_582, getitem_597, getitem_591, getitem_585, getitem_579, getitem_574, None, None, None, getitem_573, getitem_568, None, None, None, getitem_567, getitem_562, None, None, None, getitem_561, getitem_576, getitem_570, getitem_564, getitem_558, getitem_553, None, None, None, getitem_552, getitem_547, None, None, None, getitem_546, getitem_541, None, None, None, getitem_540, getitem_555, getitem_549, getitem_543, getitem_537, getitem_532, None, None, None, getitem_531, getitem_526, None, None, None, getitem_525, getitem_520, None, None, None, getitem_519, getitem_534, getitem_528, getitem_522, getitem_516, getitem_511, None, None, None, getitem_510, getitem_505, None, None, None, getitem_504, getitem_499, None, None, None, getitem_498, getitem_513, getitem_507, getitem_501, getitem_495, getitem_490, None, None, None, getitem_489, getitem_484, None, None, None, getitem_483, getitem_478, None, None, None, getitem_477, getitem_492, getitem_486, getitem_480, getitem_474, getitem_469, None, None, None, getitem_468, getitem_463, None, None, None, getitem_462, getitem_457, None, None, None, getitem_456, getitem_471, getitem_465, getitem_459, getitem_453, getitem_847, None, None, None, getitem_846, getitem_841, None, None, None, getitem_840, getitem_835, None, None, None, getitem_834, getitem_849, getitem_843, getitem_837, getitem_831, getitem_448, None, None, None, getitem_447, getitem_442, None, None, None, getitem_441, getitem_436, None, None, None, getitem_435, getitem_450, getitem_444, getitem_438, getitem_432, getitem_427, None, None, None, getitem_426, getitem_421, None, None, None, getitem_420, getitem_415, None, None, None, getitem_414, getitem_429, getitem_423, getitem_417, getitem_411, getitem_406, None, None, None, getitem_405, getitem_400, None, None, None, getitem_399, getitem_394, None, None, None, getitem_393, getitem_408, getitem_402, getitem_396, getitem_390, getitem_826, None, None, None, getitem_825, getitem_820, None, None, None, getitem_819, getitem_814, None, None, None, getitem_813, getitem_828, getitem_822, getitem_816, getitem_810, getitem_805, None, None, None, getitem_804, getitem_799, None, None, None, getitem_798, getitem_793, None, None, None, getitem_792, getitem_807, getitem_801, getitem_795, getitem_789, getitem_784, None, None, None, getitem_783, getitem_778, None, None, None, getitem_777, getitem_772, None, None, None, getitem_771, getitem_786, getitem_780, getitem_774, getitem_768, getitem_763, None, None, None, getitem_762, getitem_757, None, None, None, getitem_756, getitem_751, None, None, None, getitem_750, getitem_765, getitem_759, getitem_753, getitem_747, getitem_742, None, None, None, getitem_741, getitem_736, None, None, None, getitem_735, getitem_730, None, None, None, getitem_729, getitem_744, getitem_738, getitem_732, getitem_726, getitem_721, None, None, None, getitem_720, getitem_715, None, None, None, getitem_714, getitem_709, None, None, None, getitem_708, getitem_723, getitem_717, getitem_711, getitem_705, getitem_700, None, None, None, getitem_699, getitem_694, None, None, None, getitem_693, getitem_688, None, None, None, getitem_687, getitem_702, getitem_696, getitem_690, getitem_684, getitem_679, None, None, None, getitem_678, getitem_673, None, None, None, getitem_672, getitem_667, None, None, None, getitem_666, getitem_681, getitem_675, getitem_669, getitem_663, getitem_385, None, None, None, getitem_384, getitem_379, None, None, None, getitem_378, getitem_373, None, None, None, getitem_372, getitem_387, getitem_381, getitem_375, getitem_366, getitem_364, None, None, None, getitem_363, getitem_369, getitem_358, None, None, None, getitem_357, getitem_352, None, None, None, getitem_351, getitem_346, None, None, None, getitem_345, getitem_360, getitem_354, getitem_348, getitem_342, getitem_337, None, None, None, getitem_336, getitem_331, None, None, None, getitem_330, getitem_325, None, None, None, getitem_324, getitem_339, getitem_333, getitem_327, getitem_321, None]
        
