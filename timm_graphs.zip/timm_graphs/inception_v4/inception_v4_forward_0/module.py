
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/inception_v4/inception_v4_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897):
        convolution_default = torch.ops.aten.convolution.default(primals_897, primals_6, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 0.001);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_552, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_551, primals_547, primals_549, primals_550, True, 0.1, 0.001);  primals_547 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_678, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_677, primals_673, primals_675, primals_676, True, 0.1, 0.001);  primals_673 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_684, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_683, primals_679, primals_681, primals_682, True, 0.1, 0.001);  primals_679 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        cat_default = torch.ops.aten.cat.default([getitem_9, relu__default_3], 1);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(cat_default, primals_690, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_689, primals_685, primals_687, primals_688, True, 0.1, 0.001);  primals_685 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_696, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_695, primals_691, primals_693, primals_694, True, 0.1, 0.001);  primals_691 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_6 = torch.ops.aten.convolution.default(cat_default, primals_702, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_701, primals_697, primals_699, primals_700, True, 0.1, 0.001);  primals_697 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_708, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_707, primals_703, primals_705, primals_706, True, 0.1, 0.001);  primals_703 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_7, primals_714, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_713, primals_709, primals_711, primals_712, True, 0.1, 0.001);  primals_709 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_720, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_719, primals_715, primals_717, primals_718, True, 0.1, 0.001);  primals_715 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_5, relu__default_9], 1)
        convolution_default_10 = torch.ops.aten.convolution.default(cat_default_1, primals_726, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_725, primals_721, primals_723, primals_724, True, 0.1, 0.001);  primals_721 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_1, [3, 3], [2, 2])
        getitem_35 = max_pool2d_with_indices_default_1[0]
        getitem_36 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_10, getitem_35], 1);  getitem_35 = None
        convolution_default_11 = torch.ops.aten.convolution.default(cat_default_2, primals_732, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_731, primals_727, primals_729, primals_730, True, 0.1, 0.001);  primals_727 = None
        getitem_37 = native_batch_norm_default_11[0]
        getitem_38 = native_batch_norm_default_11[1]
        getitem_39 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_37);  getitem_37 = None
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default_2, primals_738, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_737, primals_733, primals_735, primals_736, True, 0.1, 0.001);  primals_733 = None
        getitem_40 = native_batch_norm_default_12[0]
        getitem_41 = native_batch_norm_default_12[1]
        getitem_42 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_40);  getitem_40 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_12, primals_744, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_743, primals_739, primals_741, primals_742, True, 0.1, 0.001);  primals_739 = None
        getitem_43 = native_batch_norm_default_13[0]
        getitem_44 = native_batch_norm_default_13[1]
        getitem_45 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_43);  getitem_43 = None
        convolution_default_14 = torch.ops.aten.convolution.default(cat_default_2, primals_750, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_749, primals_745, primals_747, primals_748, True, 0.1, 0.001);  primals_745 = None
        getitem_46 = native_batch_norm_default_14[0]
        getitem_47 = native_batch_norm_default_14[1]
        getitem_48 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_46);  getitem_46 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_14, primals_756, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_755, primals_751, primals_753, primals_754, True, 0.1, 0.001);  primals_751 = None
        getitem_49 = native_batch_norm_default_15[0]
        getitem_50 = native_batch_norm_default_15[1]
        getitem_51 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_49);  getitem_49 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_15, primals_762, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_761, primals_757, primals_759, primals_760, True, 0.1, 0.001);  primals_757 = None
        getitem_52 = native_batch_norm_default_16[0]
        getitem_53 = native_batch_norm_default_16[1]
        getitem_54 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(cat_default_2, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_17 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_768, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_767, primals_763, primals_765, primals_766, True, 0.1, 0.001);  primals_763 = None
        getitem_55 = native_batch_norm_default_17[0]
        getitem_56 = native_batch_norm_default_17[1]
        getitem_57 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_11, relu__default_13, relu__default_16, relu__default_17], 1)
        convolution_default_18 = torch.ops.aten.convolution.default(cat_default_3, primals_774, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_773, primals_769, primals_771, primals_772, True, 0.1, 0.001);  primals_769 = None
        getitem_58 = native_batch_norm_default_18[0]
        getitem_59 = native_batch_norm_default_18[1]
        getitem_60 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_58);  getitem_58 = None
        convolution_default_19 = torch.ops.aten.convolution.default(cat_default_3, primals_780, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_779, primals_775, primals_777, primals_778, True, 0.1, 0.001);  primals_775 = None
        getitem_61 = native_batch_norm_default_19[0]
        getitem_62 = native_batch_norm_default_19[1]
        getitem_63 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_61);  getitem_61 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_19, primals_786, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_785, primals_781, primals_783, primals_784, True, 0.1, 0.001);  primals_781 = None
        getitem_64 = native_batch_norm_default_20[0]
        getitem_65 = native_batch_norm_default_20[1]
        getitem_66 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_64);  getitem_64 = None
        convolution_default_21 = torch.ops.aten.convolution.default(cat_default_3, primals_792, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_791, primals_787, primals_789, primals_790, True, 0.1, 0.001);  primals_787 = None
        getitem_67 = native_batch_norm_default_21[0]
        getitem_68 = native_batch_norm_default_21[1]
        getitem_69 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_67);  getitem_67 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_21, primals_798, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_797, primals_793, primals_795, primals_796, True, 0.1, 0.001);  primals_793 = None
        getitem_70 = native_batch_norm_default_22[0]
        getitem_71 = native_batch_norm_default_22[1]
        getitem_72 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_70);  getitem_70 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_22, primals_804, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_803, primals_799, primals_801, primals_802, True, 0.1, 0.001);  primals_799 = None
        getitem_73 = native_batch_norm_default_23[0]
        getitem_74 = native_batch_norm_default_23[1]
        getitem_75 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_73);  getitem_73 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(cat_default_3, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_24 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_810, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_809, primals_805, primals_807, primals_808, True, 0.1, 0.001);  primals_805 = None
        getitem_76 = native_batch_norm_default_24[0]
        getitem_77 = native_batch_norm_default_24[1]
        getitem_78 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_76);  getitem_76 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_18, relu__default_20, relu__default_23, relu__default_24], 1)
        convolution_default_25 = torch.ops.aten.convolution.default(cat_default_4, primals_816, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_815, primals_811, primals_813, primals_814, True, 0.1, 0.001);  primals_811 = None
        getitem_79 = native_batch_norm_default_25[0]
        getitem_80 = native_batch_norm_default_25[1]
        getitem_81 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_79);  getitem_79 = None
        convolution_default_26 = torch.ops.aten.convolution.default(cat_default_4, primals_822, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_821, primals_817, primals_819, primals_820, True, 0.1, 0.001);  primals_817 = None
        getitem_82 = native_batch_norm_default_26[0]
        getitem_83 = native_batch_norm_default_26[1]
        getitem_84 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_82);  getitem_82 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_26, primals_828, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_827, primals_823, primals_825, primals_826, True, 0.1, 0.001);  primals_823 = None
        getitem_85 = native_batch_norm_default_27[0]
        getitem_86 = native_batch_norm_default_27[1]
        getitem_87 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_85);  getitem_85 = None
        convolution_default_28 = torch.ops.aten.convolution.default(cat_default_4, primals_834, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_833, primals_829, primals_831, primals_832, True, 0.1, 0.001);  primals_829 = None
        getitem_88 = native_batch_norm_default_28[0]
        getitem_89 = native_batch_norm_default_28[1]
        getitem_90 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_88);  getitem_88 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_28, primals_840, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_839, primals_835, primals_837, primals_838, True, 0.1, 0.001);  primals_835 = None
        getitem_91 = native_batch_norm_default_29[0]
        getitem_92 = native_batch_norm_default_29[1]
        getitem_93 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_91);  getitem_91 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_29, primals_846, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_845, primals_841, primals_843, primals_844, True, 0.1, 0.001);  primals_841 = None
        getitem_94 = native_batch_norm_default_30[0]
        getitem_95 = native_batch_norm_default_30[1]
        getitem_96 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_94);  getitem_94 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(cat_default_4, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_31 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_852, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_851, primals_847, primals_849, primals_850, True, 0.1, 0.001);  primals_847 = None
        getitem_97 = native_batch_norm_default_31[0]
        getitem_98 = native_batch_norm_default_31[1]
        getitem_99 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_97);  getitem_97 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_25, relu__default_27, relu__default_30, relu__default_31], 1)
        convolution_default_32 = torch.ops.aten.convolution.default(cat_default_5, primals_858, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_857, primals_853, primals_855, primals_856, True, 0.1, 0.001);  primals_853 = None
        getitem_100 = native_batch_norm_default_32[0]
        getitem_101 = native_batch_norm_default_32[1]
        getitem_102 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_100);  getitem_100 = None
        convolution_default_33 = torch.ops.aten.convolution.default(cat_default_5, primals_864, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_863, primals_859, primals_861, primals_862, True, 0.1, 0.001);  primals_859 = None
        getitem_103 = native_batch_norm_default_33[0]
        getitem_104 = native_batch_norm_default_33[1]
        getitem_105 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_103);  getitem_103 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_33, primals_870, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_869, primals_865, primals_867, primals_868, True, 0.1, 0.001);  primals_865 = None
        getitem_106 = native_batch_norm_default_34[0]
        getitem_107 = native_batch_norm_default_34[1]
        getitem_108 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_106);  getitem_106 = None
        convolution_default_35 = torch.ops.aten.convolution.default(cat_default_5, primals_876, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_875, primals_871, primals_873, primals_874, True, 0.1, 0.001);  primals_871 = None
        getitem_109 = native_batch_norm_default_35[0]
        getitem_110 = native_batch_norm_default_35[1]
        getitem_111 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_109);  getitem_109 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_35, primals_882, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_881, primals_877, primals_879, primals_880, True, 0.1, 0.001);  primals_877 = None
        getitem_112 = native_batch_norm_default_36[0]
        getitem_113 = native_batch_norm_default_36[1]
        getitem_114 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_112);  getitem_112 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_36, primals_888, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_887, primals_883, primals_885, primals_886, True, 0.1, 0.001);  primals_883 = None
        getitem_115 = native_batch_norm_default_37[0]
        getitem_116 = native_batch_norm_default_37[1]
        getitem_117 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_115);  getitem_115 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(cat_default_5, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_38 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_894, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_893, primals_889, primals_891, primals_892, True, 0.1, 0.001);  primals_889 = None
        getitem_118 = native_batch_norm_default_38[0]
        getitem_119 = native_batch_norm_default_38[1]
        getitem_120 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_118);  getitem_118 = None
        cat_default_6 = torch.ops.aten.cat.default([relu__default_32, relu__default_34, relu__default_37, relu__default_38], 1)
        convolution_default_39 = torch.ops.aten.convolution.default(cat_default_6, primals_12, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_11, primals_7, primals_9, primals_10, True, 0.1, 0.001);  primals_7 = None
        getitem_121 = native_batch_norm_default_39[0]
        getitem_122 = native_batch_norm_default_39[1]
        getitem_123 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_121);  getitem_121 = None
        convolution_default_40 = torch.ops.aten.convolution.default(cat_default_6, primals_18, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_17, primals_13, primals_15, primals_16, True, 0.1, 0.001);  primals_13 = None
        getitem_124 = native_batch_norm_default_40[0]
        getitem_125 = native_batch_norm_default_40[1]
        getitem_126 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_124);  getitem_124 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_40, primals_24, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_23, primals_19, primals_21, primals_22, True, 0.1, 0.001);  primals_19 = None
        getitem_127 = native_batch_norm_default_41[0]
        getitem_128 = native_batch_norm_default_41[1]
        getitem_129 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_127);  getitem_127 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_41, primals_30, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_29, primals_25, primals_27, primals_28, True, 0.1, 0.001);  primals_25 = None
        getitem_130 = native_batch_norm_default_42[0]
        getitem_131 = native_batch_norm_default_42[1]
        getitem_132 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_130);  getitem_130 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_6, [3, 3], [2, 2])
        getitem_133 = max_pool2d_with_indices_default_2[0]
        getitem_134 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        cat_default_7 = torch.ops.aten.cat.default([relu__default_39, relu__default_42, getitem_133], 1);  getitem_133 = None
        convolution_default_43 = torch.ops.aten.convolution.default(cat_default_7, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_35, primals_31, primals_33, primals_34, True, 0.1, 0.001);  primals_31 = None
        getitem_135 = native_batch_norm_default_43[0]
        getitem_136 = native_batch_norm_default_43[1]
        getitem_137 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        convolution_default_44 = torch.ops.aten.convolution.default(cat_default_7, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_41, primals_37, primals_39, primals_40, True, 0.1, 0.001);  primals_37 = None
        getitem_138 = native_batch_norm_default_44[0]
        getitem_139 = native_batch_norm_default_44[1]
        getitem_140 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_44, primals_48, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_47, primals_43, primals_45, primals_46, True, 0.1, 0.001);  primals_43 = None
        getitem_141 = native_batch_norm_default_45[0]
        getitem_142 = native_batch_norm_default_45[1]
        getitem_143 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_141);  getitem_141 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_45, primals_54, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_53, primals_49, primals_51, primals_52, True, 0.1, 0.001);  primals_49 = None
        getitem_144 = native_batch_norm_default_46[0]
        getitem_145 = native_batch_norm_default_46[1]
        getitem_146 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_47 = torch.ops.aten.convolution.default(cat_default_7, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_59, primals_55, primals_57, primals_58, True, 0.1, 0.001);  primals_55 = None
        getitem_147 = native_batch_norm_default_47[0]
        getitem_148 = native_batch_norm_default_47[1]
        getitem_149 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_147);  getitem_147 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_47, primals_66, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_65, primals_61, primals_63, primals_64, True, 0.1, 0.001);  primals_61 = None
        getitem_150 = native_batch_norm_default_48[0]
        getitem_151 = native_batch_norm_default_48[1]
        getitem_152 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_48, primals_72, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_71, primals_67, primals_69, primals_70, True, 0.1, 0.001);  primals_67 = None
        getitem_153 = native_batch_norm_default_49[0]
        getitem_154 = native_batch_norm_default_49[1]
        getitem_155 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_153);  getitem_153 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_49, primals_78, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_77, primals_73, primals_75, primals_76, True, 0.1, 0.001);  primals_73 = None
        getitem_156 = native_batch_norm_default_50[0]
        getitem_157 = native_batch_norm_default_50[1]
        getitem_158 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_50, primals_84, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_83, primals_79, primals_81, primals_82, True, 0.1, 0.001);  primals_79 = None
        getitem_159 = native_batch_norm_default_51[0]
        getitem_160 = native_batch_norm_default_51[1]
        getitem_161 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_159);  getitem_159 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(cat_default_7, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_52 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_90, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_89, primals_85, primals_87, primals_88, True, 0.1, 0.001);  primals_85 = None
        getitem_162 = native_batch_norm_default_52[0]
        getitem_163 = native_batch_norm_default_52[1]
        getitem_164 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        cat_default_8 = torch.ops.aten.cat.default([relu__default_43, relu__default_46, relu__default_51, relu__default_52], 1)
        convolution_default_53 = torch.ops.aten.convolution.default(cat_default_8, primals_96, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_95, primals_91, primals_93, primals_94, True, 0.1, 0.001);  primals_91 = None
        getitem_165 = native_batch_norm_default_53[0]
        getitem_166 = native_batch_norm_default_53[1]
        getitem_167 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_165);  getitem_165 = None
        convolution_default_54 = torch.ops.aten.convolution.default(cat_default_8, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_101, primals_97, primals_99, primals_100, True, 0.1, 0.001);  primals_97 = None
        getitem_168 = native_batch_norm_default_54[0]
        getitem_169 = native_batch_norm_default_54[1]
        getitem_170 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_54, primals_108, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_107, primals_103, primals_105, primals_106, True, 0.1, 0.001);  primals_103 = None
        getitem_171 = native_batch_norm_default_55[0]
        getitem_172 = native_batch_norm_default_55[1]
        getitem_173 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_171);  getitem_171 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_55, primals_114, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_113, primals_109, primals_111, primals_112, True, 0.1, 0.001);  primals_109 = None
        getitem_174 = native_batch_norm_default_56[0]
        getitem_175 = native_batch_norm_default_56[1]
        getitem_176 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_57 = torch.ops.aten.convolution.default(cat_default_8, primals_120, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_119, primals_115, primals_117, primals_118, True, 0.1, 0.001);  primals_115 = None
        getitem_177 = native_batch_norm_default_57[0]
        getitem_178 = native_batch_norm_default_57[1]
        getitem_179 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_177);  getitem_177 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_57, primals_126, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_125, primals_121, primals_123, primals_124, True, 0.1, 0.001);  primals_121 = None
        getitem_180 = native_batch_norm_default_58[0]
        getitem_181 = native_batch_norm_default_58[1]
        getitem_182 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_180);  getitem_180 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_58, primals_132, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_131, primals_127, primals_129, primals_130, True, 0.1, 0.001);  primals_127 = None
        getitem_183 = native_batch_norm_default_59[0]
        getitem_184 = native_batch_norm_default_59[1]
        getitem_185 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_183);  getitem_183 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_59, primals_138, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_137, primals_133, primals_135, primals_136, True, 0.1, 0.001);  primals_133 = None
        getitem_186 = native_batch_norm_default_60[0]
        getitem_187 = native_batch_norm_default_60[1]
        getitem_188 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_186);  getitem_186 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_60, primals_144, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_143, primals_139, primals_141, primals_142, True, 0.1, 0.001);  primals_139 = None
        getitem_189 = native_batch_norm_default_61[0]
        getitem_190 = native_batch_norm_default_61[1]
        getitem_191 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_189);  getitem_189 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(cat_default_8, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_62 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_150, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_149, primals_145, primals_147, primals_148, True, 0.1, 0.001);  primals_145 = None
        getitem_192 = native_batch_norm_default_62[0]
        getitem_193 = native_batch_norm_default_62[1]
        getitem_194 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_192);  getitem_192 = None
        cat_default_9 = torch.ops.aten.cat.default([relu__default_53, relu__default_56, relu__default_61, relu__default_62], 1)
        convolution_default_63 = torch.ops.aten.convolution.default(cat_default_9, primals_156, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_155, primals_151, primals_153, primals_154, True, 0.1, 0.001);  primals_151 = None
        getitem_195 = native_batch_norm_default_63[0]
        getitem_196 = native_batch_norm_default_63[1]
        getitem_197 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_195);  getitem_195 = None
        convolution_default_64 = torch.ops.aten.convolution.default(cat_default_9, primals_162, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_161, primals_157, primals_159, primals_160, True, 0.1, 0.001);  primals_157 = None
        getitem_198 = native_batch_norm_default_64[0]
        getitem_199 = native_batch_norm_default_64[1]
        getitem_200 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_198);  getitem_198 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_64, primals_168, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_167, primals_163, primals_165, primals_166, True, 0.1, 0.001);  primals_163 = None
        getitem_201 = native_batch_norm_default_65[0]
        getitem_202 = native_batch_norm_default_65[1]
        getitem_203 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_201);  getitem_201 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_65, primals_174, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_173, primals_169, primals_171, primals_172, True, 0.1, 0.001);  primals_169 = None
        getitem_204 = native_batch_norm_default_66[0]
        getitem_205 = native_batch_norm_default_66[1]
        getitem_206 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_204);  getitem_204 = None
        convolution_default_67 = torch.ops.aten.convolution.default(cat_default_9, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_179, primals_175, primals_177, primals_178, True, 0.1, 0.001);  primals_175 = None
        getitem_207 = native_batch_norm_default_67[0]
        getitem_208 = native_batch_norm_default_67[1]
        getitem_209 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_207);  getitem_207 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_67, primals_186, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_185, primals_181, primals_183, primals_184, True, 0.1, 0.001);  primals_181 = None
        getitem_210 = native_batch_norm_default_68[0]
        getitem_211 = native_batch_norm_default_68[1]
        getitem_212 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_210);  getitem_210 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_68, primals_192, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_191, primals_187, primals_189, primals_190, True, 0.1, 0.001);  primals_187 = None
        getitem_213 = native_batch_norm_default_69[0]
        getitem_214 = native_batch_norm_default_69[1]
        getitem_215 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_213);  getitem_213 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_69, primals_198, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_197, primals_193, primals_195, primals_196, True, 0.1, 0.001);  primals_193 = None
        getitem_216 = native_batch_norm_default_70[0]
        getitem_217 = native_batch_norm_default_70[1]
        getitem_218 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_216);  getitem_216 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_70, primals_204, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_203, primals_199, primals_201, primals_202, True, 0.1, 0.001);  primals_199 = None
        getitem_219 = native_batch_norm_default_71[0]
        getitem_220 = native_batch_norm_default_71[1]
        getitem_221 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_219);  getitem_219 = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(cat_default_9, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_72 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_210, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_209, primals_205, primals_207, primals_208, True, 0.1, 0.001);  primals_205 = None
        getitem_222 = native_batch_norm_default_72[0]
        getitem_223 = native_batch_norm_default_72[1]
        getitem_224 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_222);  getitem_222 = None
        cat_default_10 = torch.ops.aten.cat.default([relu__default_63, relu__default_66, relu__default_71, relu__default_72], 1)
        convolution_default_73 = torch.ops.aten.convolution.default(cat_default_10, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_215, primals_211, primals_213, primals_214, True, 0.1, 0.001);  primals_211 = None
        getitem_225 = native_batch_norm_default_73[0]
        getitem_226 = native_batch_norm_default_73[1]
        getitem_227 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_225);  getitem_225 = None
        convolution_default_74 = torch.ops.aten.convolution.default(cat_default_10, primals_222, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_221, primals_217, primals_219, primals_220, True, 0.1, 0.001);  primals_217 = None
        getitem_228 = native_batch_norm_default_74[0]
        getitem_229 = native_batch_norm_default_74[1]
        getitem_230 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_228);  getitem_228 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_74, primals_228, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_227, primals_223, primals_225, primals_226, True, 0.1, 0.001);  primals_223 = None
        getitem_231 = native_batch_norm_default_75[0]
        getitem_232 = native_batch_norm_default_75[1]
        getitem_233 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_231);  getitem_231 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_75, primals_234, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_233, primals_229, primals_231, primals_232, True, 0.1, 0.001);  primals_229 = None
        getitem_234 = native_batch_norm_default_76[0]
        getitem_235 = native_batch_norm_default_76[1]
        getitem_236 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_234);  getitem_234 = None
        convolution_default_77 = torch.ops.aten.convolution.default(cat_default_10, primals_240, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_239, primals_235, primals_237, primals_238, True, 0.1, 0.001);  primals_235 = None
        getitem_237 = native_batch_norm_default_77[0]
        getitem_238 = native_batch_norm_default_77[1]
        getitem_239 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_237);  getitem_237 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_77, primals_246, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_245, primals_241, primals_243, primals_244, True, 0.1, 0.001);  primals_241 = None
        getitem_240 = native_batch_norm_default_78[0]
        getitem_241 = native_batch_norm_default_78[1]
        getitem_242 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_240);  getitem_240 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_78, primals_252, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_251, primals_247, primals_249, primals_250, True, 0.1, 0.001);  primals_247 = None
        getitem_243 = native_batch_norm_default_79[0]
        getitem_244 = native_batch_norm_default_79[1]
        getitem_245 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_243);  getitem_243 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_79, primals_258, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_257, primals_253, primals_255, primals_256, True, 0.1, 0.001);  primals_253 = None
        getitem_246 = native_batch_norm_default_80[0]
        getitem_247 = native_batch_norm_default_80[1]
        getitem_248 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_246);  getitem_246 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_80, primals_264, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_263, primals_259, primals_261, primals_262, True, 0.1, 0.001);  primals_259 = None
        getitem_249 = native_batch_norm_default_81[0]
        getitem_250 = native_batch_norm_default_81[1]
        getitem_251 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_249);  getitem_249 = None
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(cat_default_10, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_82 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_270, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_269, primals_265, primals_267, primals_268, True, 0.1, 0.001);  primals_265 = None
        getitem_252 = native_batch_norm_default_82[0]
        getitem_253 = native_batch_norm_default_82[1]
        getitem_254 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_252);  getitem_252 = None
        cat_default_11 = torch.ops.aten.cat.default([relu__default_73, relu__default_76, relu__default_81, relu__default_82], 1)
        convolution_default_83 = torch.ops.aten.convolution.default(cat_default_11, primals_276, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_275, primals_271, primals_273, primals_274, True, 0.1, 0.001);  primals_271 = None
        getitem_255 = native_batch_norm_default_83[0]
        getitem_256 = native_batch_norm_default_83[1]
        getitem_257 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_255);  getitem_255 = None
        convolution_default_84 = torch.ops.aten.convolution.default(cat_default_11, primals_282, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_281, primals_277, primals_279, primals_280, True, 0.1, 0.001);  primals_277 = None
        getitem_258 = native_batch_norm_default_84[0]
        getitem_259 = native_batch_norm_default_84[1]
        getitem_260 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_258);  getitem_258 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_84, primals_288, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_287, primals_283, primals_285, primals_286, True, 0.1, 0.001);  primals_283 = None
        getitem_261 = native_batch_norm_default_85[0]
        getitem_262 = native_batch_norm_default_85[1]
        getitem_263 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_261);  getitem_261 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_85, primals_294, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_293, primals_289, primals_291, primals_292, True, 0.1, 0.001);  primals_289 = None
        getitem_264 = native_batch_norm_default_86[0]
        getitem_265 = native_batch_norm_default_86[1]
        getitem_266 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_264);  getitem_264 = None
        convolution_default_87 = torch.ops.aten.convolution.default(cat_default_11, primals_300, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_299, primals_295, primals_297, primals_298, True, 0.1, 0.001);  primals_295 = None
        getitem_267 = native_batch_norm_default_87[0]
        getitem_268 = native_batch_norm_default_87[1]
        getitem_269 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_267);  getitem_267 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_87, primals_306, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_305, primals_301, primals_303, primals_304, True, 0.1, 0.001);  primals_301 = None
        getitem_270 = native_batch_norm_default_88[0]
        getitem_271 = native_batch_norm_default_88[1]
        getitem_272 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_270);  getitem_270 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_88, primals_312, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_311, primals_307, primals_309, primals_310, True, 0.1, 0.001);  primals_307 = None
        getitem_273 = native_batch_norm_default_89[0]
        getitem_274 = native_batch_norm_default_89[1]
        getitem_275 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_273);  getitem_273 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_89, primals_318, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_317, primals_313, primals_315, primals_316, True, 0.1, 0.001);  primals_313 = None
        getitem_276 = native_batch_norm_default_90[0]
        getitem_277 = native_batch_norm_default_90[1]
        getitem_278 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu__default_90 = torch.ops.aten.relu_.default(getitem_276);  getitem_276 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_90, primals_324, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_323, primals_319, primals_321, primals_322, True, 0.1, 0.001);  primals_319 = None
        getitem_279 = native_batch_norm_default_91[0]
        getitem_280 = native_batch_norm_default_91[1]
        getitem_281 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_279);  getitem_279 = None
        avg_pool2d_default_8 = torch.ops.aten.avg_pool2d.default(cat_default_11, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_92 = torch.ops.aten.convolution.default(avg_pool2d_default_8, primals_330, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_329, primals_325, primals_327, primals_328, True, 0.1, 0.001);  primals_325 = None
        getitem_282 = native_batch_norm_default_92[0]
        getitem_283 = native_batch_norm_default_92[1]
        getitem_284 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_282);  getitem_282 = None
        cat_default_12 = torch.ops.aten.cat.default([relu__default_83, relu__default_86, relu__default_91, relu__default_92], 1)
        convolution_default_93 = torch.ops.aten.convolution.default(cat_default_12, primals_336, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_335, primals_331, primals_333, primals_334, True, 0.1, 0.001);  primals_331 = None
        getitem_285 = native_batch_norm_default_93[0]
        getitem_286 = native_batch_norm_default_93[1]
        getitem_287 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_285);  getitem_285 = None
        convolution_default_94 = torch.ops.aten.convolution.default(cat_default_12, primals_342, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_341, primals_337, primals_339, primals_340, True, 0.1, 0.001);  primals_337 = None
        getitem_288 = native_batch_norm_default_94[0]
        getitem_289 = native_batch_norm_default_94[1]
        getitem_290 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_288);  getitem_288 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_94, primals_348, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_347, primals_343, primals_345, primals_346, True, 0.1, 0.001);  primals_343 = None
        getitem_291 = native_batch_norm_default_95[0]
        getitem_292 = native_batch_norm_default_95[1]
        getitem_293 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_291);  getitem_291 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_95, primals_354, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_353, primals_349, primals_351, primals_352, True, 0.1, 0.001);  primals_349 = None
        getitem_294 = native_batch_norm_default_96[0]
        getitem_295 = native_batch_norm_default_96[1]
        getitem_296 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_294);  getitem_294 = None
        convolution_default_97 = torch.ops.aten.convolution.default(cat_default_12, primals_360, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_359, primals_355, primals_357, primals_358, True, 0.1, 0.001);  primals_355 = None
        getitem_297 = native_batch_norm_default_97[0]
        getitem_298 = native_batch_norm_default_97[1]
        getitem_299 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_297);  getitem_297 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_97, primals_366, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_365, primals_361, primals_363, primals_364, True, 0.1, 0.001);  primals_361 = None
        getitem_300 = native_batch_norm_default_98[0]
        getitem_301 = native_batch_norm_default_98[1]
        getitem_302 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_300);  getitem_300 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_98, primals_372, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_371, primals_367, primals_369, primals_370, True, 0.1, 0.001);  primals_367 = None
        getitem_303 = native_batch_norm_default_99[0]
        getitem_304 = native_batch_norm_default_99[1]
        getitem_305 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_303);  getitem_303 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_99, primals_378, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_377, primals_373, primals_375, primals_376, True, 0.1, 0.001);  primals_373 = None
        getitem_306 = native_batch_norm_default_100[0]
        getitem_307 = native_batch_norm_default_100[1]
        getitem_308 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu__default_100 = torch.ops.aten.relu_.default(getitem_306);  getitem_306 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_100, primals_384, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_383, primals_379, primals_381, primals_382, True, 0.1, 0.001);  primals_379 = None
        getitem_309 = native_batch_norm_default_101[0]
        getitem_310 = native_batch_norm_default_101[1]
        getitem_311 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        relu__default_101 = torch.ops.aten.relu_.default(getitem_309);  getitem_309 = None
        avg_pool2d_default_9 = torch.ops.aten.avg_pool2d.default(cat_default_12, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_102 = torch.ops.aten.convolution.default(avg_pool2d_default_9, primals_390, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_389, primals_385, primals_387, primals_388, True, 0.1, 0.001);  primals_385 = None
        getitem_312 = native_batch_norm_default_102[0]
        getitem_313 = native_batch_norm_default_102[1]
        getitem_314 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_102 = torch.ops.aten.relu_.default(getitem_312);  getitem_312 = None
        cat_default_13 = torch.ops.aten.cat.default([relu__default_93, relu__default_96, relu__default_101, relu__default_102], 1)
        convolution_default_103 = torch.ops.aten.convolution.default(cat_default_13, primals_396, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_395, primals_391, primals_393, primals_394, True, 0.1, 0.001);  primals_391 = None
        getitem_315 = native_batch_norm_default_103[0]
        getitem_316 = native_batch_norm_default_103[1]
        getitem_317 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        relu__default_103 = torch.ops.aten.relu_.default(getitem_315);  getitem_315 = None
        convolution_default_104 = torch.ops.aten.convolution.default(cat_default_13, primals_402, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_401, primals_397, primals_399, primals_400, True, 0.1, 0.001);  primals_397 = None
        getitem_318 = native_batch_norm_default_104[0]
        getitem_319 = native_batch_norm_default_104[1]
        getitem_320 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu__default_104 = torch.ops.aten.relu_.default(getitem_318);  getitem_318 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_104, primals_408, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_407, primals_403, primals_405, primals_406, True, 0.1, 0.001);  primals_403 = None
        getitem_321 = native_batch_norm_default_105[0]
        getitem_322 = native_batch_norm_default_105[1]
        getitem_323 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        relu__default_105 = torch.ops.aten.relu_.default(getitem_321);  getitem_321 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_105, primals_414, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_413, primals_409, primals_411, primals_412, True, 0.1, 0.001);  primals_409 = None
        getitem_324 = native_batch_norm_default_106[0]
        getitem_325 = native_batch_norm_default_106[1]
        getitem_326 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu__default_106 = torch.ops.aten.relu_.default(getitem_324);  getitem_324 = None
        convolution_default_107 = torch.ops.aten.convolution.default(cat_default_13, primals_420, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_419, primals_415, primals_417, primals_418, True, 0.1, 0.001);  primals_415 = None
        getitem_327 = native_batch_norm_default_107[0]
        getitem_328 = native_batch_norm_default_107[1]
        getitem_329 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        relu__default_107 = torch.ops.aten.relu_.default(getitem_327);  getitem_327 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_107, primals_426, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_425, primals_421, primals_423, primals_424, True, 0.1, 0.001);  primals_421 = None
        getitem_330 = native_batch_norm_default_108[0]
        getitem_331 = native_batch_norm_default_108[1]
        getitem_332 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu__default_108 = torch.ops.aten.relu_.default(getitem_330);  getitem_330 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_108, primals_432, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_431, primals_427, primals_429, primals_430, True, 0.1, 0.001);  primals_427 = None
        getitem_333 = native_batch_norm_default_109[0]
        getitem_334 = native_batch_norm_default_109[1]
        getitem_335 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        relu__default_109 = torch.ops.aten.relu_.default(getitem_333);  getitem_333 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_109, primals_438, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_437, primals_433, primals_435, primals_436, True, 0.1, 0.001);  primals_433 = None
        getitem_336 = native_batch_norm_default_110[0]
        getitem_337 = native_batch_norm_default_110[1]
        getitem_338 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        relu__default_110 = torch.ops.aten.relu_.default(getitem_336);  getitem_336 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_110, primals_444, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_443, primals_439, primals_441, primals_442, True, 0.1, 0.001);  primals_439 = None
        getitem_339 = native_batch_norm_default_111[0]
        getitem_340 = native_batch_norm_default_111[1]
        getitem_341 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        relu__default_111 = torch.ops.aten.relu_.default(getitem_339);  getitem_339 = None
        avg_pool2d_default_10 = torch.ops.aten.avg_pool2d.default(cat_default_13, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_112 = torch.ops.aten.convolution.default(avg_pool2d_default_10, primals_450, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_449, primals_445, primals_447, primals_448, True, 0.1, 0.001);  primals_445 = None
        getitem_342 = native_batch_norm_default_112[0]
        getitem_343 = native_batch_norm_default_112[1]
        getitem_344 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        relu__default_112 = torch.ops.aten.relu_.default(getitem_342);  getitem_342 = None
        cat_default_14 = torch.ops.aten.cat.default([relu__default_103, relu__default_106, relu__default_111, relu__default_112], 1)
        convolution_default_113 = torch.ops.aten.convolution.default(cat_default_14, primals_456, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_455, primals_451, primals_453, primals_454, True, 0.1, 0.001);  primals_451 = None
        getitem_345 = native_batch_norm_default_113[0]
        getitem_346 = native_batch_norm_default_113[1]
        getitem_347 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        relu__default_113 = torch.ops.aten.relu_.default(getitem_345);  getitem_345 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu__default_113, primals_462, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_461, primals_457, primals_459, primals_460, True, 0.1, 0.001);  primals_457 = None
        getitem_348 = native_batch_norm_default_114[0]
        getitem_349 = native_batch_norm_default_114[1]
        getitem_350 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        relu__default_114 = torch.ops.aten.relu_.default(getitem_348);  getitem_348 = None
        convolution_default_115 = torch.ops.aten.convolution.default(cat_default_14, primals_468, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_467, primals_463, primals_465, primals_466, True, 0.1, 0.001);  primals_463 = None
        getitem_351 = native_batch_norm_default_115[0]
        getitem_352 = native_batch_norm_default_115[1]
        getitem_353 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        relu__default_115 = torch.ops.aten.relu_.default(getitem_351);  getitem_351 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_115, primals_474, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_473, primals_469, primals_471, primals_472, True, 0.1, 0.001);  primals_469 = None
        getitem_354 = native_batch_norm_default_116[0]
        getitem_355 = native_batch_norm_default_116[1]
        getitem_356 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        relu__default_116 = torch.ops.aten.relu_.default(getitem_354);  getitem_354 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_116, primals_480, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_479, primals_475, primals_477, primals_478, True, 0.1, 0.001);  primals_475 = None
        getitem_357 = native_batch_norm_default_117[0]
        getitem_358 = native_batch_norm_default_117[1]
        getitem_359 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        relu__default_117 = torch.ops.aten.relu_.default(getitem_357);  getitem_357 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_117, primals_486, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_485, primals_481, primals_483, primals_484, True, 0.1, 0.001);  primals_481 = None
        getitem_360 = native_batch_norm_default_118[0]
        getitem_361 = native_batch_norm_default_118[1]
        getitem_362 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        relu__default_118 = torch.ops.aten.relu_.default(getitem_360);  getitem_360 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_14, [3, 3], [2, 2])
        getitem_363 = max_pool2d_with_indices_default_3[0]
        getitem_364 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        cat_default_15 = torch.ops.aten.cat.default([relu__default_114, relu__default_118, getitem_363], 1);  getitem_363 = None
        convolution_default_119 = torch.ops.aten.convolution.default(cat_default_15, primals_492, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_491, primals_487, primals_489, primals_490, True, 0.1, 0.001);  primals_487 = None
        getitem_365 = native_batch_norm_default_119[0]
        getitem_366 = native_batch_norm_default_119[1]
        getitem_367 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        relu__default_119 = torch.ops.aten.relu_.default(getitem_365);  getitem_365 = None
        convolution_default_120 = torch.ops.aten.convolution.default(cat_default_15, primals_498, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_497, primals_493, primals_495, primals_496, True, 0.1, 0.001);  primals_493 = None
        getitem_368 = native_batch_norm_default_120[0]
        getitem_369 = native_batch_norm_default_120[1]
        getitem_370 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        relu__default_120 = torch.ops.aten.relu_.default(getitem_368);  getitem_368 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_120, primals_504, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_503, primals_499, primals_501, primals_502, True, 0.1, 0.001);  primals_499 = None
        getitem_371 = native_batch_norm_default_121[0]
        getitem_372 = native_batch_norm_default_121[1]
        getitem_373 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        relu__default_121 = torch.ops.aten.relu_.default(getitem_371);  getitem_371 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_120, primals_510, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_509, primals_505, primals_507, primals_508, True, 0.1, 0.001);  primals_505 = None
        getitem_374 = native_batch_norm_default_122[0]
        getitem_375 = native_batch_norm_default_122[1]
        getitem_376 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        relu__default_122 = torch.ops.aten.relu_.default(getitem_374);  getitem_374 = None
        cat_default_16 = torch.ops.aten.cat.default([relu__default_121, relu__default_122], 1)
        convolution_default_123 = torch.ops.aten.convolution.default(cat_default_15, primals_516, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_515, primals_511, primals_513, primals_514, True, 0.1, 0.001);  primals_511 = None
        getitem_377 = native_batch_norm_default_123[0]
        getitem_378 = native_batch_norm_default_123[1]
        getitem_379 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        relu__default_123 = torch.ops.aten.relu_.default(getitem_377);  getitem_377 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_123, primals_522, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_521, primals_517, primals_519, primals_520, True, 0.1, 0.001);  primals_517 = None
        getitem_380 = native_batch_norm_default_124[0]
        getitem_381 = native_batch_norm_default_124[1]
        getitem_382 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        relu__default_124 = torch.ops.aten.relu_.default(getitem_380);  getitem_380 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu__default_124, primals_528, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_527, primals_523, primals_525, primals_526, True, 0.1, 0.001);  primals_523 = None
        getitem_383 = native_batch_norm_default_125[0]
        getitem_384 = native_batch_norm_default_125[1]
        getitem_385 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        relu__default_125 = torch.ops.aten.relu_.default(getitem_383);  getitem_383 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_125, primals_534, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_533, primals_529, primals_531, primals_532, True, 0.1, 0.001);  primals_529 = None
        getitem_386 = native_batch_norm_default_126[0]
        getitem_387 = native_batch_norm_default_126[1]
        getitem_388 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        relu__default_126 = torch.ops.aten.relu_.default(getitem_386);  getitem_386 = None
        convolution_default_127 = torch.ops.aten.convolution.default(relu__default_125, primals_540, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_539, primals_535, primals_537, primals_538, True, 0.1, 0.001);  primals_535 = None
        getitem_389 = native_batch_norm_default_127[0]
        getitem_390 = native_batch_norm_default_127[1]
        getitem_391 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        relu__default_127 = torch.ops.aten.relu_.default(getitem_389);  getitem_389 = None
        cat_default_17 = torch.ops.aten.cat.default([relu__default_126, relu__default_127], 1)
        avg_pool2d_default_11 = torch.ops.aten.avg_pool2d.default(cat_default_15, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_128 = torch.ops.aten.convolution.default(avg_pool2d_default_11, primals_546, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_545, primals_541, primals_543, primals_544, True, 0.1, 0.001);  primals_541 = None
        getitem_392 = native_batch_norm_default_128[0]
        getitem_393 = native_batch_norm_default_128[1]
        getitem_394 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        relu__default_128 = torch.ops.aten.relu_.default(getitem_392);  getitem_392 = None
        cat_default_18 = torch.ops.aten.cat.default([relu__default_119, cat_default_16, cat_default_17, relu__default_128], 1);  cat_default_16 = cat_default_17 = None
        convolution_default_129 = torch.ops.aten.convolution.default(cat_default_18, primals_558, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_557, primals_553, primals_555, primals_556, True, 0.1, 0.001);  primals_553 = None
        getitem_395 = native_batch_norm_default_129[0]
        getitem_396 = native_batch_norm_default_129[1]
        getitem_397 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        relu__default_129 = torch.ops.aten.relu_.default(getitem_395);  getitem_395 = None
        convolution_default_130 = torch.ops.aten.convolution.default(cat_default_18, primals_564, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_563, primals_559, primals_561, primals_562, True, 0.1, 0.001);  primals_559 = None
        getitem_398 = native_batch_norm_default_130[0]
        getitem_399 = native_batch_norm_default_130[1]
        getitem_400 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        relu__default_130 = torch.ops.aten.relu_.default(getitem_398);  getitem_398 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_130, primals_570, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_569, primals_565, primals_567, primals_568, True, 0.1, 0.001);  primals_565 = None
        getitem_401 = native_batch_norm_default_131[0]
        getitem_402 = native_batch_norm_default_131[1]
        getitem_403 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        relu__default_131 = torch.ops.aten.relu_.default(getitem_401);  getitem_401 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu__default_130, primals_576, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_575, primals_571, primals_573, primals_574, True, 0.1, 0.001);  primals_571 = None
        getitem_404 = native_batch_norm_default_132[0]
        getitem_405 = native_batch_norm_default_132[1]
        getitem_406 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        relu__default_132 = torch.ops.aten.relu_.default(getitem_404);  getitem_404 = None
        cat_default_19 = torch.ops.aten.cat.default([relu__default_131, relu__default_132], 1)
        convolution_default_133 = torch.ops.aten.convolution.default(cat_default_18, primals_582, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_581, primals_577, primals_579, primals_580, True, 0.1, 0.001);  primals_577 = None
        getitem_407 = native_batch_norm_default_133[0]
        getitem_408 = native_batch_norm_default_133[1]
        getitem_409 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        relu__default_133 = torch.ops.aten.relu_.default(getitem_407);  getitem_407 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_133, primals_588, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_587, primals_583, primals_585, primals_586, True, 0.1, 0.001);  primals_583 = None
        getitem_410 = native_batch_norm_default_134[0]
        getitem_411 = native_batch_norm_default_134[1]
        getitem_412 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        relu__default_134 = torch.ops.aten.relu_.default(getitem_410);  getitem_410 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu__default_134, primals_594, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_593, primals_589, primals_591, primals_592, True, 0.1, 0.001);  primals_589 = None
        getitem_413 = native_batch_norm_default_135[0]
        getitem_414 = native_batch_norm_default_135[1]
        getitem_415 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        relu__default_135 = torch.ops.aten.relu_.default(getitem_413);  getitem_413 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_135, primals_600, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_599, primals_595, primals_597, primals_598, True, 0.1, 0.001);  primals_595 = None
        getitem_416 = native_batch_norm_default_136[0]
        getitem_417 = native_batch_norm_default_136[1]
        getitem_418 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        relu__default_136 = torch.ops.aten.relu_.default(getitem_416);  getitem_416 = None
        convolution_default_137 = torch.ops.aten.convolution.default(relu__default_135, primals_606, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_605, primals_601, primals_603, primals_604, True, 0.1, 0.001);  primals_601 = None
        getitem_419 = native_batch_norm_default_137[0]
        getitem_420 = native_batch_norm_default_137[1]
        getitem_421 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        relu__default_137 = torch.ops.aten.relu_.default(getitem_419);  getitem_419 = None
        cat_default_20 = torch.ops.aten.cat.default([relu__default_136, relu__default_137], 1)
        avg_pool2d_default_12 = torch.ops.aten.avg_pool2d.default(cat_default_18, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_138 = torch.ops.aten.convolution.default(avg_pool2d_default_12, primals_612, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_611, primals_607, primals_609, primals_610, True, 0.1, 0.001);  primals_607 = None
        getitem_422 = native_batch_norm_default_138[0]
        getitem_423 = native_batch_norm_default_138[1]
        getitem_424 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        relu__default_138 = torch.ops.aten.relu_.default(getitem_422);  getitem_422 = None
        cat_default_21 = torch.ops.aten.cat.default([relu__default_129, cat_default_19, cat_default_20, relu__default_138], 1);  cat_default_19 = cat_default_20 = None
        convolution_default_139 = torch.ops.aten.convolution.default(cat_default_21, primals_618, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_617, primals_613, primals_615, primals_616, True, 0.1, 0.001);  primals_613 = None
        getitem_425 = native_batch_norm_default_139[0]
        getitem_426 = native_batch_norm_default_139[1]
        getitem_427 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        relu__default_139 = torch.ops.aten.relu_.default(getitem_425);  getitem_425 = None
        convolution_default_140 = torch.ops.aten.convolution.default(cat_default_21, primals_624, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_623, primals_619, primals_621, primals_622, True, 0.1, 0.001);  primals_619 = None
        getitem_428 = native_batch_norm_default_140[0]
        getitem_429 = native_batch_norm_default_140[1]
        getitem_430 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        relu__default_140 = torch.ops.aten.relu_.default(getitem_428);  getitem_428 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_140, primals_630, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_629, primals_625, primals_627, primals_628, True, 0.1, 0.001);  primals_625 = None
        getitem_431 = native_batch_norm_default_141[0]
        getitem_432 = native_batch_norm_default_141[1]
        getitem_433 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        relu__default_141 = torch.ops.aten.relu_.default(getitem_431);  getitem_431 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu__default_140, primals_636, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_635, primals_631, primals_633, primals_634, True, 0.1, 0.001);  primals_631 = None
        getitem_434 = native_batch_norm_default_142[0]
        getitem_435 = native_batch_norm_default_142[1]
        getitem_436 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        relu__default_142 = torch.ops.aten.relu_.default(getitem_434);  getitem_434 = None
        cat_default_22 = torch.ops.aten.cat.default([relu__default_141, relu__default_142], 1)
        convolution_default_143 = torch.ops.aten.convolution.default(cat_default_21, primals_642, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_641, primals_637, primals_639, primals_640, True, 0.1, 0.001);  primals_637 = None
        getitem_437 = native_batch_norm_default_143[0]
        getitem_438 = native_batch_norm_default_143[1]
        getitem_439 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        relu__default_143 = torch.ops.aten.relu_.default(getitem_437);  getitem_437 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_143, primals_648, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_647, primals_643, primals_645, primals_646, True, 0.1, 0.001);  primals_643 = None
        getitem_440 = native_batch_norm_default_144[0]
        getitem_441 = native_batch_norm_default_144[1]
        getitem_442 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        relu__default_144 = torch.ops.aten.relu_.default(getitem_440);  getitem_440 = None
        convolution_default_145 = torch.ops.aten.convolution.default(relu__default_144, primals_654, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_653, primals_649, primals_651, primals_652, True, 0.1, 0.001);  primals_649 = None
        getitem_443 = native_batch_norm_default_145[0]
        getitem_444 = native_batch_norm_default_145[1]
        getitem_445 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        relu__default_145 = torch.ops.aten.relu_.default(getitem_443);  getitem_443 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_145, primals_660, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_659, primals_655, primals_657, primals_658, True, 0.1, 0.001);  primals_655 = None
        getitem_446 = native_batch_norm_default_146[0]
        getitem_447 = native_batch_norm_default_146[1]
        getitem_448 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        relu__default_146 = torch.ops.aten.relu_.default(getitem_446);  getitem_446 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu__default_145, primals_666, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_665, primals_661, primals_663, primals_664, True, 0.1, 0.001);  primals_661 = None
        getitem_449 = native_batch_norm_default_147[0]
        getitem_450 = native_batch_norm_default_147[1]
        getitem_451 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        relu__default_147 = torch.ops.aten.relu_.default(getitem_449);  getitem_449 = None
        cat_default_23 = torch.ops.aten.cat.default([relu__default_146, relu__default_147], 1)
        avg_pool2d_default_13 = torch.ops.aten.avg_pool2d.default(cat_default_21, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_148 = torch.ops.aten.convolution.default(avg_pool2d_default_13, primals_672, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_671, primals_667, primals_669, primals_670, True, 0.1, 0.001);  primals_667 = None
        getitem_452 = native_batch_norm_default_148[0]
        getitem_453 = native_batch_norm_default_148[1]
        getitem_454 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        relu__default_148 = torch.ops.aten.relu_.default(getitem_452);  getitem_452 = None
        cat_default_24 = torch.ops.aten.cat.default([relu__default_139, cat_default_22, cat_default_23, relu__default_148], 1);  cat_default_22 = cat_default_23 = None
        mean_dim = torch.ops.aten.mean.dim(cat_default_24, [-1, -2], True);  cat_default_24 = None
        view_default = torch.ops.aten.view.default(mean_dim, [128, 1536]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_896);  primals_896 = None
        addmm_default = torch.ops.aten.addmm.default(primals_895, view_default, t_default);  primals_895 = None
        return [addmm_default, getitem_116, getitem_117, primals_711, primals_712, primals_135, primals_141, primals_713, relu__default_37, primals_136, primals_714, relu__default_38, convolution_default_38, avg_pool2d_default_3, primals_717, primals_147, primals_718, getitem_120, primals_719, getitem_119, convolution_default_39, primals_720, primals_143, primals_150, primals_149, primals_723, primals_148, primals_724, primals_725, primals_137, primals_726, primals_144, cat_default_6, primals_142, primals_729, primals_138, primals_730, primals_16, getitem_256, primals_585, getitem_257, primals_586, relu__default_83, primals_587, convolution_default_84, primals_588, primals_11, primals_15, primals_10, primals_17, primals_591, getitem_260, getitem_259, primals_21, primals_592, primals_12, primals_593, primals_594, relu__default_84, primals_18, primals_597, convolution_default_85, primals_9, primals_598, primals_599, getitem_262, primals_24, primals_600, primals_23, primals_22, primals_603, getitem_263, primals_604, convolution_default_86, relu__default_85, getitem_96, relu__default_113, primals_459, convolution_default_114, primals_460, convolution_default_115, relu__default_30, primals_461, getitem_95, avg_pool2d_default_2, primals_462, convolution_default_32, getitem_350, getitem_349, convolution_default_31, primals_465, getitem_99, primals_466, relu__default_114, primals_467, getitem_98, primals_468, relu__default_31, primals_471, primals_472, getitem_352, primals_473, getitem_353, primals_474, cat_default_5, relu__default_115, primals_477, primals_478, getitem_101, convolution_default_116, primals_333, getitem_167, relu__default_7, primals_334, getitem_166, convolution_default_8, convolution_default_9, primals_335, primals_336, relu__default_53, getitem_28, getitem_27, convolution_default_54, primals_339, primals_352, primals_340, relu__default_8, primals_341, getitem_170, getitem_169, primals_342, relu__default_54, primals_345, primals_346, cat_default_1, primals_347, getitem_30, convolution_default_55, getitem_31, primals_348, relu__default_9, primals_351, getitem_172, getitem_433, primals_857, getitem_432, primals_858, relu__default_141, convolution_default_142, primals_861, primals_862, primals_863, primals_864, getitem_436, getitem_435, primals_867, primals_868, relu__default_142, primals_869, primals_870, convolution_default_143, primals_873, primals_874, primals_875, primals_876, getitem_438, primals_87, relu__default_106, primals_731, primals_732, primals_88, primals_95, getitem_329, primals_735, getitem_328, primals_736, primals_737, primals_738, relu__default_107, primals_83, primals_81, primals_82, convolution_default_108, primals_89, primals_741, primals_94, primals_742, primals_743, primals_93, getitem_332, primals_744, getitem_331, relu__default_108, primals_747, primals_84, primals_90, primals_748, primals_749, primals_96, convolution_default_109, primals_750, getitem_75, primals_605, getitem_236, primals_606, relu__default_23, relu__default_76, avg_pool2d_default_1, convolution_default_25, convolution_default_77, primals_609, convolution_default_24, primals_610, primals_611, getitem_239, getitem_78, getitem_238, primals_612, getitem_77, relu__default_77, primals_615, relu__default_24, primals_616, primals_617, convolution_default_78, primals_618, primals_621, cat_default_4, getitem_241, primals_622, getitem_242, primals_623, getitem_80, convolution_default_79, primals_624, getitem_81, relu__default_78, primals_479, getitem_146, getitem_145, primals_480, relu__default_69, convolution_default_70, convolution_default_71, relu__default_46, primals_100, primals_483, convolution_default_47, primals_484, primals_105, getitem_218, primals_485, getitem_217, primals_111, primals_486, primals_99, primals_106, getitem_149, relu__default_70, getitem_148, primals_113, primals_489, primals_490, primals_491, relu__default_47, primals_114, primals_112, primals_492, primals_108, primals_102, primals_101, getitem_1, convolution_default_48, getitem_220, getitem_221, primals_495, primals_107, primals_496, relu__default_71, primals_497, convolution_default_1, primals_498, getitem_151, getitem_152, avg_pool2d_default_6, getitem_2, primals_353, primals_4, relu__default_129, primals_354, convolution_default_130, convolution_default_131, primals_5, primals_357, getitem_400, primals_358, getitem_399, primals_359, primals_360, relu__default_130, primals_363, primals_364, primals_365, primals_366, getitem_402, getitem_403, primals_369, primals_3, primals_6, primals_370, relu__default_131, primals_371, primals_372, convolution_default_132, getitem_122, getitem_123, relu__default_39, getitem_308, convolution_default_94, convolution_default_40, convolution_default_93, getitem_307, getitem_287, getitem_286, relu__default_100, getitem_126, getitem_125, relu__default_93, convolution_default_101, relu__default_40, getitem_311, convolution_default_102, getitem_310, convolution_default_41, getitem_289, getitem_290, relu__default_101, relu__default_94, convolution_default_42, getitem_128, getitem_129, convolution_default_95, relu__default_41, avg_pool2d_default_9, getitem_194, relu__default_16, primals_879, avg_pool2d_default, convolution_default_18, relu__default_62, primals_880, primals_881, convolution_default_17, primals_882, convolution_default_63, getitem_57, getitem_56, getitem_197, primals_885, getitem_196, primals_886, primals_887, relu__default_17, primals_888, relu__default_63, convolution_default_64, primals_891, primals_892, primals_893, cat_default_3, getitem_59, primals_894, convolution_default_19, convolution_default_65, getitem_199, getitem_200, primals_897, getitem_60, relu__default_64, primals_160, convolution_default_123, convolution_default_10, convolution_default_124, primals_753, getitem_356, primals_754, primals_156, getitem_355, primals_165, primals_755, getitem_34, primals_167, getitem_33, primals_756, getitem_379, relu__default_116, getitem_378, primals_161, primals_166, relu__default_10, convolution_default_117, primals_155, primals_759, relu__default_123, primals_760, primals_153, primals_761, primals_162, primals_762, cat_default_2, getitem_359, getitem_358, getitem_36, primals_159, primals_154, getitem_382, primals_765, relu__default_117, getitem_381, convolution_default_11, primals_766, primals_767, primals_768, convolution_default_118, relu__default_124, primals_168, relu__default_11, cat_default_15, getitem_38, getitem_39, convolution_default_125, primals_771, primals_772, convolution_default_12, relu__default, getitem_173, primals_501, getitem_335, primals_627, getitem_334, relu__default_55, primals_502, primals_628, convolution_default_56, primals_503, convolution_default_57, primals_629, primals_504, getitem_5, convolution_default_110, primals_630, relu__default_109, getitem_4, getitem_176, getitem_175, primals_507, primals_633, relu__default_1, primals_508, primals_634, primals_509, primals_635, relu__default_56, getitem_338, convolution_default_2, primals_510, getitem_337, primals_636, convolution_default_139, relu__default_110, primals_513, getitem_8, primals_639, getitem_7, primals_514, primals_640, primals_515, primals_641, convolution_default_111, getitem_178, primals_516, convolution_default_3, relu__default_2, primals_642, getitem_179, primals_519, relu__default_57, primals_645, convolution_default_58, getitem_340, primals_520, primals_646, getitem_102, getitem_439, primals_375, primals_376, relu__default_32, relu__default_143, convolution_default_33, primals_377, convolution_default_34, convolution_default_144, primals_378, getitem_266, getitem_265, getitem_105, getitem_104, getitem_442, primals_381, relu__default_86, getitem_441, primals_382, primals_383, relu__default_33, convolution_default_87, primals_384, relu__default_144, getitem_269, convolution_default_145, primals_387, getitem_268, primals_388, primals_389, getitem_107, primals_390, relu__default_87, getitem_108, relu__default_145, getitem_444, getitem_445, convolution_default_88, primals_393, relu__default_34, convolution_default_35, primals_394, convolution_default_146, primals_249, primals_216, primals_250, primals_209, primals_251, primals_252, primals_225, primals_226, primals_255, primals_256, primals_257, primals_222, primals_258, primals_227, primals_261, primals_262, primals_215, primals_263, primals_214, primals_264, primals_220, primals_221, primals_210, primals_267, primals_268, primals_219, primals_213, relu__default_136, convolution_default_72, getitem_224, getitem_245, getitem_244, getitem_223, getitem_421, getitem_420, relu__default_79, relu__default_72, relu__default_137, convolution_default_80, convolution_default_73, getitem_248, getitem_247, cat_default_10, avg_pool2d_default_12, getitem_424, getitem_226, convolution_default_138, getitem_227, relu__default_80, relu__default_73, getitem_423, convolution_default_81, cat_default_21, convolution_default_74, primals_773, relu__default_25, primals_774, convolution_default_26, convolution_default_27, getitem_10, getitem_13, getitem_12, primals_777, cat_default, getitem_84, primals_778, getitem_83, primals_779, relu__default_3, primals_780, relu__default_26, convolution_default_4, primals_783, primals_784, primals_785, getitem_16, getitem_15, primals_786, getitem_86, getitem_87, relu__default_4, primals_789, primals_790, relu__default_27, primals_791, convolution_default_5, primals_792, convolution_default_28, primals_647, relu__default_48, primals_648, convolution_default_49, getitem_406, getitem_293, getitem_314, convolution_default_50, getitem_292, getitem_313, getitem_405, primals_651, relu__default_132, getitem_155, relu__default_95, relu__default_102, primals_652, getitem_154, primals_653, convolution_default_103, primals_654, relu__default_49, convolution_default_96, convolution_default_133, getitem_296, cat_default_13, primals_657, getitem_295, getitem_317, primals_658, getitem_316, getitem_409, getitem_408, primals_659, primals_660, relu__default_96, relu__default_103, getitem_157, relu__default_133, getitem_158, convolution_default_97, primals_663, convolution_default_104, primals_664, relu__default_50, convolution_default_134, primals_665, primals_666, convolution_default_51, getitem_298, primals_521, convolution_default_126, primals_171, primals_231, primals_522, primals_184, getitem_385, primals_185, getitem_384, primals_234, primals_177, primals_183, getitem_203, primals_525, primals_246, getitem_202, primals_237, relu__default_125, primals_526, primals_180, primals_238, primals_527, primals_172, primals_239, primals_528, relu__default_65, primals_178, primals_174, convolution_default_66, getitem_388, primals_173, getitem_387, primals_179, primals_232, primals_531, primals_233, primals_532, primals_533, getitem_206, getitem_205, relu__default_126, primals_186, primals_243, primals_534, primals_245, relu__default_66, convolution_default_127, primals_537, primals_538, primals_228, primals_240, primals_539, convolution_default_67, primals_540, getitem_390, primals_244, primals_395, relu__default_18, primals_396, getitem_111, getitem_110, primals_399, getitem_63, getitem_62, primals_400, primals_401, relu__default_35, primals_402, relu__default_19, convolution_default_36, convolution_default_20, primals_405, primals_406, getitem_114, primals_407, getitem_113, primals_408, getitem_66, getitem_65, relu__default_36, primals_411, relu__default_20, primals_412, convolution_default_37, primals_413, primals_414, convolution_default_21, getitem_132, getitem_131, relu__default_42, cat_default_7, getitem_134, convolution_default_43, convolution_default_44, getitem_136, getitem_137, relu__default_43, primals_269, getitem_362, primals_270, primals_795, primals_796, relu__default_118, getitem_361, primals_797, primals_273, primals_798, primals_274, primals_275, getitem_364, primals_276, convolution_default_119, primals_801, primals_802, primals_803, primals_279, getitem_367, primals_804, getitem_366, primals_280, primals_281, primals_282, primals_807, relu__default_119, primals_808, primals_809, primals_285, convolution_default_120, primals_810, primals_286, primals_287, primals_288, primals_813, primals_814, getitem_369, getitem_272, getitem_271, primals_669, primals_670, getitem_182, getitem_42, getitem_181, primals_671, getitem_41, relu__default_88, primals_672, convolution_default_89, relu__default_58, relu__default_12, primals_675, convolution_default_59, primals_676, convolution_default_13, getitem_275, primals_677, getitem_274, primals_678, getitem_185, getitem_45, getitem_184, getitem_44, relu__default_89, primals_681, primals_682, relu__default_59, relu__default_13, convolution_default_90, primals_683, primals_684, convolution_default_60, convolution_default_14, primals_687, getitem_277, primals_688, getitem_278, getitem_19, getitem_250, primals_543, getitem_18, primals_63, getitem_251, primals_72, primals_544, getitem_448, primals_545, relu__default_5, relu__default_81, getitem_447, convolution_default_6, primals_546, relu__default_82, primals_76, relu__default_146, convolution_default_82, avg_pool2d_default_7, primals_549, primals_71, primals_64, primals_65, primals_550, convolution_default_147, primals_77, getitem_22, getitem_254, primals_66, primals_551, getitem_21, getitem_253, primals_69, convolution_default_83, primals_552, getitem_451, primals_75, relu__default_6, getitem_450, primals_555, primals_556, convolution_default_7, relu__default_147, primals_557, primals_70, primals_558, primals_78, cat_default_11, primals_561, getitem_24, convolution_default_148, getitem_25, primals_562, avg_pool2d_default_13, primals_417, primals_418, primals_419, primals_420, primals_423, primals_424, primals_425, primals_426, primals_429, primals_430, primals_431, primals_432, primals_435, primals_436, relu__default_138, relu__default_111, getitem_90, getitem_161, getitem_341, getitem_427, avg_pool2d_default_10, getitem_89, getitem_160, convolution_default_113, getitem_426, relu__default_28, relu__default_51, convolution_default_112, relu__default_52, getitem_344, relu__default_139, convolution_default_29, getitem_343, convolution_default_52, avg_pool2d_default_4, getitem_93, relu__default_112, getitem_92, convolution_default_140, getitem_164, getitem_163, getitem_430, getitem_429, relu__default_29, cat_default_8, relu__default_140, convolution_default_30, cat_default_14, convolution_default_141, convolution_default_53, getitem_346, getitem_347, primals_815, primals_291, primals_816, primals_292, relu__default_104, primals_293, convolution_default_105, primals_298, primals_294, primals_819, getitem_320, primals_820, primals_821, getitem_319, primals_297, primals_822, getitem_323, getitem_322, primals_299, primals_300, primals_825, relu__default_105, primals_826, primals_827, primals_828, primals_303, convolution_default_106, primals_304, primals_305, getitem_325, primals_831, primals_306, convolution_default_107, primals_832, primals_833, primals_309, primals_834, getitem_326, primals_310, primals_48, primals_53, getitem_69, getitem_230, primals_131, getitem_68, primals_132, primals_130, getitem_229, primals_46, convolution_default_22, relu__default_21, relu__default_74, primals_60, primals_124, primals_119, primals_126, convolution_default_75, primals_57, primals_118, getitem_72, primals_47, getitem_71, getitem_233, primals_117, getitem_232, primals_45, relu__default_22, primals_125, primals_51, relu__default_75, convolution_default_23, convolution_default_76, primals_54, primals_123, primals_59, primals_58, primals_129, primals_120, getitem_74, getitem_235, primals_52, getitem_411, getitem_391, primals_689, getitem_299, getitem_412, primals_690, relu__default_127, relu__default_97, avg_pool2d_default_11, convolution_default_98, relu__default_134, getitem_140, getitem_139, convolution_default_135, primals_693, convolution_default_128, primals_694, primals_695, relu__default_44, getitem_302, getitem_301, primals_696, getitem_415, getitem_417, getitem_393, getitem_414, convolution_default_45, getitem_394, relu__default_98, primals_699, relu__default_128, primals_700, relu__default_135, getitem_143, primals_701, getitem_142, convolution_default_99, primals_702, convolution_default_136, convolution_default_137, relu__default_45, primals_705, primals_706, relu__default_99, cat_default_18, convolution_default_46, getitem_304, primals_707, getitem_305, getitem_418, getitem_396, primals_708, getitem_397, convolution_default_100, primals_27, primals_311, primals_437, primals_563, getitem_209, primals_312, primals_438, getitem_208, primals_564, primals_315, primals_441, relu__default_67, primals_29, primals_28, primals_567, primals_316, primals_442, convolution_default_68, primals_568, primals_317, primals_443, primals_569, primals_318, primals_444, primals_35, primals_570, primals_42, getitem_212, primals_41, getitem_211, primals_321, primals_447, primals_573, primals_30, primals_322, primals_448, primals_574, primals_323, primals_449, relu__default_68, primals_36, primals_575, primals_34, primals_324, primals_450, primals_576, primals_40, primals_33, convolution_default_69, primals_327, primals_453, primals_579, primals_328, primals_454, primals_580, primals_329, primals_455, primals_581, primals_330, primals_456, getitem_214, primals_39, primals_582, getitem_215, primals_195, getitem_188, relu__default_60, convolution_default_61, primals_190, primals_197, getitem_187, primals_204, primals_202, cat_default_9, getitem_191, primals_203, primals_189, getitem_190, primals_192, primals_201, getitem_193, relu__default_61, primals_208, primals_207, avg_pool2d_default_5, convolution_default_62, primals_191, primals_198, primals_196, getitem_370, getitem_47, relu__default_90, primals_837, getitem_454, convolution_default_91, relu__default_120, primals_838, getitem_453, relu__default_14, convolution_default_121, primals_839, convolution_default_15, primals_840, getitem_48, getitem_281, relu__default_148, getitem_280, getitem_373, getitem_372, primals_843, primals_844, getitem_51, getitem_50, relu__default_91, primals_845, relu__default_121, primals_846, getitem_284, relu__default_15, convolution_default_129, view_default, t_default, convolution_default_122, primals_849, avg_pool2d_default_8, convolution_default_92, primals_850, convolution_default, convolution_default_16, primals_851, primals_852, getitem_283, relu__default_122, getitem_375, getitem_376, getitem_53, cat_default_12, getitem_54, primals_855, primals_856, relu__default_92]
        
