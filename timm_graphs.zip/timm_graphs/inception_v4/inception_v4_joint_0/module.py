
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/inception_v4/inception_v4_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666, primals_667, primals_668, primals_669, primals_670, primals_671, primals_672, primals_673, primals_674, primals_675, primals_676, primals_677, primals_678, primals_679, primals_680, primals_681, primals_682, primals_683, primals_684, primals_685, primals_686, primals_687, primals_688, primals_689, primals_690, primals_691, primals_692, primals_693, primals_694, primals_695, primals_696, primals_697, primals_698, primals_699, primals_700, primals_701, primals_702, primals_703, primals_704, primals_705, primals_706, primals_707, primals_708, primals_709, primals_710, primals_711, primals_712, primals_713, primals_714, primals_715, primals_716, primals_717, primals_718, primals_719, primals_720, primals_721, primals_722, primals_723, primals_724, primals_725, primals_726, primals_727, primals_728, primals_729, primals_730, primals_731, primals_732, primals_733, primals_734, primals_735, primals_736, primals_737, primals_738, primals_739, primals_740, primals_741, primals_742, primals_743, primals_744, primals_745, primals_746, primals_747, primals_748, primals_749, primals_750, primals_751, primals_752, primals_753, primals_754, primals_755, primals_756, primals_757, primals_758, primals_759, primals_760, primals_761, primals_762, primals_763, primals_764, primals_765, primals_766, primals_767, primals_768, primals_769, primals_770, primals_771, primals_772, primals_773, primals_774, primals_775, primals_776, primals_777, primals_778, primals_779, primals_780, primals_781, primals_782, primals_783, primals_784, primals_785, primals_786, primals_787, primals_788, primals_789, primals_790, primals_791, primals_792, primals_793, primals_794, primals_795, primals_796, primals_797, primals_798, primals_799, primals_800, primals_801, primals_802, primals_803, primals_804, primals_805, primals_806, primals_807, primals_808, primals_809, primals_810, primals_811, primals_812, primals_813, primals_814, primals_815, primals_816, primals_817, primals_818, primals_819, primals_820, primals_821, primals_822, primals_823, primals_824, primals_825, primals_826, primals_827, primals_828, primals_829, primals_830, primals_831, primals_832, primals_833, primals_834, primals_835, primals_836, primals_837, primals_838, primals_839, primals_840, primals_841, primals_842, primals_843, primals_844, primals_845, primals_846, primals_847, primals_848, primals_849, primals_850, primals_851, primals_852, primals_853, primals_854, primals_855, primals_856, primals_857, primals_858, primals_859, primals_860, primals_861, primals_862, primals_863, primals_864, primals_865, primals_866, primals_867, primals_868, primals_869, primals_870, primals_871, primals_872, primals_873, primals_874, primals_875, primals_876, primals_877, primals_878, primals_879, primals_880, primals_881, primals_882, primals_883, primals_884, primals_885, primals_886, primals_887, primals_888, primals_889, primals_890, primals_891, primals_892, primals_893, primals_894, primals_895, primals_896, primals_897, tangents_1):
        convolution_default = torch.ops.aten.convolution.default(primals_897, primals_6, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor = torch.ops.aten.add_.Tensor(primals_2, 1);  primals_2 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_5, primals_1, primals_3, primals_4, True, 0.1, 0.001);  primals_1 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_552, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_1 = torch.ops.aten.add_.Tensor(primals_548, 1);  primals_548 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_551, primals_547, primals_549, primals_550, True, 0.1, 0.001);  primals_547 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_678, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_2 = torch.ops.aten.add_.Tensor(primals_674, 1);  primals_674 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_677, primals_673, primals_675, primals_676, True, 0.1, 0.001);  primals_673 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default_2, [3, 3], [2, 2])
        getitem_9 = max_pool2d_with_indices_default[0]
        getitem_10 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_684, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_3 = torch.ops.aten.add_.Tensor(primals_680, 1);  primals_680 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_683, primals_679, primals_681, primals_682, True, 0.1, 0.001);  primals_679 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        cat_default = torch.ops.aten.cat.default([getitem_9, relu__default_3], 1);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(cat_default, primals_690, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_4 = torch.ops.aten.add_.Tensor(primals_686, 1);  primals_686 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_689, primals_685, primals_687, primals_688, True, 0.1, 0.001);  primals_685 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_4, primals_696, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_5 = torch.ops.aten.add_.Tensor(primals_692, 1);  primals_692 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_695, primals_691, primals_693, primals_694, True, 0.1, 0.001);  primals_691 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_6 = torch.ops.aten.convolution.default(cat_default, primals_702, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_6 = torch.ops.aten.add_.Tensor(primals_698, 1);  primals_698 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_701, primals_697, primals_699, primals_700, True, 0.1, 0.001);  primals_697 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_6, primals_708, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_7 = torch.ops.aten.add_.Tensor(primals_704, 1);  primals_704 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_707, primals_703, primals_705, primals_706, True, 0.1, 0.001);  primals_703 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_7, primals_714, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_8 = torch.ops.aten.add_.Tensor(primals_710, 1);  primals_710 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_713, primals_709, primals_711, primals_712, True, 0.1, 0.001);  primals_709 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_8, primals_720, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_9 = torch.ops.aten.add_.Tensor(primals_716, 1);  primals_716 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_719, primals_715, primals_717, primals_718, True, 0.1, 0.001);  primals_715 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        cat_default_1 = torch.ops.aten.cat.default([relu__default_5, relu__default_9], 1)
        convolution_default_10 = torch.ops.aten.convolution.default(cat_default_1, primals_726, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_10 = torch.ops.aten.add_.Tensor(primals_722, 1);  primals_722 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_725, primals_721, primals_723, primals_724, True, 0.1, 0.001);  primals_721 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        max_pool2d_with_indices_default_1 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_1, [3, 3], [2, 2])
        getitem_35 = max_pool2d_with_indices_default_1[0]
        getitem_36 = max_pool2d_with_indices_default_1[1];  max_pool2d_with_indices_default_1 = None
        cat_default_2 = torch.ops.aten.cat.default([relu__default_10, getitem_35], 1);  getitem_35 = None
        convolution_default_11 = torch.ops.aten.convolution.default(cat_default_2, primals_732, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_11 = torch.ops.aten.add_.Tensor(primals_728, 1);  primals_728 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_731, primals_727, primals_729, primals_730, True, 0.1, 0.001);  primals_727 = None
        getitem_37 = native_batch_norm_default_11[0]
        getitem_38 = native_batch_norm_default_11[1]
        getitem_39 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_37);  getitem_37 = None
        convolution_default_12 = torch.ops.aten.convolution.default(cat_default_2, primals_738, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_12 = torch.ops.aten.add_.Tensor(primals_734, 1);  primals_734 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_737, primals_733, primals_735, primals_736, True, 0.1, 0.001);  primals_733 = None
        getitem_40 = native_batch_norm_default_12[0]
        getitem_41 = native_batch_norm_default_12[1]
        getitem_42 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_40);  getitem_40 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_12, primals_744, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_13 = torch.ops.aten.add_.Tensor(primals_740, 1);  primals_740 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_743, primals_739, primals_741, primals_742, True, 0.1, 0.001);  primals_739 = None
        getitem_43 = native_batch_norm_default_13[0]
        getitem_44 = native_batch_norm_default_13[1]
        getitem_45 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_43);  getitem_43 = None
        convolution_default_14 = torch.ops.aten.convolution.default(cat_default_2, primals_750, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_14 = torch.ops.aten.add_.Tensor(primals_746, 1);  primals_746 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_749, primals_745, primals_747, primals_748, True, 0.1, 0.001);  primals_745 = None
        getitem_46 = native_batch_norm_default_14[0]
        getitem_47 = native_batch_norm_default_14[1]
        getitem_48 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_46);  getitem_46 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_14, primals_756, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_15 = torch.ops.aten.add_.Tensor(primals_752, 1);  primals_752 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_755, primals_751, primals_753, primals_754, True, 0.1, 0.001);  primals_751 = None
        getitem_49 = native_batch_norm_default_15[0]
        getitem_50 = native_batch_norm_default_15[1]
        getitem_51 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_49);  getitem_49 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_15, primals_762, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_16 = torch.ops.aten.add_.Tensor(primals_758, 1);  primals_758 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_761, primals_757, primals_759, primals_760, True, 0.1, 0.001);  primals_757 = None
        getitem_52 = native_batch_norm_default_16[0]
        getitem_53 = native_batch_norm_default_16[1]
        getitem_54 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_52);  getitem_52 = None
        avg_pool2d_default = torch.ops.aten.avg_pool2d.default(cat_default_2, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_17 = torch.ops.aten.convolution.default(avg_pool2d_default, primals_768, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_17 = torch.ops.aten.add_.Tensor(primals_764, 1);  primals_764 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_767, primals_763, primals_765, primals_766, True, 0.1, 0.001);  primals_763 = None
        getitem_55 = native_batch_norm_default_17[0]
        getitem_56 = native_batch_norm_default_17[1]
        getitem_57 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_55);  getitem_55 = None
        cat_default_3 = torch.ops.aten.cat.default([relu__default_11, relu__default_13, relu__default_16, relu__default_17], 1)
        convolution_default_18 = torch.ops.aten.convolution.default(cat_default_3, primals_774, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_18 = torch.ops.aten.add_.Tensor(primals_770, 1);  primals_770 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_773, primals_769, primals_771, primals_772, True, 0.1, 0.001);  primals_769 = None
        getitem_58 = native_batch_norm_default_18[0]
        getitem_59 = native_batch_norm_default_18[1]
        getitem_60 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_58);  getitem_58 = None
        convolution_default_19 = torch.ops.aten.convolution.default(cat_default_3, primals_780, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_19 = torch.ops.aten.add_.Tensor(primals_776, 1);  primals_776 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_779, primals_775, primals_777, primals_778, True, 0.1, 0.001);  primals_775 = None
        getitem_61 = native_batch_norm_default_19[0]
        getitem_62 = native_batch_norm_default_19[1]
        getitem_63 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_61);  getitem_61 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_19, primals_786, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_20 = torch.ops.aten.add_.Tensor(primals_782, 1);  primals_782 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_785, primals_781, primals_783, primals_784, True, 0.1, 0.001);  primals_781 = None
        getitem_64 = native_batch_norm_default_20[0]
        getitem_65 = native_batch_norm_default_20[1]
        getitem_66 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_64);  getitem_64 = None
        convolution_default_21 = torch.ops.aten.convolution.default(cat_default_3, primals_792, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_21 = torch.ops.aten.add_.Tensor(primals_788, 1);  primals_788 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_791, primals_787, primals_789, primals_790, True, 0.1, 0.001);  primals_787 = None
        getitem_67 = native_batch_norm_default_21[0]
        getitem_68 = native_batch_norm_default_21[1]
        getitem_69 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_67);  getitem_67 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_21, primals_798, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_22 = torch.ops.aten.add_.Tensor(primals_794, 1);  primals_794 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_797, primals_793, primals_795, primals_796, True, 0.1, 0.001);  primals_793 = None
        getitem_70 = native_batch_norm_default_22[0]
        getitem_71 = native_batch_norm_default_22[1]
        getitem_72 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_70);  getitem_70 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_22, primals_804, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_23 = torch.ops.aten.add_.Tensor(primals_800, 1);  primals_800 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_803, primals_799, primals_801, primals_802, True, 0.1, 0.001);  primals_799 = None
        getitem_73 = native_batch_norm_default_23[0]
        getitem_74 = native_batch_norm_default_23[1]
        getitem_75 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_73);  getitem_73 = None
        avg_pool2d_default_1 = torch.ops.aten.avg_pool2d.default(cat_default_3, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_24 = torch.ops.aten.convolution.default(avg_pool2d_default_1, primals_810, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_24 = torch.ops.aten.add_.Tensor(primals_806, 1);  primals_806 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_809, primals_805, primals_807, primals_808, True, 0.1, 0.001);  primals_805 = None
        getitem_76 = native_batch_norm_default_24[0]
        getitem_77 = native_batch_norm_default_24[1]
        getitem_78 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_76);  getitem_76 = None
        cat_default_4 = torch.ops.aten.cat.default([relu__default_18, relu__default_20, relu__default_23, relu__default_24], 1)
        convolution_default_25 = torch.ops.aten.convolution.default(cat_default_4, primals_816, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_25 = torch.ops.aten.add_.Tensor(primals_812, 1);  primals_812 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_815, primals_811, primals_813, primals_814, True, 0.1, 0.001);  primals_811 = None
        getitem_79 = native_batch_norm_default_25[0]
        getitem_80 = native_batch_norm_default_25[1]
        getitem_81 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_79);  getitem_79 = None
        convolution_default_26 = torch.ops.aten.convolution.default(cat_default_4, primals_822, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_26 = torch.ops.aten.add_.Tensor(primals_818, 1);  primals_818 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_821, primals_817, primals_819, primals_820, True, 0.1, 0.001);  primals_817 = None
        getitem_82 = native_batch_norm_default_26[0]
        getitem_83 = native_batch_norm_default_26[1]
        getitem_84 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_82);  getitem_82 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_26, primals_828, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_27 = torch.ops.aten.add_.Tensor(primals_824, 1);  primals_824 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_827, primals_823, primals_825, primals_826, True, 0.1, 0.001);  primals_823 = None
        getitem_85 = native_batch_norm_default_27[0]
        getitem_86 = native_batch_norm_default_27[1]
        getitem_87 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_85);  getitem_85 = None
        convolution_default_28 = torch.ops.aten.convolution.default(cat_default_4, primals_834, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_28 = torch.ops.aten.add_.Tensor(primals_830, 1);  primals_830 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_833, primals_829, primals_831, primals_832, True, 0.1, 0.001);  primals_829 = None
        getitem_88 = native_batch_norm_default_28[0]
        getitem_89 = native_batch_norm_default_28[1]
        getitem_90 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_88);  getitem_88 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_28, primals_840, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_29 = torch.ops.aten.add_.Tensor(primals_836, 1);  primals_836 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_839, primals_835, primals_837, primals_838, True, 0.1, 0.001);  primals_835 = None
        getitem_91 = native_batch_norm_default_29[0]
        getitem_92 = native_batch_norm_default_29[1]
        getitem_93 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_91);  getitem_91 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_29, primals_846, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_30 = torch.ops.aten.add_.Tensor(primals_842, 1);  primals_842 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_845, primals_841, primals_843, primals_844, True, 0.1, 0.001);  primals_841 = None
        getitem_94 = native_batch_norm_default_30[0]
        getitem_95 = native_batch_norm_default_30[1]
        getitem_96 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_94);  getitem_94 = None
        avg_pool2d_default_2 = torch.ops.aten.avg_pool2d.default(cat_default_4, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_31 = torch.ops.aten.convolution.default(avg_pool2d_default_2, primals_852, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_31 = torch.ops.aten.add_.Tensor(primals_848, 1);  primals_848 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_851, primals_847, primals_849, primals_850, True, 0.1, 0.001);  primals_847 = None
        getitem_97 = native_batch_norm_default_31[0]
        getitem_98 = native_batch_norm_default_31[1]
        getitem_99 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_97);  getitem_97 = None
        cat_default_5 = torch.ops.aten.cat.default([relu__default_25, relu__default_27, relu__default_30, relu__default_31], 1)
        convolution_default_32 = torch.ops.aten.convolution.default(cat_default_5, primals_858, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_32 = torch.ops.aten.add_.Tensor(primals_854, 1);  primals_854 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_857, primals_853, primals_855, primals_856, True, 0.1, 0.001);  primals_853 = None
        getitem_100 = native_batch_norm_default_32[0]
        getitem_101 = native_batch_norm_default_32[1]
        getitem_102 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_100);  getitem_100 = None
        convolution_default_33 = torch.ops.aten.convolution.default(cat_default_5, primals_864, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_33 = torch.ops.aten.add_.Tensor(primals_860, 1);  primals_860 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_863, primals_859, primals_861, primals_862, True, 0.1, 0.001);  primals_859 = None
        getitem_103 = native_batch_norm_default_33[0]
        getitem_104 = native_batch_norm_default_33[1]
        getitem_105 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_33 = torch.ops.aten.relu_.default(getitem_103);  getitem_103 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_33, primals_870, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_34 = torch.ops.aten.add_.Tensor(primals_866, 1);  primals_866 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_869, primals_865, primals_867, primals_868, True, 0.1, 0.001);  primals_865 = None
        getitem_106 = native_batch_norm_default_34[0]
        getitem_107 = native_batch_norm_default_34[1]
        getitem_108 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_34 = torch.ops.aten.relu_.default(getitem_106);  getitem_106 = None
        convolution_default_35 = torch.ops.aten.convolution.default(cat_default_5, primals_876, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_35 = torch.ops.aten.add_.Tensor(primals_872, 1);  primals_872 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_875, primals_871, primals_873, primals_874, True, 0.1, 0.001);  primals_871 = None
        getitem_109 = native_batch_norm_default_35[0]
        getitem_110 = native_batch_norm_default_35[1]
        getitem_111 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_35 = torch.ops.aten.relu_.default(getitem_109);  getitem_109 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_35, primals_882, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_36 = torch.ops.aten.add_.Tensor(primals_878, 1);  primals_878 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_881, primals_877, primals_879, primals_880, True, 0.1, 0.001);  primals_877 = None
        getitem_112 = native_batch_norm_default_36[0]
        getitem_113 = native_batch_norm_default_36[1]
        getitem_114 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_36 = torch.ops.aten.relu_.default(getitem_112);  getitem_112 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_36, primals_888, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_37 = torch.ops.aten.add_.Tensor(primals_884, 1);  primals_884 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_887, primals_883, primals_885, primals_886, True, 0.1, 0.001);  primals_883 = None
        getitem_115 = native_batch_norm_default_37[0]
        getitem_116 = native_batch_norm_default_37[1]
        getitem_117 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_115);  getitem_115 = None
        avg_pool2d_default_3 = torch.ops.aten.avg_pool2d.default(cat_default_5, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_38 = torch.ops.aten.convolution.default(avg_pool2d_default_3, primals_894, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_38 = torch.ops.aten.add_.Tensor(primals_890, 1);  primals_890 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_893, primals_889, primals_891, primals_892, True, 0.1, 0.001);  primals_889 = None
        getitem_118 = native_batch_norm_default_38[0]
        getitem_119 = native_batch_norm_default_38[1]
        getitem_120 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_38 = torch.ops.aten.relu_.default(getitem_118);  getitem_118 = None
        cat_default_6 = torch.ops.aten.cat.default([relu__default_32, relu__default_34, relu__default_37, relu__default_38], 1)
        convolution_default_39 = torch.ops.aten.convolution.default(cat_default_6, primals_12, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_39 = torch.ops.aten.add_.Tensor(primals_8, 1);  primals_8 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_11, primals_7, primals_9, primals_10, True, 0.1, 0.001);  primals_7 = None
        getitem_121 = native_batch_norm_default_39[0]
        getitem_122 = native_batch_norm_default_39[1]
        getitem_123 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_39 = torch.ops.aten.relu_.default(getitem_121);  getitem_121 = None
        convolution_default_40 = torch.ops.aten.convolution.default(cat_default_6, primals_18, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_40 = torch.ops.aten.add_.Tensor(primals_14, 1);  primals_14 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_17, primals_13, primals_15, primals_16, True, 0.1, 0.001);  primals_13 = None
        getitem_124 = native_batch_norm_default_40[0]
        getitem_125 = native_batch_norm_default_40[1]
        getitem_126 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_40 = torch.ops.aten.relu_.default(getitem_124);  getitem_124 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_40, primals_24, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        add__tensor_41 = torch.ops.aten.add_.Tensor(primals_20, 1);  primals_20 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_23, primals_19, primals_21, primals_22, True, 0.1, 0.001);  primals_19 = None
        getitem_127 = native_batch_norm_default_41[0]
        getitem_128 = native_batch_norm_default_41[1]
        getitem_129 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_41 = torch.ops.aten.relu_.default(getitem_127);  getitem_127 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_41, primals_30, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_42 = torch.ops.aten.add_.Tensor(primals_26, 1);  primals_26 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_29, primals_25, primals_27, primals_28, True, 0.1, 0.001);  primals_25 = None
        getitem_130 = native_batch_norm_default_42[0]
        getitem_131 = native_batch_norm_default_42[1]
        getitem_132 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_42 = torch.ops.aten.relu_.default(getitem_130);  getitem_130 = None
        max_pool2d_with_indices_default_2 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_6, [3, 3], [2, 2])
        getitem_133 = max_pool2d_with_indices_default_2[0]
        getitem_134 = max_pool2d_with_indices_default_2[1];  max_pool2d_with_indices_default_2 = None
        cat_default_7 = torch.ops.aten.cat.default([relu__default_39, relu__default_42, getitem_133], 1);  getitem_133 = None
        convolution_default_43 = torch.ops.aten.convolution.default(cat_default_7, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_43 = torch.ops.aten.add_.Tensor(primals_32, 1);  primals_32 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_35, primals_31, primals_33, primals_34, True, 0.1, 0.001);  primals_31 = None
        getitem_135 = native_batch_norm_default_43[0]
        getitem_136 = native_batch_norm_default_43[1]
        getitem_137 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_43 = torch.ops.aten.relu_.default(getitem_135);  getitem_135 = None
        convolution_default_44 = torch.ops.aten.convolution.default(cat_default_7, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_44 = torch.ops.aten.add_.Tensor(primals_38, 1);  primals_38 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_41, primals_37, primals_39, primals_40, True, 0.1, 0.001);  primals_37 = None
        getitem_138 = native_batch_norm_default_44[0]
        getitem_139 = native_batch_norm_default_44[1]
        getitem_140 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_44 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_44, primals_48, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_45 = torch.ops.aten.add_.Tensor(primals_44, 1);  primals_44 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_47, primals_43, primals_45, primals_46, True, 0.1, 0.001);  primals_43 = None
        getitem_141 = native_batch_norm_default_45[0]
        getitem_142 = native_batch_norm_default_45[1]
        getitem_143 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_45 = torch.ops.aten.relu_.default(getitem_141);  getitem_141 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_45, primals_54, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_46 = torch.ops.aten.add_.Tensor(primals_50, 1);  primals_50 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_53, primals_49, primals_51, primals_52, True, 0.1, 0.001);  primals_49 = None
        getitem_144 = native_batch_norm_default_46[0]
        getitem_145 = native_batch_norm_default_46[1]
        getitem_146 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_46 = torch.ops.aten.relu_.default(getitem_144);  getitem_144 = None
        convolution_default_47 = torch.ops.aten.convolution.default(cat_default_7, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_47 = torch.ops.aten.add_.Tensor(primals_56, 1);  primals_56 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_59, primals_55, primals_57, primals_58, True, 0.1, 0.001);  primals_55 = None
        getitem_147 = native_batch_norm_default_47[0]
        getitem_148 = native_batch_norm_default_47[1]
        getitem_149 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_47 = torch.ops.aten.relu_.default(getitem_147);  getitem_147 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_47, primals_66, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_48 = torch.ops.aten.add_.Tensor(primals_62, 1);  primals_62 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_65, primals_61, primals_63, primals_64, True, 0.1, 0.001);  primals_61 = None
        getitem_150 = native_batch_norm_default_48[0]
        getitem_151 = native_batch_norm_default_48[1]
        getitem_152 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_48 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_48, primals_72, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_49 = torch.ops.aten.add_.Tensor(primals_68, 1);  primals_68 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_71, primals_67, primals_69, primals_70, True, 0.1, 0.001);  primals_67 = None
        getitem_153 = native_batch_norm_default_49[0]
        getitem_154 = native_batch_norm_default_49[1]
        getitem_155 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_49 = torch.ops.aten.relu_.default(getitem_153);  getitem_153 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_49, primals_78, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_50 = torch.ops.aten.add_.Tensor(primals_74, 1);  primals_74 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_77, primals_73, primals_75, primals_76, True, 0.1, 0.001);  primals_73 = None
        getitem_156 = native_batch_norm_default_50[0]
        getitem_157 = native_batch_norm_default_50[1]
        getitem_158 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_50 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_50, primals_84, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_51 = torch.ops.aten.add_.Tensor(primals_80, 1);  primals_80 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_83, primals_79, primals_81, primals_82, True, 0.1, 0.001);  primals_79 = None
        getitem_159 = native_batch_norm_default_51[0]
        getitem_160 = native_batch_norm_default_51[1]
        getitem_161 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_51 = torch.ops.aten.relu_.default(getitem_159);  getitem_159 = None
        avg_pool2d_default_4 = torch.ops.aten.avg_pool2d.default(cat_default_7, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_52 = torch.ops.aten.convolution.default(avg_pool2d_default_4, primals_90, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_52 = torch.ops.aten.add_.Tensor(primals_86, 1);  primals_86 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_89, primals_85, primals_87, primals_88, True, 0.1, 0.001);  primals_85 = None
        getitem_162 = native_batch_norm_default_52[0]
        getitem_163 = native_batch_norm_default_52[1]
        getitem_164 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_52 = torch.ops.aten.relu_.default(getitem_162);  getitem_162 = None
        cat_default_8 = torch.ops.aten.cat.default([relu__default_43, relu__default_46, relu__default_51, relu__default_52], 1)
        convolution_default_53 = torch.ops.aten.convolution.default(cat_default_8, primals_96, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_53 = torch.ops.aten.add_.Tensor(primals_92, 1);  primals_92 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_95, primals_91, primals_93, primals_94, True, 0.1, 0.001);  primals_91 = None
        getitem_165 = native_batch_norm_default_53[0]
        getitem_166 = native_batch_norm_default_53[1]
        getitem_167 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_53 = torch.ops.aten.relu_.default(getitem_165);  getitem_165 = None
        convolution_default_54 = torch.ops.aten.convolution.default(cat_default_8, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_54 = torch.ops.aten.add_.Tensor(primals_98, 1);  primals_98 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_101, primals_97, primals_99, primals_100, True, 0.1, 0.001);  primals_97 = None
        getitem_168 = native_batch_norm_default_54[0]
        getitem_169 = native_batch_norm_default_54[1]
        getitem_170 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_54 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_54, primals_108, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_55 = torch.ops.aten.add_.Tensor(primals_104, 1);  primals_104 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_107, primals_103, primals_105, primals_106, True, 0.1, 0.001);  primals_103 = None
        getitem_171 = native_batch_norm_default_55[0]
        getitem_172 = native_batch_norm_default_55[1]
        getitem_173 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_55 = torch.ops.aten.relu_.default(getitem_171);  getitem_171 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_55, primals_114, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_56 = torch.ops.aten.add_.Tensor(primals_110, 1);  primals_110 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_113, primals_109, primals_111, primals_112, True, 0.1, 0.001);  primals_109 = None
        getitem_174 = native_batch_norm_default_56[0]
        getitem_175 = native_batch_norm_default_56[1]
        getitem_176 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_56 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_57 = torch.ops.aten.convolution.default(cat_default_8, primals_120, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_57 = torch.ops.aten.add_.Tensor(primals_116, 1);  primals_116 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_119, primals_115, primals_117, primals_118, True, 0.1, 0.001);  primals_115 = None
        getitem_177 = native_batch_norm_default_57[0]
        getitem_178 = native_batch_norm_default_57[1]
        getitem_179 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_57 = torch.ops.aten.relu_.default(getitem_177);  getitem_177 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_57, primals_126, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_58 = torch.ops.aten.add_.Tensor(primals_122, 1);  primals_122 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_125, primals_121, primals_123, primals_124, True, 0.1, 0.001);  primals_121 = None
        getitem_180 = native_batch_norm_default_58[0]
        getitem_181 = native_batch_norm_default_58[1]
        getitem_182 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_58 = torch.ops.aten.relu_.default(getitem_180);  getitem_180 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_58, primals_132, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_59 = torch.ops.aten.add_.Tensor(primals_128, 1);  primals_128 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_131, primals_127, primals_129, primals_130, True, 0.1, 0.001);  primals_127 = None
        getitem_183 = native_batch_norm_default_59[0]
        getitem_184 = native_batch_norm_default_59[1]
        getitem_185 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_59 = torch.ops.aten.relu_.default(getitem_183);  getitem_183 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_59, primals_138, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_60 = torch.ops.aten.add_.Tensor(primals_134, 1);  primals_134 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_137, primals_133, primals_135, primals_136, True, 0.1, 0.001);  primals_133 = None
        getitem_186 = native_batch_norm_default_60[0]
        getitem_187 = native_batch_norm_default_60[1]
        getitem_188 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_60 = torch.ops.aten.relu_.default(getitem_186);  getitem_186 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_60, primals_144, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_61 = torch.ops.aten.add_.Tensor(primals_140, 1);  primals_140 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_143, primals_139, primals_141, primals_142, True, 0.1, 0.001);  primals_139 = None
        getitem_189 = native_batch_norm_default_61[0]
        getitem_190 = native_batch_norm_default_61[1]
        getitem_191 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_61 = torch.ops.aten.relu_.default(getitem_189);  getitem_189 = None
        avg_pool2d_default_5 = torch.ops.aten.avg_pool2d.default(cat_default_8, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_62 = torch.ops.aten.convolution.default(avg_pool2d_default_5, primals_150, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_62 = torch.ops.aten.add_.Tensor(primals_146, 1);  primals_146 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_149, primals_145, primals_147, primals_148, True, 0.1, 0.001);  primals_145 = None
        getitem_192 = native_batch_norm_default_62[0]
        getitem_193 = native_batch_norm_default_62[1]
        getitem_194 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_62, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_62 = torch.ops.aten.relu_.default(getitem_192);  getitem_192 = None
        cat_default_9 = torch.ops.aten.cat.default([relu__default_53, relu__default_56, relu__default_61, relu__default_62], 1)
        convolution_default_63 = torch.ops.aten.convolution.default(cat_default_9, primals_156, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_63 = torch.ops.aten.add_.Tensor(primals_152, 1);  primals_152 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_155, primals_151, primals_153, primals_154, True, 0.1, 0.001);  primals_151 = None
        getitem_195 = native_batch_norm_default_63[0]
        getitem_196 = native_batch_norm_default_63[1]
        getitem_197 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_63 = torch.ops.aten.relu_.default(getitem_195);  getitem_195 = None
        convolution_default_64 = torch.ops.aten.convolution.default(cat_default_9, primals_162, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_64 = torch.ops.aten.add_.Tensor(primals_158, 1);  primals_158 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_161, primals_157, primals_159, primals_160, True, 0.1, 0.001);  primals_157 = None
        getitem_198 = native_batch_norm_default_64[0]
        getitem_199 = native_batch_norm_default_64[1]
        getitem_200 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_64 = torch.ops.aten.relu_.default(getitem_198);  getitem_198 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_64, primals_168, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_65 = torch.ops.aten.add_.Tensor(primals_164, 1);  primals_164 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_167, primals_163, primals_165, primals_166, True, 0.1, 0.001);  primals_163 = None
        getitem_201 = native_batch_norm_default_65[0]
        getitem_202 = native_batch_norm_default_65[1]
        getitem_203 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(convolution_default_65, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_65 = torch.ops.aten.relu_.default(getitem_201);  getitem_201 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_65, primals_174, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_66 = torch.ops.aten.add_.Tensor(primals_170, 1);  primals_170 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_66, primals_173, primals_169, primals_171, primals_172, True, 0.1, 0.001);  primals_169 = None
        getitem_204 = native_batch_norm_default_66[0]
        getitem_205 = native_batch_norm_default_66[1]
        getitem_206 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(convolution_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_66 = torch.ops.aten.relu_.default(getitem_204);  getitem_204 = None
        convolution_default_67 = torch.ops.aten.convolution.default(cat_default_9, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_67 = torch.ops.aten.add_.Tensor(primals_176, 1);  primals_176 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_179, primals_175, primals_177, primals_178, True, 0.1, 0.001);  primals_175 = None
        getitem_207 = native_batch_norm_default_67[0]
        getitem_208 = native_batch_norm_default_67[1]
        getitem_209 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(convolution_default_67, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_67 = torch.ops.aten.relu_.default(getitem_207);  getitem_207 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_67, primals_186, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_68 = torch.ops.aten.add_.Tensor(primals_182, 1);  primals_182 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_185, primals_181, primals_183, primals_184, True, 0.1, 0.001);  primals_181 = None
        getitem_210 = native_batch_norm_default_68[0]
        getitem_211 = native_batch_norm_default_68[1]
        getitem_212 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(convolution_default_68, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_68 = torch.ops.aten.relu_.default(getitem_210);  getitem_210 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_68, primals_192, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_69 = torch.ops.aten.add_.Tensor(primals_188, 1);  primals_188 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_69, primals_191, primals_187, primals_189, primals_190, True, 0.1, 0.001);  primals_187 = None
        getitem_213 = native_batch_norm_default_69[0]
        getitem_214 = native_batch_norm_default_69[1]
        getitem_215 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(convolution_default_69, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_69 = torch.ops.aten.relu_.default(getitem_213);  getitem_213 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_69, primals_198, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_70 = torch.ops.aten.add_.Tensor(primals_194, 1);  primals_194 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_197, primals_193, primals_195, primals_196, True, 0.1, 0.001);  primals_193 = None
        getitem_216 = native_batch_norm_default_70[0]
        getitem_217 = native_batch_norm_default_70[1]
        getitem_218 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(convolution_default_70, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_70 = torch.ops.aten.relu_.default(getitem_216);  getitem_216 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_70, primals_204, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_71 = torch.ops.aten.add_.Tensor(primals_200, 1);  primals_200 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_203, primals_199, primals_201, primals_202, True, 0.1, 0.001);  primals_199 = None
        getitem_219 = native_batch_norm_default_71[0]
        getitem_220 = native_batch_norm_default_71[1]
        getitem_221 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(convolution_default_71, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_71 = torch.ops.aten.relu_.default(getitem_219);  getitem_219 = None
        avg_pool2d_default_6 = torch.ops.aten.avg_pool2d.default(cat_default_9, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_72 = torch.ops.aten.convolution.default(avg_pool2d_default_6, primals_210, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_72 = torch.ops.aten.add_.Tensor(primals_206, 1);  primals_206 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_72, primals_209, primals_205, primals_207, primals_208, True, 0.1, 0.001);  primals_205 = None
        getitem_222 = native_batch_norm_default_72[0]
        getitem_223 = native_batch_norm_default_72[1]
        getitem_224 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(convolution_default_72, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_72 = torch.ops.aten.relu_.default(getitem_222);  getitem_222 = None
        cat_default_10 = torch.ops.aten.cat.default([relu__default_63, relu__default_66, relu__default_71, relu__default_72], 1)
        convolution_default_73 = torch.ops.aten.convolution.default(cat_default_10, primals_216, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_73 = torch.ops.aten.add_.Tensor(primals_212, 1);  primals_212 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_215, primals_211, primals_213, primals_214, True, 0.1, 0.001);  primals_211 = None
        getitem_225 = native_batch_norm_default_73[0]
        getitem_226 = native_batch_norm_default_73[1]
        getitem_227 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(convolution_default_73, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_73 = torch.ops.aten.relu_.default(getitem_225);  getitem_225 = None
        convolution_default_74 = torch.ops.aten.convolution.default(cat_default_10, primals_222, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_74 = torch.ops.aten.add_.Tensor(primals_218, 1);  primals_218 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_221, primals_217, primals_219, primals_220, True, 0.1, 0.001);  primals_217 = None
        getitem_228 = native_batch_norm_default_74[0]
        getitem_229 = native_batch_norm_default_74[1]
        getitem_230 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(convolution_default_74, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_74 = torch.ops.aten.relu_.default(getitem_228);  getitem_228 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_74, primals_228, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_75 = torch.ops.aten.add_.Tensor(primals_224, 1);  primals_224 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_75, primals_227, primals_223, primals_225, primals_226, True, 0.1, 0.001);  primals_223 = None
        getitem_231 = native_batch_norm_default_75[0]
        getitem_232 = native_batch_norm_default_75[1]
        getitem_233 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(convolution_default_75, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_75 = torch.ops.aten.relu_.default(getitem_231);  getitem_231 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_75, primals_234, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_76 = torch.ops.aten.add_.Tensor(primals_230, 1);  primals_230 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_233, primals_229, primals_231, primals_232, True, 0.1, 0.001);  primals_229 = None
        getitem_234 = native_batch_norm_default_76[0]
        getitem_235 = native_batch_norm_default_76[1]
        getitem_236 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(convolution_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_76 = torch.ops.aten.relu_.default(getitem_234);  getitem_234 = None
        convolution_default_77 = torch.ops.aten.convolution.default(cat_default_10, primals_240, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_77 = torch.ops.aten.add_.Tensor(primals_236, 1);  primals_236 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_239, primals_235, primals_237, primals_238, True, 0.1, 0.001);  primals_235 = None
        getitem_237 = native_batch_norm_default_77[0]
        getitem_238 = native_batch_norm_default_77[1]
        getitem_239 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(convolution_default_77, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_77 = torch.ops.aten.relu_.default(getitem_237);  getitem_237 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_77, primals_246, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_78 = torch.ops.aten.add_.Tensor(primals_242, 1);  primals_242 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_78, primals_245, primals_241, primals_243, primals_244, True, 0.1, 0.001);  primals_241 = None
        getitem_240 = native_batch_norm_default_78[0]
        getitem_241 = native_batch_norm_default_78[1]
        getitem_242 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(convolution_default_78, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_78 = torch.ops.aten.relu_.default(getitem_240);  getitem_240 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_78, primals_252, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_79 = torch.ops.aten.add_.Tensor(primals_248, 1);  primals_248 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_251, primals_247, primals_249, primals_250, True, 0.1, 0.001);  primals_247 = None
        getitem_243 = native_batch_norm_default_79[0]
        getitem_244 = native_batch_norm_default_79[1]
        getitem_245 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(convolution_default_79, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_79 = torch.ops.aten.relu_.default(getitem_243);  getitem_243 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_79, primals_258, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_80 = torch.ops.aten.add_.Tensor(primals_254, 1);  primals_254 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_257, primals_253, primals_255, primals_256, True, 0.1, 0.001);  primals_253 = None
        getitem_246 = native_batch_norm_default_80[0]
        getitem_247 = native_batch_norm_default_80[1]
        getitem_248 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_80 = torch.ops.aten.relu_.default(getitem_246);  getitem_246 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_80, primals_264, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_81 = torch.ops.aten.add_.Tensor(primals_260, 1);  primals_260 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_81, primals_263, primals_259, primals_261, primals_262, True, 0.1, 0.001);  primals_259 = None
        getitem_249 = native_batch_norm_default_81[0]
        getitem_250 = native_batch_norm_default_81[1]
        getitem_251 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(convolution_default_81, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_81 = torch.ops.aten.relu_.default(getitem_249);  getitem_249 = None
        avg_pool2d_default_7 = torch.ops.aten.avg_pool2d.default(cat_default_10, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_82 = torch.ops.aten.convolution.default(avg_pool2d_default_7, primals_270, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_82 = torch.ops.aten.add_.Tensor(primals_266, 1);  primals_266 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_269, primals_265, primals_267, primals_268, True, 0.1, 0.001);  primals_265 = None
        getitem_252 = native_batch_norm_default_82[0]
        getitem_253 = native_batch_norm_default_82[1]
        getitem_254 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(convolution_default_82, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_82 = torch.ops.aten.relu_.default(getitem_252);  getitem_252 = None
        cat_default_11 = torch.ops.aten.cat.default([relu__default_73, relu__default_76, relu__default_81, relu__default_82], 1)
        convolution_default_83 = torch.ops.aten.convolution.default(cat_default_11, primals_276, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_83 = torch.ops.aten.add_.Tensor(primals_272, 1);  primals_272 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_275, primals_271, primals_273, primals_274, True, 0.1, 0.001);  primals_271 = None
        getitem_255 = native_batch_norm_default_83[0]
        getitem_256 = native_batch_norm_default_83[1]
        getitem_257 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(convolution_default_83, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_83 = torch.ops.aten.relu_.default(getitem_255);  getitem_255 = None
        convolution_default_84 = torch.ops.aten.convolution.default(cat_default_11, primals_282, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_84 = torch.ops.aten.add_.Tensor(primals_278, 1);  primals_278 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_281, primals_277, primals_279, primals_280, True, 0.1, 0.001);  primals_277 = None
        getitem_258 = native_batch_norm_default_84[0]
        getitem_259 = native_batch_norm_default_84[1]
        getitem_260 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_84 = torch.ops.aten.relu_.default(getitem_258);  getitem_258 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_84, primals_288, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_85 = torch.ops.aten.add_.Tensor(primals_284, 1);  primals_284 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_287, primals_283, primals_285, primals_286, True, 0.1, 0.001);  primals_283 = None
        getitem_261 = native_batch_norm_default_85[0]
        getitem_262 = native_batch_norm_default_85[1]
        getitem_263 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_85 = torch.ops.aten.relu_.default(getitem_261);  getitem_261 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_85, primals_294, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_86 = torch.ops.aten.add_.Tensor(primals_290, 1);  primals_290 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_293, primals_289, primals_291, primals_292, True, 0.1, 0.001);  primals_289 = None
        getitem_264 = native_batch_norm_default_86[0]
        getitem_265 = native_batch_norm_default_86[1]
        getitem_266 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(convolution_default_86, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_86 = torch.ops.aten.relu_.default(getitem_264);  getitem_264 = None
        convolution_default_87 = torch.ops.aten.convolution.default(cat_default_11, primals_300, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_87 = torch.ops.aten.add_.Tensor(primals_296, 1);  primals_296 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_87, primals_299, primals_295, primals_297, primals_298, True, 0.1, 0.001);  primals_295 = None
        getitem_267 = native_batch_norm_default_87[0]
        getitem_268 = native_batch_norm_default_87[1]
        getitem_269 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(convolution_default_87, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_87 = torch.ops.aten.relu_.default(getitem_267);  getitem_267 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_87, primals_306, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_88 = torch.ops.aten.add_.Tensor(primals_302, 1);  primals_302 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_305, primals_301, primals_303, primals_304, True, 0.1, 0.001);  primals_301 = None
        getitem_270 = native_batch_norm_default_88[0]
        getitem_271 = native_batch_norm_default_88[1]
        getitem_272 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_88 = torch.ops.aten.relu_.default(getitem_270);  getitem_270 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_88, primals_312, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_89 = torch.ops.aten.add_.Tensor(primals_308, 1);  primals_308 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_311, primals_307, primals_309, primals_310, True, 0.1, 0.001);  primals_307 = None
        getitem_273 = native_batch_norm_default_89[0]
        getitem_274 = native_batch_norm_default_89[1]
        getitem_275 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(convolution_default_89, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_89 = torch.ops.aten.relu_.default(getitem_273);  getitem_273 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_89, primals_318, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_90 = torch.ops.aten.add_.Tensor(primals_314, 1);  primals_314 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_90, primals_317, primals_313, primals_315, primals_316, True, 0.1, 0.001);  primals_313 = None
        getitem_276 = native_batch_norm_default_90[0]
        getitem_277 = native_batch_norm_default_90[1]
        getitem_278 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(convolution_default_90, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_90 = torch.ops.aten.relu_.default(getitem_276);  getitem_276 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_90, primals_324, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_91 = torch.ops.aten.add_.Tensor(primals_320, 1);  primals_320 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_323, primals_319, primals_321, primals_322, True, 0.1, 0.001);  primals_319 = None
        getitem_279 = native_batch_norm_default_91[0]
        getitem_280 = native_batch_norm_default_91[1]
        getitem_281 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(convolution_default_91, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_91 = torch.ops.aten.relu_.default(getitem_279);  getitem_279 = None
        avg_pool2d_default_8 = torch.ops.aten.avg_pool2d.default(cat_default_11, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_92 = torch.ops.aten.convolution.default(avg_pool2d_default_8, primals_330, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_92 = torch.ops.aten.add_.Tensor(primals_326, 1);  primals_326 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_329, primals_325, primals_327, primals_328, True, 0.1, 0.001);  primals_325 = None
        getitem_282 = native_batch_norm_default_92[0]
        getitem_283 = native_batch_norm_default_92[1]
        getitem_284 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(convolution_default_92, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_92 = torch.ops.aten.relu_.default(getitem_282);  getitem_282 = None
        cat_default_12 = torch.ops.aten.cat.default([relu__default_83, relu__default_86, relu__default_91, relu__default_92], 1)
        convolution_default_93 = torch.ops.aten.convolution.default(cat_default_12, primals_336, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_93 = torch.ops.aten.add_.Tensor(primals_332, 1);  primals_332 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_93, primals_335, primals_331, primals_333, primals_334, True, 0.1, 0.001);  primals_331 = None
        getitem_285 = native_batch_norm_default_93[0]
        getitem_286 = native_batch_norm_default_93[1]
        getitem_287 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(convolution_default_93, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_93 = torch.ops.aten.relu_.default(getitem_285);  getitem_285 = None
        convolution_default_94 = torch.ops.aten.convolution.default(cat_default_12, primals_342, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_94 = torch.ops.aten.add_.Tensor(primals_338, 1);  primals_338 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_341, primals_337, primals_339, primals_340, True, 0.1, 0.001);  primals_337 = None
        getitem_288 = native_batch_norm_default_94[0]
        getitem_289 = native_batch_norm_default_94[1]
        getitem_290 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(convolution_default_94, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_94 = torch.ops.aten.relu_.default(getitem_288);  getitem_288 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_94, primals_348, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_95 = torch.ops.aten.add_.Tensor(primals_344, 1);  primals_344 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_347, primals_343, primals_345, primals_346, True, 0.1, 0.001);  primals_343 = None
        getitem_291 = native_batch_norm_default_95[0]
        getitem_292 = native_batch_norm_default_95[1]
        getitem_293 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(convolution_default_95, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_95 = torch.ops.aten.relu_.default(getitem_291);  getitem_291 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_95, primals_354, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_96 = torch.ops.aten.add_.Tensor(primals_350, 1);  primals_350 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_96, primals_353, primals_349, primals_351, primals_352, True, 0.1, 0.001);  primals_349 = None
        getitem_294 = native_batch_norm_default_96[0]
        getitem_295 = native_batch_norm_default_96[1]
        getitem_296 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(convolution_default_96, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_96 = torch.ops.aten.relu_.default(getitem_294);  getitem_294 = None
        convolution_default_97 = torch.ops.aten.convolution.default(cat_default_12, primals_360, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_97 = torch.ops.aten.add_.Tensor(primals_356, 1);  primals_356 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_359, primals_355, primals_357, primals_358, True, 0.1, 0.001);  primals_355 = None
        getitem_297 = native_batch_norm_default_97[0]
        getitem_298 = native_batch_norm_default_97[1]
        getitem_299 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(convolution_default_97, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_97 = torch.ops.aten.relu_.default(getitem_297);  getitem_297 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_97, primals_366, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_98 = torch.ops.aten.add_.Tensor(primals_362, 1);  primals_362 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_365, primals_361, primals_363, primals_364, True, 0.1, 0.001);  primals_361 = None
        getitem_300 = native_batch_norm_default_98[0]
        getitem_301 = native_batch_norm_default_98[1]
        getitem_302 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(convolution_default_98, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_98 = torch.ops.aten.relu_.default(getitem_300);  getitem_300 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_98, primals_372, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_99 = torch.ops.aten.add_.Tensor(primals_368, 1);  primals_368 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_99, primals_371, primals_367, primals_369, primals_370, True, 0.1, 0.001);  primals_367 = None
        getitem_303 = native_batch_norm_default_99[0]
        getitem_304 = native_batch_norm_default_99[1]
        getitem_305 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(convolution_default_99, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_99 = torch.ops.aten.relu_.default(getitem_303);  getitem_303 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_99, primals_378, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_100 = torch.ops.aten.add_.Tensor(primals_374, 1);  primals_374 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(convolution_default_100, primals_377, primals_373, primals_375, primals_376, True, 0.1, 0.001);  primals_373 = None
        getitem_306 = native_batch_norm_default_100[0]
        getitem_307 = native_batch_norm_default_100[1]
        getitem_308 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(convolution_default_100, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_100 = torch.ops.aten.relu_.default(getitem_306);  getitem_306 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_100, primals_384, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_101 = torch.ops.aten.add_.Tensor(primals_380, 1);  primals_380 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_383, primals_379, primals_381, primals_382, True, 0.1, 0.001);  primals_379 = None
        getitem_309 = native_batch_norm_default_101[0]
        getitem_310 = native_batch_norm_default_101[1]
        getitem_311 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(convolution_default_101, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_101 = torch.ops.aten.relu_.default(getitem_309);  getitem_309 = None
        avg_pool2d_default_9 = torch.ops.aten.avg_pool2d.default(cat_default_12, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_102 = torch.ops.aten.convolution.default(avg_pool2d_default_9, primals_390, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_102 = torch.ops.aten.add_.Tensor(primals_386, 1);  primals_386 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_389, primals_385, primals_387, primals_388, True, 0.1, 0.001);  primals_385 = None
        getitem_312 = native_batch_norm_default_102[0]
        getitem_313 = native_batch_norm_default_102[1]
        getitem_314 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(convolution_default_102, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_102 = torch.ops.aten.relu_.default(getitem_312);  getitem_312 = None
        cat_default_13 = torch.ops.aten.cat.default([relu__default_93, relu__default_96, relu__default_101, relu__default_102], 1)
        convolution_default_103 = torch.ops.aten.convolution.default(cat_default_13, primals_396, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_103 = torch.ops.aten.add_.Tensor(primals_392, 1);  primals_392 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_103, primals_395, primals_391, primals_393, primals_394, True, 0.1, 0.001);  primals_391 = None
        getitem_315 = native_batch_norm_default_103[0]
        getitem_316 = native_batch_norm_default_103[1]
        getitem_317 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(convolution_default_103, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_103 = torch.ops.aten.relu_.default(getitem_315);  getitem_315 = None
        convolution_default_104 = torch.ops.aten.convolution.default(cat_default_13, primals_402, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_104 = torch.ops.aten.add_.Tensor(primals_398, 1);  primals_398 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_401, primals_397, primals_399, primals_400, True, 0.1, 0.001);  primals_397 = None
        getitem_318 = native_batch_norm_default_104[0]
        getitem_319 = native_batch_norm_default_104[1]
        getitem_320 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(convolution_default_104, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_104 = torch.ops.aten.relu_.default(getitem_318);  getitem_318 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_104, primals_408, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_105 = torch.ops.aten.add_.Tensor(primals_404, 1);  primals_404 = None
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_407, primals_403, primals_405, primals_406, True, 0.1, 0.001);  primals_403 = None
        getitem_321 = native_batch_norm_default_105[0]
        getitem_322 = native_batch_norm_default_105[1]
        getitem_323 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(convolution_default_105, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_105 = torch.ops.aten.relu_.default(getitem_321);  getitem_321 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_105, primals_414, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_106 = torch.ops.aten.add_.Tensor(primals_410, 1);  primals_410 = None
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_106, primals_413, primals_409, primals_411, primals_412, True, 0.1, 0.001);  primals_409 = None
        getitem_324 = native_batch_norm_default_106[0]
        getitem_325 = native_batch_norm_default_106[1]
        getitem_326 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(convolution_default_106, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_106 = torch.ops.aten.relu_.default(getitem_324);  getitem_324 = None
        convolution_default_107 = torch.ops.aten.convolution.default(cat_default_13, primals_420, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_107 = torch.ops.aten.add_.Tensor(primals_416, 1);  primals_416 = None
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_419, primals_415, primals_417, primals_418, True, 0.1, 0.001);  primals_415 = None
        getitem_327 = native_batch_norm_default_107[0]
        getitem_328 = native_batch_norm_default_107[1]
        getitem_329 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(convolution_default_107, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_107 = torch.ops.aten.relu_.default(getitem_327);  getitem_327 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_107, primals_426, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_108 = torch.ops.aten.add_.Tensor(primals_422, 1);  primals_422 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_425, primals_421, primals_423, primals_424, True, 0.1, 0.001);  primals_421 = None
        getitem_330 = native_batch_norm_default_108[0]
        getitem_331 = native_batch_norm_default_108[1]
        getitem_332 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(convolution_default_108, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_108 = torch.ops.aten.relu_.default(getitem_330);  getitem_330 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_108, primals_432, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_109 = torch.ops.aten.add_.Tensor(primals_428, 1);  primals_428 = None
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_109, primals_431, primals_427, primals_429, primals_430, True, 0.1, 0.001);  primals_427 = None
        getitem_333 = native_batch_norm_default_109[0]
        getitem_334 = native_batch_norm_default_109[1]
        getitem_335 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(convolution_default_109, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_109 = torch.ops.aten.relu_.default(getitem_333);  getitem_333 = None
        convolution_default_110 = torch.ops.aten.convolution.default(relu__default_109, primals_438, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_110 = torch.ops.aten.add_.Tensor(primals_434, 1);  primals_434 = None
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(convolution_default_110, primals_437, primals_433, primals_435, primals_436, True, 0.1, 0.001);  primals_433 = None
        getitem_336 = native_batch_norm_default_110[0]
        getitem_337 = native_batch_norm_default_110[1]
        getitem_338 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(convolution_default_110, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_110 = torch.ops.aten.relu_.default(getitem_336);  getitem_336 = None
        convolution_default_111 = torch.ops.aten.convolution.default(relu__default_110, primals_444, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_111 = torch.ops.aten.add_.Tensor(primals_440, 1);  primals_440 = None
        native_batch_norm_default_111 = torch.ops.aten.native_batch_norm.default(convolution_default_111, primals_443, primals_439, primals_441, primals_442, True, 0.1, 0.001);  primals_439 = None
        getitem_339 = native_batch_norm_default_111[0]
        getitem_340 = native_batch_norm_default_111[1]
        getitem_341 = native_batch_norm_default_111[2];  native_batch_norm_default_111 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(convolution_default_111, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_111 = torch.ops.aten.relu_.default(getitem_339);  getitem_339 = None
        avg_pool2d_default_10 = torch.ops.aten.avg_pool2d.default(cat_default_13, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_112 = torch.ops.aten.convolution.default(avg_pool2d_default_10, primals_450, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_112 = torch.ops.aten.add_.Tensor(primals_446, 1);  primals_446 = None
        native_batch_norm_default_112 = torch.ops.aten.native_batch_norm.default(convolution_default_112, primals_449, primals_445, primals_447, primals_448, True, 0.1, 0.001);  primals_445 = None
        getitem_342 = native_batch_norm_default_112[0]
        getitem_343 = native_batch_norm_default_112[1]
        getitem_344 = native_batch_norm_default_112[2];  native_batch_norm_default_112 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(convolution_default_112, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_112 = torch.ops.aten.relu_.default(getitem_342);  getitem_342 = None
        cat_default_14 = torch.ops.aten.cat.default([relu__default_103, relu__default_106, relu__default_111, relu__default_112], 1)
        convolution_default_113 = torch.ops.aten.convolution.default(cat_default_14, primals_456, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_113 = torch.ops.aten.add_.Tensor(primals_452, 1);  primals_452 = None
        native_batch_norm_default_113 = torch.ops.aten.native_batch_norm.default(convolution_default_113, primals_455, primals_451, primals_453, primals_454, True, 0.1, 0.001);  primals_451 = None
        getitem_345 = native_batch_norm_default_113[0]
        getitem_346 = native_batch_norm_default_113[1]
        getitem_347 = native_batch_norm_default_113[2];  native_batch_norm_default_113 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(convolution_default_113, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_113 = torch.ops.aten.relu_.default(getitem_345);  getitem_345 = None
        convolution_default_114 = torch.ops.aten.convolution.default(relu__default_113, primals_462, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_114 = torch.ops.aten.add_.Tensor(primals_458, 1);  primals_458 = None
        native_batch_norm_default_114 = torch.ops.aten.native_batch_norm.default(convolution_default_114, primals_461, primals_457, primals_459, primals_460, True, 0.1, 0.001);  primals_457 = None
        getitem_348 = native_batch_norm_default_114[0]
        getitem_349 = native_batch_norm_default_114[1]
        getitem_350 = native_batch_norm_default_114[2];  native_batch_norm_default_114 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(convolution_default_114, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_114 = torch.ops.aten.relu_.default(getitem_348);  getitem_348 = None
        convolution_default_115 = torch.ops.aten.convolution.default(cat_default_14, primals_468, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_115 = torch.ops.aten.add_.Tensor(primals_464, 1);  primals_464 = None
        native_batch_norm_default_115 = torch.ops.aten.native_batch_norm.default(convolution_default_115, primals_467, primals_463, primals_465, primals_466, True, 0.1, 0.001);  primals_463 = None
        getitem_351 = native_batch_norm_default_115[0]
        getitem_352 = native_batch_norm_default_115[1]
        getitem_353 = native_batch_norm_default_115[2];  native_batch_norm_default_115 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(convolution_default_115, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_115 = torch.ops.aten.relu_.default(getitem_351);  getitem_351 = None
        convolution_default_116 = torch.ops.aten.convolution.default(relu__default_115, primals_474, None, [1, 1], [0, 3], [1, 1], False, [0, 0], 1)
        add__tensor_116 = torch.ops.aten.add_.Tensor(primals_470, 1);  primals_470 = None
        native_batch_norm_default_116 = torch.ops.aten.native_batch_norm.default(convolution_default_116, primals_473, primals_469, primals_471, primals_472, True, 0.1, 0.001);  primals_469 = None
        getitem_354 = native_batch_norm_default_116[0]
        getitem_355 = native_batch_norm_default_116[1]
        getitem_356 = native_batch_norm_default_116[2];  native_batch_norm_default_116 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(convolution_default_116, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_116 = torch.ops.aten.relu_.default(getitem_354);  getitem_354 = None
        convolution_default_117 = torch.ops.aten.convolution.default(relu__default_116, primals_480, None, [1, 1], [3, 0], [1, 1], False, [0, 0], 1)
        add__tensor_117 = torch.ops.aten.add_.Tensor(primals_476, 1);  primals_476 = None
        native_batch_norm_default_117 = torch.ops.aten.native_batch_norm.default(convolution_default_117, primals_479, primals_475, primals_477, primals_478, True, 0.1, 0.001);  primals_475 = None
        getitem_357 = native_batch_norm_default_117[0]
        getitem_358 = native_batch_norm_default_117[1]
        getitem_359 = native_batch_norm_default_117[2];  native_batch_norm_default_117 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(convolution_default_117, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_117 = torch.ops.aten.relu_.default(getitem_357);  getitem_357 = None
        convolution_default_118 = torch.ops.aten.convolution.default(relu__default_117, primals_486, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_118 = torch.ops.aten.add_.Tensor(primals_482, 1);  primals_482 = None
        native_batch_norm_default_118 = torch.ops.aten.native_batch_norm.default(convolution_default_118, primals_485, primals_481, primals_483, primals_484, True, 0.1, 0.001);  primals_481 = None
        getitem_360 = native_batch_norm_default_118[0]
        getitem_361 = native_batch_norm_default_118[1]
        getitem_362 = native_batch_norm_default_118[2];  native_batch_norm_default_118 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(convolution_default_118, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_118 = torch.ops.aten.relu_.default(getitem_360);  getitem_360 = None
        max_pool2d_with_indices_default_3 = torch.ops.aten.max_pool2d_with_indices.default(cat_default_14, [3, 3], [2, 2])
        getitem_363 = max_pool2d_with_indices_default_3[0]
        getitem_364 = max_pool2d_with_indices_default_3[1];  max_pool2d_with_indices_default_3 = None
        cat_default_15 = torch.ops.aten.cat.default([relu__default_114, relu__default_118, getitem_363], 1);  getitem_363 = None
        convolution_default_119 = torch.ops.aten.convolution.default(cat_default_15, primals_492, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_119 = torch.ops.aten.add_.Tensor(primals_488, 1);  primals_488 = None
        native_batch_norm_default_119 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_491, primals_487, primals_489, primals_490, True, 0.1, 0.001);  primals_487 = None
        getitem_365 = native_batch_norm_default_119[0]
        getitem_366 = native_batch_norm_default_119[1]
        getitem_367 = native_batch_norm_default_119[2];  native_batch_norm_default_119 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_119 = torch.ops.aten.relu_.default(getitem_365);  getitem_365 = None
        convolution_default_120 = torch.ops.aten.convolution.default(cat_default_15, primals_498, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_120 = torch.ops.aten.add_.Tensor(primals_494, 1);  primals_494 = None
        native_batch_norm_default_120 = torch.ops.aten.native_batch_norm.default(convolution_default_120, primals_497, primals_493, primals_495, primals_496, True, 0.1, 0.001);  primals_493 = None
        getitem_368 = native_batch_norm_default_120[0]
        getitem_369 = native_batch_norm_default_120[1]
        getitem_370 = native_batch_norm_default_120[2];  native_batch_norm_default_120 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(convolution_default_120, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_120 = torch.ops.aten.relu_.default(getitem_368);  getitem_368 = None
        convolution_default_121 = torch.ops.aten.convolution.default(relu__default_120, primals_504, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_121 = torch.ops.aten.add_.Tensor(primals_500, 1);  primals_500 = None
        native_batch_norm_default_121 = torch.ops.aten.native_batch_norm.default(convolution_default_121, primals_503, primals_499, primals_501, primals_502, True, 0.1, 0.001);  primals_499 = None
        getitem_371 = native_batch_norm_default_121[0]
        getitem_372 = native_batch_norm_default_121[1]
        getitem_373 = native_batch_norm_default_121[2];  native_batch_norm_default_121 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(convolution_default_121, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_121 = torch.ops.aten.relu_.default(getitem_371);  getitem_371 = None
        convolution_default_122 = torch.ops.aten.convolution.default(relu__default_120, primals_510, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_122 = torch.ops.aten.add_.Tensor(primals_506, 1);  primals_506 = None
        native_batch_norm_default_122 = torch.ops.aten.native_batch_norm.default(convolution_default_122, primals_509, primals_505, primals_507, primals_508, True, 0.1, 0.001);  primals_505 = None
        getitem_374 = native_batch_norm_default_122[0]
        getitem_375 = native_batch_norm_default_122[1]
        getitem_376 = native_batch_norm_default_122[2];  native_batch_norm_default_122 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(convolution_default_122, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_122 = torch.ops.aten.relu_.default(getitem_374);  getitem_374 = None
        cat_default_16 = torch.ops.aten.cat.default([relu__default_121, relu__default_122], 1)
        convolution_default_123 = torch.ops.aten.convolution.default(cat_default_15, primals_516, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_123 = torch.ops.aten.add_.Tensor(primals_512, 1);  primals_512 = None
        native_batch_norm_default_123 = torch.ops.aten.native_batch_norm.default(convolution_default_123, primals_515, primals_511, primals_513, primals_514, True, 0.1, 0.001);  primals_511 = None
        getitem_377 = native_batch_norm_default_123[0]
        getitem_378 = native_batch_norm_default_123[1]
        getitem_379 = native_batch_norm_default_123[2];  native_batch_norm_default_123 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(convolution_default_123, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_123 = torch.ops.aten.relu_.default(getitem_377);  getitem_377 = None
        convolution_default_124 = torch.ops.aten.convolution.default(relu__default_123, primals_522, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_124 = torch.ops.aten.add_.Tensor(primals_518, 1);  primals_518 = None
        native_batch_norm_default_124 = torch.ops.aten.native_batch_norm.default(convolution_default_124, primals_521, primals_517, primals_519, primals_520, True, 0.1, 0.001);  primals_517 = None
        getitem_380 = native_batch_norm_default_124[0]
        getitem_381 = native_batch_norm_default_124[1]
        getitem_382 = native_batch_norm_default_124[2];  native_batch_norm_default_124 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(convolution_default_124, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_124 = torch.ops.aten.relu_.default(getitem_380);  getitem_380 = None
        convolution_default_125 = torch.ops.aten.convolution.default(relu__default_124, primals_528, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_125 = torch.ops.aten.add_.Tensor(primals_524, 1);  primals_524 = None
        native_batch_norm_default_125 = torch.ops.aten.native_batch_norm.default(convolution_default_125, primals_527, primals_523, primals_525, primals_526, True, 0.1, 0.001);  primals_523 = None
        getitem_383 = native_batch_norm_default_125[0]
        getitem_384 = native_batch_norm_default_125[1]
        getitem_385 = native_batch_norm_default_125[2];  native_batch_norm_default_125 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(convolution_default_125, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_125 = torch.ops.aten.relu_.default(getitem_383);  getitem_383 = None
        convolution_default_126 = torch.ops.aten.convolution.default(relu__default_125, primals_534, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_126 = torch.ops.aten.add_.Tensor(primals_530, 1);  primals_530 = None
        native_batch_norm_default_126 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_533, primals_529, primals_531, primals_532, True, 0.1, 0.001);  primals_529 = None
        getitem_386 = native_batch_norm_default_126[0]
        getitem_387 = native_batch_norm_default_126[1]
        getitem_388 = native_batch_norm_default_126[2];  native_batch_norm_default_126 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_126 = torch.ops.aten.relu_.default(getitem_386);  getitem_386 = None
        convolution_default_127 = torch.ops.aten.convolution.default(relu__default_125, primals_540, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_127 = torch.ops.aten.add_.Tensor(primals_536, 1);  primals_536 = None
        native_batch_norm_default_127 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_539, primals_535, primals_537, primals_538, True, 0.1, 0.001);  primals_535 = None
        getitem_389 = native_batch_norm_default_127[0]
        getitem_390 = native_batch_norm_default_127[1]
        getitem_391 = native_batch_norm_default_127[2];  native_batch_norm_default_127 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(convolution_default_127, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_127 = torch.ops.aten.relu_.default(getitem_389);  getitem_389 = None
        cat_default_17 = torch.ops.aten.cat.default([relu__default_126, relu__default_127], 1)
        avg_pool2d_default_11 = torch.ops.aten.avg_pool2d.default(cat_default_15, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_128 = torch.ops.aten.convolution.default(avg_pool2d_default_11, primals_546, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_128 = torch.ops.aten.add_.Tensor(primals_542, 1);  primals_542 = None
        native_batch_norm_default_128 = torch.ops.aten.native_batch_norm.default(convolution_default_128, primals_545, primals_541, primals_543, primals_544, True, 0.1, 0.001);  primals_541 = None
        getitem_392 = native_batch_norm_default_128[0]
        getitem_393 = native_batch_norm_default_128[1]
        getitem_394 = native_batch_norm_default_128[2];  native_batch_norm_default_128 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(convolution_default_128, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_128 = torch.ops.aten.relu_.default(getitem_392);  getitem_392 = None
        cat_default_18 = torch.ops.aten.cat.default([relu__default_119, cat_default_16, cat_default_17, relu__default_128], 1);  cat_default_16 = cat_default_17 = None
        convolution_default_129 = torch.ops.aten.convolution.default(cat_default_18, primals_558, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_129 = torch.ops.aten.add_.Tensor(primals_554, 1);  primals_554 = None
        native_batch_norm_default_129 = torch.ops.aten.native_batch_norm.default(convolution_default_129, primals_557, primals_553, primals_555, primals_556, True, 0.1, 0.001);  primals_553 = None
        getitem_395 = native_batch_norm_default_129[0]
        getitem_396 = native_batch_norm_default_129[1]
        getitem_397 = native_batch_norm_default_129[2];  native_batch_norm_default_129 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(convolution_default_129, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_129 = torch.ops.aten.relu_.default(getitem_395);  getitem_395 = None
        convolution_default_130 = torch.ops.aten.convolution.default(cat_default_18, primals_564, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_130 = torch.ops.aten.add_.Tensor(primals_560, 1);  primals_560 = None
        native_batch_norm_default_130 = torch.ops.aten.native_batch_norm.default(convolution_default_130, primals_563, primals_559, primals_561, primals_562, True, 0.1, 0.001);  primals_559 = None
        getitem_398 = native_batch_norm_default_130[0]
        getitem_399 = native_batch_norm_default_130[1]
        getitem_400 = native_batch_norm_default_130[2];  native_batch_norm_default_130 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(convolution_default_130, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_130 = torch.ops.aten.relu_.default(getitem_398);  getitem_398 = None
        convolution_default_131 = torch.ops.aten.convolution.default(relu__default_130, primals_570, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_131 = torch.ops.aten.add_.Tensor(primals_566, 1);  primals_566 = None
        native_batch_norm_default_131 = torch.ops.aten.native_batch_norm.default(convolution_default_131, primals_569, primals_565, primals_567, primals_568, True, 0.1, 0.001);  primals_565 = None
        getitem_401 = native_batch_norm_default_131[0]
        getitem_402 = native_batch_norm_default_131[1]
        getitem_403 = native_batch_norm_default_131[2];  native_batch_norm_default_131 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(convolution_default_131, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_131 = torch.ops.aten.relu_.default(getitem_401);  getitem_401 = None
        convolution_default_132 = torch.ops.aten.convolution.default(relu__default_130, primals_576, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_132 = torch.ops.aten.add_.Tensor(primals_572, 1);  primals_572 = None
        native_batch_norm_default_132 = torch.ops.aten.native_batch_norm.default(convolution_default_132, primals_575, primals_571, primals_573, primals_574, True, 0.1, 0.001);  primals_571 = None
        getitem_404 = native_batch_norm_default_132[0]
        getitem_405 = native_batch_norm_default_132[1]
        getitem_406 = native_batch_norm_default_132[2];  native_batch_norm_default_132 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(convolution_default_132, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_132 = torch.ops.aten.relu_.default(getitem_404);  getitem_404 = None
        cat_default_19 = torch.ops.aten.cat.default([relu__default_131, relu__default_132], 1)
        convolution_default_133 = torch.ops.aten.convolution.default(cat_default_18, primals_582, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_133 = torch.ops.aten.add_.Tensor(primals_578, 1);  primals_578 = None
        native_batch_norm_default_133 = torch.ops.aten.native_batch_norm.default(convolution_default_133, primals_581, primals_577, primals_579, primals_580, True, 0.1, 0.001);  primals_577 = None
        getitem_407 = native_batch_norm_default_133[0]
        getitem_408 = native_batch_norm_default_133[1]
        getitem_409 = native_batch_norm_default_133[2];  native_batch_norm_default_133 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(convolution_default_133, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_133 = torch.ops.aten.relu_.default(getitem_407);  getitem_407 = None
        convolution_default_134 = torch.ops.aten.convolution.default(relu__default_133, primals_588, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_134 = torch.ops.aten.add_.Tensor(primals_584, 1);  primals_584 = None
        native_batch_norm_default_134 = torch.ops.aten.native_batch_norm.default(convolution_default_134, primals_587, primals_583, primals_585, primals_586, True, 0.1, 0.001);  primals_583 = None
        getitem_410 = native_batch_norm_default_134[0]
        getitem_411 = native_batch_norm_default_134[1]
        getitem_412 = native_batch_norm_default_134[2];  native_batch_norm_default_134 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(convolution_default_134, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_134 = torch.ops.aten.relu_.default(getitem_410);  getitem_410 = None
        convolution_default_135 = torch.ops.aten.convolution.default(relu__default_134, primals_594, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_135 = torch.ops.aten.add_.Tensor(primals_590, 1);  primals_590 = None
        native_batch_norm_default_135 = torch.ops.aten.native_batch_norm.default(convolution_default_135, primals_593, primals_589, primals_591, primals_592, True, 0.1, 0.001);  primals_589 = None
        getitem_413 = native_batch_norm_default_135[0]
        getitem_414 = native_batch_norm_default_135[1]
        getitem_415 = native_batch_norm_default_135[2];  native_batch_norm_default_135 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(convolution_default_135, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_135 = torch.ops.aten.relu_.default(getitem_413);  getitem_413 = None
        convolution_default_136 = torch.ops.aten.convolution.default(relu__default_135, primals_600, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_136 = torch.ops.aten.add_.Tensor(primals_596, 1);  primals_596 = None
        native_batch_norm_default_136 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_599, primals_595, primals_597, primals_598, True, 0.1, 0.001);  primals_595 = None
        getitem_416 = native_batch_norm_default_136[0]
        getitem_417 = native_batch_norm_default_136[1]
        getitem_418 = native_batch_norm_default_136[2];  native_batch_norm_default_136 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(convolution_default_136, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_136 = torch.ops.aten.relu_.default(getitem_416);  getitem_416 = None
        convolution_default_137 = torch.ops.aten.convolution.default(relu__default_135, primals_606, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_137 = torch.ops.aten.add_.Tensor(primals_602, 1);  primals_602 = None
        native_batch_norm_default_137 = torch.ops.aten.native_batch_norm.default(convolution_default_137, primals_605, primals_601, primals_603, primals_604, True, 0.1, 0.001);  primals_601 = None
        getitem_419 = native_batch_norm_default_137[0]
        getitem_420 = native_batch_norm_default_137[1]
        getitem_421 = native_batch_norm_default_137[2];  native_batch_norm_default_137 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(convolution_default_137, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_137 = torch.ops.aten.relu_.default(getitem_419);  getitem_419 = None
        cat_default_20 = torch.ops.aten.cat.default([relu__default_136, relu__default_137], 1)
        avg_pool2d_default_12 = torch.ops.aten.avg_pool2d.default(cat_default_18, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_138 = torch.ops.aten.convolution.default(avg_pool2d_default_12, primals_612, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_138 = torch.ops.aten.add_.Tensor(primals_608, 1);  primals_608 = None
        native_batch_norm_default_138 = torch.ops.aten.native_batch_norm.default(convolution_default_138, primals_611, primals_607, primals_609, primals_610, True, 0.1, 0.001);  primals_607 = None
        getitem_422 = native_batch_norm_default_138[0]
        getitem_423 = native_batch_norm_default_138[1]
        getitem_424 = native_batch_norm_default_138[2];  native_batch_norm_default_138 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(convolution_default_138, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_138 = torch.ops.aten.relu_.default(getitem_422);  getitem_422 = None
        cat_default_21 = torch.ops.aten.cat.default([relu__default_129, cat_default_19, cat_default_20, relu__default_138], 1);  cat_default_19 = cat_default_20 = None
        convolution_default_139 = torch.ops.aten.convolution.default(cat_default_21, primals_618, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_139 = torch.ops.aten.add_.Tensor(primals_614, 1);  primals_614 = None
        native_batch_norm_default_139 = torch.ops.aten.native_batch_norm.default(convolution_default_139, primals_617, primals_613, primals_615, primals_616, True, 0.1, 0.001);  primals_613 = None
        getitem_425 = native_batch_norm_default_139[0]
        getitem_426 = native_batch_norm_default_139[1]
        getitem_427 = native_batch_norm_default_139[2];  native_batch_norm_default_139 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(convolution_default_139, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_139 = torch.ops.aten.relu_.default(getitem_425);  getitem_425 = None
        convolution_default_140 = torch.ops.aten.convolution.default(cat_default_21, primals_624, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_140 = torch.ops.aten.add_.Tensor(primals_620, 1);  primals_620 = None
        native_batch_norm_default_140 = torch.ops.aten.native_batch_norm.default(convolution_default_140, primals_623, primals_619, primals_621, primals_622, True, 0.1, 0.001);  primals_619 = None
        getitem_428 = native_batch_norm_default_140[0]
        getitem_429 = native_batch_norm_default_140[1]
        getitem_430 = native_batch_norm_default_140[2];  native_batch_norm_default_140 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(convolution_default_140, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_140 = torch.ops.aten.relu_.default(getitem_428);  getitem_428 = None
        convolution_default_141 = torch.ops.aten.convolution.default(relu__default_140, primals_630, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_141 = torch.ops.aten.add_.Tensor(primals_626, 1);  primals_626 = None
        native_batch_norm_default_141 = torch.ops.aten.native_batch_norm.default(convolution_default_141, primals_629, primals_625, primals_627, primals_628, True, 0.1, 0.001);  primals_625 = None
        getitem_431 = native_batch_norm_default_141[0]
        getitem_432 = native_batch_norm_default_141[1]
        getitem_433 = native_batch_norm_default_141[2];  native_batch_norm_default_141 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(convolution_default_141, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_141 = torch.ops.aten.relu_.default(getitem_431);  getitem_431 = None
        convolution_default_142 = torch.ops.aten.convolution.default(relu__default_140, primals_636, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_142 = torch.ops.aten.add_.Tensor(primals_632, 1);  primals_632 = None
        native_batch_norm_default_142 = torch.ops.aten.native_batch_norm.default(convolution_default_142, primals_635, primals_631, primals_633, primals_634, True, 0.1, 0.001);  primals_631 = None
        getitem_434 = native_batch_norm_default_142[0]
        getitem_435 = native_batch_norm_default_142[1]
        getitem_436 = native_batch_norm_default_142[2];  native_batch_norm_default_142 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(convolution_default_142, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_142 = torch.ops.aten.relu_.default(getitem_434);  getitem_434 = None
        cat_default_22 = torch.ops.aten.cat.default([relu__default_141, relu__default_142], 1)
        convolution_default_143 = torch.ops.aten.convolution.default(cat_default_21, primals_642, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_143 = torch.ops.aten.add_.Tensor(primals_638, 1);  primals_638 = None
        native_batch_norm_default_143 = torch.ops.aten.native_batch_norm.default(convolution_default_143, primals_641, primals_637, primals_639, primals_640, True, 0.1, 0.001);  primals_637 = None
        getitem_437 = native_batch_norm_default_143[0]
        getitem_438 = native_batch_norm_default_143[1]
        getitem_439 = native_batch_norm_default_143[2];  native_batch_norm_default_143 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(convolution_default_143, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_143 = torch.ops.aten.relu_.default(getitem_437);  getitem_437 = None
        convolution_default_144 = torch.ops.aten.convolution.default(relu__default_143, primals_648, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_144 = torch.ops.aten.add_.Tensor(primals_644, 1);  primals_644 = None
        native_batch_norm_default_144 = torch.ops.aten.native_batch_norm.default(convolution_default_144, primals_647, primals_643, primals_645, primals_646, True, 0.1, 0.001);  primals_643 = None
        getitem_440 = native_batch_norm_default_144[0]
        getitem_441 = native_batch_norm_default_144[1]
        getitem_442 = native_batch_norm_default_144[2];  native_batch_norm_default_144 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(convolution_default_144, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_144 = torch.ops.aten.relu_.default(getitem_440);  getitem_440 = None
        convolution_default_145 = torch.ops.aten.convolution.default(relu__default_144, primals_654, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_145 = torch.ops.aten.add_.Tensor(primals_650, 1);  primals_650 = None
        native_batch_norm_default_145 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_653, primals_649, primals_651, primals_652, True, 0.1, 0.001);  primals_649 = None
        getitem_443 = native_batch_norm_default_145[0]
        getitem_444 = native_batch_norm_default_145[1]
        getitem_445 = native_batch_norm_default_145[2];  native_batch_norm_default_145 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(convolution_default_145, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_145 = torch.ops.aten.relu_.default(getitem_443);  getitem_443 = None
        convolution_default_146 = torch.ops.aten.convolution.default(relu__default_145, primals_660, None, [1, 1], [0, 1], [1, 1], False, [0, 0], 1)
        add__tensor_146 = torch.ops.aten.add_.Tensor(primals_656, 1);  primals_656 = None
        native_batch_norm_default_146 = torch.ops.aten.native_batch_norm.default(convolution_default_146, primals_659, primals_655, primals_657, primals_658, True, 0.1, 0.001);  primals_655 = None
        getitem_446 = native_batch_norm_default_146[0]
        getitem_447 = native_batch_norm_default_146[1]
        getitem_448 = native_batch_norm_default_146[2];  native_batch_norm_default_146 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(convolution_default_146, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_146 = torch.ops.aten.relu_.default(getitem_446);  getitem_446 = None
        convolution_default_147 = torch.ops.aten.convolution.default(relu__default_145, primals_666, None, [1, 1], [1, 0], [1, 1], False, [0, 0], 1)
        add__tensor_147 = torch.ops.aten.add_.Tensor(primals_662, 1);  primals_662 = None
        native_batch_norm_default_147 = torch.ops.aten.native_batch_norm.default(convolution_default_147, primals_665, primals_661, primals_663, primals_664, True, 0.1, 0.001);  primals_661 = None
        getitem_449 = native_batch_norm_default_147[0]
        getitem_450 = native_batch_norm_default_147[1]
        getitem_451 = native_batch_norm_default_147[2];  native_batch_norm_default_147 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(convolution_default_147, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_147 = torch.ops.aten.relu_.default(getitem_449);  getitem_449 = None
        cat_default_23 = torch.ops.aten.cat.default([relu__default_146, relu__default_147], 1)
        avg_pool2d_default_13 = torch.ops.aten.avg_pool2d.default(cat_default_21, [3, 3], [1, 1], [1, 1], False, False)
        convolution_default_148 = torch.ops.aten.convolution.default(avg_pool2d_default_13, primals_672, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add__tensor_148 = torch.ops.aten.add_.Tensor(primals_668, 1);  primals_668 = None
        native_batch_norm_default_148 = torch.ops.aten.native_batch_norm.default(convolution_default_148, primals_671, primals_667, primals_669, primals_670, True, 0.1, 0.001);  primals_667 = None
        getitem_452 = native_batch_norm_default_148[0]
        getitem_453 = native_batch_norm_default_148[1]
        getitem_454 = native_batch_norm_default_148[2];  native_batch_norm_default_148 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(convolution_default_148, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_148 = torch.ops.aten.relu_.default(getitem_452);  getitem_452 = None
        cat_default_24 = torch.ops.aten.cat.default([relu__default_139, cat_default_22, cat_default_23, relu__default_148], 1);  cat_default_22 = cat_default_23 = None
        mean_dim = torch.ops.aten.mean.dim(cat_default_24, [-1, -2], True);  cat_default_24 = None
        view_default = torch.ops.aten.view.default(mean_dim, [128, 1536]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_896);  primals_896 = None
        addmm_default = torch.ops.aten.addmm.default(primals_895, view_default, t_default);  primals_895 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1536, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1536, 8, 8]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 64);  expand_default = None
        slice_tensor = torch.ops.aten.slice.Tensor(div_scalar, 1, 0, 256)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(div_scalar, 1, 256, 768)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(div_scalar, 1, 768, 1280)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(div_scalar, 1, 1280, 1536);  div_scalar = None
        to_dtype = torch.ops.aten.to.dtype(slice_tensor_3, torch.float32);  slice_tensor_3 = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_148, torch.float32);  relu__default_148 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_149, to_dtype);  le_scalar = new_zeros_default_149 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_148, primals_671, primals_669, primals_670, getitem_453, getitem_454, True, 0.001, [True, True, True]);  to_dtype_2 = convolution_default_148 = primals_671 = primals_669 = primals_670 = getitem_453 = getitem_454 = None
        getitem_455 = native_batch_norm_backward_default[0]
        getitem_456 = native_batch_norm_backward_default[1]
        getitem_457 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_455, avg_pool2d_default_13, primals_672, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_455 = avg_pool2d_default_13 = primals_672 = None
        getitem_458 = convolution_backward_default[0]
        getitem_459 = convolution_backward_default[1]
        getitem_460 = convolution_backward_default[2];  convolution_backward_default = None
        avg_pool2d_backward_default = torch.ops.aten.avg_pool2d_backward.default(getitem_458, cat_default_21, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_458 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(slice_tensor_2, 1, 0, 256)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(slice_tensor_2, 1, 256, 512);  slice_tensor_2 = None
        to_dtype_3 = torch.ops.aten.to.dtype(slice_tensor_5, torch.float32);  slice_tensor_5 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_147, torch.float32);  relu__default_147 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_150, to_dtype_3);  le_scalar_1 = new_zeros_default_150 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_147, primals_665, primals_663, primals_664, getitem_450, getitem_451, True, 0.001, [True, True, True]);  to_dtype_5 = convolution_default_147 = primals_665 = primals_663 = primals_664 = getitem_450 = getitem_451 = None
        getitem_461 = native_batch_norm_backward_default_1[0]
        getitem_462 = native_batch_norm_backward_default_1[1]
        getitem_463 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_461, relu__default_145, primals_666, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_461 = primals_666 = None
        getitem_464 = convolution_backward_default_1[0]
        getitem_465 = convolution_backward_default_1[1]
        getitem_466 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_6 = torch.ops.aten.to.dtype(slice_tensor_4, torch.float32);  slice_tensor_4 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_146, torch.float32);  relu__default_146 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_151, to_dtype_6);  le_scalar_2 = new_zeros_default_151 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_146, primals_659, primals_657, primals_658, getitem_447, getitem_448, True, 0.001, [True, True, True]);  to_dtype_8 = convolution_default_146 = primals_659 = primals_657 = primals_658 = getitem_447 = getitem_448 = None
        getitem_467 = native_batch_norm_backward_default_2[0]
        getitem_468 = native_batch_norm_backward_default_2[1]
        getitem_469 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_467, relu__default_145, primals_660, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_467 = primals_660 = None
        getitem_470 = convolution_backward_default_2[0]
        getitem_471 = convolution_backward_default_2[1]
        getitem_472 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        add_tensor = torch.ops.aten.add.Tensor(getitem_464, getitem_470);  getitem_464 = getitem_470 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_145, torch.float32);  relu__default_145 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_152, to_dtype_9);  le_scalar_3 = new_zeros_default_152 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_145, primals_653, primals_651, primals_652, getitem_444, getitem_445, True, 0.001, [True, True, True]);  to_dtype_11 = convolution_default_145 = primals_653 = primals_651 = primals_652 = getitem_444 = getitem_445 = None
        getitem_473 = native_batch_norm_backward_default_3[0]
        getitem_474 = native_batch_norm_backward_default_3[1]
        getitem_475 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_473, relu__default_144, primals_654, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_473 = primals_654 = None
        getitem_476 = convolution_backward_default_3[0]
        getitem_477 = convolution_backward_default_3[1]
        getitem_478 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_476, torch.float32);  getitem_476 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_144, torch.float32);  relu__default_144 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_153, to_dtype_12);  le_scalar_4 = new_zeros_default_153 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_144, primals_647, primals_645, primals_646, getitem_441, getitem_442, True, 0.001, [True, True, True]);  to_dtype_14 = convolution_default_144 = primals_647 = primals_645 = primals_646 = getitem_441 = getitem_442 = None
        getitem_479 = native_batch_norm_backward_default_4[0]
        getitem_480 = native_batch_norm_backward_default_4[1]
        getitem_481 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_479, relu__default_143, primals_648, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_479 = primals_648 = None
        getitem_482 = convolution_backward_default_4[0]
        getitem_483 = convolution_backward_default_4[1]
        getitem_484 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_482, torch.float32);  getitem_482 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_143, torch.float32);  relu__default_143 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_154, to_dtype_15);  le_scalar_5 = new_zeros_default_154 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_143, primals_641, primals_639, primals_640, getitem_438, getitem_439, True, 0.001, [True, True, True]);  to_dtype_17 = convolution_default_143 = primals_641 = primals_639 = primals_640 = getitem_438 = getitem_439 = None
        getitem_485 = native_batch_norm_backward_default_5[0]
        getitem_486 = native_batch_norm_backward_default_5[1]
        getitem_487 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_485, cat_default_21, primals_642, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_485 = primals_642 = None
        getitem_488 = convolution_backward_default_5[0]
        getitem_489 = convolution_backward_default_5[1]
        getitem_490 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default, getitem_488);  avg_pool2d_backward_default = getitem_488 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(slice_tensor_1, 1, 0, 256)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(slice_tensor_1, 1, 256, 512);  slice_tensor_1 = None
        to_dtype_18 = torch.ops.aten.to.dtype(slice_tensor_7, torch.float32);  slice_tensor_7 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_142, torch.float32);  relu__default_142 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_155, to_dtype_18);  le_scalar_6 = new_zeros_default_155 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_142, primals_635, primals_633, primals_634, getitem_435, getitem_436, True, 0.001, [True, True, True]);  to_dtype_20 = convolution_default_142 = primals_635 = primals_633 = primals_634 = getitem_435 = getitem_436 = None
        getitem_491 = native_batch_norm_backward_default_6[0]
        getitem_492 = native_batch_norm_backward_default_6[1]
        getitem_493 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_491, relu__default_140, primals_636, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_491 = primals_636 = None
        getitem_494 = convolution_backward_default_6[0]
        getitem_495 = convolution_backward_default_6[1]
        getitem_496 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        to_dtype_21 = torch.ops.aten.to.dtype(slice_tensor_6, torch.float32);  slice_tensor_6 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_141, torch.float32);  relu__default_141 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_156, to_dtype_21);  le_scalar_7 = new_zeros_default_156 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_141, primals_629, primals_627, primals_628, getitem_432, getitem_433, True, 0.001, [True, True, True]);  to_dtype_23 = convolution_default_141 = primals_629 = primals_627 = primals_628 = getitem_432 = getitem_433 = None
        getitem_497 = native_batch_norm_backward_default_7[0]
        getitem_498 = native_batch_norm_backward_default_7[1]
        getitem_499 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_497, relu__default_140, primals_630, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_497 = primals_630 = None
        getitem_500 = convolution_backward_default_7[0]
        getitem_501 = convolution_backward_default_7[1]
        getitem_502 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(getitem_494, getitem_500);  getitem_494 = getitem_500 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_140, torch.float32);  relu__default_140 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_157, to_dtype_24);  le_scalar_8 = new_zeros_default_157 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_140, primals_623, primals_621, primals_622, getitem_429, getitem_430, True, 0.001, [True, True, True]);  to_dtype_26 = convolution_default_140 = primals_623 = primals_621 = primals_622 = getitem_429 = getitem_430 = None
        getitem_503 = native_batch_norm_backward_default_8[0]
        getitem_504 = native_batch_norm_backward_default_8[1]
        getitem_505 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_503, cat_default_21, primals_624, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_503 = primals_624 = None
        getitem_506 = convolution_backward_default_8[0]
        getitem_507 = convolution_backward_default_8[1]
        getitem_508 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(add_tensor_1, getitem_506);  add_tensor_1 = getitem_506 = None
        to_dtype_27 = torch.ops.aten.to.dtype(slice_tensor, torch.float32);  slice_tensor = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_139, torch.float32);  relu__default_139 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_158, to_dtype_27);  le_scalar_9 = new_zeros_default_158 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_139, primals_617, primals_615, primals_616, getitem_426, getitem_427, True, 0.001, [True, True, True]);  to_dtype_29 = convolution_default_139 = primals_617 = primals_615 = primals_616 = getitem_426 = getitem_427 = None
        getitem_509 = native_batch_norm_backward_default_9[0]
        getitem_510 = native_batch_norm_backward_default_9[1]
        getitem_511 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_509, cat_default_21, primals_618, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_509 = cat_default_21 = primals_618 = None
        getitem_512 = convolution_backward_default_9[0]
        getitem_513 = convolution_backward_default_9[1]
        getitem_514 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(add_tensor_3, getitem_512);  add_tensor_3 = getitem_512 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(add_tensor_4, 1, 0, 256)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(add_tensor_4, 1, 256, 768)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(add_tensor_4, 1, 768, 1280)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(add_tensor_4, 1, 1280, 1536);  add_tensor_4 = None
        to_dtype_30 = torch.ops.aten.to.dtype(slice_tensor_11, torch.float32);  slice_tensor_11 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_138, torch.float32);  relu__default_138 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_159, to_dtype_30);  le_scalar_10 = new_zeros_default_159 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_138, primals_611, primals_609, primals_610, getitem_423, getitem_424, True, 0.001, [True, True, True]);  to_dtype_32 = convolution_default_138 = primals_611 = primals_609 = primals_610 = getitem_423 = getitem_424 = None
        getitem_515 = native_batch_norm_backward_default_10[0]
        getitem_516 = native_batch_norm_backward_default_10[1]
        getitem_517 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_515, avg_pool2d_default_12, primals_612, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_515 = avg_pool2d_default_12 = primals_612 = None
        getitem_518 = convolution_backward_default_10[0]
        getitem_519 = convolution_backward_default_10[1]
        getitem_520 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        avg_pool2d_backward_default_1 = torch.ops.aten.avg_pool2d_backward.default(getitem_518, cat_default_18, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_518 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(slice_tensor_10, 1, 0, 256)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(slice_tensor_10, 1, 256, 512);  slice_tensor_10 = None
        to_dtype_33 = torch.ops.aten.to.dtype(slice_tensor_13, torch.float32);  slice_tensor_13 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_137, torch.float32);  relu__default_137 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_160, to_dtype_33);  le_scalar_11 = new_zeros_default_160 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_137, primals_605, primals_603, primals_604, getitem_420, getitem_421, True, 0.001, [True, True, True]);  to_dtype_35 = convolution_default_137 = primals_605 = primals_603 = primals_604 = getitem_420 = getitem_421 = None
        getitem_521 = native_batch_norm_backward_default_11[0]
        getitem_522 = native_batch_norm_backward_default_11[1]
        getitem_523 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_521, relu__default_135, primals_606, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_521 = primals_606 = None
        getitem_524 = convolution_backward_default_11[0]
        getitem_525 = convolution_backward_default_11[1]
        getitem_526 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_36 = torch.ops.aten.to.dtype(slice_tensor_12, torch.float32);  slice_tensor_12 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_136, torch.float32);  relu__default_136 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_161, to_dtype_36);  le_scalar_12 = new_zeros_default_161 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_136, primals_599, primals_597, primals_598, getitem_417, getitem_418, True, 0.001, [True, True, True]);  to_dtype_38 = convolution_default_136 = primals_599 = primals_597 = primals_598 = getitem_417 = getitem_418 = None
        getitem_527 = native_batch_norm_backward_default_12[0]
        getitem_528 = native_batch_norm_backward_default_12[1]
        getitem_529 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_527, relu__default_135, primals_600, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_527 = primals_600 = None
        getitem_530 = convolution_backward_default_12[0]
        getitem_531 = convolution_backward_default_12[1]
        getitem_532 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(getitem_524, getitem_530);  getitem_524 = getitem_530 = None
        to_dtype_39 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_135, torch.float32);  relu__default_135 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_162, to_dtype_39);  le_scalar_13 = new_zeros_default_162 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_135, primals_593, primals_591, primals_592, getitem_414, getitem_415, True, 0.001, [True, True, True]);  to_dtype_41 = convolution_default_135 = primals_593 = primals_591 = primals_592 = getitem_414 = getitem_415 = None
        getitem_533 = native_batch_norm_backward_default_13[0]
        getitem_534 = native_batch_norm_backward_default_13[1]
        getitem_535 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_533, relu__default_134, primals_594, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_533 = primals_594 = None
        getitem_536 = convolution_backward_default_13[0]
        getitem_537 = convolution_backward_default_13[1]
        getitem_538 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_536, torch.float32);  getitem_536 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_134, torch.float32);  relu__default_134 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_163, to_dtype_42);  le_scalar_14 = new_zeros_default_163 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_134, primals_587, primals_585, primals_586, getitem_411, getitem_412, True, 0.001, [True, True, True]);  to_dtype_44 = convolution_default_134 = primals_587 = primals_585 = primals_586 = getitem_411 = getitem_412 = None
        getitem_539 = native_batch_norm_backward_default_14[0]
        getitem_540 = native_batch_norm_backward_default_14[1]
        getitem_541 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_539, relu__default_133, primals_588, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_539 = primals_588 = None
        getitem_542 = convolution_backward_default_14[0]
        getitem_543 = convolution_backward_default_14[1]
        getitem_544 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_542, torch.float32);  getitem_542 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_133, torch.float32);  relu__default_133 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_164, to_dtype_45);  le_scalar_15 = new_zeros_default_164 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_133, primals_581, primals_579, primals_580, getitem_408, getitem_409, True, 0.001, [True, True, True]);  to_dtype_47 = convolution_default_133 = primals_581 = primals_579 = primals_580 = getitem_408 = getitem_409 = None
        getitem_545 = native_batch_norm_backward_default_15[0]
        getitem_546 = native_batch_norm_backward_default_15[1]
        getitem_547 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_545, cat_default_18, primals_582, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_545 = primals_582 = None
        getitem_548 = convolution_backward_default_15[0]
        getitem_549 = convolution_backward_default_15[1]
        getitem_550 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_1, getitem_548);  avg_pool2d_backward_default_1 = getitem_548 = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(slice_tensor_9, 1, 0, 256)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(slice_tensor_9, 1, 256, 512);  slice_tensor_9 = None
        to_dtype_48 = torch.ops.aten.to.dtype(slice_tensor_15, torch.float32);  slice_tensor_15 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_132, torch.float32);  relu__default_132 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_165, to_dtype_48);  le_scalar_16 = new_zeros_default_165 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_132, primals_575, primals_573, primals_574, getitem_405, getitem_406, True, 0.001, [True, True, True]);  to_dtype_50 = convolution_default_132 = primals_575 = primals_573 = primals_574 = getitem_405 = getitem_406 = None
        getitem_551 = native_batch_norm_backward_default_16[0]
        getitem_552 = native_batch_norm_backward_default_16[1]
        getitem_553 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_551, relu__default_130, primals_576, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_551 = primals_576 = None
        getitem_554 = convolution_backward_default_16[0]
        getitem_555 = convolution_backward_default_16[1]
        getitem_556 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_51 = torch.ops.aten.to.dtype(slice_tensor_14, torch.float32);  slice_tensor_14 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_131, torch.float32);  relu__default_131 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_166, to_dtype_51);  le_scalar_17 = new_zeros_default_166 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_131, primals_569, primals_567, primals_568, getitem_402, getitem_403, True, 0.001, [True, True, True]);  to_dtype_53 = convolution_default_131 = primals_569 = primals_567 = primals_568 = getitem_402 = getitem_403 = None
        getitem_557 = native_batch_norm_backward_default_17[0]
        getitem_558 = native_batch_norm_backward_default_17[1]
        getitem_559 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_557, relu__default_130, primals_570, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_557 = primals_570 = None
        getitem_560 = convolution_backward_default_17[0]
        getitem_561 = convolution_backward_default_17[1]
        getitem_562 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(getitem_554, getitem_560);  getitem_554 = getitem_560 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_130, torch.float32);  relu__default_130 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_167, to_dtype_54);  le_scalar_18 = new_zeros_default_167 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_130, primals_563, primals_561, primals_562, getitem_399, getitem_400, True, 0.001, [True, True, True]);  to_dtype_56 = convolution_default_130 = primals_563 = primals_561 = primals_562 = getitem_399 = getitem_400 = None
        getitem_563 = native_batch_norm_backward_default_18[0]
        getitem_564 = native_batch_norm_backward_default_18[1]
        getitem_565 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_563, cat_default_18, primals_564, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_563 = primals_564 = None
        getitem_566 = convolution_backward_default_18[0]
        getitem_567 = convolution_backward_default_18[1]
        getitem_568 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_566);  add_tensor_6 = getitem_566 = None
        to_dtype_57 = torch.ops.aten.to.dtype(slice_tensor_8, torch.float32);  slice_tensor_8 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_129, torch.float32);  relu__default_129 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_168, to_dtype_57);  le_scalar_19 = new_zeros_default_168 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_129, primals_557, primals_555, primals_556, getitem_396, getitem_397, True, 0.001, [True, True, True]);  to_dtype_59 = convolution_default_129 = primals_557 = primals_555 = primals_556 = getitem_396 = getitem_397 = None
        getitem_569 = native_batch_norm_backward_default_19[0]
        getitem_570 = native_batch_norm_backward_default_19[1]
        getitem_571 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_569, cat_default_18, primals_558, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_569 = cat_default_18 = primals_558 = None
        getitem_572 = convolution_backward_default_19[0]
        getitem_573 = convolution_backward_default_19[1]
        getitem_574 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, getitem_572);  add_tensor_8 = getitem_572 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(add_tensor_9, 1, 0, 256)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(add_tensor_9, 1, 256, 768)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(add_tensor_9, 1, 768, 1280)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(add_tensor_9, 1, 1280, 1536);  add_tensor_9 = None
        to_dtype_60 = torch.ops.aten.to.dtype(slice_tensor_19, torch.float32);  slice_tensor_19 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_128, torch.float32);  relu__default_128 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_169, to_dtype_60);  le_scalar_20 = new_zeros_default_169 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_128, primals_545, primals_543, primals_544, getitem_393, getitem_394, True, 0.001, [True, True, True]);  to_dtype_62 = convolution_default_128 = primals_545 = primals_543 = primals_544 = getitem_393 = getitem_394 = None
        getitem_575 = native_batch_norm_backward_default_20[0]
        getitem_576 = native_batch_norm_backward_default_20[1]
        getitem_577 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_575, avg_pool2d_default_11, primals_546, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_575 = avg_pool2d_default_11 = primals_546 = None
        getitem_578 = convolution_backward_default_20[0]
        getitem_579 = convolution_backward_default_20[1]
        getitem_580 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        avg_pool2d_backward_default_2 = torch.ops.aten.avg_pool2d_backward.default(getitem_578, cat_default_15, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_578 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(slice_tensor_18, 1, 0, 256)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(slice_tensor_18, 1, 256, 512);  slice_tensor_18 = None
        to_dtype_63 = torch.ops.aten.to.dtype(slice_tensor_21, torch.float32);  slice_tensor_21 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_127, torch.float32);  relu__default_127 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_170, to_dtype_63);  le_scalar_21 = new_zeros_default_170 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_127, primals_539, primals_537, primals_538, getitem_390, getitem_391, True, 0.001, [True, True, True]);  to_dtype_65 = convolution_default_127 = primals_539 = primals_537 = primals_538 = getitem_390 = getitem_391 = None
        getitem_581 = native_batch_norm_backward_default_21[0]
        getitem_582 = native_batch_norm_backward_default_21[1]
        getitem_583 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_581, relu__default_125, primals_540, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_581 = primals_540 = None
        getitem_584 = convolution_backward_default_21[0]
        getitem_585 = convolution_backward_default_21[1]
        getitem_586 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        to_dtype_66 = torch.ops.aten.to.dtype(slice_tensor_20, torch.float32);  slice_tensor_20 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_126, torch.float32);  relu__default_126 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_171, to_dtype_66);  le_scalar_22 = new_zeros_default_171 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_126, primals_533, primals_531, primals_532, getitem_387, getitem_388, True, 0.001, [True, True, True]);  to_dtype_68 = convolution_default_126 = primals_533 = primals_531 = primals_532 = getitem_387 = getitem_388 = None
        getitem_587 = native_batch_norm_backward_default_22[0]
        getitem_588 = native_batch_norm_backward_default_22[1]
        getitem_589 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_587, relu__default_125, primals_534, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_587 = primals_534 = None
        getitem_590 = convolution_backward_default_22[0]
        getitem_591 = convolution_backward_default_22[1]
        getitem_592 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_584, getitem_590);  getitem_584 = getitem_590 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_10, torch.float32);  add_tensor_10 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_125, torch.float32);  relu__default_125 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_172, to_dtype_69);  le_scalar_23 = new_zeros_default_172 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_125, primals_527, primals_525, primals_526, getitem_384, getitem_385, True, 0.001, [True, True, True]);  to_dtype_71 = convolution_default_125 = primals_527 = primals_525 = primals_526 = getitem_384 = getitem_385 = None
        getitem_593 = native_batch_norm_backward_default_23[0]
        getitem_594 = native_batch_norm_backward_default_23[1]
        getitem_595 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_593, relu__default_124, primals_528, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_593 = primals_528 = None
        getitem_596 = convolution_backward_default_23[0]
        getitem_597 = convolution_backward_default_23[1]
        getitem_598 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_596, torch.float32);  getitem_596 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_124, torch.float32);  relu__default_124 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_173, to_dtype_72);  le_scalar_24 = new_zeros_default_173 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_124, primals_521, primals_519, primals_520, getitem_381, getitem_382, True, 0.001, [True, True, True]);  to_dtype_74 = convolution_default_124 = primals_521 = primals_519 = primals_520 = getitem_381 = getitem_382 = None
        getitem_599 = native_batch_norm_backward_default_24[0]
        getitem_600 = native_batch_norm_backward_default_24[1]
        getitem_601 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_599, relu__default_123, primals_522, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_599 = primals_522 = None
        getitem_602 = convolution_backward_default_24[0]
        getitem_603 = convolution_backward_default_24[1]
        getitem_604 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_602, torch.float32);  getitem_602 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_123, torch.float32);  relu__default_123 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_174, to_dtype_75);  le_scalar_25 = new_zeros_default_174 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_123, primals_515, primals_513, primals_514, getitem_378, getitem_379, True, 0.001, [True, True, True]);  to_dtype_77 = convolution_default_123 = primals_515 = primals_513 = primals_514 = getitem_378 = getitem_379 = None
        getitem_605 = native_batch_norm_backward_default_25[0]
        getitem_606 = native_batch_norm_backward_default_25[1]
        getitem_607 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_605, cat_default_15, primals_516, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_605 = primals_516 = None
        getitem_608 = convolution_backward_default_25[0]
        getitem_609 = convolution_backward_default_25[1]
        getitem_610 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_2, getitem_608);  avg_pool2d_backward_default_2 = getitem_608 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(slice_tensor_17, 1, 0, 256)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(slice_tensor_17, 1, 256, 512);  slice_tensor_17 = None
        to_dtype_78 = torch.ops.aten.to.dtype(slice_tensor_23, torch.float32);  slice_tensor_23 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_122, torch.float32);  relu__default_122 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_175, to_dtype_78);  le_scalar_26 = new_zeros_default_175 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_122, primals_509, primals_507, primals_508, getitem_375, getitem_376, True, 0.001, [True, True, True]);  to_dtype_80 = convolution_default_122 = primals_509 = primals_507 = primals_508 = getitem_375 = getitem_376 = None
        getitem_611 = native_batch_norm_backward_default_26[0]
        getitem_612 = native_batch_norm_backward_default_26[1]
        getitem_613 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_611, relu__default_120, primals_510, [0], [1, 1], [1, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_611 = primals_510 = None
        getitem_614 = convolution_backward_default_26[0]
        getitem_615 = convolution_backward_default_26[1]
        getitem_616 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_81 = torch.ops.aten.to.dtype(slice_tensor_22, torch.float32);  slice_tensor_22 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_121, torch.float32);  relu__default_121 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_176, to_dtype_81);  le_scalar_27 = new_zeros_default_176 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_121, primals_503, primals_501, primals_502, getitem_372, getitem_373, True, 0.001, [True, True, True]);  to_dtype_83 = convolution_default_121 = primals_503 = primals_501 = primals_502 = getitem_372 = getitem_373 = None
        getitem_617 = native_batch_norm_backward_default_27[0]
        getitem_618 = native_batch_norm_backward_default_27[1]
        getitem_619 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_617, relu__default_120, primals_504, [0], [1, 1], [0, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_617 = primals_504 = None
        getitem_620 = convolution_backward_default_27[0]
        getitem_621 = convolution_backward_default_27[1]
        getitem_622 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(getitem_614, getitem_620);  getitem_614 = getitem_620 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_12, torch.float32);  add_tensor_12 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_120, torch.float32);  relu__default_120 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_177, to_dtype_84);  le_scalar_28 = new_zeros_default_177 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_120, primals_497, primals_495, primals_496, getitem_369, getitem_370, True, 0.001, [True, True, True]);  to_dtype_86 = convolution_default_120 = primals_497 = primals_495 = primals_496 = getitem_369 = getitem_370 = None
        getitem_623 = native_batch_norm_backward_default_28[0]
        getitem_624 = native_batch_norm_backward_default_28[1]
        getitem_625 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_623, cat_default_15, primals_498, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_623 = primals_498 = None
        getitem_626 = convolution_backward_default_28[0]
        getitem_627 = convolution_backward_default_28[1]
        getitem_628 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_11, getitem_626);  add_tensor_11 = getitem_626 = None
        to_dtype_87 = torch.ops.aten.to.dtype(slice_tensor_16, torch.float32);  slice_tensor_16 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_119, torch.float32);  relu__default_119 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_178, to_dtype_87);  le_scalar_29 = new_zeros_default_178 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_119, primals_491, primals_489, primals_490, getitem_366, getitem_367, True, 0.001, [True, True, True]);  to_dtype_89 = convolution_default_119 = primals_491 = primals_489 = primals_490 = getitem_366 = getitem_367 = None
        getitem_629 = native_batch_norm_backward_default_29[0]
        getitem_630 = native_batch_norm_backward_default_29[1]
        getitem_631 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_629, cat_default_15, primals_492, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_629 = cat_default_15 = primals_492 = None
        getitem_632 = convolution_backward_default_29[0]
        getitem_633 = convolution_backward_default_29[1]
        getitem_634 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, getitem_632);  add_tensor_13 = getitem_632 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(add_tensor_14, 1, 0, 192)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(add_tensor_14, 1, 192, 512)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(add_tensor_14, 1, 512, 1536);  add_tensor_14 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_26, cat_default_14, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_364);  slice_tensor_26 = getitem_364 = None
        to_dtype_90 = torch.ops.aten.to.dtype(slice_tensor_25, torch.float32);  slice_tensor_25 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_118, torch.float32);  relu__default_118 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_179, to_dtype_90);  le_scalar_30 = new_zeros_default_179 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_118, primals_485, primals_483, primals_484, getitem_361, getitem_362, True, 0.001, [True, True, True]);  to_dtype_92 = convolution_default_118 = primals_485 = primals_483 = primals_484 = getitem_361 = getitem_362 = None
        getitem_635 = native_batch_norm_backward_default_30[0]
        getitem_636 = native_batch_norm_backward_default_30[1]
        getitem_637 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_635, relu__default_117, primals_486, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_635 = primals_486 = None
        getitem_638 = convolution_backward_default_30[0]
        getitem_639 = convolution_backward_default_30[1]
        getitem_640 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_638, torch.float32);  getitem_638 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_117, torch.float32);  relu__default_117 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_180, to_dtype_93);  le_scalar_31 = new_zeros_default_180 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_117, primals_479, primals_477, primals_478, getitem_358, getitem_359, True, 0.001, [True, True, True]);  to_dtype_95 = convolution_default_117 = primals_479 = primals_477 = primals_478 = getitem_358 = getitem_359 = None
        getitem_641 = native_batch_norm_backward_default_31[0]
        getitem_642 = native_batch_norm_backward_default_31[1]
        getitem_643 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_641, relu__default_116, primals_480, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_641 = primals_480 = None
        getitem_644 = convolution_backward_default_31[0]
        getitem_645 = convolution_backward_default_31[1]
        getitem_646 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_644, torch.float32);  getitem_644 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_116, torch.float32);  relu__default_116 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_181, to_dtype_96);  le_scalar_32 = new_zeros_default_181 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_116, primals_473, primals_471, primals_472, getitem_355, getitem_356, True, 0.001, [True, True, True]);  to_dtype_98 = convolution_default_116 = primals_473 = primals_471 = primals_472 = getitem_355 = getitem_356 = None
        getitem_647 = native_batch_norm_backward_default_32[0]
        getitem_648 = native_batch_norm_backward_default_32[1]
        getitem_649 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_647, relu__default_115, primals_474, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_647 = primals_474 = None
        getitem_650 = convolution_backward_default_32[0]
        getitem_651 = convolution_backward_default_32[1]
        getitem_652 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_650, torch.float32);  getitem_650 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_115, torch.float32);  relu__default_115 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_182, to_dtype_99);  le_scalar_33 = new_zeros_default_182 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_115, primals_467, primals_465, primals_466, getitem_352, getitem_353, True, 0.001, [True, True, True]);  to_dtype_101 = convolution_default_115 = primals_467 = primals_465 = primals_466 = getitem_352 = getitem_353 = None
        getitem_653 = native_batch_norm_backward_default_33[0]
        getitem_654 = native_batch_norm_backward_default_33[1]
        getitem_655 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_653, cat_default_14, primals_468, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_653 = primals_468 = None
        getitem_656 = convolution_backward_default_33[0]
        getitem_657 = convolution_backward_default_33[1]
        getitem_658 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(max_pool2d_with_indices_backward_default, getitem_656);  max_pool2d_with_indices_backward_default = getitem_656 = None
        to_dtype_102 = torch.ops.aten.to.dtype(slice_tensor_24, torch.float32);  slice_tensor_24 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_114, torch.float32);  relu__default_114 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_183, to_dtype_102);  le_scalar_34 = new_zeros_default_183 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_114, primals_461, primals_459, primals_460, getitem_349, getitem_350, True, 0.001, [True, True, True]);  to_dtype_104 = convolution_default_114 = primals_461 = primals_459 = primals_460 = getitem_349 = getitem_350 = None
        getitem_659 = native_batch_norm_backward_default_34[0]
        getitem_660 = native_batch_norm_backward_default_34[1]
        getitem_661 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_659, relu__default_113, primals_462, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_659 = primals_462 = None
        getitem_662 = convolution_backward_default_34[0]
        getitem_663 = convolution_backward_default_34[1]
        getitem_664 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_662, torch.float32);  getitem_662 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_113, torch.float32);  relu__default_113 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_184, to_dtype_105);  le_scalar_35 = new_zeros_default_184 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_113, primals_455, primals_453, primals_454, getitem_346, getitem_347, True, 0.001, [True, True, True]);  to_dtype_107 = convolution_default_113 = primals_455 = primals_453 = primals_454 = getitem_346 = getitem_347 = None
        getitem_665 = native_batch_norm_backward_default_35[0]
        getitem_666 = native_batch_norm_backward_default_35[1]
        getitem_667 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_665, cat_default_14, primals_456, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_665 = cat_default_14 = primals_456 = None
        getitem_668 = convolution_backward_default_35[0]
        getitem_669 = convolution_backward_default_35[1]
        getitem_670 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(add_tensor_15, getitem_668);  add_tensor_15 = getitem_668 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(add_tensor_16, 1, 0, 384)
        slice_tensor_28 = torch.ops.aten.slice.Tensor(add_tensor_16, 1, 384, 640)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(add_tensor_16, 1, 640, 896)
        slice_tensor_30 = torch.ops.aten.slice.Tensor(add_tensor_16, 1, 896, 1024);  add_tensor_16 = None
        to_dtype_108 = torch.ops.aten.to.dtype(slice_tensor_30, torch.float32);  slice_tensor_30 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_112, torch.float32);  relu__default_112 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_185, to_dtype_108);  le_scalar_36 = new_zeros_default_185 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_112, primals_449, primals_447, primals_448, getitem_343, getitem_344, True, 0.001, [True, True, True]);  to_dtype_110 = convolution_default_112 = primals_449 = primals_447 = primals_448 = getitem_343 = getitem_344 = None
        getitem_671 = native_batch_norm_backward_default_36[0]
        getitem_672 = native_batch_norm_backward_default_36[1]
        getitem_673 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_671, avg_pool2d_default_10, primals_450, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_671 = avg_pool2d_default_10 = primals_450 = None
        getitem_674 = convolution_backward_default_36[0]
        getitem_675 = convolution_backward_default_36[1]
        getitem_676 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        avg_pool2d_backward_default_3 = torch.ops.aten.avg_pool2d_backward.default(getitem_674, cat_default_13, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_674 = None
        to_dtype_111 = torch.ops.aten.to.dtype(slice_tensor_29, torch.float32);  slice_tensor_29 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_111, torch.float32);  relu__default_111 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_186, to_dtype_111);  le_scalar_37 = new_zeros_default_186 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_111, primals_443, primals_441, primals_442, getitem_340, getitem_341, True, 0.001, [True, True, True]);  to_dtype_113 = convolution_default_111 = primals_443 = primals_441 = primals_442 = getitem_340 = getitem_341 = None
        getitem_677 = native_batch_norm_backward_default_37[0]
        getitem_678 = native_batch_norm_backward_default_37[1]
        getitem_679 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_677, relu__default_110, primals_444, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_677 = primals_444 = None
        getitem_680 = convolution_backward_default_37[0]
        getitem_681 = convolution_backward_default_37[1]
        getitem_682 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_680, torch.float32);  getitem_680 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_110, torch.float32);  relu__default_110 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_187, to_dtype_114);  le_scalar_38 = new_zeros_default_187 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_110, primals_437, primals_435, primals_436, getitem_337, getitem_338, True, 0.001, [True, True, True]);  to_dtype_116 = convolution_default_110 = primals_437 = primals_435 = primals_436 = getitem_337 = getitem_338 = None
        getitem_683 = native_batch_norm_backward_default_38[0]
        getitem_684 = native_batch_norm_backward_default_38[1]
        getitem_685 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_683, relu__default_109, primals_438, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_683 = primals_438 = None
        getitem_686 = convolution_backward_default_38[0]
        getitem_687 = convolution_backward_default_38[1]
        getitem_688 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_686, torch.float32);  getitem_686 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_188, to_dtype_117);  le_scalar_39 = new_zeros_default_188 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_109, primals_431, primals_429, primals_430, getitem_334, getitem_335, True, 0.001, [True, True, True]);  to_dtype_119 = convolution_default_109 = primals_431 = primals_429 = primals_430 = getitem_334 = getitem_335 = None
        getitem_689 = native_batch_norm_backward_default_39[0]
        getitem_690 = native_batch_norm_backward_default_39[1]
        getitem_691 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_689, relu__default_108, primals_432, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_689 = primals_432 = None
        getitem_692 = convolution_backward_default_39[0]
        getitem_693 = convolution_backward_default_39[1]
        getitem_694 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_692, torch.float32);  getitem_692 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_189, to_dtype_120);  le_scalar_40 = new_zeros_default_189 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_108, primals_425, primals_423, primals_424, getitem_331, getitem_332, True, 0.001, [True, True, True]);  to_dtype_122 = convolution_default_108 = primals_425 = primals_423 = primals_424 = getitem_331 = getitem_332 = None
        getitem_695 = native_batch_norm_backward_default_40[0]
        getitem_696 = native_batch_norm_backward_default_40[1]
        getitem_697 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_695, relu__default_107, primals_426, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_695 = primals_426 = None
        getitem_698 = convolution_backward_default_40[0]
        getitem_699 = convolution_backward_default_40[1]
        getitem_700 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_698, torch.float32);  getitem_698 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_190, to_dtype_123);  le_scalar_41 = new_zeros_default_190 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_107, primals_419, primals_417, primals_418, getitem_328, getitem_329, True, 0.001, [True, True, True]);  to_dtype_125 = convolution_default_107 = primals_419 = primals_417 = primals_418 = getitem_328 = getitem_329 = None
        getitem_701 = native_batch_norm_backward_default_41[0]
        getitem_702 = native_batch_norm_backward_default_41[1]
        getitem_703 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_701, cat_default_13, primals_420, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_701 = primals_420 = None
        getitem_704 = convolution_backward_default_41[0]
        getitem_705 = convolution_backward_default_41[1]
        getitem_706 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_3, getitem_704);  avg_pool2d_backward_default_3 = getitem_704 = None
        to_dtype_126 = torch.ops.aten.to.dtype(slice_tensor_28, torch.float32);  slice_tensor_28 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_191, to_dtype_126);  le_scalar_42 = new_zeros_default_191 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_106, primals_413, primals_411, primals_412, getitem_325, getitem_326, True, 0.001, [True, True, True]);  to_dtype_128 = convolution_default_106 = primals_413 = primals_411 = primals_412 = getitem_325 = getitem_326 = None
        getitem_707 = native_batch_norm_backward_default_42[0]
        getitem_708 = native_batch_norm_backward_default_42[1]
        getitem_709 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_707, relu__default_105, primals_414, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_707 = primals_414 = None
        getitem_710 = convolution_backward_default_42[0]
        getitem_711 = convolution_backward_default_42[1]
        getitem_712 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_710, torch.float32);  getitem_710 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_192, to_dtype_129);  le_scalar_43 = new_zeros_default_192 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_105, primals_407, primals_405, primals_406, getitem_322, getitem_323, True, 0.001, [True, True, True]);  to_dtype_131 = convolution_default_105 = primals_407 = primals_405 = primals_406 = getitem_322 = getitem_323 = None
        getitem_713 = native_batch_norm_backward_default_43[0]
        getitem_714 = native_batch_norm_backward_default_43[1]
        getitem_715 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_713, relu__default_104, primals_408, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_713 = primals_408 = None
        getitem_716 = convolution_backward_default_43[0]
        getitem_717 = convolution_backward_default_43[1]
        getitem_718 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_716, torch.float32);  getitem_716 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_193, to_dtype_132);  le_scalar_44 = new_zeros_default_193 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_104, primals_401, primals_399, primals_400, getitem_319, getitem_320, True, 0.001, [True, True, True]);  to_dtype_134 = convolution_default_104 = primals_401 = primals_399 = primals_400 = getitem_319 = getitem_320 = None
        getitem_719 = native_batch_norm_backward_default_44[0]
        getitem_720 = native_batch_norm_backward_default_44[1]
        getitem_721 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_719, cat_default_13, primals_402, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_719 = primals_402 = None
        getitem_722 = convolution_backward_default_44[0]
        getitem_723 = convolution_backward_default_44[1]
        getitem_724 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(add_tensor_17, getitem_722);  add_tensor_17 = getitem_722 = None
        to_dtype_135 = torch.ops.aten.to.dtype(slice_tensor_27, torch.float32);  slice_tensor_27 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_194, to_dtype_135);  le_scalar_45 = new_zeros_default_194 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_103, primals_395, primals_393, primals_394, getitem_316, getitem_317, True, 0.001, [True, True, True]);  to_dtype_137 = convolution_default_103 = primals_395 = primals_393 = primals_394 = getitem_316 = getitem_317 = None
        getitem_725 = native_batch_norm_backward_default_45[0]
        getitem_726 = native_batch_norm_backward_default_45[1]
        getitem_727 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_725, cat_default_13, primals_396, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_725 = cat_default_13 = primals_396 = None
        getitem_728 = convolution_backward_default_45[0]
        getitem_729 = convolution_backward_default_45[1]
        getitem_730 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_18, getitem_728);  add_tensor_18 = getitem_728 = None
        slice_tensor_31 = torch.ops.aten.slice.Tensor(add_tensor_19, 1, 0, 384)
        slice_tensor_32 = torch.ops.aten.slice.Tensor(add_tensor_19, 1, 384, 640)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(add_tensor_19, 1, 640, 896)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(add_tensor_19, 1, 896, 1024);  add_tensor_19 = None
        to_dtype_138 = torch.ops.aten.to.dtype(slice_tensor_34, torch.float32);  slice_tensor_34 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_195, to_dtype_138);  le_scalar_46 = new_zeros_default_195 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_102, primals_389, primals_387, primals_388, getitem_313, getitem_314, True, 0.001, [True, True, True]);  to_dtype_140 = convolution_default_102 = primals_389 = primals_387 = primals_388 = getitem_313 = getitem_314 = None
        getitem_731 = native_batch_norm_backward_default_46[0]
        getitem_732 = native_batch_norm_backward_default_46[1]
        getitem_733 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_731, avg_pool2d_default_9, primals_390, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_731 = avg_pool2d_default_9 = primals_390 = None
        getitem_734 = convolution_backward_default_46[0]
        getitem_735 = convolution_backward_default_46[1]
        getitem_736 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        avg_pool2d_backward_default_4 = torch.ops.aten.avg_pool2d_backward.default(getitem_734, cat_default_12, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_734 = None
        to_dtype_141 = torch.ops.aten.to.dtype(slice_tensor_33, torch.float32);  slice_tensor_33 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_196, to_dtype_141);  le_scalar_47 = new_zeros_default_196 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_101, primals_383, primals_381, primals_382, getitem_310, getitem_311, True, 0.001, [True, True, True]);  to_dtype_143 = convolution_default_101 = primals_383 = primals_381 = primals_382 = getitem_310 = getitem_311 = None
        getitem_737 = native_batch_norm_backward_default_47[0]
        getitem_738 = native_batch_norm_backward_default_47[1]
        getitem_739 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_737, relu__default_100, primals_384, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_737 = primals_384 = None
        getitem_740 = convolution_backward_default_47[0]
        getitem_741 = convolution_backward_default_47[1]
        getitem_742 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_740, torch.float32);  getitem_740 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_197, to_dtype_144);  le_scalar_48 = new_zeros_default_197 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_100, primals_377, primals_375, primals_376, getitem_307, getitem_308, True, 0.001, [True, True, True]);  to_dtype_146 = convolution_default_100 = primals_377 = primals_375 = primals_376 = getitem_307 = getitem_308 = None
        getitem_743 = native_batch_norm_backward_default_48[0]
        getitem_744 = native_batch_norm_backward_default_48[1]
        getitem_745 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_743, relu__default_99, primals_378, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_743 = primals_378 = None
        getitem_746 = convolution_backward_default_48[0]
        getitem_747 = convolution_backward_default_48[1]
        getitem_748 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_746, torch.float32);  getitem_746 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_198, to_dtype_147);  le_scalar_49 = new_zeros_default_198 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_99, primals_371, primals_369, primals_370, getitem_304, getitem_305, True, 0.001, [True, True, True]);  to_dtype_149 = convolution_default_99 = primals_371 = primals_369 = primals_370 = getitem_304 = getitem_305 = None
        getitem_749 = native_batch_norm_backward_default_49[0]
        getitem_750 = native_batch_norm_backward_default_49[1]
        getitem_751 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_749, relu__default_98, primals_372, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_749 = primals_372 = None
        getitem_752 = convolution_backward_default_49[0]
        getitem_753 = convolution_backward_default_49[1]
        getitem_754 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_752, torch.float32);  getitem_752 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_199, to_dtype_150);  le_scalar_50 = new_zeros_default_199 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_98, primals_365, primals_363, primals_364, getitem_301, getitem_302, True, 0.001, [True, True, True]);  to_dtype_152 = convolution_default_98 = primals_365 = primals_363 = primals_364 = getitem_301 = getitem_302 = None
        getitem_755 = native_batch_norm_backward_default_50[0]
        getitem_756 = native_batch_norm_backward_default_50[1]
        getitem_757 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_755, relu__default_97, primals_366, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_755 = primals_366 = None
        getitem_758 = convolution_backward_default_50[0]
        getitem_759 = convolution_backward_default_50[1]
        getitem_760 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_758, torch.float32);  getitem_758 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_200, to_dtype_153);  le_scalar_51 = new_zeros_default_200 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_97, primals_359, primals_357, primals_358, getitem_298, getitem_299, True, 0.001, [True, True, True]);  to_dtype_155 = convolution_default_97 = primals_359 = primals_357 = primals_358 = getitem_298 = getitem_299 = None
        getitem_761 = native_batch_norm_backward_default_51[0]
        getitem_762 = native_batch_norm_backward_default_51[1]
        getitem_763 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_761, cat_default_12, primals_360, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_761 = primals_360 = None
        getitem_764 = convolution_backward_default_51[0]
        getitem_765 = convolution_backward_default_51[1]
        getitem_766 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_4, getitem_764);  avg_pool2d_backward_default_4 = getitem_764 = None
        to_dtype_156 = torch.ops.aten.to.dtype(slice_tensor_32, torch.float32);  slice_tensor_32 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_201, to_dtype_156);  le_scalar_52 = new_zeros_default_201 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_96, primals_353, primals_351, primals_352, getitem_295, getitem_296, True, 0.001, [True, True, True]);  to_dtype_158 = convolution_default_96 = primals_353 = primals_351 = primals_352 = getitem_295 = getitem_296 = None
        getitem_767 = native_batch_norm_backward_default_52[0]
        getitem_768 = native_batch_norm_backward_default_52[1]
        getitem_769 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_767, relu__default_95, primals_354, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_767 = primals_354 = None
        getitem_770 = convolution_backward_default_52[0]
        getitem_771 = convolution_backward_default_52[1]
        getitem_772 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_770, torch.float32);  getitem_770 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_202, to_dtype_159);  le_scalar_53 = new_zeros_default_202 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_95, primals_347, primals_345, primals_346, getitem_292, getitem_293, True, 0.001, [True, True, True]);  to_dtype_161 = convolution_default_95 = primals_347 = primals_345 = primals_346 = getitem_292 = getitem_293 = None
        getitem_773 = native_batch_norm_backward_default_53[0]
        getitem_774 = native_batch_norm_backward_default_53[1]
        getitem_775 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_773, relu__default_94, primals_348, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_773 = primals_348 = None
        getitem_776 = convolution_backward_default_53[0]
        getitem_777 = convolution_backward_default_53[1]
        getitem_778 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_776, torch.float32);  getitem_776 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_203, to_dtype_162);  le_scalar_54 = new_zeros_default_203 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_94, primals_341, primals_339, primals_340, getitem_289, getitem_290, True, 0.001, [True, True, True]);  to_dtype_164 = convolution_default_94 = primals_341 = primals_339 = primals_340 = getitem_289 = getitem_290 = None
        getitem_779 = native_batch_norm_backward_default_54[0]
        getitem_780 = native_batch_norm_backward_default_54[1]
        getitem_781 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_779, cat_default_12, primals_342, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_779 = primals_342 = None
        getitem_782 = convolution_backward_default_54[0]
        getitem_783 = convolution_backward_default_54[1]
        getitem_784 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(add_tensor_20, getitem_782);  add_tensor_20 = getitem_782 = None
        to_dtype_165 = torch.ops.aten.to.dtype(slice_tensor_31, torch.float32);  slice_tensor_31 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_204, to_dtype_165);  le_scalar_55 = new_zeros_default_204 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_93, primals_335, primals_333, primals_334, getitem_286, getitem_287, True, 0.001, [True, True, True]);  to_dtype_167 = convolution_default_93 = primals_335 = primals_333 = primals_334 = getitem_286 = getitem_287 = None
        getitem_785 = native_batch_norm_backward_default_55[0]
        getitem_786 = native_batch_norm_backward_default_55[1]
        getitem_787 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_785, cat_default_12, primals_336, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_785 = cat_default_12 = primals_336 = None
        getitem_788 = convolution_backward_default_55[0]
        getitem_789 = convolution_backward_default_55[1]
        getitem_790 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, getitem_788);  add_tensor_21 = getitem_788 = None
        slice_tensor_35 = torch.ops.aten.slice.Tensor(add_tensor_22, 1, 0, 384)
        slice_tensor_36 = torch.ops.aten.slice.Tensor(add_tensor_22, 1, 384, 640)
        slice_tensor_37 = torch.ops.aten.slice.Tensor(add_tensor_22, 1, 640, 896)
        slice_tensor_38 = torch.ops.aten.slice.Tensor(add_tensor_22, 1, 896, 1024);  add_tensor_22 = None
        to_dtype_168 = torch.ops.aten.to.dtype(slice_tensor_38, torch.float32);  slice_tensor_38 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_205, to_dtype_168);  le_scalar_56 = new_zeros_default_205 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_92, primals_329, primals_327, primals_328, getitem_283, getitem_284, True, 0.001, [True, True, True]);  to_dtype_170 = convolution_default_92 = primals_329 = primals_327 = primals_328 = getitem_283 = getitem_284 = None
        getitem_791 = native_batch_norm_backward_default_56[0]
        getitem_792 = native_batch_norm_backward_default_56[1]
        getitem_793 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_791, avg_pool2d_default_8, primals_330, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_791 = avg_pool2d_default_8 = primals_330 = None
        getitem_794 = convolution_backward_default_56[0]
        getitem_795 = convolution_backward_default_56[1]
        getitem_796 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        avg_pool2d_backward_default_5 = torch.ops.aten.avg_pool2d_backward.default(getitem_794, cat_default_11, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_794 = None
        to_dtype_171 = torch.ops.aten.to.dtype(slice_tensor_37, torch.float32);  slice_tensor_37 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_206, to_dtype_171);  le_scalar_57 = new_zeros_default_206 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_91, primals_323, primals_321, primals_322, getitem_280, getitem_281, True, 0.001, [True, True, True]);  to_dtype_173 = convolution_default_91 = primals_323 = primals_321 = primals_322 = getitem_280 = getitem_281 = None
        getitem_797 = native_batch_norm_backward_default_57[0]
        getitem_798 = native_batch_norm_backward_default_57[1]
        getitem_799 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_797, relu__default_90, primals_324, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_797 = primals_324 = None
        getitem_800 = convolution_backward_default_57[0]
        getitem_801 = convolution_backward_default_57[1]
        getitem_802 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_800, torch.float32);  getitem_800 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_207, to_dtype_174);  le_scalar_58 = new_zeros_default_207 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_90, primals_317, primals_315, primals_316, getitem_277, getitem_278, True, 0.001, [True, True, True]);  to_dtype_176 = convolution_default_90 = primals_317 = primals_315 = primals_316 = getitem_277 = getitem_278 = None
        getitem_803 = native_batch_norm_backward_default_58[0]
        getitem_804 = native_batch_norm_backward_default_58[1]
        getitem_805 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_803, relu__default_89, primals_318, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_803 = primals_318 = None
        getitem_806 = convolution_backward_default_58[0]
        getitem_807 = convolution_backward_default_58[1]
        getitem_808 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_806, torch.float32);  getitem_806 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_208, to_dtype_177);  le_scalar_59 = new_zeros_default_208 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_89, primals_311, primals_309, primals_310, getitem_274, getitem_275, True, 0.001, [True, True, True]);  to_dtype_179 = convolution_default_89 = primals_311 = primals_309 = primals_310 = getitem_274 = getitem_275 = None
        getitem_809 = native_batch_norm_backward_default_59[0]
        getitem_810 = native_batch_norm_backward_default_59[1]
        getitem_811 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_809, relu__default_88, primals_312, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_809 = primals_312 = None
        getitem_812 = convolution_backward_default_59[0]
        getitem_813 = convolution_backward_default_59[1]
        getitem_814 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        to_dtype_180 = torch.ops.aten.to.dtype(getitem_812, torch.float32);  getitem_812 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_209, to_dtype_180);  le_scalar_60 = new_zeros_default_209 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_88, primals_305, primals_303, primals_304, getitem_271, getitem_272, True, 0.001, [True, True, True]);  to_dtype_182 = convolution_default_88 = primals_305 = primals_303 = primals_304 = getitem_271 = getitem_272 = None
        getitem_815 = native_batch_norm_backward_default_60[0]
        getitem_816 = native_batch_norm_backward_default_60[1]
        getitem_817 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_815, relu__default_87, primals_306, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_815 = primals_306 = None
        getitem_818 = convolution_backward_default_60[0]
        getitem_819 = convolution_backward_default_60[1]
        getitem_820 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_818, torch.float32);  getitem_818 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_210, to_dtype_183);  le_scalar_61 = new_zeros_default_210 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_87, primals_299, primals_297, primals_298, getitem_268, getitem_269, True, 0.001, [True, True, True]);  to_dtype_185 = convolution_default_87 = primals_299 = primals_297 = primals_298 = getitem_268 = getitem_269 = None
        getitem_821 = native_batch_norm_backward_default_61[0]
        getitem_822 = native_batch_norm_backward_default_61[1]
        getitem_823 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_821, cat_default_11, primals_300, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_821 = primals_300 = None
        getitem_824 = convolution_backward_default_61[0]
        getitem_825 = convolution_backward_default_61[1]
        getitem_826 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_5, getitem_824);  avg_pool2d_backward_default_5 = getitem_824 = None
        to_dtype_186 = torch.ops.aten.to.dtype(slice_tensor_36, torch.float32);  slice_tensor_36 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_211, to_dtype_186);  le_scalar_62 = new_zeros_default_211 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_86, primals_293, primals_291, primals_292, getitem_265, getitem_266, True, 0.001, [True, True, True]);  to_dtype_188 = convolution_default_86 = primals_293 = primals_291 = primals_292 = getitem_265 = getitem_266 = None
        getitem_827 = native_batch_norm_backward_default_62[0]
        getitem_828 = native_batch_norm_backward_default_62[1]
        getitem_829 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_827, relu__default_85, primals_294, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_827 = primals_294 = None
        getitem_830 = convolution_backward_default_62[0]
        getitem_831 = convolution_backward_default_62[1]
        getitem_832 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_830, torch.float32);  getitem_830 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_212, to_dtype_189);  le_scalar_63 = new_zeros_default_212 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_85, primals_287, primals_285, primals_286, getitem_262, getitem_263, True, 0.001, [True, True, True]);  to_dtype_191 = convolution_default_85 = primals_287 = primals_285 = primals_286 = getitem_262 = getitem_263 = None
        getitem_833 = native_batch_norm_backward_default_63[0]
        getitem_834 = native_batch_norm_backward_default_63[1]
        getitem_835 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_833, relu__default_84, primals_288, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_833 = primals_288 = None
        getitem_836 = convolution_backward_default_63[0]
        getitem_837 = convolution_backward_default_63[1]
        getitem_838 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_836, torch.float32);  getitem_836 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_213, to_dtype_192);  le_scalar_64 = new_zeros_default_213 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_84, primals_281, primals_279, primals_280, getitem_259, getitem_260, True, 0.001, [True, True, True]);  to_dtype_194 = convolution_default_84 = primals_281 = primals_279 = primals_280 = getitem_259 = getitem_260 = None
        getitem_839 = native_batch_norm_backward_default_64[0]
        getitem_840 = native_batch_norm_backward_default_64[1]
        getitem_841 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_839, cat_default_11, primals_282, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_839 = primals_282 = None
        getitem_842 = convolution_backward_default_64[0]
        getitem_843 = convolution_backward_default_64[1]
        getitem_844 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, getitem_842);  add_tensor_23 = getitem_842 = None
        to_dtype_195 = torch.ops.aten.to.dtype(slice_tensor_35, torch.float32);  slice_tensor_35 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_214, to_dtype_195);  le_scalar_65 = new_zeros_default_214 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_83, primals_275, primals_273, primals_274, getitem_256, getitem_257, True, 0.001, [True, True, True]);  to_dtype_197 = convolution_default_83 = primals_275 = primals_273 = primals_274 = getitem_256 = getitem_257 = None
        getitem_845 = native_batch_norm_backward_default_65[0]
        getitem_846 = native_batch_norm_backward_default_65[1]
        getitem_847 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_845, cat_default_11, primals_276, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_845 = cat_default_11 = primals_276 = None
        getitem_848 = convolution_backward_default_65[0]
        getitem_849 = convolution_backward_default_65[1]
        getitem_850 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(add_tensor_24, getitem_848);  add_tensor_24 = getitem_848 = None
        slice_tensor_39 = torch.ops.aten.slice.Tensor(add_tensor_25, 1, 0, 384)
        slice_tensor_40 = torch.ops.aten.slice.Tensor(add_tensor_25, 1, 384, 640)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(add_tensor_25, 1, 640, 896)
        slice_tensor_42 = torch.ops.aten.slice.Tensor(add_tensor_25, 1, 896, 1024);  add_tensor_25 = None
        to_dtype_198 = torch.ops.aten.to.dtype(slice_tensor_42, torch.float32);  slice_tensor_42 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_215, to_dtype_198);  le_scalar_66 = new_zeros_default_215 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_82, primals_269, primals_267, primals_268, getitem_253, getitem_254, True, 0.001, [True, True, True]);  to_dtype_200 = convolution_default_82 = primals_269 = primals_267 = primals_268 = getitem_253 = getitem_254 = None
        getitem_851 = native_batch_norm_backward_default_66[0]
        getitem_852 = native_batch_norm_backward_default_66[1]
        getitem_853 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_851, avg_pool2d_default_7, primals_270, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_851 = avg_pool2d_default_7 = primals_270 = None
        getitem_854 = convolution_backward_default_66[0]
        getitem_855 = convolution_backward_default_66[1]
        getitem_856 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        avg_pool2d_backward_default_6 = torch.ops.aten.avg_pool2d_backward.default(getitem_854, cat_default_10, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_854 = None
        to_dtype_201 = torch.ops.aten.to.dtype(slice_tensor_41, torch.float32);  slice_tensor_41 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_216, to_dtype_201);  le_scalar_67 = new_zeros_default_216 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_81, primals_263, primals_261, primals_262, getitem_250, getitem_251, True, 0.001, [True, True, True]);  to_dtype_203 = convolution_default_81 = primals_263 = primals_261 = primals_262 = getitem_250 = getitem_251 = None
        getitem_857 = native_batch_norm_backward_default_67[0]
        getitem_858 = native_batch_norm_backward_default_67[1]
        getitem_859 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_857, relu__default_80, primals_264, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_857 = primals_264 = None
        getitem_860 = convolution_backward_default_67[0]
        getitem_861 = convolution_backward_default_67[1]
        getitem_862 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_860, torch.float32);  getitem_860 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_217, to_dtype_204);  le_scalar_68 = new_zeros_default_217 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_80, primals_257, primals_255, primals_256, getitem_247, getitem_248, True, 0.001, [True, True, True]);  to_dtype_206 = convolution_default_80 = primals_257 = primals_255 = primals_256 = getitem_247 = getitem_248 = None
        getitem_863 = native_batch_norm_backward_default_68[0]
        getitem_864 = native_batch_norm_backward_default_68[1]
        getitem_865 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_863, relu__default_79, primals_258, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_863 = primals_258 = None
        getitem_866 = convolution_backward_default_68[0]
        getitem_867 = convolution_backward_default_68[1]
        getitem_868 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_866, torch.float32);  getitem_866 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_218, to_dtype_207);  le_scalar_69 = new_zeros_default_218 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_79, primals_251, primals_249, primals_250, getitem_244, getitem_245, True, 0.001, [True, True, True]);  to_dtype_209 = convolution_default_79 = primals_251 = primals_249 = primals_250 = getitem_244 = getitem_245 = None
        getitem_869 = native_batch_norm_backward_default_69[0]
        getitem_870 = native_batch_norm_backward_default_69[1]
        getitem_871 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_869, relu__default_78, primals_252, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_869 = primals_252 = None
        getitem_872 = convolution_backward_default_69[0]
        getitem_873 = convolution_backward_default_69[1]
        getitem_874 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_872, torch.float32);  getitem_872 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_219, to_dtype_210);  le_scalar_70 = new_zeros_default_219 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_78, primals_245, primals_243, primals_244, getitem_241, getitem_242, True, 0.001, [True, True, True]);  to_dtype_212 = convolution_default_78 = primals_245 = primals_243 = primals_244 = getitem_241 = getitem_242 = None
        getitem_875 = native_batch_norm_backward_default_70[0]
        getitem_876 = native_batch_norm_backward_default_70[1]
        getitem_877 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_875, relu__default_77, primals_246, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_875 = primals_246 = None
        getitem_878 = convolution_backward_default_70[0]
        getitem_879 = convolution_backward_default_70[1]
        getitem_880 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_878, torch.float32);  getitem_878 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_220, to_dtype_213);  le_scalar_71 = new_zeros_default_220 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_77, primals_239, primals_237, primals_238, getitem_238, getitem_239, True, 0.001, [True, True, True]);  to_dtype_215 = convolution_default_77 = primals_239 = primals_237 = primals_238 = getitem_238 = getitem_239 = None
        getitem_881 = native_batch_norm_backward_default_71[0]
        getitem_882 = native_batch_norm_backward_default_71[1]
        getitem_883 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_881, cat_default_10, primals_240, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_881 = primals_240 = None
        getitem_884 = convolution_backward_default_71[0]
        getitem_885 = convolution_backward_default_71[1]
        getitem_886 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_6, getitem_884);  avg_pool2d_backward_default_6 = getitem_884 = None
        to_dtype_216 = torch.ops.aten.to.dtype(slice_tensor_40, torch.float32);  slice_tensor_40 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_221 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_221, to_dtype_216);  le_scalar_72 = new_zeros_default_221 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_76, primals_233, primals_231, primals_232, getitem_235, getitem_236, True, 0.001, [True, True, True]);  to_dtype_218 = convolution_default_76 = primals_233 = primals_231 = primals_232 = getitem_235 = getitem_236 = None
        getitem_887 = native_batch_norm_backward_default_72[0]
        getitem_888 = native_batch_norm_backward_default_72[1]
        getitem_889 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_887, relu__default_75, primals_234, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_887 = primals_234 = None
        getitem_890 = convolution_backward_default_72[0]
        getitem_891 = convolution_backward_default_72[1]
        getitem_892 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_890, torch.float32);  getitem_890 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_222 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_222, to_dtype_219);  le_scalar_73 = new_zeros_default_222 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_75, primals_227, primals_225, primals_226, getitem_232, getitem_233, True, 0.001, [True, True, True]);  to_dtype_221 = convolution_default_75 = primals_227 = primals_225 = primals_226 = getitem_232 = getitem_233 = None
        getitem_893 = native_batch_norm_backward_default_73[0]
        getitem_894 = native_batch_norm_backward_default_73[1]
        getitem_895 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_893, relu__default_74, primals_228, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_893 = primals_228 = None
        getitem_896 = convolution_backward_default_73[0]
        getitem_897 = convolution_backward_default_73[1]
        getitem_898 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_896, torch.float32);  getitem_896 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_223 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_223, to_dtype_222);  le_scalar_74 = new_zeros_default_223 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_74, primals_221, primals_219, primals_220, getitem_229, getitem_230, True, 0.001, [True, True, True]);  to_dtype_224 = convolution_default_74 = primals_221 = primals_219 = primals_220 = getitem_229 = getitem_230 = None
        getitem_899 = native_batch_norm_backward_default_74[0]
        getitem_900 = native_batch_norm_backward_default_74[1]
        getitem_901 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_899, cat_default_10, primals_222, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_899 = primals_222 = None
        getitem_902 = convolution_backward_default_74[0]
        getitem_903 = convolution_backward_default_74[1]
        getitem_904 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, getitem_902);  add_tensor_26 = getitem_902 = None
        to_dtype_225 = torch.ops.aten.to.dtype(slice_tensor_39, torch.float32);  slice_tensor_39 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_224 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_224, to_dtype_225);  le_scalar_75 = new_zeros_default_224 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_73, primals_215, primals_213, primals_214, getitem_226, getitem_227, True, 0.001, [True, True, True]);  to_dtype_227 = convolution_default_73 = primals_215 = primals_213 = primals_214 = getitem_226 = getitem_227 = None
        getitem_905 = native_batch_norm_backward_default_75[0]
        getitem_906 = native_batch_norm_backward_default_75[1]
        getitem_907 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_905, cat_default_10, primals_216, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_905 = cat_default_10 = primals_216 = None
        getitem_908 = convolution_backward_default_75[0]
        getitem_909 = convolution_backward_default_75[1]
        getitem_910 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, getitem_908);  add_tensor_27 = getitem_908 = None
        slice_tensor_43 = torch.ops.aten.slice.Tensor(add_tensor_28, 1, 0, 384)
        slice_tensor_44 = torch.ops.aten.slice.Tensor(add_tensor_28, 1, 384, 640)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(add_tensor_28, 1, 640, 896)
        slice_tensor_46 = torch.ops.aten.slice.Tensor(add_tensor_28, 1, 896, 1024);  add_tensor_28 = None
        to_dtype_228 = torch.ops.aten.to.dtype(slice_tensor_46, torch.float32);  slice_tensor_46 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_225 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_225, to_dtype_228);  le_scalar_76 = new_zeros_default_225 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_72, primals_209, primals_207, primals_208, getitem_223, getitem_224, True, 0.001, [True, True, True]);  to_dtype_230 = convolution_default_72 = primals_209 = primals_207 = primals_208 = getitem_223 = getitem_224 = None
        getitem_911 = native_batch_norm_backward_default_76[0]
        getitem_912 = native_batch_norm_backward_default_76[1]
        getitem_913 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_911, avg_pool2d_default_6, primals_210, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_911 = avg_pool2d_default_6 = primals_210 = None
        getitem_914 = convolution_backward_default_76[0]
        getitem_915 = convolution_backward_default_76[1]
        getitem_916 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        avg_pool2d_backward_default_7 = torch.ops.aten.avg_pool2d_backward.default(getitem_914, cat_default_9, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_914 = None
        to_dtype_231 = torch.ops.aten.to.dtype(slice_tensor_45, torch.float32);  slice_tensor_45 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_226 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_226, to_dtype_231);  le_scalar_77 = new_zeros_default_226 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_71, primals_203, primals_201, primals_202, getitem_220, getitem_221, True, 0.001, [True, True, True]);  to_dtype_233 = convolution_default_71 = primals_203 = primals_201 = primals_202 = getitem_220 = getitem_221 = None
        getitem_917 = native_batch_norm_backward_default_77[0]
        getitem_918 = native_batch_norm_backward_default_77[1]
        getitem_919 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_917, relu__default_70, primals_204, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_917 = primals_204 = None
        getitem_920 = convolution_backward_default_77[0]
        getitem_921 = convolution_backward_default_77[1]
        getitem_922 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        to_dtype_234 = torch.ops.aten.to.dtype(getitem_920, torch.float32);  getitem_920 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_227 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_227, to_dtype_234);  le_scalar_78 = new_zeros_default_227 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_70, primals_197, primals_195, primals_196, getitem_217, getitem_218, True, 0.001, [True, True, True]);  to_dtype_236 = convolution_default_70 = primals_197 = primals_195 = primals_196 = getitem_217 = getitem_218 = None
        getitem_923 = native_batch_norm_backward_default_78[0]
        getitem_924 = native_batch_norm_backward_default_78[1]
        getitem_925 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_923, relu__default_69, primals_198, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_923 = primals_198 = None
        getitem_926 = convolution_backward_default_78[0]
        getitem_927 = convolution_backward_default_78[1]
        getitem_928 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_926, torch.float32);  getitem_926 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_228 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_228, to_dtype_237);  le_scalar_79 = new_zeros_default_228 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_69, primals_191, primals_189, primals_190, getitem_214, getitem_215, True, 0.001, [True, True, True]);  to_dtype_239 = convolution_default_69 = primals_191 = primals_189 = primals_190 = getitem_214 = getitem_215 = None
        getitem_929 = native_batch_norm_backward_default_79[0]
        getitem_930 = native_batch_norm_backward_default_79[1]
        getitem_931 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_929, relu__default_68, primals_192, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_929 = primals_192 = None
        getitem_932 = convolution_backward_default_79[0]
        getitem_933 = convolution_backward_default_79[1]
        getitem_934 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        to_dtype_240 = torch.ops.aten.to.dtype(getitem_932, torch.float32);  getitem_932 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_229 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_229, to_dtype_240);  le_scalar_80 = new_zeros_default_229 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_68, primals_185, primals_183, primals_184, getitem_211, getitem_212, True, 0.001, [True, True, True]);  to_dtype_242 = convolution_default_68 = primals_185 = primals_183 = primals_184 = getitem_211 = getitem_212 = None
        getitem_935 = native_batch_norm_backward_default_80[0]
        getitem_936 = native_batch_norm_backward_default_80[1]
        getitem_937 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_935, relu__default_67, primals_186, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_935 = primals_186 = None
        getitem_938 = convolution_backward_default_80[0]
        getitem_939 = convolution_backward_default_80[1]
        getitem_940 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        to_dtype_243 = torch.ops.aten.to.dtype(getitem_938, torch.float32);  getitem_938 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_230 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_230, to_dtype_243);  le_scalar_81 = new_zeros_default_230 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_245, convolution_default_67, primals_179, primals_177, primals_178, getitem_208, getitem_209, True, 0.001, [True, True, True]);  to_dtype_245 = convolution_default_67 = primals_179 = primals_177 = primals_178 = getitem_208 = getitem_209 = None
        getitem_941 = native_batch_norm_backward_default_81[0]
        getitem_942 = native_batch_norm_backward_default_81[1]
        getitem_943 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_941, cat_default_9, primals_180, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_941 = primals_180 = None
        getitem_944 = convolution_backward_default_81[0]
        getitem_945 = convolution_backward_default_81[1]
        getitem_946 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_7, getitem_944);  avg_pool2d_backward_default_7 = getitem_944 = None
        to_dtype_246 = torch.ops.aten.to.dtype(slice_tensor_44, torch.float32);  slice_tensor_44 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_231 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_231, to_dtype_246);  le_scalar_82 = new_zeros_default_231 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_66, primals_173, primals_171, primals_172, getitem_205, getitem_206, True, 0.001, [True, True, True]);  to_dtype_248 = convolution_default_66 = primals_173 = primals_171 = primals_172 = getitem_205 = getitem_206 = None
        getitem_947 = native_batch_norm_backward_default_82[0]
        getitem_948 = native_batch_norm_backward_default_82[1]
        getitem_949 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_947, relu__default_65, primals_174, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_947 = primals_174 = None
        getitem_950 = convolution_backward_default_82[0]
        getitem_951 = convolution_backward_default_82[1]
        getitem_952 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_950, torch.float32);  getitem_950 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_232 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_232, to_dtype_249);  le_scalar_83 = new_zeros_default_232 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_65, primals_167, primals_165, primals_166, getitem_202, getitem_203, True, 0.001, [True, True, True]);  to_dtype_251 = convolution_default_65 = primals_167 = primals_165 = primals_166 = getitem_202 = getitem_203 = None
        getitem_953 = native_batch_norm_backward_default_83[0]
        getitem_954 = native_batch_norm_backward_default_83[1]
        getitem_955 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_953, relu__default_64, primals_168, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_953 = primals_168 = None
        getitem_956 = convolution_backward_default_83[0]
        getitem_957 = convolution_backward_default_83[1]
        getitem_958 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_956, torch.float32);  getitem_956 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_233 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_233, to_dtype_252);  le_scalar_84 = new_zeros_default_233 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_64, primals_161, primals_159, primals_160, getitem_199, getitem_200, True, 0.001, [True, True, True]);  to_dtype_254 = convolution_default_64 = primals_161 = primals_159 = primals_160 = getitem_199 = getitem_200 = None
        getitem_959 = native_batch_norm_backward_default_84[0]
        getitem_960 = native_batch_norm_backward_default_84[1]
        getitem_961 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_959, cat_default_9, primals_162, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_959 = primals_162 = None
        getitem_962 = convolution_backward_default_84[0]
        getitem_963 = convolution_backward_default_84[1]
        getitem_964 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_29, getitem_962);  add_tensor_29 = getitem_962 = None
        to_dtype_255 = torch.ops.aten.to.dtype(slice_tensor_43, torch.float32);  slice_tensor_43 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_234 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_234, to_dtype_255);  le_scalar_85 = new_zeros_default_234 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_257, convolution_default_63, primals_155, primals_153, primals_154, getitem_196, getitem_197, True, 0.001, [True, True, True]);  to_dtype_257 = convolution_default_63 = primals_155 = primals_153 = primals_154 = getitem_196 = getitem_197 = None
        getitem_965 = native_batch_norm_backward_default_85[0]
        getitem_966 = native_batch_norm_backward_default_85[1]
        getitem_967 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_965, cat_default_9, primals_156, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_965 = cat_default_9 = primals_156 = None
        getitem_968 = convolution_backward_default_85[0]
        getitem_969 = convolution_backward_default_85[1]
        getitem_970 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_30, getitem_968);  add_tensor_30 = getitem_968 = None
        slice_tensor_47 = torch.ops.aten.slice.Tensor(add_tensor_31, 1, 0, 384)
        slice_tensor_48 = torch.ops.aten.slice.Tensor(add_tensor_31, 1, 384, 640)
        slice_tensor_49 = torch.ops.aten.slice.Tensor(add_tensor_31, 1, 640, 896)
        slice_tensor_50 = torch.ops.aten.slice.Tensor(add_tensor_31, 1, 896, 1024);  add_tensor_31 = None
        to_dtype_258 = torch.ops.aten.to.dtype(slice_tensor_50, torch.float32);  slice_tensor_50 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_235 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_235, to_dtype_258);  le_scalar_86 = new_zeros_default_235 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_62, primals_149, primals_147, primals_148, getitem_193, getitem_194, True, 0.001, [True, True, True]);  to_dtype_260 = convolution_default_62 = primals_149 = primals_147 = primals_148 = getitem_193 = getitem_194 = None
        getitem_971 = native_batch_norm_backward_default_86[0]
        getitem_972 = native_batch_norm_backward_default_86[1]
        getitem_973 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_971, avg_pool2d_default_5, primals_150, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_971 = avg_pool2d_default_5 = primals_150 = None
        getitem_974 = convolution_backward_default_86[0]
        getitem_975 = convolution_backward_default_86[1]
        getitem_976 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        avg_pool2d_backward_default_8 = torch.ops.aten.avg_pool2d_backward.default(getitem_974, cat_default_8, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_974 = None
        to_dtype_261 = torch.ops.aten.to.dtype(slice_tensor_49, torch.float32);  slice_tensor_49 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_236 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_236, to_dtype_261);  le_scalar_87 = new_zeros_default_236 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_61, primals_143, primals_141, primals_142, getitem_190, getitem_191, True, 0.001, [True, True, True]);  to_dtype_263 = convolution_default_61 = primals_143 = primals_141 = primals_142 = getitem_190 = getitem_191 = None
        getitem_977 = native_batch_norm_backward_default_87[0]
        getitem_978 = native_batch_norm_backward_default_87[1]
        getitem_979 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_977, relu__default_60, primals_144, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_977 = primals_144 = None
        getitem_980 = convolution_backward_default_87[0]
        getitem_981 = convolution_backward_default_87[1]
        getitem_982 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        to_dtype_264 = torch.ops.aten.to.dtype(getitem_980, torch.float32);  getitem_980 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_237 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_237, to_dtype_264);  le_scalar_88 = new_zeros_default_237 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_60, primals_137, primals_135, primals_136, getitem_187, getitem_188, True, 0.001, [True, True, True]);  to_dtype_266 = convolution_default_60 = primals_137 = primals_135 = primals_136 = getitem_187 = getitem_188 = None
        getitem_983 = native_batch_norm_backward_default_88[0]
        getitem_984 = native_batch_norm_backward_default_88[1]
        getitem_985 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_983, relu__default_59, primals_138, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_983 = primals_138 = None
        getitem_986 = convolution_backward_default_88[0]
        getitem_987 = convolution_backward_default_88[1]
        getitem_988 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_986, torch.float32);  getitem_986 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_238 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_238, to_dtype_267);  le_scalar_89 = new_zeros_default_238 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_59, primals_131, primals_129, primals_130, getitem_184, getitem_185, True, 0.001, [True, True, True]);  to_dtype_269 = convolution_default_59 = primals_131 = primals_129 = primals_130 = getitem_184 = getitem_185 = None
        getitem_989 = native_batch_norm_backward_default_89[0]
        getitem_990 = native_batch_norm_backward_default_89[1]
        getitem_991 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_989, relu__default_58, primals_132, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_989 = primals_132 = None
        getitem_992 = convolution_backward_default_89[0]
        getitem_993 = convolution_backward_default_89[1]
        getitem_994 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        to_dtype_270 = torch.ops.aten.to.dtype(getitem_992, torch.float32);  getitem_992 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_239 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_239, to_dtype_270);  le_scalar_90 = new_zeros_default_239 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_58, primals_125, primals_123, primals_124, getitem_181, getitem_182, True, 0.001, [True, True, True]);  to_dtype_272 = convolution_default_58 = primals_125 = primals_123 = primals_124 = getitem_181 = getitem_182 = None
        getitem_995 = native_batch_norm_backward_default_90[0]
        getitem_996 = native_batch_norm_backward_default_90[1]
        getitem_997 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_995, relu__default_57, primals_126, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_995 = primals_126 = None
        getitem_998 = convolution_backward_default_90[0]
        getitem_999 = convolution_backward_default_90[1]
        getitem_1000 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_998, torch.float32);  getitem_998 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_240 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_240, to_dtype_273);  le_scalar_91 = new_zeros_default_240 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_57, primals_119, primals_117, primals_118, getitem_178, getitem_179, True, 0.001, [True, True, True]);  to_dtype_275 = convolution_default_57 = primals_119 = primals_117 = primals_118 = getitem_178 = getitem_179 = None
        getitem_1001 = native_batch_norm_backward_default_91[0]
        getitem_1002 = native_batch_norm_backward_default_91[1]
        getitem_1003 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_1001, cat_default_8, primals_120, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1001 = primals_120 = None
        getitem_1004 = convolution_backward_default_91[0]
        getitem_1005 = convolution_backward_default_91[1]
        getitem_1006 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_8, getitem_1004);  avg_pool2d_backward_default_8 = getitem_1004 = None
        to_dtype_276 = torch.ops.aten.to.dtype(slice_tensor_48, torch.float32);  slice_tensor_48 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_241 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_241, to_dtype_276);  le_scalar_92 = new_zeros_default_241 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_278, convolution_default_56, primals_113, primals_111, primals_112, getitem_175, getitem_176, True, 0.001, [True, True, True]);  to_dtype_278 = convolution_default_56 = primals_113 = primals_111 = primals_112 = getitem_175 = getitem_176 = None
        getitem_1007 = native_batch_norm_backward_default_92[0]
        getitem_1008 = native_batch_norm_backward_default_92[1]
        getitem_1009 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_1007, relu__default_55, primals_114, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1007 = primals_114 = None
        getitem_1010 = convolution_backward_default_92[0]
        getitem_1011 = convolution_backward_default_92[1]
        getitem_1012 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_1010, torch.float32);  getitem_1010 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_242 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_242, to_dtype_279);  le_scalar_93 = new_zeros_default_242 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_55, primals_107, primals_105, primals_106, getitem_172, getitem_173, True, 0.001, [True, True, True]);  to_dtype_281 = convolution_default_55 = primals_107 = primals_105 = primals_106 = getitem_172 = getitem_173 = None
        getitem_1013 = native_batch_norm_backward_default_93[0]
        getitem_1014 = native_batch_norm_backward_default_93[1]
        getitem_1015 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_1013, relu__default_54, primals_108, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1013 = primals_108 = None
        getitem_1016 = convolution_backward_default_93[0]
        getitem_1017 = convolution_backward_default_93[1]
        getitem_1018 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_1016, torch.float32);  getitem_1016 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_243 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_243, to_dtype_282);  le_scalar_94 = new_zeros_default_243 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_54, primals_101, primals_99, primals_100, getitem_169, getitem_170, True, 0.001, [True, True, True]);  to_dtype_284 = convolution_default_54 = primals_101 = primals_99 = primals_100 = getitem_169 = getitem_170 = None
        getitem_1019 = native_batch_norm_backward_default_94[0]
        getitem_1020 = native_batch_norm_backward_default_94[1]
        getitem_1021 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_1019, cat_default_8, primals_102, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1019 = primals_102 = None
        getitem_1022 = convolution_backward_default_94[0]
        getitem_1023 = convolution_backward_default_94[1]
        getitem_1024 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(add_tensor_32, getitem_1022);  add_tensor_32 = getitem_1022 = None
        to_dtype_285 = torch.ops.aten.to.dtype(slice_tensor_47, torch.float32);  slice_tensor_47 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_244 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_244, to_dtype_285);  le_scalar_95 = new_zeros_default_244 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_287, convolution_default_53, primals_95, primals_93, primals_94, getitem_166, getitem_167, True, 0.001, [True, True, True]);  to_dtype_287 = convolution_default_53 = primals_95 = primals_93 = primals_94 = getitem_166 = getitem_167 = None
        getitem_1025 = native_batch_norm_backward_default_95[0]
        getitem_1026 = native_batch_norm_backward_default_95[1]
        getitem_1027 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_1025, cat_default_8, primals_96, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1025 = cat_default_8 = primals_96 = None
        getitem_1028 = convolution_backward_default_95[0]
        getitem_1029 = convolution_backward_default_95[1]
        getitem_1030 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, getitem_1028);  add_tensor_33 = getitem_1028 = None
        slice_tensor_51 = torch.ops.aten.slice.Tensor(add_tensor_34, 1, 0, 384)
        slice_tensor_52 = torch.ops.aten.slice.Tensor(add_tensor_34, 1, 384, 640)
        slice_tensor_53 = torch.ops.aten.slice.Tensor(add_tensor_34, 1, 640, 896)
        slice_tensor_54 = torch.ops.aten.slice.Tensor(add_tensor_34, 1, 896, 1024);  add_tensor_34 = None
        to_dtype_288 = torch.ops.aten.to.dtype(slice_tensor_54, torch.float32);  slice_tensor_54 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_245 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_245, to_dtype_288);  le_scalar_96 = new_zeros_default_245 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_52, primals_89, primals_87, primals_88, getitem_163, getitem_164, True, 0.001, [True, True, True]);  to_dtype_290 = convolution_default_52 = primals_89 = primals_87 = primals_88 = getitem_163 = getitem_164 = None
        getitem_1031 = native_batch_norm_backward_default_96[0]
        getitem_1032 = native_batch_norm_backward_default_96[1]
        getitem_1033 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_1031, avg_pool2d_default_4, primals_90, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1031 = avg_pool2d_default_4 = primals_90 = None
        getitem_1034 = convolution_backward_default_96[0]
        getitem_1035 = convolution_backward_default_96[1]
        getitem_1036 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        avg_pool2d_backward_default_9 = torch.ops.aten.avg_pool2d_backward.default(getitem_1034, cat_default_7, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_1034 = None
        to_dtype_291 = torch.ops.aten.to.dtype(slice_tensor_53, torch.float32);  slice_tensor_53 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_246 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_246, to_dtype_291);  le_scalar_97 = new_zeros_default_246 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_293, convolution_default_51, primals_83, primals_81, primals_82, getitem_160, getitem_161, True, 0.001, [True, True, True]);  to_dtype_293 = convolution_default_51 = primals_83 = primals_81 = primals_82 = getitem_160 = getitem_161 = None
        getitem_1037 = native_batch_norm_backward_default_97[0]
        getitem_1038 = native_batch_norm_backward_default_97[1]
        getitem_1039 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_1037, relu__default_50, primals_84, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1037 = primals_84 = None
        getitem_1040 = convolution_backward_default_97[0]
        getitem_1041 = convolution_backward_default_97[1]
        getitem_1042 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_1040, torch.float32);  getitem_1040 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_247 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_247, to_dtype_294);  le_scalar_98 = new_zeros_default_247 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_50, primals_77, primals_75, primals_76, getitem_157, getitem_158, True, 0.001, [True, True, True]);  to_dtype_296 = convolution_default_50 = primals_77 = primals_75 = primals_76 = getitem_157 = getitem_158 = None
        getitem_1043 = native_batch_norm_backward_default_98[0]
        getitem_1044 = native_batch_norm_backward_default_98[1]
        getitem_1045 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_1043, relu__default_49, primals_78, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1043 = primals_78 = None
        getitem_1046 = convolution_backward_default_98[0]
        getitem_1047 = convolution_backward_default_98[1]
        getitem_1048 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_1046, torch.float32);  getitem_1046 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_248 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_248, to_dtype_297);  le_scalar_99 = new_zeros_default_248 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_49, primals_71, primals_69, primals_70, getitem_154, getitem_155, True, 0.001, [True, True, True]);  to_dtype_299 = convolution_default_49 = primals_71 = primals_69 = primals_70 = getitem_154 = getitem_155 = None
        getitem_1049 = native_batch_norm_backward_default_99[0]
        getitem_1050 = native_batch_norm_backward_default_99[1]
        getitem_1051 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_1049, relu__default_48, primals_72, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1049 = primals_72 = None
        getitem_1052 = convolution_backward_default_99[0]
        getitem_1053 = convolution_backward_default_99[1]
        getitem_1054 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        to_dtype_300 = torch.ops.aten.to.dtype(getitem_1052, torch.float32);  getitem_1052 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_249 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_249, to_dtype_300);  le_scalar_100 = new_zeros_default_249 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default_48, primals_65, primals_63, primals_64, getitem_151, getitem_152, True, 0.001, [True, True, True]);  to_dtype_302 = convolution_default_48 = primals_65 = primals_63 = primals_64 = getitem_151 = getitem_152 = None
        getitem_1055 = native_batch_norm_backward_default_100[0]
        getitem_1056 = native_batch_norm_backward_default_100[1]
        getitem_1057 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_1055, relu__default_47, primals_66, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1055 = primals_66 = None
        getitem_1058 = convolution_backward_default_100[0]
        getitem_1059 = convolution_backward_default_100[1]
        getitem_1060 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        to_dtype_303 = torch.ops.aten.to.dtype(getitem_1058, torch.float32);  getitem_1058 = None
        to_dtype_304 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_304, 0);  to_dtype_304 = None
        new_zeros_default_250 = torch.ops.aten.new_zeros.default(to_dtype_303, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_250, to_dtype_303);  le_scalar_101 = new_zeros_default_250 = to_dtype_303 = None
        to_dtype_305 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_305, convolution_default_47, primals_59, primals_57, primals_58, getitem_148, getitem_149, True, 0.001, [True, True, True]);  to_dtype_305 = convolution_default_47 = primals_59 = primals_57 = primals_58 = getitem_148 = getitem_149 = None
        getitem_1061 = native_batch_norm_backward_default_101[0]
        getitem_1062 = native_batch_norm_backward_default_101[1]
        getitem_1063 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1061, cat_default_7, primals_60, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1061 = primals_60 = None
        getitem_1064 = convolution_backward_default_101[0]
        getitem_1065 = convolution_backward_default_101[1]
        getitem_1066 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_9, getitem_1064);  avg_pool2d_backward_default_9 = getitem_1064 = None
        to_dtype_306 = torch.ops.aten.to.dtype(slice_tensor_52, torch.float32);  slice_tensor_52 = None
        to_dtype_307 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_307, 0);  to_dtype_307 = None
        new_zeros_default_251 = torch.ops.aten.new_zeros.default(to_dtype_306, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_251, to_dtype_306);  le_scalar_102 = new_zeros_default_251 = to_dtype_306 = None
        to_dtype_308 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_308, convolution_default_46, primals_53, primals_51, primals_52, getitem_145, getitem_146, True, 0.001, [True, True, True]);  to_dtype_308 = convolution_default_46 = primals_53 = primals_51 = primals_52 = getitem_145 = getitem_146 = None
        getitem_1067 = native_batch_norm_backward_default_102[0]
        getitem_1068 = native_batch_norm_backward_default_102[1]
        getitem_1069 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1067, relu__default_45, primals_54, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1067 = primals_54 = None
        getitem_1070 = convolution_backward_default_102[0]
        getitem_1071 = convolution_backward_default_102[1]
        getitem_1072 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        to_dtype_309 = torch.ops.aten.to.dtype(getitem_1070, torch.float32);  getitem_1070 = None
        to_dtype_310 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_310, 0);  to_dtype_310 = None
        new_zeros_default_252 = torch.ops.aten.new_zeros.default(to_dtype_309, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_252, to_dtype_309);  le_scalar_103 = new_zeros_default_252 = to_dtype_309 = None
        to_dtype_311 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_311, convolution_default_45, primals_47, primals_45, primals_46, getitem_142, getitem_143, True, 0.001, [True, True, True]);  to_dtype_311 = convolution_default_45 = primals_47 = primals_45 = primals_46 = getitem_142 = getitem_143 = None
        getitem_1073 = native_batch_norm_backward_default_103[0]
        getitem_1074 = native_batch_norm_backward_default_103[1]
        getitem_1075 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_1073, relu__default_44, primals_48, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1073 = primals_48 = None
        getitem_1076 = convolution_backward_default_103[0]
        getitem_1077 = convolution_backward_default_103[1]
        getitem_1078 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        to_dtype_312 = torch.ops.aten.to.dtype(getitem_1076, torch.float32);  getitem_1076 = None
        to_dtype_313 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_313, 0);  to_dtype_313 = None
        new_zeros_default_253 = torch.ops.aten.new_zeros.default(to_dtype_312, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_253, to_dtype_312);  le_scalar_104 = new_zeros_default_253 = to_dtype_312 = None
        to_dtype_314 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_314, convolution_default_44, primals_41, primals_39, primals_40, getitem_139, getitem_140, True, 0.001, [True, True, True]);  to_dtype_314 = convolution_default_44 = primals_41 = primals_39 = primals_40 = getitem_139 = getitem_140 = None
        getitem_1079 = native_batch_norm_backward_default_104[0]
        getitem_1080 = native_batch_norm_backward_default_104[1]
        getitem_1081 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_1079, cat_default_7, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1079 = primals_42 = None
        getitem_1082 = convolution_backward_default_104[0]
        getitem_1083 = convolution_backward_default_104[1]
        getitem_1084 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_35, getitem_1082);  add_tensor_35 = getitem_1082 = None
        to_dtype_315 = torch.ops.aten.to.dtype(slice_tensor_51, torch.float32);  slice_tensor_51 = None
        to_dtype_316 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_316, 0);  to_dtype_316 = None
        new_zeros_default_254 = torch.ops.aten.new_zeros.default(to_dtype_315, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_254, to_dtype_315);  le_scalar_105 = new_zeros_default_254 = to_dtype_315 = None
        to_dtype_317 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_317, convolution_default_43, primals_35, primals_33, primals_34, getitem_136, getitem_137, True, 0.001, [True, True, True]);  to_dtype_317 = convolution_default_43 = primals_35 = primals_33 = primals_34 = getitem_136 = getitem_137 = None
        getitem_1085 = native_batch_norm_backward_default_105[0]
        getitem_1086 = native_batch_norm_backward_default_105[1]
        getitem_1087 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_1085, cat_default_7, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1085 = cat_default_7 = primals_36 = None
        getitem_1088 = convolution_backward_default_105[0]
        getitem_1089 = convolution_backward_default_105[1]
        getitem_1090 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_36, getitem_1088);  add_tensor_36 = getitem_1088 = None
        slice_tensor_55 = torch.ops.aten.slice.Tensor(add_tensor_37, 1, 0, 384)
        slice_tensor_56 = torch.ops.aten.slice.Tensor(add_tensor_37, 1, 384, 640)
        slice_tensor_57 = torch.ops.aten.slice.Tensor(add_tensor_37, 1, 640, 1024);  add_tensor_37 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_57, cat_default_6, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_134);  slice_tensor_57 = getitem_134 = None
        to_dtype_318 = torch.ops.aten.to.dtype(slice_tensor_56, torch.float32);  slice_tensor_56 = None
        to_dtype_319 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_319, 0);  to_dtype_319 = None
        new_zeros_default_255 = torch.ops.aten.new_zeros.default(to_dtype_318, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_255, to_dtype_318);  le_scalar_106 = new_zeros_default_255 = to_dtype_318 = None
        to_dtype_320 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_320, convolution_default_42, primals_29, primals_27, primals_28, getitem_131, getitem_132, True, 0.001, [True, True, True]);  to_dtype_320 = convolution_default_42 = primals_29 = primals_27 = primals_28 = getitem_131 = getitem_132 = None
        getitem_1091 = native_batch_norm_backward_default_106[0]
        getitem_1092 = native_batch_norm_backward_default_106[1]
        getitem_1093 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_1091, relu__default_41, primals_30, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1091 = primals_30 = None
        getitem_1094 = convolution_backward_default_106[0]
        getitem_1095 = convolution_backward_default_106[1]
        getitem_1096 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        to_dtype_321 = torch.ops.aten.to.dtype(getitem_1094, torch.float32);  getitem_1094 = None
        to_dtype_322 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_322, 0);  to_dtype_322 = None
        new_zeros_default_256 = torch.ops.aten.new_zeros.default(to_dtype_321, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_256, to_dtype_321);  le_scalar_107 = new_zeros_default_256 = to_dtype_321 = None
        to_dtype_323 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_323, convolution_default_41, primals_23, primals_21, primals_22, getitem_128, getitem_129, True, 0.001, [True, True, True]);  to_dtype_323 = convolution_default_41 = primals_23 = primals_21 = primals_22 = getitem_128 = getitem_129 = None
        getitem_1097 = native_batch_norm_backward_default_107[0]
        getitem_1098 = native_batch_norm_backward_default_107[1]
        getitem_1099 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_1097, relu__default_40, primals_24, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1097 = primals_24 = None
        getitem_1100 = convolution_backward_default_107[0]
        getitem_1101 = convolution_backward_default_107[1]
        getitem_1102 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        to_dtype_324 = torch.ops.aten.to.dtype(getitem_1100, torch.float32);  getitem_1100 = None
        to_dtype_325 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_325, 0);  to_dtype_325 = None
        new_zeros_default_257 = torch.ops.aten.new_zeros.default(to_dtype_324, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_257, to_dtype_324);  le_scalar_108 = new_zeros_default_257 = to_dtype_324 = None
        to_dtype_326 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_326, convolution_default_40, primals_17, primals_15, primals_16, getitem_125, getitem_126, True, 0.001, [True, True, True]);  to_dtype_326 = convolution_default_40 = primals_17 = primals_15 = primals_16 = getitem_125 = getitem_126 = None
        getitem_1103 = native_batch_norm_backward_default_108[0]
        getitem_1104 = native_batch_norm_backward_default_108[1]
        getitem_1105 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(getitem_1103, cat_default_6, primals_18, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1103 = primals_18 = None
        getitem_1106 = convolution_backward_default_108[0]
        getitem_1107 = convolution_backward_default_108[1]
        getitem_1108 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(max_pool2d_with_indices_backward_default_1, getitem_1106);  max_pool2d_with_indices_backward_default_1 = getitem_1106 = None
        to_dtype_327 = torch.ops.aten.to.dtype(slice_tensor_55, torch.float32);  slice_tensor_55 = None
        to_dtype_328 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_328, 0);  to_dtype_328 = None
        new_zeros_default_258 = torch.ops.aten.new_zeros.default(to_dtype_327, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_258, to_dtype_327);  le_scalar_109 = new_zeros_default_258 = to_dtype_327 = None
        to_dtype_329 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_329, convolution_default_39, primals_11, primals_9, primals_10, getitem_122, getitem_123, True, 0.001, [True, True, True]);  to_dtype_329 = convolution_default_39 = primals_11 = primals_9 = primals_10 = getitem_122 = getitem_123 = None
        getitem_1109 = native_batch_norm_backward_default_109[0]
        getitem_1110 = native_batch_norm_backward_default_109[1]
        getitem_1111 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_1109, cat_default_6, primals_12, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1109 = cat_default_6 = primals_12 = None
        getitem_1112 = convolution_backward_default_109[0]
        getitem_1113 = convolution_backward_default_109[1]
        getitem_1114 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(add_tensor_38, getitem_1112);  add_tensor_38 = getitem_1112 = None
        slice_tensor_58 = torch.ops.aten.slice.Tensor(add_tensor_39, 1, 0, 96)
        slice_tensor_59 = torch.ops.aten.slice.Tensor(add_tensor_39, 1, 96, 192)
        slice_tensor_60 = torch.ops.aten.slice.Tensor(add_tensor_39, 1, 192, 288)
        slice_tensor_61 = torch.ops.aten.slice.Tensor(add_tensor_39, 1, 288, 384);  add_tensor_39 = None
        to_dtype_330 = torch.ops.aten.to.dtype(slice_tensor_61, torch.float32);  slice_tensor_61 = None
        to_dtype_331 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_331, 0);  to_dtype_331 = None
        new_zeros_default_259 = torch.ops.aten.new_zeros.default(to_dtype_330, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_259, to_dtype_330);  le_scalar_110 = new_zeros_default_259 = to_dtype_330 = None
        to_dtype_332 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_332, convolution_default_38, primals_893, primals_891, primals_892, getitem_119, getitem_120, True, 0.001, [True, True, True]);  to_dtype_332 = convolution_default_38 = primals_893 = primals_891 = primals_892 = getitem_119 = getitem_120 = None
        getitem_1115 = native_batch_norm_backward_default_110[0]
        getitem_1116 = native_batch_norm_backward_default_110[1]
        getitem_1117 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(getitem_1115, avg_pool2d_default_3, primals_894, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1115 = avg_pool2d_default_3 = primals_894 = None
        getitem_1118 = convolution_backward_default_110[0]
        getitem_1119 = convolution_backward_default_110[1]
        getitem_1120 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        avg_pool2d_backward_default_10 = torch.ops.aten.avg_pool2d_backward.default(getitem_1118, cat_default_5, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_1118 = None
        to_dtype_333 = torch.ops.aten.to.dtype(slice_tensor_60, torch.float32);  slice_tensor_60 = None
        to_dtype_334 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_111 = torch.ops.aten.le.Scalar(to_dtype_334, 0);  to_dtype_334 = None
        new_zeros_default_260 = torch.ops.aten.new_zeros.default(to_dtype_333, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_111, new_zeros_default_260, to_dtype_333);  le_scalar_111 = new_zeros_default_260 = to_dtype_333 = None
        to_dtype_335 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_111 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_335, convolution_default_37, primals_887, primals_885, primals_886, getitem_116, getitem_117, True, 0.001, [True, True, True]);  to_dtype_335 = convolution_default_37 = primals_887 = primals_885 = primals_886 = getitem_116 = getitem_117 = None
        getitem_1121 = native_batch_norm_backward_default_111[0]
        getitem_1122 = native_batch_norm_backward_default_111[1]
        getitem_1123 = native_batch_norm_backward_default_111[2];  native_batch_norm_backward_default_111 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(getitem_1121, relu__default_36, primals_888, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1121 = primals_888 = None
        getitem_1124 = convolution_backward_default_111[0]
        getitem_1125 = convolution_backward_default_111[1]
        getitem_1126 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        to_dtype_336 = torch.ops.aten.to.dtype(getitem_1124, torch.float32);  getitem_1124 = None
        to_dtype_337 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_112 = torch.ops.aten.le.Scalar(to_dtype_337, 0);  to_dtype_337 = None
        new_zeros_default_261 = torch.ops.aten.new_zeros.default(to_dtype_336, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_112 = torch.ops.aten.where.self(le_scalar_112, new_zeros_default_261, to_dtype_336);  le_scalar_112 = new_zeros_default_261 = to_dtype_336 = None
        to_dtype_338 = torch.ops.aten.to.dtype(where_self_112, torch.float32);  where_self_112 = None
        native_batch_norm_backward_default_112 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_338, convolution_default_36, primals_881, primals_879, primals_880, getitem_113, getitem_114, True, 0.001, [True, True, True]);  to_dtype_338 = convolution_default_36 = primals_881 = primals_879 = primals_880 = getitem_113 = getitem_114 = None
        getitem_1127 = native_batch_norm_backward_default_112[0]
        getitem_1128 = native_batch_norm_backward_default_112[1]
        getitem_1129 = native_batch_norm_backward_default_112[2];  native_batch_norm_backward_default_112 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(getitem_1127, relu__default_35, primals_882, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1127 = primals_882 = None
        getitem_1130 = convolution_backward_default_112[0]
        getitem_1131 = convolution_backward_default_112[1]
        getitem_1132 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        to_dtype_339 = torch.ops.aten.to.dtype(getitem_1130, torch.float32);  getitem_1130 = None
        to_dtype_340 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_113 = torch.ops.aten.le.Scalar(to_dtype_340, 0);  to_dtype_340 = None
        new_zeros_default_262 = torch.ops.aten.new_zeros.default(to_dtype_339, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_113 = torch.ops.aten.where.self(le_scalar_113, new_zeros_default_262, to_dtype_339);  le_scalar_113 = new_zeros_default_262 = to_dtype_339 = None
        to_dtype_341 = torch.ops.aten.to.dtype(where_self_113, torch.float32);  where_self_113 = None
        native_batch_norm_backward_default_113 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_341, convolution_default_35, primals_875, primals_873, primals_874, getitem_110, getitem_111, True, 0.001, [True, True, True]);  to_dtype_341 = convolution_default_35 = primals_875 = primals_873 = primals_874 = getitem_110 = getitem_111 = None
        getitem_1133 = native_batch_norm_backward_default_113[0]
        getitem_1134 = native_batch_norm_backward_default_113[1]
        getitem_1135 = native_batch_norm_backward_default_113[2];  native_batch_norm_backward_default_113 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(getitem_1133, cat_default_5, primals_876, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1133 = primals_876 = None
        getitem_1136 = convolution_backward_default_113[0]
        getitem_1137 = convolution_backward_default_113[1]
        getitem_1138 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_10, getitem_1136);  avg_pool2d_backward_default_10 = getitem_1136 = None
        to_dtype_342 = torch.ops.aten.to.dtype(slice_tensor_59, torch.float32);  slice_tensor_59 = None
        to_dtype_343 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_114 = torch.ops.aten.le.Scalar(to_dtype_343, 0);  to_dtype_343 = None
        new_zeros_default_263 = torch.ops.aten.new_zeros.default(to_dtype_342, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_114 = torch.ops.aten.where.self(le_scalar_114, new_zeros_default_263, to_dtype_342);  le_scalar_114 = new_zeros_default_263 = to_dtype_342 = None
        to_dtype_344 = torch.ops.aten.to.dtype(where_self_114, torch.float32);  where_self_114 = None
        native_batch_norm_backward_default_114 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_344, convolution_default_34, primals_869, primals_867, primals_868, getitem_107, getitem_108, True, 0.001, [True, True, True]);  to_dtype_344 = convolution_default_34 = primals_869 = primals_867 = primals_868 = getitem_107 = getitem_108 = None
        getitem_1139 = native_batch_norm_backward_default_114[0]
        getitem_1140 = native_batch_norm_backward_default_114[1]
        getitem_1141 = native_batch_norm_backward_default_114[2];  native_batch_norm_backward_default_114 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(getitem_1139, relu__default_33, primals_870, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1139 = primals_870 = None
        getitem_1142 = convolution_backward_default_114[0]
        getitem_1143 = convolution_backward_default_114[1]
        getitem_1144 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        to_dtype_345 = torch.ops.aten.to.dtype(getitem_1142, torch.float32);  getitem_1142 = None
        to_dtype_346 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_115 = torch.ops.aten.le.Scalar(to_dtype_346, 0);  to_dtype_346 = None
        new_zeros_default_264 = torch.ops.aten.new_zeros.default(to_dtype_345, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_115 = torch.ops.aten.where.self(le_scalar_115, new_zeros_default_264, to_dtype_345);  le_scalar_115 = new_zeros_default_264 = to_dtype_345 = None
        to_dtype_347 = torch.ops.aten.to.dtype(where_self_115, torch.float32);  where_self_115 = None
        native_batch_norm_backward_default_115 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_347, convolution_default_33, primals_863, primals_861, primals_862, getitem_104, getitem_105, True, 0.001, [True, True, True]);  to_dtype_347 = convolution_default_33 = primals_863 = primals_861 = primals_862 = getitem_104 = getitem_105 = None
        getitem_1145 = native_batch_norm_backward_default_115[0]
        getitem_1146 = native_batch_norm_backward_default_115[1]
        getitem_1147 = native_batch_norm_backward_default_115[2];  native_batch_norm_backward_default_115 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(getitem_1145, cat_default_5, primals_864, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1145 = primals_864 = None
        getitem_1148 = convolution_backward_default_115[0]
        getitem_1149 = convolution_backward_default_115[1]
        getitem_1150 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(add_tensor_40, getitem_1148);  add_tensor_40 = getitem_1148 = None
        to_dtype_348 = torch.ops.aten.to.dtype(slice_tensor_58, torch.float32);  slice_tensor_58 = None
        to_dtype_349 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_116 = torch.ops.aten.le.Scalar(to_dtype_349, 0);  to_dtype_349 = None
        new_zeros_default_265 = torch.ops.aten.new_zeros.default(to_dtype_348, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_116 = torch.ops.aten.where.self(le_scalar_116, new_zeros_default_265, to_dtype_348);  le_scalar_116 = new_zeros_default_265 = to_dtype_348 = None
        to_dtype_350 = torch.ops.aten.to.dtype(where_self_116, torch.float32);  where_self_116 = None
        native_batch_norm_backward_default_116 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_350, convolution_default_32, primals_857, primals_855, primals_856, getitem_101, getitem_102, True, 0.001, [True, True, True]);  to_dtype_350 = convolution_default_32 = primals_857 = primals_855 = primals_856 = getitem_101 = getitem_102 = None
        getitem_1151 = native_batch_norm_backward_default_116[0]
        getitem_1152 = native_batch_norm_backward_default_116[1]
        getitem_1153 = native_batch_norm_backward_default_116[2];  native_batch_norm_backward_default_116 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(getitem_1151, cat_default_5, primals_858, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1151 = cat_default_5 = primals_858 = None
        getitem_1154 = convolution_backward_default_116[0]
        getitem_1155 = convolution_backward_default_116[1]
        getitem_1156 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, getitem_1154);  add_tensor_41 = getitem_1154 = None
        slice_tensor_62 = torch.ops.aten.slice.Tensor(add_tensor_42, 1, 0, 96)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(add_tensor_42, 1, 96, 192)
        slice_tensor_64 = torch.ops.aten.slice.Tensor(add_tensor_42, 1, 192, 288)
        slice_tensor_65 = torch.ops.aten.slice.Tensor(add_tensor_42, 1, 288, 384);  add_tensor_42 = None
        to_dtype_351 = torch.ops.aten.to.dtype(slice_tensor_65, torch.float32);  slice_tensor_65 = None
        to_dtype_352 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_117 = torch.ops.aten.le.Scalar(to_dtype_352, 0);  to_dtype_352 = None
        new_zeros_default_266 = torch.ops.aten.new_zeros.default(to_dtype_351, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_117 = torch.ops.aten.where.self(le_scalar_117, new_zeros_default_266, to_dtype_351);  le_scalar_117 = new_zeros_default_266 = to_dtype_351 = None
        to_dtype_353 = torch.ops.aten.to.dtype(where_self_117, torch.float32);  where_self_117 = None
        native_batch_norm_backward_default_117 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_353, convolution_default_31, primals_851, primals_849, primals_850, getitem_98, getitem_99, True, 0.001, [True, True, True]);  to_dtype_353 = convolution_default_31 = primals_851 = primals_849 = primals_850 = getitem_98 = getitem_99 = None
        getitem_1157 = native_batch_norm_backward_default_117[0]
        getitem_1158 = native_batch_norm_backward_default_117[1]
        getitem_1159 = native_batch_norm_backward_default_117[2];  native_batch_norm_backward_default_117 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(getitem_1157, avg_pool2d_default_2, primals_852, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1157 = avg_pool2d_default_2 = primals_852 = None
        getitem_1160 = convolution_backward_default_117[0]
        getitem_1161 = convolution_backward_default_117[1]
        getitem_1162 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        avg_pool2d_backward_default_11 = torch.ops.aten.avg_pool2d_backward.default(getitem_1160, cat_default_4, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_1160 = None
        to_dtype_354 = torch.ops.aten.to.dtype(slice_tensor_64, torch.float32);  slice_tensor_64 = None
        to_dtype_355 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_118 = torch.ops.aten.le.Scalar(to_dtype_355, 0);  to_dtype_355 = None
        new_zeros_default_267 = torch.ops.aten.new_zeros.default(to_dtype_354, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_118 = torch.ops.aten.where.self(le_scalar_118, new_zeros_default_267, to_dtype_354);  le_scalar_118 = new_zeros_default_267 = to_dtype_354 = None
        to_dtype_356 = torch.ops.aten.to.dtype(where_self_118, torch.float32);  where_self_118 = None
        native_batch_norm_backward_default_118 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_356, convolution_default_30, primals_845, primals_843, primals_844, getitem_95, getitem_96, True, 0.001, [True, True, True]);  to_dtype_356 = convolution_default_30 = primals_845 = primals_843 = primals_844 = getitem_95 = getitem_96 = None
        getitem_1163 = native_batch_norm_backward_default_118[0]
        getitem_1164 = native_batch_norm_backward_default_118[1]
        getitem_1165 = native_batch_norm_backward_default_118[2];  native_batch_norm_backward_default_118 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(getitem_1163, relu__default_29, primals_846, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1163 = primals_846 = None
        getitem_1166 = convolution_backward_default_118[0]
        getitem_1167 = convolution_backward_default_118[1]
        getitem_1168 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        to_dtype_357 = torch.ops.aten.to.dtype(getitem_1166, torch.float32);  getitem_1166 = None
        to_dtype_358 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_119 = torch.ops.aten.le.Scalar(to_dtype_358, 0);  to_dtype_358 = None
        new_zeros_default_268 = torch.ops.aten.new_zeros.default(to_dtype_357, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_119 = torch.ops.aten.where.self(le_scalar_119, new_zeros_default_268, to_dtype_357);  le_scalar_119 = new_zeros_default_268 = to_dtype_357 = None
        to_dtype_359 = torch.ops.aten.to.dtype(where_self_119, torch.float32);  where_self_119 = None
        native_batch_norm_backward_default_119 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_359, convolution_default_29, primals_839, primals_837, primals_838, getitem_92, getitem_93, True, 0.001, [True, True, True]);  to_dtype_359 = convolution_default_29 = primals_839 = primals_837 = primals_838 = getitem_92 = getitem_93 = None
        getitem_1169 = native_batch_norm_backward_default_119[0]
        getitem_1170 = native_batch_norm_backward_default_119[1]
        getitem_1171 = native_batch_norm_backward_default_119[2];  native_batch_norm_backward_default_119 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(getitem_1169, relu__default_28, primals_840, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1169 = primals_840 = None
        getitem_1172 = convolution_backward_default_119[0]
        getitem_1173 = convolution_backward_default_119[1]
        getitem_1174 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        to_dtype_360 = torch.ops.aten.to.dtype(getitem_1172, torch.float32);  getitem_1172 = None
        to_dtype_361 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_120 = torch.ops.aten.le.Scalar(to_dtype_361, 0);  to_dtype_361 = None
        new_zeros_default_269 = torch.ops.aten.new_zeros.default(to_dtype_360, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_120 = torch.ops.aten.where.self(le_scalar_120, new_zeros_default_269, to_dtype_360);  le_scalar_120 = new_zeros_default_269 = to_dtype_360 = None
        to_dtype_362 = torch.ops.aten.to.dtype(where_self_120, torch.float32);  where_self_120 = None
        native_batch_norm_backward_default_120 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_362, convolution_default_28, primals_833, primals_831, primals_832, getitem_89, getitem_90, True, 0.001, [True, True, True]);  to_dtype_362 = convolution_default_28 = primals_833 = primals_831 = primals_832 = getitem_89 = getitem_90 = None
        getitem_1175 = native_batch_norm_backward_default_120[0]
        getitem_1176 = native_batch_norm_backward_default_120[1]
        getitem_1177 = native_batch_norm_backward_default_120[2];  native_batch_norm_backward_default_120 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(getitem_1175, cat_default_4, primals_834, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1175 = primals_834 = None
        getitem_1178 = convolution_backward_default_120[0]
        getitem_1179 = convolution_backward_default_120[1]
        getitem_1180 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_11, getitem_1178);  avg_pool2d_backward_default_11 = getitem_1178 = None
        to_dtype_363 = torch.ops.aten.to.dtype(slice_tensor_63, torch.float32);  slice_tensor_63 = None
        to_dtype_364 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_121 = torch.ops.aten.le.Scalar(to_dtype_364, 0);  to_dtype_364 = None
        new_zeros_default_270 = torch.ops.aten.new_zeros.default(to_dtype_363, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_121 = torch.ops.aten.where.self(le_scalar_121, new_zeros_default_270, to_dtype_363);  le_scalar_121 = new_zeros_default_270 = to_dtype_363 = None
        to_dtype_365 = torch.ops.aten.to.dtype(where_self_121, torch.float32);  where_self_121 = None
        native_batch_norm_backward_default_121 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_365, convolution_default_27, primals_827, primals_825, primals_826, getitem_86, getitem_87, True, 0.001, [True, True, True]);  to_dtype_365 = convolution_default_27 = primals_827 = primals_825 = primals_826 = getitem_86 = getitem_87 = None
        getitem_1181 = native_batch_norm_backward_default_121[0]
        getitem_1182 = native_batch_norm_backward_default_121[1]
        getitem_1183 = native_batch_norm_backward_default_121[2];  native_batch_norm_backward_default_121 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(getitem_1181, relu__default_26, primals_828, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1181 = primals_828 = None
        getitem_1184 = convolution_backward_default_121[0]
        getitem_1185 = convolution_backward_default_121[1]
        getitem_1186 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        to_dtype_366 = torch.ops.aten.to.dtype(getitem_1184, torch.float32);  getitem_1184 = None
        to_dtype_367 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_122 = torch.ops.aten.le.Scalar(to_dtype_367, 0);  to_dtype_367 = None
        new_zeros_default_271 = torch.ops.aten.new_zeros.default(to_dtype_366, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_122 = torch.ops.aten.where.self(le_scalar_122, new_zeros_default_271, to_dtype_366);  le_scalar_122 = new_zeros_default_271 = to_dtype_366 = None
        to_dtype_368 = torch.ops.aten.to.dtype(where_self_122, torch.float32);  where_self_122 = None
        native_batch_norm_backward_default_122 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_368, convolution_default_26, primals_821, primals_819, primals_820, getitem_83, getitem_84, True, 0.001, [True, True, True]);  to_dtype_368 = convolution_default_26 = primals_821 = primals_819 = primals_820 = getitem_83 = getitem_84 = None
        getitem_1187 = native_batch_norm_backward_default_122[0]
        getitem_1188 = native_batch_norm_backward_default_122[1]
        getitem_1189 = native_batch_norm_backward_default_122[2];  native_batch_norm_backward_default_122 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(getitem_1187, cat_default_4, primals_822, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1187 = primals_822 = None
        getitem_1190 = convolution_backward_default_122[0]
        getitem_1191 = convolution_backward_default_122[1]
        getitem_1192 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(add_tensor_43, getitem_1190);  add_tensor_43 = getitem_1190 = None
        to_dtype_369 = torch.ops.aten.to.dtype(slice_tensor_62, torch.float32);  slice_tensor_62 = None
        to_dtype_370 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_123 = torch.ops.aten.le.Scalar(to_dtype_370, 0);  to_dtype_370 = None
        new_zeros_default_272 = torch.ops.aten.new_zeros.default(to_dtype_369, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_123 = torch.ops.aten.where.self(le_scalar_123, new_zeros_default_272, to_dtype_369);  le_scalar_123 = new_zeros_default_272 = to_dtype_369 = None
        to_dtype_371 = torch.ops.aten.to.dtype(where_self_123, torch.float32);  where_self_123 = None
        native_batch_norm_backward_default_123 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_371, convolution_default_25, primals_815, primals_813, primals_814, getitem_80, getitem_81, True, 0.001, [True, True, True]);  to_dtype_371 = convolution_default_25 = primals_815 = primals_813 = primals_814 = getitem_80 = getitem_81 = None
        getitem_1193 = native_batch_norm_backward_default_123[0]
        getitem_1194 = native_batch_norm_backward_default_123[1]
        getitem_1195 = native_batch_norm_backward_default_123[2];  native_batch_norm_backward_default_123 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(getitem_1193, cat_default_4, primals_816, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1193 = cat_default_4 = primals_816 = None
        getitem_1196 = convolution_backward_default_123[0]
        getitem_1197 = convolution_backward_default_123[1]
        getitem_1198 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_44, getitem_1196);  add_tensor_44 = getitem_1196 = None
        slice_tensor_66 = torch.ops.aten.slice.Tensor(add_tensor_45, 1, 0, 96)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(add_tensor_45, 1, 96, 192)
        slice_tensor_68 = torch.ops.aten.slice.Tensor(add_tensor_45, 1, 192, 288)
        slice_tensor_69 = torch.ops.aten.slice.Tensor(add_tensor_45, 1, 288, 384);  add_tensor_45 = None
        to_dtype_372 = torch.ops.aten.to.dtype(slice_tensor_69, torch.float32);  slice_tensor_69 = None
        to_dtype_373 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_124 = torch.ops.aten.le.Scalar(to_dtype_373, 0);  to_dtype_373 = None
        new_zeros_default_273 = torch.ops.aten.new_zeros.default(to_dtype_372, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_124 = torch.ops.aten.where.self(le_scalar_124, new_zeros_default_273, to_dtype_372);  le_scalar_124 = new_zeros_default_273 = to_dtype_372 = None
        to_dtype_374 = torch.ops.aten.to.dtype(where_self_124, torch.float32);  where_self_124 = None
        native_batch_norm_backward_default_124 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_374, convolution_default_24, primals_809, primals_807, primals_808, getitem_77, getitem_78, True, 0.001, [True, True, True]);  to_dtype_374 = convolution_default_24 = primals_809 = primals_807 = primals_808 = getitem_77 = getitem_78 = None
        getitem_1199 = native_batch_norm_backward_default_124[0]
        getitem_1200 = native_batch_norm_backward_default_124[1]
        getitem_1201 = native_batch_norm_backward_default_124[2];  native_batch_norm_backward_default_124 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(getitem_1199, avg_pool2d_default_1, primals_810, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1199 = avg_pool2d_default_1 = primals_810 = None
        getitem_1202 = convolution_backward_default_124[0]
        getitem_1203 = convolution_backward_default_124[1]
        getitem_1204 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        avg_pool2d_backward_default_12 = torch.ops.aten.avg_pool2d_backward.default(getitem_1202, cat_default_3, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_1202 = None
        to_dtype_375 = torch.ops.aten.to.dtype(slice_tensor_68, torch.float32);  slice_tensor_68 = None
        to_dtype_376 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_125 = torch.ops.aten.le.Scalar(to_dtype_376, 0);  to_dtype_376 = None
        new_zeros_default_274 = torch.ops.aten.new_zeros.default(to_dtype_375, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_125 = torch.ops.aten.where.self(le_scalar_125, new_zeros_default_274, to_dtype_375);  le_scalar_125 = new_zeros_default_274 = to_dtype_375 = None
        to_dtype_377 = torch.ops.aten.to.dtype(where_self_125, torch.float32);  where_self_125 = None
        native_batch_norm_backward_default_125 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_377, convolution_default_23, primals_803, primals_801, primals_802, getitem_74, getitem_75, True, 0.001, [True, True, True]);  to_dtype_377 = convolution_default_23 = primals_803 = primals_801 = primals_802 = getitem_74 = getitem_75 = None
        getitem_1205 = native_batch_norm_backward_default_125[0]
        getitem_1206 = native_batch_norm_backward_default_125[1]
        getitem_1207 = native_batch_norm_backward_default_125[2];  native_batch_norm_backward_default_125 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(getitem_1205, relu__default_22, primals_804, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1205 = primals_804 = None
        getitem_1208 = convolution_backward_default_125[0]
        getitem_1209 = convolution_backward_default_125[1]
        getitem_1210 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        to_dtype_378 = torch.ops.aten.to.dtype(getitem_1208, torch.float32);  getitem_1208 = None
        to_dtype_379 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_126 = torch.ops.aten.le.Scalar(to_dtype_379, 0);  to_dtype_379 = None
        new_zeros_default_275 = torch.ops.aten.new_zeros.default(to_dtype_378, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_126 = torch.ops.aten.where.self(le_scalar_126, new_zeros_default_275, to_dtype_378);  le_scalar_126 = new_zeros_default_275 = to_dtype_378 = None
        to_dtype_380 = torch.ops.aten.to.dtype(where_self_126, torch.float32);  where_self_126 = None
        native_batch_norm_backward_default_126 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_380, convolution_default_22, primals_797, primals_795, primals_796, getitem_71, getitem_72, True, 0.001, [True, True, True]);  to_dtype_380 = convolution_default_22 = primals_797 = primals_795 = primals_796 = getitem_71 = getitem_72 = None
        getitem_1211 = native_batch_norm_backward_default_126[0]
        getitem_1212 = native_batch_norm_backward_default_126[1]
        getitem_1213 = native_batch_norm_backward_default_126[2];  native_batch_norm_backward_default_126 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(getitem_1211, relu__default_21, primals_798, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1211 = primals_798 = None
        getitem_1214 = convolution_backward_default_126[0]
        getitem_1215 = convolution_backward_default_126[1]
        getitem_1216 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        to_dtype_381 = torch.ops.aten.to.dtype(getitem_1214, torch.float32);  getitem_1214 = None
        to_dtype_382 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_127 = torch.ops.aten.le.Scalar(to_dtype_382, 0);  to_dtype_382 = None
        new_zeros_default_276 = torch.ops.aten.new_zeros.default(to_dtype_381, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_127 = torch.ops.aten.where.self(le_scalar_127, new_zeros_default_276, to_dtype_381);  le_scalar_127 = new_zeros_default_276 = to_dtype_381 = None
        to_dtype_383 = torch.ops.aten.to.dtype(where_self_127, torch.float32);  where_self_127 = None
        native_batch_norm_backward_default_127 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_383, convolution_default_21, primals_791, primals_789, primals_790, getitem_68, getitem_69, True, 0.001, [True, True, True]);  to_dtype_383 = convolution_default_21 = primals_791 = primals_789 = primals_790 = getitem_68 = getitem_69 = None
        getitem_1217 = native_batch_norm_backward_default_127[0]
        getitem_1218 = native_batch_norm_backward_default_127[1]
        getitem_1219 = native_batch_norm_backward_default_127[2];  native_batch_norm_backward_default_127 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(getitem_1217, cat_default_3, primals_792, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1217 = primals_792 = None
        getitem_1220 = convolution_backward_default_127[0]
        getitem_1221 = convolution_backward_default_127[1]
        getitem_1222 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_12, getitem_1220);  avg_pool2d_backward_default_12 = getitem_1220 = None
        to_dtype_384 = torch.ops.aten.to.dtype(slice_tensor_67, torch.float32);  slice_tensor_67 = None
        to_dtype_385 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_128 = torch.ops.aten.le.Scalar(to_dtype_385, 0);  to_dtype_385 = None
        new_zeros_default_277 = torch.ops.aten.new_zeros.default(to_dtype_384, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_128 = torch.ops.aten.where.self(le_scalar_128, new_zeros_default_277, to_dtype_384);  le_scalar_128 = new_zeros_default_277 = to_dtype_384 = None
        to_dtype_386 = torch.ops.aten.to.dtype(where_self_128, torch.float32);  where_self_128 = None
        native_batch_norm_backward_default_128 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_386, convolution_default_20, primals_785, primals_783, primals_784, getitem_65, getitem_66, True, 0.001, [True, True, True]);  to_dtype_386 = convolution_default_20 = primals_785 = primals_783 = primals_784 = getitem_65 = getitem_66 = None
        getitem_1223 = native_batch_norm_backward_default_128[0]
        getitem_1224 = native_batch_norm_backward_default_128[1]
        getitem_1225 = native_batch_norm_backward_default_128[2];  native_batch_norm_backward_default_128 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(getitem_1223, relu__default_19, primals_786, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1223 = primals_786 = None
        getitem_1226 = convolution_backward_default_128[0]
        getitem_1227 = convolution_backward_default_128[1]
        getitem_1228 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        to_dtype_387 = torch.ops.aten.to.dtype(getitem_1226, torch.float32);  getitem_1226 = None
        to_dtype_388 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_129 = torch.ops.aten.le.Scalar(to_dtype_388, 0);  to_dtype_388 = None
        new_zeros_default_278 = torch.ops.aten.new_zeros.default(to_dtype_387, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_129 = torch.ops.aten.where.self(le_scalar_129, new_zeros_default_278, to_dtype_387);  le_scalar_129 = new_zeros_default_278 = to_dtype_387 = None
        to_dtype_389 = torch.ops.aten.to.dtype(where_self_129, torch.float32);  where_self_129 = None
        native_batch_norm_backward_default_129 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_389, convolution_default_19, primals_779, primals_777, primals_778, getitem_62, getitem_63, True, 0.001, [True, True, True]);  to_dtype_389 = convolution_default_19 = primals_779 = primals_777 = primals_778 = getitem_62 = getitem_63 = None
        getitem_1229 = native_batch_norm_backward_default_129[0]
        getitem_1230 = native_batch_norm_backward_default_129[1]
        getitem_1231 = native_batch_norm_backward_default_129[2];  native_batch_norm_backward_default_129 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(getitem_1229, cat_default_3, primals_780, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1229 = primals_780 = None
        getitem_1232 = convolution_backward_default_129[0]
        getitem_1233 = convolution_backward_default_129[1]
        getitem_1234 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(add_tensor_46, getitem_1232);  add_tensor_46 = getitem_1232 = None
        to_dtype_390 = torch.ops.aten.to.dtype(slice_tensor_66, torch.float32);  slice_tensor_66 = None
        to_dtype_391 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_130 = torch.ops.aten.le.Scalar(to_dtype_391, 0);  to_dtype_391 = None
        new_zeros_default_279 = torch.ops.aten.new_zeros.default(to_dtype_390, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_130 = torch.ops.aten.where.self(le_scalar_130, new_zeros_default_279, to_dtype_390);  le_scalar_130 = new_zeros_default_279 = to_dtype_390 = None
        to_dtype_392 = torch.ops.aten.to.dtype(where_self_130, torch.float32);  where_self_130 = None
        native_batch_norm_backward_default_130 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_392, convolution_default_18, primals_773, primals_771, primals_772, getitem_59, getitem_60, True, 0.001, [True, True, True]);  to_dtype_392 = convolution_default_18 = primals_773 = primals_771 = primals_772 = getitem_59 = getitem_60 = None
        getitem_1235 = native_batch_norm_backward_default_130[0]
        getitem_1236 = native_batch_norm_backward_default_130[1]
        getitem_1237 = native_batch_norm_backward_default_130[2];  native_batch_norm_backward_default_130 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(getitem_1235, cat_default_3, primals_774, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1235 = cat_default_3 = primals_774 = None
        getitem_1238 = convolution_backward_default_130[0]
        getitem_1239 = convolution_backward_default_130[1]
        getitem_1240 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_47, getitem_1238);  add_tensor_47 = getitem_1238 = None
        slice_tensor_70 = torch.ops.aten.slice.Tensor(add_tensor_48, 1, 0, 96)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(add_tensor_48, 1, 96, 192)
        slice_tensor_72 = torch.ops.aten.slice.Tensor(add_tensor_48, 1, 192, 288)
        slice_tensor_73 = torch.ops.aten.slice.Tensor(add_tensor_48, 1, 288, 384);  add_tensor_48 = None
        to_dtype_393 = torch.ops.aten.to.dtype(slice_tensor_73, torch.float32);  slice_tensor_73 = None
        to_dtype_394 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_131 = torch.ops.aten.le.Scalar(to_dtype_394, 0);  to_dtype_394 = None
        new_zeros_default_280 = torch.ops.aten.new_zeros.default(to_dtype_393, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_131 = torch.ops.aten.where.self(le_scalar_131, new_zeros_default_280, to_dtype_393);  le_scalar_131 = new_zeros_default_280 = to_dtype_393 = None
        to_dtype_395 = torch.ops.aten.to.dtype(where_self_131, torch.float32);  where_self_131 = None
        native_batch_norm_backward_default_131 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_395, convolution_default_17, primals_767, primals_765, primals_766, getitem_56, getitem_57, True, 0.001, [True, True, True]);  to_dtype_395 = convolution_default_17 = primals_767 = primals_765 = primals_766 = getitem_56 = getitem_57 = None
        getitem_1241 = native_batch_norm_backward_default_131[0]
        getitem_1242 = native_batch_norm_backward_default_131[1]
        getitem_1243 = native_batch_norm_backward_default_131[2];  native_batch_norm_backward_default_131 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(getitem_1241, avg_pool2d_default, primals_768, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1241 = avg_pool2d_default = primals_768 = None
        getitem_1244 = convolution_backward_default_131[0]
        getitem_1245 = convolution_backward_default_131[1]
        getitem_1246 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        avg_pool2d_backward_default_13 = torch.ops.aten.avg_pool2d_backward.default(getitem_1244, cat_default_2, [3, 3], [1, 1], [1, 1], False, False, None);  getitem_1244 = None
        to_dtype_396 = torch.ops.aten.to.dtype(slice_tensor_72, torch.float32);  slice_tensor_72 = None
        to_dtype_397 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_132 = torch.ops.aten.le.Scalar(to_dtype_397, 0);  to_dtype_397 = None
        new_zeros_default_281 = torch.ops.aten.new_zeros.default(to_dtype_396, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_132 = torch.ops.aten.where.self(le_scalar_132, new_zeros_default_281, to_dtype_396);  le_scalar_132 = new_zeros_default_281 = to_dtype_396 = None
        to_dtype_398 = torch.ops.aten.to.dtype(where_self_132, torch.float32);  where_self_132 = None
        native_batch_norm_backward_default_132 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_398, convolution_default_16, primals_761, primals_759, primals_760, getitem_53, getitem_54, True, 0.001, [True, True, True]);  to_dtype_398 = convolution_default_16 = primals_761 = primals_759 = primals_760 = getitem_53 = getitem_54 = None
        getitem_1247 = native_batch_norm_backward_default_132[0]
        getitem_1248 = native_batch_norm_backward_default_132[1]
        getitem_1249 = native_batch_norm_backward_default_132[2];  native_batch_norm_backward_default_132 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(getitem_1247, relu__default_15, primals_762, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1247 = primals_762 = None
        getitem_1250 = convolution_backward_default_132[0]
        getitem_1251 = convolution_backward_default_132[1]
        getitem_1252 = convolution_backward_default_132[2];  convolution_backward_default_132 = None
        to_dtype_399 = torch.ops.aten.to.dtype(getitem_1250, torch.float32);  getitem_1250 = None
        to_dtype_400 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_133 = torch.ops.aten.le.Scalar(to_dtype_400, 0);  to_dtype_400 = None
        new_zeros_default_282 = torch.ops.aten.new_zeros.default(to_dtype_399, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_133 = torch.ops.aten.where.self(le_scalar_133, new_zeros_default_282, to_dtype_399);  le_scalar_133 = new_zeros_default_282 = to_dtype_399 = None
        to_dtype_401 = torch.ops.aten.to.dtype(where_self_133, torch.float32);  where_self_133 = None
        native_batch_norm_backward_default_133 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_401, convolution_default_15, primals_755, primals_753, primals_754, getitem_50, getitem_51, True, 0.001, [True, True, True]);  to_dtype_401 = convolution_default_15 = primals_755 = primals_753 = primals_754 = getitem_50 = getitem_51 = None
        getitem_1253 = native_batch_norm_backward_default_133[0]
        getitem_1254 = native_batch_norm_backward_default_133[1]
        getitem_1255 = native_batch_norm_backward_default_133[2];  native_batch_norm_backward_default_133 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(getitem_1253, relu__default_14, primals_756, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1253 = primals_756 = None
        getitem_1256 = convolution_backward_default_133[0]
        getitem_1257 = convolution_backward_default_133[1]
        getitem_1258 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        to_dtype_402 = torch.ops.aten.to.dtype(getitem_1256, torch.float32);  getitem_1256 = None
        to_dtype_403 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_134 = torch.ops.aten.le.Scalar(to_dtype_403, 0);  to_dtype_403 = None
        new_zeros_default_283 = torch.ops.aten.new_zeros.default(to_dtype_402, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_134 = torch.ops.aten.where.self(le_scalar_134, new_zeros_default_283, to_dtype_402);  le_scalar_134 = new_zeros_default_283 = to_dtype_402 = None
        to_dtype_404 = torch.ops.aten.to.dtype(where_self_134, torch.float32);  where_self_134 = None
        native_batch_norm_backward_default_134 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_404, convolution_default_14, primals_749, primals_747, primals_748, getitem_47, getitem_48, True, 0.001, [True, True, True]);  to_dtype_404 = convolution_default_14 = primals_749 = primals_747 = primals_748 = getitem_47 = getitem_48 = None
        getitem_1259 = native_batch_norm_backward_default_134[0]
        getitem_1260 = native_batch_norm_backward_default_134[1]
        getitem_1261 = native_batch_norm_backward_default_134[2];  native_batch_norm_backward_default_134 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(getitem_1259, cat_default_2, primals_750, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1259 = primals_750 = None
        getitem_1262 = convolution_backward_default_134[0]
        getitem_1263 = convolution_backward_default_134[1]
        getitem_1264 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(avg_pool2d_backward_default_13, getitem_1262);  avg_pool2d_backward_default_13 = getitem_1262 = None
        to_dtype_405 = torch.ops.aten.to.dtype(slice_tensor_71, torch.float32);  slice_tensor_71 = None
        to_dtype_406 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_135 = torch.ops.aten.le.Scalar(to_dtype_406, 0);  to_dtype_406 = None
        new_zeros_default_284 = torch.ops.aten.new_zeros.default(to_dtype_405, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_135 = torch.ops.aten.where.self(le_scalar_135, new_zeros_default_284, to_dtype_405);  le_scalar_135 = new_zeros_default_284 = to_dtype_405 = None
        to_dtype_407 = torch.ops.aten.to.dtype(where_self_135, torch.float32);  where_self_135 = None
        native_batch_norm_backward_default_135 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_407, convolution_default_13, primals_743, primals_741, primals_742, getitem_44, getitem_45, True, 0.001, [True, True, True]);  to_dtype_407 = convolution_default_13 = primals_743 = primals_741 = primals_742 = getitem_44 = getitem_45 = None
        getitem_1265 = native_batch_norm_backward_default_135[0]
        getitem_1266 = native_batch_norm_backward_default_135[1]
        getitem_1267 = native_batch_norm_backward_default_135[2];  native_batch_norm_backward_default_135 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(getitem_1265, relu__default_12, primals_744, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1265 = primals_744 = None
        getitem_1268 = convolution_backward_default_135[0]
        getitem_1269 = convolution_backward_default_135[1]
        getitem_1270 = convolution_backward_default_135[2];  convolution_backward_default_135 = None
        to_dtype_408 = torch.ops.aten.to.dtype(getitem_1268, torch.float32);  getitem_1268 = None
        to_dtype_409 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_136 = torch.ops.aten.le.Scalar(to_dtype_409, 0);  to_dtype_409 = None
        new_zeros_default_285 = torch.ops.aten.new_zeros.default(to_dtype_408, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_136 = torch.ops.aten.where.self(le_scalar_136, new_zeros_default_285, to_dtype_408);  le_scalar_136 = new_zeros_default_285 = to_dtype_408 = None
        to_dtype_410 = torch.ops.aten.to.dtype(where_self_136, torch.float32);  where_self_136 = None
        native_batch_norm_backward_default_136 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_410, convolution_default_12, primals_737, primals_735, primals_736, getitem_41, getitem_42, True, 0.001, [True, True, True]);  to_dtype_410 = convolution_default_12 = primals_737 = primals_735 = primals_736 = getitem_41 = getitem_42 = None
        getitem_1271 = native_batch_norm_backward_default_136[0]
        getitem_1272 = native_batch_norm_backward_default_136[1]
        getitem_1273 = native_batch_norm_backward_default_136[2];  native_batch_norm_backward_default_136 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(getitem_1271, cat_default_2, primals_738, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1271 = primals_738 = None
        getitem_1274 = convolution_backward_default_136[0]
        getitem_1275 = convolution_backward_default_136[1]
        getitem_1276 = convolution_backward_default_136[2];  convolution_backward_default_136 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(add_tensor_49, getitem_1274);  add_tensor_49 = getitem_1274 = None
        to_dtype_411 = torch.ops.aten.to.dtype(slice_tensor_70, torch.float32);  slice_tensor_70 = None
        to_dtype_412 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_137 = torch.ops.aten.le.Scalar(to_dtype_412, 0);  to_dtype_412 = None
        new_zeros_default_286 = torch.ops.aten.new_zeros.default(to_dtype_411, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_137 = torch.ops.aten.where.self(le_scalar_137, new_zeros_default_286, to_dtype_411);  le_scalar_137 = new_zeros_default_286 = to_dtype_411 = None
        to_dtype_413 = torch.ops.aten.to.dtype(where_self_137, torch.float32);  where_self_137 = None
        native_batch_norm_backward_default_137 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_413, convolution_default_11, primals_731, primals_729, primals_730, getitem_38, getitem_39, True, 0.001, [True, True, True]);  to_dtype_413 = convolution_default_11 = primals_731 = primals_729 = primals_730 = getitem_38 = getitem_39 = None
        getitem_1277 = native_batch_norm_backward_default_137[0]
        getitem_1278 = native_batch_norm_backward_default_137[1]
        getitem_1279 = native_batch_norm_backward_default_137[2];  native_batch_norm_backward_default_137 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(getitem_1277, cat_default_2, primals_732, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1277 = cat_default_2 = primals_732 = None
        getitem_1280 = convolution_backward_default_137[0]
        getitem_1281 = convolution_backward_default_137[1]
        getitem_1282 = convolution_backward_default_137[2];  convolution_backward_default_137 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(add_tensor_50, getitem_1280);  add_tensor_50 = getitem_1280 = None
        slice_tensor_74 = torch.ops.aten.slice.Tensor(add_tensor_51, 1, 0, 192)
        slice_tensor_75 = torch.ops.aten.slice.Tensor(add_tensor_51, 1, 192, 384);  add_tensor_51 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_75, cat_default_1, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_36);  slice_tensor_75 = getitem_36 = None
        to_dtype_414 = torch.ops.aten.to.dtype(slice_tensor_74, torch.float32);  slice_tensor_74 = None
        to_dtype_415 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_138 = torch.ops.aten.le.Scalar(to_dtype_415, 0);  to_dtype_415 = None
        new_zeros_default_287 = torch.ops.aten.new_zeros.default(to_dtype_414, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_138 = torch.ops.aten.where.self(le_scalar_138, new_zeros_default_287, to_dtype_414);  le_scalar_138 = new_zeros_default_287 = to_dtype_414 = None
        to_dtype_416 = torch.ops.aten.to.dtype(where_self_138, torch.float32);  where_self_138 = None
        native_batch_norm_backward_default_138 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_416, convolution_default_10, primals_725, primals_723, primals_724, getitem_33, getitem_34, True, 0.001, [True, True, True]);  to_dtype_416 = convolution_default_10 = primals_725 = primals_723 = primals_724 = getitem_33 = getitem_34 = None
        getitem_1283 = native_batch_norm_backward_default_138[0]
        getitem_1284 = native_batch_norm_backward_default_138[1]
        getitem_1285 = native_batch_norm_backward_default_138[2];  native_batch_norm_backward_default_138 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(getitem_1283, cat_default_1, primals_726, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1283 = cat_default_1 = primals_726 = None
        getitem_1286 = convolution_backward_default_138[0]
        getitem_1287 = convolution_backward_default_138[1]
        getitem_1288 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(max_pool2d_with_indices_backward_default_2, getitem_1286);  max_pool2d_with_indices_backward_default_2 = getitem_1286 = None
        slice_tensor_76 = torch.ops.aten.slice.Tensor(add_tensor_52, 1, 0, 96)
        slice_tensor_77 = torch.ops.aten.slice.Tensor(add_tensor_52, 1, 96, 192);  add_tensor_52 = None
        to_dtype_417 = torch.ops.aten.to.dtype(slice_tensor_77, torch.float32);  slice_tensor_77 = None
        to_dtype_418 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_139 = torch.ops.aten.le.Scalar(to_dtype_418, 0);  to_dtype_418 = None
        new_zeros_default_288 = torch.ops.aten.new_zeros.default(to_dtype_417, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_139 = torch.ops.aten.where.self(le_scalar_139, new_zeros_default_288, to_dtype_417);  le_scalar_139 = new_zeros_default_288 = to_dtype_417 = None
        to_dtype_419 = torch.ops.aten.to.dtype(where_self_139, torch.float32);  where_self_139 = None
        native_batch_norm_backward_default_139 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_419, convolution_default_9, primals_719, primals_717, primals_718, getitem_30, getitem_31, True, 0.001, [True, True, True]);  to_dtype_419 = convolution_default_9 = primals_719 = primals_717 = primals_718 = getitem_30 = getitem_31 = None
        getitem_1289 = native_batch_norm_backward_default_139[0]
        getitem_1290 = native_batch_norm_backward_default_139[1]
        getitem_1291 = native_batch_norm_backward_default_139[2];  native_batch_norm_backward_default_139 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_1289, relu__default_8, primals_720, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1289 = primals_720 = None
        getitem_1292 = convolution_backward_default_139[0]
        getitem_1293 = convolution_backward_default_139[1]
        getitem_1294 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        to_dtype_420 = torch.ops.aten.to.dtype(getitem_1292, torch.float32);  getitem_1292 = None
        to_dtype_421 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_140 = torch.ops.aten.le.Scalar(to_dtype_421, 0);  to_dtype_421 = None
        new_zeros_default_289 = torch.ops.aten.new_zeros.default(to_dtype_420, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_140 = torch.ops.aten.where.self(le_scalar_140, new_zeros_default_289, to_dtype_420);  le_scalar_140 = new_zeros_default_289 = to_dtype_420 = None
        to_dtype_422 = torch.ops.aten.to.dtype(where_self_140, torch.float32);  where_self_140 = None
        native_batch_norm_backward_default_140 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_422, convolution_default_8, primals_713, primals_711, primals_712, getitem_27, getitem_28, True, 0.001, [True, True, True]);  to_dtype_422 = convolution_default_8 = primals_713 = primals_711 = primals_712 = getitem_27 = getitem_28 = None
        getitem_1295 = native_batch_norm_backward_default_140[0]
        getitem_1296 = native_batch_norm_backward_default_140[1]
        getitem_1297 = native_batch_norm_backward_default_140[2];  native_batch_norm_backward_default_140 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(getitem_1295, relu__default_7, primals_714, [0], [1, 1], [3, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1295 = primals_714 = None
        getitem_1298 = convolution_backward_default_140[0]
        getitem_1299 = convolution_backward_default_140[1]
        getitem_1300 = convolution_backward_default_140[2];  convolution_backward_default_140 = None
        to_dtype_423 = torch.ops.aten.to.dtype(getitem_1298, torch.float32);  getitem_1298 = None
        to_dtype_424 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_141 = torch.ops.aten.le.Scalar(to_dtype_424, 0);  to_dtype_424 = None
        new_zeros_default_290 = torch.ops.aten.new_zeros.default(to_dtype_423, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_141 = torch.ops.aten.where.self(le_scalar_141, new_zeros_default_290, to_dtype_423);  le_scalar_141 = new_zeros_default_290 = to_dtype_423 = None
        to_dtype_425 = torch.ops.aten.to.dtype(where_self_141, torch.float32);  where_self_141 = None
        native_batch_norm_backward_default_141 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_425, convolution_default_7, primals_707, primals_705, primals_706, getitem_24, getitem_25, True, 0.001, [True, True, True]);  to_dtype_425 = convolution_default_7 = primals_707 = primals_705 = primals_706 = getitem_24 = getitem_25 = None
        getitem_1301 = native_batch_norm_backward_default_141[0]
        getitem_1302 = native_batch_norm_backward_default_141[1]
        getitem_1303 = native_batch_norm_backward_default_141[2];  native_batch_norm_backward_default_141 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(getitem_1301, relu__default_6, primals_708, [0], [1, 1], [0, 3], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1301 = primals_708 = None
        getitem_1304 = convolution_backward_default_141[0]
        getitem_1305 = convolution_backward_default_141[1]
        getitem_1306 = convolution_backward_default_141[2];  convolution_backward_default_141 = None
        to_dtype_426 = torch.ops.aten.to.dtype(getitem_1304, torch.float32);  getitem_1304 = None
        to_dtype_427 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_142 = torch.ops.aten.le.Scalar(to_dtype_427, 0);  to_dtype_427 = None
        new_zeros_default_291 = torch.ops.aten.new_zeros.default(to_dtype_426, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_142 = torch.ops.aten.where.self(le_scalar_142, new_zeros_default_291, to_dtype_426);  le_scalar_142 = new_zeros_default_291 = to_dtype_426 = None
        to_dtype_428 = torch.ops.aten.to.dtype(where_self_142, torch.float32);  where_self_142 = None
        native_batch_norm_backward_default_142 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_428, convolution_default_6, primals_701, primals_699, primals_700, getitem_21, getitem_22, True, 0.001, [True, True, True]);  to_dtype_428 = convolution_default_6 = primals_701 = primals_699 = primals_700 = getitem_21 = getitem_22 = None
        getitem_1307 = native_batch_norm_backward_default_142[0]
        getitem_1308 = native_batch_norm_backward_default_142[1]
        getitem_1309 = native_batch_norm_backward_default_142[2];  native_batch_norm_backward_default_142 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_1307, cat_default, primals_702, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1307 = primals_702 = None
        getitem_1310 = convolution_backward_default_142[0]
        getitem_1311 = convolution_backward_default_142[1]
        getitem_1312 = convolution_backward_default_142[2];  convolution_backward_default_142 = None
        to_dtype_429 = torch.ops.aten.to.dtype(slice_tensor_76, torch.float32);  slice_tensor_76 = None
        to_dtype_430 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_143 = torch.ops.aten.le.Scalar(to_dtype_430, 0);  to_dtype_430 = None
        new_zeros_default_292 = torch.ops.aten.new_zeros.default(to_dtype_429, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_143 = torch.ops.aten.where.self(le_scalar_143, new_zeros_default_292, to_dtype_429);  le_scalar_143 = new_zeros_default_292 = to_dtype_429 = None
        to_dtype_431 = torch.ops.aten.to.dtype(where_self_143, torch.float32);  where_self_143 = None
        native_batch_norm_backward_default_143 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_431, convolution_default_5, primals_695, primals_693, primals_694, getitem_18, getitem_19, True, 0.001, [True, True, True]);  to_dtype_431 = convolution_default_5 = primals_695 = primals_693 = primals_694 = getitem_18 = getitem_19 = None
        getitem_1313 = native_batch_norm_backward_default_143[0]
        getitem_1314 = native_batch_norm_backward_default_143[1]
        getitem_1315 = native_batch_norm_backward_default_143[2];  native_batch_norm_backward_default_143 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(getitem_1313, relu__default_4, primals_696, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1313 = primals_696 = None
        getitem_1316 = convolution_backward_default_143[0]
        getitem_1317 = convolution_backward_default_143[1]
        getitem_1318 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        to_dtype_432 = torch.ops.aten.to.dtype(getitem_1316, torch.float32);  getitem_1316 = None
        to_dtype_433 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_144 = torch.ops.aten.le.Scalar(to_dtype_433, 0);  to_dtype_433 = None
        new_zeros_default_293 = torch.ops.aten.new_zeros.default(to_dtype_432, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_144 = torch.ops.aten.where.self(le_scalar_144, new_zeros_default_293, to_dtype_432);  le_scalar_144 = new_zeros_default_293 = to_dtype_432 = None
        to_dtype_434 = torch.ops.aten.to.dtype(where_self_144, torch.float32);  where_self_144 = None
        native_batch_norm_backward_default_144 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_434, convolution_default_4, primals_689, primals_687, primals_688, getitem_15, getitem_16, True, 0.001, [True, True, True]);  to_dtype_434 = convolution_default_4 = primals_689 = primals_687 = primals_688 = getitem_15 = getitem_16 = None
        getitem_1319 = native_batch_norm_backward_default_144[0]
        getitem_1320 = native_batch_norm_backward_default_144[1]
        getitem_1321 = native_batch_norm_backward_default_144[2];  native_batch_norm_backward_default_144 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(getitem_1319, cat_default, primals_690, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1319 = cat_default = primals_690 = None
        getitem_1322 = convolution_backward_default_144[0]
        getitem_1323 = convolution_backward_default_144[1]
        getitem_1324 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_1310, getitem_1322);  getitem_1310 = getitem_1322 = None
        slice_tensor_78 = torch.ops.aten.slice.Tensor(add_tensor_53, 1, 0, 64)
        slice_tensor_79 = torch.ops.aten.slice.Tensor(add_tensor_53, 1, 64, 160);  add_tensor_53 = None
        to_dtype_435 = torch.ops.aten.to.dtype(slice_tensor_79, torch.float32);  slice_tensor_79 = None
        to_dtype_436 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_145 = torch.ops.aten.le.Scalar(to_dtype_436, 0);  to_dtype_436 = None
        new_zeros_default_294 = torch.ops.aten.new_zeros.default(to_dtype_435, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_145 = torch.ops.aten.where.self(le_scalar_145, new_zeros_default_294, to_dtype_435);  le_scalar_145 = new_zeros_default_294 = to_dtype_435 = None
        to_dtype_437 = torch.ops.aten.to.dtype(where_self_145, torch.float32);  where_self_145 = None
        native_batch_norm_backward_default_145 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_437, convolution_default_3, primals_683, primals_681, primals_682, getitem_12, getitem_13, True, 0.001, [True, True, True]);  to_dtype_437 = convolution_default_3 = primals_683 = primals_681 = primals_682 = getitem_12 = getitem_13 = None
        getitem_1325 = native_batch_norm_backward_default_145[0]
        getitem_1326 = native_batch_norm_backward_default_145[1]
        getitem_1327 = native_batch_norm_backward_default_145[2];  native_batch_norm_backward_default_145 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(getitem_1325, relu__default_2, primals_684, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1325 = primals_684 = None
        getitem_1328 = convolution_backward_default_145[0]
        getitem_1329 = convolution_backward_default_145[1]
        getitem_1330 = convolution_backward_default_145[2];  convolution_backward_default_145 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_78, relu__default_2, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_10);  slice_tensor_78 = getitem_10 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(getitem_1328, max_pool2d_with_indices_backward_default_3);  getitem_1328 = max_pool2d_with_indices_backward_default_3 = None
        to_dtype_438 = torch.ops.aten.to.dtype(add_tensor_54, torch.float32);  add_tensor_54 = None
        to_dtype_439 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_146 = torch.ops.aten.le.Scalar(to_dtype_439, 0);  to_dtype_439 = None
        new_zeros_default_295 = torch.ops.aten.new_zeros.default(to_dtype_438, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_146 = torch.ops.aten.where.self(le_scalar_146, new_zeros_default_295, to_dtype_438);  le_scalar_146 = new_zeros_default_295 = to_dtype_438 = None
        to_dtype_440 = torch.ops.aten.to.dtype(where_self_146, torch.float32);  where_self_146 = None
        native_batch_norm_backward_default_146 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_440, convolution_default_2, primals_677, primals_675, primals_676, getitem_7, getitem_8, True, 0.001, [True, True, True]);  to_dtype_440 = convolution_default_2 = primals_677 = primals_675 = primals_676 = getitem_7 = getitem_8 = None
        getitem_1331 = native_batch_norm_backward_default_146[0]
        getitem_1332 = native_batch_norm_backward_default_146[1]
        getitem_1333 = native_batch_norm_backward_default_146[2];  native_batch_norm_backward_default_146 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(getitem_1331, relu__default_1, primals_678, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1331 = primals_678 = None
        getitem_1334 = convolution_backward_default_146[0]
        getitem_1335 = convolution_backward_default_146[1]
        getitem_1336 = convolution_backward_default_146[2];  convolution_backward_default_146 = None
        to_dtype_441 = torch.ops.aten.to.dtype(getitem_1334, torch.float32);  getitem_1334 = None
        to_dtype_442 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_147 = torch.ops.aten.le.Scalar(to_dtype_442, 0);  to_dtype_442 = None
        new_zeros_default_296 = torch.ops.aten.new_zeros.default(to_dtype_441, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_147 = torch.ops.aten.where.self(le_scalar_147, new_zeros_default_296, to_dtype_441);  le_scalar_147 = new_zeros_default_296 = to_dtype_441 = None
        to_dtype_443 = torch.ops.aten.to.dtype(where_self_147, torch.float32);  where_self_147 = None
        native_batch_norm_backward_default_147 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_443, convolution_default_1, primals_551, primals_549, primals_550, getitem_4, getitem_5, True, 0.001, [True, True, True]);  to_dtype_443 = convolution_default_1 = primals_551 = primals_549 = primals_550 = getitem_4 = getitem_5 = None
        getitem_1337 = native_batch_norm_backward_default_147[0]
        getitem_1338 = native_batch_norm_backward_default_147[1]
        getitem_1339 = native_batch_norm_backward_default_147[2];  native_batch_norm_backward_default_147 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(getitem_1337, relu__default, primals_552, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1337 = primals_552 = None
        getitem_1340 = convolution_backward_default_147[0]
        getitem_1341 = convolution_backward_default_147[1]
        getitem_1342 = convolution_backward_default_147[2];  convolution_backward_default_147 = None
        to_dtype_444 = torch.ops.aten.to.dtype(getitem_1340, torch.float32);  getitem_1340 = None
        to_dtype_445 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_148 = torch.ops.aten.le.Scalar(to_dtype_445, 0);  to_dtype_445 = None
        new_zeros_default_297 = torch.ops.aten.new_zeros.default(to_dtype_444, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_148 = torch.ops.aten.where.self(le_scalar_148, new_zeros_default_297, to_dtype_444);  le_scalar_148 = new_zeros_default_297 = to_dtype_444 = None
        to_dtype_446 = torch.ops.aten.to.dtype(where_self_148, torch.float32);  where_self_148 = None
        native_batch_norm_backward_default_148 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_446, convolution_default, primals_5, primals_3, primals_4, getitem_1, getitem_2, True, 0.001, [True, True, True]);  to_dtype_446 = convolution_default = primals_5 = primals_3 = primals_4 = getitem_1 = getitem_2 = None
        getitem_1343 = native_batch_norm_backward_default_148[0]
        getitem_1344 = native_batch_norm_backward_default_148[1]
        getitem_1345 = native_batch_norm_backward_default_148[2];  native_batch_norm_backward_default_148 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(getitem_1343, primals_897, primals_6, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_1343 = primals_897 = primals_6 = None
        getitem_1346 = convolution_backward_default_148[0]
        getitem_1347 = convolution_backward_default_148[1]
        getitem_1348 = convolution_backward_default_148[2];  convolution_backward_default_148 = None
        return [addmm_default, getitem_1345, None, None, None, getitem_1344, getitem_1347, getitem_1111, None, None, None, getitem_1110, getitem_1113, getitem_1105, None, None, None, getitem_1104, getitem_1107, getitem_1099, None, None, None, getitem_1098, getitem_1101, getitem_1093, None, None, None, getitem_1092, getitem_1095, getitem_1087, None, None, None, getitem_1086, getitem_1089, getitem_1081, None, None, None, getitem_1080, getitem_1083, getitem_1075, None, None, None, getitem_1074, getitem_1077, getitem_1069, None, None, None, getitem_1068, getitem_1071, getitem_1063, None, None, None, getitem_1062, getitem_1065, getitem_1057, None, None, None, getitem_1056, getitem_1059, getitem_1051, None, None, None, getitem_1050, getitem_1053, getitem_1045, None, None, None, getitem_1044, getitem_1047, getitem_1039, None, None, None, getitem_1038, getitem_1041, getitem_1033, None, None, None, getitem_1032, getitem_1035, getitem_1027, None, None, None, getitem_1026, getitem_1029, getitem_1021, None, None, None, getitem_1020, getitem_1023, getitem_1015, None, None, None, getitem_1014, getitem_1017, getitem_1009, None, None, None, getitem_1008, getitem_1011, getitem_1003, None, None, None, getitem_1002, getitem_1005, getitem_997, None, None, None, getitem_996, getitem_999, getitem_991, None, None, None, getitem_990, getitem_993, getitem_985, None, None, None, getitem_984, getitem_987, getitem_979, None, None, None, getitem_978, getitem_981, getitem_973, None, None, None, getitem_972, getitem_975, getitem_967, None, None, None, getitem_966, getitem_969, getitem_961, None, None, None, getitem_960, getitem_963, getitem_955, None, None, None, getitem_954, getitem_957, getitem_949, None, None, None, getitem_948, getitem_951, getitem_943, None, None, None, getitem_942, getitem_945, getitem_937, None, None, None, getitem_936, getitem_939, getitem_931, None, None, None, getitem_930, getitem_933, getitem_925, None, None, None, getitem_924, getitem_927, getitem_919, None, None, None, getitem_918, getitem_921, getitem_913, None, None, None, getitem_912, getitem_915, getitem_907, None, None, None, getitem_906, getitem_909, getitem_901, None, None, None, getitem_900, getitem_903, getitem_895, None, None, None, getitem_894, getitem_897, getitem_889, None, None, None, getitem_888, getitem_891, getitem_883, None, None, None, getitem_882, getitem_885, getitem_877, None, None, None, getitem_876, getitem_879, getitem_871, None, None, None, getitem_870, getitem_873, getitem_865, None, None, None, getitem_864, getitem_867, getitem_859, None, None, None, getitem_858, getitem_861, getitem_853, None, None, None, getitem_852, getitem_855, getitem_847, None, None, None, getitem_846, getitem_849, getitem_841, None, None, None, getitem_840, getitem_843, getitem_835, None, None, None, getitem_834, getitem_837, getitem_829, None, None, None, getitem_828, getitem_831, getitem_823, None, None, None, getitem_822, getitem_825, getitem_817, None, None, None, getitem_816, getitem_819, getitem_811, None, None, None, getitem_810, getitem_813, getitem_805, None, None, None, getitem_804, getitem_807, getitem_799, None, None, None, getitem_798, getitem_801, getitem_793, None, None, None, getitem_792, getitem_795, getitem_787, None, None, None, getitem_786, getitem_789, getitem_781, None, None, None, getitem_780, getitem_783, getitem_775, None, None, None, getitem_774, getitem_777, getitem_769, None, None, None, getitem_768, getitem_771, getitem_763, None, None, None, getitem_762, getitem_765, getitem_757, None, None, None, getitem_756, getitem_759, getitem_751, None, None, None, getitem_750, getitem_753, getitem_745, None, None, None, getitem_744, getitem_747, getitem_739, None, None, None, getitem_738, getitem_741, getitem_733, None, None, None, getitem_732, getitem_735, getitem_727, None, None, None, getitem_726, getitem_729, getitem_721, None, None, None, getitem_720, getitem_723, getitem_715, None, None, None, getitem_714, getitem_717, getitem_709, None, None, None, getitem_708, getitem_711, getitem_703, None, None, None, getitem_702, getitem_705, getitem_697, None, None, None, getitem_696, getitem_699, getitem_691, None, None, None, getitem_690, getitem_693, getitem_685, None, None, None, getitem_684, getitem_687, getitem_679, None, None, None, getitem_678, getitem_681, getitem_673, None, None, None, getitem_672, getitem_675, getitem_667, None, None, None, getitem_666, getitem_669, getitem_661, None, None, None, getitem_660, getitem_663, getitem_655, None, None, None, getitem_654, getitem_657, getitem_649, None, None, None, getitem_648, getitem_651, getitem_643, None, None, None, getitem_642, getitem_645, getitem_637, None, None, None, getitem_636, getitem_639, getitem_631, None, None, None, getitem_630, getitem_633, getitem_625, None, None, None, getitem_624, getitem_627, getitem_619, None, None, None, getitem_618, getitem_621, getitem_613, None, None, None, getitem_612, getitem_615, getitem_607, None, None, None, getitem_606, getitem_609, getitem_601, None, None, None, getitem_600, getitem_603, getitem_595, None, None, None, getitem_594, getitem_597, getitem_589, None, None, None, getitem_588, getitem_591, getitem_583, None, None, None, getitem_582, getitem_585, getitem_577, None, None, None, getitem_576, getitem_579, getitem_1339, None, None, None, getitem_1338, getitem_1341, getitem_571, None, None, None, getitem_570, getitem_573, getitem_565, None, None, None, getitem_564, getitem_567, getitem_559, None, None, None, getitem_558, getitem_561, getitem_553, None, None, None, getitem_552, getitem_555, getitem_547, None, None, None, getitem_546, getitem_549, getitem_541, None, None, None, getitem_540, getitem_543, getitem_535, None, None, None, getitem_534, getitem_537, getitem_529, None, None, None, getitem_528, getitem_531, getitem_523, None, None, None, getitem_522, getitem_525, getitem_517, None, None, None, getitem_516, getitem_519, getitem_511, None, None, None, getitem_510, getitem_513, getitem_505, None, None, None, getitem_504, getitem_507, getitem_499, None, None, None, getitem_498, getitem_501, getitem_493, None, None, None, getitem_492, getitem_495, getitem_487, None, None, None, getitem_486, getitem_489, getitem_481, None, None, None, getitem_480, getitem_483, getitem_475, None, None, None, getitem_474, getitem_477, getitem_469, None, None, None, getitem_468, getitem_471, getitem_463, None, None, None, getitem_462, getitem_465, getitem_457, None, None, None, getitem_456, getitem_459, getitem_1333, None, None, None, getitem_1332, getitem_1335, getitem_1327, None, None, None, getitem_1326, getitem_1329, getitem_1321, None, None, None, getitem_1320, getitem_1323, getitem_1315, None, None, None, getitem_1314, getitem_1317, getitem_1309, None, None, None, getitem_1308, getitem_1311, getitem_1303, None, None, None, getitem_1302, getitem_1305, getitem_1297, None, None, None, getitem_1296, getitem_1299, getitem_1291, None, None, None, getitem_1290, getitem_1293, getitem_1285, None, None, None, getitem_1284, getitem_1287, getitem_1279, None, None, None, getitem_1278, getitem_1281, getitem_1273, None, None, None, getitem_1272, getitem_1275, getitem_1267, None, None, None, getitem_1266, getitem_1269, getitem_1261, None, None, None, getitem_1260, getitem_1263, getitem_1255, None, None, None, getitem_1254, getitem_1257, getitem_1249, None, None, None, getitem_1248, getitem_1251, getitem_1243, None, None, None, getitem_1242, getitem_1245, getitem_1237, None, None, None, getitem_1236, getitem_1239, getitem_1231, None, None, None, getitem_1230, getitem_1233, getitem_1225, None, None, None, getitem_1224, getitem_1227, getitem_1219, None, None, None, getitem_1218, getitem_1221, getitem_1213, None, None, None, getitem_1212, getitem_1215, getitem_1207, None, None, None, getitem_1206, getitem_1209, getitem_1201, None, None, None, getitem_1200, getitem_1203, getitem_1195, None, None, None, getitem_1194, getitem_1197, getitem_1189, None, None, None, getitem_1188, getitem_1191, getitem_1183, None, None, None, getitem_1182, getitem_1185, getitem_1177, None, None, None, getitem_1176, getitem_1179, getitem_1171, None, None, None, getitem_1170, getitem_1173, getitem_1165, None, None, None, getitem_1164, getitem_1167, getitem_1159, None, None, None, getitem_1158, getitem_1161, getitem_1153, None, None, None, getitem_1152, getitem_1155, getitem_1147, None, None, None, getitem_1146, getitem_1149, getitem_1141, None, None, None, getitem_1140, getitem_1143, getitem_1135, None, None, None, getitem_1134, getitem_1137, getitem_1129, None, None, None, getitem_1128, getitem_1131, getitem_1123, None, None, None, getitem_1122, getitem_1125, getitem_1117, None, None, None, getitem_1116, getitem_1119, view_default_1, t_default_4, None]
        
