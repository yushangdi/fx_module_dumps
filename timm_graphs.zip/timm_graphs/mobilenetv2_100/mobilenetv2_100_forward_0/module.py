
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/mobilenetv2_100/mobilenetv2_100_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315):
        convolution_default = torch.ops.aten.convolution.default(primals_55, primals_54, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_56, 1);  primals_56 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_59, primals_60, primals_57, primals_58, True, 0.1, 1e-05);  primals_60 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        hardtanh__default = torch.ops.aten.hardtanh_.default(getitem, 0.0, 6.0)
        convolution_default_1 = torch.ops.aten.convolution.default(hardtanh__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_61, 1);  primals_61 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_64, primals_65, primals_62, primals_63, True, 0.1, 1e-05);  primals_65 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        hardtanh__default_1 = torch.ops.aten.hardtanh_.default(getitem_3, 0.0, 6.0)
        convolution_default_2 = torch.ops.aten.convolution.default(hardtanh__default_1, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_66, 1);  primals_66 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_69, primals_70, primals_67, primals_68, True, 0.1, 1e-05);  primals_70 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_6, primals_4, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_71, 1);  primals_71 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_74, primals_75, primals_72, primals_73, True, 0.1, 1e-05);  primals_75 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        hardtanh__default_2 = torch.ops.aten.hardtanh_.default(getitem_9, 0.0, 6.0)
        convolution_default_4 = torch.ops.aten.convolution.default(hardtanh__default_2, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 96)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_76, 1);  primals_76 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_79, primals_80, primals_77, primals_78, True, 0.1, 1e-05);  primals_80 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        hardtanh__default_3 = torch.ops.aten.hardtanh_.default(getitem_12, 0.0, 6.0)
        convolution_default_5 = torch.ops.aten.convolution.default(hardtanh__default_3, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_81, 1);  primals_81 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_84, primals_85, primals_82, primals_83, True, 0.1, 1e-05);  primals_85 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_86, 1);  primals_86 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_89, primals_90, primals_87, primals_88, True, 0.1, 1e-05);  primals_90 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        hardtanh__default_4 = torch.ops.aten.hardtanh_.default(getitem_18, 0.0, 6.0)
        convolution_default_7 = torch.ops.aten.convolution.default(hardtanh__default_4, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_91, 1);  primals_91 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_94, primals_95, primals_92, primals_93, True, 0.1, 1e-05);  primals_95 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        hardtanh__default_5 = torch.ops.aten.hardtanh_.default(getitem_21, 0.0, 6.0)
        convolution_default_8 = torch.ops.aten.convolution.default(hardtanh__default_5, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_96, 1);  primals_96 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_99, primals_100, primals_97, primals_98, True, 0.1, 1e-05);  primals_100 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_24, getitem_15);  getitem_24 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor_9, primals_10, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_101, 1);  primals_101 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_104, primals_105, primals_102, primals_103, True, 0.1, 1e-05);  primals_105 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        hardtanh__default_6 = torch.ops.aten.hardtanh_.default(getitem_27, 0.0, 6.0)
        convolution_default_10 = torch.ops.aten.convolution.default(hardtanh__default_6, primals_9, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 144)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_106, 1);  primals_106 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_109, primals_110, primals_107, primals_108, True, 0.1, 1e-05);  primals_110 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        hardtanh__default_7 = torch.ops.aten.hardtanh_.default(getitem_30, 0.0, 6.0)
        convolution_default_11 = torch.ops.aten.convolution.default(hardtanh__default_7, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_111, 1);  primals_111 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_114, primals_115, primals_112, primals_113, True, 0.1, 1e-05);  primals_115 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(getitem_33, primals_13, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_116, 1);  primals_116 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_119, primals_120, primals_117, primals_118, True, 0.1, 1e-05);  primals_120 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        hardtanh__default_8 = torch.ops.aten.hardtanh_.default(getitem_36, 0.0, 6.0)
        convolution_default_13 = torch.ops.aten.convolution.default(hardtanh__default_8, primals_12, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 192)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_121, 1);  primals_121 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_124, primals_125, primals_122, primals_123, True, 0.1, 1e-05);  primals_125 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        hardtanh__default_9 = torch.ops.aten.hardtanh_.default(getitem_39, 0.0, 6.0)
        convolution_default_14 = torch.ops.aten.convolution.default(hardtanh__default_9, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_126, 1);  primals_126 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_129, primals_130, primals_127, primals_128, True, 0.1, 1e-05);  primals_130 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_42, getitem_33);  getitem_42 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_16, primals_16, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_131, 1);  primals_131 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_134, primals_135, primals_132, primals_133, True, 0.1, 1e-05);  primals_135 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        hardtanh__default_10 = torch.ops.aten.hardtanh_.default(getitem_45, 0.0, 6.0)
        convolution_default_16 = torch.ops.aten.convolution.default(hardtanh__default_10, primals_15, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 192)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_136, 1);  primals_136 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_139, primals_140, primals_137, primals_138, True, 0.1, 1e-05);  primals_140 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        hardtanh__default_11 = torch.ops.aten.hardtanh_.default(getitem_48, 0.0, 6.0)
        convolution_default_17 = torch.ops.aten.convolution.default(hardtanh__default_11, primals_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_141, 1);  primals_141 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_144, primals_145, primals_142, primals_143, True, 0.1, 1e-05);  primals_145 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(getitem_51, add_tensor_16);  getitem_51 = None
        convolution_default_18 = torch.ops.aten.convolution.default(add_tensor_20, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_146, 1);  primals_146 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_149, primals_150, primals_147, primals_148, True, 0.1, 1e-05);  primals_150 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        hardtanh__default_12 = torch.ops.aten.hardtanh_.default(getitem_54, 0.0, 6.0)
        convolution_default_19 = torch.ops.aten.convolution.default(hardtanh__default_12, primals_18, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 192)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_151, 1);  primals_151 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_154, primals_155, primals_152, primals_153, True, 0.1, 1e-05);  primals_155 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        hardtanh__default_13 = torch.ops.aten.hardtanh_.default(getitem_57, 0.0, 6.0)
        convolution_default_20 = torch.ops.aten.convolution.default(hardtanh__default_13, primals_20, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_156, 1);  primals_156 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_159, primals_160, primals_157, primals_158, True, 0.1, 1e-05);  primals_160 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        convolution_default_21 = torch.ops.aten.convolution.default(getitem_60, primals_22, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_161, 1);  primals_161 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_164, primals_165, primals_162, primals_163, True, 0.1, 1e-05);  primals_165 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        hardtanh__default_14 = torch.ops.aten.hardtanh_.default(getitem_63, 0.0, 6.0)
        convolution_default_22 = torch.ops.aten.convolution.default(hardtanh__default_14, primals_21, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_166, 1);  primals_166 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_169, primals_170, primals_167, primals_168, True, 0.1, 1e-05);  primals_170 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        hardtanh__default_15 = torch.ops.aten.hardtanh_.default(getitem_66, 0.0, 6.0)
        convolution_default_23 = torch.ops.aten.convolution.default(hardtanh__default_15, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_171, 1);  primals_171 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_174, primals_175, primals_172, primals_173, True, 0.1, 1e-05);  primals_175 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_69, getitem_60);  getitem_69 = None
        convolution_default_24 = torch.ops.aten.convolution.default(add_tensor_27, primals_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_176, 1);  primals_176 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_179, primals_180, primals_177, primals_178, True, 0.1, 1e-05);  primals_180 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        hardtanh__default_16 = torch.ops.aten.hardtanh_.default(getitem_72, 0.0, 6.0)
        convolution_default_25 = torch.ops.aten.convolution.default(hardtanh__default_16, primals_24, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_181, 1);  primals_181 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_184, primals_185, primals_182, primals_183, True, 0.1, 1e-05);  primals_185 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        hardtanh__default_17 = torch.ops.aten.hardtanh_.default(getitem_75, 0.0, 6.0)
        convolution_default_26 = torch.ops.aten.convolution.default(hardtanh__default_17, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_186, 1);  primals_186 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_189, primals_190, primals_187, primals_188, True, 0.1, 1e-05);  primals_190 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(getitem_78, add_tensor_27);  getitem_78 = None
        convolution_default_27 = torch.ops.aten.convolution.default(add_tensor_31, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_191, 1);  primals_191 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_194, primals_195, primals_192, primals_193, True, 0.1, 1e-05);  primals_195 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        hardtanh__default_18 = torch.ops.aten.hardtanh_.default(getitem_81, 0.0, 6.0)
        convolution_default_28 = torch.ops.aten.convolution.default(hardtanh__default_18, primals_27, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_196, 1);  primals_196 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_199, primals_200, primals_197, primals_198, True, 0.1, 1e-05);  primals_200 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        hardtanh__default_19 = torch.ops.aten.hardtanh_.default(getitem_84, 0.0, 6.0)
        convolution_default_29 = torch.ops.aten.convolution.default(hardtanh__default_19, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_34 = torch.ops.aten.add.Tensor(primals_201, 1);  primals_201 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_204, primals_205, primals_202, primals_203, True, 0.1, 1e-05);  primals_205 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_87, add_tensor_31);  getitem_87 = None
        convolution_default_30 = torch.ops.aten.convolution.default(add_tensor_35, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_206, 1);  primals_206 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_209, primals_210, primals_207, primals_208, True, 0.1, 1e-05);  primals_210 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        hardtanh__default_20 = torch.ops.aten.hardtanh_.default(getitem_90, 0.0, 6.0)
        convolution_default_31 = torch.ops.aten.convolution.default(hardtanh__default_20, primals_30, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_211, 1);  primals_211 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_214, primals_215, primals_212, primals_213, True, 0.1, 1e-05);  primals_215 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        hardtanh__default_21 = torch.ops.aten.hardtanh_.default(getitem_93, 0.0, 6.0)
        convolution_default_32 = torch.ops.aten.convolution.default(hardtanh__default_21, primals_32, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_38 = torch.ops.aten.add.Tensor(primals_216, 1);  primals_216 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_219, primals_220, primals_217, primals_218, True, 0.1, 1e-05);  primals_220 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        convolution_default_33 = torch.ops.aten.convolution.default(getitem_96, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_221, 1);  primals_221 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_224, primals_225, primals_222, primals_223, True, 0.1, 1e-05);  primals_225 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        hardtanh__default_22 = torch.ops.aten.hardtanh_.default(getitem_99, 0.0, 6.0)
        convolution_default_34 = torch.ops.aten.convolution.default(hardtanh__default_22, primals_33, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 576)
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_226, 1);  primals_226 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_229, primals_230, primals_227, primals_228, True, 0.1, 1e-05);  primals_230 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        hardtanh__default_23 = torch.ops.aten.hardtanh_.default(getitem_102, 0.0, 6.0)
        convolution_default_35 = torch.ops.aten.convolution.default(hardtanh__default_23, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_231, 1);  primals_231 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_234, primals_235, primals_232, primals_233, True, 0.1, 1e-05);  primals_235 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(getitem_105, getitem_96);  getitem_105 = None
        convolution_default_36 = torch.ops.aten.convolution.default(add_tensor_42, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_236, 1);  primals_236 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_239, primals_240, primals_237, primals_238, True, 0.1, 1e-05);  primals_240 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        hardtanh__default_24 = torch.ops.aten.hardtanh_.default(getitem_108, 0.0, 6.0)
        convolution_default_37 = torch.ops.aten.convolution.default(hardtanh__default_24, primals_36, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 576)
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_241, 1);  primals_241 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_244, primals_245, primals_242, primals_243, True, 0.1, 1e-05);  primals_245 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        hardtanh__default_25 = torch.ops.aten.hardtanh_.default(getitem_111, 0.0, 6.0)
        convolution_default_38 = torch.ops.aten.convolution.default(hardtanh__default_25, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_45 = torch.ops.aten.add.Tensor(primals_246, 1);  primals_246 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_249, primals_250, primals_247, primals_248, True, 0.1, 1e-05);  primals_250 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(getitem_114, add_tensor_42);  getitem_114 = None
        convolution_default_39 = torch.ops.aten.convolution.default(add_tensor_46, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_251, 1);  primals_251 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_254, primals_255, primals_252, primals_253, True, 0.1, 1e-05);  primals_255 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        hardtanh__default_26 = torch.ops.aten.hardtanh_.default(getitem_117, 0.0, 6.0)
        convolution_default_40 = torch.ops.aten.convolution.default(hardtanh__default_26, primals_39, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 576)
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_256, 1);  primals_256 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_259, primals_260, primals_257, primals_258, True, 0.1, 1e-05);  primals_260 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        hardtanh__default_27 = torch.ops.aten.hardtanh_.default(getitem_120, 0.0, 6.0)
        convolution_default_41 = torch.ops.aten.convolution.default(hardtanh__default_27, primals_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_49 = torch.ops.aten.add.Tensor(primals_261, 1);  primals_261 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_264, primals_265, primals_262, primals_263, True, 0.1, 1e-05);  primals_265 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        convolution_default_42 = torch.ops.aten.convolution.default(getitem_123, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_266, 1);  primals_266 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_269, primals_270, primals_267, primals_268, True, 0.1, 1e-05);  primals_270 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        hardtanh__default_28 = torch.ops.aten.hardtanh_.default(getitem_126, 0.0, 6.0)
        convolution_default_43 = torch.ops.aten.convolution.default(hardtanh__default_28, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 960)
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_271, 1);  primals_271 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_274, primals_275, primals_272, primals_273, True, 0.1, 1e-05);  primals_275 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        hardtanh__default_29 = torch.ops.aten.hardtanh_.default(getitem_129, 0.0, 6.0)
        convolution_default_44 = torch.ops.aten.convolution.default(hardtanh__default_29, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_276, 1);  primals_276 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_279, primals_280, primals_277, primals_278, True, 0.1, 1e-05);  primals_280 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_132, getitem_123);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(add_tensor_53, primals_46, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_281, 1);  primals_281 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_284, primals_285, primals_282, primals_283, True, 0.1, 1e-05);  primals_285 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        hardtanh__default_30 = torch.ops.aten.hardtanh_.default(getitem_135, 0.0, 6.0)
        convolution_default_46 = torch.ops.aten.convolution.default(hardtanh__default_30, primals_45, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 960)
        add_tensor_55 = torch.ops.aten.add.Tensor(primals_286, 1);  primals_286 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_289, primals_290, primals_287, primals_288, True, 0.1, 1e-05);  primals_290 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        hardtanh__default_31 = torch.ops.aten.hardtanh_.default(getitem_138, 0.0, 6.0)
        convolution_default_47 = torch.ops.aten.convolution.default(hardtanh__default_31, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_291, 1);  primals_291 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_294, primals_295, primals_292, primals_293, True, 0.1, 1e-05);  primals_295 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(getitem_141, add_tensor_53);  getitem_141 = None
        convolution_default_48 = torch.ops.aten.convolution.default(add_tensor_57, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_58 = torch.ops.aten.add.Tensor(primals_296, 1);  primals_296 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_299, primals_300, primals_297, primals_298, True, 0.1, 1e-05);  primals_300 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        hardtanh__default_32 = torch.ops.aten.hardtanh_.default(getitem_144, 0.0, 6.0)
        convolution_default_49 = torch.ops.aten.convolution.default(hardtanh__default_32, primals_48, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 960)
        add_tensor_59 = torch.ops.aten.add.Tensor(primals_301, 1);  primals_301 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_304, primals_305, primals_302, primals_303, True, 0.1, 1e-05);  primals_305 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        hardtanh__default_33 = torch.ops.aten.hardtanh_.default(getitem_147, 0.0, 6.0)
        convolution_default_50 = torch.ops.aten.convolution.default(hardtanh__default_33, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_60 = torch.ops.aten.add.Tensor(primals_306, 1);  primals_306 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_309, primals_310, primals_307, primals_308, True, 0.1, 1e-05);  primals_310 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        convolution_default_51 = torch.ops.aten.convolution.default(getitem_150, primals_53, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_311, 1);  primals_311 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_314, primals_315, primals_312, primals_313, True, 0.1, 1e-05);  primals_315 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        hardtanh__default_34 = torch.ops.aten.hardtanh_.default(getitem_153, 0.0, 6.0)
        mean_dim = torch.ops.aten.mean.dim(hardtanh__default_34, [-1, -2], True);  hardtanh__default_34 = None
        view_default = torch.ops.aten.view.default(mean_dim, [128, 1280]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_52);  primals_52 = None
        addmm_default = torch.ops.aten.addmm.default(primals_51, view_default, t_default);  primals_51 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_21, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_25, add_tensor_26, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_32, add_tensor_33, add_tensor_34, add_tensor_36, add_tensor_37, add_tensor_38, add_tensor_39, add_tensor_40, add_tensor_41, add_tensor_43, add_tensor_44, add_tensor_45, add_tensor_47, add_tensor_48, add_tensor_49, add_tensor_50, add_tensor_51, add_tensor_52, add_tensor_54, add_tensor_55, add_tensor_56, add_tensor_58, add_tensor_59, add_tensor_60, add_tensor_61, primals_33, getitem_92, getitem_91, primals_62, getitem_93, primals_35, primals_16, convolution_default_31, primals_36, getitem_90, primals_15, primals_32, primals_88, primals_63, primals_37, hardtanh__default_20, getitem_95, primals_87, getitem_94, getitem_125, primals_177, primals_34, primals_64, primals_84, hardtanh__default_21, convolution_default_32, primals_21, getitem_62, getitem_139, primals_109, getitem_35, getitem_140, primals_112, convolution_default_21, getitem_147, getitem_34, getitem_113, getitem_63, getitem_112, convolution_default_47, primals_25, getitem_138, primals_17, getitem_33, getitem_65, convolution_default_12, primals_104, getitem_36, getitem_64, primals_23, convolution_default_38, primals_113, hardtanh__default_31, getitem_38, getitem_111, primals_19, getitem_37, getitem_143, convolution_default_22, getitem_142, hardtanh__default_25, primals_179, getitem_66, getitem_116, getitem_117, hardtanh__default_14, getitem_115, convolution_default_48, primals_98, getitem_67, add_tensor_57, primals_182, primals_102, getitem_39, primals_169, primals_18, primals_108, getitem_68, getitem_145, hardtanh__default_8, convolution_default_39, primals_107, convolution_default_13, add_tensor_46, primals_20, getitem_144, primals_24, primals_38, primals_99, getitem_40, convolution_default_23, primals_22, getitem_41, getitem_146, primals_103, hardtanh__default_15, convolution_default_49, primals_50, primals_243, getitem_98, primals_307, primals_119, primals_153, primals_242, getitem_97, primals_287, primals_308, primals_45, convolution_default_42, convolution_default_51, primals_44, primals_154, getitem_126, primals_41, primals_117, primals_288, primals_309, getitem_50, getitem_49, getitem_96, primals_289, primals_40, primals_239, getitem_99, getitem_128, convolution_default_50, primals_42, convolution_default_33, primals_39, primals_238, getitem_127, primals_312, primals_237, t_default, primals_292, primals_313, getitem_154, convolution_default_17, getitem_151, getitem_101, primals_293, primals_314, view_default, primals_47, primals_143, getitem_48, getitem_100, primals_294, convolution_default_43, primals_234, primals_159, primals_233, hardtanh__default_11, primals_232, getitem_150, primals_139, primals_297, getitem_129, primals_46, getitem_155, getitem_53, getitem_153, primals_298, hardtanh__default_28, getitem_52, getitem_130, primals_299, getitem_148, primals_142, primals_48, primals_229, primals_137, primals_147, getitem_102, primals_228, getitem_149, getitem_131, hardtanh__default_22, primals_227, primals_302, primals_43, primals_158, convolution_default_18, convolution_default_34, add_tensor_20, primals_303, primals_144, primals_304, hardtanh__default_33, primals_49, primals_157, getitem_103, primals_138, primals_224, convolution_default_44, getitem_104, primals_118, primals_223, hardtanh__default_29, getitem_54, primals_114, primals_178, primals_172, primals_67, primals_173, hardtanh__default_1, getitem_71, convolution_default_24, getitem_70, getitem_8, getitem_72, getitem, getitem_9, getitem_7, getitem_2, primals_174, primals_168, getitem_1, add_tensor_27, convolution_default_3, primals_68, getitem_6, getitem_74, getitem_11, getitem_73, getitem_10, getitem_4, convolution_default_1, hardtanh__default, getitem_3, primals_69, getitem_5, hardtanh__default_16, hardtanh__default_2, convolution_default_25, convolution_default_4, convolution_default_2, primals_244, primals_192, convolution_default, getitem_152, primals_247, primals_189, hardtanh__default_18, primals_11, primals_193, hardtanh__default_4, primals_12, primals_248, primals_194, primals_249, getitem_86, getitem_23, getitem_85, primals_183, primals_10, getitem_22, primals_197, primals_252, primals_198, primals_253, primals_199, primals_254, getitem_84, getitem_21, getitem_88, primals_14, getitem_25, primals_202, primals_257, convolution_default_29, hardtanh__default_19, hardtanh__default_5, primals_258, primals_203, convolution_default_8, primals_259, primals_204, primals_13, convolution_default_9, add_tensor_35, getitem_89, primals_262, primals_207, getitem_26, convolution_default_30, add_tensor_9, primals_263, primals_208, primals_264, primals_209, primals_152, getitem_57, primals_9, getitem_55, convolution_default_14, getitem_56, primals_187, primals_267, getitem_134, convolution_default_45, primals_148, primals_268, convolution_default_19, getitem_133, hardtanh__default_32, getitem_135, primals_164, primals_269, hardtanh__default_9, primals_167, getitem_44, convolution_default_15, getitem_43, hardtanh__default_12, primals_272, add_tensor_53, getitem_45, primals_273, getitem_59, primals_188, getitem_58, primals_274, getitem_137, primals_133, getitem_46, add_tensor_16, getitem_136, primals_277, primals_278, primals_132, primals_279, getitem_47, primals_149, getitem_60, hardtanh__default_13, primals_282, convolution_default_20, primals_283, convolution_default_16, hardtanh__default_30, convolution_default_46, primals_284, getitem_61, primals_134, hardtanh__default_10, primals_79, getitem_27, primals_28, convolution_default_35, primals_163, primals_89, primals_124, primals_5, primals_122, getitem_29, getitem_30, primals_123, primals_78, getitem_28, hardtanh__default_23, primals_7, primals_27, primals_29, getitem_107, convolution_default_10, convolution_default_36, getitem_106, primals_127, primals_74, primals_97, primals_214, getitem_108, primals_6, primals_218, primals_77, primals_222, primals_213, primals_217, primals_2, primals_128, primals_184, primals_212, hardtanh__default_6, getitem_109, add_tensor_42, getitem_32, primals_82, primals_129, getitem_31, primals_92, primals_26, primals_94, primals_30, primals_73, getitem_110, primals_31, primals_83, primals_72, primals_8, primals_219, convolution_default_37, primals_93, primals_4, primals_1, primals_3, primals_162, hardtanh__default_7, hardtanh__default_24, convolution_default_11, getitem_75, getitem_120, primals_54, getitem_118, getitem_14, getitem_76, getitem_119, getitem_13, getitem_77, convolution_default_40, getitem_12, convolution_default_26, convolution_default_5, hardtanh__default_26, primals_53, primals_58, getitem_15, hardtanh__default_17, hardtanh__default_3, getitem_122, getitem_121, getitem_80, getitem_17, getitem_79, getitem_16, getitem_19, convolution_default_27, add_tensor_31, convolution_default_6, getitem_123, primals_59, getitem_82, hardtanh__default_27, convolution_default_41, getitem_81, getitem_18, primals_55, getitem_20, convolution_default_28, getitem_124, primals_57, getitem_83, convolution_default_7]
        
