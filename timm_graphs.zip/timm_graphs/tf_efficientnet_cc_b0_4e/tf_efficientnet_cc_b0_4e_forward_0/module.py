
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/tf_efficientnet_cc_b0_4e/tf_efficientnet_cc_b0_4e_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377):
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(primals_132, [0, 1, 0, 1], 0.0);  primals_132 = None
        convolution_default = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_131, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_133, 1);  primals_133 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_136, primals_137, primals_134, primals_135, True, 0.1, 0.001);  primals_137 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        silu__default = torch.ops.aten.silu_.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(silu__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_138, 1);  primals_138 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_141, primals_142, primals_139, primals_140, True, 0.1, 0.001);  primals_142 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        silu__default_1 = torch.ops.aten.silu_.default(getitem_3)
        mean_dim = torch.ops.aten.mean.dim(silu__default_1, [2, 3], True)
        convolution_default_2 = torch.ops.aten.convolution.default(mean_dim, primals_6, primals_5, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_5 = None
        silu__default_2 = torch.ops.aten.silu_.default(convolution_default_2)
        convolution_default_3 = torch.ops.aten.convolution.default(silu__default_2, primals_4, primals_3, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_3 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_3);  convolution_default_3 = None
        mul_tensor = torch.ops.aten.mul.Tensor(silu__default_1, sigmoid_default)
        convolution_default_4 = torch.ops.aten.convolution.default(mul_tensor, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_143, 1);  primals_143 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_146, primals_147, primals_144, primals_145, True, 0.1, 0.001);  primals_147 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_6, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_148, 1);  primals_148 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_151, primals_152, primals_149, primals_150, True, 0.1, 0.001);  primals_152 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        silu__default_3 = torch.ops.aten.silu_.default(getitem_9)
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(silu__default_3, [0, 1, 0, 1], 0.0);  silu__default_3 = None
        convolution_default_6 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, primals_7, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_153, 1);  primals_153 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_156, primals_157, primals_154, primals_155, True, 0.1, 0.001);  primals_157 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        silu__default_4 = torch.ops.aten.silu_.default(getitem_12)
        mean_dim_1 = torch.ops.aten.mean.dim(silu__default_4, [2, 3], True)
        convolution_default_7 = torch.ops.aten.convolution.default(mean_dim_1, primals_13, primals_12, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_12 = None
        silu__default_5 = torch.ops.aten.silu_.default(convolution_default_7)
        convolution_default_8 = torch.ops.aten.convolution.default(silu__default_5, primals_11, primals_10, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_10 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_8);  convolution_default_8 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(silu__default_4, sigmoid_default_1)
        convolution_default_9 = torch.ops.aten.convolution.default(mul_tensor_1, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_158, 1);  primals_158 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_161, primals_162, primals_159, primals_160, True, 0.1, 0.001);  primals_162 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_10 = torch.ops.aten.convolution.default(getitem_15, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_163, 1);  primals_163 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_166, primals_167, primals_164, primals_165, True, 0.1, 0.001);  primals_167 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        silu__default_6 = torch.ops.aten.silu_.default(getitem_18)
        convolution_default_11 = torch.ops.aten.convolution.default(silu__default_6, primals_14, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_168, 1);  primals_168 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_171, primals_172, primals_169, primals_170, True, 0.1, 0.001);  primals_172 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        silu__default_7 = torch.ops.aten.silu_.default(getitem_21)
        mean_dim_2 = torch.ops.aten.mean.dim(silu__default_7, [2, 3], True)
        convolution_default_12 = torch.ops.aten.convolution.default(mean_dim_2, primals_20, primals_19, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_19 = None
        silu__default_8 = torch.ops.aten.silu_.default(convolution_default_12)
        convolution_default_13 = torch.ops.aten.convolution.default(silu__default_8, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_13);  convolution_default_13 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(silu__default_7, sigmoid_default_2)
        convolution_default_14 = torch.ops.aten.convolution.default(mul_tensor_2, primals_16, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_173, 1);  primals_173 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_176, primals_177, primals_174, primals_175, True, 0.1, 0.001);  primals_177 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_24, getitem_15);  getitem_24 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_9, primals_22, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_178, 1);  primals_178 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_181, primals_182, primals_179, primals_180, True, 0.1, 0.001);  primals_182 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        silu__default_9 = torch.ops.aten.silu_.default(getitem_27)
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(silu__default_9, [1, 2, 1, 2], 0.0);  silu__default_9 = None
        convolution_default_16 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, primals_21, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 144)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_183, 1);  primals_183 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_186, primals_187, primals_184, primals_185, True, 0.1, 0.001);  primals_187 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        silu__default_10 = torch.ops.aten.silu_.default(getitem_30)
        mean_dim_3 = torch.ops.aten.mean.dim(silu__default_10, [2, 3], True)
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_3, primals_27, primals_26, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_26 = None
        silu__default_11 = torch.ops.aten.silu_.default(convolution_default_17)
        convolution_default_18 = torch.ops.aten.convolution.default(silu__default_11, primals_25, primals_24, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_24 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_18);  convolution_default_18 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(silu__default_10, sigmoid_default_3)
        convolution_default_19 = torch.ops.aten.convolution.default(mul_tensor_3, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_188, 1);  primals_188 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_191, primals_192, primals_189, primals_190, True, 0.1, 0.001);  primals_192 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_33, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_193, 1);  primals_193 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_196, primals_197, primals_194, primals_195, True, 0.1, 0.001);  primals_197 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        silu__default_12 = torch.ops.aten.silu_.default(getitem_36)
        convolution_default_21 = torch.ops.aten.convolution.default(silu__default_12, primals_28, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 240)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_198, 1);  primals_198 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_201, primals_202, primals_199, primals_200, True, 0.1, 0.001);  primals_202 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        silu__default_13 = torch.ops.aten.silu_.default(getitem_39)
        mean_dim_4 = torch.ops.aten.mean.dim(silu__default_13, [2, 3], True)
        convolution_default_22 = torch.ops.aten.convolution.default(mean_dim_4, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        silu__default_14 = torch.ops.aten.silu_.default(convolution_default_22)
        convolution_default_23 = torch.ops.aten.convolution.default(silu__default_14, primals_32, primals_31, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_31 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_23);  convolution_default_23 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(silu__default_13, sigmoid_default_4)
        convolution_default_24 = torch.ops.aten.convolution.default(mul_tensor_4, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_203, 1);  primals_203 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_206, primals_207, primals_204, primals_205, True, 0.1, 0.001);  primals_207 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_42, getitem_33);  getitem_42 = None
        convolution_default_25 = torch.ops.aten.convolution.default(add_tensor_16, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_208, 1);  primals_208 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_211, primals_212, primals_209, primals_210, True, 0.1, 0.001);  primals_212 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        silu__default_15 = torch.ops.aten.silu_.default(getitem_45)
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(silu__default_15, [0, 1, 0, 1], 0.0);  silu__default_15 = None
        convolution_default_26 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, primals_35, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 240)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_213, 1);  primals_213 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_216, primals_217, primals_214, primals_215, True, 0.1, 0.001);  primals_217 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        silu__default_16 = torch.ops.aten.silu_.default(getitem_48)
        mean_dim_5 = torch.ops.aten.mean.dim(silu__default_16, [2, 3], True)
        convolution_default_27 = torch.ops.aten.convolution.default(mean_dim_5, primals_41, primals_40, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_40 = None
        silu__default_17 = torch.ops.aten.silu_.default(convolution_default_27)
        convolution_default_28 = torch.ops.aten.convolution.default(silu__default_17, primals_39, primals_38, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_38 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_28);  convolution_default_28 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(silu__default_16, sigmoid_default_5)
        convolution_default_29 = torch.ops.aten.convolution.default(mul_tensor_5, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_218, 1);  primals_218 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_221, primals_222, primals_219, primals_220, True, 0.1, 0.001);  primals_222 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        convolution_default_30 = torch.ops.aten.convolution.default(getitem_51, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_223, 1);  primals_223 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_226, primals_227, primals_224, primals_225, True, 0.1, 0.001);  primals_227 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        silu__default_18 = torch.ops.aten.silu_.default(getitem_54)
        convolution_default_31 = torch.ops.aten.convolution.default(silu__default_18, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_228, 1);  primals_228 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_231, primals_232, primals_229, primals_230, True, 0.1, 0.001);  primals_232 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        silu__default_19 = torch.ops.aten.silu_.default(getitem_57)
        mean_dim_6 = torch.ops.aten.mean.dim(silu__default_19, [2, 3], True)
        convolution_default_32 = torch.ops.aten.convolution.default(mean_dim_6, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        silu__default_20 = torch.ops.aten.silu_.default(convolution_default_32)
        convolution_default_33 = torch.ops.aten.convolution.default(silu__default_20, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_33);  convolution_default_33 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(silu__default_19, sigmoid_default_6)
        convolution_default_34 = torch.ops.aten.convolution.default(mul_tensor_6, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_233, 1);  primals_233 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_236, primals_237, primals_234, primals_235, True, 0.1, 0.001);  primals_237 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(getitem_60, getitem_51);  getitem_60 = None
        convolution_default_35 = torch.ops.aten.convolution.default(add_tensor_23, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_238, 1);  primals_238 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_241, primals_242, primals_239, primals_240, True, 0.1, 0.001);  primals_242 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        silu__default_21 = torch.ops.aten.silu_.default(getitem_63)
        convolution_default_36 = torch.ops.aten.convolution.default(silu__default_21, primals_49, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_243, 1);  primals_243 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_246, primals_247, primals_244, primals_245, True, 0.1, 0.001);  primals_247 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        silu__default_22 = torch.ops.aten.silu_.default(getitem_66)
        mean_dim_7 = torch.ops.aten.mean.dim(silu__default_22, [2, 3], True)
        convolution_default_37 = torch.ops.aten.convolution.default(mean_dim_7, primals_55, primals_54, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_54 = None
        silu__default_23 = torch.ops.aten.silu_.default(convolution_default_37)
        convolution_default_38 = torch.ops.aten.convolution.default(silu__default_23, primals_53, primals_52, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_52 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_38);  convolution_default_38 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(silu__default_22, sigmoid_default_7)
        convolution_default_39 = torch.ops.aten.convolution.default(mul_tensor_7, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_248, 1);  primals_248 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_251, primals_252, primals_249, primals_250, True, 0.1, 0.001);  primals_252 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_69, add_tensor_23);  getitem_69 = None
        mean_dim_8 = torch.ops.aten.mean.dim(add_tensor_27, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_8, [128, 80]);  mean_dim_8 = None
        t_default = torch.ops.aten.t.default(primals_60);  primals_60 = None
        addmm_default = torch.ops.aten.addmm.default(primals_59, view_default, t_default);  primals_59 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(addmm_default);  addmm_default = None
        mm_default = torch.ops.aten.mm.default(sigmoid_default_8, primals_57)
        view_default_1 = torch.ops.aten.view.default(mm_default, [61440, 80, 1, 1]);  mm_default = None
        view_default_2 = torch.ops.aten.view.default(add_tensor_27, [1, 10240, 14, 14]);  add_tensor_27 = None
        convolution_default_40 = torch.ops.aten.convolution.default(view_default_2, view_default_1, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default = torch.ops.aten.permute.default(convolution_default_40, [1, 0, 2, 3]);  convolution_default_40 = None
        view_default_3 = torch.ops.aten.view.default(permute_default, [128, 480, 14, 14]);  permute_default = None
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_253, 1);  primals_253 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(view_default_3, primals_256, primals_257, primals_254, primals_255, True, 0.1, 0.001);  primals_257 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        silu__default_24 = torch.ops.aten.silu_.default(getitem_72)
        mm_default_1 = torch.ops.aten.mm.default(sigmoid_default_8, primals_56)
        view_default_4 = torch.ops.aten.view.default(mm_default_1, [61440, 1, 5, 5]);  mm_default_1 = None
        view_default_5 = torch.ops.aten.view.default(silu__default_24, [1, 61440, 14, 14]);  silu__default_24 = None
        convolution_default_41 = torch.ops.aten.convolution.default(view_default_5, view_default_4, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 61440)
        permute_default_1 = torch.ops.aten.permute.default(convolution_default_41, [1, 0, 2, 3]);  convolution_default_41 = None
        view_default_6 = torch.ops.aten.view.default(permute_default_1, [128, 480, 14, 14]);  permute_default_1 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_258, 1);  primals_258 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(view_default_6, primals_261, primals_262, primals_259, primals_260, True, 0.1, 0.001);  primals_262 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        silu__default_25 = torch.ops.aten.silu_.default(getitem_75)
        mean_dim_9 = torch.ops.aten.mean.dim(silu__default_25, [2, 3], True)
        convolution_default_42 = torch.ops.aten.convolution.default(mean_dim_9, primals_64, primals_63, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_63 = None
        silu__default_26 = torch.ops.aten.silu_.default(convolution_default_42)
        convolution_default_43 = torch.ops.aten.convolution.default(silu__default_26, primals_62, primals_61, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_61 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_43);  convolution_default_43 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(silu__default_25, sigmoid_default_9)
        mm_default_2 = torch.ops.aten.mm.default(sigmoid_default_8, primals_58)
        view_default_7 = torch.ops.aten.view.default(mm_default_2, [14336, 480, 1, 1]);  mm_default_2 = None
        view_default_8 = torch.ops.aten.view.default(mul_tensor_8, [1, 61440, 14, 14]);  mul_tensor_8 = None
        convolution_default_44 = torch.ops.aten.convolution.default(view_default_8, view_default_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_2 = torch.ops.aten.permute.default(convolution_default_44, [1, 0, 2, 3]);  convolution_default_44 = None
        view_default_9 = torch.ops.aten.view.default(permute_default_2, [128, 112, 14, 14]);  permute_default_2 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_263, 1);  primals_263 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(view_default_9, primals_266, primals_267, primals_264, primals_265, True, 0.1, 0.001);  primals_267 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        mean_dim_10 = torch.ops.aten.mean.dim(getitem_78, [-1, -2], True)
        view_default_10 = torch.ops.aten.view.default(mean_dim_10, [128, 112]);  mean_dim_10 = None
        t_default_1 = torch.ops.aten.t.default(primals_69);  primals_69 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_68, view_default_10, t_default_1);  primals_68 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(addmm_default_1);  addmm_default_1 = None
        mm_default_3 = torch.ops.aten.mm.default(sigmoid_default_10, primals_66)
        view_default_11 = torch.ops.aten.view.default(mm_default_3, [86016, 112, 1, 1]);  mm_default_3 = None
        view_default_12 = torch.ops.aten.view.default(getitem_78, [1, 14336, 14, 14])
        convolution_default_45 = torch.ops.aten.convolution.default(view_default_12, view_default_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_3 = torch.ops.aten.permute.default(convolution_default_45, [1, 0, 2, 3]);  convolution_default_45 = None
        view_default_13 = torch.ops.aten.view.default(permute_default_3, [128, 672, 14, 14]);  permute_default_3 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_268, 1);  primals_268 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(view_default_13, primals_271, primals_272, primals_269, primals_270, True, 0.1, 0.001);  primals_272 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        silu__default_27 = torch.ops.aten.silu_.default(getitem_81)
        mm_default_4 = torch.ops.aten.mm.default(sigmoid_default_10, primals_65)
        view_default_14 = torch.ops.aten.view.default(mm_default_4, [86016, 1, 5, 5]);  mm_default_4 = None
        view_default_15 = torch.ops.aten.view.default(silu__default_27, [1, 86016, 14, 14]);  silu__default_27 = None
        convolution_default_46 = torch.ops.aten.convolution.default(view_default_15, view_default_14, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 86016)
        permute_default_4 = torch.ops.aten.permute.default(convolution_default_46, [1, 0, 2, 3]);  convolution_default_46 = None
        view_default_16 = torch.ops.aten.view.default(permute_default_4, [128, 672, 14, 14]);  permute_default_4 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_273, 1);  primals_273 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(view_default_16, primals_276, primals_277, primals_274, primals_275, True, 0.1, 0.001);  primals_277 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        silu__default_28 = torch.ops.aten.silu_.default(getitem_84)
        mean_dim_11 = torch.ops.aten.mean.dim(silu__default_28, [2, 3], True)
        convolution_default_47 = torch.ops.aten.convolution.default(mean_dim_11, primals_73, primals_72, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_72 = None
        silu__default_29 = torch.ops.aten.silu_.default(convolution_default_47)
        convolution_default_48 = torch.ops.aten.convolution.default(silu__default_29, primals_71, primals_70, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_70 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_48);  convolution_default_48 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(silu__default_28, sigmoid_default_11)
        mm_default_5 = torch.ops.aten.mm.default(sigmoid_default_10, primals_67)
        view_default_17 = torch.ops.aten.view.default(mm_default_5, [14336, 672, 1, 1]);  mm_default_5 = None
        view_default_18 = torch.ops.aten.view.default(mul_tensor_9, [1, 86016, 14, 14]);  mul_tensor_9 = None
        convolution_default_49 = torch.ops.aten.convolution.default(view_default_18, view_default_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_5 = torch.ops.aten.permute.default(convolution_default_49, [1, 0, 2, 3]);  convolution_default_49 = None
        view_default_19 = torch.ops.aten.view.default(permute_default_5, [128, 112, 14, 14]);  permute_default_5 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_278, 1);  primals_278 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(view_default_19, primals_281, primals_282, primals_279, primals_280, True, 0.1, 0.001);  primals_282 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(getitem_87, getitem_78);  getitem_87 = getitem_78 = None
        mean_dim_12 = torch.ops.aten.mean.dim(add_tensor_34, [-1, -2], True)
        view_default_20 = torch.ops.aten.view.default(mean_dim_12, [128, 112]);  mean_dim_12 = None
        t_default_2 = torch.ops.aten.t.default(primals_78);  primals_78 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_77, view_default_20, t_default_2);  primals_77 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(addmm_default_2);  addmm_default_2 = None
        mm_default_6 = torch.ops.aten.mm.default(sigmoid_default_12, primals_75)
        view_default_21 = torch.ops.aten.view.default(mm_default_6, [86016, 112, 1, 1]);  mm_default_6 = None
        view_default_22 = torch.ops.aten.view.default(add_tensor_34, [1, 14336, 14, 14])
        convolution_default_50 = torch.ops.aten.convolution.default(view_default_22, view_default_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_6 = torch.ops.aten.permute.default(convolution_default_50, [1, 0, 2, 3]);  convolution_default_50 = None
        view_default_23 = torch.ops.aten.view.default(permute_default_6, [128, 672, 14, 14]);  permute_default_6 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_283, 1);  primals_283 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(view_default_23, primals_286, primals_287, primals_284, primals_285, True, 0.1, 0.001);  primals_287 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        silu__default_30 = torch.ops.aten.silu_.default(getitem_90)
        mm_default_7 = torch.ops.aten.mm.default(sigmoid_default_12, primals_74)
        view_default_24 = torch.ops.aten.view.default(mm_default_7, [86016, 1, 5, 5]);  mm_default_7 = None
        view_default_25 = torch.ops.aten.view.default(silu__default_30, [1, 86016, 14, 14]);  silu__default_30 = None
        convolution_default_51 = torch.ops.aten.convolution.default(view_default_25, view_default_24, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 86016)
        permute_default_7 = torch.ops.aten.permute.default(convolution_default_51, [1, 0, 2, 3]);  convolution_default_51 = None
        view_default_26 = torch.ops.aten.view.default(permute_default_7, [128, 672, 14, 14]);  permute_default_7 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_288, 1);  primals_288 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(view_default_26, primals_291, primals_292, primals_289, primals_290, True, 0.1, 0.001);  primals_292 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        silu__default_31 = torch.ops.aten.silu_.default(getitem_93)
        mean_dim_13 = torch.ops.aten.mean.dim(silu__default_31, [2, 3], True)
        convolution_default_52 = torch.ops.aten.convolution.default(mean_dim_13, primals_82, primals_81, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_81 = None
        silu__default_32 = torch.ops.aten.silu_.default(convolution_default_52)
        convolution_default_53 = torch.ops.aten.convolution.default(silu__default_32, primals_80, primals_79, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_79 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_53);  convolution_default_53 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(silu__default_31, sigmoid_default_13)
        mm_default_8 = torch.ops.aten.mm.default(sigmoid_default_12, primals_76)
        view_default_27 = torch.ops.aten.view.default(mm_default_8, [14336, 672, 1, 1]);  mm_default_8 = None
        view_default_28 = torch.ops.aten.view.default(mul_tensor_10, [1, 86016, 14, 14]);  mul_tensor_10 = None
        convolution_default_54 = torch.ops.aten.convolution.default(view_default_28, view_default_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_8 = torch.ops.aten.permute.default(convolution_default_54, [1, 0, 2, 3]);  convolution_default_54 = None
        view_default_29 = torch.ops.aten.view.default(permute_default_8, [128, 112, 14, 14]);  permute_default_8 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_293, 1);  primals_293 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(view_default_29, primals_296, primals_297, primals_294, primals_295, True, 0.1, 0.001);  primals_297 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_96, add_tensor_34);  getitem_96 = add_tensor_34 = None
        mean_dim_14 = torch.ops.aten.mean.dim(add_tensor_38, [-1, -2], True)
        view_default_30 = torch.ops.aten.view.default(mean_dim_14, [128, 112]);  mean_dim_14 = None
        t_default_3 = torch.ops.aten.t.default(primals_87);  primals_87 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_86, view_default_30, t_default_3);  primals_86 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(addmm_default_3);  addmm_default_3 = None
        mm_default_9 = torch.ops.aten.mm.default(sigmoid_default_14, primals_84)
        view_default_31 = torch.ops.aten.view.default(mm_default_9, [86016, 112, 1, 1]);  mm_default_9 = None
        view_default_32 = torch.ops.aten.view.default(add_tensor_38, [1, 14336, 14, 14]);  add_tensor_38 = None
        convolution_default_55 = torch.ops.aten.convolution.default(view_default_32, view_default_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_9 = torch.ops.aten.permute.default(convolution_default_55, [1, 0, 2, 3]);  convolution_default_55 = None
        view_default_33 = torch.ops.aten.view.default(permute_default_9, [128, 672, 14, 14]);  permute_default_9 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_298, 1);  primals_298 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(view_default_33, primals_301, primals_302, primals_299, primals_300, True, 0.1, 0.001);  primals_302 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        silu__default_33 = torch.ops.aten.silu_.default(getitem_99)
        mm_default_10 = torch.ops.aten.mm.default(sigmoid_default_14, primals_83)
        view_default_34 = torch.ops.aten.view.default(mm_default_10, [86016, 1, 5, 5]);  mm_default_10 = None
        view_default_35 = torch.ops.aten.view.default(silu__default_33, [1, 86016, 14, 14]);  silu__default_33 = None
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(view_default_35, [1, 2, 1, 2], 0.0);  view_default_35 = None
        convolution_default_56 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, view_default_34, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 86016)
        permute_default_10 = torch.ops.aten.permute.default(convolution_default_56, [1, 0, 2, 3]);  convolution_default_56 = None
        view_default_36 = torch.ops.aten.view.default(permute_default_10, [128, 672, 7, 7]);  permute_default_10 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_303, 1);  primals_303 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(view_default_36, primals_306, primals_307, primals_304, primals_305, True, 0.1, 0.001);  primals_307 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        silu__default_34 = torch.ops.aten.silu_.default(getitem_102)
        mean_dim_15 = torch.ops.aten.mean.dim(silu__default_34, [2, 3], True)
        convolution_default_57 = torch.ops.aten.convolution.default(mean_dim_15, primals_91, primals_90, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_90 = None
        silu__default_35 = torch.ops.aten.silu_.default(convolution_default_57)
        convolution_default_58 = torch.ops.aten.convolution.default(silu__default_35, primals_89, primals_88, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_88 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_58);  convolution_default_58 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(silu__default_34, sigmoid_default_15)
        mm_default_11 = torch.ops.aten.mm.default(sigmoid_default_14, primals_85)
        view_default_37 = torch.ops.aten.view.default(mm_default_11, [24576, 672, 1, 1]);  mm_default_11 = None
        view_default_38 = torch.ops.aten.view.default(mul_tensor_11, [1, 86016, 7, 7]);  mul_tensor_11 = None
        convolution_default_59 = torch.ops.aten.convolution.default(view_default_38, view_default_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_11 = torch.ops.aten.permute.default(convolution_default_59, [1, 0, 2, 3]);  convolution_default_59 = None
        view_default_39 = torch.ops.aten.view.default(permute_default_11, [128, 192, 7, 7]);  permute_default_11 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_308, 1);  primals_308 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(view_default_39, primals_311, primals_312, primals_309, primals_310, True, 0.1, 0.001);  primals_312 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        mean_dim_16 = torch.ops.aten.mean.dim(getitem_105, [-1, -2], True)
        view_default_40 = torch.ops.aten.view.default(mean_dim_16, [128, 192]);  mean_dim_16 = None
        t_default_4 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_95, view_default_40, t_default_4);  primals_95 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(addmm_default_4);  addmm_default_4 = None
        mm_default_12 = torch.ops.aten.mm.default(sigmoid_default_16, primals_93)
        view_default_41 = torch.ops.aten.view.default(mm_default_12, [147456, 192, 1, 1]);  mm_default_12 = None
        view_default_42 = torch.ops.aten.view.default(getitem_105, [1, 24576, 7, 7])
        convolution_default_60 = torch.ops.aten.convolution.default(view_default_42, view_default_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_12 = torch.ops.aten.permute.default(convolution_default_60, [1, 0, 2, 3]);  convolution_default_60 = None
        view_default_43 = torch.ops.aten.view.default(permute_default_12, [128, 1152, 7, 7]);  permute_default_12 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(primals_313, 1);  primals_313 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(view_default_43, primals_316, primals_317, primals_314, primals_315, True, 0.1, 0.001);  primals_317 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        silu__default_36 = torch.ops.aten.silu_.default(getitem_108)
        mm_default_13 = torch.ops.aten.mm.default(sigmoid_default_16, primals_92)
        view_default_44 = torch.ops.aten.view.default(mm_default_13, [147456, 1, 5, 5]);  mm_default_13 = None
        view_default_45 = torch.ops.aten.view.default(silu__default_36, [1, 147456, 7, 7]);  silu__default_36 = None
        convolution_default_61 = torch.ops.aten.convolution.default(view_default_45, view_default_44, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 147456)
        permute_default_13 = torch.ops.aten.permute.default(convolution_default_61, [1, 0, 2, 3]);  convolution_default_61 = None
        view_default_46 = torch.ops.aten.view.default(permute_default_13, [128, 1152, 7, 7]);  permute_default_13 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_318, 1);  primals_318 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(view_default_46, primals_321, primals_322, primals_319, primals_320, True, 0.1, 0.001);  primals_322 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        silu__default_37 = torch.ops.aten.silu_.default(getitem_111)
        mean_dim_17 = torch.ops.aten.mean.dim(silu__default_37, [2, 3], True)
        convolution_default_62 = torch.ops.aten.convolution.default(mean_dim_17, primals_100, primals_99, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_99 = None
        silu__default_38 = torch.ops.aten.silu_.default(convolution_default_62)
        convolution_default_63 = torch.ops.aten.convolution.default(silu__default_38, primals_98, primals_97, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_97 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_63);  convolution_default_63 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(silu__default_37, sigmoid_default_17)
        mm_default_14 = torch.ops.aten.mm.default(sigmoid_default_16, primals_94)
        view_default_47 = torch.ops.aten.view.default(mm_default_14, [24576, 1152, 1, 1]);  mm_default_14 = None
        view_default_48 = torch.ops.aten.view.default(mul_tensor_12, [1, 147456, 7, 7]);  mul_tensor_12 = None
        convolution_default_64 = torch.ops.aten.convolution.default(view_default_48, view_default_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_14 = torch.ops.aten.permute.default(convolution_default_64, [1, 0, 2, 3]);  convolution_default_64 = None
        view_default_49 = torch.ops.aten.view.default(permute_default_14, [128, 192, 7, 7]);  permute_default_14 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_323, 1);  primals_323 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(view_default_49, primals_326, primals_327, primals_324, primals_325, True, 0.1, 0.001);  primals_327 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_114, getitem_105);  getitem_114 = getitem_105 = None
        mean_dim_18 = torch.ops.aten.mean.dim(add_tensor_45, [-1, -2], True)
        view_default_50 = torch.ops.aten.view.default(mean_dim_18, [128, 192]);  mean_dim_18 = None
        t_default_5 = torch.ops.aten.t.default(primals_105);  primals_105 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_104, view_default_50, t_default_5);  primals_104 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(addmm_default_5);  addmm_default_5 = None
        mm_default_15 = torch.ops.aten.mm.default(sigmoid_default_18, primals_102)
        view_default_51 = torch.ops.aten.view.default(mm_default_15, [147456, 192, 1, 1]);  mm_default_15 = None
        view_default_52 = torch.ops.aten.view.default(add_tensor_45, [1, 24576, 7, 7])
        convolution_default_65 = torch.ops.aten.convolution.default(view_default_52, view_default_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_15 = torch.ops.aten.permute.default(convolution_default_65, [1, 0, 2, 3]);  convolution_default_65 = None
        view_default_53 = torch.ops.aten.view.default(permute_default_15, [128, 1152, 7, 7]);  permute_default_15 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_328, 1);  primals_328 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(view_default_53, primals_331, primals_332, primals_329, primals_330, True, 0.1, 0.001);  primals_332 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        silu__default_39 = torch.ops.aten.silu_.default(getitem_117)
        mm_default_16 = torch.ops.aten.mm.default(sigmoid_default_18, primals_101)
        view_default_54 = torch.ops.aten.view.default(mm_default_16, [147456, 1, 5, 5]);  mm_default_16 = None
        view_default_55 = torch.ops.aten.view.default(silu__default_39, [1, 147456, 7, 7]);  silu__default_39 = None
        convolution_default_66 = torch.ops.aten.convolution.default(view_default_55, view_default_54, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 147456)
        permute_default_16 = torch.ops.aten.permute.default(convolution_default_66, [1, 0, 2, 3]);  convolution_default_66 = None
        view_default_56 = torch.ops.aten.view.default(permute_default_16, [128, 1152, 7, 7]);  permute_default_16 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_333, 1);  primals_333 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(view_default_56, primals_336, primals_337, primals_334, primals_335, True, 0.1, 0.001);  primals_337 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        silu__default_40 = torch.ops.aten.silu_.default(getitem_120)
        mean_dim_19 = torch.ops.aten.mean.dim(silu__default_40, [2, 3], True)
        convolution_default_67 = torch.ops.aten.convolution.default(mean_dim_19, primals_109, primals_108, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_108 = None
        silu__default_41 = torch.ops.aten.silu_.default(convolution_default_67)
        convolution_default_68 = torch.ops.aten.convolution.default(silu__default_41, primals_107, primals_106, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_106 = None
        sigmoid_default_19 = torch.ops.aten.sigmoid.default(convolution_default_68);  convolution_default_68 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(silu__default_40, sigmoid_default_19)
        mm_default_17 = torch.ops.aten.mm.default(sigmoid_default_18, primals_103)
        view_default_57 = torch.ops.aten.view.default(mm_default_17, [24576, 1152, 1, 1]);  mm_default_17 = None
        view_default_58 = torch.ops.aten.view.default(mul_tensor_13, [1, 147456, 7, 7]);  mul_tensor_13 = None
        convolution_default_69 = torch.ops.aten.convolution.default(view_default_58, view_default_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_17 = torch.ops.aten.permute.default(convolution_default_69, [1, 0, 2, 3]);  convolution_default_69 = None
        view_default_59 = torch.ops.aten.view.default(permute_default_17, [128, 192, 7, 7]);  permute_default_17 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_338, 1);  primals_338 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(view_default_59, primals_341, primals_342, primals_339, primals_340, True, 0.1, 0.001);  primals_342 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(getitem_123, add_tensor_45);  getitem_123 = add_tensor_45 = None
        mean_dim_20 = torch.ops.aten.mean.dim(add_tensor_49, [-1, -2], True)
        view_default_60 = torch.ops.aten.view.default(mean_dim_20, [128, 192]);  mean_dim_20 = None
        t_default_6 = torch.ops.aten.t.default(primals_114);  primals_114 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_113, view_default_60, t_default_6);  primals_113 = None
        sigmoid_default_20 = torch.ops.aten.sigmoid.default(addmm_default_6);  addmm_default_6 = None
        mm_default_18 = torch.ops.aten.mm.default(sigmoid_default_20, primals_111)
        view_default_61 = torch.ops.aten.view.default(mm_default_18, [147456, 192, 1, 1]);  mm_default_18 = None
        view_default_62 = torch.ops.aten.view.default(add_tensor_49, [1, 24576, 7, 7])
        convolution_default_70 = torch.ops.aten.convolution.default(view_default_62, view_default_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_18 = torch.ops.aten.permute.default(convolution_default_70, [1, 0, 2, 3]);  convolution_default_70 = None
        view_default_63 = torch.ops.aten.view.default(permute_default_18, [128, 1152, 7, 7]);  permute_default_18 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_343, 1);  primals_343 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(view_default_63, primals_346, primals_347, primals_344, primals_345, True, 0.1, 0.001);  primals_347 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        silu__default_42 = torch.ops.aten.silu_.default(getitem_126)
        mm_default_19 = torch.ops.aten.mm.default(sigmoid_default_20, primals_110)
        view_default_64 = torch.ops.aten.view.default(mm_default_19, [147456, 1, 5, 5]);  mm_default_19 = None
        view_default_65 = torch.ops.aten.view.default(silu__default_42, [1, 147456, 7, 7]);  silu__default_42 = None
        convolution_default_71 = torch.ops.aten.convolution.default(view_default_65, view_default_64, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 147456)
        permute_default_19 = torch.ops.aten.permute.default(convolution_default_71, [1, 0, 2, 3]);  convolution_default_71 = None
        view_default_66 = torch.ops.aten.view.default(permute_default_19, [128, 1152, 7, 7]);  permute_default_19 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_348, 1);  primals_348 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(view_default_66, primals_351, primals_352, primals_349, primals_350, True, 0.1, 0.001);  primals_352 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        silu__default_43 = torch.ops.aten.silu_.default(getitem_129)
        mean_dim_21 = torch.ops.aten.mean.dim(silu__default_43, [2, 3], True)
        convolution_default_72 = torch.ops.aten.convolution.default(mean_dim_21, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        silu__default_44 = torch.ops.aten.silu_.default(convolution_default_72)
        convolution_default_73 = torch.ops.aten.convolution.default(silu__default_44, primals_116, primals_115, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_115 = None
        sigmoid_default_21 = torch.ops.aten.sigmoid.default(convolution_default_73);  convolution_default_73 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(silu__default_43, sigmoid_default_21)
        mm_default_20 = torch.ops.aten.mm.default(sigmoid_default_20, primals_112)
        view_default_67 = torch.ops.aten.view.default(mm_default_20, [24576, 1152, 1, 1]);  mm_default_20 = None
        view_default_68 = torch.ops.aten.view.default(mul_tensor_14, [1, 147456, 7, 7]);  mul_tensor_14 = None
        convolution_default_74 = torch.ops.aten.convolution.default(view_default_68, view_default_67, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_20 = torch.ops.aten.permute.default(convolution_default_74, [1, 0, 2, 3]);  convolution_default_74 = None
        view_default_69 = torch.ops.aten.view.default(permute_default_20, [128, 192, 7, 7]);  permute_default_20 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_353, 1);  primals_353 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(view_default_69, primals_356, primals_357, primals_354, primals_355, True, 0.1, 0.001);  primals_357 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_132, add_tensor_49);  getitem_132 = add_tensor_49 = None
        mean_dim_22 = torch.ops.aten.mean.dim(add_tensor_53, [-1, -2], True)
        view_default_70 = torch.ops.aten.view.default(mean_dim_22, [128, 192]);  mean_dim_22 = None
        t_default_7 = torch.ops.aten.t.default(primals_123);  primals_123 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_122, view_default_70, t_default_7);  primals_122 = None
        sigmoid_default_22 = torch.ops.aten.sigmoid.default(addmm_default_7);  addmm_default_7 = None
        mm_default_21 = torch.ops.aten.mm.default(sigmoid_default_22, primals_120)
        view_default_71 = torch.ops.aten.view.default(mm_default_21, [147456, 192, 1, 1]);  mm_default_21 = None
        view_default_72 = torch.ops.aten.view.default(add_tensor_53, [1, 24576, 7, 7]);  add_tensor_53 = None
        convolution_default_75 = torch.ops.aten.convolution.default(view_default_72, view_default_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_21 = torch.ops.aten.permute.default(convolution_default_75, [1, 0, 2, 3]);  convolution_default_75 = None
        view_default_73 = torch.ops.aten.view.default(permute_default_21, [128, 1152, 7, 7]);  permute_default_21 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_358, 1);  primals_358 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(view_default_73, primals_361, primals_362, primals_359, primals_360, True, 0.1, 0.001);  primals_362 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        silu__default_45 = torch.ops.aten.silu_.default(getitem_135)
        mm_default_22 = torch.ops.aten.mm.default(sigmoid_default_22, primals_119)
        view_default_74 = torch.ops.aten.view.default(mm_default_22, [147456, 1, 3, 3]);  mm_default_22 = None
        view_default_75 = torch.ops.aten.view.default(silu__default_45, [1, 147456, 7, 7]);  silu__default_45 = None
        convolution_default_76 = torch.ops.aten.convolution.default(view_default_75, view_default_74, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 147456)
        permute_default_22 = torch.ops.aten.permute.default(convolution_default_76, [1, 0, 2, 3]);  convolution_default_76 = None
        view_default_76 = torch.ops.aten.view.default(permute_default_22, [128, 1152, 7, 7]);  permute_default_22 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(primals_363, 1);  primals_363 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(view_default_76, primals_366, primals_367, primals_364, primals_365, True, 0.1, 0.001);  primals_367 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        silu__default_46 = torch.ops.aten.silu_.default(getitem_138)
        mean_dim_23 = torch.ops.aten.mean.dim(silu__default_46, [2, 3], True)
        convolution_default_77 = torch.ops.aten.convolution.default(mean_dim_23, primals_127, primals_126, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_126 = None
        silu__default_47 = torch.ops.aten.silu_.default(convolution_default_77)
        convolution_default_78 = torch.ops.aten.convolution.default(silu__default_47, primals_125, primals_124, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_124 = None
        sigmoid_default_23 = torch.ops.aten.sigmoid.default(convolution_default_78);  convolution_default_78 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(silu__default_46, sigmoid_default_23)
        mm_default_23 = torch.ops.aten.mm.default(sigmoid_default_22, primals_121)
        view_default_77 = torch.ops.aten.view.default(mm_default_23, [40960, 1152, 1, 1]);  mm_default_23 = None
        view_default_78 = torch.ops.aten.view.default(mul_tensor_15, [1, 147456, 7, 7]);  mul_tensor_15 = None
        convolution_default_79 = torch.ops.aten.convolution.default(view_default_78, view_default_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_23 = torch.ops.aten.permute.default(convolution_default_79, [1, 0, 2, 3]);  convolution_default_79 = None
        view_default_79 = torch.ops.aten.view.default(permute_default_23, [128, 320, 7, 7]);  permute_default_23 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_368, 1);  primals_368 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(view_default_79, primals_371, primals_372, primals_369, primals_370, True, 0.1, 0.001);  primals_372 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        convolution_default_80 = torch.ops.aten.convolution.default(getitem_141, primals_130, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_373, 1);  primals_373 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_376, primals_377, primals_374, primals_375, True, 0.1, 0.001);  primals_377 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        silu__default_48 = torch.ops.aten.silu_.default(getitem_144)
        mean_dim_24 = torch.ops.aten.mean.dim(silu__default_48, [-1, -2], True);  silu__default_48 = None
        view_default_80 = torch.ops.aten.view.default(mean_dim_24, [128, 1280]);  mean_dim_24 = None
        t_default_8 = torch.ops.aten.t.default(primals_129);  primals_129 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_128, view_default_80, t_default_8);  primals_128 = None
        return [addmm_default_8, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_24, add_tensor_25, add_tensor_26, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_35, add_tensor_36, add_tensor_37, add_tensor_39, add_tensor_40, add_tensor_41, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_50, add_tensor_51, add_tensor_52, add_tensor_54, add_tensor_55, add_tensor_56, add_tensor_57, primals_356, getitem_138, primals_245, sigmoid_default_17, primals_354, convolution_default_72, getitem_139, convolution_default_7, primals_239, mean_dim_1, getitem_13, getitem_35, getitem_36, getitem_140, getitem_14, getitem_26, getitem_27, getitem_130, getitem_9, convolution_default_15, primals_266, primals_376, getitem_7, getitem_8, getitem_34, getitem_25, mean_dim_21, primals_280, view_default_67, primals_166, primals_355, convolution_default_4, getitem_6, getitem_129, primals_241, view_default_24, primals_169, primals_244, view_default_25, convolution_default_20, view_default_57, primals_171, view_default_68, getitem_134, add_tensor_9, primals_234, getitem_95, view_default_58, view_default_47, getitem_125, getitem_131, silu__default_46, convolution_default_5, view_default_69, getitem_12, primals_240, primals_375, silu__default_4, getitem_33, getitem_38, getitem_29, view_default_26, getitem_116, primals_170, getitem_37, getitem_94, view_default_59, silu__default_43, mean_dim_13, getitem_28, getitem_124, convolution_default_77, primals_264, getitem_11, view_default_49, primals_371, getitem_10, getitem_115, primals_236, constant_pad_nd_default_1, primals_334, t_default_7, silu__default_47, primals_279, primals_265, getitem_93, view_default_70, t_default_6, primals_335, primals_374, sigmoid_default_23, primals_370, silu__default_5, silu__default_12, silu__default_31, view_default_60, t_default_5, silu__default_44, primals_285, convolution_default_52, view_default_50, convolution_default_6, primals_336, constant_pad_nd_default_2, convolution_default_21, primals_235, sigmoid_default_22, primals_281, mul_tensor_1, view_default_77, sigmoid_default_1, convolution_default_16, sigmoid_default_20, view_default_79, mean_dim_23, primals_284, getitem_39, primals_286, sigmoid_default_21, view_default_71, view_default_78, getitem_3, getitem_15, getitem_41, convolution_default_9, getitem_23, convolution_default_12, convolution_default_42, primals_136, getitem_40, getitem_5, getitem_22, mean_dim_4, getitem_4, primals_274, convolution_default_2, getitem_17, mean_dim, convolution_default_22, getitem_18, getitem_16, getitem_21, silu__default_26, primals_110, silu__default_13, sigmoid_default_9, primals_319, convolution_default_10, silu__default_7, mean_dim_2, primals_275, primals_134, primals_139, silu__default_1, getitem_20, getitem_19, primals_107, primals_341, silu__default_14, convolution_default_14, silu__default_8, view_default_7, primals_135, view_default_8, silu__default_2, primals_321, sigmoid_default_4, getitem_79, getitem_80, silu__default_6, sigmoid_default_2, sigmoid_default, mul_tensor, mul_tensor_4, primals_109, primals_140, mul_tensor_2, convolution_default_24, convolution_default_11, view_default_9, primals_320, primals_261, getitem_30, getitem_44, convolution_default_17, getitem_71, mean_dim_3, sigmoid_default_11, primals_296, getitem_31, getitem_43, getitem_45, primals_112, primals_55, getitem_32, primals_256, getitem_70, silu__default_29, sigmoid_default_15, primals_250, t_default, primals_51, primals_62, view_default, primals_49, add_tensor_16, primals_254, primals_304, primals_116, primals_50, primals_249, silu__default_10, primals_145, primals_46, primals_300, convolution_default_25, primals_111, getitem_47, sigmoid_default_8, view_default_37, getitem_46, view_default_38, getitem_107, primals_53, primals_324, primals_260, primals_56, primals_246, primals_309, primals_299, primals_310, convolution_default_26, view_default_17, view_default_39, primals_57, silu__default_11, getitem_106, primals_141, primals_118, view_default_1, view_default_18, primals_306, view_default_2, getitem_89, t_default_4, primals_259, primals_294, primals_301, getitem_73, view_default_19, sigmoid_default_3, primals_146, getitem_48, getitem_88, primals_48, primals_251, getitem_72, view_default_40, view_default_3, primals_326, primals_144, primals_255, primals_305, mul_tensor_3, getitem_74, primals_311, convolution_default_19, constant_pad_nd_default_3, primals_325, primals_58, primals_295, mean_dim_5, getitem_53, primals_221, getitem_144, primals_98, primals_215, getitem_52, primals_32, primals_101, getitem_133, primals_102, getitem_142, primals_130, getitem_51, getitem_141, convolution_default_30, primals_361, getitem_54, primals_121, convolution_default_80, getitem_143, primals_219, view_default_14, getitem_56, primals_36, primals_216, mean_dim_6, primals_346, view_default_15, primals_94, getitem_55, primals_35, getitem_86, primals_29, primals_214, primals_226, primals_103, getitem_146, view_default_16, getitem_145, primals_23, primals_21, primals_229, getitem_85, primals_28, mean_dim_11, primals_34, constant_pad_nd_default, primals_27, primals_127, primals_340, primals_359, primals_100, primals_125, primals_91, primals_93, silu__default_18, primals_25, primals_350, primals_224, primals_92, primals_220, primals_30, getitem_84, convolution_default_47, convolution_default_31, primals_225, getitem_57, primals_360, primals_119, silu__default_28, primals_22, t_default_8, getitem_58, view_default_80, primals_120, primals_339, getitem_63, convolution_default_35, getitem_61, getitem_50, t_default_2, view_default_20, t_default_1, getitem_62, sigmoid_default_16, primals_330, sigmoid_default_10, getitem_49, view_default_10, primals_190, add_tensor_23, silu__default_22, sigmoid_default_12, silu__default_16, getitem_65, mean_dim_7, convolution_default_37, primals_186, getitem_64, view_default_41, primals_315, view_default_42, primals_316, primals_164, primals_329, convolution_default_27, getitem_110, convolution_default, primals_185, getitem, primals_189, silu__default_23, view_default_43, view_default_21, view_default_22, getitem_108, getitem_1, getitem_109, silu__default_17, getitem_92, primals_181, view_default_11, view_default_12, getitem_2, silu__default_21, mul_tensor_7, getitem_83, view_default_23, getitem_90, sigmoid_default_7, getitem_91, sigmoid_default_5, convolution_default_36, getitem_66, view_default_13, getitem_81, convolution_default_39, getitem_82, mul_tensor_5, convolution_default_1, convolution_default_29, primals_191, primals_180, getitem_67, silu__default, getitem_68, primals_165, view_default_45, primals_184, view_default_44, primals_194, t_default_3, primals_199, primals_291, primals_351, sigmoid_default_18, primals_196, view_default_48, primals_161, primals_159, getitem_122, primals_82, getitem_120, view_default_72, primals_149, primals_174, view_default_56, sigmoid_default_14, primals_156, getitem_121, view_default_61, view_default_62, mean_dim_19, getitem_137, primals_176, primals_9, view_default_51, getitem_128, view_default_52, view_default_73, primals_8, primals_151, primals_14, getitem_136, getitem_119, primals_84, view_default_63, getitem_127, primals_200, primals_83, view_default_53, view_default_31, view_default_32, getitem_118, primals_11, silu__default_40, getitem_101, primals_7, primals_80, primals_150, primals_269, getitem_135, convolution_default_67, primals_155, primals_289, primals_16, primals_20, view_default_33, primals_18, primals_271, getitem_99, getitem_100, getitem_126, primals_290, primals_15, primals_175, primals_270, getitem_117, view_default_54, primals_154, primals_6, primals_195, primals_89, primals_160, view_default_66, view_default_74, primals_85, silu__default_41, primals_179, primals_13, sigmoid_default_19, view_default_75, view_default_64, primals_201, view_default_55, view_default_65, view_default_76, primals_2, getitem_59, getitem_104, getitem_113, view_default_34, silu__default_19, view_default_46, constant_pad_nd_default_4, getitem_112, view_default_36, primals_206, mean_dim_17, convolution_default_32, getitem_103, mean_dim_15, primals_345, view_default_4, view_default_5, primals_209, primals_4, getitem_77, getitem_111, silu__default_20, primals_204, view_default_6, silu__default_37, getitem_102, getitem_76, primals_1, primals_210, primals_344, convolution_default_62, silu__default_34, primals_211, primals_364, primals_205, convolution_default_57, mul_tensor_6, sigmoid_default_6, convolution_default_34, mean_dim_9, getitem_75, silu__default_25, silu__default_35, silu__default_38, primals_314, silu__default_32, primals_37, primals_64, primals_366, primals_65, primals_230, sigmoid_default_13, primals_231, primals_349, primals_76, primals_44, primals_73, view_default_27, primals_42, primals_67, view_default_28, getitem_98, primals_66, primals_276, view_default_29, primals_369, primals_331, primals_74, getitem_97, primals_41, primals_75, primals_39, primals_131, primals_365, primals_71, primals_43, view_default_30]
        
