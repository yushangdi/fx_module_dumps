
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/tf_efficientnet_cc_b0_4e/tf_efficientnet_cc_b0_4e_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50):
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(primals_132, [0, 1, 0, 1], 0.0);  primals_132 = None
        convolution_default = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_131, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_133, 1);  primals_133 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_136, primals_137, primals_134, primals_135, True, 0.1, 0.001);  primals_137 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default = torch.ops.aten.clone.default(getitem)
        silu__default = torch.ops.aten.silu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(silu__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_138, 1);  primals_138 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_141, primals_142, primals_139, primals_140, True, 0.1, 0.001);  primals_142 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_1 = torch.ops.aten.clone.default(getitem_3)
        silu__default_1 = torch.ops.aten.silu_.default(getitem_3);  getitem_3 = None
        mean_dim = torch.ops.aten.mean.dim(silu__default_1, [2, 3], True)
        convolution_default_2 = torch.ops.aten.convolution.default(mean_dim, primals_6, primals_5, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_5 = None
        clone_default_2 = torch.ops.aten.clone.default(convolution_default_2)
        silu__default_2 = torch.ops.aten.silu_.default(convolution_default_2);  convolution_default_2 = None
        convolution_default_3 = torch.ops.aten.convolution.default(silu__default_2, primals_4, primals_3, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_3 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_3);  convolution_default_3 = None
        mul_tensor = torch.ops.aten.mul.Tensor(silu__default_1, sigmoid_default)
        convolution_default_4 = torch.ops.aten.convolution.default(mul_tensor, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_143, 1);  primals_143 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_146, primals_147, primals_144, primals_145, True, 0.1, 0.001);  primals_147 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_6, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_148, 1);  primals_148 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_151, primals_152, primals_149, primals_150, True, 0.1, 0.001);  primals_152 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_3 = torch.ops.aten.clone.default(getitem_9)
        silu__default_3 = torch.ops.aten.silu_.default(getitem_9);  getitem_9 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(silu__default_3, [0, 1, 0, 1], 0.0);  silu__default_3 = None
        convolution_default_6 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, primals_7, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 96)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_153, 1);  primals_153 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_156, primals_157, primals_154, primals_155, True, 0.1, 0.001);  primals_157 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_4 = torch.ops.aten.clone.default(getitem_12)
        silu__default_4 = torch.ops.aten.silu_.default(getitem_12);  getitem_12 = None
        mean_dim_1 = torch.ops.aten.mean.dim(silu__default_4, [2, 3], True)
        convolution_default_7 = torch.ops.aten.convolution.default(mean_dim_1, primals_13, primals_12, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_12 = None
        clone_default_5 = torch.ops.aten.clone.default(convolution_default_7)
        silu__default_5 = torch.ops.aten.silu_.default(convolution_default_7);  convolution_default_7 = None
        convolution_default_8 = torch.ops.aten.convolution.default(silu__default_5, primals_11, primals_10, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_10 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_8);  convolution_default_8 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(silu__default_4, sigmoid_default_1)
        convolution_default_9 = torch.ops.aten.convolution.default(mul_tensor_1, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_158, 1);  primals_158 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_161, primals_162, primals_159, primals_160, True, 0.1, 0.001);  primals_162 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_10 = torch.ops.aten.convolution.default(getitem_15, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_163, 1);  primals_163 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_166, primals_167, primals_164, primals_165, True, 0.1, 0.001);  primals_167 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_6 = torch.ops.aten.clone.default(getitem_18)
        silu__default_6 = torch.ops.aten.silu_.default(getitem_18);  getitem_18 = None
        convolution_default_11 = torch.ops.aten.convolution.default(silu__default_6, primals_14, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_168, 1);  primals_168 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_171, primals_172, primals_169, primals_170, True, 0.1, 0.001);  primals_172 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_7 = torch.ops.aten.clone.default(getitem_21)
        silu__default_7 = torch.ops.aten.silu_.default(getitem_21);  getitem_21 = None
        mean_dim_2 = torch.ops.aten.mean.dim(silu__default_7, [2, 3], True)
        convolution_default_12 = torch.ops.aten.convolution.default(mean_dim_2, primals_20, primals_19, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_19 = None
        clone_default_8 = torch.ops.aten.clone.default(convolution_default_12)
        silu__default_8 = torch.ops.aten.silu_.default(convolution_default_12);  convolution_default_12 = None
        convolution_default_13 = torch.ops.aten.convolution.default(silu__default_8, primals_18, primals_17, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_17 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_13);  convolution_default_13 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(silu__default_7, sigmoid_default_2)
        convolution_default_14 = torch.ops.aten.convolution.default(mul_tensor_2, primals_16, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_173, 1);  primals_173 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_176, primals_177, primals_174, primals_175, True, 0.1, 0.001);  primals_177 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_9 = torch.ops.aten.add.Tensor(getitem_24, getitem_15);  getitem_24 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_9, primals_22, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_178, 1);  primals_178 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_181, primals_182, primals_179, primals_180, True, 0.1, 0.001);  primals_182 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_9 = torch.ops.aten.clone.default(getitem_27)
        silu__default_9 = torch.ops.aten.silu_.default(getitem_27);  getitem_27 = None
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(silu__default_9, [1, 2, 1, 2], 0.0);  silu__default_9 = None
        convolution_default_16 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, primals_21, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 144)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_183, 1);  primals_183 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_186, primals_187, primals_184, primals_185, True, 0.1, 0.001);  primals_187 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_10 = torch.ops.aten.clone.default(getitem_30)
        silu__default_10 = torch.ops.aten.silu_.default(getitem_30);  getitem_30 = None
        mean_dim_3 = torch.ops.aten.mean.dim(silu__default_10, [2, 3], True)
        convolution_default_17 = torch.ops.aten.convolution.default(mean_dim_3, primals_27, primals_26, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_26 = None
        clone_default_11 = torch.ops.aten.clone.default(convolution_default_17)
        silu__default_11 = torch.ops.aten.silu_.default(convolution_default_17);  convolution_default_17 = None
        convolution_default_18 = torch.ops.aten.convolution.default(silu__default_11, primals_25, primals_24, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_24 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_18);  convolution_default_18 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(silu__default_10, sigmoid_default_3)
        convolution_default_19 = torch.ops.aten.convolution.default(mul_tensor_3, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_188, 1);  primals_188 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_191, primals_192, primals_189, primals_190, True, 0.1, 0.001);  primals_192 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_20 = torch.ops.aten.convolution.default(getitem_33, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_193, 1);  primals_193 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_196, primals_197, primals_194, primals_195, True, 0.1, 0.001);  primals_197 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_12 = torch.ops.aten.clone.default(getitem_36)
        silu__default_12 = torch.ops.aten.silu_.default(getitem_36);  getitem_36 = None
        convolution_default_21 = torch.ops.aten.convolution.default(silu__default_12, primals_28, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 240)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_198, 1);  primals_198 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_201, primals_202, primals_199, primals_200, True, 0.1, 0.001);  primals_202 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_13 = torch.ops.aten.clone.default(getitem_39)
        silu__default_13 = torch.ops.aten.silu_.default(getitem_39);  getitem_39 = None
        mean_dim_4 = torch.ops.aten.mean.dim(silu__default_13, [2, 3], True)
        convolution_default_22 = torch.ops.aten.convolution.default(mean_dim_4, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        clone_default_14 = torch.ops.aten.clone.default(convolution_default_22)
        silu__default_14 = torch.ops.aten.silu_.default(convolution_default_22);  convolution_default_22 = None
        convolution_default_23 = torch.ops.aten.convolution.default(silu__default_14, primals_32, primals_31, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_31 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_23);  convolution_default_23 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(silu__default_13, sigmoid_default_4)
        convolution_default_24 = torch.ops.aten.convolution.default(mul_tensor_4, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_203, 1);  primals_203 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_206, primals_207, primals_204, primals_205, True, 0.1, 0.001);  primals_207 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_16 = torch.ops.aten.add.Tensor(getitem_42, getitem_33);  getitem_42 = None
        convolution_default_25 = torch.ops.aten.convolution.default(add_tensor_16, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_208, 1);  primals_208 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_211, primals_212, primals_209, primals_210, True, 0.1, 0.001);  primals_212 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_15 = torch.ops.aten.clone.default(getitem_45)
        silu__default_15 = torch.ops.aten.silu_.default(getitem_45);  getitem_45 = None
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(silu__default_15, [0, 1, 0, 1], 0.0);  silu__default_15 = None
        convolution_default_26 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, primals_35, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 240)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_213, 1);  primals_213 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_216, primals_217, primals_214, primals_215, True, 0.1, 0.001);  primals_217 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_16 = torch.ops.aten.clone.default(getitem_48)
        silu__default_16 = torch.ops.aten.silu_.default(getitem_48);  getitem_48 = None
        mean_dim_5 = torch.ops.aten.mean.dim(silu__default_16, [2, 3], True)
        convolution_default_27 = torch.ops.aten.convolution.default(mean_dim_5, primals_41, primals_40, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_40 = None
        clone_default_17 = torch.ops.aten.clone.default(convolution_default_27)
        silu__default_17 = torch.ops.aten.silu_.default(convolution_default_27);  convolution_default_27 = None
        convolution_default_28 = torch.ops.aten.convolution.default(silu__default_17, primals_39, primals_38, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_38 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_28);  convolution_default_28 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(silu__default_16, sigmoid_default_5)
        convolution_default_29 = torch.ops.aten.convolution.default(mul_tensor_5, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_218, 1);  primals_218 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_221, primals_222, primals_219, primals_220, True, 0.1, 0.001);  primals_222 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_30 = torch.ops.aten.convolution.default(getitem_51, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_223, 1);  primals_223 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_226, primals_227, primals_224, primals_225, True, 0.1, 0.001);  primals_227 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_18 = torch.ops.aten.clone.default(getitem_54)
        silu__default_18 = torch.ops.aten.silu_.default(getitem_54);  getitem_54 = None
        convolution_default_31 = torch.ops.aten.convolution.default(silu__default_18, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_228, 1);  primals_228 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_231, primals_232, primals_229, primals_230, True, 0.1, 0.001);  primals_232 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_19 = torch.ops.aten.clone.default(getitem_57)
        silu__default_19 = torch.ops.aten.silu_.default(getitem_57);  getitem_57 = None
        mean_dim_6 = torch.ops.aten.mean.dim(silu__default_19, [2, 3], True)
        convolution_default_32 = torch.ops.aten.convolution.default(mean_dim_6, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        clone_default_20 = torch.ops.aten.clone.default(convolution_default_32)
        silu__default_20 = torch.ops.aten.silu_.default(convolution_default_32);  convolution_default_32 = None
        convolution_default_33 = torch.ops.aten.convolution.default(silu__default_20, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_33);  convolution_default_33 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(silu__default_19, sigmoid_default_6)
        convolution_default_34 = torch.ops.aten.convolution.default(mul_tensor_6, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_233, 1);  primals_233 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_236, primals_237, primals_234, primals_235, True, 0.1, 0.001);  primals_237 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_23 = torch.ops.aten.add.Tensor(getitem_60, getitem_51);  getitem_60 = None
        convolution_default_35 = torch.ops.aten.convolution.default(add_tensor_23, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_238, 1);  primals_238 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_241, primals_242, primals_239, primals_240, True, 0.1, 0.001);  primals_242 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_21 = torch.ops.aten.clone.default(getitem_63)
        silu__default_21 = torch.ops.aten.silu_.default(getitem_63);  getitem_63 = None
        convolution_default_36 = torch.ops.aten.convolution.default(silu__default_21, primals_49, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 480)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_243, 1);  primals_243 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_246, primals_247, primals_244, primals_245, True, 0.1, 0.001);  primals_247 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_22 = torch.ops.aten.clone.default(getitem_66)
        silu__default_22 = torch.ops.aten.silu_.default(getitem_66);  getitem_66 = None
        mean_dim_7 = torch.ops.aten.mean.dim(silu__default_22, [2, 3], True)
        convolution_default_37 = torch.ops.aten.convolution.default(mean_dim_7, primals_55, primals_54, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_54 = None
        clone_default_23 = torch.ops.aten.clone.default(convolution_default_37)
        silu__default_23 = torch.ops.aten.silu_.default(convolution_default_37);  convolution_default_37 = None
        convolution_default_38 = torch.ops.aten.convolution.default(silu__default_23, primals_53, primals_52, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_52 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_38);  convolution_default_38 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(silu__default_22, sigmoid_default_7)
        convolution_default_39 = torch.ops.aten.convolution.default(mul_tensor_7, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_248, 1);  primals_248 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_251, primals_252, primals_249, primals_250, True, 0.1, 0.001);  primals_252 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_69, add_tensor_23);  getitem_69 = None
        mean_dim_8 = torch.ops.aten.mean.dim(add_tensor_27, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_8, [128, 80]);  mean_dim_8 = None
        t_default = torch.ops.aten.t.default(primals_60);  primals_60 = None
        addmm_default = torch.ops.aten.addmm.default(primals_59, view_default, t_default);  primals_59 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(addmm_default);  addmm_default = None
        mm_default = torch.ops.aten.mm.default(sigmoid_default_8, primals_57)
        view_default_1 = torch.ops.aten.view.default(mm_default, [61440, 80, 1, 1]);  mm_default = None
        view_default_2 = torch.ops.aten.view.default(add_tensor_27, [1, 10240, 14, 14]);  add_tensor_27 = None
        convolution_default_40 = torch.ops.aten.convolution.default(view_default_2, view_default_1, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default = torch.ops.aten.permute.default(convolution_default_40, [1, 0, 2, 3]);  convolution_default_40 = None
        view_default_3 = torch.ops.aten.view.default(permute_default, [128, 480, 14, 14]);  permute_default = None
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_253, 1);  primals_253 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(view_default_3, primals_256, primals_257, primals_254, primals_255, True, 0.1, 0.001);  primals_257 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(view_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_24 = torch.ops.aten.clone.default(getitem_72)
        silu__default_24 = torch.ops.aten.silu_.default(getitem_72);  getitem_72 = None
        mm_default_1 = torch.ops.aten.mm.default(sigmoid_default_8, primals_56)
        view_default_4 = torch.ops.aten.view.default(mm_default_1, [61440, 1, 5, 5]);  mm_default_1 = None
        view_default_5 = torch.ops.aten.view.default(silu__default_24, [1, 61440, 14, 14]);  silu__default_24 = None
        convolution_default_41 = torch.ops.aten.convolution.default(view_default_5, view_default_4, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 61440)
        permute_default_1 = torch.ops.aten.permute.default(convolution_default_41, [1, 0, 2, 3]);  convolution_default_41 = None
        view_default_6 = torch.ops.aten.view.default(permute_default_1, [128, 480, 14, 14]);  permute_default_1 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_258, 1);  primals_258 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(view_default_6, primals_261, primals_262, primals_259, primals_260, True, 0.1, 0.001);  primals_262 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(view_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_25 = torch.ops.aten.clone.default(getitem_75)
        silu__default_25 = torch.ops.aten.silu_.default(getitem_75);  getitem_75 = None
        mean_dim_9 = torch.ops.aten.mean.dim(silu__default_25, [2, 3], True)
        convolution_default_42 = torch.ops.aten.convolution.default(mean_dim_9, primals_64, primals_63, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_63 = None
        clone_default_26 = torch.ops.aten.clone.default(convolution_default_42)
        silu__default_26 = torch.ops.aten.silu_.default(convolution_default_42);  convolution_default_42 = None
        convolution_default_43 = torch.ops.aten.convolution.default(silu__default_26, primals_62, primals_61, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_61 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_43);  convolution_default_43 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(silu__default_25, sigmoid_default_9)
        mm_default_2 = torch.ops.aten.mm.default(sigmoid_default_8, primals_58)
        view_default_7 = torch.ops.aten.view.default(mm_default_2, [14336, 480, 1, 1]);  mm_default_2 = None
        view_default_8 = torch.ops.aten.view.default(mul_tensor_8, [1, 61440, 14, 14]);  mul_tensor_8 = None
        convolution_default_44 = torch.ops.aten.convolution.default(view_default_8, view_default_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_2 = torch.ops.aten.permute.default(convolution_default_44, [1, 0, 2, 3]);  convolution_default_44 = None
        view_default_9 = torch.ops.aten.view.default(permute_default_2, [128, 112, 14, 14]);  permute_default_2 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_263, 1);  primals_263 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(view_default_9, primals_266, primals_267, primals_264, primals_265, True, 0.1, 0.001);  primals_267 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(view_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_10 = torch.ops.aten.mean.dim(getitem_78, [-1, -2], True)
        view_default_10 = torch.ops.aten.view.default(mean_dim_10, [128, 112]);  mean_dim_10 = None
        t_default_1 = torch.ops.aten.t.default(primals_69);  primals_69 = None
        addmm_default_1 = torch.ops.aten.addmm.default(primals_68, view_default_10, t_default_1);  primals_68 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(addmm_default_1);  addmm_default_1 = None
        mm_default_3 = torch.ops.aten.mm.default(sigmoid_default_10, primals_66)
        view_default_11 = torch.ops.aten.view.default(mm_default_3, [86016, 112, 1, 1]);  mm_default_3 = None
        view_default_12 = torch.ops.aten.view.default(getitem_78, [1, 14336, 14, 14])
        convolution_default_45 = torch.ops.aten.convolution.default(view_default_12, view_default_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_3 = torch.ops.aten.permute.default(convolution_default_45, [1, 0, 2, 3]);  convolution_default_45 = None
        view_default_13 = torch.ops.aten.view.default(permute_default_3, [128, 672, 14, 14]);  permute_default_3 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_268, 1);  primals_268 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(view_default_13, primals_271, primals_272, primals_269, primals_270, True, 0.1, 0.001);  primals_272 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(view_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_27 = torch.ops.aten.clone.default(getitem_81)
        silu__default_27 = torch.ops.aten.silu_.default(getitem_81);  getitem_81 = None
        mm_default_4 = torch.ops.aten.mm.default(sigmoid_default_10, primals_65)
        view_default_14 = torch.ops.aten.view.default(mm_default_4, [86016, 1, 5, 5]);  mm_default_4 = None
        view_default_15 = torch.ops.aten.view.default(silu__default_27, [1, 86016, 14, 14]);  silu__default_27 = None
        convolution_default_46 = torch.ops.aten.convolution.default(view_default_15, view_default_14, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 86016)
        permute_default_4 = torch.ops.aten.permute.default(convolution_default_46, [1, 0, 2, 3]);  convolution_default_46 = None
        view_default_16 = torch.ops.aten.view.default(permute_default_4, [128, 672, 14, 14]);  permute_default_4 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_273, 1);  primals_273 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(view_default_16, primals_276, primals_277, primals_274, primals_275, True, 0.1, 0.001);  primals_277 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(view_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_28 = torch.ops.aten.clone.default(getitem_84)
        silu__default_28 = torch.ops.aten.silu_.default(getitem_84);  getitem_84 = None
        mean_dim_11 = torch.ops.aten.mean.dim(silu__default_28, [2, 3], True)
        convolution_default_47 = torch.ops.aten.convolution.default(mean_dim_11, primals_73, primals_72, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_72 = None
        clone_default_29 = torch.ops.aten.clone.default(convolution_default_47)
        silu__default_29 = torch.ops.aten.silu_.default(convolution_default_47);  convolution_default_47 = None
        convolution_default_48 = torch.ops.aten.convolution.default(silu__default_29, primals_71, primals_70, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_70 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_48);  convolution_default_48 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(silu__default_28, sigmoid_default_11)
        mm_default_5 = torch.ops.aten.mm.default(sigmoid_default_10, primals_67)
        view_default_17 = torch.ops.aten.view.default(mm_default_5, [14336, 672, 1, 1]);  mm_default_5 = None
        view_default_18 = torch.ops.aten.view.default(mul_tensor_9, [1, 86016, 14, 14]);  mul_tensor_9 = None
        convolution_default_49 = torch.ops.aten.convolution.default(view_default_18, view_default_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_5 = torch.ops.aten.permute.default(convolution_default_49, [1, 0, 2, 3]);  convolution_default_49 = None
        view_default_19 = torch.ops.aten.view.default(permute_default_5, [128, 112, 14, 14]);  permute_default_5 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_278, 1);  primals_278 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(view_default_19, primals_281, primals_282, primals_279, primals_280, True, 0.1, 0.001);  primals_282 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(view_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_34 = torch.ops.aten.add.Tensor(getitem_87, getitem_78);  getitem_87 = getitem_78 = None
        mean_dim_12 = torch.ops.aten.mean.dim(add_tensor_34, [-1, -2], True)
        view_default_20 = torch.ops.aten.view.default(mean_dim_12, [128, 112]);  mean_dim_12 = None
        t_default_2 = torch.ops.aten.t.default(primals_78);  primals_78 = None
        addmm_default_2 = torch.ops.aten.addmm.default(primals_77, view_default_20, t_default_2);  primals_77 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(addmm_default_2);  addmm_default_2 = None
        mm_default_6 = torch.ops.aten.mm.default(sigmoid_default_12, primals_75)
        view_default_21 = torch.ops.aten.view.default(mm_default_6, [86016, 112, 1, 1]);  mm_default_6 = None
        view_default_22 = torch.ops.aten.view.default(add_tensor_34, [1, 14336, 14, 14])
        convolution_default_50 = torch.ops.aten.convolution.default(view_default_22, view_default_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_6 = torch.ops.aten.permute.default(convolution_default_50, [1, 0, 2, 3]);  convolution_default_50 = None
        view_default_23 = torch.ops.aten.view.default(permute_default_6, [128, 672, 14, 14]);  permute_default_6 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_283, 1);  primals_283 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(view_default_23, primals_286, primals_287, primals_284, primals_285, True, 0.1, 0.001);  primals_287 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(view_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_30 = torch.ops.aten.clone.default(getitem_90)
        silu__default_30 = torch.ops.aten.silu_.default(getitem_90);  getitem_90 = None
        mm_default_7 = torch.ops.aten.mm.default(sigmoid_default_12, primals_74)
        view_default_24 = torch.ops.aten.view.default(mm_default_7, [86016, 1, 5, 5]);  mm_default_7 = None
        view_default_25 = torch.ops.aten.view.default(silu__default_30, [1, 86016, 14, 14]);  silu__default_30 = None
        convolution_default_51 = torch.ops.aten.convolution.default(view_default_25, view_default_24, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 86016)
        permute_default_7 = torch.ops.aten.permute.default(convolution_default_51, [1, 0, 2, 3]);  convolution_default_51 = None
        view_default_26 = torch.ops.aten.view.default(permute_default_7, [128, 672, 14, 14]);  permute_default_7 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_288, 1);  primals_288 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(view_default_26, primals_291, primals_292, primals_289, primals_290, True, 0.1, 0.001);  primals_292 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(view_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_31 = torch.ops.aten.clone.default(getitem_93)
        silu__default_31 = torch.ops.aten.silu_.default(getitem_93);  getitem_93 = None
        mean_dim_13 = torch.ops.aten.mean.dim(silu__default_31, [2, 3], True)
        convolution_default_52 = torch.ops.aten.convolution.default(mean_dim_13, primals_82, primals_81, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_81 = None
        clone_default_32 = torch.ops.aten.clone.default(convolution_default_52)
        silu__default_32 = torch.ops.aten.silu_.default(convolution_default_52);  convolution_default_52 = None
        convolution_default_53 = torch.ops.aten.convolution.default(silu__default_32, primals_80, primals_79, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_79 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_53);  convolution_default_53 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(silu__default_31, sigmoid_default_13)
        mm_default_8 = torch.ops.aten.mm.default(sigmoid_default_12, primals_76)
        view_default_27 = torch.ops.aten.view.default(mm_default_8, [14336, 672, 1, 1]);  mm_default_8 = None
        view_default_28 = torch.ops.aten.view.default(mul_tensor_10, [1, 86016, 14, 14]);  mul_tensor_10 = None
        convolution_default_54 = torch.ops.aten.convolution.default(view_default_28, view_default_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_8 = torch.ops.aten.permute.default(convolution_default_54, [1, 0, 2, 3]);  convolution_default_54 = None
        view_default_29 = torch.ops.aten.view.default(permute_default_8, [128, 112, 14, 14]);  permute_default_8 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_293, 1);  primals_293 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(view_default_29, primals_296, primals_297, primals_294, primals_295, True, 0.1, 0.001);  primals_297 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(view_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_38 = torch.ops.aten.add.Tensor(getitem_96, add_tensor_34);  getitem_96 = add_tensor_34 = None
        mean_dim_14 = torch.ops.aten.mean.dim(add_tensor_38, [-1, -2], True)
        view_default_30 = torch.ops.aten.view.default(mean_dim_14, [128, 112]);  mean_dim_14 = None
        t_default_3 = torch.ops.aten.t.default(primals_87);  primals_87 = None
        addmm_default_3 = torch.ops.aten.addmm.default(primals_86, view_default_30, t_default_3);  primals_86 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(addmm_default_3);  addmm_default_3 = None
        mm_default_9 = torch.ops.aten.mm.default(sigmoid_default_14, primals_84)
        view_default_31 = torch.ops.aten.view.default(mm_default_9, [86016, 112, 1, 1]);  mm_default_9 = None
        view_default_32 = torch.ops.aten.view.default(add_tensor_38, [1, 14336, 14, 14]);  add_tensor_38 = None
        convolution_default_55 = torch.ops.aten.convolution.default(view_default_32, view_default_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_9 = torch.ops.aten.permute.default(convolution_default_55, [1, 0, 2, 3]);  convolution_default_55 = None
        view_default_33 = torch.ops.aten.view.default(permute_default_9, [128, 672, 14, 14]);  permute_default_9 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_298, 1);  primals_298 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(view_default_33, primals_301, primals_302, primals_299, primals_300, True, 0.1, 0.001);  primals_302 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(view_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_33 = torch.ops.aten.clone.default(getitem_99)
        silu__default_33 = torch.ops.aten.silu_.default(getitem_99);  getitem_99 = None
        mm_default_10 = torch.ops.aten.mm.default(sigmoid_default_14, primals_83)
        view_default_34 = torch.ops.aten.view.default(mm_default_10, [86016, 1, 5, 5]);  mm_default_10 = None
        view_default_35 = torch.ops.aten.view.default(silu__default_33, [1, 86016, 14, 14]);  silu__default_33 = None
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(view_default_35, [1, 2, 1, 2], 0.0);  view_default_35 = None
        convolution_default_56 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, view_default_34, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 86016)
        permute_default_10 = torch.ops.aten.permute.default(convolution_default_56, [1, 0, 2, 3]);  convolution_default_56 = None
        view_default_36 = torch.ops.aten.view.default(permute_default_10, [128, 672, 7, 7]);  permute_default_10 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_303, 1);  primals_303 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(view_default_36, primals_306, primals_307, primals_304, primals_305, True, 0.1, 0.001);  primals_307 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(view_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_34 = torch.ops.aten.clone.default(getitem_102)
        silu__default_34 = torch.ops.aten.silu_.default(getitem_102);  getitem_102 = None
        mean_dim_15 = torch.ops.aten.mean.dim(silu__default_34, [2, 3], True)
        convolution_default_57 = torch.ops.aten.convolution.default(mean_dim_15, primals_91, primals_90, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_90 = None
        clone_default_35 = torch.ops.aten.clone.default(convolution_default_57)
        silu__default_35 = torch.ops.aten.silu_.default(convolution_default_57);  convolution_default_57 = None
        convolution_default_58 = torch.ops.aten.convolution.default(silu__default_35, primals_89, primals_88, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_88 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_58);  convolution_default_58 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(silu__default_34, sigmoid_default_15)
        mm_default_11 = torch.ops.aten.mm.default(sigmoid_default_14, primals_85)
        view_default_37 = torch.ops.aten.view.default(mm_default_11, [24576, 672, 1, 1]);  mm_default_11 = None
        view_default_38 = torch.ops.aten.view.default(mul_tensor_11, [1, 86016, 7, 7]);  mul_tensor_11 = None
        convolution_default_59 = torch.ops.aten.convolution.default(view_default_38, view_default_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_11 = torch.ops.aten.permute.default(convolution_default_59, [1, 0, 2, 3]);  convolution_default_59 = None
        view_default_39 = torch.ops.aten.view.default(permute_default_11, [128, 192, 7, 7]);  permute_default_11 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_308, 1);  primals_308 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(view_default_39, primals_311, primals_312, primals_309, primals_310, True, 0.1, 0.001);  primals_312 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(view_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        mean_dim_16 = torch.ops.aten.mean.dim(getitem_105, [-1, -2], True)
        view_default_40 = torch.ops.aten.view.default(mean_dim_16, [128, 192]);  mean_dim_16 = None
        t_default_4 = torch.ops.aten.t.default(primals_96);  primals_96 = None
        addmm_default_4 = torch.ops.aten.addmm.default(primals_95, view_default_40, t_default_4);  primals_95 = None
        sigmoid_default_16 = torch.ops.aten.sigmoid.default(addmm_default_4);  addmm_default_4 = None
        mm_default_12 = torch.ops.aten.mm.default(sigmoid_default_16, primals_93)
        view_default_41 = torch.ops.aten.view.default(mm_default_12, [147456, 192, 1, 1]);  mm_default_12 = None
        view_default_42 = torch.ops.aten.view.default(getitem_105, [1, 24576, 7, 7])
        convolution_default_60 = torch.ops.aten.convolution.default(view_default_42, view_default_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_12 = torch.ops.aten.permute.default(convolution_default_60, [1, 0, 2, 3]);  convolution_default_60 = None
        view_default_43 = torch.ops.aten.view.default(permute_default_12, [128, 1152, 7, 7]);  permute_default_12 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(primals_313, 1);  primals_313 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(view_default_43, primals_316, primals_317, primals_314, primals_315, True, 0.1, 0.001);  primals_317 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(view_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_36 = torch.ops.aten.clone.default(getitem_108)
        silu__default_36 = torch.ops.aten.silu_.default(getitem_108);  getitem_108 = None
        mm_default_13 = torch.ops.aten.mm.default(sigmoid_default_16, primals_92)
        view_default_44 = torch.ops.aten.view.default(mm_default_13, [147456, 1, 5, 5]);  mm_default_13 = None
        view_default_45 = torch.ops.aten.view.default(silu__default_36, [1, 147456, 7, 7]);  silu__default_36 = None
        convolution_default_61 = torch.ops.aten.convolution.default(view_default_45, view_default_44, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 147456)
        permute_default_13 = torch.ops.aten.permute.default(convolution_default_61, [1, 0, 2, 3]);  convolution_default_61 = None
        view_default_46 = torch.ops.aten.view.default(permute_default_13, [128, 1152, 7, 7]);  permute_default_13 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_318, 1);  primals_318 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(view_default_46, primals_321, primals_322, primals_319, primals_320, True, 0.1, 0.001);  primals_322 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(view_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_37 = torch.ops.aten.clone.default(getitem_111)
        silu__default_37 = torch.ops.aten.silu_.default(getitem_111);  getitem_111 = None
        mean_dim_17 = torch.ops.aten.mean.dim(silu__default_37, [2, 3], True)
        convolution_default_62 = torch.ops.aten.convolution.default(mean_dim_17, primals_100, primals_99, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_99 = None
        clone_default_38 = torch.ops.aten.clone.default(convolution_default_62)
        silu__default_38 = torch.ops.aten.silu_.default(convolution_default_62);  convolution_default_62 = None
        convolution_default_63 = torch.ops.aten.convolution.default(silu__default_38, primals_98, primals_97, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_97 = None
        sigmoid_default_17 = torch.ops.aten.sigmoid.default(convolution_default_63);  convolution_default_63 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(silu__default_37, sigmoid_default_17)
        mm_default_14 = torch.ops.aten.mm.default(sigmoid_default_16, primals_94)
        view_default_47 = torch.ops.aten.view.default(mm_default_14, [24576, 1152, 1, 1]);  mm_default_14 = None
        view_default_48 = torch.ops.aten.view.default(mul_tensor_12, [1, 147456, 7, 7]);  mul_tensor_12 = None
        convolution_default_64 = torch.ops.aten.convolution.default(view_default_48, view_default_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_14 = torch.ops.aten.permute.default(convolution_default_64, [1, 0, 2, 3]);  convolution_default_64 = None
        view_default_49 = torch.ops.aten.view.default(permute_default_14, [128, 192, 7, 7]);  permute_default_14 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_323, 1);  primals_323 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(view_default_49, primals_326, primals_327, primals_324, primals_325, True, 0.1, 0.001);  primals_327 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(view_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_114, getitem_105);  getitem_114 = getitem_105 = None
        mean_dim_18 = torch.ops.aten.mean.dim(add_tensor_45, [-1, -2], True)
        view_default_50 = torch.ops.aten.view.default(mean_dim_18, [128, 192]);  mean_dim_18 = None
        t_default_5 = torch.ops.aten.t.default(primals_105);  primals_105 = None
        addmm_default_5 = torch.ops.aten.addmm.default(primals_104, view_default_50, t_default_5);  primals_104 = None
        sigmoid_default_18 = torch.ops.aten.sigmoid.default(addmm_default_5);  addmm_default_5 = None
        mm_default_15 = torch.ops.aten.mm.default(sigmoid_default_18, primals_102)
        view_default_51 = torch.ops.aten.view.default(mm_default_15, [147456, 192, 1, 1]);  mm_default_15 = None
        view_default_52 = torch.ops.aten.view.default(add_tensor_45, [1, 24576, 7, 7])
        convolution_default_65 = torch.ops.aten.convolution.default(view_default_52, view_default_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_15 = torch.ops.aten.permute.default(convolution_default_65, [1, 0, 2, 3]);  convolution_default_65 = None
        view_default_53 = torch.ops.aten.view.default(permute_default_15, [128, 1152, 7, 7]);  permute_default_15 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_328, 1);  primals_328 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(view_default_53, primals_331, primals_332, primals_329, primals_330, True, 0.1, 0.001);  primals_332 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(view_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_39 = torch.ops.aten.clone.default(getitem_117)
        silu__default_39 = torch.ops.aten.silu_.default(getitem_117);  getitem_117 = None
        mm_default_16 = torch.ops.aten.mm.default(sigmoid_default_18, primals_101)
        view_default_54 = torch.ops.aten.view.default(mm_default_16, [147456, 1, 5, 5]);  mm_default_16 = None
        view_default_55 = torch.ops.aten.view.default(silu__default_39, [1, 147456, 7, 7]);  silu__default_39 = None
        convolution_default_66 = torch.ops.aten.convolution.default(view_default_55, view_default_54, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 147456)
        permute_default_16 = torch.ops.aten.permute.default(convolution_default_66, [1, 0, 2, 3]);  convolution_default_66 = None
        view_default_56 = torch.ops.aten.view.default(permute_default_16, [128, 1152, 7, 7]);  permute_default_16 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_333, 1);  primals_333 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(view_default_56, primals_336, primals_337, primals_334, primals_335, True, 0.1, 0.001);  primals_337 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(view_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_40 = torch.ops.aten.clone.default(getitem_120)
        silu__default_40 = torch.ops.aten.silu_.default(getitem_120);  getitem_120 = None
        mean_dim_19 = torch.ops.aten.mean.dim(silu__default_40, [2, 3], True)
        convolution_default_67 = torch.ops.aten.convolution.default(mean_dim_19, primals_109, primals_108, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_108 = None
        clone_default_41 = torch.ops.aten.clone.default(convolution_default_67)
        silu__default_41 = torch.ops.aten.silu_.default(convolution_default_67);  convolution_default_67 = None
        convolution_default_68 = torch.ops.aten.convolution.default(silu__default_41, primals_107, primals_106, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_106 = None
        sigmoid_default_19 = torch.ops.aten.sigmoid.default(convolution_default_68);  convolution_default_68 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(silu__default_40, sigmoid_default_19)
        mm_default_17 = torch.ops.aten.mm.default(sigmoid_default_18, primals_103)
        view_default_57 = torch.ops.aten.view.default(mm_default_17, [24576, 1152, 1, 1]);  mm_default_17 = None
        view_default_58 = torch.ops.aten.view.default(mul_tensor_13, [1, 147456, 7, 7]);  mul_tensor_13 = None
        convolution_default_69 = torch.ops.aten.convolution.default(view_default_58, view_default_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_17 = torch.ops.aten.permute.default(convolution_default_69, [1, 0, 2, 3]);  convolution_default_69 = None
        view_default_59 = torch.ops.aten.view.default(permute_default_17, [128, 192, 7, 7]);  permute_default_17 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_338, 1);  primals_338 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(view_default_59, primals_341, primals_342, primals_339, primals_340, True, 0.1, 0.001);  primals_342 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(view_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_49 = torch.ops.aten.add.Tensor(getitem_123, add_tensor_45);  getitem_123 = add_tensor_45 = None
        mean_dim_20 = torch.ops.aten.mean.dim(add_tensor_49, [-1, -2], True)
        view_default_60 = torch.ops.aten.view.default(mean_dim_20, [128, 192]);  mean_dim_20 = None
        t_default_6 = torch.ops.aten.t.default(primals_114);  primals_114 = None
        addmm_default_6 = torch.ops.aten.addmm.default(primals_113, view_default_60, t_default_6);  primals_113 = None
        sigmoid_default_20 = torch.ops.aten.sigmoid.default(addmm_default_6);  addmm_default_6 = None
        mm_default_18 = torch.ops.aten.mm.default(sigmoid_default_20, primals_111)
        view_default_61 = torch.ops.aten.view.default(mm_default_18, [147456, 192, 1, 1]);  mm_default_18 = None
        view_default_62 = torch.ops.aten.view.default(add_tensor_49, [1, 24576, 7, 7])
        convolution_default_70 = torch.ops.aten.convolution.default(view_default_62, view_default_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_18 = torch.ops.aten.permute.default(convolution_default_70, [1, 0, 2, 3]);  convolution_default_70 = None
        view_default_63 = torch.ops.aten.view.default(permute_default_18, [128, 1152, 7, 7]);  permute_default_18 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_343, 1);  primals_343 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(view_default_63, primals_346, primals_347, primals_344, primals_345, True, 0.1, 0.001);  primals_347 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(view_default_63, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_42 = torch.ops.aten.clone.default(getitem_126)
        silu__default_42 = torch.ops.aten.silu_.default(getitem_126);  getitem_126 = None
        mm_default_19 = torch.ops.aten.mm.default(sigmoid_default_20, primals_110)
        view_default_64 = torch.ops.aten.view.default(mm_default_19, [147456, 1, 5, 5]);  mm_default_19 = None
        view_default_65 = torch.ops.aten.view.default(silu__default_42, [1, 147456, 7, 7]);  silu__default_42 = None
        convolution_default_71 = torch.ops.aten.convolution.default(view_default_65, view_default_64, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 147456)
        permute_default_19 = torch.ops.aten.permute.default(convolution_default_71, [1, 0, 2, 3]);  convolution_default_71 = None
        view_default_66 = torch.ops.aten.view.default(permute_default_19, [128, 1152, 7, 7]);  permute_default_19 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_348, 1);  primals_348 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(view_default_66, primals_351, primals_352, primals_349, primals_350, True, 0.1, 0.001);  primals_352 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(view_default_66, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_43 = torch.ops.aten.clone.default(getitem_129)
        silu__default_43 = torch.ops.aten.silu_.default(getitem_129);  getitem_129 = None
        mean_dim_21 = torch.ops.aten.mean.dim(silu__default_43, [2, 3], True)
        convolution_default_72 = torch.ops.aten.convolution.default(mean_dim_21, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        clone_default_44 = torch.ops.aten.clone.default(convolution_default_72)
        silu__default_44 = torch.ops.aten.silu_.default(convolution_default_72);  convolution_default_72 = None
        convolution_default_73 = torch.ops.aten.convolution.default(silu__default_44, primals_116, primals_115, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_115 = None
        sigmoid_default_21 = torch.ops.aten.sigmoid.default(convolution_default_73);  convolution_default_73 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(silu__default_43, sigmoid_default_21)
        mm_default_20 = torch.ops.aten.mm.default(sigmoid_default_20, primals_112)
        view_default_67 = torch.ops.aten.view.default(mm_default_20, [24576, 1152, 1, 1]);  mm_default_20 = None
        view_default_68 = torch.ops.aten.view.default(mul_tensor_14, [1, 147456, 7, 7]);  mul_tensor_14 = None
        convolution_default_74 = torch.ops.aten.convolution.default(view_default_68, view_default_67, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_20 = torch.ops.aten.permute.default(convolution_default_74, [1, 0, 2, 3]);  convolution_default_74 = None
        view_default_69 = torch.ops.aten.view.default(permute_default_20, [128, 192, 7, 7]);  permute_default_20 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_353, 1);  primals_353 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(view_default_69, primals_356, primals_357, primals_354, primals_355, True, 0.1, 0.001);  primals_357 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(view_default_69, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_53 = torch.ops.aten.add.Tensor(getitem_132, add_tensor_49);  getitem_132 = add_tensor_49 = None
        mean_dim_22 = torch.ops.aten.mean.dim(add_tensor_53, [-1, -2], True)
        view_default_70 = torch.ops.aten.view.default(mean_dim_22, [128, 192]);  mean_dim_22 = None
        t_default_7 = torch.ops.aten.t.default(primals_123);  primals_123 = None
        addmm_default_7 = torch.ops.aten.addmm.default(primals_122, view_default_70, t_default_7);  primals_122 = None
        sigmoid_default_22 = torch.ops.aten.sigmoid.default(addmm_default_7);  addmm_default_7 = None
        mm_default_21 = torch.ops.aten.mm.default(sigmoid_default_22, primals_120)
        view_default_71 = torch.ops.aten.view.default(mm_default_21, [147456, 192, 1, 1]);  mm_default_21 = None
        view_default_72 = torch.ops.aten.view.default(add_tensor_53, [1, 24576, 7, 7]);  add_tensor_53 = None
        convolution_default_75 = torch.ops.aten.convolution.default(view_default_72, view_default_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_21 = torch.ops.aten.permute.default(convolution_default_75, [1, 0, 2, 3]);  convolution_default_75 = None
        view_default_73 = torch.ops.aten.view.default(permute_default_21, [128, 1152, 7, 7]);  permute_default_21 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_358, 1);  primals_358 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(view_default_73, primals_361, primals_362, primals_359, primals_360, True, 0.1, 0.001);  primals_362 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(view_default_73, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_45 = torch.ops.aten.clone.default(getitem_135)
        silu__default_45 = torch.ops.aten.silu_.default(getitem_135);  getitem_135 = None
        mm_default_22 = torch.ops.aten.mm.default(sigmoid_default_22, primals_119)
        view_default_74 = torch.ops.aten.view.default(mm_default_22, [147456, 1, 3, 3]);  mm_default_22 = None
        view_default_75 = torch.ops.aten.view.default(silu__default_45, [1, 147456, 7, 7]);  silu__default_45 = None
        convolution_default_76 = torch.ops.aten.convolution.default(view_default_75, view_default_74, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 147456)
        permute_default_22 = torch.ops.aten.permute.default(convolution_default_76, [1, 0, 2, 3]);  convolution_default_76 = None
        view_default_76 = torch.ops.aten.view.default(permute_default_22, [128, 1152, 7, 7]);  permute_default_22 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(primals_363, 1);  primals_363 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(view_default_76, primals_366, primals_367, primals_364, primals_365, True, 0.1, 0.001);  primals_367 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(view_default_76, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_46 = torch.ops.aten.clone.default(getitem_138)
        silu__default_46 = torch.ops.aten.silu_.default(getitem_138);  getitem_138 = None
        mean_dim_23 = torch.ops.aten.mean.dim(silu__default_46, [2, 3], True)
        convolution_default_77 = torch.ops.aten.convolution.default(mean_dim_23, primals_127, primals_126, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_126 = None
        clone_default_47 = torch.ops.aten.clone.default(convolution_default_77)
        silu__default_47 = torch.ops.aten.silu_.default(convolution_default_77);  convolution_default_77 = None
        convolution_default_78 = torch.ops.aten.convolution.default(silu__default_47, primals_125, primals_124, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_124 = None
        sigmoid_default_23 = torch.ops.aten.sigmoid.default(convolution_default_78);  convolution_default_78 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(silu__default_46, sigmoid_default_23)
        mm_default_23 = torch.ops.aten.mm.default(sigmoid_default_22, primals_121)
        view_default_77 = torch.ops.aten.view.default(mm_default_23, [40960, 1152, 1, 1]);  mm_default_23 = None
        view_default_78 = torch.ops.aten.view.default(mul_tensor_15, [1, 147456, 7, 7]);  mul_tensor_15 = None
        convolution_default_79 = torch.ops.aten.convolution.default(view_default_78, view_default_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 128)
        permute_default_23 = torch.ops.aten.permute.default(convolution_default_79, [1, 0, 2, 3]);  convolution_default_79 = None
        view_default_79 = torch.ops.aten.view.default(permute_default_23, [128, 320, 7, 7]);  permute_default_23 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_368, 1);  primals_368 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(view_default_79, primals_371, primals_372, primals_369, primals_370, True, 0.1, 0.001);  primals_372 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(view_default_79, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_80 = torch.ops.aten.convolution.default(getitem_141, primals_130, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_373, 1);  primals_373 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_376, primals_377, primals_374, primals_375, True, 0.1, 0.001);  primals_377 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_80, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_48 = torch.ops.aten.clone.default(getitem_144)
        silu__default_48 = torch.ops.aten.silu_.default(getitem_144);  getitem_144 = None
        mean_dim_24 = torch.ops.aten.mean.dim(silu__default_48, [-1, -2], True);  silu__default_48 = None
        view_default_80 = torch.ops.aten.view.default(mean_dim_24, [128, 1280]);  mean_dim_24 = None
        t_default_8 = torch.ops.aten.t.default(primals_129);  primals_129 = None
        addmm_default_8 = torch.ops.aten.addmm.default(primals_128, view_default_80, t_default_8);  primals_128 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default_8, tangents_1)
        t_default_9 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_24 = torch.ops.aten.mm.default(tangents_1, t_default_9);  t_default_9 = None
        t_default_10 = torch.ops.aten.t.default(tangents_1)
        mm_default_25 = torch.ops.aten.mm.default(t_default_10, view_default_80);  t_default_10 = view_default_80 = None
        t_default_11 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_81 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_12 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        view_default_82 = torch.ops.aten.view.default(mm_default_24, [128, 1280, 1, 1]);  mm_default_24 = None
        expand_default = torch.ops.aten.expand.default(view_default_82, [128, 1280, 7, 7]);  view_default_82 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(clone_default_48, torch.float32);  clone_default_48 = None
        neg_default = torch.ops.aten.neg.default(to_dtype_1)
        exp_default = torch.ops.aten.exp.default(neg_default);  neg_default = None
        add_tensor_58 = torch.ops.aten.add.Tensor(exp_default, 1);  exp_default = None
        reciprocal_default = torch.ops.aten.reciprocal.default(add_tensor_58);  add_tensor_58 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(reciprocal_default, 1);  reciprocal_default = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype, mul_tensor_16);  to_dtype = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(mul_tensor_16, 1);  mul_tensor_16 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype_1, rsub_scalar);  to_dtype_1 = rsub_scalar = None
        add_tensor_59 = torch.ops.aten.add.Tensor(mul_tensor_18, 1);  mul_tensor_18 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(mul_tensor_17, add_tensor_59);  mul_tensor_17 = add_tensor_59 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_19, torch.float32);  mul_tensor_19 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_80, primals_376, primals_374, primals_375, getitem_145, getitem_146, True, 0.001, [True, True, True]);  to_dtype_2 = convolution_default_80 = primals_376 = primals_374 = primals_375 = getitem_145 = getitem_146 = None
        getitem_147 = native_batch_norm_backward_default[0]
        getitem_148 = native_batch_norm_backward_default[1]
        getitem_149 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_147, getitem_141, primals_130, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_147 = getitem_141 = primals_130 = None
        getitem_150 = convolution_backward_default[0]
        getitem_151 = convolution_backward_default[1]
        getitem_152 = convolution_backward_default[2];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_150, view_default_79, primals_371, primals_369, primals_370, getitem_142, getitem_143, True, 0.001, [True, True, True]);  getitem_150 = view_default_79 = primals_371 = primals_369 = primals_370 = getitem_142 = getitem_143 = None
        getitem_153 = native_batch_norm_backward_default_1[0]
        getitem_154 = native_batch_norm_backward_default_1[1]
        getitem_155 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        view_default_83 = torch.ops.aten.view.default(getitem_153, [40960, 1, 7, 7]);  getitem_153 = None
        permute_default_24 = torch.ops.aten.permute.default(view_default_83, [1, 0, 2, 3]);  view_default_83 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(permute_default_24, view_default_78, view_default_77, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_24 = view_default_78 = view_default_77 = None
        getitem_156 = convolution_backward_default_1[0]
        getitem_157 = convolution_backward_default_1[1]
        getitem_158 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        view_default_84 = torch.ops.aten.view.default(getitem_156, [128, 1152, 7, 7]);  getitem_156 = None
        view_default_85 = torch.ops.aten.view.default(getitem_157, [128, 368640]);  getitem_157 = None
        t_default_13 = torch.ops.aten.t.default(sigmoid_default_22)
        mm_default_26 = torch.ops.aten.mm.default(t_default_13, view_default_85);  t_default_13 = None
        t_default_14 = torch.ops.aten.t.default(primals_121);  primals_121 = None
        mm_default_27 = torch.ops.aten.mm.default(view_default_85, t_default_14);  view_default_85 = t_default_14 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(view_default_84, silu__default_46);  silu__default_46 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(view_default_84, sigmoid_default_23);  view_default_84 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_20, [2, 3], True);  mul_tensor_20 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_23, torch.float32);  sigmoid_default_23 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar_1);  to_dtype_4 = rsub_scalar_1 = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_22);  mul_tensor_22 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_23, torch.float32);  mul_tensor_23 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(to_dtype_5, silu__default_47, primals_125, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = silu__default_47 = primals_125 = None
        getitem_159 = convolution_backward_default_2[0]
        getitem_160 = convolution_backward_default_2[1]
        getitem_161 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_159, torch.float32);  getitem_159 = None
        to_dtype_7 = torch.ops.aten.to.dtype(clone_default_47, torch.float32);  clone_default_47 = None
        neg_default_1 = torch.ops.aten.neg.default(to_dtype_7)
        exp_default_1 = torch.ops.aten.exp.default(neg_default_1);  neg_default_1 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(exp_default_1, 1);  exp_default_1 = None
        reciprocal_default_1 = torch.ops.aten.reciprocal.default(add_tensor_60);  add_tensor_60 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(reciprocal_default_1, 1);  reciprocal_default_1 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_6, mul_tensor_24);  to_dtype_6 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(mul_tensor_24, 1);  mul_tensor_24 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_7, rsub_scalar_2);  to_dtype_7 = rsub_scalar_2 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(mul_tensor_26, 1);  mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(mul_tensor_25, add_tensor_61);  mul_tensor_25 = add_tensor_61 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_27, torch.float32);  mul_tensor_27 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_23, primals_127, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_23 = primals_127 = None
        getitem_162 = convolution_backward_default_3[0]
        getitem_163 = convolution_backward_default_3[1]
        getitem_164 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_162, [128, 1152, 7, 7]);  getitem_162 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(mul_tensor_21, div_scalar_1);  mul_tensor_21 = div_scalar_1 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_10 = torch.ops.aten.to.dtype(clone_default_46, torch.float32);  clone_default_46 = None
        neg_default_2 = torch.ops.aten.neg.default(to_dtype_10)
        exp_default_2 = torch.ops.aten.exp.default(neg_default_2);  neg_default_2 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(exp_default_2, 1);  exp_default_2 = None
        reciprocal_default_2 = torch.ops.aten.reciprocal.default(add_tensor_63);  add_tensor_63 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(reciprocal_default_2, 1);  reciprocal_default_2 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_9, mul_tensor_28);  to_dtype_9 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(mul_tensor_28, 1);  mul_tensor_28 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_10, rsub_scalar_3);  to_dtype_10 = rsub_scalar_3 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(mul_tensor_30, 1);  mul_tensor_30 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_29, add_tensor_64);  mul_tensor_29 = add_tensor_64 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_31, torch.float32);  mul_tensor_31 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, view_default_76, primals_366, primals_364, primals_365, getitem_139, getitem_140, True, 0.001, [True, True, True]);  to_dtype_11 = view_default_76 = primals_366 = primals_364 = primals_365 = getitem_139 = getitem_140 = None
        getitem_165 = native_batch_norm_backward_default_2[0]
        getitem_166 = native_batch_norm_backward_default_2[1]
        getitem_167 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        view_default_86 = torch.ops.aten.view.default(getitem_165, [147456, 1, 7, 7]);  getitem_165 = None
        permute_default_25 = torch.ops.aten.permute.default(view_default_86, [1, 0, 2, 3]);  view_default_86 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(permute_default_25, view_default_75, view_default_74, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 147456, [True, True, False]);  permute_default_25 = view_default_75 = view_default_74 = None
        getitem_168 = convolution_backward_default_4[0]
        getitem_169 = convolution_backward_default_4[1]
        getitem_170 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        view_default_87 = torch.ops.aten.view.default(getitem_168, [128, 1152, 7, 7]);  getitem_168 = None
        view_default_88 = torch.ops.aten.view.default(getitem_169, [128, 10368]);  getitem_169 = None
        t_default_15 = torch.ops.aten.t.default(sigmoid_default_22)
        mm_default_28 = torch.ops.aten.mm.default(t_default_15, view_default_88);  t_default_15 = None
        t_default_16 = torch.ops.aten.t.default(primals_119);  primals_119 = None
        mm_default_29 = torch.ops.aten.mm.default(view_default_88, t_default_16);  view_default_88 = t_default_16 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(mm_default_27, mm_default_29);  mm_default_27 = mm_default_29 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_87, torch.float32);  view_default_87 = None
        to_dtype_13 = torch.ops.aten.to.dtype(clone_default_45, torch.float32);  clone_default_45 = None
        neg_default_3 = torch.ops.aten.neg.default(to_dtype_13)
        exp_default_3 = torch.ops.aten.exp.default(neg_default_3);  neg_default_3 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(exp_default_3, 1);  exp_default_3 = None
        reciprocal_default_3 = torch.ops.aten.reciprocal.default(add_tensor_66);  add_tensor_66 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(reciprocal_default_3, 1);  reciprocal_default_3 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_12, mul_tensor_32);  to_dtype_12 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(mul_tensor_32, 1);  mul_tensor_32 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_13, rsub_scalar_4);  to_dtype_13 = rsub_scalar_4 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(mul_tensor_34, 1);  mul_tensor_34 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(mul_tensor_33, add_tensor_67);  mul_tensor_33 = add_tensor_67 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_35, torch.float32);  mul_tensor_35 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, view_default_73, primals_361, primals_359, primals_360, getitem_136, getitem_137, True, 0.001, [True, True, True]);  to_dtype_14 = view_default_73 = primals_361 = primals_359 = primals_360 = getitem_136 = getitem_137 = None
        getitem_171 = native_batch_norm_backward_default_3[0]
        getitem_172 = native_batch_norm_backward_default_3[1]
        getitem_173 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        view_default_89 = torch.ops.aten.view.default(getitem_171, [147456, 1, 7, 7]);  getitem_171 = None
        permute_default_26 = torch.ops.aten.permute.default(view_default_89, [1, 0, 2, 3]);  view_default_89 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(permute_default_26, view_default_72, view_default_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_26 = view_default_72 = view_default_71 = None
        getitem_174 = convolution_backward_default_5[0]
        getitem_175 = convolution_backward_default_5[1]
        getitem_176 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        view_default_90 = torch.ops.aten.view.default(getitem_174, [128, 192, 7, 7]);  getitem_174 = None
        view_default_91 = torch.ops.aten.view.default(getitem_175, [128, 221184]);  getitem_175 = None
        t_default_17 = torch.ops.aten.t.default(sigmoid_default_22)
        mm_default_30 = torch.ops.aten.mm.default(t_default_17, view_default_91);  t_default_17 = None
        t_default_18 = torch.ops.aten.t.default(primals_120);  primals_120 = None
        mm_default_31 = torch.ops.aten.mm.default(view_default_91, t_default_18);  view_default_91 = t_default_18 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(add_tensor_65, mm_default_31);  add_tensor_65 = mm_default_31 = None
        to_dtype_15 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_16 = torch.ops.aten.to.dtype(sigmoid_default_22, torch.float32);  sigmoid_default_22 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(to_dtype_16, 1)
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_16, rsub_scalar_5);  to_dtype_16 = rsub_scalar_5 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_36);  mul_tensor_36 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_15, conj_physical_default_1);  to_dtype_15 = conj_physical_default_1 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_37, torch.float32);  mul_tensor_37 = None
        t_default_19 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_32 = torch.ops.aten.mm.default(to_dtype_17, t_default_19);  t_default_19 = None
        t_default_20 = torch.ops.aten.t.default(to_dtype_17)
        mm_default_33 = torch.ops.aten.mm.default(t_default_20, view_default_70);  t_default_20 = view_default_70 = None
        t_default_21 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(to_dtype_17, [0], True);  to_dtype_17 = None
        view_default_92 = torch.ops.aten.view.default(sum_dim_int_list_2, [4]);  sum_dim_int_list_2 = None
        t_default_22 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        view_default_93 = torch.ops.aten.view.default(mm_default_32, [128, 192, 1, 1]);  mm_default_32 = None
        expand_default_2 = torch.ops.aten.expand.default(view_default_93, [128, 192, 7, 7]);  view_default_93 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(view_default_90, div_scalar_2);  view_default_90 = div_scalar_2 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_69, view_default_69, primals_356, primals_354, primals_355, getitem_133, getitem_134, True, 0.001, [True, True, True]);  view_default_69 = primals_356 = primals_354 = primals_355 = getitem_133 = getitem_134 = None
        getitem_177 = native_batch_norm_backward_default_4[0]
        getitem_178 = native_batch_norm_backward_default_4[1]
        getitem_179 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        view_default_94 = torch.ops.aten.view.default(getitem_177, [24576, 1, 7, 7]);  getitem_177 = None
        permute_default_27 = torch.ops.aten.permute.default(view_default_94, [1, 0, 2, 3]);  view_default_94 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(permute_default_27, view_default_68, view_default_67, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_27 = view_default_68 = view_default_67 = None
        getitem_180 = convolution_backward_default_6[0]
        getitem_181 = convolution_backward_default_6[1]
        getitem_182 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        view_default_95 = torch.ops.aten.view.default(getitem_180, [128, 1152, 7, 7]);  getitem_180 = None
        view_default_96 = torch.ops.aten.view.default(getitem_181, [128, 221184]);  getitem_181 = None
        t_default_23 = torch.ops.aten.t.default(sigmoid_default_20)
        mm_default_34 = torch.ops.aten.mm.default(t_default_23, view_default_96);  t_default_23 = None
        t_default_24 = torch.ops.aten.t.default(primals_112);  primals_112 = None
        mm_default_35 = torch.ops.aten.mm.default(view_default_96, t_default_24);  view_default_96 = t_default_24 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(view_default_95, silu__default_43);  silu__default_43 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(view_default_95, sigmoid_default_21);  view_default_95 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_38, [2, 3], True);  mul_tensor_38 = None
        to_dtype_18 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_19 = torch.ops.aten.to.dtype(sigmoid_default_21, torch.float32);  sigmoid_default_21 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(to_dtype_19, 1)
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_6);  to_dtype_19 = rsub_scalar_6 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_40);  mul_tensor_40 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_18, conj_physical_default_2);  to_dtype_18 = conj_physical_default_2 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_41, torch.float32);  mul_tensor_41 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(to_dtype_20, silu__default_44, primals_116, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = silu__default_44 = primals_116 = None
        getitem_183 = convolution_backward_default_7[0]
        getitem_184 = convolution_backward_default_7[1]
        getitem_185 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_183, torch.float32);  getitem_183 = None
        to_dtype_22 = torch.ops.aten.to.dtype(clone_default_44, torch.float32);  clone_default_44 = None
        neg_default_4 = torch.ops.aten.neg.default(to_dtype_22)
        exp_default_4 = torch.ops.aten.exp.default(neg_default_4);  neg_default_4 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(exp_default_4, 1);  exp_default_4 = None
        reciprocal_default_4 = torch.ops.aten.reciprocal.default(add_tensor_70);  add_tensor_70 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(reciprocal_default_4, 1);  reciprocal_default_4 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(to_dtype_21, mul_tensor_42);  to_dtype_21 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(mul_tensor_42, 1);  mul_tensor_42 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_22, rsub_scalar_7);  to_dtype_22 = rsub_scalar_7 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(mul_tensor_44, 1);  mul_tensor_44 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(mul_tensor_43, add_tensor_71);  mul_tensor_43 = add_tensor_71 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_45, torch.float32);  mul_tensor_45 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_23, mean_dim_21, primals_118, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_23 = mean_dim_21 = primals_118 = None
        getitem_186 = convolution_backward_default_8[0]
        getitem_187 = convolution_backward_default_8[1]
        getitem_188 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_186, [128, 1152, 7, 7]);  getitem_186 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 49);  expand_default_3 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(mul_tensor_39, div_scalar_3);  mul_tensor_39 = div_scalar_3 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_72, torch.float32);  add_tensor_72 = None
        to_dtype_25 = torch.ops.aten.to.dtype(clone_default_43, torch.float32);  clone_default_43 = None
        neg_default_5 = torch.ops.aten.neg.default(to_dtype_25)
        exp_default_5 = torch.ops.aten.exp.default(neg_default_5);  neg_default_5 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(exp_default_5, 1);  exp_default_5 = None
        reciprocal_default_5 = torch.ops.aten.reciprocal.default(add_tensor_73);  add_tensor_73 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(reciprocal_default_5, 1);  reciprocal_default_5 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(to_dtype_24, mul_tensor_46);  to_dtype_24 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(mul_tensor_46, 1);  mul_tensor_46 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_25, rsub_scalar_8);  to_dtype_25 = rsub_scalar_8 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(mul_tensor_48, 1);  mul_tensor_48 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(mul_tensor_47, add_tensor_74);  mul_tensor_47 = add_tensor_74 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_49, torch.float32);  mul_tensor_49 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, view_default_66, primals_351, primals_349, primals_350, getitem_130, getitem_131, True, 0.001, [True, True, True]);  to_dtype_26 = view_default_66 = primals_351 = primals_349 = primals_350 = getitem_130 = getitem_131 = None
        getitem_189 = native_batch_norm_backward_default_5[0]
        getitem_190 = native_batch_norm_backward_default_5[1]
        getitem_191 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        view_default_97 = torch.ops.aten.view.default(getitem_189, [147456, 1, 7, 7]);  getitem_189 = None
        permute_default_28 = torch.ops.aten.permute.default(view_default_97, [1, 0, 2, 3]);  view_default_97 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(permute_default_28, view_default_65, view_default_64, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 147456, [True, True, False]);  permute_default_28 = view_default_65 = view_default_64 = None
        getitem_192 = convolution_backward_default_9[0]
        getitem_193 = convolution_backward_default_9[1]
        getitem_194 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        view_default_98 = torch.ops.aten.view.default(getitem_192, [128, 1152, 7, 7]);  getitem_192 = None
        view_default_99 = torch.ops.aten.view.default(getitem_193, [128, 28800]);  getitem_193 = None
        t_default_25 = torch.ops.aten.t.default(sigmoid_default_20)
        mm_default_36 = torch.ops.aten.mm.default(t_default_25, view_default_99);  t_default_25 = None
        t_default_26 = torch.ops.aten.t.default(primals_110);  primals_110 = None
        mm_default_37 = torch.ops.aten.mm.default(view_default_99, t_default_26);  view_default_99 = t_default_26 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(mm_default_35, mm_default_37);  mm_default_35 = mm_default_37 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_98, torch.float32);  view_default_98 = None
        to_dtype_28 = torch.ops.aten.to.dtype(clone_default_42, torch.float32);  clone_default_42 = None
        neg_default_6 = torch.ops.aten.neg.default(to_dtype_28)
        exp_default_6 = torch.ops.aten.exp.default(neg_default_6);  neg_default_6 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(exp_default_6, 1);  exp_default_6 = None
        reciprocal_default_6 = torch.ops.aten.reciprocal.default(add_tensor_76);  add_tensor_76 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(reciprocal_default_6, 1);  reciprocal_default_6 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_27, mul_tensor_50);  to_dtype_27 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(mul_tensor_50, 1);  mul_tensor_50 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_28, rsub_scalar_9);  to_dtype_28 = rsub_scalar_9 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(mul_tensor_52, 1);  mul_tensor_52 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(mul_tensor_51, add_tensor_77);  mul_tensor_51 = add_tensor_77 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_53, torch.float32);  mul_tensor_53 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, view_default_63, primals_346, primals_344, primals_345, getitem_127, getitem_128, True, 0.001, [True, True, True]);  to_dtype_29 = view_default_63 = primals_346 = primals_344 = primals_345 = getitem_127 = getitem_128 = None
        getitem_195 = native_batch_norm_backward_default_6[0]
        getitem_196 = native_batch_norm_backward_default_6[1]
        getitem_197 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        view_default_100 = torch.ops.aten.view.default(getitem_195, [147456, 1, 7, 7]);  getitem_195 = None
        permute_default_29 = torch.ops.aten.permute.default(view_default_100, [1, 0, 2, 3]);  view_default_100 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(permute_default_29, view_default_62, view_default_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_29 = view_default_62 = view_default_61 = None
        getitem_198 = convolution_backward_default_10[0]
        getitem_199 = convolution_backward_default_10[1]
        getitem_200 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        view_default_101 = torch.ops.aten.view.default(getitem_198, [128, 192, 7, 7]);  getitem_198 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(add_tensor_69, view_default_101);  add_tensor_69 = view_default_101 = None
        view_default_102 = torch.ops.aten.view.default(getitem_199, [128, 221184]);  getitem_199 = None
        t_default_27 = torch.ops.aten.t.default(sigmoid_default_20)
        mm_default_38 = torch.ops.aten.mm.default(t_default_27, view_default_102);  t_default_27 = None
        t_default_28 = torch.ops.aten.t.default(primals_111);  primals_111 = None
        mm_default_39 = torch.ops.aten.mm.default(view_default_102, t_default_28);  view_default_102 = t_default_28 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(add_tensor_75, mm_default_39);  add_tensor_75 = mm_default_39 = None
        to_dtype_30 = torch.ops.aten.to.dtype(add_tensor_79, torch.float32);  add_tensor_79 = None
        to_dtype_31 = torch.ops.aten.to.dtype(sigmoid_default_20, torch.float32);  sigmoid_default_20 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(to_dtype_31, 1)
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_31, rsub_scalar_10);  to_dtype_31 = rsub_scalar_10 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_54);  mul_tensor_54 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(to_dtype_30, conj_physical_default_3);  to_dtype_30 = conj_physical_default_3 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_55, torch.float32);  mul_tensor_55 = None
        t_default_29 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_40 = torch.ops.aten.mm.default(to_dtype_32, t_default_29);  t_default_29 = None
        t_default_30 = torch.ops.aten.t.default(to_dtype_32)
        mm_default_41 = torch.ops.aten.mm.default(t_default_30, view_default_60);  t_default_30 = view_default_60 = None
        t_default_31 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(to_dtype_32, [0], True);  to_dtype_32 = None
        view_default_103 = torch.ops.aten.view.default(sum_dim_int_list_4, [4]);  sum_dim_int_list_4 = None
        t_default_32 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        view_default_104 = torch.ops.aten.view.default(mm_default_40, [128, 192, 1, 1]);  mm_default_40 = None
        expand_default_4 = torch.ops.aten.expand.default(view_default_104, [128, 192, 7, 7]);  view_default_104 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 49);  expand_default_4 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(add_tensor_78, div_scalar_4);  add_tensor_78 = div_scalar_4 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_80, view_default_59, primals_341, primals_339, primals_340, getitem_124, getitem_125, True, 0.001, [True, True, True]);  view_default_59 = primals_341 = primals_339 = primals_340 = getitem_124 = getitem_125 = None
        getitem_201 = native_batch_norm_backward_default_7[0]
        getitem_202 = native_batch_norm_backward_default_7[1]
        getitem_203 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        view_default_105 = torch.ops.aten.view.default(getitem_201, [24576, 1, 7, 7]);  getitem_201 = None
        permute_default_30 = torch.ops.aten.permute.default(view_default_105, [1, 0, 2, 3]);  view_default_105 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(permute_default_30, view_default_58, view_default_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_30 = view_default_58 = view_default_57 = None
        getitem_204 = convolution_backward_default_11[0]
        getitem_205 = convolution_backward_default_11[1]
        getitem_206 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        view_default_106 = torch.ops.aten.view.default(getitem_204, [128, 1152, 7, 7]);  getitem_204 = None
        view_default_107 = torch.ops.aten.view.default(getitem_205, [128, 221184]);  getitem_205 = None
        t_default_33 = torch.ops.aten.t.default(sigmoid_default_18)
        mm_default_42 = torch.ops.aten.mm.default(t_default_33, view_default_107);  t_default_33 = None
        t_default_34 = torch.ops.aten.t.default(primals_103);  primals_103 = None
        mm_default_43 = torch.ops.aten.mm.default(view_default_107, t_default_34);  view_default_107 = t_default_34 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(view_default_106, silu__default_40);  silu__default_40 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(view_default_106, sigmoid_default_19);  view_default_106 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_56, [2, 3], True);  mul_tensor_56 = None
        to_dtype_33 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_34 = torch.ops.aten.to.dtype(sigmoid_default_19, torch.float32);  sigmoid_default_19 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(to_dtype_34, 1)
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_11);  to_dtype_34 = rsub_scalar_11 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_58);  mul_tensor_58 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(to_dtype_33, conj_physical_default_4);  to_dtype_33 = conj_physical_default_4 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_59, torch.float32);  mul_tensor_59 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_35, silu__default_41, primals_107, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_35 = silu__default_41 = primals_107 = None
        getitem_207 = convolution_backward_default_12[0]
        getitem_208 = convolution_backward_default_12[1]
        getitem_209 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_207, torch.float32);  getitem_207 = None
        to_dtype_37 = torch.ops.aten.to.dtype(clone_default_41, torch.float32);  clone_default_41 = None
        neg_default_7 = torch.ops.aten.neg.default(to_dtype_37)
        exp_default_7 = torch.ops.aten.exp.default(neg_default_7);  neg_default_7 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(exp_default_7, 1);  exp_default_7 = None
        reciprocal_default_7 = torch.ops.aten.reciprocal.default(add_tensor_81);  add_tensor_81 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(reciprocal_default_7, 1);  reciprocal_default_7 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_36, mul_tensor_60);  to_dtype_36 = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(mul_tensor_60, 1);  mul_tensor_60 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_37, rsub_scalar_12);  to_dtype_37 = rsub_scalar_12 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(mul_tensor_62, 1);  mul_tensor_62 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(mul_tensor_61, add_tensor_82);  mul_tensor_61 = add_tensor_82 = None
        to_dtype_38 = torch.ops.aten.to.dtype(mul_tensor_63, torch.float32);  mul_tensor_63 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_38, mean_dim_19, primals_109, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_38 = mean_dim_19 = primals_109 = None
        getitem_210 = convolution_backward_default_13[0]
        getitem_211 = convolution_backward_default_13[1]
        getitem_212 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_210, [128, 1152, 7, 7]);  getitem_210 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 49);  expand_default_5 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(mul_tensor_57, div_scalar_5);  mul_tensor_57 = div_scalar_5 = None
        to_dtype_39 = torch.ops.aten.to.dtype(add_tensor_83, torch.float32);  add_tensor_83 = None
        to_dtype_40 = torch.ops.aten.to.dtype(clone_default_40, torch.float32);  clone_default_40 = None
        neg_default_8 = torch.ops.aten.neg.default(to_dtype_40)
        exp_default_8 = torch.ops.aten.exp.default(neg_default_8);  neg_default_8 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(exp_default_8, 1);  exp_default_8 = None
        reciprocal_default_8 = torch.ops.aten.reciprocal.default(add_tensor_84);  add_tensor_84 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(reciprocal_default_8, 1);  reciprocal_default_8 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_39, mul_tensor_64);  to_dtype_39 = None
        rsub_scalar_13 = torch.ops.aten.rsub.Scalar(mul_tensor_64, 1);  mul_tensor_64 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_40, rsub_scalar_13);  to_dtype_40 = rsub_scalar_13 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(mul_tensor_66, 1);  mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(mul_tensor_65, add_tensor_85);  mul_tensor_65 = add_tensor_85 = None
        to_dtype_41 = torch.ops.aten.to.dtype(mul_tensor_67, torch.float32);  mul_tensor_67 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, view_default_56, primals_336, primals_334, primals_335, getitem_121, getitem_122, True, 0.001, [True, True, True]);  to_dtype_41 = view_default_56 = primals_336 = primals_334 = primals_335 = getitem_121 = getitem_122 = None
        getitem_213 = native_batch_norm_backward_default_8[0]
        getitem_214 = native_batch_norm_backward_default_8[1]
        getitem_215 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        view_default_108 = torch.ops.aten.view.default(getitem_213, [147456, 1, 7, 7]);  getitem_213 = None
        permute_default_31 = torch.ops.aten.permute.default(view_default_108, [1, 0, 2, 3]);  view_default_108 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(permute_default_31, view_default_55, view_default_54, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 147456, [True, True, False]);  permute_default_31 = view_default_55 = view_default_54 = None
        getitem_216 = convolution_backward_default_14[0]
        getitem_217 = convolution_backward_default_14[1]
        getitem_218 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        view_default_109 = torch.ops.aten.view.default(getitem_216, [128, 1152, 7, 7]);  getitem_216 = None
        view_default_110 = torch.ops.aten.view.default(getitem_217, [128, 28800]);  getitem_217 = None
        t_default_35 = torch.ops.aten.t.default(sigmoid_default_18)
        mm_default_44 = torch.ops.aten.mm.default(t_default_35, view_default_110);  t_default_35 = None
        t_default_36 = torch.ops.aten.t.default(primals_101);  primals_101 = None
        mm_default_45 = torch.ops.aten.mm.default(view_default_110, t_default_36);  view_default_110 = t_default_36 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(mm_default_43, mm_default_45);  mm_default_43 = mm_default_45 = None
        to_dtype_42 = torch.ops.aten.to.dtype(view_default_109, torch.float32);  view_default_109 = None
        to_dtype_43 = torch.ops.aten.to.dtype(clone_default_39, torch.float32);  clone_default_39 = None
        neg_default_9 = torch.ops.aten.neg.default(to_dtype_43)
        exp_default_9 = torch.ops.aten.exp.default(neg_default_9);  neg_default_9 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(exp_default_9, 1);  exp_default_9 = None
        reciprocal_default_9 = torch.ops.aten.reciprocal.default(add_tensor_87);  add_tensor_87 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(reciprocal_default_9, 1);  reciprocal_default_9 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_42, mul_tensor_68);  to_dtype_42 = None
        rsub_scalar_14 = torch.ops.aten.rsub.Scalar(mul_tensor_68, 1);  mul_tensor_68 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_43, rsub_scalar_14);  to_dtype_43 = rsub_scalar_14 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(mul_tensor_70, 1);  mul_tensor_70 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mul_tensor_69, add_tensor_88);  mul_tensor_69 = add_tensor_88 = None
        to_dtype_44 = torch.ops.aten.to.dtype(mul_tensor_71, torch.float32);  mul_tensor_71 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, view_default_53, primals_331, primals_329, primals_330, getitem_118, getitem_119, True, 0.001, [True, True, True]);  to_dtype_44 = view_default_53 = primals_331 = primals_329 = primals_330 = getitem_118 = getitem_119 = None
        getitem_219 = native_batch_norm_backward_default_9[0]
        getitem_220 = native_batch_norm_backward_default_9[1]
        getitem_221 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        view_default_111 = torch.ops.aten.view.default(getitem_219, [147456, 1, 7, 7]);  getitem_219 = None
        permute_default_32 = torch.ops.aten.permute.default(view_default_111, [1, 0, 2, 3]);  view_default_111 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(permute_default_32, view_default_52, view_default_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_32 = view_default_52 = view_default_51 = None
        getitem_222 = convolution_backward_default_15[0]
        getitem_223 = convolution_backward_default_15[1]
        getitem_224 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        view_default_112 = torch.ops.aten.view.default(getitem_222, [128, 192, 7, 7]);  getitem_222 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(add_tensor_80, view_default_112);  add_tensor_80 = view_default_112 = None
        view_default_113 = torch.ops.aten.view.default(getitem_223, [128, 221184]);  getitem_223 = None
        t_default_37 = torch.ops.aten.t.default(sigmoid_default_18)
        mm_default_46 = torch.ops.aten.mm.default(t_default_37, view_default_113);  t_default_37 = None
        t_default_38 = torch.ops.aten.t.default(primals_102);  primals_102 = None
        mm_default_47 = torch.ops.aten.mm.default(view_default_113, t_default_38);  view_default_113 = t_default_38 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(add_tensor_86, mm_default_47);  add_tensor_86 = mm_default_47 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_90, torch.float32);  add_tensor_90 = None
        to_dtype_46 = torch.ops.aten.to.dtype(sigmoid_default_18, torch.float32);  sigmoid_default_18 = None
        rsub_scalar_15 = torch.ops.aten.rsub.Scalar(to_dtype_46, 1)
        mul_tensor_72 = torch.ops.aten.mul.Tensor(to_dtype_46, rsub_scalar_15);  to_dtype_46 = rsub_scalar_15 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_72);  mul_tensor_72 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_45, conj_physical_default_5);  to_dtype_45 = conj_physical_default_5 = None
        to_dtype_47 = torch.ops.aten.to.dtype(mul_tensor_73, torch.float32);  mul_tensor_73 = None
        t_default_39 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_48 = torch.ops.aten.mm.default(to_dtype_47, t_default_39);  t_default_39 = None
        t_default_40 = torch.ops.aten.t.default(to_dtype_47)
        mm_default_49 = torch.ops.aten.mm.default(t_default_40, view_default_50);  t_default_40 = view_default_50 = None
        t_default_41 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(to_dtype_47, [0], True);  to_dtype_47 = None
        view_default_114 = torch.ops.aten.view.default(sum_dim_int_list_6, [4]);  sum_dim_int_list_6 = None
        t_default_42 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        view_default_115 = torch.ops.aten.view.default(mm_default_48, [128, 192, 1, 1]);  mm_default_48 = None
        expand_default_6 = torch.ops.aten.expand.default(view_default_115, [128, 192, 7, 7]);  view_default_115 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 49);  expand_default_6 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(add_tensor_89, div_scalar_6);  add_tensor_89 = div_scalar_6 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_91, view_default_49, primals_326, primals_324, primals_325, getitem_115, getitem_116, True, 0.001, [True, True, True]);  view_default_49 = primals_326 = primals_324 = primals_325 = getitem_115 = getitem_116 = None
        getitem_225 = native_batch_norm_backward_default_10[0]
        getitem_226 = native_batch_norm_backward_default_10[1]
        getitem_227 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        view_default_116 = torch.ops.aten.view.default(getitem_225, [24576, 1, 7, 7]);  getitem_225 = None
        permute_default_33 = torch.ops.aten.permute.default(view_default_116, [1, 0, 2, 3]);  view_default_116 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(permute_default_33, view_default_48, view_default_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_33 = view_default_48 = view_default_47 = None
        getitem_228 = convolution_backward_default_16[0]
        getitem_229 = convolution_backward_default_16[1]
        getitem_230 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        view_default_117 = torch.ops.aten.view.default(getitem_228, [128, 1152, 7, 7]);  getitem_228 = None
        view_default_118 = torch.ops.aten.view.default(getitem_229, [128, 221184]);  getitem_229 = None
        t_default_43 = torch.ops.aten.t.default(sigmoid_default_16)
        mm_default_50 = torch.ops.aten.mm.default(t_default_43, view_default_118);  t_default_43 = None
        t_default_44 = torch.ops.aten.t.default(primals_94);  primals_94 = None
        mm_default_51 = torch.ops.aten.mm.default(view_default_118, t_default_44);  view_default_118 = t_default_44 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(view_default_117, silu__default_37);  silu__default_37 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(view_default_117, sigmoid_default_17);  view_default_117 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_74, [2, 3], True);  mul_tensor_74 = None
        to_dtype_48 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_49 = torch.ops.aten.to.dtype(sigmoid_default_17, torch.float32);  sigmoid_default_17 = None
        rsub_scalar_16 = torch.ops.aten.rsub.Scalar(to_dtype_49, 1)
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_16);  to_dtype_49 = rsub_scalar_16 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_76);  mul_tensor_76 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_48, conj_physical_default_6);  to_dtype_48 = conj_physical_default_6 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_77, torch.float32);  mul_tensor_77 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(to_dtype_50, silu__default_38, primals_98, [1152], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_50 = silu__default_38 = primals_98 = None
        getitem_231 = convolution_backward_default_17[0]
        getitem_232 = convolution_backward_default_17[1]
        getitem_233 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_231, torch.float32);  getitem_231 = None
        to_dtype_52 = torch.ops.aten.to.dtype(clone_default_38, torch.float32);  clone_default_38 = None
        neg_default_10 = torch.ops.aten.neg.default(to_dtype_52)
        exp_default_10 = torch.ops.aten.exp.default(neg_default_10);  neg_default_10 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(exp_default_10, 1);  exp_default_10 = None
        reciprocal_default_10 = torch.ops.aten.reciprocal.default(add_tensor_92);  add_tensor_92 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(reciprocal_default_10, 1);  reciprocal_default_10 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(to_dtype_51, mul_tensor_78);  to_dtype_51 = None
        rsub_scalar_17 = torch.ops.aten.rsub.Scalar(mul_tensor_78, 1);  mul_tensor_78 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(to_dtype_52, rsub_scalar_17);  to_dtype_52 = rsub_scalar_17 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(mul_tensor_80, 1);  mul_tensor_80 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(mul_tensor_79, add_tensor_93);  mul_tensor_79 = add_tensor_93 = None
        to_dtype_53 = torch.ops.aten.to.dtype(mul_tensor_81, torch.float32);  mul_tensor_81 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_53, mean_dim_17, primals_100, [48], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = mean_dim_17 = primals_100 = None
        getitem_234 = convolution_backward_default_18[0]
        getitem_235 = convolution_backward_default_18[1]
        getitem_236 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_234, [128, 1152, 7, 7]);  getitem_234 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 49);  expand_default_7 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(mul_tensor_75, div_scalar_7);  mul_tensor_75 = div_scalar_7 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_94, torch.float32);  add_tensor_94 = None
        to_dtype_55 = torch.ops.aten.to.dtype(clone_default_37, torch.float32);  clone_default_37 = None
        neg_default_11 = torch.ops.aten.neg.default(to_dtype_55)
        exp_default_11 = torch.ops.aten.exp.default(neg_default_11);  neg_default_11 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(exp_default_11, 1);  exp_default_11 = None
        reciprocal_default_11 = torch.ops.aten.reciprocal.default(add_tensor_95);  add_tensor_95 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(reciprocal_default_11, 1);  reciprocal_default_11 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(to_dtype_54, mul_tensor_82);  to_dtype_54 = None
        rsub_scalar_18 = torch.ops.aten.rsub.Scalar(mul_tensor_82, 1);  mul_tensor_82 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_55, rsub_scalar_18);  to_dtype_55 = rsub_scalar_18 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(mul_tensor_84, 1);  mul_tensor_84 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(mul_tensor_83, add_tensor_96);  mul_tensor_83 = add_tensor_96 = None
        to_dtype_56 = torch.ops.aten.to.dtype(mul_tensor_85, torch.float32);  mul_tensor_85 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, view_default_46, primals_321, primals_319, primals_320, getitem_112, getitem_113, True, 0.001, [True, True, True]);  to_dtype_56 = view_default_46 = primals_321 = primals_319 = primals_320 = getitem_112 = getitem_113 = None
        getitem_237 = native_batch_norm_backward_default_11[0]
        getitem_238 = native_batch_norm_backward_default_11[1]
        getitem_239 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        view_default_119 = torch.ops.aten.view.default(getitem_237, [147456, 1, 7, 7]);  getitem_237 = None
        permute_default_34 = torch.ops.aten.permute.default(view_default_119, [1, 0, 2, 3]);  view_default_119 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(permute_default_34, view_default_45, view_default_44, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 147456, [True, True, False]);  permute_default_34 = view_default_45 = view_default_44 = None
        getitem_240 = convolution_backward_default_19[0]
        getitem_241 = convolution_backward_default_19[1]
        getitem_242 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        view_default_120 = torch.ops.aten.view.default(getitem_240, [128, 1152, 7, 7]);  getitem_240 = None
        view_default_121 = torch.ops.aten.view.default(getitem_241, [128, 28800]);  getitem_241 = None
        t_default_45 = torch.ops.aten.t.default(sigmoid_default_16)
        mm_default_52 = torch.ops.aten.mm.default(t_default_45, view_default_121);  t_default_45 = None
        t_default_46 = torch.ops.aten.t.default(primals_92);  primals_92 = None
        mm_default_53 = torch.ops.aten.mm.default(view_default_121, t_default_46);  view_default_121 = t_default_46 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mm_default_51, mm_default_53);  mm_default_51 = mm_default_53 = None
        to_dtype_57 = torch.ops.aten.to.dtype(view_default_120, torch.float32);  view_default_120 = None
        to_dtype_58 = torch.ops.aten.to.dtype(clone_default_36, torch.float32);  clone_default_36 = None
        neg_default_12 = torch.ops.aten.neg.default(to_dtype_58)
        exp_default_12 = torch.ops.aten.exp.default(neg_default_12);  neg_default_12 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(exp_default_12, 1);  exp_default_12 = None
        reciprocal_default_12 = torch.ops.aten.reciprocal.default(add_tensor_98);  add_tensor_98 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(reciprocal_default_12, 1);  reciprocal_default_12 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(to_dtype_57, mul_tensor_86);  to_dtype_57 = None
        rsub_scalar_19 = torch.ops.aten.rsub.Scalar(mul_tensor_86, 1);  mul_tensor_86 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(to_dtype_58, rsub_scalar_19);  to_dtype_58 = rsub_scalar_19 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(mul_tensor_88, 1);  mul_tensor_88 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(mul_tensor_87, add_tensor_99);  mul_tensor_87 = add_tensor_99 = None
        to_dtype_59 = torch.ops.aten.to.dtype(mul_tensor_89, torch.float32);  mul_tensor_89 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, view_default_43, primals_316, primals_314, primals_315, getitem_109, getitem_110, True, 0.001, [True, True, True]);  to_dtype_59 = view_default_43 = primals_316 = primals_314 = primals_315 = getitem_109 = getitem_110 = None
        getitem_243 = native_batch_norm_backward_default_12[0]
        getitem_244 = native_batch_norm_backward_default_12[1]
        getitem_245 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        view_default_122 = torch.ops.aten.view.default(getitem_243, [147456, 1, 7, 7]);  getitem_243 = None
        permute_default_35 = torch.ops.aten.permute.default(view_default_122, [1, 0, 2, 3]);  view_default_122 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(permute_default_35, view_default_42, view_default_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_35 = view_default_42 = view_default_41 = None
        getitem_246 = convolution_backward_default_20[0]
        getitem_247 = convolution_backward_default_20[1]
        getitem_248 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        view_default_123 = torch.ops.aten.view.default(getitem_246, [128, 192, 7, 7]);  getitem_246 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(add_tensor_91, view_default_123);  add_tensor_91 = view_default_123 = None
        view_default_124 = torch.ops.aten.view.default(getitem_247, [128, 221184]);  getitem_247 = None
        t_default_47 = torch.ops.aten.t.default(sigmoid_default_16)
        mm_default_54 = torch.ops.aten.mm.default(t_default_47, view_default_124);  t_default_47 = None
        t_default_48 = torch.ops.aten.t.default(primals_93);  primals_93 = None
        mm_default_55 = torch.ops.aten.mm.default(view_default_124, t_default_48);  view_default_124 = t_default_48 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(add_tensor_97, mm_default_55);  add_tensor_97 = mm_default_55 = None
        to_dtype_60 = torch.ops.aten.to.dtype(add_tensor_101, torch.float32);  add_tensor_101 = None
        to_dtype_61 = torch.ops.aten.to.dtype(sigmoid_default_16, torch.float32);  sigmoid_default_16 = None
        rsub_scalar_20 = torch.ops.aten.rsub.Scalar(to_dtype_61, 1)
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_61, rsub_scalar_20);  to_dtype_61 = rsub_scalar_20 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_90);  mul_tensor_90 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(to_dtype_60, conj_physical_default_7);  to_dtype_60 = conj_physical_default_7 = None
        to_dtype_62 = torch.ops.aten.to.dtype(mul_tensor_91, torch.float32);  mul_tensor_91 = None
        t_default_49 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_56 = torch.ops.aten.mm.default(to_dtype_62, t_default_49);  t_default_49 = None
        t_default_50 = torch.ops.aten.t.default(to_dtype_62)
        mm_default_57 = torch.ops.aten.mm.default(t_default_50, view_default_40);  t_default_50 = view_default_40 = None
        t_default_51 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(to_dtype_62, [0], True);  to_dtype_62 = None
        view_default_125 = torch.ops.aten.view.default(sum_dim_int_list_8, [4]);  sum_dim_int_list_8 = None
        t_default_52 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        view_default_126 = torch.ops.aten.view.default(mm_default_56, [128, 192, 1, 1]);  mm_default_56 = None
        expand_default_8 = torch.ops.aten.expand.default(view_default_126, [128, 192, 7, 7]);  view_default_126 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 49);  expand_default_8 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(add_tensor_100, div_scalar_8);  add_tensor_100 = div_scalar_8 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_102, view_default_39, primals_311, primals_309, primals_310, getitem_106, getitem_107, True, 0.001, [True, True, True]);  add_tensor_102 = view_default_39 = primals_311 = primals_309 = primals_310 = getitem_106 = getitem_107 = None
        getitem_249 = native_batch_norm_backward_default_13[0]
        getitem_250 = native_batch_norm_backward_default_13[1]
        getitem_251 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        view_default_127 = torch.ops.aten.view.default(getitem_249, [24576, 1, 7, 7]);  getitem_249 = None
        permute_default_36 = torch.ops.aten.permute.default(view_default_127, [1, 0, 2, 3]);  view_default_127 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(permute_default_36, view_default_38, view_default_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_36 = view_default_38 = view_default_37 = None
        getitem_252 = convolution_backward_default_21[0]
        getitem_253 = convolution_backward_default_21[1]
        getitem_254 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        view_default_128 = torch.ops.aten.view.default(getitem_252, [128, 672, 7, 7]);  getitem_252 = None
        view_default_129 = torch.ops.aten.view.default(getitem_253, [128, 129024]);  getitem_253 = None
        t_default_53 = torch.ops.aten.t.default(sigmoid_default_14)
        mm_default_58 = torch.ops.aten.mm.default(t_default_53, view_default_129);  t_default_53 = None
        t_default_54 = torch.ops.aten.t.default(primals_85);  primals_85 = None
        mm_default_59 = torch.ops.aten.mm.default(view_default_129, t_default_54);  view_default_129 = t_default_54 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(view_default_128, silu__default_34);  silu__default_34 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(view_default_128, sigmoid_default_15);  view_default_128 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_92, [2, 3], True);  mul_tensor_92 = None
        to_dtype_63 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_15, torch.float32);  sigmoid_default_15 = None
        rsub_scalar_21 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_21);  to_dtype_64 = rsub_scalar_21 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_94);  mul_tensor_94 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_8);  to_dtype_63 = conj_physical_default_8 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_95, torch.float32);  mul_tensor_95 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_65, silu__default_35, primals_89, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = silu__default_35 = primals_89 = None
        getitem_255 = convolution_backward_default_22[0]
        getitem_256 = convolution_backward_default_22[1]
        getitem_257 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_255, torch.float32);  getitem_255 = None
        to_dtype_67 = torch.ops.aten.to.dtype(clone_default_35, torch.float32);  clone_default_35 = None
        neg_default_13 = torch.ops.aten.neg.default(to_dtype_67)
        exp_default_13 = torch.ops.aten.exp.default(neg_default_13);  neg_default_13 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(exp_default_13, 1);  exp_default_13 = None
        reciprocal_default_13 = torch.ops.aten.reciprocal.default(add_tensor_103);  add_tensor_103 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(reciprocal_default_13, 1);  reciprocal_default_13 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_66, mul_tensor_96);  to_dtype_66 = None
        rsub_scalar_22 = torch.ops.aten.rsub.Scalar(mul_tensor_96, 1);  mul_tensor_96 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_67, rsub_scalar_22);  to_dtype_67 = rsub_scalar_22 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(mul_tensor_98, 1);  mul_tensor_98 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(mul_tensor_97, add_tensor_104);  mul_tensor_97 = add_tensor_104 = None
        to_dtype_68 = torch.ops.aten.to.dtype(mul_tensor_99, torch.float32);  mul_tensor_99 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_68, mean_dim_15, primals_91, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = mean_dim_15 = primals_91 = None
        getitem_258 = convolution_backward_default_23[0]
        getitem_259 = convolution_backward_default_23[1]
        getitem_260 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        expand_default_9 = torch.ops.aten.expand.default(getitem_258, [128, 672, 7, 7]);  getitem_258 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_9, 49);  expand_default_9 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(mul_tensor_93, div_scalar_9);  mul_tensor_93 = div_scalar_9 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_105, torch.float32);  add_tensor_105 = None
        to_dtype_70 = torch.ops.aten.to.dtype(clone_default_34, torch.float32);  clone_default_34 = None
        neg_default_14 = torch.ops.aten.neg.default(to_dtype_70)
        exp_default_14 = torch.ops.aten.exp.default(neg_default_14);  neg_default_14 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(exp_default_14, 1);  exp_default_14 = None
        reciprocal_default_14 = torch.ops.aten.reciprocal.default(add_tensor_106);  add_tensor_106 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(reciprocal_default_14, 1);  reciprocal_default_14 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_69, mul_tensor_100);  to_dtype_69 = None
        rsub_scalar_23 = torch.ops.aten.rsub.Scalar(mul_tensor_100, 1);  mul_tensor_100 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_70, rsub_scalar_23);  to_dtype_70 = rsub_scalar_23 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(mul_tensor_102, 1);  mul_tensor_102 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(mul_tensor_101, add_tensor_107);  mul_tensor_101 = add_tensor_107 = None
        to_dtype_71 = torch.ops.aten.to.dtype(mul_tensor_103, torch.float32);  mul_tensor_103 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, view_default_36, primals_306, primals_304, primals_305, getitem_103, getitem_104, True, 0.001, [True, True, True]);  to_dtype_71 = view_default_36 = primals_306 = primals_304 = primals_305 = getitem_103 = getitem_104 = None
        getitem_261 = native_batch_norm_backward_default_14[0]
        getitem_262 = native_batch_norm_backward_default_14[1]
        getitem_263 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        view_default_130 = torch.ops.aten.view.default(getitem_261, [86016, 1, 7, 7]);  getitem_261 = None
        permute_default_37 = torch.ops.aten.permute.default(view_default_130, [1, 0, 2, 3]);  view_default_130 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(permute_default_37, constant_pad_nd_default_4, view_default_34, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 86016, [True, True, False]);  permute_default_37 = constant_pad_nd_default_4 = view_default_34 = None
        getitem_264 = convolution_backward_default_24[0]
        getitem_265 = convolution_backward_default_24[1]
        getitem_266 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(getitem_264, [-1, -2, -1, -2]);  getitem_264 = None
        view_default_131 = torch.ops.aten.view.default(constant_pad_nd_default_5, [128, 672, 14, 14]);  constant_pad_nd_default_5 = None
        view_default_132 = torch.ops.aten.view.default(getitem_265, [128, 16800]);  getitem_265 = None
        t_default_55 = torch.ops.aten.t.default(sigmoid_default_14)
        mm_default_60 = torch.ops.aten.mm.default(t_default_55, view_default_132);  t_default_55 = None
        t_default_56 = torch.ops.aten.t.default(primals_83);  primals_83 = None
        mm_default_61 = torch.ops.aten.mm.default(view_default_132, t_default_56);  view_default_132 = t_default_56 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(mm_default_59, mm_default_61);  mm_default_59 = mm_default_61 = None
        to_dtype_72 = torch.ops.aten.to.dtype(view_default_131, torch.float32);  view_default_131 = None
        to_dtype_73 = torch.ops.aten.to.dtype(clone_default_33, torch.float32);  clone_default_33 = None
        neg_default_15 = torch.ops.aten.neg.default(to_dtype_73)
        exp_default_15 = torch.ops.aten.exp.default(neg_default_15);  neg_default_15 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(exp_default_15, 1);  exp_default_15 = None
        reciprocal_default_15 = torch.ops.aten.reciprocal.default(add_tensor_109);  add_tensor_109 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(reciprocal_default_15, 1);  reciprocal_default_15 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_72, mul_tensor_104);  to_dtype_72 = None
        rsub_scalar_24 = torch.ops.aten.rsub.Scalar(mul_tensor_104, 1);  mul_tensor_104 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_73, rsub_scalar_24);  to_dtype_73 = rsub_scalar_24 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(mul_tensor_106, 1);  mul_tensor_106 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(mul_tensor_105, add_tensor_110);  mul_tensor_105 = add_tensor_110 = None
        to_dtype_74 = torch.ops.aten.to.dtype(mul_tensor_107, torch.float32);  mul_tensor_107 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, view_default_33, primals_301, primals_299, primals_300, getitem_100, getitem_101, True, 0.001, [True, True, True]);  to_dtype_74 = view_default_33 = primals_301 = primals_299 = primals_300 = getitem_100 = getitem_101 = None
        getitem_267 = native_batch_norm_backward_default_15[0]
        getitem_268 = native_batch_norm_backward_default_15[1]
        getitem_269 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        view_default_133 = torch.ops.aten.view.default(getitem_267, [86016, 1, 14, 14]);  getitem_267 = None
        permute_default_38 = torch.ops.aten.permute.default(view_default_133, [1, 0, 2, 3]);  view_default_133 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(permute_default_38, view_default_32, view_default_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_38 = view_default_32 = view_default_31 = None
        getitem_270 = convolution_backward_default_25[0]
        getitem_271 = convolution_backward_default_25[1]
        getitem_272 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        view_default_134 = torch.ops.aten.view.default(getitem_270, [128, 112, 14, 14]);  getitem_270 = None
        view_default_135 = torch.ops.aten.view.default(getitem_271, [128, 75264]);  getitem_271 = None
        t_default_57 = torch.ops.aten.t.default(sigmoid_default_14)
        mm_default_62 = torch.ops.aten.mm.default(t_default_57, view_default_135);  t_default_57 = None
        t_default_58 = torch.ops.aten.t.default(primals_84);  primals_84 = None
        mm_default_63 = torch.ops.aten.mm.default(view_default_135, t_default_58);  view_default_135 = t_default_58 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(add_tensor_108, mm_default_63);  add_tensor_108 = mm_default_63 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_111, torch.float32);  add_tensor_111 = None
        to_dtype_76 = torch.ops.aten.to.dtype(sigmoid_default_14, torch.float32);  sigmoid_default_14 = None
        rsub_scalar_25 = torch.ops.aten.rsub.Scalar(to_dtype_76, 1)
        mul_tensor_108 = torch.ops.aten.mul.Tensor(to_dtype_76, rsub_scalar_25);  to_dtype_76 = rsub_scalar_25 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_108);  mul_tensor_108 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_75, conj_physical_default_9);  to_dtype_75 = conj_physical_default_9 = None
        to_dtype_77 = torch.ops.aten.to.dtype(mul_tensor_109, torch.float32);  mul_tensor_109 = None
        t_default_59 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_64 = torch.ops.aten.mm.default(to_dtype_77, t_default_59);  t_default_59 = None
        t_default_60 = torch.ops.aten.t.default(to_dtype_77)
        mm_default_65 = torch.ops.aten.mm.default(t_default_60, view_default_30);  t_default_60 = view_default_30 = None
        t_default_61 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(to_dtype_77, [0], True);  to_dtype_77 = None
        view_default_136 = torch.ops.aten.view.default(sum_dim_int_list_10, [4]);  sum_dim_int_list_10 = None
        t_default_62 = torch.ops.aten.t.default(t_default_61);  t_default_61 = None
        view_default_137 = torch.ops.aten.view.default(mm_default_64, [128, 112, 1, 1]);  mm_default_64 = None
        expand_default_10 = torch.ops.aten.expand.default(view_default_137, [128, 112, 14, 14]);  view_default_137 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_10, 196);  expand_default_10 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(view_default_134, div_scalar_10);  view_default_134 = div_scalar_10 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_112, view_default_29, primals_296, primals_294, primals_295, getitem_97, getitem_98, True, 0.001, [True, True, True]);  view_default_29 = primals_296 = primals_294 = primals_295 = getitem_97 = getitem_98 = None
        getitem_273 = native_batch_norm_backward_default_16[0]
        getitem_274 = native_batch_norm_backward_default_16[1]
        getitem_275 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        view_default_138 = torch.ops.aten.view.default(getitem_273, [14336, 1, 14, 14]);  getitem_273 = None
        permute_default_39 = torch.ops.aten.permute.default(view_default_138, [1, 0, 2, 3]);  view_default_138 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(permute_default_39, view_default_28, view_default_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_39 = view_default_28 = view_default_27 = None
        getitem_276 = convolution_backward_default_26[0]
        getitem_277 = convolution_backward_default_26[1]
        getitem_278 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        view_default_139 = torch.ops.aten.view.default(getitem_276, [128, 672, 14, 14]);  getitem_276 = None
        view_default_140 = torch.ops.aten.view.default(getitem_277, [128, 75264]);  getitem_277 = None
        t_default_63 = torch.ops.aten.t.default(sigmoid_default_12)
        mm_default_66 = torch.ops.aten.mm.default(t_default_63, view_default_140);  t_default_63 = None
        t_default_64 = torch.ops.aten.t.default(primals_76);  primals_76 = None
        mm_default_67 = torch.ops.aten.mm.default(view_default_140, t_default_64);  view_default_140 = t_default_64 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(view_default_139, silu__default_31);  silu__default_31 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(view_default_139, sigmoid_default_13);  view_default_139 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_110, [2, 3], True);  mul_tensor_110 = None
        to_dtype_78 = torch.ops.aten.to.dtype(sum_dim_int_list_11, torch.float32);  sum_dim_int_list_11 = None
        to_dtype_79 = torch.ops.aten.to.dtype(sigmoid_default_13, torch.float32);  sigmoid_default_13 = None
        rsub_scalar_26 = torch.ops.aten.rsub.Scalar(to_dtype_79, 1)
        mul_tensor_112 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_26);  to_dtype_79 = rsub_scalar_26 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_112);  mul_tensor_112 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(to_dtype_78, conj_physical_default_10);  to_dtype_78 = conj_physical_default_10 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_113, torch.float32);  mul_tensor_113 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(to_dtype_80, silu__default_32, primals_80, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = silu__default_32 = primals_80 = None
        getitem_279 = convolution_backward_default_27[0]
        getitem_280 = convolution_backward_default_27[1]
        getitem_281 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_279, torch.float32);  getitem_279 = None
        to_dtype_82 = torch.ops.aten.to.dtype(clone_default_32, torch.float32);  clone_default_32 = None
        neg_default_16 = torch.ops.aten.neg.default(to_dtype_82)
        exp_default_16 = torch.ops.aten.exp.default(neg_default_16);  neg_default_16 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(exp_default_16, 1);  exp_default_16 = None
        reciprocal_default_16 = torch.ops.aten.reciprocal.default(add_tensor_113);  add_tensor_113 = None
        mul_tensor_114 = torch.ops.aten.mul.Tensor(reciprocal_default_16, 1);  reciprocal_default_16 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(to_dtype_81, mul_tensor_114);  to_dtype_81 = None
        rsub_scalar_27 = torch.ops.aten.rsub.Scalar(mul_tensor_114, 1);  mul_tensor_114 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(to_dtype_82, rsub_scalar_27);  to_dtype_82 = rsub_scalar_27 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(mul_tensor_116, 1);  mul_tensor_116 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(mul_tensor_115, add_tensor_114);  mul_tensor_115 = add_tensor_114 = None
        to_dtype_83 = torch.ops.aten.to.dtype(mul_tensor_117, torch.float32);  mul_tensor_117 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(to_dtype_83, mean_dim_13, primals_82, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_83 = mean_dim_13 = primals_82 = None
        getitem_282 = convolution_backward_default_28[0]
        getitem_283 = convolution_backward_default_28[1]
        getitem_284 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_282, [128, 672, 14, 14]);  getitem_282 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_11, 196);  expand_default_11 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(mul_tensor_111, div_scalar_11);  mul_tensor_111 = div_scalar_11 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_115, torch.float32);  add_tensor_115 = None
        to_dtype_85 = torch.ops.aten.to.dtype(clone_default_31, torch.float32);  clone_default_31 = None
        neg_default_17 = torch.ops.aten.neg.default(to_dtype_85)
        exp_default_17 = torch.ops.aten.exp.default(neg_default_17);  neg_default_17 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(exp_default_17, 1);  exp_default_17 = None
        reciprocal_default_17 = torch.ops.aten.reciprocal.default(add_tensor_116);  add_tensor_116 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(reciprocal_default_17, 1);  reciprocal_default_17 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(to_dtype_84, mul_tensor_118);  to_dtype_84 = None
        rsub_scalar_28 = torch.ops.aten.rsub.Scalar(mul_tensor_118, 1);  mul_tensor_118 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(to_dtype_85, rsub_scalar_28);  to_dtype_85 = rsub_scalar_28 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(mul_tensor_120, 1);  mul_tensor_120 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(mul_tensor_119, add_tensor_117);  mul_tensor_119 = add_tensor_117 = None
        to_dtype_86 = torch.ops.aten.to.dtype(mul_tensor_121, torch.float32);  mul_tensor_121 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, view_default_26, primals_291, primals_289, primals_290, getitem_94, getitem_95, True, 0.001, [True, True, True]);  to_dtype_86 = view_default_26 = primals_291 = primals_289 = primals_290 = getitem_94 = getitem_95 = None
        getitem_285 = native_batch_norm_backward_default_17[0]
        getitem_286 = native_batch_norm_backward_default_17[1]
        getitem_287 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        view_default_141 = torch.ops.aten.view.default(getitem_285, [86016, 1, 14, 14]);  getitem_285 = None
        permute_default_40 = torch.ops.aten.permute.default(view_default_141, [1, 0, 2, 3]);  view_default_141 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(permute_default_40, view_default_25, view_default_24, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 86016, [True, True, False]);  permute_default_40 = view_default_25 = view_default_24 = None
        getitem_288 = convolution_backward_default_29[0]
        getitem_289 = convolution_backward_default_29[1]
        getitem_290 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        view_default_142 = torch.ops.aten.view.default(getitem_288, [128, 672, 14, 14]);  getitem_288 = None
        view_default_143 = torch.ops.aten.view.default(getitem_289, [128, 16800]);  getitem_289 = None
        t_default_65 = torch.ops.aten.t.default(sigmoid_default_12)
        mm_default_68 = torch.ops.aten.mm.default(t_default_65, view_default_143);  t_default_65 = None
        t_default_66 = torch.ops.aten.t.default(primals_74);  primals_74 = None
        mm_default_69 = torch.ops.aten.mm.default(view_default_143, t_default_66);  view_default_143 = t_default_66 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(mm_default_67, mm_default_69);  mm_default_67 = mm_default_69 = None
        to_dtype_87 = torch.ops.aten.to.dtype(view_default_142, torch.float32);  view_default_142 = None
        to_dtype_88 = torch.ops.aten.to.dtype(clone_default_30, torch.float32);  clone_default_30 = None
        neg_default_18 = torch.ops.aten.neg.default(to_dtype_88)
        exp_default_18 = torch.ops.aten.exp.default(neg_default_18);  neg_default_18 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(exp_default_18, 1);  exp_default_18 = None
        reciprocal_default_18 = torch.ops.aten.reciprocal.default(add_tensor_119);  add_tensor_119 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(reciprocal_default_18, 1);  reciprocal_default_18 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(to_dtype_87, mul_tensor_122);  to_dtype_87 = None
        rsub_scalar_29 = torch.ops.aten.rsub.Scalar(mul_tensor_122, 1);  mul_tensor_122 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(to_dtype_88, rsub_scalar_29);  to_dtype_88 = rsub_scalar_29 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(mul_tensor_124, 1);  mul_tensor_124 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(mul_tensor_123, add_tensor_120);  mul_tensor_123 = add_tensor_120 = None
        to_dtype_89 = torch.ops.aten.to.dtype(mul_tensor_125, torch.float32);  mul_tensor_125 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, view_default_23, primals_286, primals_284, primals_285, getitem_91, getitem_92, True, 0.001, [True, True, True]);  to_dtype_89 = view_default_23 = primals_286 = primals_284 = primals_285 = getitem_91 = getitem_92 = None
        getitem_291 = native_batch_norm_backward_default_18[0]
        getitem_292 = native_batch_norm_backward_default_18[1]
        getitem_293 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        view_default_144 = torch.ops.aten.view.default(getitem_291, [86016, 1, 14, 14]);  getitem_291 = None
        permute_default_41 = torch.ops.aten.permute.default(view_default_144, [1, 0, 2, 3]);  view_default_144 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(permute_default_41, view_default_22, view_default_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_41 = view_default_22 = view_default_21 = None
        getitem_294 = convolution_backward_default_30[0]
        getitem_295 = convolution_backward_default_30[1]
        getitem_296 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        view_default_145 = torch.ops.aten.view.default(getitem_294, [128, 112, 14, 14]);  getitem_294 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(add_tensor_112, view_default_145);  add_tensor_112 = view_default_145 = None
        view_default_146 = torch.ops.aten.view.default(getitem_295, [128, 75264]);  getitem_295 = None
        t_default_67 = torch.ops.aten.t.default(sigmoid_default_12)
        mm_default_70 = torch.ops.aten.mm.default(t_default_67, view_default_146);  t_default_67 = None
        t_default_68 = torch.ops.aten.t.default(primals_75);  primals_75 = None
        mm_default_71 = torch.ops.aten.mm.default(view_default_146, t_default_68);  view_default_146 = t_default_68 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(add_tensor_118, mm_default_71);  add_tensor_118 = mm_default_71 = None
        to_dtype_90 = torch.ops.aten.to.dtype(add_tensor_122, torch.float32);  add_tensor_122 = None
        to_dtype_91 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar_30 = torch.ops.aten.rsub.Scalar(to_dtype_91, 1)
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_91, rsub_scalar_30);  to_dtype_91 = rsub_scalar_30 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_126);  mul_tensor_126 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(to_dtype_90, conj_physical_default_11);  to_dtype_90 = conj_physical_default_11 = None
        to_dtype_92 = torch.ops.aten.to.dtype(mul_tensor_127, torch.float32);  mul_tensor_127 = None
        t_default_69 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_72 = torch.ops.aten.mm.default(to_dtype_92, t_default_69);  t_default_69 = None
        t_default_70 = torch.ops.aten.t.default(to_dtype_92)
        mm_default_73 = torch.ops.aten.mm.default(t_default_70, view_default_20);  t_default_70 = view_default_20 = None
        t_default_71 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(to_dtype_92, [0], True);  to_dtype_92 = None
        view_default_147 = torch.ops.aten.view.default(sum_dim_int_list_12, [4]);  sum_dim_int_list_12 = None
        t_default_72 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        view_default_148 = torch.ops.aten.view.default(mm_default_72, [128, 112, 1, 1]);  mm_default_72 = None
        expand_default_12 = torch.ops.aten.expand.default(view_default_148, [128, 112, 14, 14]);  view_default_148 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_12, 196);  expand_default_12 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(add_tensor_121, div_scalar_12);  add_tensor_121 = div_scalar_12 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_123, view_default_19, primals_281, primals_279, primals_280, getitem_88, getitem_89, True, 0.001, [True, True, True]);  view_default_19 = primals_281 = primals_279 = primals_280 = getitem_88 = getitem_89 = None
        getitem_297 = native_batch_norm_backward_default_19[0]
        getitem_298 = native_batch_norm_backward_default_19[1]
        getitem_299 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        view_default_149 = torch.ops.aten.view.default(getitem_297, [14336, 1, 14, 14]);  getitem_297 = None
        permute_default_42 = torch.ops.aten.permute.default(view_default_149, [1, 0, 2, 3]);  view_default_149 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(permute_default_42, view_default_18, view_default_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_42 = view_default_18 = view_default_17 = None
        getitem_300 = convolution_backward_default_31[0]
        getitem_301 = convolution_backward_default_31[1]
        getitem_302 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        view_default_150 = torch.ops.aten.view.default(getitem_300, [128, 672, 14, 14]);  getitem_300 = None
        view_default_151 = torch.ops.aten.view.default(getitem_301, [128, 75264]);  getitem_301 = None
        t_default_73 = torch.ops.aten.t.default(sigmoid_default_10)
        mm_default_74 = torch.ops.aten.mm.default(t_default_73, view_default_151);  t_default_73 = None
        t_default_74 = torch.ops.aten.t.default(primals_67);  primals_67 = None
        mm_default_75 = torch.ops.aten.mm.default(view_default_151, t_default_74);  view_default_151 = t_default_74 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(view_default_150, silu__default_28);  silu__default_28 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(view_default_150, sigmoid_default_11);  view_default_150 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_128, [2, 3], True);  mul_tensor_128 = None
        to_dtype_93 = torch.ops.aten.to.dtype(sum_dim_int_list_13, torch.float32);  sum_dim_int_list_13 = None
        to_dtype_94 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_31 = torch.ops.aten.rsub.Scalar(to_dtype_94, 1)
        mul_tensor_130 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_31);  to_dtype_94 = rsub_scalar_31 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_130);  mul_tensor_130 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(to_dtype_93, conj_physical_default_12);  to_dtype_93 = conj_physical_default_12 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_131, torch.float32);  mul_tensor_131 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(to_dtype_95, silu__default_29, primals_71, [672], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_95 = silu__default_29 = primals_71 = None
        getitem_303 = convolution_backward_default_32[0]
        getitem_304 = convolution_backward_default_32[1]
        getitem_305 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_303, torch.float32);  getitem_303 = None
        to_dtype_97 = torch.ops.aten.to.dtype(clone_default_29, torch.float32);  clone_default_29 = None
        neg_default_19 = torch.ops.aten.neg.default(to_dtype_97)
        exp_default_19 = torch.ops.aten.exp.default(neg_default_19);  neg_default_19 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(exp_default_19, 1);  exp_default_19 = None
        reciprocal_default_19 = torch.ops.aten.reciprocal.default(add_tensor_124);  add_tensor_124 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(reciprocal_default_19, 1);  reciprocal_default_19 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_96, mul_tensor_132);  to_dtype_96 = None
        rsub_scalar_32 = torch.ops.aten.rsub.Scalar(mul_tensor_132, 1);  mul_tensor_132 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(to_dtype_97, rsub_scalar_32);  to_dtype_97 = rsub_scalar_32 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(mul_tensor_134, 1);  mul_tensor_134 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(mul_tensor_133, add_tensor_125);  mul_tensor_133 = add_tensor_125 = None
        to_dtype_98 = torch.ops.aten.to.dtype(mul_tensor_135, torch.float32);  mul_tensor_135 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(to_dtype_98, mean_dim_11, primals_73, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_98 = mean_dim_11 = primals_73 = None
        getitem_306 = convolution_backward_default_33[0]
        getitem_307 = convolution_backward_default_33[1]
        getitem_308 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        expand_default_13 = torch.ops.aten.expand.default(getitem_306, [128, 672, 14, 14]);  getitem_306 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_13, 196);  expand_default_13 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(mul_tensor_129, div_scalar_13);  mul_tensor_129 = div_scalar_13 = None
        to_dtype_99 = torch.ops.aten.to.dtype(add_tensor_126, torch.float32);  add_tensor_126 = None
        to_dtype_100 = torch.ops.aten.to.dtype(clone_default_28, torch.float32);  clone_default_28 = None
        neg_default_20 = torch.ops.aten.neg.default(to_dtype_100)
        exp_default_20 = torch.ops.aten.exp.default(neg_default_20);  neg_default_20 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(exp_default_20, 1);  exp_default_20 = None
        reciprocal_default_20 = torch.ops.aten.reciprocal.default(add_tensor_127);  add_tensor_127 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(reciprocal_default_20, 1);  reciprocal_default_20 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_99, mul_tensor_136);  to_dtype_99 = None
        rsub_scalar_33 = torch.ops.aten.rsub.Scalar(mul_tensor_136, 1);  mul_tensor_136 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_100, rsub_scalar_33);  to_dtype_100 = rsub_scalar_33 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(mul_tensor_138, 1);  mul_tensor_138 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(mul_tensor_137, add_tensor_128);  mul_tensor_137 = add_tensor_128 = None
        to_dtype_101 = torch.ops.aten.to.dtype(mul_tensor_139, torch.float32);  mul_tensor_139 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, view_default_16, primals_276, primals_274, primals_275, getitem_85, getitem_86, True, 0.001, [True, True, True]);  to_dtype_101 = view_default_16 = primals_276 = primals_274 = primals_275 = getitem_85 = getitem_86 = None
        getitem_309 = native_batch_norm_backward_default_20[0]
        getitem_310 = native_batch_norm_backward_default_20[1]
        getitem_311 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        view_default_152 = torch.ops.aten.view.default(getitem_309, [86016, 1, 14, 14]);  getitem_309 = None
        permute_default_43 = torch.ops.aten.permute.default(view_default_152, [1, 0, 2, 3]);  view_default_152 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(permute_default_43, view_default_15, view_default_14, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 86016, [True, True, False]);  permute_default_43 = view_default_15 = view_default_14 = None
        getitem_312 = convolution_backward_default_34[0]
        getitem_313 = convolution_backward_default_34[1]
        getitem_314 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        view_default_153 = torch.ops.aten.view.default(getitem_312, [128, 672, 14, 14]);  getitem_312 = None
        view_default_154 = torch.ops.aten.view.default(getitem_313, [128, 16800]);  getitem_313 = None
        t_default_75 = torch.ops.aten.t.default(sigmoid_default_10)
        mm_default_76 = torch.ops.aten.mm.default(t_default_75, view_default_154);  t_default_75 = None
        t_default_76 = torch.ops.aten.t.default(primals_65);  primals_65 = None
        mm_default_77 = torch.ops.aten.mm.default(view_default_154, t_default_76);  view_default_154 = t_default_76 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(mm_default_75, mm_default_77);  mm_default_75 = mm_default_77 = None
        to_dtype_102 = torch.ops.aten.to.dtype(view_default_153, torch.float32);  view_default_153 = None
        to_dtype_103 = torch.ops.aten.to.dtype(clone_default_27, torch.float32);  clone_default_27 = None
        neg_default_21 = torch.ops.aten.neg.default(to_dtype_103)
        exp_default_21 = torch.ops.aten.exp.default(neg_default_21);  neg_default_21 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(exp_default_21, 1);  exp_default_21 = None
        reciprocal_default_21 = torch.ops.aten.reciprocal.default(add_tensor_130);  add_tensor_130 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(reciprocal_default_21, 1);  reciprocal_default_21 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_102, mul_tensor_140);  to_dtype_102 = None
        rsub_scalar_34 = torch.ops.aten.rsub.Scalar(mul_tensor_140, 1);  mul_tensor_140 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_103, rsub_scalar_34);  to_dtype_103 = rsub_scalar_34 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(mul_tensor_142, 1);  mul_tensor_142 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(mul_tensor_141, add_tensor_131);  mul_tensor_141 = add_tensor_131 = None
        to_dtype_104 = torch.ops.aten.to.dtype(mul_tensor_143, torch.float32);  mul_tensor_143 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, view_default_13, primals_271, primals_269, primals_270, getitem_82, getitem_83, True, 0.001, [True, True, True]);  to_dtype_104 = view_default_13 = primals_271 = primals_269 = primals_270 = getitem_82 = getitem_83 = None
        getitem_315 = native_batch_norm_backward_default_21[0]
        getitem_316 = native_batch_norm_backward_default_21[1]
        getitem_317 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        view_default_155 = torch.ops.aten.view.default(getitem_315, [86016, 1, 14, 14]);  getitem_315 = None
        permute_default_44 = torch.ops.aten.permute.default(view_default_155, [1, 0, 2, 3]);  view_default_155 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(permute_default_44, view_default_12, view_default_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_44 = view_default_12 = view_default_11 = None
        getitem_318 = convolution_backward_default_35[0]
        getitem_319 = convolution_backward_default_35[1]
        getitem_320 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        view_default_156 = torch.ops.aten.view.default(getitem_318, [128, 112, 14, 14]);  getitem_318 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(add_tensor_123, view_default_156);  add_tensor_123 = view_default_156 = None
        view_default_157 = torch.ops.aten.view.default(getitem_319, [128, 75264]);  getitem_319 = None
        t_default_77 = torch.ops.aten.t.default(sigmoid_default_10)
        mm_default_78 = torch.ops.aten.mm.default(t_default_77, view_default_157);  t_default_77 = None
        t_default_78 = torch.ops.aten.t.default(primals_66);  primals_66 = None
        mm_default_79 = torch.ops.aten.mm.default(view_default_157, t_default_78);  view_default_157 = t_default_78 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(add_tensor_129, mm_default_79);  add_tensor_129 = mm_default_79 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_133, torch.float32);  add_tensor_133 = None
        to_dtype_106 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_35 = torch.ops.aten.rsub.Scalar(to_dtype_106, 1)
        mul_tensor_144 = torch.ops.aten.mul.Tensor(to_dtype_106, rsub_scalar_35);  to_dtype_106 = rsub_scalar_35 = None
        conj_physical_default_13 = torch.ops.aten.conj_physical.default(mul_tensor_144);  mul_tensor_144 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(to_dtype_105, conj_physical_default_13);  to_dtype_105 = conj_physical_default_13 = None
        to_dtype_107 = torch.ops.aten.to.dtype(mul_tensor_145, torch.float32);  mul_tensor_145 = None
        t_default_79 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_80 = torch.ops.aten.mm.default(to_dtype_107, t_default_79);  t_default_79 = None
        t_default_80 = torch.ops.aten.t.default(to_dtype_107)
        mm_default_81 = torch.ops.aten.mm.default(t_default_80, view_default_10);  t_default_80 = view_default_10 = None
        t_default_81 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(to_dtype_107, [0], True);  to_dtype_107 = None
        view_default_158 = torch.ops.aten.view.default(sum_dim_int_list_14, [4]);  sum_dim_int_list_14 = None
        t_default_82 = torch.ops.aten.t.default(t_default_81);  t_default_81 = None
        view_default_159 = torch.ops.aten.view.default(mm_default_80, [128, 112, 1, 1]);  mm_default_80 = None
        expand_default_14 = torch.ops.aten.expand.default(view_default_159, [128, 112, 14, 14]);  view_default_159 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_14, 196);  expand_default_14 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(add_tensor_132, div_scalar_14);  add_tensor_132 = div_scalar_14 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_134, view_default_9, primals_266, primals_264, primals_265, getitem_79, getitem_80, True, 0.001, [True, True, True]);  add_tensor_134 = view_default_9 = primals_266 = primals_264 = primals_265 = getitem_79 = getitem_80 = None
        getitem_321 = native_batch_norm_backward_default_22[0]
        getitem_322 = native_batch_norm_backward_default_22[1]
        getitem_323 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        view_default_160 = torch.ops.aten.view.default(getitem_321, [14336, 1, 14, 14]);  getitem_321 = None
        permute_default_45 = torch.ops.aten.permute.default(view_default_160, [1, 0, 2, 3]);  view_default_160 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(permute_default_45, view_default_8, view_default_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_45 = view_default_8 = view_default_7 = None
        getitem_324 = convolution_backward_default_36[0]
        getitem_325 = convolution_backward_default_36[1]
        getitem_326 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        view_default_161 = torch.ops.aten.view.default(getitem_324, [128, 480, 14, 14]);  getitem_324 = None
        view_default_162 = torch.ops.aten.view.default(getitem_325, [128, 53760]);  getitem_325 = None
        t_default_83 = torch.ops.aten.t.default(sigmoid_default_8)
        mm_default_82 = torch.ops.aten.mm.default(t_default_83, view_default_162);  t_default_83 = None
        t_default_84 = torch.ops.aten.t.default(primals_58);  primals_58 = None
        mm_default_83 = torch.ops.aten.mm.default(view_default_162, t_default_84);  view_default_162 = t_default_84 = None
        mul_tensor_146 = torch.ops.aten.mul.Tensor(view_default_161, silu__default_25);  silu__default_25 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(view_default_161, sigmoid_default_9);  view_default_161 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_146, [2, 3], True);  mul_tensor_146 = None
        to_dtype_108 = torch.ops.aten.to.dtype(sum_dim_int_list_15, torch.float32);  sum_dim_int_list_15 = None
        to_dtype_109 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_36 = torch.ops.aten.rsub.Scalar(to_dtype_109, 1)
        mul_tensor_148 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_36);  to_dtype_109 = rsub_scalar_36 = None
        conj_physical_default_14 = torch.ops.aten.conj_physical.default(mul_tensor_148);  mul_tensor_148 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_108, conj_physical_default_14);  to_dtype_108 = conj_physical_default_14 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_149, torch.float32);  mul_tensor_149 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(to_dtype_110, silu__default_26, primals_62, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_110 = silu__default_26 = primals_62 = None
        getitem_327 = convolution_backward_default_37[0]
        getitem_328 = convolution_backward_default_37[1]
        getitem_329 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_327, torch.float32);  getitem_327 = None
        to_dtype_112 = torch.ops.aten.to.dtype(clone_default_26, torch.float32);  clone_default_26 = None
        neg_default_22 = torch.ops.aten.neg.default(to_dtype_112)
        exp_default_22 = torch.ops.aten.exp.default(neg_default_22);  neg_default_22 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(exp_default_22, 1);  exp_default_22 = None
        reciprocal_default_22 = torch.ops.aten.reciprocal.default(add_tensor_135);  add_tensor_135 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(reciprocal_default_22, 1);  reciprocal_default_22 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(to_dtype_111, mul_tensor_150);  to_dtype_111 = None
        rsub_scalar_37 = torch.ops.aten.rsub.Scalar(mul_tensor_150, 1);  mul_tensor_150 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(to_dtype_112, rsub_scalar_37);  to_dtype_112 = rsub_scalar_37 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(mul_tensor_152, 1);  mul_tensor_152 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(mul_tensor_151, add_tensor_136);  mul_tensor_151 = add_tensor_136 = None
        to_dtype_113 = torch.ops.aten.to.dtype(mul_tensor_153, torch.float32);  mul_tensor_153 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(to_dtype_113, mean_dim_9, primals_64, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = mean_dim_9 = primals_64 = None
        getitem_330 = convolution_backward_default_38[0]
        getitem_331 = convolution_backward_default_38[1]
        getitem_332 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        expand_default_15 = torch.ops.aten.expand.default(getitem_330, [128, 480, 14, 14]);  getitem_330 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_15, 196);  expand_default_15 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(mul_tensor_147, div_scalar_15);  mul_tensor_147 = div_scalar_15 = None
        to_dtype_114 = torch.ops.aten.to.dtype(add_tensor_137, torch.float32);  add_tensor_137 = None
        to_dtype_115 = torch.ops.aten.to.dtype(clone_default_25, torch.float32);  clone_default_25 = None
        neg_default_23 = torch.ops.aten.neg.default(to_dtype_115)
        exp_default_23 = torch.ops.aten.exp.default(neg_default_23);  neg_default_23 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(exp_default_23, 1);  exp_default_23 = None
        reciprocal_default_23 = torch.ops.aten.reciprocal.default(add_tensor_138);  add_tensor_138 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(reciprocal_default_23, 1);  reciprocal_default_23 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(to_dtype_114, mul_tensor_154);  to_dtype_114 = None
        rsub_scalar_38 = torch.ops.aten.rsub.Scalar(mul_tensor_154, 1);  mul_tensor_154 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(to_dtype_115, rsub_scalar_38);  to_dtype_115 = rsub_scalar_38 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(mul_tensor_156, 1);  mul_tensor_156 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(mul_tensor_155, add_tensor_139);  mul_tensor_155 = add_tensor_139 = None
        to_dtype_116 = torch.ops.aten.to.dtype(mul_tensor_157, torch.float32);  mul_tensor_157 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, view_default_6, primals_261, primals_259, primals_260, getitem_76, getitem_77, True, 0.001, [True, True, True]);  to_dtype_116 = view_default_6 = primals_261 = primals_259 = primals_260 = getitem_76 = getitem_77 = None
        getitem_333 = native_batch_norm_backward_default_23[0]
        getitem_334 = native_batch_norm_backward_default_23[1]
        getitem_335 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        view_default_163 = torch.ops.aten.view.default(getitem_333, [61440, 1, 14, 14]);  getitem_333 = None
        permute_default_46 = torch.ops.aten.permute.default(view_default_163, [1, 0, 2, 3]);  view_default_163 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(permute_default_46, view_default_5, view_default_4, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 61440, [True, True, False]);  permute_default_46 = view_default_5 = view_default_4 = None
        getitem_336 = convolution_backward_default_39[0]
        getitem_337 = convolution_backward_default_39[1]
        getitem_338 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        view_default_164 = torch.ops.aten.view.default(getitem_336, [128, 480, 14, 14]);  getitem_336 = None
        view_default_165 = torch.ops.aten.view.default(getitem_337, [128, 12000]);  getitem_337 = None
        t_default_85 = torch.ops.aten.t.default(sigmoid_default_8)
        mm_default_84 = torch.ops.aten.mm.default(t_default_85, view_default_165);  t_default_85 = None
        t_default_86 = torch.ops.aten.t.default(primals_56);  primals_56 = None
        mm_default_85 = torch.ops.aten.mm.default(view_default_165, t_default_86);  view_default_165 = t_default_86 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(mm_default_83, mm_default_85);  mm_default_83 = mm_default_85 = None
        to_dtype_117 = torch.ops.aten.to.dtype(view_default_164, torch.float32);  view_default_164 = None
        to_dtype_118 = torch.ops.aten.to.dtype(clone_default_24, torch.float32);  clone_default_24 = None
        neg_default_24 = torch.ops.aten.neg.default(to_dtype_118)
        exp_default_24 = torch.ops.aten.exp.default(neg_default_24);  neg_default_24 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(exp_default_24, 1);  exp_default_24 = None
        reciprocal_default_24 = torch.ops.aten.reciprocal.default(add_tensor_141);  add_tensor_141 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(reciprocal_default_24, 1);  reciprocal_default_24 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(to_dtype_117, mul_tensor_158);  to_dtype_117 = None
        rsub_scalar_39 = torch.ops.aten.rsub.Scalar(mul_tensor_158, 1);  mul_tensor_158 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(to_dtype_118, rsub_scalar_39);  to_dtype_118 = rsub_scalar_39 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(mul_tensor_160, 1);  mul_tensor_160 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(mul_tensor_159, add_tensor_142);  mul_tensor_159 = add_tensor_142 = None
        to_dtype_119 = torch.ops.aten.to.dtype(mul_tensor_161, torch.float32);  mul_tensor_161 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, view_default_3, primals_256, primals_254, primals_255, getitem_73, getitem_74, True, 0.001, [True, True, True]);  to_dtype_119 = view_default_3 = primals_256 = primals_254 = primals_255 = getitem_73 = getitem_74 = None
        getitem_339 = native_batch_norm_backward_default_24[0]
        getitem_340 = native_batch_norm_backward_default_24[1]
        getitem_341 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        view_default_166 = torch.ops.aten.view.default(getitem_339, [61440, 1, 14, 14]);  getitem_339 = None
        permute_default_47 = torch.ops.aten.permute.default(view_default_166, [1, 0, 2, 3]);  view_default_166 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(permute_default_47, view_default_2, view_default_1, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 128, [True, True, False]);  permute_default_47 = view_default_2 = view_default_1 = None
        getitem_342 = convolution_backward_default_40[0]
        getitem_343 = convolution_backward_default_40[1]
        getitem_344 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        view_default_167 = torch.ops.aten.view.default(getitem_342, [128, 80, 14, 14]);  getitem_342 = None
        view_default_168 = torch.ops.aten.view.default(getitem_343, [128, 38400]);  getitem_343 = None
        t_default_87 = torch.ops.aten.t.default(sigmoid_default_8)
        mm_default_86 = torch.ops.aten.mm.default(t_default_87, view_default_168);  t_default_87 = None
        t_default_88 = torch.ops.aten.t.default(primals_57);  primals_57 = None
        mm_default_87 = torch.ops.aten.mm.default(view_default_168, t_default_88);  view_default_168 = t_default_88 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(add_tensor_140, mm_default_87);  add_tensor_140 = mm_default_87 = None
        to_dtype_120 = torch.ops.aten.to.dtype(add_tensor_143, torch.float32);  add_tensor_143 = None
        to_dtype_121 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_40 = torch.ops.aten.rsub.Scalar(to_dtype_121, 1)
        mul_tensor_162 = torch.ops.aten.mul.Tensor(to_dtype_121, rsub_scalar_40);  to_dtype_121 = rsub_scalar_40 = None
        conj_physical_default_15 = torch.ops.aten.conj_physical.default(mul_tensor_162);  mul_tensor_162 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(to_dtype_120, conj_physical_default_15);  to_dtype_120 = conj_physical_default_15 = None
        to_dtype_122 = torch.ops.aten.to.dtype(mul_tensor_163, torch.float32);  mul_tensor_163 = None
        t_default_89 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_88 = torch.ops.aten.mm.default(to_dtype_122, t_default_89);  t_default_89 = None
        t_default_90 = torch.ops.aten.t.default(to_dtype_122)
        mm_default_89 = torch.ops.aten.mm.default(t_default_90, view_default);  t_default_90 = view_default = None
        t_default_91 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(to_dtype_122, [0], True);  to_dtype_122 = None
        view_default_169 = torch.ops.aten.view.default(sum_dim_int_list_16, [4]);  sum_dim_int_list_16 = None
        t_default_92 = torch.ops.aten.t.default(t_default_91);  t_default_91 = None
        view_default_170 = torch.ops.aten.view.default(mm_default_88, [128, 80, 1, 1]);  mm_default_88 = None
        expand_default_16 = torch.ops.aten.expand.default(view_default_170, [128, 80, 14, 14]);  view_default_170 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_16, 196);  expand_default_16 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(view_default_167, div_scalar_16);  view_default_167 = div_scalar_16 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_144, convolution_default_39, primals_251, primals_249, primals_250, getitem_70, getitem_71, True, 0.001, [True, True, True]);  convolution_default_39 = primals_251 = primals_249 = primals_250 = getitem_70 = getitem_71 = None
        getitem_345 = native_batch_norm_backward_default_25[0]
        getitem_346 = native_batch_norm_backward_default_25[1]
        getitem_347 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_345, mul_tensor_7, primals_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_345 = mul_tensor_7 = primals_51 = None
        getitem_348 = convolution_backward_default_41[0]
        getitem_349 = convolution_backward_default_41[1]
        getitem_350 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(getitem_348, silu__default_22);  silu__default_22 = None
        mul_tensor_165 = torch.ops.aten.mul.Tensor(getitem_348, sigmoid_default_7);  getitem_348 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(mul_tensor_164, [2, 3], True);  mul_tensor_164 = None
        to_dtype_123 = torch.ops.aten.to.dtype(sum_dim_int_list_17, torch.float32);  sum_dim_int_list_17 = None
        to_dtype_124 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_41 = torch.ops.aten.rsub.Scalar(to_dtype_124, 1)
        mul_tensor_166 = torch.ops.aten.mul.Tensor(to_dtype_124, rsub_scalar_41);  to_dtype_124 = rsub_scalar_41 = None
        conj_physical_default_16 = torch.ops.aten.conj_physical.default(mul_tensor_166);  mul_tensor_166 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(to_dtype_123, conj_physical_default_16);  to_dtype_123 = conj_physical_default_16 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_167, torch.float32);  mul_tensor_167 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(to_dtype_125, silu__default_23, primals_53, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = silu__default_23 = primals_53 = None
        getitem_351 = convolution_backward_default_42[0]
        getitem_352 = convolution_backward_default_42[1]
        getitem_353 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_351, torch.float32);  getitem_351 = None
        to_dtype_127 = torch.ops.aten.to.dtype(clone_default_23, torch.float32);  clone_default_23 = None
        neg_default_25 = torch.ops.aten.neg.default(to_dtype_127)
        exp_default_25 = torch.ops.aten.exp.default(neg_default_25);  neg_default_25 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(exp_default_25, 1);  exp_default_25 = None
        reciprocal_default_25 = torch.ops.aten.reciprocal.default(add_tensor_145);  add_tensor_145 = None
        mul_tensor_168 = torch.ops.aten.mul.Tensor(reciprocal_default_25, 1);  reciprocal_default_25 = None
        mul_tensor_169 = torch.ops.aten.mul.Tensor(to_dtype_126, mul_tensor_168);  to_dtype_126 = None
        rsub_scalar_42 = torch.ops.aten.rsub.Scalar(mul_tensor_168, 1);  mul_tensor_168 = None
        mul_tensor_170 = torch.ops.aten.mul.Tensor(to_dtype_127, rsub_scalar_42);  to_dtype_127 = rsub_scalar_42 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(mul_tensor_170, 1);  mul_tensor_170 = None
        mul_tensor_171 = torch.ops.aten.mul.Tensor(mul_tensor_169, add_tensor_146);  mul_tensor_169 = add_tensor_146 = None
        to_dtype_128 = torch.ops.aten.to.dtype(mul_tensor_171, torch.float32);  mul_tensor_171 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(to_dtype_128, mean_dim_7, primals_55, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_128 = mean_dim_7 = primals_55 = None
        getitem_354 = convolution_backward_default_43[0]
        getitem_355 = convolution_backward_default_43[1]
        getitem_356 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        expand_default_17 = torch.ops.aten.expand.default(getitem_354, [128, 480, 14, 14]);  getitem_354 = None
        div_scalar_17 = torch.ops.aten.div.Scalar(expand_default_17, 196);  expand_default_17 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(mul_tensor_165, div_scalar_17);  mul_tensor_165 = div_scalar_17 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_147, torch.float32);  add_tensor_147 = None
        to_dtype_130 = torch.ops.aten.to.dtype(clone_default_22, torch.float32);  clone_default_22 = None
        neg_default_26 = torch.ops.aten.neg.default(to_dtype_130)
        exp_default_26 = torch.ops.aten.exp.default(neg_default_26);  neg_default_26 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(exp_default_26, 1);  exp_default_26 = None
        reciprocal_default_26 = torch.ops.aten.reciprocal.default(add_tensor_148);  add_tensor_148 = None
        mul_tensor_172 = torch.ops.aten.mul.Tensor(reciprocal_default_26, 1);  reciprocal_default_26 = None
        mul_tensor_173 = torch.ops.aten.mul.Tensor(to_dtype_129, mul_tensor_172);  to_dtype_129 = None
        rsub_scalar_43 = torch.ops.aten.rsub.Scalar(mul_tensor_172, 1);  mul_tensor_172 = None
        mul_tensor_174 = torch.ops.aten.mul.Tensor(to_dtype_130, rsub_scalar_43);  to_dtype_130 = rsub_scalar_43 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(mul_tensor_174, 1);  mul_tensor_174 = None
        mul_tensor_175 = torch.ops.aten.mul.Tensor(mul_tensor_173, add_tensor_149);  mul_tensor_173 = add_tensor_149 = None
        to_dtype_131 = torch.ops.aten.to.dtype(mul_tensor_175, torch.float32);  mul_tensor_175 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_36, primals_246, primals_244, primals_245, getitem_67, getitem_68, True, 0.001, [True, True, True]);  to_dtype_131 = convolution_default_36 = primals_246 = primals_244 = primals_245 = getitem_67 = getitem_68 = None
        getitem_357 = native_batch_norm_backward_default_26[0]
        getitem_358 = native_batch_norm_backward_default_26[1]
        getitem_359 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_357, silu__default_21, primals_49, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_357 = silu__default_21 = primals_49 = None
        getitem_360 = convolution_backward_default_44[0]
        getitem_361 = convolution_backward_default_44[1]
        getitem_362 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_360, torch.float32);  getitem_360 = None
        to_dtype_133 = torch.ops.aten.to.dtype(clone_default_21, torch.float32);  clone_default_21 = None
        neg_default_27 = torch.ops.aten.neg.default(to_dtype_133)
        exp_default_27 = torch.ops.aten.exp.default(neg_default_27);  neg_default_27 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(exp_default_27, 1);  exp_default_27 = None
        reciprocal_default_27 = torch.ops.aten.reciprocal.default(add_tensor_150);  add_tensor_150 = None
        mul_tensor_176 = torch.ops.aten.mul.Tensor(reciprocal_default_27, 1);  reciprocal_default_27 = None
        mul_tensor_177 = torch.ops.aten.mul.Tensor(to_dtype_132, mul_tensor_176);  to_dtype_132 = None
        rsub_scalar_44 = torch.ops.aten.rsub.Scalar(mul_tensor_176, 1);  mul_tensor_176 = None
        mul_tensor_178 = torch.ops.aten.mul.Tensor(to_dtype_133, rsub_scalar_44);  to_dtype_133 = rsub_scalar_44 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(mul_tensor_178, 1);  mul_tensor_178 = None
        mul_tensor_179 = torch.ops.aten.mul.Tensor(mul_tensor_177, add_tensor_151);  mul_tensor_177 = add_tensor_151 = None
        to_dtype_134 = torch.ops.aten.to.dtype(mul_tensor_179, torch.float32);  mul_tensor_179 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_35, primals_241, primals_239, primals_240, getitem_64, getitem_65, True, 0.001, [True, True, True]);  to_dtype_134 = convolution_default_35 = primals_241 = primals_239 = primals_240 = getitem_64 = getitem_65 = None
        getitem_363 = native_batch_norm_backward_default_27[0]
        getitem_364 = native_batch_norm_backward_default_27[1]
        getitem_365 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_363, add_tensor_23, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_363 = add_tensor_23 = primals_50 = None
        getitem_366 = convolution_backward_default_45[0]
        getitem_367 = convolution_backward_default_45[1]
        getitem_368 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(add_tensor_144, getitem_366);  add_tensor_144 = getitem_366 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_152, convolution_default_34, primals_236, primals_234, primals_235, getitem_61, getitem_62, True, 0.001, [True, True, True]);  convolution_default_34 = primals_236 = primals_234 = primals_235 = getitem_61 = getitem_62 = None
        getitem_369 = native_batch_norm_backward_default_28[0]
        getitem_370 = native_batch_norm_backward_default_28[1]
        getitem_371 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_369, mul_tensor_6, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_369 = mul_tensor_6 = primals_44 = None
        getitem_372 = convolution_backward_default_46[0]
        getitem_373 = convolution_backward_default_46[1]
        getitem_374 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        mul_tensor_180 = torch.ops.aten.mul.Tensor(getitem_372, silu__default_19);  silu__default_19 = None
        mul_tensor_181 = torch.ops.aten.mul.Tensor(getitem_372, sigmoid_default_6);  getitem_372 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(mul_tensor_180, [2, 3], True);  mul_tensor_180 = None
        to_dtype_135 = torch.ops.aten.to.dtype(sum_dim_int_list_18, torch.float32);  sum_dim_int_list_18 = None
        to_dtype_136 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_45 = torch.ops.aten.rsub.Scalar(to_dtype_136, 1)
        mul_tensor_182 = torch.ops.aten.mul.Tensor(to_dtype_136, rsub_scalar_45);  to_dtype_136 = rsub_scalar_45 = None
        conj_physical_default_17 = torch.ops.aten.conj_physical.default(mul_tensor_182);  mul_tensor_182 = None
        mul_tensor_183 = torch.ops.aten.mul.Tensor(to_dtype_135, conj_physical_default_17);  to_dtype_135 = conj_physical_default_17 = None
        to_dtype_137 = torch.ops.aten.to.dtype(mul_tensor_183, torch.float32);  mul_tensor_183 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(to_dtype_137, silu__default_20, primals_46, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_137 = silu__default_20 = primals_46 = None
        getitem_375 = convolution_backward_default_47[0]
        getitem_376 = convolution_backward_default_47[1]
        getitem_377 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_375, torch.float32);  getitem_375 = None
        to_dtype_139 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        neg_default_28 = torch.ops.aten.neg.default(to_dtype_139)
        exp_default_28 = torch.ops.aten.exp.default(neg_default_28);  neg_default_28 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(exp_default_28, 1);  exp_default_28 = None
        reciprocal_default_28 = torch.ops.aten.reciprocal.default(add_tensor_153);  add_tensor_153 = None
        mul_tensor_184 = torch.ops.aten.mul.Tensor(reciprocal_default_28, 1);  reciprocal_default_28 = None
        mul_tensor_185 = torch.ops.aten.mul.Tensor(to_dtype_138, mul_tensor_184);  to_dtype_138 = None
        rsub_scalar_46 = torch.ops.aten.rsub.Scalar(mul_tensor_184, 1);  mul_tensor_184 = None
        mul_tensor_186 = torch.ops.aten.mul.Tensor(to_dtype_139, rsub_scalar_46);  to_dtype_139 = rsub_scalar_46 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(mul_tensor_186, 1);  mul_tensor_186 = None
        mul_tensor_187 = torch.ops.aten.mul.Tensor(mul_tensor_185, add_tensor_154);  mul_tensor_185 = add_tensor_154 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_187, torch.float32);  mul_tensor_187 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(to_dtype_140, mean_dim_6, primals_48, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_140 = mean_dim_6 = primals_48 = None
        getitem_378 = convolution_backward_default_48[0]
        getitem_379 = convolution_backward_default_48[1]
        getitem_380 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        expand_default_18 = torch.ops.aten.expand.default(getitem_378, [128, 480, 14, 14]);  getitem_378 = None
        div_scalar_18 = torch.ops.aten.div.Scalar(expand_default_18, 196);  expand_default_18 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(mul_tensor_181, div_scalar_18);  mul_tensor_181 = div_scalar_18 = None
        to_dtype_141 = torch.ops.aten.to.dtype(add_tensor_155, torch.float32);  add_tensor_155 = None
        to_dtype_142 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        neg_default_29 = torch.ops.aten.neg.default(to_dtype_142)
        exp_default_29 = torch.ops.aten.exp.default(neg_default_29);  neg_default_29 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(exp_default_29, 1);  exp_default_29 = None
        reciprocal_default_29 = torch.ops.aten.reciprocal.default(add_tensor_156);  add_tensor_156 = None
        mul_tensor_188 = torch.ops.aten.mul.Tensor(reciprocal_default_29, 1);  reciprocal_default_29 = None
        mul_tensor_189 = torch.ops.aten.mul.Tensor(to_dtype_141, mul_tensor_188);  to_dtype_141 = None
        rsub_scalar_47 = torch.ops.aten.rsub.Scalar(mul_tensor_188, 1);  mul_tensor_188 = None
        mul_tensor_190 = torch.ops.aten.mul.Tensor(to_dtype_142, rsub_scalar_47);  to_dtype_142 = rsub_scalar_47 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(mul_tensor_190, 1);  mul_tensor_190 = None
        mul_tensor_191 = torch.ops.aten.mul.Tensor(mul_tensor_189, add_tensor_157);  mul_tensor_189 = add_tensor_157 = None
        to_dtype_143 = torch.ops.aten.to.dtype(mul_tensor_191, torch.float32);  mul_tensor_191 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_31, primals_231, primals_229, primals_230, getitem_58, getitem_59, True, 0.001, [True, True, True]);  to_dtype_143 = convolution_default_31 = primals_231 = primals_229 = primals_230 = getitem_58 = getitem_59 = None
        getitem_381 = native_batch_norm_backward_default_29[0]
        getitem_382 = native_batch_norm_backward_default_29[1]
        getitem_383 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_381, silu__default_18, primals_42, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 480, [True, True, False]);  getitem_381 = silu__default_18 = primals_42 = None
        getitem_384 = convolution_backward_default_49[0]
        getitem_385 = convolution_backward_default_49[1]
        getitem_386 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_384, torch.float32);  getitem_384 = None
        to_dtype_145 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        neg_default_30 = torch.ops.aten.neg.default(to_dtype_145)
        exp_default_30 = torch.ops.aten.exp.default(neg_default_30);  neg_default_30 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(exp_default_30, 1);  exp_default_30 = None
        reciprocal_default_30 = torch.ops.aten.reciprocal.default(add_tensor_158);  add_tensor_158 = None
        mul_tensor_192 = torch.ops.aten.mul.Tensor(reciprocal_default_30, 1);  reciprocal_default_30 = None
        mul_tensor_193 = torch.ops.aten.mul.Tensor(to_dtype_144, mul_tensor_192);  to_dtype_144 = None
        rsub_scalar_48 = torch.ops.aten.rsub.Scalar(mul_tensor_192, 1);  mul_tensor_192 = None
        mul_tensor_194 = torch.ops.aten.mul.Tensor(to_dtype_145, rsub_scalar_48);  to_dtype_145 = rsub_scalar_48 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(mul_tensor_194, 1);  mul_tensor_194 = None
        mul_tensor_195 = torch.ops.aten.mul.Tensor(mul_tensor_193, add_tensor_159);  mul_tensor_193 = add_tensor_159 = None
        to_dtype_146 = torch.ops.aten.to.dtype(mul_tensor_195, torch.float32);  mul_tensor_195 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_30, primals_226, primals_224, primals_225, getitem_55, getitem_56, True, 0.001, [True, True, True]);  to_dtype_146 = convolution_default_30 = primals_226 = primals_224 = primals_225 = getitem_55 = getitem_56 = None
        getitem_387 = native_batch_norm_backward_default_30[0]
        getitem_388 = native_batch_norm_backward_default_30[1]
        getitem_389 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_387, getitem_51, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_387 = getitem_51 = primals_43 = None
        getitem_390 = convolution_backward_default_50[0]
        getitem_391 = convolution_backward_default_50[1]
        getitem_392 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(add_tensor_152, getitem_390);  add_tensor_152 = getitem_390 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_160, convolution_default_29, primals_221, primals_219, primals_220, getitem_52, getitem_53, True, 0.001, [True, True, True]);  add_tensor_160 = convolution_default_29 = primals_221 = primals_219 = primals_220 = getitem_52 = getitem_53 = None
        getitem_393 = native_batch_norm_backward_default_31[0]
        getitem_394 = native_batch_norm_backward_default_31[1]
        getitem_395 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_393, mul_tensor_5, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_393 = mul_tensor_5 = primals_37 = None
        getitem_396 = convolution_backward_default_51[0]
        getitem_397 = convolution_backward_default_51[1]
        getitem_398 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        mul_tensor_196 = torch.ops.aten.mul.Tensor(getitem_396, silu__default_16);  silu__default_16 = None
        mul_tensor_197 = torch.ops.aten.mul.Tensor(getitem_396, sigmoid_default_5);  getitem_396 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(mul_tensor_196, [2, 3], True);  mul_tensor_196 = None
        to_dtype_147 = torch.ops.aten.to.dtype(sum_dim_int_list_19, torch.float32);  sum_dim_int_list_19 = None
        to_dtype_148 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_49 = torch.ops.aten.rsub.Scalar(to_dtype_148, 1)
        mul_tensor_198 = torch.ops.aten.mul.Tensor(to_dtype_148, rsub_scalar_49);  to_dtype_148 = rsub_scalar_49 = None
        conj_physical_default_18 = torch.ops.aten.conj_physical.default(mul_tensor_198);  mul_tensor_198 = None
        mul_tensor_199 = torch.ops.aten.mul.Tensor(to_dtype_147, conj_physical_default_18);  to_dtype_147 = conj_physical_default_18 = None
        to_dtype_149 = torch.ops.aten.to.dtype(mul_tensor_199, torch.float32);  mul_tensor_199 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(to_dtype_149, silu__default_17, primals_39, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_149 = silu__default_17 = primals_39 = None
        getitem_399 = convolution_backward_default_52[0]
        getitem_400 = convolution_backward_default_52[1]
        getitem_401 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_399, torch.float32);  getitem_399 = None
        to_dtype_151 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        neg_default_31 = torch.ops.aten.neg.default(to_dtype_151)
        exp_default_31 = torch.ops.aten.exp.default(neg_default_31);  neg_default_31 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(exp_default_31, 1);  exp_default_31 = None
        reciprocal_default_31 = torch.ops.aten.reciprocal.default(add_tensor_161);  add_tensor_161 = None
        mul_tensor_200 = torch.ops.aten.mul.Tensor(reciprocal_default_31, 1);  reciprocal_default_31 = None
        mul_tensor_201 = torch.ops.aten.mul.Tensor(to_dtype_150, mul_tensor_200);  to_dtype_150 = None
        rsub_scalar_50 = torch.ops.aten.rsub.Scalar(mul_tensor_200, 1);  mul_tensor_200 = None
        mul_tensor_202 = torch.ops.aten.mul.Tensor(to_dtype_151, rsub_scalar_50);  to_dtype_151 = rsub_scalar_50 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(mul_tensor_202, 1);  mul_tensor_202 = None
        mul_tensor_203 = torch.ops.aten.mul.Tensor(mul_tensor_201, add_tensor_162);  mul_tensor_201 = add_tensor_162 = None
        to_dtype_152 = torch.ops.aten.to.dtype(mul_tensor_203, torch.float32);  mul_tensor_203 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(to_dtype_152, mean_dim_5, primals_41, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_152 = mean_dim_5 = primals_41 = None
        getitem_402 = convolution_backward_default_53[0]
        getitem_403 = convolution_backward_default_53[1]
        getitem_404 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        expand_default_19 = torch.ops.aten.expand.default(getitem_402, [128, 240, 14, 14]);  getitem_402 = None
        div_scalar_19 = torch.ops.aten.div.Scalar(expand_default_19, 196);  expand_default_19 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(mul_tensor_197, div_scalar_19);  mul_tensor_197 = div_scalar_19 = None
        to_dtype_153 = torch.ops.aten.to.dtype(add_tensor_163, torch.float32);  add_tensor_163 = None
        to_dtype_154 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        neg_default_32 = torch.ops.aten.neg.default(to_dtype_154)
        exp_default_32 = torch.ops.aten.exp.default(neg_default_32);  neg_default_32 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(exp_default_32, 1);  exp_default_32 = None
        reciprocal_default_32 = torch.ops.aten.reciprocal.default(add_tensor_164);  add_tensor_164 = None
        mul_tensor_204 = torch.ops.aten.mul.Tensor(reciprocal_default_32, 1);  reciprocal_default_32 = None
        mul_tensor_205 = torch.ops.aten.mul.Tensor(to_dtype_153, mul_tensor_204);  to_dtype_153 = None
        rsub_scalar_51 = torch.ops.aten.rsub.Scalar(mul_tensor_204, 1);  mul_tensor_204 = None
        mul_tensor_206 = torch.ops.aten.mul.Tensor(to_dtype_154, rsub_scalar_51);  to_dtype_154 = rsub_scalar_51 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(mul_tensor_206, 1);  mul_tensor_206 = None
        mul_tensor_207 = torch.ops.aten.mul.Tensor(mul_tensor_205, add_tensor_165);  mul_tensor_205 = add_tensor_165 = None
        to_dtype_155 = torch.ops.aten.to.dtype(mul_tensor_207, torch.float32);  mul_tensor_207 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_26, primals_216, primals_214, primals_215, getitem_49, getitem_50, True, 0.001, [True, True, True]);  to_dtype_155 = convolution_default_26 = primals_216 = primals_214 = primals_215 = getitem_49 = getitem_50 = None
        getitem_405 = native_batch_norm_backward_default_32[0]
        getitem_406 = native_batch_norm_backward_default_32[1]
        getitem_407 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_405, constant_pad_nd_default_3, primals_35, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_405 = constant_pad_nd_default_3 = primals_35 = None
        getitem_408 = convolution_backward_default_54[0]
        getitem_409 = convolution_backward_default_54[1]
        getitem_410 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_408, [0, -1, 0, -1]);  getitem_408 = None
        to_dtype_156 = torch.ops.aten.to.dtype(constant_pad_nd_default_6, torch.float32);  constant_pad_nd_default_6 = None
        to_dtype_157 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        neg_default_33 = torch.ops.aten.neg.default(to_dtype_157)
        exp_default_33 = torch.ops.aten.exp.default(neg_default_33);  neg_default_33 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(exp_default_33, 1);  exp_default_33 = None
        reciprocal_default_33 = torch.ops.aten.reciprocal.default(add_tensor_166);  add_tensor_166 = None
        mul_tensor_208 = torch.ops.aten.mul.Tensor(reciprocal_default_33, 1);  reciprocal_default_33 = None
        mul_tensor_209 = torch.ops.aten.mul.Tensor(to_dtype_156, mul_tensor_208);  to_dtype_156 = None
        rsub_scalar_52 = torch.ops.aten.rsub.Scalar(mul_tensor_208, 1);  mul_tensor_208 = None
        mul_tensor_210 = torch.ops.aten.mul.Tensor(to_dtype_157, rsub_scalar_52);  to_dtype_157 = rsub_scalar_52 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(mul_tensor_210, 1);  mul_tensor_210 = None
        mul_tensor_211 = torch.ops.aten.mul.Tensor(mul_tensor_209, add_tensor_167);  mul_tensor_209 = add_tensor_167 = None
        to_dtype_158 = torch.ops.aten.to.dtype(mul_tensor_211, torch.float32);  mul_tensor_211 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_25, primals_211, primals_209, primals_210, getitem_46, getitem_47, True, 0.001, [True, True, True]);  to_dtype_158 = convolution_default_25 = primals_211 = primals_209 = primals_210 = getitem_46 = getitem_47 = None
        getitem_411 = native_batch_norm_backward_default_33[0]
        getitem_412 = native_batch_norm_backward_default_33[1]
        getitem_413 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_411, add_tensor_16, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_411 = add_tensor_16 = primals_36 = None
        getitem_414 = convolution_backward_default_55[0]
        getitem_415 = convolution_backward_default_55[1]
        getitem_416 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(getitem_414, convolution_default_24, primals_206, primals_204, primals_205, getitem_43, getitem_44, True, 0.001, [True, True, True]);  convolution_default_24 = primals_206 = primals_204 = primals_205 = getitem_43 = getitem_44 = None
        getitem_417 = native_batch_norm_backward_default_34[0]
        getitem_418 = native_batch_norm_backward_default_34[1]
        getitem_419 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_417, mul_tensor_4, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_417 = mul_tensor_4 = primals_30 = None
        getitem_420 = convolution_backward_default_56[0]
        getitem_421 = convolution_backward_default_56[1]
        getitem_422 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        mul_tensor_212 = torch.ops.aten.mul.Tensor(getitem_420, silu__default_13);  silu__default_13 = None
        mul_tensor_213 = torch.ops.aten.mul.Tensor(getitem_420, sigmoid_default_4);  getitem_420 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(mul_tensor_212, [2, 3], True);  mul_tensor_212 = None
        to_dtype_159 = torch.ops.aten.to.dtype(sum_dim_int_list_20, torch.float32);  sum_dim_int_list_20 = None
        to_dtype_160 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_53 = torch.ops.aten.rsub.Scalar(to_dtype_160, 1)
        mul_tensor_214 = torch.ops.aten.mul.Tensor(to_dtype_160, rsub_scalar_53);  to_dtype_160 = rsub_scalar_53 = None
        conj_physical_default_19 = torch.ops.aten.conj_physical.default(mul_tensor_214);  mul_tensor_214 = None
        mul_tensor_215 = torch.ops.aten.mul.Tensor(to_dtype_159, conj_physical_default_19);  to_dtype_159 = conj_physical_default_19 = None
        to_dtype_161 = torch.ops.aten.to.dtype(mul_tensor_215, torch.float32);  mul_tensor_215 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(to_dtype_161, silu__default_14, primals_32, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_161 = silu__default_14 = primals_32 = None
        getitem_423 = convolution_backward_default_57[0]
        getitem_424 = convolution_backward_default_57[1]
        getitem_425 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_423, torch.float32);  getitem_423 = None
        to_dtype_163 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        neg_default_34 = torch.ops.aten.neg.default(to_dtype_163)
        exp_default_34 = torch.ops.aten.exp.default(neg_default_34);  neg_default_34 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(exp_default_34, 1);  exp_default_34 = None
        reciprocal_default_34 = torch.ops.aten.reciprocal.default(add_tensor_168);  add_tensor_168 = None
        mul_tensor_216 = torch.ops.aten.mul.Tensor(reciprocal_default_34, 1);  reciprocal_default_34 = None
        mul_tensor_217 = torch.ops.aten.mul.Tensor(to_dtype_162, mul_tensor_216);  to_dtype_162 = None
        rsub_scalar_54 = torch.ops.aten.rsub.Scalar(mul_tensor_216, 1);  mul_tensor_216 = None
        mul_tensor_218 = torch.ops.aten.mul.Tensor(to_dtype_163, rsub_scalar_54);  to_dtype_163 = rsub_scalar_54 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(mul_tensor_218, 1);  mul_tensor_218 = None
        mul_tensor_219 = torch.ops.aten.mul.Tensor(mul_tensor_217, add_tensor_169);  mul_tensor_217 = add_tensor_169 = None
        to_dtype_164 = torch.ops.aten.to.dtype(mul_tensor_219, torch.float32);  mul_tensor_219 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(to_dtype_164, mean_dim_4, primals_34, [10], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_164 = mean_dim_4 = primals_34 = None
        getitem_426 = convolution_backward_default_58[0]
        getitem_427 = convolution_backward_default_58[1]
        getitem_428 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        expand_default_20 = torch.ops.aten.expand.default(getitem_426, [128, 240, 28, 28]);  getitem_426 = None
        div_scalar_20 = torch.ops.aten.div.Scalar(expand_default_20, 784);  expand_default_20 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(mul_tensor_213, div_scalar_20);  mul_tensor_213 = div_scalar_20 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_170, torch.float32);  add_tensor_170 = None
        to_dtype_166 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        neg_default_35 = torch.ops.aten.neg.default(to_dtype_166)
        exp_default_35 = torch.ops.aten.exp.default(neg_default_35);  neg_default_35 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(exp_default_35, 1);  exp_default_35 = None
        reciprocal_default_35 = torch.ops.aten.reciprocal.default(add_tensor_171);  add_tensor_171 = None
        mul_tensor_220 = torch.ops.aten.mul.Tensor(reciprocal_default_35, 1);  reciprocal_default_35 = None
        mul_tensor_221 = torch.ops.aten.mul.Tensor(to_dtype_165, mul_tensor_220);  to_dtype_165 = None
        rsub_scalar_55 = torch.ops.aten.rsub.Scalar(mul_tensor_220, 1);  mul_tensor_220 = None
        mul_tensor_222 = torch.ops.aten.mul.Tensor(to_dtype_166, rsub_scalar_55);  to_dtype_166 = rsub_scalar_55 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(mul_tensor_222, 1);  mul_tensor_222 = None
        mul_tensor_223 = torch.ops.aten.mul.Tensor(mul_tensor_221, add_tensor_172);  mul_tensor_221 = add_tensor_172 = None
        to_dtype_167 = torch.ops.aten.to.dtype(mul_tensor_223, torch.float32);  mul_tensor_223 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_21, primals_201, primals_199, primals_200, getitem_40, getitem_41, True, 0.001, [True, True, True]);  to_dtype_167 = convolution_default_21 = primals_201 = primals_199 = primals_200 = getitem_40 = getitem_41 = None
        getitem_429 = native_batch_norm_backward_default_35[0]
        getitem_430 = native_batch_norm_backward_default_35[1]
        getitem_431 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_429, silu__default_12, primals_28, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 240, [True, True, False]);  getitem_429 = silu__default_12 = primals_28 = None
        getitem_432 = convolution_backward_default_59[0]
        getitem_433 = convolution_backward_default_59[1]
        getitem_434 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_432, torch.float32);  getitem_432 = None
        to_dtype_169 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        neg_default_36 = torch.ops.aten.neg.default(to_dtype_169)
        exp_default_36 = torch.ops.aten.exp.default(neg_default_36);  neg_default_36 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(exp_default_36, 1);  exp_default_36 = None
        reciprocal_default_36 = torch.ops.aten.reciprocal.default(add_tensor_173);  add_tensor_173 = None
        mul_tensor_224 = torch.ops.aten.mul.Tensor(reciprocal_default_36, 1);  reciprocal_default_36 = None
        mul_tensor_225 = torch.ops.aten.mul.Tensor(to_dtype_168, mul_tensor_224);  to_dtype_168 = None
        rsub_scalar_56 = torch.ops.aten.rsub.Scalar(mul_tensor_224, 1);  mul_tensor_224 = None
        mul_tensor_226 = torch.ops.aten.mul.Tensor(to_dtype_169, rsub_scalar_56);  to_dtype_169 = rsub_scalar_56 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(mul_tensor_226, 1);  mul_tensor_226 = None
        mul_tensor_227 = torch.ops.aten.mul.Tensor(mul_tensor_225, add_tensor_174);  mul_tensor_225 = add_tensor_174 = None
        to_dtype_170 = torch.ops.aten.to.dtype(mul_tensor_227, torch.float32);  mul_tensor_227 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_20, primals_196, primals_194, primals_195, getitem_37, getitem_38, True, 0.001, [True, True, True]);  to_dtype_170 = convolution_default_20 = primals_196 = primals_194 = primals_195 = getitem_37 = getitem_38 = None
        getitem_435 = native_batch_norm_backward_default_36[0]
        getitem_436 = native_batch_norm_backward_default_36[1]
        getitem_437 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_435, getitem_33, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_435 = getitem_33 = primals_29 = None
        getitem_438 = convolution_backward_default_60[0]
        getitem_439 = convolution_backward_default_60[1]
        getitem_440 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(getitem_414, getitem_438);  getitem_414 = getitem_438 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_175, convolution_default_19, primals_191, primals_189, primals_190, getitem_34, getitem_35, True, 0.001, [True, True, True]);  add_tensor_175 = convolution_default_19 = primals_191 = primals_189 = primals_190 = getitem_34 = getitem_35 = None
        getitem_441 = native_batch_norm_backward_default_37[0]
        getitem_442 = native_batch_norm_backward_default_37[1]
        getitem_443 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_441, mul_tensor_3, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_441 = mul_tensor_3 = primals_23 = None
        getitem_444 = convolution_backward_default_61[0]
        getitem_445 = convolution_backward_default_61[1]
        getitem_446 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        mul_tensor_228 = torch.ops.aten.mul.Tensor(getitem_444, silu__default_10);  silu__default_10 = None
        mul_tensor_229 = torch.ops.aten.mul.Tensor(getitem_444, sigmoid_default_3);  getitem_444 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(mul_tensor_228, [2, 3], True);  mul_tensor_228 = None
        to_dtype_171 = torch.ops.aten.to.dtype(sum_dim_int_list_21, torch.float32);  sum_dim_int_list_21 = None
        to_dtype_172 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_57 = torch.ops.aten.rsub.Scalar(to_dtype_172, 1)
        mul_tensor_230 = torch.ops.aten.mul.Tensor(to_dtype_172, rsub_scalar_57);  to_dtype_172 = rsub_scalar_57 = None
        conj_physical_default_20 = torch.ops.aten.conj_physical.default(mul_tensor_230);  mul_tensor_230 = None
        mul_tensor_231 = torch.ops.aten.mul.Tensor(to_dtype_171, conj_physical_default_20);  to_dtype_171 = conj_physical_default_20 = None
        to_dtype_173 = torch.ops.aten.to.dtype(mul_tensor_231, torch.float32);  mul_tensor_231 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(to_dtype_173, silu__default_11, primals_25, [144], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_173 = silu__default_11 = primals_25 = None
        getitem_447 = convolution_backward_default_62[0]
        getitem_448 = convolution_backward_default_62[1]
        getitem_449 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_447, torch.float32);  getitem_447 = None
        to_dtype_175 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        neg_default_37 = torch.ops.aten.neg.default(to_dtype_175)
        exp_default_37 = torch.ops.aten.exp.default(neg_default_37);  neg_default_37 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(exp_default_37, 1);  exp_default_37 = None
        reciprocal_default_37 = torch.ops.aten.reciprocal.default(add_tensor_176);  add_tensor_176 = None
        mul_tensor_232 = torch.ops.aten.mul.Tensor(reciprocal_default_37, 1);  reciprocal_default_37 = None
        mul_tensor_233 = torch.ops.aten.mul.Tensor(to_dtype_174, mul_tensor_232);  to_dtype_174 = None
        rsub_scalar_58 = torch.ops.aten.rsub.Scalar(mul_tensor_232, 1);  mul_tensor_232 = None
        mul_tensor_234 = torch.ops.aten.mul.Tensor(to_dtype_175, rsub_scalar_58);  to_dtype_175 = rsub_scalar_58 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(mul_tensor_234, 1);  mul_tensor_234 = None
        mul_tensor_235 = torch.ops.aten.mul.Tensor(mul_tensor_233, add_tensor_177);  mul_tensor_233 = add_tensor_177 = None
        to_dtype_176 = torch.ops.aten.to.dtype(mul_tensor_235, torch.float32);  mul_tensor_235 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(to_dtype_176, mean_dim_3, primals_27, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_176 = mean_dim_3 = primals_27 = None
        getitem_450 = convolution_backward_default_63[0]
        getitem_451 = convolution_backward_default_63[1]
        getitem_452 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        expand_default_21 = torch.ops.aten.expand.default(getitem_450, [128, 144, 28, 28]);  getitem_450 = None
        div_scalar_21 = torch.ops.aten.div.Scalar(expand_default_21, 784);  expand_default_21 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(mul_tensor_229, div_scalar_21);  mul_tensor_229 = div_scalar_21 = None
        to_dtype_177 = torch.ops.aten.to.dtype(add_tensor_178, torch.float32);  add_tensor_178 = None
        to_dtype_178 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        neg_default_38 = torch.ops.aten.neg.default(to_dtype_178)
        exp_default_38 = torch.ops.aten.exp.default(neg_default_38);  neg_default_38 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(exp_default_38, 1);  exp_default_38 = None
        reciprocal_default_38 = torch.ops.aten.reciprocal.default(add_tensor_179);  add_tensor_179 = None
        mul_tensor_236 = torch.ops.aten.mul.Tensor(reciprocal_default_38, 1);  reciprocal_default_38 = None
        mul_tensor_237 = torch.ops.aten.mul.Tensor(to_dtype_177, mul_tensor_236);  to_dtype_177 = None
        rsub_scalar_59 = torch.ops.aten.rsub.Scalar(mul_tensor_236, 1);  mul_tensor_236 = None
        mul_tensor_238 = torch.ops.aten.mul.Tensor(to_dtype_178, rsub_scalar_59);  to_dtype_178 = rsub_scalar_59 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(mul_tensor_238, 1);  mul_tensor_238 = None
        mul_tensor_239 = torch.ops.aten.mul.Tensor(mul_tensor_237, add_tensor_180);  mul_tensor_237 = add_tensor_180 = None
        to_dtype_179 = torch.ops.aten.to.dtype(mul_tensor_239, torch.float32);  mul_tensor_239 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_16, primals_186, primals_184, primals_185, getitem_31, getitem_32, True, 0.001, [True, True, True]);  to_dtype_179 = convolution_default_16 = primals_186 = primals_184 = primals_185 = getitem_31 = getitem_32 = None
        getitem_453 = native_batch_norm_backward_default_38[0]
        getitem_454 = native_batch_norm_backward_default_38[1]
        getitem_455 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_453, constant_pad_nd_default_2, primals_21, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_453 = constant_pad_nd_default_2 = primals_21 = None
        getitem_456 = convolution_backward_default_64[0]
        getitem_457 = convolution_backward_default_64[1]
        getitem_458 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(getitem_456, [-1, -2, -1, -2]);  getitem_456 = None
        to_dtype_180 = torch.ops.aten.to.dtype(constant_pad_nd_default_7, torch.float32);  constant_pad_nd_default_7 = None
        to_dtype_181 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        neg_default_39 = torch.ops.aten.neg.default(to_dtype_181)
        exp_default_39 = torch.ops.aten.exp.default(neg_default_39);  neg_default_39 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(exp_default_39, 1);  exp_default_39 = None
        reciprocal_default_39 = torch.ops.aten.reciprocal.default(add_tensor_181);  add_tensor_181 = None
        mul_tensor_240 = torch.ops.aten.mul.Tensor(reciprocal_default_39, 1);  reciprocal_default_39 = None
        mul_tensor_241 = torch.ops.aten.mul.Tensor(to_dtype_180, mul_tensor_240);  to_dtype_180 = None
        rsub_scalar_60 = torch.ops.aten.rsub.Scalar(mul_tensor_240, 1);  mul_tensor_240 = None
        mul_tensor_242 = torch.ops.aten.mul.Tensor(to_dtype_181, rsub_scalar_60);  to_dtype_181 = rsub_scalar_60 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(mul_tensor_242, 1);  mul_tensor_242 = None
        mul_tensor_243 = torch.ops.aten.mul.Tensor(mul_tensor_241, add_tensor_182);  mul_tensor_241 = add_tensor_182 = None
        to_dtype_182 = torch.ops.aten.to.dtype(mul_tensor_243, torch.float32);  mul_tensor_243 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_15, primals_181, primals_179, primals_180, getitem_28, getitem_29, True, 0.001, [True, True, True]);  to_dtype_182 = convolution_default_15 = primals_181 = primals_179 = primals_180 = getitem_28 = getitem_29 = None
        getitem_459 = native_batch_norm_backward_default_39[0]
        getitem_460 = native_batch_norm_backward_default_39[1]
        getitem_461 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_459, add_tensor_9, primals_22, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_459 = add_tensor_9 = primals_22 = None
        getitem_462 = convolution_backward_default_65[0]
        getitem_463 = convolution_backward_default_65[1]
        getitem_464 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(getitem_462, convolution_default_14, primals_176, primals_174, primals_175, getitem_25, getitem_26, True, 0.001, [True, True, True]);  convolution_default_14 = primals_176 = primals_174 = primals_175 = getitem_25 = getitem_26 = None
        getitem_465 = native_batch_norm_backward_default_40[0]
        getitem_466 = native_batch_norm_backward_default_40[1]
        getitem_467 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_465, mul_tensor_2, primals_16, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_465 = mul_tensor_2 = primals_16 = None
        getitem_468 = convolution_backward_default_66[0]
        getitem_469 = convolution_backward_default_66[1]
        getitem_470 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        mul_tensor_244 = torch.ops.aten.mul.Tensor(getitem_468, silu__default_7);  silu__default_7 = None
        mul_tensor_245 = torch.ops.aten.mul.Tensor(getitem_468, sigmoid_default_2);  getitem_468 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(mul_tensor_244, [2, 3], True);  mul_tensor_244 = None
        to_dtype_183 = torch.ops.aten.to.dtype(sum_dim_int_list_22, torch.float32);  sum_dim_int_list_22 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_61 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_246 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_61);  to_dtype_184 = rsub_scalar_61 = None
        conj_physical_default_21 = torch.ops.aten.conj_physical.default(mul_tensor_246);  mul_tensor_246 = None
        mul_tensor_247 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_21);  to_dtype_183 = conj_physical_default_21 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_247, torch.float32);  mul_tensor_247 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(to_dtype_185, silu__default_8, primals_18, [144], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_185 = silu__default_8 = primals_18 = None
        getitem_471 = convolution_backward_default_67[0]
        getitem_472 = convolution_backward_default_67[1]
        getitem_473 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_471, torch.float32);  getitem_471 = None
        to_dtype_187 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        neg_default_40 = torch.ops.aten.neg.default(to_dtype_187)
        exp_default_40 = torch.ops.aten.exp.default(neg_default_40);  neg_default_40 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(exp_default_40, 1);  exp_default_40 = None
        reciprocal_default_40 = torch.ops.aten.reciprocal.default(add_tensor_183);  add_tensor_183 = None
        mul_tensor_248 = torch.ops.aten.mul.Tensor(reciprocal_default_40, 1);  reciprocal_default_40 = None
        mul_tensor_249 = torch.ops.aten.mul.Tensor(to_dtype_186, mul_tensor_248);  to_dtype_186 = None
        rsub_scalar_62 = torch.ops.aten.rsub.Scalar(mul_tensor_248, 1);  mul_tensor_248 = None
        mul_tensor_250 = torch.ops.aten.mul.Tensor(to_dtype_187, rsub_scalar_62);  to_dtype_187 = rsub_scalar_62 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(mul_tensor_250, 1);  mul_tensor_250 = None
        mul_tensor_251 = torch.ops.aten.mul.Tensor(mul_tensor_249, add_tensor_184);  mul_tensor_249 = add_tensor_184 = None
        to_dtype_188 = torch.ops.aten.to.dtype(mul_tensor_251, torch.float32);  mul_tensor_251 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(to_dtype_188, mean_dim_2, primals_20, [6], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_188 = mean_dim_2 = primals_20 = None
        getitem_474 = convolution_backward_default_68[0]
        getitem_475 = convolution_backward_default_68[1]
        getitem_476 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        expand_default_22 = torch.ops.aten.expand.default(getitem_474, [128, 144, 56, 56]);  getitem_474 = None
        div_scalar_22 = torch.ops.aten.div.Scalar(expand_default_22, 3136);  expand_default_22 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(mul_tensor_245, div_scalar_22);  mul_tensor_245 = div_scalar_22 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_185, torch.float32);  add_tensor_185 = None
        to_dtype_190 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        neg_default_41 = torch.ops.aten.neg.default(to_dtype_190)
        exp_default_41 = torch.ops.aten.exp.default(neg_default_41);  neg_default_41 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(exp_default_41, 1);  exp_default_41 = None
        reciprocal_default_41 = torch.ops.aten.reciprocal.default(add_tensor_186);  add_tensor_186 = None
        mul_tensor_252 = torch.ops.aten.mul.Tensor(reciprocal_default_41, 1);  reciprocal_default_41 = None
        mul_tensor_253 = torch.ops.aten.mul.Tensor(to_dtype_189, mul_tensor_252);  to_dtype_189 = None
        rsub_scalar_63 = torch.ops.aten.rsub.Scalar(mul_tensor_252, 1);  mul_tensor_252 = None
        mul_tensor_254 = torch.ops.aten.mul.Tensor(to_dtype_190, rsub_scalar_63);  to_dtype_190 = rsub_scalar_63 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(mul_tensor_254, 1);  mul_tensor_254 = None
        mul_tensor_255 = torch.ops.aten.mul.Tensor(mul_tensor_253, add_tensor_187);  mul_tensor_253 = add_tensor_187 = None
        to_dtype_191 = torch.ops.aten.to.dtype(mul_tensor_255, torch.float32);  mul_tensor_255 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_11, primals_171, primals_169, primals_170, getitem_22, getitem_23, True, 0.001, [True, True, True]);  to_dtype_191 = convolution_default_11 = primals_171 = primals_169 = primals_170 = getitem_22 = getitem_23 = None
        getitem_477 = native_batch_norm_backward_default_41[0]
        getitem_478 = native_batch_norm_backward_default_41[1]
        getitem_479 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_477, silu__default_6, primals_14, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_477 = silu__default_6 = primals_14 = None
        getitem_480 = convolution_backward_default_69[0]
        getitem_481 = convolution_backward_default_69[1]
        getitem_482 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_480, torch.float32);  getitem_480 = None
        to_dtype_193 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        neg_default_42 = torch.ops.aten.neg.default(to_dtype_193)
        exp_default_42 = torch.ops.aten.exp.default(neg_default_42);  neg_default_42 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(exp_default_42, 1);  exp_default_42 = None
        reciprocal_default_42 = torch.ops.aten.reciprocal.default(add_tensor_188);  add_tensor_188 = None
        mul_tensor_256 = torch.ops.aten.mul.Tensor(reciprocal_default_42, 1);  reciprocal_default_42 = None
        mul_tensor_257 = torch.ops.aten.mul.Tensor(to_dtype_192, mul_tensor_256);  to_dtype_192 = None
        rsub_scalar_64 = torch.ops.aten.rsub.Scalar(mul_tensor_256, 1);  mul_tensor_256 = None
        mul_tensor_258 = torch.ops.aten.mul.Tensor(to_dtype_193, rsub_scalar_64);  to_dtype_193 = rsub_scalar_64 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(mul_tensor_258, 1);  mul_tensor_258 = None
        mul_tensor_259 = torch.ops.aten.mul.Tensor(mul_tensor_257, add_tensor_189);  mul_tensor_257 = add_tensor_189 = None
        to_dtype_194 = torch.ops.aten.to.dtype(mul_tensor_259, torch.float32);  mul_tensor_259 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_10, primals_166, primals_164, primals_165, getitem_19, getitem_20, True, 0.001, [True, True, True]);  to_dtype_194 = convolution_default_10 = primals_166 = primals_164 = primals_165 = getitem_19 = getitem_20 = None
        getitem_483 = native_batch_norm_backward_default_42[0]
        getitem_484 = native_batch_norm_backward_default_42[1]
        getitem_485 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_483, getitem_15, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_483 = getitem_15 = primals_15 = None
        getitem_486 = convolution_backward_default_70[0]
        getitem_487 = convolution_backward_default_70[1]
        getitem_488 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(getitem_462, getitem_486);  getitem_462 = getitem_486 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_190, convolution_default_9, primals_161, primals_159, primals_160, getitem_16, getitem_17, True, 0.001, [True, True, True]);  add_tensor_190 = convolution_default_9 = primals_161 = primals_159 = primals_160 = getitem_16 = getitem_17 = None
        getitem_489 = native_batch_norm_backward_default_43[0]
        getitem_490 = native_batch_norm_backward_default_43[1]
        getitem_491 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_489, mul_tensor_1, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_489 = mul_tensor_1 = primals_9 = None
        getitem_492 = convolution_backward_default_71[0]
        getitem_493 = convolution_backward_default_71[1]
        getitem_494 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        mul_tensor_260 = torch.ops.aten.mul.Tensor(getitem_492, silu__default_4);  silu__default_4 = None
        mul_tensor_261 = torch.ops.aten.mul.Tensor(getitem_492, sigmoid_default_1);  getitem_492 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(mul_tensor_260, [2, 3], True);  mul_tensor_260 = None
        to_dtype_195 = torch.ops.aten.to.dtype(sum_dim_int_list_23, torch.float32);  sum_dim_int_list_23 = None
        to_dtype_196 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_65 = torch.ops.aten.rsub.Scalar(to_dtype_196, 1)
        mul_tensor_262 = torch.ops.aten.mul.Tensor(to_dtype_196, rsub_scalar_65);  to_dtype_196 = rsub_scalar_65 = None
        conj_physical_default_22 = torch.ops.aten.conj_physical.default(mul_tensor_262);  mul_tensor_262 = None
        mul_tensor_263 = torch.ops.aten.mul.Tensor(to_dtype_195, conj_physical_default_22);  to_dtype_195 = conj_physical_default_22 = None
        to_dtype_197 = torch.ops.aten.to.dtype(mul_tensor_263, torch.float32);  mul_tensor_263 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(to_dtype_197, silu__default_5, primals_11, [96], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_197 = silu__default_5 = primals_11 = None
        getitem_495 = convolution_backward_default_72[0]
        getitem_496 = convolution_backward_default_72[1]
        getitem_497 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_495, torch.float32);  getitem_495 = None
        to_dtype_199 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        neg_default_43 = torch.ops.aten.neg.default(to_dtype_199)
        exp_default_43 = torch.ops.aten.exp.default(neg_default_43);  neg_default_43 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(exp_default_43, 1);  exp_default_43 = None
        reciprocal_default_43 = torch.ops.aten.reciprocal.default(add_tensor_191);  add_tensor_191 = None
        mul_tensor_264 = torch.ops.aten.mul.Tensor(reciprocal_default_43, 1);  reciprocal_default_43 = None
        mul_tensor_265 = torch.ops.aten.mul.Tensor(to_dtype_198, mul_tensor_264);  to_dtype_198 = None
        rsub_scalar_66 = torch.ops.aten.rsub.Scalar(mul_tensor_264, 1);  mul_tensor_264 = None
        mul_tensor_266 = torch.ops.aten.mul.Tensor(to_dtype_199, rsub_scalar_66);  to_dtype_199 = rsub_scalar_66 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(mul_tensor_266, 1);  mul_tensor_266 = None
        mul_tensor_267 = torch.ops.aten.mul.Tensor(mul_tensor_265, add_tensor_192);  mul_tensor_265 = add_tensor_192 = None
        to_dtype_200 = torch.ops.aten.to.dtype(mul_tensor_267, torch.float32);  mul_tensor_267 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(to_dtype_200, mean_dim_1, primals_13, [4], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_200 = mean_dim_1 = primals_13 = None
        getitem_498 = convolution_backward_default_73[0]
        getitem_499 = convolution_backward_default_73[1]
        getitem_500 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        expand_default_23 = torch.ops.aten.expand.default(getitem_498, [128, 96, 56, 56]);  getitem_498 = None
        div_scalar_23 = torch.ops.aten.div.Scalar(expand_default_23, 3136);  expand_default_23 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(mul_tensor_261, div_scalar_23);  mul_tensor_261 = div_scalar_23 = None
        to_dtype_201 = torch.ops.aten.to.dtype(add_tensor_193, torch.float32);  add_tensor_193 = None
        to_dtype_202 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        neg_default_44 = torch.ops.aten.neg.default(to_dtype_202)
        exp_default_44 = torch.ops.aten.exp.default(neg_default_44);  neg_default_44 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(exp_default_44, 1);  exp_default_44 = None
        reciprocal_default_44 = torch.ops.aten.reciprocal.default(add_tensor_194);  add_tensor_194 = None
        mul_tensor_268 = torch.ops.aten.mul.Tensor(reciprocal_default_44, 1);  reciprocal_default_44 = None
        mul_tensor_269 = torch.ops.aten.mul.Tensor(to_dtype_201, mul_tensor_268);  to_dtype_201 = None
        rsub_scalar_67 = torch.ops.aten.rsub.Scalar(mul_tensor_268, 1);  mul_tensor_268 = None
        mul_tensor_270 = torch.ops.aten.mul.Tensor(to_dtype_202, rsub_scalar_67);  to_dtype_202 = rsub_scalar_67 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(mul_tensor_270, 1);  mul_tensor_270 = None
        mul_tensor_271 = torch.ops.aten.mul.Tensor(mul_tensor_269, add_tensor_195);  mul_tensor_269 = add_tensor_195 = None
        to_dtype_203 = torch.ops.aten.to.dtype(mul_tensor_271, torch.float32);  mul_tensor_271 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_6, primals_156, primals_154, primals_155, getitem_13, getitem_14, True, 0.001, [True, True, True]);  to_dtype_203 = convolution_default_6 = primals_156 = primals_154 = primals_155 = getitem_13 = getitem_14 = None
        getitem_501 = native_batch_norm_backward_default_44[0]
        getitem_502 = native_batch_norm_backward_default_44[1]
        getitem_503 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_501, constant_pad_nd_default_1, primals_7, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_501 = constant_pad_nd_default_1 = primals_7 = None
        getitem_504 = convolution_backward_default_74[0]
        getitem_505 = convolution_backward_default_74[1]
        getitem_506 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(getitem_504, [0, -1, 0, -1]);  getitem_504 = None
        to_dtype_204 = torch.ops.aten.to.dtype(constant_pad_nd_default_8, torch.float32);  constant_pad_nd_default_8 = None
        to_dtype_205 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        neg_default_45 = torch.ops.aten.neg.default(to_dtype_205)
        exp_default_45 = torch.ops.aten.exp.default(neg_default_45);  neg_default_45 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(exp_default_45, 1);  exp_default_45 = None
        reciprocal_default_45 = torch.ops.aten.reciprocal.default(add_tensor_196);  add_tensor_196 = None
        mul_tensor_272 = torch.ops.aten.mul.Tensor(reciprocal_default_45, 1);  reciprocal_default_45 = None
        mul_tensor_273 = torch.ops.aten.mul.Tensor(to_dtype_204, mul_tensor_272);  to_dtype_204 = None
        rsub_scalar_68 = torch.ops.aten.rsub.Scalar(mul_tensor_272, 1);  mul_tensor_272 = None
        mul_tensor_274 = torch.ops.aten.mul.Tensor(to_dtype_205, rsub_scalar_68);  to_dtype_205 = rsub_scalar_68 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(mul_tensor_274, 1);  mul_tensor_274 = None
        mul_tensor_275 = torch.ops.aten.mul.Tensor(mul_tensor_273, add_tensor_197);  mul_tensor_273 = add_tensor_197 = None
        to_dtype_206 = torch.ops.aten.to.dtype(mul_tensor_275, torch.float32);  mul_tensor_275 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_5, primals_151, primals_149, primals_150, getitem_10, getitem_11, True, 0.001, [True, True, True]);  to_dtype_206 = convolution_default_5 = primals_151 = primals_149 = primals_150 = getitem_10 = getitem_11 = None
        getitem_507 = native_batch_norm_backward_default_45[0]
        getitem_508 = native_batch_norm_backward_default_45[1]
        getitem_509 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_507, getitem_6, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_507 = getitem_6 = primals_8 = None
        getitem_510 = convolution_backward_default_75[0]
        getitem_511 = convolution_backward_default_75[1]
        getitem_512 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(getitem_510, convolution_default_4, primals_146, primals_144, primals_145, getitem_7, getitem_8, True, 0.001, [True, True, True]);  getitem_510 = convolution_default_4 = primals_146 = primals_144 = primals_145 = getitem_7 = getitem_8 = None
        getitem_513 = native_batch_norm_backward_default_46[0]
        getitem_514 = native_batch_norm_backward_default_46[1]
        getitem_515 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_513, mul_tensor, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_513 = mul_tensor = primals_2 = None
        getitem_516 = convolution_backward_default_76[0]
        getitem_517 = convolution_backward_default_76[1]
        getitem_518 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        mul_tensor_276 = torch.ops.aten.mul.Tensor(getitem_516, silu__default_1);  silu__default_1 = None
        mul_tensor_277 = torch.ops.aten.mul.Tensor(getitem_516, sigmoid_default);  getitem_516 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(mul_tensor_276, [2, 3], True);  mul_tensor_276 = None
        to_dtype_207 = torch.ops.aten.to.dtype(sum_dim_int_list_24, torch.float32);  sum_dim_int_list_24 = None
        to_dtype_208 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_69 = torch.ops.aten.rsub.Scalar(to_dtype_208, 1)
        mul_tensor_278 = torch.ops.aten.mul.Tensor(to_dtype_208, rsub_scalar_69);  to_dtype_208 = rsub_scalar_69 = None
        conj_physical_default_23 = torch.ops.aten.conj_physical.default(mul_tensor_278);  mul_tensor_278 = None
        mul_tensor_279 = torch.ops.aten.mul.Tensor(to_dtype_207, conj_physical_default_23);  to_dtype_207 = conj_physical_default_23 = None
        to_dtype_209 = torch.ops.aten.to.dtype(mul_tensor_279, torch.float32);  mul_tensor_279 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(to_dtype_209, silu__default_2, primals_4, [32], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_209 = silu__default_2 = primals_4 = None
        getitem_519 = convolution_backward_default_77[0]
        getitem_520 = convolution_backward_default_77[1]
        getitem_521 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_519, torch.float32);  getitem_519 = None
        to_dtype_211 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        neg_default_46 = torch.ops.aten.neg.default(to_dtype_211)
        exp_default_46 = torch.ops.aten.exp.default(neg_default_46);  neg_default_46 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(exp_default_46, 1);  exp_default_46 = None
        reciprocal_default_46 = torch.ops.aten.reciprocal.default(add_tensor_198);  add_tensor_198 = None
        mul_tensor_280 = torch.ops.aten.mul.Tensor(reciprocal_default_46, 1);  reciprocal_default_46 = None
        mul_tensor_281 = torch.ops.aten.mul.Tensor(to_dtype_210, mul_tensor_280);  to_dtype_210 = None
        rsub_scalar_70 = torch.ops.aten.rsub.Scalar(mul_tensor_280, 1);  mul_tensor_280 = None
        mul_tensor_282 = torch.ops.aten.mul.Tensor(to_dtype_211, rsub_scalar_70);  to_dtype_211 = rsub_scalar_70 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(mul_tensor_282, 1);  mul_tensor_282 = None
        mul_tensor_283 = torch.ops.aten.mul.Tensor(mul_tensor_281, add_tensor_199);  mul_tensor_281 = add_tensor_199 = None
        to_dtype_212 = torch.ops.aten.to.dtype(mul_tensor_283, torch.float32);  mul_tensor_283 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(to_dtype_212, mean_dim, primals_6, [8], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_212 = mean_dim = primals_6 = None
        getitem_522 = convolution_backward_default_78[0]
        getitem_523 = convolution_backward_default_78[1]
        getitem_524 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        expand_default_24 = torch.ops.aten.expand.default(getitem_522, [128, 32, 112, 112]);  getitem_522 = None
        div_scalar_24 = torch.ops.aten.div.Scalar(expand_default_24, 12544);  expand_default_24 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(mul_tensor_277, div_scalar_24);  mul_tensor_277 = div_scalar_24 = None
        to_dtype_213 = torch.ops.aten.to.dtype(add_tensor_200, torch.float32);  add_tensor_200 = None
        to_dtype_214 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        neg_default_47 = torch.ops.aten.neg.default(to_dtype_214)
        exp_default_47 = torch.ops.aten.exp.default(neg_default_47);  neg_default_47 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(exp_default_47, 1);  exp_default_47 = None
        reciprocal_default_47 = torch.ops.aten.reciprocal.default(add_tensor_201);  add_tensor_201 = None
        mul_tensor_284 = torch.ops.aten.mul.Tensor(reciprocal_default_47, 1);  reciprocal_default_47 = None
        mul_tensor_285 = torch.ops.aten.mul.Tensor(to_dtype_213, mul_tensor_284);  to_dtype_213 = None
        rsub_scalar_71 = torch.ops.aten.rsub.Scalar(mul_tensor_284, 1);  mul_tensor_284 = None
        mul_tensor_286 = torch.ops.aten.mul.Tensor(to_dtype_214, rsub_scalar_71);  to_dtype_214 = rsub_scalar_71 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(mul_tensor_286, 1);  mul_tensor_286 = None
        mul_tensor_287 = torch.ops.aten.mul.Tensor(mul_tensor_285, add_tensor_202);  mul_tensor_285 = add_tensor_202 = None
        to_dtype_215 = torch.ops.aten.to.dtype(mul_tensor_287, torch.float32);  mul_tensor_287 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_1, primals_141, primals_139, primals_140, getitem_4, getitem_5, True, 0.001, [True, True, True]);  to_dtype_215 = convolution_default_1 = primals_141 = primals_139 = primals_140 = getitem_4 = getitem_5 = None
        getitem_525 = native_batch_norm_backward_default_47[0]
        getitem_526 = native_batch_norm_backward_default_47[1]
        getitem_527 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_525, silu__default, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_525 = silu__default = primals_1 = None
        getitem_528 = convolution_backward_default_79[0]
        getitem_529 = convolution_backward_default_79[1]
        getitem_530 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_528, torch.float32);  getitem_528 = None
        to_dtype_217 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        neg_default_48 = torch.ops.aten.neg.default(to_dtype_217)
        exp_default_48 = torch.ops.aten.exp.default(neg_default_48);  neg_default_48 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(exp_default_48, 1);  exp_default_48 = None
        reciprocal_default_48 = torch.ops.aten.reciprocal.default(add_tensor_203);  add_tensor_203 = None
        mul_tensor_288 = torch.ops.aten.mul.Tensor(reciprocal_default_48, 1);  reciprocal_default_48 = None
        mul_tensor_289 = torch.ops.aten.mul.Tensor(to_dtype_216, mul_tensor_288);  to_dtype_216 = None
        rsub_scalar_72 = torch.ops.aten.rsub.Scalar(mul_tensor_288, 1);  mul_tensor_288 = None
        mul_tensor_290 = torch.ops.aten.mul.Tensor(to_dtype_217, rsub_scalar_72);  to_dtype_217 = rsub_scalar_72 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(mul_tensor_290, 1);  mul_tensor_290 = None
        mul_tensor_291 = torch.ops.aten.mul.Tensor(mul_tensor_289, add_tensor_204);  mul_tensor_289 = add_tensor_204 = None
        to_dtype_218 = torch.ops.aten.to.dtype(mul_tensor_291, torch.float32);  mul_tensor_291 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default, primals_136, primals_134, primals_135, getitem_1, getitem_2, True, 0.001, [True, True, True]);  to_dtype_218 = convolution_default = primals_136 = primals_134 = primals_135 = getitem_1 = getitem_2 = None
        getitem_531 = native_batch_norm_backward_default_48[0]
        getitem_532 = native_batch_norm_backward_default_48[1]
        getitem_533 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_531, constant_pad_nd_default, primals_131, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_531 = constant_pad_nd_default = primals_131 = None
        getitem_534 = convolution_backward_default_80[0]
        getitem_535 = convolution_backward_default_80[1]
        getitem_536 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        return [addmm_default_8, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_22, add_tensor_24, add_tensor_25, add_tensor_26, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_35, add_tensor_36, add_tensor_37, add_tensor_39, add_tensor_40, add_tensor_41, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_50, add_tensor_51, add_tensor_52, add_tensor_54, add_tensor_55, add_tensor_56, add_tensor_57, getitem_529, getitem_517, getitem_521, getitem_520, getitem_524, getitem_523, getitem_505, getitem_511, getitem_493, getitem_497, getitem_496, getitem_500, getitem_499, getitem_481, getitem_487, getitem_469, getitem_473, getitem_472, getitem_476, getitem_475, getitem_457, getitem_463, getitem_445, getitem_449, getitem_448, getitem_452, getitem_451, getitem_433, getitem_439, getitem_421, getitem_425, getitem_424, getitem_428, getitem_427, getitem_409, getitem_415, getitem_397, getitem_401, getitem_400, getitem_404, getitem_403, getitem_385, getitem_391, getitem_373, getitem_377, getitem_376, getitem_380, getitem_379, getitem_361, getitem_367, getitem_349, getitem_353, getitem_352, getitem_356, getitem_355, mm_default_84, mm_default_86, mm_default_82, view_default_169, t_default_92, getitem_329, getitem_328, getitem_332, getitem_331, mm_default_76, mm_default_78, mm_default_74, view_default_158, t_default_82, getitem_305, getitem_304, getitem_308, getitem_307, mm_default_68, mm_default_70, mm_default_66, view_default_147, t_default_72, getitem_281, getitem_280, getitem_284, getitem_283, mm_default_60, mm_default_62, mm_default_58, view_default_136, t_default_62, getitem_257, getitem_256, getitem_260, getitem_259, mm_default_52, mm_default_54, mm_default_50, view_default_125, t_default_52, getitem_233, getitem_232, getitem_236, getitem_235, mm_default_44, mm_default_46, mm_default_42, view_default_114, t_default_42, getitem_209, getitem_208, getitem_212, getitem_211, mm_default_36, mm_default_38, mm_default_34, view_default_103, t_default_32, getitem_185, getitem_184, getitem_188, getitem_187, mm_default_28, mm_default_30, mm_default_26, view_default_92, t_default_22, getitem_161, getitem_160, getitem_164, getitem_163, view_default_81, t_default_12, getitem_151, getitem_535, None, None, None, None, getitem_532, getitem_533, None, None, None, getitem_526, getitem_527, None, None, None, getitem_514, getitem_515, None, None, None, getitem_508, getitem_509, None, None, None, getitem_502, getitem_503, None, None, None, getitem_490, getitem_491, None, None, None, getitem_484, getitem_485, None, None, None, getitem_478, getitem_479, None, None, None, getitem_466, getitem_467, None, None, None, getitem_460, getitem_461, None, None, None, getitem_454, getitem_455, None, None, None, getitem_442, getitem_443, None, None, None, getitem_436, getitem_437, None, None, None, getitem_430, getitem_431, None, None, None, getitem_418, getitem_419, None, None, None, getitem_412, getitem_413, None, None, None, getitem_406, getitem_407, None, None, None, getitem_394, getitem_395, None, None, None, getitem_388, getitem_389, None, None, None, getitem_382, getitem_383, None, None, None, getitem_370, getitem_371, None, None, None, getitem_364, getitem_365, None, None, None, getitem_358, getitem_359, None, None, None, getitem_346, getitem_347, None, None, None, getitem_340, getitem_341, None, None, None, getitem_334, getitem_335, None, None, None, getitem_322, getitem_323, None, None, None, getitem_316, getitem_317, None, None, None, getitem_310, getitem_311, None, None, None, getitem_298, getitem_299, None, None, None, getitem_292, getitem_293, None, None, None, getitem_286, getitem_287, None, None, None, getitem_274, getitem_275, None, None, None, getitem_268, getitem_269, None, None, None, getitem_262, getitem_263, None, None, None, getitem_250, getitem_251, None, None, None, getitem_244, getitem_245, None, None, None, getitem_238, getitem_239, None, None, None, getitem_226, getitem_227, None, None, None, getitem_220, getitem_221, None, None, None, getitem_214, getitem_215, None, None, None, getitem_202, getitem_203, None, None, None, getitem_196, getitem_197, None, None, None, getitem_190, getitem_191, None, None, None, getitem_178, getitem_179, None, None, None, getitem_172, getitem_173, None, None, None, getitem_166, getitem_167, None, None, None, getitem_154, getitem_155, None, None, None, getitem_148, getitem_149]
        
