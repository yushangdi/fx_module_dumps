
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/tf_mobilenetv3_large_075/tf_mobilenetv3_large_075_backward_0/state_dict.pt'))

    
    
    def forward(self, convolution_default_24, primals_250, convolution_default_25, primals_157, primals_200, primals_15, primals_201, primals_152, primals_247, getitem_53, primals_39, primals_151, getitem_13, getitem_15, getitem_98, getitem_14, primals_251, getitem_97, convolution_default_14, primals_252, to_dtype_5, primals_41, getitem_52, relu__default_2, primals_150, getitem_54, primals_196, convolution_default_5, primals_161, primals_237, primals_40, getitem_55, primals_38, to_dtype_7, convolution_default_40, primals_202, constant_pad_nd_default_3, primals_132, primals_296, primals_155, getitem_17, getitem_56, getitem_16, primals_2, primals_16, primals_162, relu__default_14, primals_131, getitem_72, mul_tensor_3, primals_197, primals_156, primals_90, primals_160, primals_92, primals_91, getitem_74, primals_25, convolution_default_6, getitem_73, primals_1, primals_130, convolution_default_31, add_tensor_24, convolution_default_23, primals_37, primals_246, getitem_96, hardswish__default_5, getitem_19, primals_116, primals_300, primals_126, getitem_40, convolution_default_55, primals_120, relu__default_12, primals_261, convolution_default_26, relu__default_17, convolution_default_15, primals_265, mul_tensor_2, primals_262, primals_241, getitem_47, getitem_37, primals_270, primals_125, primals_240, primals_245, primals_266, mean_dim_2, primals_137, primals_111, relu__default_8, relu__default_9, primals_135, constant_pad_nd_default_4, relu__default_10, hardswish__default_16, primals_242, getitem_49, getitem_109, getitem_50, mul_tensor_6, convolution_default_20, getitem_110, primals_136, primals_115, relu__default_13, primals_121, convolution_default_17, convolution_default_54, primals_267, getitem_41, primals_122, primals_117, primals_291, convolution_default_22, getitem_38, primals_112, primals_127, mean_dim_1, relu__default_11, primals_177, convolution_default_49, primals_42, primals_17, primals_212, primals_57, primals_206, primals_43, to_dtype_3, convolution_default_35, relu__default_16, hardswish__default_14, getitem_43, convolution_default_56, primals_63, convolution_default_13, primals_290, mul_tensor, primals_48, getitem_44, getitem_33, to_dtype_1, add_tensor_39, primals_211, convolution_default_18, getitem_125, primals_49, getitem_86, primals_176, getitem_113, primals_210, primals_18, getitem_84, getitem_111, getitem_34, primals_64, primals_58, primals_110, mean_dim_5, getitem_124, getitem_88, primals_11, primals_205, mul_tensor_1, primals_44, primals_207, add_tensor_19, primals_60, getitem_89, getitem_112, getitem_46, convolution_default_19, getitem_127, getitem_85, convolution_default_36, hardswish__default_8, primals_62, to_dtype_13, getitem_126, primals_46, add_tensor_57, primals_20, hardswish__default_2, primals_97, primals_165, hardswish__default_10, mul_tensor_4, primals_95, convolution_default, getitem_107, getitem, primals_282, primals_106, convolution_default_47, convolution_default_60, primals_96, primals_13, primals_105, getitem_1, primals_100, relu__default_18, getitem_59, primals_180, getitem_2, getitem_58, primals_272, primals_172, primals_140, primals_171, getitem_106, primals_271, convolution_default_59, primals_147, primals_276, primals_275, mul_tensor_7, add_tensor_48, convolution_default_45, getitem_57, primals_146, hardswish__default, primals_102, primals_166, getitem_108, primals_101, convolution_default_1, primals_181, primals_170, to_dtype_9, getitem_118, convolution_default_46, hardswish__default_18, primals_56, primals_167, to_dtype_15, primals_107, getitem_4, primals_175, getitem_5, primals_255, getitem_20, primals_287, getitem_93, relu__default_3, hardswish__default_9, primals_9, getitem_60, getitem_62, primals_285, getitem_94, convolution_default_7, getitem_122, primals_257, convolution_default_39, getitem_64, getitem_92, getitem_133, primals_256, constant_pad_nd_default, getitem_23, primals_286, getitem_22, getitem_120, getitem_95, getitem_119, primals_142, add_tensor_62, convolution_default_37, primals_10, convolution_default_27, mean_dim_3, getitem_135, relu__default_4, getitem_90, getitem_121, primals_32, getitem_134, convolution_default_62, primals_141, getitem_136, primals_8, convolution_default_8, getitem_25, convolution_default_61, hardswish__default_3, primals_297, hardswish__default_15, getitem_65, convolution_default_28, convolution_default_9, getitem_63, mean_dim_8, mean_dim_6, primals_31, getitem_91, getitem_26, convolution_default_52, add_tensor_10, getitem_137, getitem_61, primals_182, primals_71, getitem_116, primals_76, primals_185, primals_22, primals_191, getitem_66, convolution_default_50, primals_195, primals_53, getitem_70, primals_36, primals_72, mul_tensor_5, getitem_115, primals_55, getitem_67, hardswish__default_4, getitem_117, relu__default_15, primals_69, convolution_default_51, primals_33, primals_190, convolution_default_44, convolution_default_30, primals_70, primals_192, to_dtype_11, primals_74, primals_186, primals_281, primals_77, primals_277, getitem_71, primals_65, primals_35, primals_187, getitem_114, primals_280, convolution_default_29, primals_67, getitem_68, relu__default, getitem_29, getitem_28, convolution_default_2, getitem_81, primals_30, convolution_default_34, getitem_8, convolution_default_3, getitem_83, getitem_7, relu__default_5, getitem_101, primals_50, getitem_82, getitem_79, convolution_default_10, add_tensor_3, getitem_31, constant_pad_nd_default_2, mean_dim, getitem_11, primals_295, getitem_32, hardswish__default_7, getitem_10, constant_pad_nd_default_1, relu__default_6, getitem_80, hardswish__default_11, primals_145, convolution_default_42, primals_29, getitem_100, getitem_99, relu__default_1, getitem_35, convolution_default_33, relu__default_7, primals_302, convolution_default_4, add_tensor_35, primals_51, convolution_default_41, primals_34, convolution_default_12, primals_23, primals_86, getitem_128, primals_3, primals_5, primals_292, primals_312, mean_dim_4, view_default, primals_311, primals_82, primals_221, primals_310, t_default, getitem_130, getitem_103, primals_27, primals_220, hardswish__default_6, primals_4, primals_24, primals_307, convolution_default_57, primals_306, primals_215, primals_305, primals_226, primals_81, primals_216, getitem_75, primals_222, primals_230, primals_6, primals_235, primals_227, add_tensor_31, hardswish__default_12, primals_87, primals_225, primals_231, primals_301, getitem_77, getitem_104, getitem_76, getitem_131, primals_217, primals_260, hardswish__default_17, getitem_102, getitem_129, primals_232, convolution_default_32, primals_85, primals_7, primals_236, mean_dim_7, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47):
        clone_default = torch.ops.aten.clone.default(getitem);  getitem = None
        clone_default_1 = torch.ops.aten.clone.default(getitem_54);  getitem_54 = None
        clone_default_2 = torch.ops.aten.clone.default(getitem_57);  getitem_57 = None
        clone_default_3 = torch.ops.aten.clone.default(getitem_63);  getitem_63 = None
        clone_default_4 = torch.ops.aten.clone.default(getitem_66);  getitem_66 = None
        clone_default_5 = torch.ops.aten.clone.default(getitem_72);  getitem_72 = None
        clone_default_6 = torch.ops.aten.clone.default(getitem_75);  getitem_75 = None
        clone_default_7 = torch.ops.aten.clone.default(getitem_81);  getitem_81 = None
        clone_default_8 = torch.ops.aten.clone.default(getitem_84);  getitem_84 = None
        clone_default_9 = torch.ops.aten.clone.default(getitem_90);  getitem_90 = None
        clone_default_10 = torch.ops.aten.clone.default(getitem_93);  getitem_93 = None
        clone_default_11 = torch.ops.aten.clone.default(getitem_99);  getitem_99 = None
        clone_default_12 = torch.ops.aten.clone.default(getitem_102);  getitem_102 = None
        clone_default_13 = torch.ops.aten.clone.default(getitem_108);  getitem_108 = None
        clone_default_14 = torch.ops.aten.clone.default(getitem_111);  getitem_111 = None
        clone_default_15 = torch.ops.aten.clone.default(getitem_117);  getitem_117 = None
        clone_default_16 = torch.ops.aten.clone.default(getitem_120);  getitem_120 = None
        clone_default_17 = torch.ops.aten.clone.default(getitem_126);  getitem_126 = None
        clone_default_18 = torch.ops.aten.clone.default(getitem_129);  getitem_129 = None
        clone_default_19 = torch.ops.aten.clone.default(getitem_135);  getitem_135 = None
        clone_default_20 = torch.ops.aten.clone.default(convolution_default_62);  convolution_default_62 = None
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1280, 1, 1]);  mm_default = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_2, torch.float32);  view_default_2 = None
        to_dtype_17 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        lt_scalar = torch.ops.aten.lt.Scalar(to_dtype_17, -3)
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_16, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_17, 3)
        div_tensor_8 = torch.ops.aten.div.Tensor(to_dtype_17, 3);  to_dtype_17 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(div_tensor_8, 0.5);  div_tensor_8 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(to_dtype_16, add_tensor_64);  add_tensor_64 = None
        where_self = torch.ops.aten.where.self(le_scalar, mul_tensor_8, to_dtype_16);  le_scalar = mul_tensor_8 = to_dtype_16 = None
        where_self_1 = torch.ops.aten.where.self(lt_scalar, new_zeros_default_46, where_self);  lt_scalar = new_zeros_default_46 = where_self = None
        to_dtype_18 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(to_dtype_18, mean_dim_8, primals_81, [1280], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_18 = mean_dim_8 = primals_81 = None
        getitem_138 = convolution_backward_default[0]
        getitem_139 = convolution_backward_default[1]
        getitem_140 = convolution_backward_default[2];  convolution_backward_default = None
        expand_default = torch.ops.aten.expand.default(getitem_138, [128, 720, 7, 7]);  getitem_138 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype_19 = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_20 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        lt_scalar_1 = torch.ops.aten.lt.Scalar(to_dtype_20, -3)
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_19, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_20, 3)
        div_tensor_9 = torch.ops.aten.div.Tensor(to_dtype_20, 3);  to_dtype_20 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(div_tensor_9, 0.5);  div_tensor_9 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(to_dtype_19, add_tensor_65);  add_tensor_65 = None
        where_self_2 = torch.ops.aten.where.self(le_scalar_1, mul_tensor_9, to_dtype_19);  le_scalar_1 = mul_tensor_9 = to_dtype_19 = None
        where_self_3 = torch.ops.aten.where.self(lt_scalar_1, new_zeros_default_47, where_self_2);  lt_scalar_1 = new_zeros_default_47 = where_self_2 = None
        to_dtype_21 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_21, convolution_default_61, primals_312, primals_310, primals_311, getitem_136, getitem_137, True, 0.001, [True, True, True]);  to_dtype_21 = convolution_default_61 = primals_312 = primals_310 = primals_311 = getitem_136 = getitem_137 = None
        getitem_141 = native_batch_norm_backward_default[0]
        getitem_142 = native_batch_norm_backward_default[1]
        getitem_143 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_141, add_tensor_62, primals_77, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_141 = add_tensor_62 = primals_77 = None
        getitem_144 = convolution_backward_default_1[0]
        getitem_145 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_144, convolution_default_60, primals_307, primals_305, primals_306, getitem_133, getitem_134, True, 0.001, [True, True, True]);  convolution_default_60 = primals_307 = primals_305 = primals_306 = getitem_133 = getitem_134 = None
        getitem_147 = native_batch_norm_backward_default_1[0]
        getitem_148 = native_batch_norm_backward_default_1[1]
        getitem_149 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_147, mul_tensor_7, primals_72, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_147 = mul_tensor_7 = primals_72 = None
        getitem_150 = convolution_backward_default_2[0]
        getitem_151 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(getitem_150, hardswish__default_18);  hardswish__default_18 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(getitem_150, to_dtype_15);  getitem_150 = to_dtype_15 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_10, [2, 3], True);  mul_tensor_10 = None
        to_dtype_22 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_23 = torch.ops.aten.to.dtype(convolution_default_59, torch.float32);  convolution_default_59 = None
        gt_scalar = torch.ops.aten.gt.Scalar(to_dtype_23, -3.0)
        lt_scalar_2 = torch.ops.aten.lt.Scalar(to_dtype_23, 3.0);  to_dtype_23 = None
        __and___tensor = torch.ops.aten.__and__.Tensor(gt_scalar, lt_scalar_2);  gt_scalar = lt_scalar_2 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.16666666666666666)
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_22, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_22 = None
        where_self_4 = torch.ops.aten.where.self(__and___tensor, mul_tensor_12, new_zeros_default_48);  __and___tensor = mul_tensor_12 = new_zeros_default_48 = None
        to_dtype_24 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_24, relu__default_18, primals_74, [720], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_24 = primals_74 = None
        getitem_153 = convolution_backward_default_3[0]
        getitem_154 = convolution_backward_default_3[1]
        getitem_155 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_25 = torch.ops.aten.to.dtype(getitem_153, torch.float32);  getitem_153 = None
        to_dtype_26 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_26, 0);  to_dtype_26 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_25, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_49, to_dtype_25);  le_scalar_2 = new_zeros_default_49 = to_dtype_25 = None
        to_dtype_27 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(to_dtype_27, mean_dim_7, primals_76, [184], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_27 = mean_dim_7 = primals_76 = None
        getitem_156 = convolution_backward_default_4[0]
        getitem_157 = convolution_backward_default_4[1]
        getitem_158 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_156, [128, 720, 7, 7]);  getitem_156 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(mul_tensor_11, div_scalar_1);  mul_tensor_11 = div_scalar_1 = None
        to_dtype_28 = torch.ops.aten.to.dtype(add_tensor_66, torch.float32);  add_tensor_66 = None
        to_dtype_29 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        lt_scalar_3 = torch.ops.aten.lt.Scalar(to_dtype_29, -3)
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_28, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_29, 3)
        div_tensor_10 = torch.ops.aten.div.Tensor(to_dtype_29, 3);  to_dtype_29 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(div_tensor_10, 0.5);  div_tensor_10 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(to_dtype_28, add_tensor_67);  add_tensor_67 = None
        where_self_6 = torch.ops.aten.where.self(le_scalar_3, mul_tensor_13, to_dtype_28);  le_scalar_3 = mul_tensor_13 = to_dtype_28 = None
        where_self_7 = torch.ops.aten.where.self(lt_scalar_3, new_zeros_default_50, where_self_6);  lt_scalar_3 = new_zeros_default_50 = where_self_6 = None
        to_dtype_30 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_30, convolution_default_57, primals_302, primals_300, primals_301, getitem_130, getitem_131, True, 0.001, [True, True, True]);  to_dtype_30 = convolution_default_57 = primals_302 = primals_300 = primals_301 = getitem_130 = getitem_131 = None
        getitem_159 = native_batch_norm_backward_default_2[0]
        getitem_160 = native_batch_norm_backward_default_2[1]
        getitem_161 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_159, hardswish__default_17, primals_70, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 720, [True, True, False]);  getitem_159 = hardswish__default_17 = primals_70 = None
        getitem_162 = convolution_backward_default_5[0]
        getitem_163 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_31 = torch.ops.aten.to.dtype(getitem_162, torch.float32);  getitem_162 = None
        to_dtype_32 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        lt_scalar_4 = torch.ops.aten.lt.Scalar(to_dtype_32, -3)
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_31, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_32, 3)
        div_tensor_11 = torch.ops.aten.div.Tensor(to_dtype_32, 3);  to_dtype_32 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(div_tensor_11, 0.5);  div_tensor_11 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_31, add_tensor_68);  add_tensor_68 = None
        where_self_8 = torch.ops.aten.where.self(le_scalar_4, mul_tensor_14, to_dtype_31);  le_scalar_4 = mul_tensor_14 = to_dtype_31 = None
        where_self_9 = torch.ops.aten.where.self(lt_scalar_4, new_zeros_default_51, where_self_8);  lt_scalar_4 = new_zeros_default_51 = where_self_8 = None
        to_dtype_33 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_33, convolution_default_56, primals_297, primals_295, primals_296, getitem_127, getitem_128, True, 0.001, [True, True, True]);  to_dtype_33 = convolution_default_56 = primals_297 = primals_295 = primals_296 = getitem_127 = getitem_128 = None
        getitem_165 = native_batch_norm_backward_default_3[0]
        getitem_166 = native_batch_norm_backward_default_3[1]
        getitem_167 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_165, add_tensor_57, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_165 = add_tensor_57 = primals_71 = None
        getitem_168 = convolution_backward_default_6[0]
        getitem_169 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(getitem_144, getitem_168);  getitem_144 = getitem_168 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_69, convolution_default_55, primals_292, primals_290, primals_291, getitem_124, getitem_125, True, 0.001, [True, True, True]);  convolution_default_55 = primals_292 = primals_290 = primals_291 = getitem_124 = getitem_125 = None
        getitem_171 = native_batch_norm_backward_default_4[0]
        getitem_172 = native_batch_norm_backward_default_4[1]
        getitem_173 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_171, mul_tensor_6, primals_65, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_171 = mul_tensor_6 = primals_65 = None
        getitem_174 = convolution_backward_default_7[0]
        getitem_175 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(getitem_174, hardswish__default_16);  hardswish__default_16 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(getitem_174, to_dtype_13);  getitem_174 = to_dtype_13 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_15, [2, 3], True);  mul_tensor_15 = None
        to_dtype_34 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_35 = torch.ops.aten.to.dtype(convolution_default_54, torch.float32);  convolution_default_54 = None
        gt_scalar_1 = torch.ops.aten.gt.Scalar(to_dtype_35, -3.0)
        lt_scalar_5 = torch.ops.aten.lt.Scalar(to_dtype_35, 3.0);  to_dtype_35 = None
        __and___tensor_1 = torch.ops.aten.__and__.Tensor(gt_scalar_1, lt_scalar_5);  gt_scalar_1 = lt_scalar_5 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.16666666666666666)
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_34, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_34 = None
        where_self_10 = torch.ops.aten.where.self(__and___tensor_1, mul_tensor_17, new_zeros_default_52);  __and___tensor_1 = mul_tensor_17 = new_zeros_default_52 = None
        to_dtype_36 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(to_dtype_36, relu__default_17, primals_67, [720], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_36 = primals_67 = None
        getitem_177 = convolution_backward_default_8[0]
        getitem_178 = convolution_backward_default_8[1]
        getitem_179 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_37 = torch.ops.aten.to.dtype(getitem_177, torch.float32);  getitem_177 = None
        to_dtype_38 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_38, 0);  to_dtype_38 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_37, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_53, to_dtype_37);  le_scalar_5 = new_zeros_default_53 = to_dtype_37 = None
        to_dtype_39 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(to_dtype_39, mean_dim_6, primals_69, [184], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_39 = mean_dim_6 = primals_69 = None
        getitem_180 = convolution_backward_default_9[0]
        getitem_181 = convolution_backward_default_9[1]
        getitem_182 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_180, [128, 720, 7, 7]);  getitem_180 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(mul_tensor_16, div_scalar_2);  mul_tensor_16 = div_scalar_2 = None
        to_dtype_40 = torch.ops.aten.to.dtype(add_tensor_70, torch.float32);  add_tensor_70 = None
        to_dtype_41 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        lt_scalar_6 = torch.ops.aten.lt.Scalar(to_dtype_41, -3)
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_40, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_41, 3)
        div_tensor_12 = torch.ops.aten.div.Tensor(to_dtype_41, 3);  to_dtype_41 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(div_tensor_12, 0.5);  div_tensor_12 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype_40, add_tensor_71);  add_tensor_71 = None
        where_self_12 = torch.ops.aten.where.self(le_scalar_6, mul_tensor_18, to_dtype_40);  le_scalar_6 = mul_tensor_18 = to_dtype_40 = None
        where_self_13 = torch.ops.aten.where.self(lt_scalar_6, new_zeros_default_54, where_self_12);  lt_scalar_6 = new_zeros_default_54 = where_self_12 = None
        to_dtype_42 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_42, convolution_default_52, primals_287, primals_285, primals_286, getitem_121, getitem_122, True, 0.001, [True, True, True]);  to_dtype_42 = convolution_default_52 = primals_287 = primals_285 = primals_286 = getitem_121 = getitem_122 = None
        getitem_183 = native_batch_norm_backward_default_5[0]
        getitem_184 = native_batch_norm_backward_default_5[1]
        getitem_185 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_183, hardswish__default_15, primals_63, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 720, [True, True, False]);  getitem_183 = hardswish__default_15 = primals_63 = None
        getitem_186 = convolution_backward_default_10[0]
        getitem_187 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_43 = torch.ops.aten.to.dtype(getitem_186, torch.float32);  getitem_186 = None
        to_dtype_44 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        lt_scalar_7 = torch.ops.aten.lt.Scalar(to_dtype_44, -3)
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_43, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_44, 3)
        div_tensor_13 = torch.ops.aten.div.Tensor(to_dtype_44, 3);  to_dtype_44 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(div_tensor_13, 0.5);  div_tensor_13 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_43, add_tensor_72);  add_tensor_72 = None
        where_self_14 = torch.ops.aten.where.self(le_scalar_7, mul_tensor_19, to_dtype_43);  le_scalar_7 = mul_tensor_19 = to_dtype_43 = None
        where_self_15 = torch.ops.aten.where.self(lt_scalar_7, new_zeros_default_55, where_self_14);  lt_scalar_7 = new_zeros_default_55 = where_self_14 = None
        to_dtype_45 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_45, convolution_default_51, primals_282, primals_280, primals_281, getitem_118, getitem_119, True, 0.001, [True, True, True]);  to_dtype_45 = convolution_default_51 = primals_282 = primals_280 = primals_281 = getitem_118 = getitem_119 = None
        getitem_189 = native_batch_norm_backward_default_6[0]
        getitem_190 = native_batch_norm_backward_default_6[1]
        getitem_191 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_189, getitem_114, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_189 = getitem_114 = primals_64 = None
        getitem_192 = convolution_backward_default_11[0]
        getitem_193 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(add_tensor_69, getitem_192);  add_tensor_69 = getitem_192 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_73, convolution_default_50, primals_277, primals_275, primals_276, getitem_115, getitem_116, True, 0.001, [True, True, True]);  add_tensor_73 = convolution_default_50 = primals_277 = primals_275 = primals_276 = getitem_115 = getitem_116 = None
        getitem_195 = native_batch_norm_backward_default_7[0]
        getitem_196 = native_batch_norm_backward_default_7[1]
        getitem_197 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_195, mul_tensor_5, primals_58, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_195 = mul_tensor_5 = primals_58 = None
        getitem_198 = convolution_backward_default_12[0]
        getitem_199 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(getitem_198, hardswish__default_14);  hardswish__default_14 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(getitem_198, to_dtype_11);  getitem_198 = to_dtype_11 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_20, [2, 3], True);  mul_tensor_20 = None
        to_dtype_46 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_47 = torch.ops.aten.to.dtype(convolution_default_49, torch.float32);  convolution_default_49 = None
        gt_scalar_2 = torch.ops.aten.gt.Scalar(to_dtype_47, -3.0)
        lt_scalar_8 = torch.ops.aten.lt.Scalar(to_dtype_47, 3.0);  to_dtype_47 = None
        __and___tensor_2 = torch.ops.aten.__and__.Tensor(gt_scalar_2, lt_scalar_8);  gt_scalar_2 = lt_scalar_8 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_46, 0.16666666666666666)
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_46, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_46 = None
        where_self_16 = torch.ops.aten.where.self(__and___tensor_2, mul_tensor_22, new_zeros_default_56);  __and___tensor_2 = mul_tensor_22 = new_zeros_default_56 = None
        to_dtype_48 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_48, relu__default_16, primals_60, [528], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_48 = primals_60 = None
        getitem_201 = convolution_backward_default_13[0]
        getitem_202 = convolution_backward_default_13[1]
        getitem_203 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_49 = torch.ops.aten.to.dtype(getitem_201, torch.float32);  getitem_201 = None
        to_dtype_50 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_50, 0);  to_dtype_50 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_49, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_57, to_dtype_49);  le_scalar_8 = new_zeros_default_57 = to_dtype_49 = None
        to_dtype_51 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(to_dtype_51, mean_dim_5, primals_62, [136], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_51 = mean_dim_5 = primals_62 = None
        getitem_204 = convolution_backward_default_14[0]
        getitem_205 = convolution_backward_default_14[1]
        getitem_206 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_204, [128, 528, 7, 7]);  getitem_204 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 49);  expand_default_3 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(mul_tensor_21, div_scalar_3);  mul_tensor_21 = div_scalar_3 = None
        to_dtype_52 = torch.ops.aten.to.dtype(add_tensor_74, torch.float32);  add_tensor_74 = None
        to_dtype_53 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        lt_scalar_9 = torch.ops.aten.lt.Scalar(to_dtype_53, -3)
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_52, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_53, 3)
        div_tensor_14 = torch.ops.aten.div.Tensor(to_dtype_53, 3);  to_dtype_53 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(div_tensor_14, 0.5);  div_tensor_14 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(to_dtype_52, add_tensor_75);  add_tensor_75 = None
        where_self_18 = torch.ops.aten.where.self(le_scalar_9, mul_tensor_23, to_dtype_52);  le_scalar_9 = mul_tensor_23 = to_dtype_52 = None
        where_self_19 = torch.ops.aten.where.self(lt_scalar_9, new_zeros_default_58, where_self_18);  lt_scalar_9 = new_zeros_default_58 = where_self_18 = None
        to_dtype_54 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_54, convolution_default_47, primals_272, primals_270, primals_271, getitem_112, getitem_113, True, 0.001, [True, True, True]);  to_dtype_54 = convolution_default_47 = primals_272 = primals_270 = primals_271 = getitem_112 = getitem_113 = None
        getitem_207 = native_batch_norm_backward_default_8[0]
        getitem_208 = native_batch_norm_backward_default_8[1]
        getitem_209 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_207, constant_pad_nd_default_4, primals_56, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 528, [True, True, False]);  getitem_207 = constant_pad_nd_default_4 = primals_56 = None
        getitem_210 = convolution_backward_default_15[0]
        getitem_211 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        constant_pad_nd_default_5 = torch.ops.aten.constant_pad_nd.default(getitem_210, [-1, -2, -1, -2]);  getitem_210 = None
        to_dtype_55 = torch.ops.aten.to.dtype(constant_pad_nd_default_5, torch.float32);  constant_pad_nd_default_5 = None
        to_dtype_56 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        lt_scalar_10 = torch.ops.aten.lt.Scalar(to_dtype_56, -3)
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_55, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_56, 3)
        div_tensor_15 = torch.ops.aten.div.Tensor(to_dtype_56, 3);  to_dtype_56 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(div_tensor_15, 0.5);  div_tensor_15 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(to_dtype_55, add_tensor_76);  add_tensor_76 = None
        where_self_20 = torch.ops.aten.where.self(le_scalar_10, mul_tensor_24, to_dtype_55);  le_scalar_10 = mul_tensor_24 = to_dtype_55 = None
        where_self_21 = torch.ops.aten.where.self(lt_scalar_10, new_zeros_default_59, where_self_20);  lt_scalar_10 = new_zeros_default_59 = where_self_20 = None
        to_dtype_57 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_57, convolution_default_46, primals_267, primals_265, primals_266, getitem_109, getitem_110, True, 0.001, [True, True, True]);  to_dtype_57 = convolution_default_46 = primals_267 = primals_265 = primals_266 = getitem_109 = getitem_110 = None
        getitem_213 = native_batch_norm_backward_default_9[0]
        getitem_214 = native_batch_norm_backward_default_9[1]
        getitem_215 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_213, add_tensor_48, primals_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_213 = add_tensor_48 = primals_57 = None
        getitem_216 = convolution_backward_default_16[0]
        getitem_217 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(getitem_216, convolution_default_45, primals_262, primals_260, primals_261, getitem_106, getitem_107, True, 0.001, [True, True, True]);  convolution_default_45 = primals_262 = primals_260 = primals_261 = getitem_106 = getitem_107 = None
        getitem_219 = native_batch_norm_backward_default_10[0]
        getitem_220 = native_batch_norm_backward_default_10[1]
        getitem_221 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_219, mul_tensor_4, primals_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_219 = mul_tensor_4 = primals_51 = None
        getitem_222 = convolution_backward_default_17[0]
        getitem_223 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(getitem_222, hardswish__default_12);  hardswish__default_12 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(getitem_222, to_dtype_9);  getitem_222 = to_dtype_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_25, [2, 3], True);  mul_tensor_25 = None
        to_dtype_58 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_59 = torch.ops.aten.to.dtype(convolution_default_44, torch.float32);  convolution_default_44 = None
        gt_scalar_3 = torch.ops.aten.gt.Scalar(to_dtype_59, -3.0)
        lt_scalar_11 = torch.ops.aten.lt.Scalar(to_dtype_59, 3.0);  to_dtype_59 = None
        __and___tensor_3 = torch.ops.aten.__and__.Tensor(gt_scalar_3, lt_scalar_11);  gt_scalar_3 = lt_scalar_11 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(to_dtype_58, 0.16666666666666666)
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_58, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_58 = None
        where_self_22 = torch.ops.aten.where.self(__and___tensor_3, mul_tensor_27, new_zeros_default_60);  __and___tensor_3 = mul_tensor_27 = new_zeros_default_60 = None
        to_dtype_60 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(to_dtype_60, relu__default_15, primals_53, [528], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_60 = primals_53 = None
        getitem_225 = convolution_backward_default_18[0]
        getitem_226 = convolution_backward_default_18[1]
        getitem_227 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        to_dtype_61 = torch.ops.aten.to.dtype(getitem_225, torch.float32);  getitem_225 = None
        to_dtype_62 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_62, 0);  to_dtype_62 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_61, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_61, to_dtype_61);  le_scalar_11 = new_zeros_default_61 = to_dtype_61 = None
        to_dtype_63 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(to_dtype_63, mean_dim_4, primals_55, [136], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_63 = mean_dim_4 = primals_55 = None
        getitem_228 = convolution_backward_default_19[0]
        getitem_229 = convolution_backward_default_19[1]
        getitem_230 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_228, [128, 528, 14, 14]);  getitem_228 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 196);  expand_default_4 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(mul_tensor_26, div_scalar_4);  mul_tensor_26 = div_scalar_4 = None
        to_dtype_64 = torch.ops.aten.to.dtype(add_tensor_77, torch.float32);  add_tensor_77 = None
        to_dtype_65 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        lt_scalar_12 = torch.ops.aten.lt.Scalar(to_dtype_65, -3)
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_64, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_65, 3)
        div_tensor_16 = torch.ops.aten.div.Tensor(to_dtype_65, 3);  to_dtype_65 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(div_tensor_16, 0.5);  div_tensor_16 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_64, add_tensor_78);  add_tensor_78 = None
        where_self_24 = torch.ops.aten.where.self(le_scalar_12, mul_tensor_28, to_dtype_64);  le_scalar_12 = mul_tensor_28 = to_dtype_64 = None
        where_self_25 = torch.ops.aten.where.self(lt_scalar_12, new_zeros_default_62, where_self_24);  lt_scalar_12 = new_zeros_default_62 = where_self_24 = None
        to_dtype_66 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_66, convolution_default_42, primals_257, primals_255, primals_256, getitem_103, getitem_104, True, 0.001, [True, True, True]);  to_dtype_66 = convolution_default_42 = primals_257 = primals_255 = primals_256 = getitem_103 = getitem_104 = None
        getitem_231 = native_batch_norm_backward_default_11[0]
        getitem_232 = native_batch_norm_backward_default_11[1]
        getitem_233 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_231, hardswish__default_11, primals_49, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 528, [True, True, False]);  getitem_231 = hardswish__default_11 = primals_49 = None
        getitem_234 = convolution_backward_default_20[0]
        getitem_235 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_67 = torch.ops.aten.to.dtype(getitem_234, torch.float32);  getitem_234 = None
        to_dtype_68 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        lt_scalar_13 = torch.ops.aten.lt.Scalar(to_dtype_68, -3)
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_67, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_68, 3)
        div_tensor_17 = torch.ops.aten.div.Tensor(to_dtype_68, 3);  to_dtype_68 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(div_tensor_17, 0.5);  div_tensor_17 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_67, add_tensor_79);  add_tensor_79 = None
        where_self_26 = torch.ops.aten.where.self(le_scalar_13, mul_tensor_29, to_dtype_67);  le_scalar_13 = mul_tensor_29 = to_dtype_67 = None
        where_self_27 = torch.ops.aten.where.self(lt_scalar_13, new_zeros_default_63, where_self_26);  lt_scalar_13 = new_zeros_default_63 = where_self_26 = None
        to_dtype_69 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_69, convolution_default_41, primals_252, primals_250, primals_251, getitem_100, getitem_101, True, 0.001, [True, True, True]);  to_dtype_69 = convolution_default_41 = primals_252 = primals_250 = primals_251 = getitem_100 = getitem_101 = None
        getitem_237 = native_batch_norm_backward_default_12[0]
        getitem_238 = native_batch_norm_backward_default_12[1]
        getitem_239 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_237, getitem_96, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_237 = getitem_96 = primals_50 = None
        getitem_240 = convolution_backward_default_21[0]
        getitem_241 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_216, getitem_240);  getitem_216 = getitem_240 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_80, convolution_default_40, primals_247, primals_245, primals_246, getitem_97, getitem_98, True, 0.001, [True, True, True]);  add_tensor_80 = convolution_default_40 = primals_247 = primals_245 = primals_246 = getitem_97 = getitem_98 = None
        getitem_243 = native_batch_norm_backward_default_13[0]
        getitem_244 = native_batch_norm_backward_default_13[1]
        getitem_245 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_243, mul_tensor_3, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_243 = mul_tensor_3 = primals_44 = None
        getitem_246 = convolution_backward_default_22[0]
        getitem_247 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(getitem_246, hardswish__default_10);  hardswish__default_10 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(getitem_246, to_dtype_7);  getitem_246 = to_dtype_7 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_30, [2, 3], True);  mul_tensor_30 = None
        to_dtype_70 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_71 = torch.ops.aten.to.dtype(convolution_default_39, torch.float32);  convolution_default_39 = None
        gt_scalar_4 = torch.ops.aten.gt.Scalar(to_dtype_71, -3.0)
        lt_scalar_14 = torch.ops.aten.lt.Scalar(to_dtype_71, 3.0);  to_dtype_71 = None
        __and___tensor_4 = torch.ops.aten.__and__.Tensor(gt_scalar_4, lt_scalar_14);  gt_scalar_4 = lt_scalar_14 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(to_dtype_70, 0.16666666666666666)
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_70, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_70 = None
        where_self_28 = torch.ops.aten.where.self(__and___tensor_4, mul_tensor_32, new_zeros_default_64);  __and___tensor_4 = mul_tensor_32 = new_zeros_default_64 = None
        to_dtype_72 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(to_dtype_72, relu__default_14, primals_46, [384], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_72 = primals_46 = None
        getitem_249 = convolution_backward_default_23[0]
        getitem_250 = convolution_backward_default_23[1]
        getitem_251 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_73 = torch.ops.aten.to.dtype(getitem_249, torch.float32);  getitem_249 = None
        to_dtype_74 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_74, 0);  to_dtype_74 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_73, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_65, to_dtype_73);  le_scalar_14 = new_zeros_default_65 = to_dtype_73 = None
        to_dtype_75 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(to_dtype_75, mean_dim_3, primals_48, [96], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_75 = mean_dim_3 = primals_48 = None
        getitem_252 = convolution_backward_default_24[0]
        getitem_253 = convolution_backward_default_24[1]
        getitem_254 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_252, [128, 384, 14, 14]);  getitem_252 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 196);  expand_default_5 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(mul_tensor_31, div_scalar_5);  mul_tensor_31 = div_scalar_5 = None
        to_dtype_76 = torch.ops.aten.to.dtype(add_tensor_81, torch.float32);  add_tensor_81 = None
        to_dtype_77 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        lt_scalar_15 = torch.ops.aten.lt.Scalar(to_dtype_77, -3)
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_76, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_77, 3)
        div_tensor_18 = torch.ops.aten.div.Tensor(to_dtype_77, 3);  to_dtype_77 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(div_tensor_18, 0.5);  div_tensor_18 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_76, add_tensor_82);  add_tensor_82 = None
        where_self_30 = torch.ops.aten.where.self(le_scalar_15, mul_tensor_33, to_dtype_76);  le_scalar_15 = mul_tensor_33 = to_dtype_76 = None
        where_self_31 = torch.ops.aten.where.self(lt_scalar_15, new_zeros_default_66, where_self_30);  lt_scalar_15 = new_zeros_default_66 = where_self_30 = None
        to_dtype_78 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_78, convolution_default_37, primals_242, primals_240, primals_241, getitem_94, getitem_95, True, 0.001, [True, True, True]);  to_dtype_78 = convolution_default_37 = primals_242 = primals_240 = primals_241 = getitem_94 = getitem_95 = None
        getitem_255 = native_batch_norm_backward_default_14[0]
        getitem_256 = native_batch_norm_backward_default_14[1]
        getitem_257 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_255, hardswish__default_9, primals_42, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 384, [True, True, False]);  getitem_255 = hardswish__default_9 = primals_42 = None
        getitem_258 = convolution_backward_default_25[0]
        getitem_259 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_79 = torch.ops.aten.to.dtype(getitem_258, torch.float32);  getitem_258 = None
        to_dtype_80 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        lt_scalar_16 = torch.ops.aten.lt.Scalar(to_dtype_80, -3)
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_79, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_80, 3)
        div_tensor_19 = torch.ops.aten.div.Tensor(to_dtype_80, 3);  to_dtype_80 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(div_tensor_19, 0.5);  div_tensor_19 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_79, add_tensor_83);  add_tensor_83 = None
        where_self_32 = torch.ops.aten.where.self(le_scalar_16, mul_tensor_34, to_dtype_79);  le_scalar_16 = mul_tensor_34 = to_dtype_79 = None
        where_self_33 = torch.ops.aten.where.self(lt_scalar_16, new_zeros_default_67, where_self_32);  lt_scalar_16 = new_zeros_default_67 = where_self_32 = None
        to_dtype_81 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_81, convolution_default_36, primals_237, primals_235, primals_236, getitem_91, getitem_92, True, 0.001, [True, True, True]);  to_dtype_81 = convolution_default_36 = primals_237 = primals_235 = primals_236 = getitem_91 = getitem_92 = None
        getitem_261 = native_batch_norm_backward_default_15[0]
        getitem_262 = native_batch_norm_backward_default_15[1]
        getitem_263 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_261, add_tensor_39, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_261 = add_tensor_39 = primals_43 = None
        getitem_264 = convolution_backward_default_26[0]
        getitem_265 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_264, convolution_default_35, primals_232, primals_230, primals_231, getitem_88, getitem_89, True, 0.001, [True, True, True]);  convolution_default_35 = primals_232 = primals_230 = primals_231 = getitem_88 = getitem_89 = None
        getitem_267 = native_batch_norm_backward_default_16[0]
        getitem_268 = native_batch_norm_backward_default_16[1]
        getitem_269 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_267, hardswish__default_8, primals_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_267 = hardswish__default_8 = primals_41 = None
        getitem_270 = convolution_backward_default_27[0]
        getitem_271 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        to_dtype_82 = torch.ops.aten.to.dtype(getitem_270, torch.float32);  getitem_270 = None
        to_dtype_83 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        lt_scalar_17 = torch.ops.aten.lt.Scalar(to_dtype_83, -3)
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_82, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_83, 3)
        div_tensor_20 = torch.ops.aten.div.Tensor(to_dtype_83, 3);  to_dtype_83 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(div_tensor_20, 0.5);  div_tensor_20 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_82, add_tensor_84);  add_tensor_84 = None
        where_self_34 = torch.ops.aten.where.self(le_scalar_17, mul_tensor_35, to_dtype_82);  le_scalar_17 = mul_tensor_35 = to_dtype_82 = None
        where_self_35 = torch.ops.aten.where.self(lt_scalar_17, new_zeros_default_68, where_self_34);  lt_scalar_17 = new_zeros_default_68 = where_self_34 = None
        to_dtype_84 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_84, convolution_default_34, primals_227, primals_225, primals_226, getitem_85, getitem_86, True, 0.001, [True, True, True]);  to_dtype_84 = convolution_default_34 = primals_227 = primals_225 = primals_226 = getitem_85 = getitem_86 = None
        getitem_273 = native_batch_norm_backward_default_17[0]
        getitem_274 = native_batch_norm_backward_default_17[1]
        getitem_275 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_273, hardswish__default_7, primals_39, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_273 = hardswish__default_7 = primals_39 = None
        getitem_276 = convolution_backward_default_28[0]
        getitem_277 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_85 = torch.ops.aten.to.dtype(getitem_276, torch.float32);  getitem_276 = None
        to_dtype_86 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        lt_scalar_18 = torch.ops.aten.lt.Scalar(to_dtype_86, -3)
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_85, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_86, 3)
        div_tensor_21 = torch.ops.aten.div.Tensor(to_dtype_86, 3);  to_dtype_86 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(div_tensor_21, 0.5);  div_tensor_21 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_85, add_tensor_85);  add_tensor_85 = None
        where_self_36 = torch.ops.aten.where.self(le_scalar_18, mul_tensor_36, to_dtype_85);  le_scalar_18 = mul_tensor_36 = to_dtype_85 = None
        where_self_37 = torch.ops.aten.where.self(lt_scalar_18, new_zeros_default_69, where_self_36);  lt_scalar_18 = new_zeros_default_69 = where_self_36 = None
        to_dtype_87 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_87, convolution_default_33, primals_222, primals_220, primals_221, getitem_82, getitem_83, True, 0.001, [True, True, True]);  to_dtype_87 = convolution_default_33 = primals_222 = primals_220 = primals_221 = getitem_82 = getitem_83 = None
        getitem_279 = native_batch_norm_backward_default_18[0]
        getitem_280 = native_batch_norm_backward_default_18[1]
        getitem_281 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_279, add_tensor_35, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_279 = add_tensor_35 = primals_40 = None
        getitem_282 = convolution_backward_default_29[0]
        getitem_283 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(getitem_264, getitem_282);  getitem_264 = getitem_282 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_86, convolution_default_32, primals_217, primals_215, primals_216, getitem_79, getitem_80, True, 0.001, [True, True, True]);  convolution_default_32 = primals_217 = primals_215 = primals_216 = getitem_79 = getitem_80 = None
        getitem_285 = native_batch_norm_backward_default_19[0]
        getitem_286 = native_batch_norm_backward_default_19[1]
        getitem_287 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_285, hardswish__default_6, primals_38, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_285 = hardswish__default_6 = primals_38 = None
        getitem_288 = convolution_backward_default_30[0]
        getitem_289 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        to_dtype_88 = torch.ops.aten.to.dtype(getitem_288, torch.float32);  getitem_288 = None
        to_dtype_89 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        lt_scalar_19 = torch.ops.aten.lt.Scalar(to_dtype_89, -3)
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_88, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_89, 3)
        div_tensor_22 = torch.ops.aten.div.Tensor(to_dtype_89, 3);  to_dtype_89 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(div_tensor_22, 0.5);  div_tensor_22 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_88, add_tensor_87);  add_tensor_87 = None
        where_self_38 = torch.ops.aten.where.self(le_scalar_19, mul_tensor_37, to_dtype_88);  le_scalar_19 = mul_tensor_37 = to_dtype_88 = None
        where_self_39 = torch.ops.aten.where.self(lt_scalar_19, new_zeros_default_70, where_self_38);  lt_scalar_19 = new_zeros_default_70 = where_self_38 = None
        to_dtype_90 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_90, convolution_default_31, primals_212, primals_210, primals_211, getitem_76, getitem_77, True, 0.001, [True, True, True]);  to_dtype_90 = convolution_default_31 = primals_212 = primals_210 = primals_211 = getitem_76 = getitem_77 = None
        getitem_291 = native_batch_norm_backward_default_20[0]
        getitem_292 = native_batch_norm_backward_default_20[1]
        getitem_293 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_291, hardswish__default_5, primals_36, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_291 = hardswish__default_5 = primals_36 = None
        getitem_294 = convolution_backward_default_31[0]
        getitem_295 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_91 = torch.ops.aten.to.dtype(getitem_294, torch.float32);  getitem_294 = None
        to_dtype_92 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        lt_scalar_20 = torch.ops.aten.lt.Scalar(to_dtype_92, -3)
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_91, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_92, 3)
        div_tensor_23 = torch.ops.aten.div.Tensor(to_dtype_92, 3);  to_dtype_92 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(div_tensor_23, 0.5);  div_tensor_23 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_91, add_tensor_88);  add_tensor_88 = None
        where_self_40 = torch.ops.aten.where.self(le_scalar_20, mul_tensor_38, to_dtype_91);  le_scalar_20 = mul_tensor_38 = to_dtype_91 = None
        where_self_41 = torch.ops.aten.where.self(lt_scalar_20, new_zeros_default_71, where_self_40);  lt_scalar_20 = new_zeros_default_71 = where_self_40 = None
        to_dtype_93 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_93, convolution_default_30, primals_207, primals_205, primals_206, getitem_73, getitem_74, True, 0.001, [True, True, True]);  to_dtype_93 = convolution_default_30 = primals_207 = primals_205 = primals_206 = getitem_73 = getitem_74 = None
        getitem_297 = native_batch_norm_backward_default_21[0]
        getitem_298 = native_batch_norm_backward_default_21[1]
        getitem_299 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_297, add_tensor_31, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_297 = add_tensor_31 = primals_37 = None
        getitem_300 = convolution_backward_default_32[0]
        getitem_301 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(add_tensor_86, getitem_300);  add_tensor_86 = getitem_300 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_89, convolution_default_29, primals_202, primals_200, primals_201, getitem_70, getitem_71, True, 0.001, [True, True, True]);  convolution_default_29 = primals_202 = primals_200 = primals_201 = getitem_70 = getitem_71 = None
        getitem_303 = native_batch_norm_backward_default_22[0]
        getitem_304 = native_batch_norm_backward_default_22[1]
        getitem_305 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_303, hardswish__default_4, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_303 = hardswish__default_4 = primals_35 = None
        getitem_306 = convolution_backward_default_33[0]
        getitem_307 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        to_dtype_94 = torch.ops.aten.to.dtype(getitem_306, torch.float32);  getitem_306 = None
        to_dtype_95 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        lt_scalar_21 = torch.ops.aten.lt.Scalar(to_dtype_95, -3)
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_94, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_95, 3)
        div_tensor_24 = torch.ops.aten.div.Tensor(to_dtype_95, 3);  to_dtype_95 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(div_tensor_24, 0.5);  div_tensor_24 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(to_dtype_94, add_tensor_90);  add_tensor_90 = None
        where_self_42 = torch.ops.aten.where.self(le_scalar_21, mul_tensor_39, to_dtype_94);  le_scalar_21 = mul_tensor_39 = to_dtype_94 = None
        where_self_43 = torch.ops.aten.where.self(lt_scalar_21, new_zeros_default_72, where_self_42);  lt_scalar_21 = new_zeros_default_72 = where_self_42 = None
        to_dtype_96 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_96, convolution_default_28, primals_197, primals_195, primals_196, getitem_67, getitem_68, True, 0.001, [True, True, True]);  to_dtype_96 = convolution_default_28 = primals_197 = primals_195 = primals_196 = getitem_67 = getitem_68 = None
        getitem_309 = native_batch_norm_backward_default_23[0]
        getitem_310 = native_batch_norm_backward_default_23[1]
        getitem_311 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_309, hardswish__default_3, primals_33, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 160, [True, True, False]);  getitem_309 = hardswish__default_3 = primals_33 = None
        getitem_312 = convolution_backward_default_34[0]
        getitem_313 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_97 = torch.ops.aten.to.dtype(getitem_312, torch.float32);  getitem_312 = None
        to_dtype_98 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        lt_scalar_22 = torch.ops.aten.lt.Scalar(to_dtype_98, -3)
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_97, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_98, 3)
        div_tensor_25 = torch.ops.aten.div.Tensor(to_dtype_98, 3);  to_dtype_98 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(div_tensor_25, 0.5);  div_tensor_25 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(to_dtype_97, add_tensor_91);  add_tensor_91 = None
        where_self_44 = torch.ops.aten.where.self(le_scalar_22, mul_tensor_40, to_dtype_97);  le_scalar_22 = mul_tensor_40 = to_dtype_97 = None
        where_self_45 = torch.ops.aten.where.self(lt_scalar_22, new_zeros_default_73, where_self_44);  lt_scalar_22 = new_zeros_default_73 = where_self_44 = None
        to_dtype_99 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_99, convolution_default_27, primals_192, primals_190, primals_191, getitem_64, getitem_65, True, 0.001, [True, True, True]);  to_dtype_99 = convolution_default_27 = primals_192 = primals_190 = primals_191 = getitem_64 = getitem_65 = None
        getitem_315 = native_batch_norm_backward_default_24[0]
        getitem_316 = native_batch_norm_backward_default_24[1]
        getitem_317 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_315, getitem_60, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_315 = getitem_60 = primals_34 = None
        getitem_318 = convolution_backward_default_35[0]
        getitem_319 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(add_tensor_89, getitem_318);  add_tensor_89 = getitem_318 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_92, convolution_default_26, primals_187, primals_185, primals_186, getitem_61, getitem_62, True, 0.001, [True, True, True]);  add_tensor_92 = convolution_default_26 = primals_187 = primals_185 = primals_186 = getitem_61 = getitem_62 = None
        getitem_321 = native_batch_norm_backward_default_25[0]
        getitem_322 = native_batch_norm_backward_default_25[1]
        getitem_323 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_321, hardswish__default_2, primals_32, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_321 = hardswish__default_2 = primals_32 = None
        getitem_324 = convolution_backward_default_36[0]
        getitem_325 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        to_dtype_100 = torch.ops.aten.to.dtype(getitem_324, torch.float32);  getitem_324 = None
        to_dtype_101 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        lt_scalar_23 = torch.ops.aten.lt.Scalar(to_dtype_101, -3)
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_100, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_101, 3)
        div_tensor_26 = torch.ops.aten.div.Tensor(to_dtype_101, 3);  to_dtype_101 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(div_tensor_26, 0.5);  div_tensor_26 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_100, add_tensor_93);  add_tensor_93 = None
        where_self_46 = torch.ops.aten.where.self(le_scalar_23, mul_tensor_41, to_dtype_100);  le_scalar_23 = mul_tensor_41 = to_dtype_100 = None
        where_self_47 = torch.ops.aten.where.self(lt_scalar_23, new_zeros_default_74, where_self_46);  lt_scalar_23 = new_zeros_default_74 = where_self_46 = None
        to_dtype_102 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_102, convolution_default_25, primals_182, primals_180, primals_181, getitem_58, getitem_59, True, 0.001, [True, True, True]);  to_dtype_102 = convolution_default_25 = primals_182 = primals_180 = primals_181 = getitem_58 = getitem_59 = None
        getitem_327 = native_batch_norm_backward_default_26[0]
        getitem_328 = native_batch_norm_backward_default_26[1]
        getitem_329 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_327, constant_pad_nd_default_3, primals_30, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_327 = constant_pad_nd_default_3 = primals_30 = None
        getitem_330 = convolution_backward_default_37[0]
        getitem_331 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        constant_pad_nd_default_6 = torch.ops.aten.constant_pad_nd.default(getitem_330, [0, -1, 0, -1]);  getitem_330 = None
        to_dtype_103 = torch.ops.aten.to.dtype(constant_pad_nd_default_6, torch.float32);  constant_pad_nd_default_6 = None
        to_dtype_104 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        lt_scalar_24 = torch.ops.aten.lt.Scalar(to_dtype_104, -3)
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_103, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_104, 3)
        div_tensor_27 = torch.ops.aten.div.Tensor(to_dtype_104, 3);  to_dtype_104 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(div_tensor_27, 0.5);  div_tensor_27 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_103, add_tensor_94);  add_tensor_94 = None
        where_self_48 = torch.ops.aten.where.self(le_scalar_24, mul_tensor_42, to_dtype_103);  le_scalar_24 = mul_tensor_42 = to_dtype_103 = None
        where_self_49 = torch.ops.aten.where.self(lt_scalar_24, new_zeros_default_75, where_self_48);  lt_scalar_24 = new_zeros_default_75 = where_self_48 = None
        to_dtype_105 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_105, convolution_default_24, primals_177, primals_175, primals_176, getitem_55, getitem_56, True, 0.001, [True, True, True]);  to_dtype_105 = convolution_default_24 = primals_177 = primals_175 = primals_176 = getitem_55 = getitem_56 = None
        getitem_333 = native_batch_norm_backward_default_27[0]
        getitem_334 = native_batch_norm_backward_default_27[1]
        getitem_335 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_333, add_tensor_24, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_333 = add_tensor_24 = primals_31 = None
        getitem_336 = convolution_backward_default_38[0]
        getitem_337 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(getitem_336, convolution_default_23, primals_172, primals_170, primals_171, getitem_52, getitem_53, True, 0.001, [True, True, True]);  convolution_default_23 = primals_172 = primals_170 = primals_171 = getitem_52 = getitem_53 = None
        getitem_339 = native_batch_norm_backward_default_28[0]
        getitem_340 = native_batch_norm_backward_default_28[1]
        getitem_341 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_339, mul_tensor_2, primals_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_339 = mul_tensor_2 = primals_25 = None
        getitem_342 = convolution_backward_default_39[0]
        getitem_343 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(getitem_342, relu__default_12)
        mul_tensor_44 = torch.ops.aten.mul.Tensor(getitem_342, to_dtype_5);  getitem_342 = to_dtype_5 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_43, [2, 3], True);  mul_tensor_43 = None
        to_dtype_106 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_107 = torch.ops.aten.to.dtype(convolution_default_22, torch.float32);  convolution_default_22 = None
        gt_scalar_5 = torch.ops.aten.gt.Scalar(to_dtype_107, -3.0)
        lt_scalar_25 = torch.ops.aten.lt.Scalar(to_dtype_107, 3.0);  to_dtype_107 = None
        __and___tensor_5 = torch.ops.aten.__and__.Tensor(gt_scalar_5, lt_scalar_25);  gt_scalar_5 = lt_scalar_25 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_106, 0.16666666666666666)
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_106, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_106 = None
        where_self_50 = torch.ops.aten.where.self(__and___tensor_5, mul_tensor_45, new_zeros_default_76);  __and___tensor_5 = mul_tensor_45 = new_zeros_default_76 = None
        to_dtype_108 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(to_dtype_108, relu__default_13, primals_27, [96], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_108 = primals_27 = None
        getitem_345 = convolution_backward_default_40[0]
        getitem_346 = convolution_backward_default_40[1]
        getitem_347 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_109 = torch.ops.aten.to.dtype(getitem_345, torch.float32);  getitem_345 = None
        to_dtype_110 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_110, 0);  to_dtype_110 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_109, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_77, to_dtype_109);  le_scalar_25 = new_zeros_default_77 = to_dtype_109 = None
        to_dtype_111 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(to_dtype_111, mean_dim_2, primals_29, [24], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_111 = mean_dim_2 = primals_29 = None
        getitem_348 = convolution_backward_default_41[0]
        getitem_349 = convolution_backward_default_41[1]
        getitem_350 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_348, [128, 96, 28, 28]);  getitem_348 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 784);  expand_default_6 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(mul_tensor_44, div_scalar_6);  mul_tensor_44 = div_scalar_6 = None
        to_dtype_112 = torch.ops.aten.to.dtype(add_tensor_95, torch.float32);  add_tensor_95 = None
        to_dtype_113 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_113, 0);  to_dtype_113 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_112, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_78, to_dtype_112);  le_scalar_26 = new_zeros_default_78 = to_dtype_112 = None
        to_dtype_114 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_114, convolution_default_20, primals_167, primals_165, primals_166, getitem_49, getitem_50, True, 0.001, [True, True, True]);  to_dtype_114 = convolution_default_20 = primals_167 = primals_165 = primals_166 = getitem_49 = getitem_50 = None
        getitem_351 = native_batch_norm_backward_default_29[0]
        getitem_352 = native_batch_norm_backward_default_29[1]
        getitem_353 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_351, relu__default_11, primals_23, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_351 = primals_23 = None
        getitem_354 = convolution_backward_default_42[0]
        getitem_355 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_115 = torch.ops.aten.to.dtype(getitem_354, torch.float32);  getitem_354 = None
        to_dtype_116 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_116, 0);  to_dtype_116 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_115, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_79, to_dtype_115);  le_scalar_27 = new_zeros_default_79 = to_dtype_115 = None
        to_dtype_117 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_117, convolution_default_19, primals_162, primals_160, primals_161, getitem_46, getitem_47, True, 0.001, [True, True, True]);  to_dtype_117 = convolution_default_19 = primals_162 = primals_160 = primals_161 = getitem_46 = getitem_47 = None
        getitem_357 = native_batch_norm_backward_default_30[0]
        getitem_358 = native_batch_norm_backward_default_30[1]
        getitem_359 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_357, add_tensor_19, primals_24, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_357 = add_tensor_19 = primals_24 = None
        getitem_360 = convolution_backward_default_43[0]
        getitem_361 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(getitem_336, getitem_360);  getitem_336 = getitem_360 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_96, convolution_default_18, primals_157, primals_155, primals_156, getitem_43, getitem_44, True, 0.001, [True, True, True]);  convolution_default_18 = primals_157 = primals_155 = primals_156 = getitem_43 = getitem_44 = None
        getitem_363 = native_batch_norm_backward_default_31[0]
        getitem_364 = native_batch_norm_backward_default_31[1]
        getitem_365 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_363, mul_tensor_1, primals_18, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_363 = mul_tensor_1 = primals_18 = None
        getitem_366 = convolution_backward_default_44[0]
        getitem_367 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(getitem_366, relu__default_9)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(getitem_366, to_dtype_3);  getitem_366 = to_dtype_3 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_46, [2, 3], True);  mul_tensor_46 = None
        to_dtype_118 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_119 = torch.ops.aten.to.dtype(convolution_default_17, torch.float32);  convolution_default_17 = None
        gt_scalar_6 = torch.ops.aten.gt.Scalar(to_dtype_119, -3.0)
        lt_scalar_26 = torch.ops.aten.lt.Scalar(to_dtype_119, 3.0);  to_dtype_119 = None
        __and___tensor_6 = torch.ops.aten.__and__.Tensor(gt_scalar_6, lt_scalar_26);  gt_scalar_6 = lt_scalar_26 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(to_dtype_118, 0.16666666666666666)
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_118, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_118 = None
        where_self_54 = torch.ops.aten.where.self(__and___tensor_6, mul_tensor_48, new_zeros_default_80);  __and___tensor_6 = mul_tensor_48 = new_zeros_default_80 = None
        to_dtype_120 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(to_dtype_120, relu__default_10, primals_20, [96], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_120 = primals_20 = None
        getitem_369 = convolution_backward_default_45[0]
        getitem_370 = convolution_backward_default_45[1]
        getitem_371 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        to_dtype_121 = torch.ops.aten.to.dtype(getitem_369, torch.float32);  getitem_369 = None
        to_dtype_122 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_122, 0);  to_dtype_122 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_121, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_81, to_dtype_121);  le_scalar_28 = new_zeros_default_81 = to_dtype_121 = None
        to_dtype_123 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(to_dtype_123, mean_dim_1, primals_22, [24], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_123 = mean_dim_1 = primals_22 = None
        getitem_372 = convolution_backward_default_46[0]
        getitem_373 = convolution_backward_default_46[1]
        getitem_374 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_372, [128, 96, 28, 28]);  getitem_372 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 784);  expand_default_7 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mul_tensor_47, div_scalar_7);  mul_tensor_47 = div_scalar_7 = None
        to_dtype_124 = torch.ops.aten.to.dtype(add_tensor_97, torch.float32);  add_tensor_97 = None
        to_dtype_125 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_125, 0);  to_dtype_125 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_124, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_82, to_dtype_124);  le_scalar_29 = new_zeros_default_82 = to_dtype_124 = None
        to_dtype_126 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_126, convolution_default_15, primals_152, primals_150, primals_151, getitem_40, getitem_41, True, 0.001, [True, True, True]);  to_dtype_126 = convolution_default_15 = primals_152 = primals_150 = primals_151 = getitem_40 = getitem_41 = None
        getitem_375 = native_batch_norm_backward_default_32[0]
        getitem_376 = native_batch_norm_backward_default_32[1]
        getitem_377 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_375, relu__default_8, primals_16, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_375 = primals_16 = None
        getitem_378 = convolution_backward_default_47[0]
        getitem_379 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        to_dtype_127 = torch.ops.aten.to.dtype(getitem_378, torch.float32);  getitem_378 = None
        to_dtype_128 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_128, 0);  to_dtype_128 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_127, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_83, to_dtype_127);  le_scalar_30 = new_zeros_default_83 = to_dtype_127 = None
        to_dtype_129 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_129, convolution_default_14, primals_147, primals_145, primals_146, getitem_37, getitem_38, True, 0.001, [True, True, True]);  to_dtype_129 = convolution_default_14 = primals_147 = primals_145 = primals_146 = getitem_37 = getitem_38 = None
        getitem_381 = native_batch_norm_backward_default_33[0]
        getitem_382 = native_batch_norm_backward_default_33[1]
        getitem_383 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_381, getitem_33, primals_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_381 = getitem_33 = primals_17 = None
        getitem_384 = convolution_backward_default_48[0]
        getitem_385 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(add_tensor_96, getitem_384);  add_tensor_96 = getitem_384 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_98, convolution_default_13, primals_142, primals_140, primals_141, getitem_34, getitem_35, True, 0.001, [True, True, True]);  add_tensor_98 = convolution_default_13 = primals_142 = primals_140 = primals_141 = getitem_34 = getitem_35 = None
        getitem_387 = native_batch_norm_backward_default_34[0]
        getitem_388 = native_batch_norm_backward_default_34[1]
        getitem_389 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_387, mul_tensor, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_387 = mul_tensor = primals_11 = None
        getitem_390 = convolution_backward_default_49[0]
        getitem_391 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(getitem_390, relu__default_6)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(getitem_390, to_dtype_1);  getitem_390 = to_dtype_1 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_49, [2, 3], True);  mul_tensor_49 = None
        to_dtype_130 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_131 = torch.ops.aten.to.dtype(convolution_default_12, torch.float32);  convolution_default_12 = None
        gt_scalar_7 = torch.ops.aten.gt.Scalar(to_dtype_131, -3.0)
        lt_scalar_27 = torch.ops.aten.lt.Scalar(to_dtype_131, 3.0);  to_dtype_131 = None
        __and___tensor_7 = torch.ops.aten.__and__.Tensor(gt_scalar_7, lt_scalar_27);  gt_scalar_7 = lt_scalar_27 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_130, 0.16666666666666666)
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_130, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False);  to_dtype_130 = None
        where_self_58 = torch.ops.aten.where.self(__and___tensor_7, mul_tensor_51, new_zeros_default_84);  __and___tensor_7 = mul_tensor_51 = new_zeros_default_84 = None
        to_dtype_132 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(to_dtype_132, relu__default_7, primals_13, [72], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_132 = primals_13 = None
        getitem_393 = convolution_backward_default_50[0]
        getitem_394 = convolution_backward_default_50[1]
        getitem_395 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_133 = torch.ops.aten.to.dtype(getitem_393, torch.float32);  getitem_393 = None
        to_dtype_134 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_134, 0);  to_dtype_134 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_133, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_85, to_dtype_133);  le_scalar_31 = new_zeros_default_85 = to_dtype_133 = None
        to_dtype_135 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(to_dtype_135, mean_dim, primals_15, [24], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_135 = mean_dim = primals_15 = None
        getitem_396 = convolution_backward_default_51[0]
        getitem_397 = convolution_backward_default_51[1]
        getitem_398 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_396, [128, 72, 28, 28]);  getitem_396 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 784);  expand_default_8 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(mul_tensor_50, div_scalar_8);  mul_tensor_50 = div_scalar_8 = None
        to_dtype_136 = torch.ops.aten.to.dtype(add_tensor_99, torch.float32);  add_tensor_99 = None
        to_dtype_137 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_137, 0);  to_dtype_137 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_136, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_86, to_dtype_136);  le_scalar_32 = new_zeros_default_86 = to_dtype_136 = None
        to_dtype_138 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_138, convolution_default_10, primals_137, primals_135, primals_136, getitem_31, getitem_32, True, 0.001, [True, True, True]);  to_dtype_138 = convolution_default_10 = primals_137 = primals_135 = primals_136 = getitem_31 = getitem_32 = None
        getitem_399 = native_batch_norm_backward_default_35[0]
        getitem_400 = native_batch_norm_backward_default_35[1]
        getitem_401 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_399, constant_pad_nd_default_2, primals_9, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 72, [True, True, False]);  getitem_399 = constant_pad_nd_default_2 = primals_9 = None
        getitem_402 = convolution_backward_default_52[0]
        getitem_403 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        constant_pad_nd_default_7 = torch.ops.aten.constant_pad_nd.default(getitem_402, [-1, -2, -1, -2]);  getitem_402 = None
        to_dtype_139 = torch.ops.aten.to.dtype(constant_pad_nd_default_7, torch.float32);  constant_pad_nd_default_7 = None
        to_dtype_140 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_140, 0);  to_dtype_140 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_139, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_87, to_dtype_139);  le_scalar_33 = new_zeros_default_87 = to_dtype_139 = None
        to_dtype_141 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_141, convolution_default_9, primals_132, primals_130, primals_131, getitem_28, getitem_29, True, 0.001, [True, True, True]);  to_dtype_141 = convolution_default_9 = primals_132 = primals_130 = primals_131 = getitem_28 = getitem_29 = None
        getitem_405 = native_batch_norm_backward_default_36[0]
        getitem_406 = native_batch_norm_backward_default_36[1]
        getitem_407 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_405, add_tensor_10, primals_10, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_405 = add_tensor_10 = primals_10 = None
        getitem_408 = convolution_backward_default_53[0]
        getitem_409 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(getitem_408, convolution_default_8, primals_127, primals_125, primals_126, getitem_25, getitem_26, True, 0.001, [True, True, True]);  convolution_default_8 = primals_127 = primals_125 = primals_126 = getitem_25 = getitem_26 = None
        getitem_411 = native_batch_norm_backward_default_37[0]
        getitem_412 = native_batch_norm_backward_default_37[1]
        getitem_413 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_411, relu__default_4, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_411 = primals_8 = None
        getitem_414 = convolution_backward_default_54[0]
        getitem_415 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        to_dtype_142 = torch.ops.aten.to.dtype(getitem_414, torch.float32);  getitem_414 = None
        to_dtype_143 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_143, 0);  to_dtype_143 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(to_dtype_142, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_88, to_dtype_142);  le_scalar_34 = new_zeros_default_88 = to_dtype_142 = None
        to_dtype_144 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_144, convolution_default_7, primals_122, primals_120, primals_121, getitem_22, getitem_23, True, 0.001, [True, True, True]);  to_dtype_144 = convolution_default_7 = primals_122 = primals_120 = primals_121 = getitem_22 = getitem_23 = None
        getitem_417 = native_batch_norm_backward_default_38[0]
        getitem_418 = native_batch_norm_backward_default_38[1]
        getitem_419 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_417, relu__default_3, primals_6, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 72, [True, True, False]);  getitem_417 = primals_6 = None
        getitem_420 = convolution_backward_default_55[0]
        getitem_421 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        to_dtype_145 = torch.ops.aten.to.dtype(getitem_420, torch.float32);  getitem_420 = None
        to_dtype_146 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_146, 0);  to_dtype_146 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(to_dtype_145, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_89, to_dtype_145);  le_scalar_35 = new_zeros_default_89 = to_dtype_145 = None
        to_dtype_147 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_147, convolution_default_6, primals_117, primals_115, primals_116, getitem_19, getitem_20, True, 0.001, [True, True, True]);  to_dtype_147 = convolution_default_6 = primals_117 = primals_115 = primals_116 = getitem_19 = getitem_20 = None
        getitem_423 = native_batch_norm_backward_default_39[0]
        getitem_424 = native_batch_norm_backward_default_39[1]
        getitem_425 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_423, getitem_15, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_423 = getitem_15 = primals_7 = None
        getitem_426 = convolution_backward_default_56[0]
        getitem_427 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(getitem_408, getitem_426);  getitem_408 = getitem_426 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_100, convolution_default_5, primals_112, primals_110, primals_111, getitem_16, getitem_17, True, 0.001, [True, True, True]);  add_tensor_100 = convolution_default_5 = primals_112 = primals_110 = primals_111 = getitem_16 = getitem_17 = None
        getitem_429 = native_batch_norm_backward_default_40[0]
        getitem_430 = native_batch_norm_backward_default_40[1]
        getitem_431 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_429, relu__default_2, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_429 = primals_5 = None
        getitem_432 = convolution_backward_default_57[0]
        getitem_433 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        to_dtype_148 = torch.ops.aten.to.dtype(getitem_432, torch.float32);  getitem_432 = None
        to_dtype_149 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_149, 0);  to_dtype_149 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(to_dtype_148, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_90, to_dtype_148);  le_scalar_36 = new_zeros_default_90 = to_dtype_148 = None
        to_dtype_150 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_150, convolution_default_4, primals_107, primals_105, primals_106, getitem_13, getitem_14, True, 0.001, [True, True, True]);  to_dtype_150 = convolution_default_4 = primals_107 = primals_105 = primals_106 = getitem_13 = getitem_14 = None
        getitem_435 = native_batch_norm_backward_default_41[0]
        getitem_436 = native_batch_norm_backward_default_41[1]
        getitem_437 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_435, constant_pad_nd_default_1, primals_3, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 64, [True, True, False]);  getitem_435 = constant_pad_nd_default_1 = primals_3 = None
        getitem_438 = convolution_backward_default_58[0]
        getitem_439 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        constant_pad_nd_default_8 = torch.ops.aten.constant_pad_nd.default(getitem_438, [0, -1, 0, -1]);  getitem_438 = None
        to_dtype_151 = torch.ops.aten.to.dtype(constant_pad_nd_default_8, torch.float32);  constant_pad_nd_default_8 = None
        to_dtype_152 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_152, 0);  to_dtype_152 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(to_dtype_151, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_91, to_dtype_151);  le_scalar_37 = new_zeros_default_91 = to_dtype_151 = None
        to_dtype_153 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_153, convolution_default_3, primals_102, primals_100, primals_101, getitem_10, getitem_11, True, 0.001, [True, True, True]);  to_dtype_153 = convolution_default_3 = primals_102 = primals_100 = primals_101 = getitem_10 = getitem_11 = None
        getitem_441 = native_batch_norm_backward_default_42[0]
        getitem_442 = native_batch_norm_backward_default_42[1]
        getitem_443 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_441, add_tensor_3, primals_4, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_441 = add_tensor_3 = primals_4 = None
        getitem_444 = convolution_backward_default_59[0]
        getitem_445 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(getitem_444, convolution_default_2, primals_97, primals_95, primals_96, getitem_7, getitem_8, True, 0.001, [True, True, True]);  convolution_default_2 = primals_97 = primals_95 = primals_96 = getitem_7 = getitem_8 = None
        getitem_447 = native_batch_norm_backward_default_43[0]
        getitem_448 = native_batch_norm_backward_default_43[1]
        getitem_449 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_447, relu__default, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_447 = primals_2 = None
        getitem_450 = convolution_backward_default_60[0]
        getitem_451 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        to_dtype_154 = torch.ops.aten.to.dtype(getitem_450, torch.float32);  getitem_450 = None
        to_dtype_155 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_155, 0);  to_dtype_155 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(to_dtype_154, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_92, to_dtype_154);  le_scalar_38 = new_zeros_default_92 = to_dtype_154 = None
        to_dtype_156 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_156, convolution_default_1, primals_92, primals_90, primals_91, getitem_4, getitem_5, True, 0.001, [True, True, True]);  to_dtype_156 = convolution_default_1 = primals_92 = primals_90 = primals_91 = getitem_4 = getitem_5 = None
        getitem_453 = native_batch_norm_backward_default_44[0]
        getitem_454 = native_batch_norm_backward_default_44[1]
        getitem_455 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_453, hardswish__default, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 16, [True, True, False]);  getitem_453 = hardswish__default = primals_1 = None
        getitem_456 = convolution_backward_default_61[0]
        getitem_457 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(getitem_444, getitem_456);  getitem_444 = getitem_456 = None
        to_dtype_157 = torch.ops.aten.to.dtype(add_tensor_101, torch.float32);  add_tensor_101 = None
        to_dtype_158 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        lt_scalar_28 = torch.ops.aten.lt.Scalar(to_dtype_158, -3)
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(to_dtype_157, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_158, 3)
        div_tensor_28 = torch.ops.aten.div.Tensor(to_dtype_158, 3);  to_dtype_158 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(div_tensor_28, 0.5);  div_tensor_28 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_157, add_tensor_102);  add_tensor_102 = None
        where_self_67 = torch.ops.aten.where.self(le_scalar_39, mul_tensor_52, to_dtype_157);  le_scalar_39 = mul_tensor_52 = to_dtype_157 = None
        where_self_68 = torch.ops.aten.where.self(lt_scalar_28, new_zeros_default_93, where_self_67);  lt_scalar_28 = new_zeros_default_93 = where_self_67 = None
        to_dtype_159 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_159, convolution_default, primals_87, primals_85, primals_86, getitem_1, getitem_2, True, 0.001, [True, True, True]);  to_dtype_159 = convolution_default = primals_87 = primals_85 = primals_86 = getitem_1 = getitem_2 = None
        getitem_459 = native_batch_norm_backward_default_45[0]
        getitem_460 = native_batch_norm_backward_default_45[1]
        getitem_461 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_459, constant_pad_nd_default, primals_82, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_459 = constant_pad_nd_default = primals_82 = None
        getitem_463 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        return [getitem_457, getitem_451, getitem_439, getitem_445, getitem_433, getitem_421, getitem_427, getitem_415, getitem_403, getitem_409, getitem_391, getitem_395, getitem_394, getitem_398, getitem_397, getitem_379, getitem_385, getitem_367, getitem_371, getitem_370, getitem_374, getitem_373, getitem_355, getitem_361, getitem_343, getitem_347, getitem_346, getitem_350, getitem_349, getitem_331, getitem_337, getitem_325, getitem_313, getitem_319, getitem_307, getitem_295, getitem_301, getitem_289, getitem_277, getitem_283, getitem_271, getitem_259, getitem_265, getitem_247, getitem_251, getitem_250, getitem_254, getitem_253, getitem_235, getitem_241, getitem_223, getitem_227, getitem_226, getitem_230, getitem_229, getitem_211, getitem_217, getitem_199, getitem_203, getitem_202, getitem_206, getitem_205, getitem_187, getitem_193, getitem_175, getitem_179, getitem_178, getitem_182, getitem_181, getitem_163, getitem_169, getitem_151, getitem_155, getitem_154, getitem_158, getitem_157, getitem_145, view_default_1, t_default_4, getitem_140, getitem_139, getitem_463, None, None, None, None, getitem_460, getitem_461, None, None, None, getitem_454, getitem_455, None, None, None, getitem_448, getitem_449, None, None, None, getitem_442, getitem_443, None, None, None, getitem_436, getitem_437, None, None, None, getitem_430, getitem_431, None, None, None, getitem_424, getitem_425, None, None, None, getitem_418, getitem_419, None, None, None, getitem_412, getitem_413, None, None, None, getitem_406, getitem_407, None, None, None, getitem_400, getitem_401, None, None, None, getitem_388, getitem_389, None, None, None, getitem_382, getitem_383, None, None, None, getitem_376, getitem_377, None, None, None, getitem_364, getitem_365, None, None, None, getitem_358, getitem_359, None, None, None, getitem_352, getitem_353, None, None, None, getitem_340, getitem_341, None, None, None, getitem_334, getitem_335, None, None, None, getitem_328, getitem_329, None, None, None, getitem_322, getitem_323, None, None, None, getitem_316, getitem_317, None, None, None, getitem_310, getitem_311, None, None, None, getitem_304, getitem_305, None, None, None, getitem_298, getitem_299, None, None, None, getitem_292, getitem_293, None, None, None, getitem_286, getitem_287, None, None, None, getitem_280, getitem_281, None, None, None, getitem_274, getitem_275, None, None, None, getitem_268, getitem_269, None, None, None, getitem_262, getitem_263, None, None, None, getitem_256, getitem_257, None, None, None, getitem_244, getitem_245, None, None, None, getitem_238, getitem_239, None, None, None, getitem_232, getitem_233, None, None, None, getitem_220, getitem_221, None, None, None, getitem_214, getitem_215, None, None, None, getitem_208, getitem_209, None, None, None, getitem_196, getitem_197, None, None, None, getitem_190, getitem_191, None, None, None, getitem_184, getitem_185, None, None, None, getitem_172, getitem_173, None, None, None, getitem_166, getitem_167, None, None, None, getitem_160, getitem_161, None, None, None, getitem_148, getitem_149, None, None, None, getitem_142, getitem_143]
        
