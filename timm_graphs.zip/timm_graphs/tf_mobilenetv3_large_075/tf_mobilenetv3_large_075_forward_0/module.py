
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/tf_mobilenetv3_large_075/tf_mobilenetv3_large_075_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313):
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(primals_83, [0, 1, 0, 1], 0.0);  primals_83 = None
        convolution_default = torch.ops.aten.convolution.default(constant_pad_nd_default, primals_82, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_84, 1);  primals_84 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_87, primals_88, primals_85, primals_86, True, 0.1, 0.001);  primals_88 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        hardswish__default = torch.ops.aten.hardswish_.default(getitem)
        convolution_default_1 = torch.ops.aten.convolution.default(hardswish__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 16)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_89, 1);  primals_89 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_92, primals_93, primals_90, primals_91, True, 0.1, 0.001);  primals_93 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_94, 1);  primals_94 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_97, primals_98, primals_95, primals_96, True, 0.1, 0.001);  primals_98 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_6, hardswish__default);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(add_tensor_3, primals_4, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_99, 1);  primals_99 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_102, primals_103, primals_100, primals_101, True, 0.1, 0.001);  primals_103 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_9);  getitem_9 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(relu__default_1, [0, 1, 0, 1], 0.0)
        convolution_default_4 = torch.ops.aten.convolution.default(constant_pad_nd_default_1, primals_3, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 64)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_104, 1);  primals_104 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_107, primals_108, primals_105, primals_106, True, 0.1, 0.001);  primals_108 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_2, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_109, 1);  primals_109 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_112, primals_113, primals_110, primals_111, True, 0.1, 0.001);  primals_113 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_114, 1);  primals_114 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_117, primals_118, primals_115, primals_116, True, 0.1, 0.001);  primals_118 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_18);  getitem_18 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_3, primals_6, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 72)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_119, 1);  primals_119 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_122, primals_123, primals_120, primals_121, True, 0.1, 0.001);  primals_123 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_4, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_124, 1);  primals_124 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_127, primals_128, primals_125, primals_126, True, 0.1, 0.001);  primals_128 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_24, getitem_15);  getitem_24 = None
        convolution_default_9 = torch.ops.aten.convolution.default(add_tensor_10, primals_10, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_129, 1);  primals_129 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_132, primals_133, primals_130, primals_131, True, 0.1, 0.001);  primals_133 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        constant_pad_nd_default_2 = torch.ops.aten.constant_pad_nd.default(relu__default_5, [1, 2, 1, 2], 0.0)
        convolution_default_10 = torch.ops.aten.convolution.default(constant_pad_nd_default_2, primals_9, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 72)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_134, 1);  primals_134 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_137, primals_138, primals_135, primals_136, True, 0.1, 0.001);  primals_138 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_6, [2, 3], True)
        convolution_default_11 = torch.ops.aten.convolution.default(mean_dim, primals_15, primals_14, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_14 = None
        relu__default_7 = torch.ops.aten.relu_.default(convolution_default_11);  convolution_default_11 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_7, primals_13, primals_12, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_12 = None
        to_dtype = torch.ops.aten.to.dtype(convolution_default_12, torch.float32)
        add_tensor_13 = torch.ops.aten.add.Tensor(to_dtype, 3);  to_dtype = None
        clamp_default = torch.ops.aten.clamp.default(add_tensor_13, 0);  add_tensor_13 = None
        clamp_default_1 = torch.ops.aten.clamp.default(clamp_default, None, 6);  clamp_default = None
        div_tensor = torch.ops.aten.div.Tensor(clamp_default_1, 6);  clamp_default_1 = None
        to_dtype_1 = torch.ops.aten.to.dtype(div_tensor, torch.float32);  div_tensor = None
        mul_tensor = torch.ops.aten.mul.Tensor(relu__default_6, to_dtype_1)
        convolution_default_13 = torch.ops.aten.convolution.default(mul_tensor, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_139, 1);  primals_139 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_142, primals_143, primals_140, primals_141, True, 0.1, 0.001);  primals_143 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        convolution_default_14 = torch.ops.aten.convolution.default(getitem_33, primals_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_144, 1);  primals_144 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_147, primals_148, primals_145, primals_146, True, 0.1, 0.001);  primals_148 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_36);  getitem_36 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_8, primals_16, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 96)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_149, 1);  primals_149 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_152, primals_153, primals_150, primals_151, True, 0.1, 0.001);  primals_153 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        mean_dim_1 = torch.ops.aten.mean.dim(relu__default_9, [2, 3], True)
        convolution_default_16 = torch.ops.aten.convolution.default(mean_dim_1, primals_22, primals_21, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_21 = None
        relu__default_10 = torch.ops.aten.relu_.default(convolution_default_16);  convolution_default_16 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_10, primals_20, primals_19, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_19 = None
        to_dtype_2 = torch.ops.aten.to.dtype(convolution_default_17, torch.float32)
        add_tensor_17 = torch.ops.aten.add.Tensor(to_dtype_2, 3);  to_dtype_2 = None
        clamp_default_2 = torch.ops.aten.clamp.default(add_tensor_17, 0);  add_tensor_17 = None
        clamp_default_3 = torch.ops.aten.clamp.default(clamp_default_2, None, 6);  clamp_default_2 = None
        div_tensor_1 = torch.ops.aten.div.Tensor(clamp_default_3, 6);  clamp_default_3 = None
        to_dtype_3 = torch.ops.aten.to.dtype(div_tensor_1, torch.float32);  div_tensor_1 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(relu__default_9, to_dtype_3)
        convolution_default_18 = torch.ops.aten.convolution.default(mul_tensor_1, primals_18, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_154, 1);  primals_154 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_157, primals_158, primals_155, primals_156, True, 0.1, 0.001);  primals_158 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(getitem_42, getitem_33);  getitem_42 = None
        convolution_default_19 = torch.ops.aten.convolution.default(add_tensor_19, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_159, 1);  primals_159 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_162, primals_163, primals_160, primals_161, True, 0.1, 0.001);  primals_163 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_45);  getitem_45 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_11, primals_23, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 96)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_164, 1);  primals_164 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_167, primals_168, primals_165, primals_166, True, 0.1, 0.001);  primals_168 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        mean_dim_2 = torch.ops.aten.mean.dim(relu__default_12, [2, 3], True)
        convolution_default_21 = torch.ops.aten.convolution.default(mean_dim_2, primals_29, primals_28, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_28 = None
        relu__default_13 = torch.ops.aten.relu_.default(convolution_default_21);  convolution_default_21 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_13, primals_27, primals_26, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_26 = None
        to_dtype_4 = torch.ops.aten.to.dtype(convolution_default_22, torch.float32)
        add_tensor_22 = torch.ops.aten.add.Tensor(to_dtype_4, 3);  to_dtype_4 = None
        clamp_default_4 = torch.ops.aten.clamp.default(add_tensor_22, 0);  add_tensor_22 = None
        clamp_default_5 = torch.ops.aten.clamp.default(clamp_default_4, None, 6);  clamp_default_4 = None
        div_tensor_2 = torch.ops.aten.div.Tensor(clamp_default_5, 6);  clamp_default_5 = None
        to_dtype_5 = torch.ops.aten.to.dtype(div_tensor_2, torch.float32);  div_tensor_2 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(relu__default_12, to_dtype_5)
        convolution_default_23 = torch.ops.aten.convolution.default(mul_tensor_2, primals_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_169, 1);  primals_169 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_172, primals_173, primals_170, primals_171, True, 0.1, 0.001);  primals_173 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(getitem_51, add_tensor_19);  getitem_51 = None
        convolution_default_24 = torch.ops.aten.convolution.default(add_tensor_24, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_174, 1);  primals_174 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_177, primals_178, primals_175, primals_176, True, 0.1, 0.001);  primals_178 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        hardswish__default_1 = torch.ops.aten.hardswish_.default(getitem_54)
        constant_pad_nd_default_3 = torch.ops.aten.constant_pad_nd.default(hardswish__default_1, [0, 1, 0, 1], 0.0);  hardswish__default_1 = None
        convolution_default_25 = torch.ops.aten.convolution.default(constant_pad_nd_default_3, primals_30, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 192)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_179, 1);  primals_179 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_182, primals_183, primals_180, primals_181, True, 0.1, 0.001);  primals_183 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        hardswish__default_2 = torch.ops.aten.hardswish_.default(getitem_57)
        convolution_default_26 = torch.ops.aten.convolution.default(hardswish__default_2, primals_32, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_27 = torch.ops.aten.add.Tensor(primals_184, 1);  primals_184 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_187, primals_188, primals_185, primals_186, True, 0.1, 0.001);  primals_188 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        convolution_default_27 = torch.ops.aten.convolution.default(getitem_60, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_189, 1);  primals_189 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_192, primals_193, primals_190, primals_191, True, 0.1, 0.001);  primals_193 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        hardswish__default_3 = torch.ops.aten.hardswish_.default(getitem_63)
        convolution_default_28 = torch.ops.aten.convolution.default(hardswish__default_3, primals_33, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 160)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_194, 1);  primals_194 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_197, primals_198, primals_195, primals_196, True, 0.1, 0.001);  primals_198 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        hardswish__default_4 = torch.ops.aten.hardswish_.default(getitem_66)
        convolution_default_29 = torch.ops.aten.convolution.default(hardswish__default_4, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_199, 1);  primals_199 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_202, primals_203, primals_200, primals_201, True, 0.1, 0.001);  primals_203 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(getitem_69, getitem_60);  getitem_69 = None
        convolution_default_30 = torch.ops.aten.convolution.default(add_tensor_31, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_204, 1);  primals_204 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_207, primals_208, primals_205, primals_206, True, 0.1, 0.001);  primals_208 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        hardswish__default_5 = torch.ops.aten.hardswish_.default(getitem_72)
        convolution_default_31 = torch.ops.aten.convolution.default(hardswish__default_5, primals_36, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_209, 1);  primals_209 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_212, primals_213, primals_210, primals_211, True, 0.1, 0.001);  primals_213 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        hardswish__default_6 = torch.ops.aten.hardswish_.default(getitem_75)
        convolution_default_32 = torch.ops.aten.convolution.default(hardswish__default_6, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_34 = torch.ops.aten.add.Tensor(primals_214, 1);  primals_214 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_217, primals_218, primals_215, primals_216, True, 0.1, 0.001);  primals_218 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_78, add_tensor_31);  getitem_78 = None
        convolution_default_33 = torch.ops.aten.convolution.default(add_tensor_35, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_219, 1);  primals_219 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_222, primals_223, primals_220, primals_221, True, 0.1, 0.001);  primals_223 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        hardswish__default_7 = torch.ops.aten.hardswish_.default(getitem_81)
        convolution_default_34 = torch.ops.aten.convolution.default(hardswish__default_7, primals_39, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 144)
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_224, 1);  primals_224 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_227, primals_228, primals_225, primals_226, True, 0.1, 0.001);  primals_228 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        hardswish__default_8 = torch.ops.aten.hardswish_.default(getitem_84)
        convolution_default_35 = torch.ops.aten.convolution.default(hardswish__default_8, primals_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_38 = torch.ops.aten.add.Tensor(primals_229, 1);  primals_229 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_232, primals_233, primals_230, primals_231, True, 0.1, 0.001);  primals_233 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(getitem_87, add_tensor_35);  getitem_87 = None
        convolution_default_36 = torch.ops.aten.convolution.default(add_tensor_39, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_234, 1);  primals_234 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_237, primals_238, primals_235, primals_236, True, 0.1, 0.001);  primals_238 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        hardswish__default_9 = torch.ops.aten.hardswish_.default(getitem_90)
        convolution_default_37 = torch.ops.aten.convolution.default(hardswish__default_9, primals_42, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 384)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_239, 1);  primals_239 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_242, primals_243, primals_240, primals_241, True, 0.1, 0.001);  primals_243 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        hardswish__default_10 = torch.ops.aten.hardswish_.default(getitem_93)
        mean_dim_3 = torch.ops.aten.mean.dim(hardswish__default_10, [2, 3], True)
        convolution_default_38 = torch.ops.aten.convolution.default(mean_dim_3, primals_48, primals_47, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_47 = None
        relu__default_14 = torch.ops.aten.relu_.default(convolution_default_38);  convolution_default_38 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_14, primals_46, primals_45, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_45 = None
        to_dtype_6 = torch.ops.aten.to.dtype(convolution_default_39, torch.float32)
        add_tensor_42 = torch.ops.aten.add.Tensor(to_dtype_6, 3);  to_dtype_6 = None
        clamp_default_6 = torch.ops.aten.clamp.default(add_tensor_42, 0);  add_tensor_42 = None
        clamp_default_7 = torch.ops.aten.clamp.default(clamp_default_6, None, 6);  clamp_default_6 = None
        div_tensor_3 = torch.ops.aten.div.Tensor(clamp_default_7, 6);  clamp_default_7 = None
        to_dtype_7 = torch.ops.aten.to.dtype(div_tensor_3, torch.float32);  div_tensor_3 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(hardswish__default_10, to_dtype_7)
        convolution_default_40 = torch.ops.aten.convolution.default(mul_tensor_3, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_244, 1);  primals_244 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_247, primals_248, primals_245, primals_246, True, 0.1, 0.001);  primals_248 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        convolution_default_41 = torch.ops.aten.convolution.default(getitem_96, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_249, 1);  primals_249 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_252, primals_253, primals_250, primals_251, True, 0.1, 0.001);  primals_253 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        hardswish__default_11 = torch.ops.aten.hardswish_.default(getitem_99)
        convolution_default_42 = torch.ops.aten.convolution.default(hardswish__default_11, primals_49, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 528)
        add_tensor_45 = torch.ops.aten.add.Tensor(primals_254, 1);  primals_254 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_257, primals_258, primals_255, primals_256, True, 0.1, 0.001);  primals_258 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        hardswish__default_12 = torch.ops.aten.hardswish_.default(getitem_102)
        mean_dim_4 = torch.ops.aten.mean.dim(hardswish__default_12, [2, 3], True)
        convolution_default_43 = torch.ops.aten.convolution.default(mean_dim_4, primals_55, primals_54, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_54 = None
        relu__default_15 = torch.ops.aten.relu_.default(convolution_default_43);  convolution_default_43 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_15, primals_53, primals_52, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_52 = None
        to_dtype_8 = torch.ops.aten.to.dtype(convolution_default_44, torch.float32)
        add_tensor_46 = torch.ops.aten.add.Tensor(to_dtype_8, 3);  to_dtype_8 = None
        clamp_default_8 = torch.ops.aten.clamp.default(add_tensor_46, 0);  add_tensor_46 = None
        clamp_default_9 = torch.ops.aten.clamp.default(clamp_default_8, None, 6);  clamp_default_8 = None
        div_tensor_4 = torch.ops.aten.div.Tensor(clamp_default_9, 6);  clamp_default_9 = None
        to_dtype_9 = torch.ops.aten.to.dtype(div_tensor_4, torch.float32);  div_tensor_4 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(hardswish__default_12, to_dtype_9)
        convolution_default_45 = torch.ops.aten.convolution.default(mul_tensor_4, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_259, 1);  primals_259 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_262, primals_263, primals_260, primals_261, True, 0.1, 0.001);  primals_263 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(getitem_105, getitem_96);  getitem_105 = None
        convolution_default_46 = torch.ops.aten.convolution.default(add_tensor_48, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_49 = torch.ops.aten.add.Tensor(primals_264, 1);  primals_264 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_267, primals_268, primals_265, primals_266, True, 0.1, 0.001);  primals_268 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        hardswish__default_13 = torch.ops.aten.hardswish_.default(getitem_108)
        constant_pad_nd_default_4 = torch.ops.aten.constant_pad_nd.default(hardswish__default_13, [1, 2, 1, 2], 0.0);  hardswish__default_13 = None
        convolution_default_47 = torch.ops.aten.convolution.default(constant_pad_nd_default_4, primals_56, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 528)
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_269, 1);  primals_269 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_272, primals_273, primals_270, primals_271, True, 0.1, 0.001);  primals_273 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        hardswish__default_14 = torch.ops.aten.hardswish_.default(getitem_111)
        mean_dim_5 = torch.ops.aten.mean.dim(hardswish__default_14, [2, 3], True)
        convolution_default_48 = torch.ops.aten.convolution.default(mean_dim_5, primals_62, primals_61, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_61 = None
        relu__default_16 = torch.ops.aten.relu_.default(convolution_default_48);  convolution_default_48 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_16, primals_60, primals_59, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_59 = None
        to_dtype_10 = torch.ops.aten.to.dtype(convolution_default_49, torch.float32)
        add_tensor_51 = torch.ops.aten.add.Tensor(to_dtype_10, 3);  to_dtype_10 = None
        clamp_default_10 = torch.ops.aten.clamp.default(add_tensor_51, 0);  add_tensor_51 = None
        clamp_default_11 = torch.ops.aten.clamp.default(clamp_default_10, None, 6);  clamp_default_10 = None
        div_tensor_5 = torch.ops.aten.div.Tensor(clamp_default_11, 6);  clamp_default_11 = None
        to_dtype_11 = torch.ops.aten.to.dtype(div_tensor_5, torch.float32);  div_tensor_5 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(hardswish__default_14, to_dtype_11)
        convolution_default_50 = torch.ops.aten.convolution.default(mul_tensor_5, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_274, 1);  primals_274 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_277, primals_278, primals_275, primals_276, True, 0.1, 0.001);  primals_278 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        convolution_default_51 = torch.ops.aten.convolution.default(getitem_114, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_53 = torch.ops.aten.add.Tensor(primals_279, 1);  primals_279 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_282, primals_283, primals_280, primals_281, True, 0.1, 0.001);  primals_283 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        hardswish__default_15 = torch.ops.aten.hardswish_.default(getitem_117)
        convolution_default_52 = torch.ops.aten.convolution.default(hardswish__default_15, primals_63, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 720)
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_284, 1);  primals_284 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_287, primals_288, primals_285, primals_286, True, 0.1, 0.001);  primals_288 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        hardswish__default_16 = torch.ops.aten.hardswish_.default(getitem_120)
        mean_dim_6 = torch.ops.aten.mean.dim(hardswish__default_16, [2, 3], True)
        convolution_default_53 = torch.ops.aten.convolution.default(mean_dim_6, primals_69, primals_68, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_68 = None
        relu__default_17 = torch.ops.aten.relu_.default(convolution_default_53);  convolution_default_53 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_17, primals_67, primals_66, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_66 = None
        to_dtype_12 = torch.ops.aten.to.dtype(convolution_default_54, torch.float32)
        add_tensor_55 = torch.ops.aten.add.Tensor(to_dtype_12, 3);  to_dtype_12 = None
        clamp_default_12 = torch.ops.aten.clamp.default(add_tensor_55, 0);  add_tensor_55 = None
        clamp_default_13 = torch.ops.aten.clamp.default(clamp_default_12, None, 6);  clamp_default_12 = None
        div_tensor_6 = torch.ops.aten.div.Tensor(clamp_default_13, 6);  clamp_default_13 = None
        to_dtype_13 = torch.ops.aten.to.dtype(div_tensor_6, torch.float32);  div_tensor_6 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(hardswish__default_16, to_dtype_13)
        convolution_default_55 = torch.ops.aten.convolution.default(mul_tensor_6, primals_65, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_289, 1);  primals_289 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_292, primals_293, primals_290, primals_291, True, 0.1, 0.001);  primals_293 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(getitem_123, getitem_114);  getitem_123 = None
        convolution_default_56 = torch.ops.aten.convolution.default(add_tensor_57, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_58 = torch.ops.aten.add.Tensor(primals_294, 1);  primals_294 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_297, primals_298, primals_295, primals_296, True, 0.1, 0.001);  primals_298 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        hardswish__default_17 = torch.ops.aten.hardswish_.default(getitem_126)
        convolution_default_57 = torch.ops.aten.convolution.default(hardswish__default_17, primals_70, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 720)
        add_tensor_59 = torch.ops.aten.add.Tensor(primals_299, 1);  primals_299 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_302, primals_303, primals_300, primals_301, True, 0.1, 0.001);  primals_303 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        hardswish__default_18 = torch.ops.aten.hardswish_.default(getitem_129)
        mean_dim_7 = torch.ops.aten.mean.dim(hardswish__default_18, [2, 3], True)
        convolution_default_58 = torch.ops.aten.convolution.default(mean_dim_7, primals_76, primals_75, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_75 = None
        relu__default_18 = torch.ops.aten.relu_.default(convolution_default_58);  convolution_default_58 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_18, primals_74, primals_73, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_73 = None
        to_dtype_14 = torch.ops.aten.to.dtype(convolution_default_59, torch.float32)
        add_tensor_60 = torch.ops.aten.add.Tensor(to_dtype_14, 3);  to_dtype_14 = None
        clamp_default_14 = torch.ops.aten.clamp.default(add_tensor_60, 0);  add_tensor_60 = None
        clamp_default_15 = torch.ops.aten.clamp.default(clamp_default_14, None, 6);  clamp_default_14 = None
        div_tensor_7 = torch.ops.aten.div.Tensor(clamp_default_15, 6);  clamp_default_15 = None
        to_dtype_15 = torch.ops.aten.to.dtype(div_tensor_7, torch.float32);  div_tensor_7 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(hardswish__default_18, to_dtype_15)
        convolution_default_60 = torch.ops.aten.convolution.default(mul_tensor_7, primals_72, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_304, 1);  primals_304 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_307, primals_308, primals_305, primals_306, True, 0.1, 0.001);  primals_308 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_132, add_tensor_57);  getitem_132 = None
        convolution_default_61 = torch.ops.aten.convolution.default(add_tensor_62, primals_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_63 = torch.ops.aten.add.Tensor(primals_309, 1);  primals_309 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_312, primals_313, primals_310, primals_311, True, 0.1, 0.001);  primals_313 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        hardswish__default_19 = torch.ops.aten.hardswish_.default(getitem_135)
        mean_dim_8 = torch.ops.aten.mean.dim(hardswish__default_19, [-1, -2], True);  hardswish__default_19 = None
        convolution_default_62 = torch.ops.aten.convolution.default(mean_dim_8, primals_81, primals_80, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_80 = None
        hardswish__default_20 = torch.ops.aten.hardswish_.default(convolution_default_62)
        view_default = torch.ops.aten.view.default(hardswish__default_20, [128, 1280]);  hardswish__default_20 = None
        t_default = torch.ops.aten.t.default(primals_79);  primals_79 = None
        addmm_default = torch.ops.aten.addmm.default(primals_78, view_default, t_default);  primals_78 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_11, add_tensor_12, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_18, add_tensor_20, add_tensor_21, add_tensor_23, add_tensor_25, add_tensor_26, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_32, add_tensor_33, add_tensor_34, add_tensor_36, add_tensor_37, add_tensor_38, add_tensor_40, add_tensor_41, add_tensor_43, add_tensor_44, add_tensor_45, add_tensor_47, add_tensor_49, add_tensor_50, add_tensor_52, add_tensor_53, add_tensor_54, add_tensor_56, add_tensor_58, add_tensor_59, add_tensor_61, add_tensor_63, convolution_default_24, primals_250, convolution_default_25, primals_157, primals_200, primals_15, primals_201, primals_152, primals_247, getitem_53, primals_39, primals_151, getitem_13, getitem_15, getitem_98, getitem_14, primals_251, getitem_97, convolution_default_14, primals_252, to_dtype_5, primals_41, getitem_52, relu__default_2, primals_150, getitem_54, primals_196, convolution_default_5, primals_161, primals_237, primals_40, getitem_55, primals_38, to_dtype_7, convolution_default_40, primals_202, constant_pad_nd_default_3, primals_132, primals_296, primals_155, getitem_17, getitem_56, getitem_16, primals_2, primals_16, primals_162, relu__default_14, primals_131, getitem_72, mul_tensor_3, primals_197, primals_156, primals_90, primals_160, primals_92, primals_91, getitem_74, primals_25, convolution_default_6, getitem_73, primals_1, primals_130, convolution_default_31, add_tensor_24, convolution_default_23, primals_37, primals_246, getitem_96, hardswish__default_5, getitem_19, primals_116, primals_300, primals_126, getitem_40, convolution_default_55, primals_120, relu__default_12, primals_261, convolution_default_26, relu__default_17, convolution_default_15, primals_265, mul_tensor_2, primals_262, primals_241, getitem_47, getitem_37, primals_270, primals_125, primals_240, primals_245, primals_266, mean_dim_2, primals_137, primals_111, relu__default_8, relu__default_9, primals_135, constant_pad_nd_default_4, relu__default_10, hardswish__default_16, primals_242, getitem_49, getitem_109, getitem_50, mul_tensor_6, convolution_default_20, getitem_110, primals_136, primals_115, relu__default_13, primals_121, convolution_default_17, convolution_default_54, primals_267, getitem_41, primals_122, primals_117, primals_291, convolution_default_22, getitem_38, primals_112, primals_127, mean_dim_1, relu__default_11, primals_177, convolution_default_49, primals_42, primals_17, primals_212, primals_57, primals_206, primals_43, to_dtype_3, convolution_default_35, relu__default_16, hardswish__default_14, getitem_43, convolution_default_56, primals_63, convolution_default_13, primals_290, mul_tensor, primals_48, getitem_44, getitem_33, to_dtype_1, add_tensor_39, primals_211, convolution_default_18, getitem_125, primals_49, getitem_86, primals_176, getitem_113, primals_210, primals_18, getitem_84, getitem_111, getitem_34, primals_64, primals_58, primals_110, mean_dim_5, getitem_124, getitem_88, primals_11, primals_205, mul_tensor_1, primals_44, primals_207, add_tensor_19, primals_60, getitem_89, getitem_112, getitem_46, convolution_default_19, getitem_127, getitem_85, convolution_default_36, hardswish__default_8, primals_62, to_dtype_13, getitem_126, primals_46, add_tensor_57, primals_20, hardswish__default_2, primals_97, primals_165, hardswish__default_10, mul_tensor_4, primals_95, convolution_default, getitem_107, getitem, primals_282, primals_106, convolution_default_47, convolution_default_60, primals_96, primals_13, primals_105, getitem_1, primals_100, relu__default_18, getitem_59, primals_180, getitem_2, getitem_58, primals_272, primals_172, primals_140, primals_171, getitem_106, primals_271, convolution_default_59, primals_147, primals_276, primals_275, mul_tensor_7, add_tensor_48, convolution_default_45, getitem_57, primals_146, hardswish__default, primals_102, primals_166, getitem_108, primals_101, convolution_default_1, primals_181, primals_170, to_dtype_9, getitem_118, convolution_default_46, hardswish__default_18, primals_56, primals_167, to_dtype_15, primals_107, getitem_4, primals_175, getitem_5, primals_255, getitem_20, primals_287, getitem_93, relu__default_3, hardswish__default_9, primals_9, getitem_60, getitem_62, primals_285, getitem_94, convolution_default_7, getitem_122, primals_257, convolution_default_39, getitem_64, getitem_92, getitem_133, primals_256, constant_pad_nd_default, getitem_23, primals_286, getitem_22, getitem_120, getitem_95, getitem_119, primals_142, add_tensor_62, convolution_default_37, primals_10, convolution_default_27, mean_dim_3, getitem_135, relu__default_4, getitem_90, getitem_121, primals_32, getitem_134, convolution_default_62, primals_141, getitem_136, primals_8, convolution_default_8, getitem_25, convolution_default_61, hardswish__default_3, primals_297, hardswish__default_15, getitem_65, convolution_default_28, convolution_default_9, getitem_63, mean_dim_8, mean_dim_6, primals_31, getitem_91, getitem_26, convolution_default_52, add_tensor_10, getitem_137, getitem_61, primals_182, primals_71, getitem_116, primals_76, primals_185, primals_22, primals_191, getitem_66, convolution_default_50, primals_195, primals_53, getitem_70, primals_36, primals_72, mul_tensor_5, getitem_115, primals_55, getitem_67, hardswish__default_4, getitem_117, relu__default_15, primals_69, convolution_default_51, primals_33, primals_190, convolution_default_44, convolution_default_30, primals_70, primals_192, to_dtype_11, primals_74, primals_186, primals_281, primals_77, primals_277, getitem_71, primals_65, primals_35, primals_187, getitem_114, primals_280, convolution_default_29, primals_67, getitem_68, relu__default, getitem_29, getitem_28, convolution_default_2, getitem_81, primals_30, convolution_default_34, getitem_8, convolution_default_3, getitem_83, getitem_7, relu__default_5, getitem_101, primals_50, getitem_82, getitem_79, convolution_default_10, add_tensor_3, getitem_31, constant_pad_nd_default_2, mean_dim, getitem_11, primals_295, getitem_32, hardswish__default_7, getitem_10, constant_pad_nd_default_1, relu__default_6, getitem_80, hardswish__default_11, primals_145, convolution_default_42, primals_29, getitem_100, getitem_99, relu__default_1, getitem_35, convolution_default_33, relu__default_7, primals_302, convolution_default_4, add_tensor_35, primals_51, convolution_default_41, primals_34, convolution_default_12, primals_23, primals_86, getitem_128, primals_3, primals_5, primals_292, primals_312, mean_dim_4, view_default, primals_311, primals_82, primals_221, primals_310, t_default, getitem_130, getitem_103, primals_27, primals_220, hardswish__default_6, primals_4, primals_24, primals_307, convolution_default_57, primals_306, primals_215, primals_305, primals_226, primals_81, primals_216, getitem_75, primals_222, primals_230, primals_6, primals_235, primals_227, add_tensor_31, hardswish__default_12, primals_87, primals_225, primals_231, primals_301, getitem_77, getitem_104, getitem_76, getitem_131, primals_217, primals_260, hardswish__default_17, getitem_102, getitem_129, primals_232, convolution_default_32, primals_85, primals_7, primals_236, mean_dim_7]
        
