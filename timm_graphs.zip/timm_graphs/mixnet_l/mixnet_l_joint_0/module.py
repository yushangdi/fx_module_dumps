
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/mixnet_l/mixnet_l_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50, tangents_51, tangents_52, tangents_53, tangents_54, tangents_55, tangents_56, tangents_57, tangents_58, tangents_59):
        convolution_default = torch.ops.aten.convolution.default(primals_190, primals_189, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_191, 1);  primals_191 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_194, primals_195, primals_192, primals_193, True, 0.1, 1e-05);  primals_195 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_196, 1);  primals_196 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_199, primals_200, primals_197, primals_198, True, 0.1, 1e-05);  primals_200 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_201, 1);  primals_201 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_204, primals_205, primals_202, primals_203, True, 0.1, 1e-05);  primals_205 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_6, relu__default);  getitem_6 = None
        split_with_sizes_default = torch.ops.aten.split_with_sizes.default(add_tensor_3, [16, 16], 1);  add_tensor_3 = None
        getitem_9 = split_with_sizes_default[0]
        getitem_10 = split_with_sizes_default[1];  split_with_sizes_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_6, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_10, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default = torch.ops.aten.cat.default([convolution_default_3, convolution_default_4], 1);  convolution_default_3 = convolution_default_4 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_206, 1);  primals_206 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(cat_default, primals_209, primals_210, primals_207, primals_208, True, 0.1, 1e-05);  primals_210 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(cat_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        split_with_sizes_default_1 = torch.ops.aten.split_with_sizes.default(relu__default_2, [64, 64, 64], 1)
        getitem_14 = split_with_sizes_default_1[0]
        getitem_15 = split_with_sizes_default_1[1]
        getitem_16 = split_with_sizes_default_1[2];  split_with_sizes_default_1 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_14, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 64)
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_4, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 64)
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_16, primals_5, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 64)
        cat_default_1 = torch.ops.aten.cat.default([convolution_default_5, convolution_default_6, convolution_default_7], 1);  convolution_default_5 = convolution_default_6 = convolution_default_7 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_211, 1);  primals_211 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_214, primals_215, primals_212, primals_213, True, 0.1, 1e-05);  primals_215 = None
        getitem_17 = native_batch_norm_default_4[0]
        getitem_18 = native_batch_norm_default_4[1]
        getitem_19 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(cat_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        split_with_sizes_default_2 = torch.ops.aten.split_with_sizes.default(relu__default_3, [96, 96], 1)
        getitem_20 = split_with_sizes_default_2[0]
        getitem_21 = split_with_sizes_default_2[1];  split_with_sizes_default_2 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_20, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_9 = torch.ops.aten.convolution.default(getitem_21, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_2 = torch.ops.aten.cat.default([convolution_default_8, convolution_default_9], 1);  convolution_default_8 = convolution_default_9 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_216, 1);  primals_216 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(cat_default_2, primals_219, primals_220, primals_217, primals_218, True, 0.1, 1e-05);  primals_220 = None
        getitem_22 = native_batch_norm_default_5[0]
        getitem_23 = native_batch_norm_default_5[1]
        getitem_24 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(cat_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        split_with_sizes_default_3 = torch.ops.aten.split_with_sizes.default(getitem_22, [20, 20], 1)
        getitem_25 = split_with_sizes_default_3[0]
        getitem_26 = split_with_sizes_default_3[1];  split_with_sizes_default_3 = None
        convolution_default_10 = torch.ops.aten.convolution.default(getitem_25, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_11 = torch.ops.aten.convolution.default(getitem_26, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([convolution_default_10, convolution_default_11], 1);  convolution_default_10 = convolution_default_11 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_221, 1);  primals_221 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_224, primals_225, primals_222, primals_223, True, 0.1, 1e-05);  primals_225 = None
        getitem_27 = native_batch_norm_default_6[0]
        getitem_28 = native_batch_norm_default_6[1]
        getitem_29 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(cat_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_4, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_226, 1);  primals_226 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_229, primals_230, primals_227, primals_228, True, 0.1, 1e-05);  primals_230 = None
        getitem_30 = native_batch_norm_default_7[0]
        getitem_31 = native_batch_norm_default_7[1]
        getitem_32 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        split_with_sizes_default_4 = torch.ops.aten.split_with_sizes.default(relu__default_5, [60, 60], 1)
        getitem_33 = split_with_sizes_default_4[0]
        getitem_34 = split_with_sizes_default_4[1];  split_with_sizes_default_4 = None
        convolution_default_13 = torch.ops.aten.convolution.default(getitem_33, primals_13, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_14 = torch.ops.aten.convolution.default(getitem_34, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_4 = torch.ops.aten.cat.default([convolution_default_13, convolution_default_14], 1);  convolution_default_13 = convolution_default_14 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_231, 1);  primals_231 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(cat_default_4, primals_234, primals_235, primals_232, primals_233, True, 0.1, 1e-05);  primals_235 = None
        getitem_35 = native_batch_norm_default_8[0]
        getitem_36 = native_batch_norm_default_8[1]
        getitem_37 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(cat_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_35, getitem_22);  getitem_35 = getitem_22 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_10, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_236, 1);  primals_236 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_239, primals_240, primals_237, primals_238, True, 0.1, 1e-05);  primals_240 = None
        getitem_38 = native_batch_norm_default_9[0]
        getitem_39 = native_batch_norm_default_9[1]
        getitem_40 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default = torch.ops.aten.clone.default(getitem_38)
        silu__default = torch.ops.aten.silu_.default(getitem_38);  getitem_38 = None
        split_with_sizes_default_5 = torch.ops.aten.split_with_sizes.default(silu__default, [60, 60, 60, 60], 1);  silu__default = None
        getitem_41 = split_with_sizes_default_5[0]
        getitem_42 = split_with_sizes_default_5[1]
        getitem_43 = split_with_sizes_default_5[2]
        getitem_44 = split_with_sizes_default_5[3];  split_with_sizes_default_5 = None
        convolution_default_16 = torch.ops.aten.convolution.default(getitem_41, primals_15, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 60)
        convolution_default_17 = torch.ops.aten.convolution.default(getitem_42, primals_16, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 60)
        convolution_default_18 = torch.ops.aten.convolution.default(getitem_43, primals_17, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 60)
        convolution_default_19 = torch.ops.aten.convolution.default(getitem_44, primals_18, None, [2, 2], [4, 4], [1, 1], False, [0, 0], 60)
        cat_default_5 = torch.ops.aten.cat.default([convolution_default_16, convolution_default_17, convolution_default_18, convolution_default_19], 1);  convolution_default_16 = convolution_default_17 = convolution_default_18 = convolution_default_19 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_241, 1);  primals_241 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(cat_default_5, primals_244, primals_245, primals_242, primals_243, True, 0.1, 1e-05);  primals_245 = None
        getitem_45 = native_batch_norm_default_10[0]
        getitem_46 = native_batch_norm_default_10[1]
        getitem_47 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(cat_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_1 = torch.ops.aten.clone.default(getitem_45)
        silu__default_1 = torch.ops.aten.silu_.default(getitem_45);  getitem_45 = None
        mean_dim = torch.ops.aten.mean.dim(silu__default_1, [2, 3], True)
        convolution_default_20 = torch.ops.aten.convolution.default(mean_dim, primals_24, primals_23, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_23 = None
        clone_default_2 = torch.ops.aten.clone.default(convolution_default_20)
        silu__default_2 = torch.ops.aten.silu_.default(convolution_default_20);  convolution_default_20 = None
        convolution_default_21 = torch.ops.aten.convolution.default(silu__default_2, primals_22, primals_21, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_21 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_21);  convolution_default_21 = None
        mul_tensor = torch.ops.aten.mul.Tensor(silu__default_1, sigmoid_default)
        convolution_default_22 = torch.ops.aten.convolution.default(mul_tensor, primals_20, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_246, 1);  primals_246 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_249, primals_250, primals_247, primals_248, True, 0.1, 1e-05);  primals_250 = None
        getitem_48 = native_batch_norm_default_11[0]
        getitem_49 = native_batch_norm_default_11[1]
        getitem_50 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        split_with_sizes_default_6 = torch.ops.aten.split_with_sizes.default(getitem_48, [28, 28], 1)
        getitem_51 = split_with_sizes_default_6[0]
        getitem_52 = split_with_sizes_default_6[1];  split_with_sizes_default_6 = None
        convolution_default_23 = torch.ops.aten.convolution.default(getitem_51, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_24 = torch.ops.aten.convolution.default(getitem_52, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_6 = torch.ops.aten.cat.default([convolution_default_23, convolution_default_24], 1);  convolution_default_23 = convolution_default_24 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_251, 1);  primals_251 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(cat_default_6, primals_254, primals_255, primals_252, primals_253, True, 0.1, 1e-05);  primals_255 = None
        getitem_53 = native_batch_norm_default_12[0]
        getitem_54 = native_batch_norm_default_12[1]
        getitem_55 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(cat_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_3 = torch.ops.aten.clone.default(getitem_53)
        silu__default_3 = torch.ops.aten.silu_.default(getitem_53);  getitem_53 = None
        split_with_sizes_default_7 = torch.ops.aten.split_with_sizes.default(silu__default_3, [168, 168], 1);  silu__default_3 = None
        getitem_56 = split_with_sizes_default_7[0]
        getitem_57 = split_with_sizes_default_7[1];  split_with_sizes_default_7 = None
        convolution_default_25 = torch.ops.aten.convolution.default(getitem_56, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_26 = torch.ops.aten.convolution.default(getitem_57, primals_26, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        cat_default_7 = torch.ops.aten.cat.default([convolution_default_25, convolution_default_26], 1);  convolution_default_25 = convolution_default_26 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_256, 1);  primals_256 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(cat_default_7, primals_259, primals_260, primals_257, primals_258, True, 0.1, 1e-05);  primals_260 = None
        getitem_58 = native_batch_norm_default_13[0]
        getitem_59 = native_batch_norm_default_13[1]
        getitem_60 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(cat_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_4 = torch.ops.aten.clone.default(getitem_58)
        silu__default_4 = torch.ops.aten.silu_.default(getitem_58);  getitem_58 = None
        mean_dim_1 = torch.ops.aten.mean.dim(silu__default_4, [2, 3], True)
        convolution_default_27 = torch.ops.aten.convolution.default(mean_dim_1, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        clone_default_5 = torch.ops.aten.clone.default(convolution_default_27)
        silu__default_5 = torch.ops.aten.silu_.default(convolution_default_27);  convolution_default_27 = None
        convolution_default_28 = torch.ops.aten.convolution.default(silu__default_5, primals_32, primals_31, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_31 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_28);  convolution_default_28 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(silu__default_4, sigmoid_default_1)
        split_with_sizes_default_8 = torch.ops.aten.split_with_sizes.default(mul_tensor_1, [168, 168], 1);  mul_tensor_1 = None
        getitem_61 = split_with_sizes_default_8[0]
        getitem_62 = split_with_sizes_default_8[1];  split_with_sizes_default_8 = None
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_61, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_30 = torch.ops.aten.convolution.default(getitem_62, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_8 = torch.ops.aten.cat.default([convolution_default_29, convolution_default_30], 1);  convolution_default_29 = convolution_default_30 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_261, 1);  primals_261 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(cat_default_8, primals_264, primals_265, primals_262, primals_263, True, 0.1, 1e-05);  primals_265 = None
        getitem_63 = native_batch_norm_default_14[0]
        getitem_64 = native_batch_norm_default_14[1]
        getitem_65 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(cat_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_63, getitem_48);  getitem_63 = getitem_48 = None
        split_with_sizes_default_9 = torch.ops.aten.split_with_sizes.default(add_tensor_17, [28, 28], 1)
        getitem_66 = split_with_sizes_default_9[0]
        getitem_67 = split_with_sizes_default_9[1];  split_with_sizes_default_9 = None
        convolution_default_31 = torch.ops.aten.convolution.default(getitem_66, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_32 = torch.ops.aten.convolution.default(getitem_67, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_9 = torch.ops.aten.cat.default([convolution_default_31, convolution_default_32], 1);  convolution_default_31 = convolution_default_32 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_266, 1);  primals_266 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(cat_default_9, primals_269, primals_270, primals_267, primals_268, True, 0.1, 1e-05);  primals_270 = None
        getitem_68 = native_batch_norm_default_15[0]
        getitem_69 = native_batch_norm_default_15[1]
        getitem_70 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(cat_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_6 = torch.ops.aten.clone.default(getitem_68)
        silu__default_6 = torch.ops.aten.silu_.default(getitem_68);  getitem_68 = None
        split_with_sizes_default_10 = torch.ops.aten.split_with_sizes.default(silu__default_6, [168, 168], 1);  silu__default_6 = None
        getitem_71 = split_with_sizes_default_10[0]
        getitem_72 = split_with_sizes_default_10[1];  split_with_sizes_default_10 = None
        convolution_default_33 = torch.ops.aten.convolution.default(getitem_71, primals_35, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_72, primals_36, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        cat_default_10 = torch.ops.aten.cat.default([convolution_default_33, convolution_default_34], 1);  convolution_default_33 = convolution_default_34 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_271, 1);  primals_271 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(cat_default_10, primals_274, primals_275, primals_272, primals_273, True, 0.1, 1e-05);  primals_275 = None
        getitem_73 = native_batch_norm_default_16[0]
        getitem_74 = native_batch_norm_default_16[1]
        getitem_75 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(cat_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_7 = torch.ops.aten.clone.default(getitem_73)
        silu__default_7 = torch.ops.aten.silu_.default(getitem_73);  getitem_73 = None
        mean_dim_2 = torch.ops.aten.mean.dim(silu__default_7, [2, 3], True)
        convolution_default_35 = torch.ops.aten.convolution.default(mean_dim_2, primals_44, primals_43, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_43 = None
        clone_default_8 = torch.ops.aten.clone.default(convolution_default_35)
        silu__default_8 = torch.ops.aten.silu_.default(convolution_default_35);  convolution_default_35 = None
        convolution_default_36 = torch.ops.aten.convolution.default(silu__default_8, primals_42, primals_41, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_41 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_36);  convolution_default_36 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(silu__default_7, sigmoid_default_2)
        split_with_sizes_default_11 = torch.ops.aten.split_with_sizes.default(mul_tensor_2, [168, 168], 1);  mul_tensor_2 = None
        getitem_76 = split_with_sizes_default_11[0]
        getitem_77 = split_with_sizes_default_11[1];  split_with_sizes_default_11 = None
        convolution_default_37 = torch.ops.aten.convolution.default(getitem_76, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_38 = torch.ops.aten.convolution.default(getitem_77, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_11 = torch.ops.aten.cat.default([convolution_default_37, convolution_default_38], 1);  convolution_default_37 = convolution_default_38 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_276, 1);  primals_276 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(cat_default_11, primals_279, primals_280, primals_277, primals_278, True, 0.1, 1e-05);  primals_280 = None
        getitem_78 = native_batch_norm_default_17[0]
        getitem_79 = native_batch_norm_default_17[1]
        getitem_80 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(cat_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_21 = torch.ops.aten.add.Tensor(getitem_78, add_tensor_17);  getitem_78 = add_tensor_17 = None
        split_with_sizes_default_12 = torch.ops.aten.split_with_sizes.default(add_tensor_21, [28, 28], 1)
        getitem_81 = split_with_sizes_default_12[0]
        getitem_82 = split_with_sizes_default_12[1];  split_with_sizes_default_12 = None
        convolution_default_39 = torch.ops.aten.convolution.default(getitem_81, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_82, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_12 = torch.ops.aten.cat.default([convolution_default_39, convolution_default_40], 1);  convolution_default_39 = convolution_default_40 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_281, 1);  primals_281 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(cat_default_12, primals_284, primals_285, primals_282, primals_283, True, 0.1, 1e-05);  primals_285 = None
        getitem_83 = native_batch_norm_default_18[0]
        getitem_84 = native_batch_norm_default_18[1]
        getitem_85 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(cat_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_9 = torch.ops.aten.clone.default(getitem_83)
        silu__default_9 = torch.ops.aten.silu_.default(getitem_83);  getitem_83 = None
        split_with_sizes_default_13 = torch.ops.aten.split_with_sizes.default(silu__default_9, [168, 168], 1);  silu__default_9 = None
        getitem_86 = split_with_sizes_default_13[0]
        getitem_87 = split_with_sizes_default_13[1];  split_with_sizes_default_13 = None
        convolution_default_41 = torch.ops.aten.convolution.default(getitem_86, primals_45, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_42 = torch.ops.aten.convolution.default(getitem_87, primals_46, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        cat_default_13 = torch.ops.aten.cat.default([convolution_default_41, convolution_default_42], 1);  convolution_default_41 = convolution_default_42 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_286, 1);  primals_286 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(cat_default_13, primals_289, primals_290, primals_287, primals_288, True, 0.1, 1e-05);  primals_290 = None
        getitem_88 = native_batch_norm_default_19[0]
        getitem_89 = native_batch_norm_default_19[1]
        getitem_90 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(cat_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_10 = torch.ops.aten.clone.default(getitem_88)
        silu__default_10 = torch.ops.aten.silu_.default(getitem_88);  getitem_88 = None
        mean_dim_3 = torch.ops.aten.mean.dim(silu__default_10, [2, 3], True)
        convolution_default_43 = torch.ops.aten.convolution.default(mean_dim_3, primals_54, primals_53, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_53 = None
        clone_default_11 = torch.ops.aten.clone.default(convolution_default_43)
        silu__default_11 = torch.ops.aten.silu_.default(convolution_default_43);  convolution_default_43 = None
        convolution_default_44 = torch.ops.aten.convolution.default(silu__default_11, primals_52, primals_51, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_51 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_44);  convolution_default_44 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(silu__default_10, sigmoid_default_3)
        split_with_sizes_default_14 = torch.ops.aten.split_with_sizes.default(mul_tensor_3, [168, 168], 1);  mul_tensor_3 = None
        getitem_91 = split_with_sizes_default_14[0]
        getitem_92 = split_with_sizes_default_14[1];  split_with_sizes_default_14 = None
        convolution_default_45 = torch.ops.aten.convolution.default(getitem_91, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_46 = torch.ops.aten.convolution.default(getitem_92, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_14 = torch.ops.aten.cat.default([convolution_default_45, convolution_default_46], 1);  convolution_default_45 = convolution_default_46 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_291, 1);  primals_291 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(cat_default_14, primals_294, primals_295, primals_292, primals_293, True, 0.1, 1e-05);  primals_295 = None
        getitem_93 = native_batch_norm_default_20[0]
        getitem_94 = native_batch_norm_default_20[1]
        getitem_95 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(cat_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_25 = torch.ops.aten.add.Tensor(getitem_93, add_tensor_21);  getitem_93 = add_tensor_21 = None
        convolution_default_47 = torch.ops.aten.convolution.default(add_tensor_25, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_296, 1);  primals_296 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_299, primals_300, primals_297, primals_298, True, 0.1, 1e-05);  primals_300 = None
        getitem_96 = native_batch_norm_default_21[0]
        getitem_97 = native_batch_norm_default_21[1]
        getitem_98 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_12 = torch.ops.aten.clone.default(getitem_96)
        silu__default_12 = torch.ops.aten.silu_.default(getitem_96);  getitem_96 = None
        split_with_sizes_default_15 = torch.ops.aten.split_with_sizes.default(silu__default_12, [112, 112, 112], 1);  silu__default_12 = None
        getitem_99 = split_with_sizes_default_15[0]
        getitem_100 = split_with_sizes_default_15[1]
        getitem_101 = split_with_sizes_default_15[2];  split_with_sizes_default_15 = None
        convolution_default_48 = torch.ops.aten.convolution.default(getitem_99, primals_55, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 112)
        convolution_default_49 = torch.ops.aten.convolution.default(getitem_100, primals_56, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 112)
        convolution_default_50 = torch.ops.aten.convolution.default(getitem_101, primals_57, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 112)
        cat_default_15 = torch.ops.aten.cat.default([convolution_default_48, convolution_default_49, convolution_default_50], 1);  convolution_default_48 = convolution_default_49 = convolution_default_50 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(primals_301, 1);  primals_301 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(cat_default_15, primals_304, primals_305, primals_302, primals_303, True, 0.1, 1e-05);  primals_305 = None
        getitem_102 = native_batch_norm_default_22[0]
        getitem_103 = native_batch_norm_default_22[1]
        getitem_104 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(cat_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_13 = torch.ops.aten.clone.default(getitem_102)
        silu__default_13 = torch.ops.aten.silu_.default(getitem_102);  getitem_102 = None
        mean_dim_4 = torch.ops.aten.mean.dim(silu__default_13, [2, 3], True)
        convolution_default_51 = torch.ops.aten.convolution.default(mean_dim_4, primals_63, primals_62, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_62 = None
        clone_default_14 = torch.ops.aten.clone.default(convolution_default_51)
        silu__default_14 = torch.ops.aten.silu_.default(convolution_default_51);  convolution_default_51 = None
        convolution_default_52 = torch.ops.aten.convolution.default(silu__default_14, primals_61, primals_60, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_60 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_52);  convolution_default_52 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(silu__default_13, sigmoid_default_4)
        convolution_default_53 = torch.ops.aten.convolution.default(mul_tensor_4, primals_59, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_306, 1);  primals_306 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_309, primals_310, primals_307, primals_308, True, 0.1, 1e-05);  primals_310 = None
        getitem_105 = native_batch_norm_default_23[0]
        getitem_106 = native_batch_norm_default_23[1]
        getitem_107 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        split_with_sizes_default_16 = torch.ops.aten.split_with_sizes.default(getitem_105, [52, 52], 1)
        getitem_108 = split_with_sizes_default_16[0]
        getitem_109 = split_with_sizes_default_16[1];  split_with_sizes_default_16 = None
        convolution_default_54 = torch.ops.aten.convolution.default(getitem_108, primals_68, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_55 = torch.ops.aten.convolution.default(getitem_109, primals_69, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_16 = torch.ops.aten.cat.default([convolution_default_54, convolution_default_55], 1);  convolution_default_54 = convolution_default_55 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_311, 1);  primals_311 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(cat_default_16, primals_314, primals_315, primals_312, primals_313, True, 0.1, 1e-05);  primals_315 = None
        getitem_110 = native_batch_norm_default_24[0]
        getitem_111 = native_batch_norm_default_24[1]
        getitem_112 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(cat_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_15 = torch.ops.aten.clone.default(getitem_110)
        silu__default_15 = torch.ops.aten.silu_.default(getitem_110);  getitem_110 = None
        split_with_sizes_default_17 = torch.ops.aten.split_with_sizes.default(silu__default_15, [156, 156, 156, 156], 1);  silu__default_15 = None
        getitem_113 = split_with_sizes_default_17[0]
        getitem_114 = split_with_sizes_default_17[1]
        getitem_115 = split_with_sizes_default_17[2]
        getitem_116 = split_with_sizes_default_17[3];  split_with_sizes_default_17 = None
        convolution_default_56 = torch.ops.aten.convolution.default(getitem_113, primals_64, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 156)
        convolution_default_57 = torch.ops.aten.convolution.default(getitem_114, primals_65, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 156)
        convolution_default_58 = torch.ops.aten.convolution.default(getitem_115, primals_66, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 156)
        convolution_default_59 = torch.ops.aten.convolution.default(getitem_116, primals_67, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 156)
        cat_default_17 = torch.ops.aten.cat.default([convolution_default_56, convolution_default_57, convolution_default_58, convolution_default_59], 1);  convolution_default_56 = convolution_default_57 = convolution_default_58 = convolution_default_59 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_316, 1);  primals_316 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(cat_default_17, primals_319, primals_320, primals_317, primals_318, True, 0.1, 1e-05);  primals_320 = None
        getitem_117 = native_batch_norm_default_25[0]
        getitem_118 = native_batch_norm_default_25[1]
        getitem_119 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(cat_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_16 = torch.ops.aten.clone.default(getitem_117)
        silu__default_16 = torch.ops.aten.silu_.default(getitem_117);  getitem_117 = None
        mean_dim_5 = torch.ops.aten.mean.dim(silu__default_16, [2, 3], True)
        convolution_default_60 = torch.ops.aten.convolution.default(mean_dim_5, primals_75, primals_74, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_74 = None
        clone_default_17 = torch.ops.aten.clone.default(convolution_default_60)
        silu__default_17 = torch.ops.aten.silu_.default(convolution_default_60);  convolution_default_60 = None
        convolution_default_61 = torch.ops.aten.convolution.default(silu__default_17, primals_73, primals_72, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_72 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_61);  convolution_default_61 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(silu__default_16, sigmoid_default_5)
        split_with_sizes_default_18 = torch.ops.aten.split_with_sizes.default(mul_tensor_5, [312, 312], 1);  mul_tensor_5 = None
        getitem_120 = split_with_sizes_default_18[0]
        getitem_121 = split_with_sizes_default_18[1];  split_with_sizes_default_18 = None
        convolution_default_62 = torch.ops.aten.convolution.default(getitem_120, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_63 = torch.ops.aten.convolution.default(getitem_121, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_18 = torch.ops.aten.cat.default([convolution_default_62, convolution_default_63], 1);  convolution_default_62 = convolution_default_63 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_321, 1);  primals_321 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(cat_default_18, primals_324, primals_325, primals_322, primals_323, True, 0.1, 1e-05);  primals_325 = None
        getitem_122 = native_batch_norm_default_26[0]
        getitem_123 = native_batch_norm_default_26[1]
        getitem_124 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(cat_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_122, getitem_105);  getitem_122 = getitem_105 = None
        split_with_sizes_default_19 = torch.ops.aten.split_with_sizes.default(add_tensor_32, [52, 52], 1)
        getitem_125 = split_with_sizes_default_19[0]
        getitem_126 = split_with_sizes_default_19[1];  split_with_sizes_default_19 = None
        convolution_default_64 = torch.ops.aten.convolution.default(getitem_125, primals_80, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_65 = torch.ops.aten.convolution.default(getitem_126, primals_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_19 = torch.ops.aten.cat.default([convolution_default_64, convolution_default_65], 1);  convolution_default_64 = convolution_default_65 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_326, 1);  primals_326 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(cat_default_19, primals_329, primals_330, primals_327, primals_328, True, 0.1, 1e-05);  primals_330 = None
        getitem_127 = native_batch_norm_default_27[0]
        getitem_128 = native_batch_norm_default_27[1]
        getitem_129 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(cat_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_18 = torch.ops.aten.clone.default(getitem_127)
        silu__default_18 = torch.ops.aten.silu_.default(getitem_127);  getitem_127 = None
        split_with_sizes_default_20 = torch.ops.aten.split_with_sizes.default(silu__default_18, [156, 156, 156, 156], 1);  silu__default_18 = None
        getitem_130 = split_with_sizes_default_20[0]
        getitem_131 = split_with_sizes_default_20[1]
        getitem_132 = split_with_sizes_default_20[2]
        getitem_133 = split_with_sizes_default_20[3];  split_with_sizes_default_20 = None
        convolution_default_66 = torch.ops.aten.convolution.default(getitem_130, primals_76, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 156)
        convolution_default_67 = torch.ops.aten.convolution.default(getitem_131, primals_77, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 156)
        convolution_default_68 = torch.ops.aten.convolution.default(getitem_132, primals_78, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 156)
        convolution_default_69 = torch.ops.aten.convolution.default(getitem_133, primals_79, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 156)
        cat_default_20 = torch.ops.aten.cat.default([convolution_default_66, convolution_default_67, convolution_default_68, convolution_default_69], 1);  convolution_default_66 = convolution_default_67 = convolution_default_68 = convolution_default_69 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(primals_331, 1);  primals_331 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(cat_default_20, primals_334, primals_335, primals_332, primals_333, True, 0.1, 1e-05);  primals_335 = None
        getitem_134 = native_batch_norm_default_28[0]
        getitem_135 = native_batch_norm_default_28[1]
        getitem_136 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(cat_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_19 = torch.ops.aten.clone.default(getitem_134)
        silu__default_19 = torch.ops.aten.silu_.default(getitem_134);  getitem_134 = None
        mean_dim_6 = torch.ops.aten.mean.dim(silu__default_19, [2, 3], True)
        convolution_default_70 = torch.ops.aten.convolution.default(mean_dim_6, primals_87, primals_86, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_86 = None
        clone_default_20 = torch.ops.aten.clone.default(convolution_default_70)
        silu__default_20 = torch.ops.aten.silu_.default(convolution_default_70);  convolution_default_70 = None
        convolution_default_71 = torch.ops.aten.convolution.default(silu__default_20, primals_85, primals_84, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_84 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_71);  convolution_default_71 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(silu__default_19, sigmoid_default_6)
        split_with_sizes_default_21 = torch.ops.aten.split_with_sizes.default(mul_tensor_6, [312, 312], 1);  mul_tensor_6 = None
        getitem_137 = split_with_sizes_default_21[0]
        getitem_138 = split_with_sizes_default_21[1];  split_with_sizes_default_21 = None
        convolution_default_72 = torch.ops.aten.convolution.default(getitem_137, primals_82, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_73 = torch.ops.aten.convolution.default(getitem_138, primals_83, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_21 = torch.ops.aten.cat.default([convolution_default_72, convolution_default_73], 1);  convolution_default_72 = convolution_default_73 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_336, 1);  primals_336 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(cat_default_21, primals_339, primals_340, primals_337, primals_338, True, 0.1, 1e-05);  primals_340 = None
        getitem_139 = native_batch_norm_default_29[0]
        getitem_140 = native_batch_norm_default_29[1]
        getitem_141 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(cat_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_36 = torch.ops.aten.add.Tensor(getitem_139, add_tensor_32);  getitem_139 = add_tensor_32 = None
        split_with_sizes_default_22 = torch.ops.aten.split_with_sizes.default(add_tensor_36, [52, 52], 1)
        getitem_142 = split_with_sizes_default_22[0]
        getitem_143 = split_with_sizes_default_22[1];  split_with_sizes_default_22 = None
        convolution_default_74 = torch.ops.aten.convolution.default(getitem_142, primals_92, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_75 = torch.ops.aten.convolution.default(getitem_143, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_22 = torch.ops.aten.cat.default([convolution_default_74, convolution_default_75], 1);  convolution_default_74 = convolution_default_75 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_341, 1);  primals_341 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(cat_default_22, primals_344, primals_345, primals_342, primals_343, True, 0.1, 1e-05);  primals_345 = None
        getitem_144 = native_batch_norm_default_30[0]
        getitem_145 = native_batch_norm_default_30[1]
        getitem_146 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(cat_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_21 = torch.ops.aten.clone.default(getitem_144)
        silu__default_21 = torch.ops.aten.silu_.default(getitem_144);  getitem_144 = None
        split_with_sizes_default_23 = torch.ops.aten.split_with_sizes.default(silu__default_21, [156, 156, 156, 156], 1);  silu__default_21 = None
        getitem_147 = split_with_sizes_default_23[0]
        getitem_148 = split_with_sizes_default_23[1]
        getitem_149 = split_with_sizes_default_23[2]
        getitem_150 = split_with_sizes_default_23[3];  split_with_sizes_default_23 = None
        convolution_default_76 = torch.ops.aten.convolution.default(getitem_147, primals_88, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 156)
        convolution_default_77 = torch.ops.aten.convolution.default(getitem_148, primals_89, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 156)
        convolution_default_78 = torch.ops.aten.convolution.default(getitem_149, primals_90, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 156)
        convolution_default_79 = torch.ops.aten.convolution.default(getitem_150, primals_91, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 156)
        cat_default_23 = torch.ops.aten.cat.default([convolution_default_76, convolution_default_77, convolution_default_78, convolution_default_79], 1);  convolution_default_76 = convolution_default_77 = convolution_default_78 = convolution_default_79 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(primals_346, 1);  primals_346 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(cat_default_23, primals_349, primals_350, primals_347, primals_348, True, 0.1, 1e-05);  primals_350 = None
        getitem_151 = native_batch_norm_default_31[0]
        getitem_152 = native_batch_norm_default_31[1]
        getitem_153 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(cat_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_22 = torch.ops.aten.clone.default(getitem_151)
        silu__default_22 = torch.ops.aten.silu_.default(getitem_151);  getitem_151 = None
        mean_dim_7 = torch.ops.aten.mean.dim(silu__default_22, [2, 3], True)
        convolution_default_80 = torch.ops.aten.convolution.default(mean_dim_7, primals_99, primals_98, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_98 = None
        clone_default_23 = torch.ops.aten.clone.default(convolution_default_80)
        silu__default_23 = torch.ops.aten.silu_.default(convolution_default_80);  convolution_default_80 = None
        convolution_default_81 = torch.ops.aten.convolution.default(silu__default_23, primals_97, primals_96, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_96 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_81);  convolution_default_81 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(silu__default_22, sigmoid_default_7)
        split_with_sizes_default_24 = torch.ops.aten.split_with_sizes.default(mul_tensor_7, [312, 312], 1);  mul_tensor_7 = None
        getitem_154 = split_with_sizes_default_24[0]
        getitem_155 = split_with_sizes_default_24[1];  split_with_sizes_default_24 = None
        convolution_default_82 = torch.ops.aten.convolution.default(getitem_154, primals_94, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_83 = torch.ops.aten.convolution.default(getitem_155, primals_95, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_24 = torch.ops.aten.cat.default([convolution_default_82, convolution_default_83], 1);  convolution_default_82 = convolution_default_83 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_351, 1);  primals_351 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(cat_default_24, primals_354, primals_355, primals_352, primals_353, True, 0.1, 1e-05);  primals_355 = None
        getitem_156 = native_batch_norm_default_32[0]
        getitem_157 = native_batch_norm_default_32[1]
        getitem_158 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(cat_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_156, add_tensor_36);  getitem_156 = add_tensor_36 = None
        convolution_default_84 = torch.ops.aten.convolution.default(add_tensor_40, primals_101, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_356, 1);  primals_356 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_359, primals_360, primals_357, primals_358, True, 0.1, 1e-05);  primals_360 = None
        getitem_159 = native_batch_norm_default_33[0]
        getitem_160 = native_batch_norm_default_33[1]
        getitem_161 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_84, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_24 = torch.ops.aten.clone.default(getitem_159)
        silu__default_24 = torch.ops.aten.silu_.default(getitem_159);  getitem_159 = None
        convolution_default_85 = torch.ops.aten.convolution.default(silu__default_24, primals_100, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 624)
        add_tensor_42 = torch.ops.aten.add.Tensor(primals_361, 1);  primals_361 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_364, primals_365, primals_362, primals_363, True, 0.1, 1e-05);  primals_365 = None
        getitem_162 = native_batch_norm_default_34[0]
        getitem_163 = native_batch_norm_default_34[1]
        getitem_164 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_85, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_25 = torch.ops.aten.clone.default(getitem_162)
        silu__default_25 = torch.ops.aten.silu_.default(getitem_162);  getitem_162 = None
        mean_dim_8 = torch.ops.aten.mean.dim(silu__default_25, [2, 3], True)
        convolution_default_86 = torch.ops.aten.convolution.default(mean_dim_8, primals_106, primals_105, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_105 = None
        clone_default_26 = torch.ops.aten.clone.default(convolution_default_86)
        silu__default_26 = torch.ops.aten.silu_.default(convolution_default_86);  convolution_default_86 = None
        convolution_default_87 = torch.ops.aten.convolution.default(silu__default_26, primals_104, primals_103, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_103 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_87);  convolution_default_87 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(silu__default_25, sigmoid_default_8)
        convolution_default_88 = torch.ops.aten.convolution.default(mul_tensor_8, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_366, 1);  primals_366 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_369, primals_370, primals_367, primals_368, True, 0.1, 1e-05);  primals_370 = None
        getitem_165 = native_batch_norm_default_35[0]
        getitem_166 = native_batch_norm_default_35[1]
        getitem_167 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_88, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        split_with_sizes_default_25 = torch.ops.aten.split_with_sizes.default(getitem_165, [80, 80], 1)
        getitem_168 = split_with_sizes_default_25[0]
        getitem_169 = split_with_sizes_default_25[1];  split_with_sizes_default_25 = None
        convolution_default_89 = torch.ops.aten.convolution.default(getitem_168, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_90 = torch.ops.aten.convolution.default(getitem_169, primals_112, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_25 = torch.ops.aten.cat.default([convolution_default_89, convolution_default_90], 1);  convolution_default_89 = convolution_default_90 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_371, 1);  primals_371 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(cat_default_25, primals_374, primals_375, primals_372, primals_373, True, 0.1, 1e-05);  primals_375 = None
        getitem_170 = native_batch_norm_default_36[0]
        getitem_171 = native_batch_norm_default_36[1]
        getitem_172 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(cat_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_27 = torch.ops.aten.clone.default(getitem_170)
        silu__default_27 = torch.ops.aten.silu_.default(getitem_170);  getitem_170 = None
        split_with_sizes_default_26 = torch.ops.aten.split_with_sizes.default(silu__default_27, [120, 120, 120, 120], 1);  silu__default_27 = None
        getitem_173 = split_with_sizes_default_26[0]
        getitem_174 = split_with_sizes_default_26[1]
        getitem_175 = split_with_sizes_default_26[2]
        getitem_176 = split_with_sizes_default_26[3];  split_with_sizes_default_26 = None
        convolution_default_91 = torch.ops.aten.convolution.default(getitem_173, primals_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        convolution_default_92 = torch.ops.aten.convolution.default(getitem_174, primals_108, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 120)
        convolution_default_93 = torch.ops.aten.convolution.default(getitem_175, primals_109, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 120)
        convolution_default_94 = torch.ops.aten.convolution.default(getitem_176, primals_110, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 120)
        cat_default_26 = torch.ops.aten.cat.default([convolution_default_91, convolution_default_92, convolution_default_93, convolution_default_94], 1);  convolution_default_91 = convolution_default_92 = convolution_default_93 = convolution_default_94 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(primals_376, 1);  primals_376 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(cat_default_26, primals_379, primals_380, primals_377, primals_378, True, 0.1, 1e-05);  primals_380 = None
        getitem_177 = native_batch_norm_default_37[0]
        getitem_178 = native_batch_norm_default_37[1]
        getitem_179 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(cat_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_28 = torch.ops.aten.clone.default(getitem_177)
        silu__default_28 = torch.ops.aten.silu_.default(getitem_177);  getitem_177 = None
        mean_dim_9 = torch.ops.aten.mean.dim(silu__default_28, [2, 3], True)
        convolution_default_95 = torch.ops.aten.convolution.default(mean_dim_9, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        clone_default_29 = torch.ops.aten.clone.default(convolution_default_95)
        silu__default_29 = torch.ops.aten.silu_.default(convolution_default_95);  convolution_default_95 = None
        convolution_default_96 = torch.ops.aten.convolution.default(silu__default_29, primals_116, primals_115, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_115 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_96);  convolution_default_96 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(silu__default_28, sigmoid_default_9)
        split_with_sizes_default_27 = torch.ops.aten.split_with_sizes.default(mul_tensor_9, [240, 240], 1);  mul_tensor_9 = None
        getitem_180 = split_with_sizes_default_27[0]
        getitem_181 = split_with_sizes_default_27[1];  split_with_sizes_default_27 = None
        convolution_default_97 = torch.ops.aten.convolution.default(getitem_180, primals_113, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_98 = torch.ops.aten.convolution.default(getitem_181, primals_114, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_27 = torch.ops.aten.cat.default([convolution_default_97, convolution_default_98], 1);  convolution_default_97 = convolution_default_98 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_381, 1);  primals_381 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(cat_default_27, primals_384, primals_385, primals_382, primals_383, True, 0.1, 1e-05);  primals_385 = None
        getitem_182 = native_batch_norm_default_38[0]
        getitem_183 = native_batch_norm_default_38[1]
        getitem_184 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(cat_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_182, getitem_165);  getitem_182 = getitem_165 = None
        split_with_sizes_default_28 = torch.ops.aten.split_with_sizes.default(add_tensor_47, [80, 80], 1)
        getitem_185 = split_with_sizes_default_28[0]
        getitem_186 = split_with_sizes_default_28[1];  split_with_sizes_default_28 = None
        convolution_default_99 = torch.ops.aten.convolution.default(getitem_185, primals_123, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_100 = torch.ops.aten.convolution.default(getitem_186, primals_124, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_28 = torch.ops.aten.cat.default([convolution_default_99, convolution_default_100], 1);  convolution_default_99 = convolution_default_100 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_386, 1);  primals_386 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(cat_default_28, primals_389, primals_390, primals_387, primals_388, True, 0.1, 1e-05);  primals_390 = None
        getitem_187 = native_batch_norm_default_39[0]
        getitem_188 = native_batch_norm_default_39[1]
        getitem_189 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(cat_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_30 = torch.ops.aten.clone.default(getitem_187)
        silu__default_30 = torch.ops.aten.silu_.default(getitem_187);  getitem_187 = None
        split_with_sizes_default_29 = torch.ops.aten.split_with_sizes.default(silu__default_30, [120, 120, 120, 120], 1);  silu__default_30 = None
        getitem_190 = split_with_sizes_default_29[0]
        getitem_191 = split_with_sizes_default_29[1]
        getitem_192 = split_with_sizes_default_29[2]
        getitem_193 = split_with_sizes_default_29[3];  split_with_sizes_default_29 = None
        convolution_default_101 = torch.ops.aten.convolution.default(getitem_190, primals_119, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        convolution_default_102 = torch.ops.aten.convolution.default(getitem_191, primals_120, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 120)
        convolution_default_103 = torch.ops.aten.convolution.default(getitem_192, primals_121, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 120)
        convolution_default_104 = torch.ops.aten.convolution.default(getitem_193, primals_122, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 120)
        cat_default_29 = torch.ops.aten.cat.default([convolution_default_101, convolution_default_102, convolution_default_103, convolution_default_104], 1);  convolution_default_101 = convolution_default_102 = convolution_default_103 = convolution_default_104 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(primals_391, 1);  primals_391 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(cat_default_29, primals_394, primals_395, primals_392, primals_393, True, 0.1, 1e-05);  primals_395 = None
        getitem_194 = native_batch_norm_default_40[0]
        getitem_195 = native_batch_norm_default_40[1]
        getitem_196 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(cat_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_31 = torch.ops.aten.clone.default(getitem_194)
        silu__default_31 = torch.ops.aten.silu_.default(getitem_194);  getitem_194 = None
        mean_dim_10 = torch.ops.aten.mean.dim(silu__default_31, [2, 3], True)
        convolution_default_105 = torch.ops.aten.convolution.default(mean_dim_10, primals_130, primals_129, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_129 = None
        clone_default_32 = torch.ops.aten.clone.default(convolution_default_105)
        silu__default_32 = torch.ops.aten.silu_.default(convolution_default_105);  convolution_default_105 = None
        convolution_default_106 = torch.ops.aten.convolution.default(silu__default_32, primals_128, primals_127, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_127 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_106);  convolution_default_106 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(silu__default_31, sigmoid_default_10)
        split_with_sizes_default_30 = torch.ops.aten.split_with_sizes.default(mul_tensor_10, [240, 240], 1);  mul_tensor_10 = None
        getitem_197 = split_with_sizes_default_30[0]
        getitem_198 = split_with_sizes_default_30[1];  split_with_sizes_default_30 = None
        convolution_default_107 = torch.ops.aten.convolution.default(getitem_197, primals_125, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_108 = torch.ops.aten.convolution.default(getitem_198, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_30 = torch.ops.aten.cat.default([convolution_default_107, convolution_default_108], 1);  convolution_default_107 = convolution_default_108 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_396, 1);  primals_396 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(cat_default_30, primals_399, primals_400, primals_397, primals_398, True, 0.1, 1e-05);  primals_400 = None
        getitem_199 = native_batch_norm_default_41[0]
        getitem_200 = native_batch_norm_default_41[1]
        getitem_201 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(cat_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_51 = torch.ops.aten.add.Tensor(getitem_199, add_tensor_47);  getitem_199 = add_tensor_47 = None
        split_with_sizes_default_31 = torch.ops.aten.split_with_sizes.default(add_tensor_51, [80, 80], 1)
        getitem_202 = split_with_sizes_default_31[0]
        getitem_203 = split_with_sizes_default_31[1];  split_with_sizes_default_31 = None
        convolution_default_109 = torch.ops.aten.convolution.default(getitem_202, primals_135, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_110 = torch.ops.aten.convolution.default(getitem_203, primals_136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_31 = torch.ops.aten.cat.default([convolution_default_109, convolution_default_110], 1);  convolution_default_109 = convolution_default_110 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_401, 1);  primals_401 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(cat_default_31, primals_404, primals_405, primals_402, primals_403, True, 0.1, 1e-05);  primals_405 = None
        getitem_204 = native_batch_norm_default_42[0]
        getitem_205 = native_batch_norm_default_42[1]
        getitem_206 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(cat_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_33 = torch.ops.aten.clone.default(getitem_204)
        silu__default_33 = torch.ops.aten.silu_.default(getitem_204);  getitem_204 = None
        split_with_sizes_default_32 = torch.ops.aten.split_with_sizes.default(silu__default_33, [120, 120, 120, 120], 1);  silu__default_33 = None
        getitem_207 = split_with_sizes_default_32[0]
        getitem_208 = split_with_sizes_default_32[1]
        getitem_209 = split_with_sizes_default_32[2]
        getitem_210 = split_with_sizes_default_32[3];  split_with_sizes_default_32 = None
        convolution_default_111 = torch.ops.aten.convolution.default(getitem_207, primals_131, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        convolution_default_112 = torch.ops.aten.convolution.default(getitem_208, primals_132, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 120)
        convolution_default_113 = torch.ops.aten.convolution.default(getitem_209, primals_133, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 120)
        convolution_default_114 = torch.ops.aten.convolution.default(getitem_210, primals_134, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 120)
        cat_default_32 = torch.ops.aten.cat.default([convolution_default_111, convolution_default_112, convolution_default_113, convolution_default_114], 1);  convolution_default_111 = convolution_default_112 = convolution_default_113 = convolution_default_114 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(primals_406, 1);  primals_406 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(cat_default_32, primals_409, primals_410, primals_407, primals_408, True, 0.1, 1e-05);  primals_410 = None
        getitem_211 = native_batch_norm_default_43[0]
        getitem_212 = native_batch_norm_default_43[1]
        getitem_213 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(cat_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_34 = torch.ops.aten.clone.default(getitem_211)
        silu__default_34 = torch.ops.aten.silu_.default(getitem_211);  getitem_211 = None
        mean_dim_11 = torch.ops.aten.mean.dim(silu__default_34, [2, 3], True)
        convolution_default_115 = torch.ops.aten.convolution.default(mean_dim_11, primals_142, primals_141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_141 = None
        clone_default_35 = torch.ops.aten.clone.default(convolution_default_115)
        silu__default_35 = torch.ops.aten.silu_.default(convolution_default_115);  convolution_default_115 = None
        convolution_default_116 = torch.ops.aten.convolution.default(silu__default_35, primals_140, primals_139, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_139 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_116);  convolution_default_116 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(silu__default_34, sigmoid_default_11)
        split_with_sizes_default_33 = torch.ops.aten.split_with_sizes.default(mul_tensor_11, [240, 240], 1);  mul_tensor_11 = None
        getitem_214 = split_with_sizes_default_33[0]
        getitem_215 = split_with_sizes_default_33[1];  split_with_sizes_default_33 = None
        convolution_default_117 = torch.ops.aten.convolution.default(getitem_214, primals_137, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_118 = torch.ops.aten.convolution.default(getitem_215, primals_138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_33 = torch.ops.aten.cat.default([convolution_default_117, convolution_default_118], 1);  convolution_default_117 = convolution_default_118 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_411, 1);  primals_411 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(cat_default_33, primals_414, primals_415, primals_412, primals_413, True, 0.1, 1e-05);  primals_415 = None
        getitem_216 = native_batch_norm_default_44[0]
        getitem_217 = native_batch_norm_default_44[1]
        getitem_218 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(cat_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_55 = torch.ops.aten.add.Tensor(getitem_216, add_tensor_51);  getitem_216 = add_tensor_51 = None
        convolution_default_119 = torch.ops.aten.convolution.default(add_tensor_55, primals_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_416, 1);  primals_416 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_419, primals_420, primals_417, primals_418, True, 0.1, 1e-05);  primals_420 = None
        getitem_219 = native_batch_norm_default_45[0]
        getitem_220 = native_batch_norm_default_45[1]
        getitem_221 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_119, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_36 = torch.ops.aten.clone.default(getitem_219)
        silu__default_36 = torch.ops.aten.silu_.default(getitem_219);  getitem_219 = None
        split_with_sizes_default_34 = torch.ops.aten.split_with_sizes.default(silu__default_36, [240, 240, 240, 240], 1);  silu__default_36 = None
        getitem_222 = split_with_sizes_default_34[0]
        getitem_223 = split_with_sizes_default_34[1]
        getitem_224 = split_with_sizes_default_34[2]
        getitem_225 = split_with_sizes_default_34[3];  split_with_sizes_default_34 = None
        convolution_default_120 = torch.ops.aten.convolution.default(getitem_222, primals_143, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 240)
        convolution_default_121 = torch.ops.aten.convolution.default(getitem_223, primals_144, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 240)
        convolution_default_122 = torch.ops.aten.convolution.default(getitem_224, primals_145, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 240)
        convolution_default_123 = torch.ops.aten.convolution.default(getitem_225, primals_146, None, [2, 2], [4, 4], [1, 1], False, [0, 0], 240)
        cat_default_34 = torch.ops.aten.cat.default([convolution_default_120, convolution_default_121, convolution_default_122, convolution_default_123], 1);  convolution_default_120 = convolution_default_121 = convolution_default_122 = convolution_default_123 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_421, 1);  primals_421 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(cat_default_34, primals_424, primals_425, primals_422, primals_423, True, 0.1, 1e-05);  primals_425 = None
        getitem_226 = native_batch_norm_default_46[0]
        getitem_227 = native_batch_norm_default_46[1]
        getitem_228 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(cat_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_37 = torch.ops.aten.clone.default(getitem_226)
        silu__default_37 = torch.ops.aten.silu_.default(getitem_226);  getitem_226 = None
        mean_dim_12 = torch.ops.aten.mean.dim(silu__default_37, [2, 3], True)
        convolution_default_124 = torch.ops.aten.convolution.default(mean_dim_12, primals_152, primals_151, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_151 = None
        clone_default_38 = torch.ops.aten.clone.default(convolution_default_124)
        silu__default_38 = torch.ops.aten.silu_.default(convolution_default_124);  convolution_default_124 = None
        convolution_default_125 = torch.ops.aten.convolution.default(silu__default_38, primals_150, primals_149, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_149 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_125);  convolution_default_125 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(silu__default_37, sigmoid_default_12)
        convolution_default_126 = torch.ops.aten.convolution.default(mul_tensor_12, primals_148, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_58 = torch.ops.aten.add.Tensor(primals_426, 1);  primals_426 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_429, primals_430, primals_427, primals_428, True, 0.1, 1e-05);  primals_430 = None
        getitem_229 = native_batch_norm_default_47[0]
        getitem_230 = native_batch_norm_default_47[1]
        getitem_231 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_126, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_127 = torch.ops.aten.convolution.default(getitem_229, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_59 = torch.ops.aten.add.Tensor(primals_431, 1);  primals_431 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_434, primals_435, primals_432, primals_433, True, 0.1, 1e-05);  primals_435 = None
        getitem_232 = native_batch_norm_default_48[0]
        getitem_233 = native_batch_norm_default_48[1]
        getitem_234 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_127, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_39 = torch.ops.aten.clone.default(getitem_232)
        silu__default_39 = torch.ops.aten.silu_.default(getitem_232);  getitem_232 = None
        split_with_sizes_default_35 = torch.ops.aten.split_with_sizes.default(silu__default_39, [396, 396, 396, 396], 1);  silu__default_39 = None
        getitem_235 = split_with_sizes_default_35[0]
        getitem_236 = split_with_sizes_default_35[1]
        getitem_237 = split_with_sizes_default_35[2]
        getitem_238 = split_with_sizes_default_35[3];  split_with_sizes_default_35 = None
        convolution_default_128 = torch.ops.aten.convolution.default(getitem_235, primals_153, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 396)
        convolution_default_129 = torch.ops.aten.convolution.default(getitem_236, primals_154, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 396)
        convolution_default_130 = torch.ops.aten.convolution.default(getitem_237, primals_155, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 396)
        convolution_default_131 = torch.ops.aten.convolution.default(getitem_238, primals_156, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 396)
        cat_default_35 = torch.ops.aten.cat.default([convolution_default_128, convolution_default_129, convolution_default_130, convolution_default_131], 1);  convolution_default_128 = convolution_default_129 = convolution_default_130 = convolution_default_131 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(primals_436, 1);  primals_436 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(cat_default_35, primals_439, primals_440, primals_437, primals_438, True, 0.1, 1e-05);  primals_440 = None
        getitem_239 = native_batch_norm_default_49[0]
        getitem_240 = native_batch_norm_default_49[1]
        getitem_241 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(cat_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_40 = torch.ops.aten.clone.default(getitem_239)
        silu__default_40 = torch.ops.aten.silu_.default(getitem_239);  getitem_239 = None
        mean_dim_13 = torch.ops.aten.mean.dim(silu__default_40, [2, 3], True)
        convolution_default_132 = torch.ops.aten.convolution.default(mean_dim_13, primals_163, primals_162, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_162 = None
        clone_default_41 = torch.ops.aten.clone.default(convolution_default_132)
        silu__default_41 = torch.ops.aten.silu_.default(convolution_default_132);  convolution_default_132 = None
        convolution_default_133 = torch.ops.aten.convolution.default(silu__default_41, primals_161, primals_160, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_160 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_133);  convolution_default_133 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(silu__default_40, sigmoid_default_13)
        split_with_sizes_default_36 = torch.ops.aten.split_with_sizes.default(mul_tensor_13, [792, 792], 1);  mul_tensor_13 = None
        getitem_242 = split_with_sizes_default_36[0]
        getitem_243 = split_with_sizes_default_36[1];  split_with_sizes_default_36 = None
        convolution_default_134 = torch.ops.aten.convolution.default(getitem_242, primals_158, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_135 = torch.ops.aten.convolution.default(getitem_243, primals_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_36 = torch.ops.aten.cat.default([convolution_default_134, convolution_default_135], 1);  convolution_default_134 = convolution_default_135 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_441, 1);  primals_441 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(cat_default_36, primals_444, primals_445, primals_442, primals_443, True, 0.1, 1e-05);  primals_445 = None
        getitem_244 = native_batch_norm_default_50[0]
        getitem_245 = native_batch_norm_default_50[1]
        getitem_246 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(cat_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_244, getitem_229);  getitem_244 = None
        convolution_default_136 = torch.ops.aten.convolution.default(add_tensor_62, primals_168, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_63 = torch.ops.aten.add.Tensor(primals_446, 1);  primals_446 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_449, primals_450, primals_447, primals_448, True, 0.1, 1e-05);  primals_450 = None
        getitem_247 = native_batch_norm_default_51[0]
        getitem_248 = native_batch_norm_default_51[1]
        getitem_249 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_136, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_42 = torch.ops.aten.clone.default(getitem_247)
        silu__default_42 = torch.ops.aten.silu_.default(getitem_247);  getitem_247 = None
        split_with_sizes_default_37 = torch.ops.aten.split_with_sizes.default(silu__default_42, [396, 396, 396, 396], 1);  silu__default_42 = None
        getitem_250 = split_with_sizes_default_37[0]
        getitem_251 = split_with_sizes_default_37[1]
        getitem_252 = split_with_sizes_default_37[2]
        getitem_253 = split_with_sizes_default_37[3];  split_with_sizes_default_37 = None
        convolution_default_137 = torch.ops.aten.convolution.default(getitem_250, primals_164, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 396)
        convolution_default_138 = torch.ops.aten.convolution.default(getitem_251, primals_165, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 396)
        convolution_default_139 = torch.ops.aten.convolution.default(getitem_252, primals_166, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 396)
        convolution_default_140 = torch.ops.aten.convolution.default(getitem_253, primals_167, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 396)
        cat_default_37 = torch.ops.aten.cat.default([convolution_default_137, convolution_default_138, convolution_default_139, convolution_default_140], 1);  convolution_default_137 = convolution_default_138 = convolution_default_139 = convolution_default_140 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(primals_451, 1);  primals_451 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(cat_default_37, primals_454, primals_455, primals_452, primals_453, True, 0.1, 1e-05);  primals_455 = None
        getitem_254 = native_batch_norm_default_52[0]
        getitem_255 = native_batch_norm_default_52[1]
        getitem_256 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(cat_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_43 = torch.ops.aten.clone.default(getitem_254)
        silu__default_43 = torch.ops.aten.silu_.default(getitem_254);  getitem_254 = None
        mean_dim_14 = torch.ops.aten.mean.dim(silu__default_43, [2, 3], True)
        convolution_default_141 = torch.ops.aten.convolution.default(mean_dim_14, primals_174, primals_173, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_173 = None
        clone_default_44 = torch.ops.aten.clone.default(convolution_default_141)
        silu__default_44 = torch.ops.aten.silu_.default(convolution_default_141);  convolution_default_141 = None
        convolution_default_142 = torch.ops.aten.convolution.default(silu__default_44, primals_172, primals_171, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_171 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_142);  convolution_default_142 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(silu__default_43, sigmoid_default_14)
        split_with_sizes_default_38 = torch.ops.aten.split_with_sizes.default(mul_tensor_14, [792, 792], 1);  mul_tensor_14 = None
        getitem_257 = split_with_sizes_default_38[0]
        getitem_258 = split_with_sizes_default_38[1];  split_with_sizes_default_38 = None
        convolution_default_143 = torch.ops.aten.convolution.default(getitem_257, primals_169, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_144 = torch.ops.aten.convolution.default(getitem_258, primals_170, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_38 = torch.ops.aten.cat.default([convolution_default_143, convolution_default_144], 1);  convolution_default_143 = convolution_default_144 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(primals_456, 1);  primals_456 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(cat_default_38, primals_459, primals_460, primals_457, primals_458, True, 0.1, 1e-05);  primals_460 = None
        getitem_259 = native_batch_norm_default_53[0]
        getitem_260 = native_batch_norm_default_53[1]
        getitem_261 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(cat_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_66 = torch.ops.aten.add.Tensor(getitem_259, add_tensor_62);  getitem_259 = None
        convolution_default_145 = torch.ops.aten.convolution.default(add_tensor_66, primals_179, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_67 = torch.ops.aten.add.Tensor(primals_461, 1);  primals_461 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_464, primals_465, primals_462, primals_463, True, 0.1, 1e-05);  primals_465 = None
        getitem_262 = native_batch_norm_default_54[0]
        getitem_263 = native_batch_norm_default_54[1]
        getitem_264 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_145, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_45 = torch.ops.aten.clone.default(getitem_262)
        silu__default_45 = torch.ops.aten.silu_.default(getitem_262);  getitem_262 = None
        split_with_sizes_default_39 = torch.ops.aten.split_with_sizes.default(silu__default_45, [396, 396, 396, 396], 1);  silu__default_45 = None
        getitem_265 = split_with_sizes_default_39[0]
        getitem_266 = split_with_sizes_default_39[1]
        getitem_267 = split_with_sizes_default_39[2]
        getitem_268 = split_with_sizes_default_39[3];  split_with_sizes_default_39 = None
        convolution_default_146 = torch.ops.aten.convolution.default(getitem_265, primals_175, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 396)
        convolution_default_147 = torch.ops.aten.convolution.default(getitem_266, primals_176, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 396)
        convolution_default_148 = torch.ops.aten.convolution.default(getitem_267, primals_177, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 396)
        convolution_default_149 = torch.ops.aten.convolution.default(getitem_268, primals_178, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 396)
        cat_default_39 = torch.ops.aten.cat.default([convolution_default_146, convolution_default_147, convolution_default_148, convolution_default_149], 1);  convolution_default_146 = convolution_default_147 = convolution_default_148 = convolution_default_149 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(primals_466, 1);  primals_466 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(cat_default_39, primals_469, primals_470, primals_467, primals_468, True, 0.1, 1e-05);  primals_470 = None
        getitem_269 = native_batch_norm_default_55[0]
        getitem_270 = native_batch_norm_default_55[1]
        getitem_271 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(cat_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        clone_default_46 = torch.ops.aten.clone.default(getitem_269)
        silu__default_46 = torch.ops.aten.silu_.default(getitem_269);  getitem_269 = None
        mean_dim_15 = torch.ops.aten.mean.dim(silu__default_46, [2, 3], True)
        convolution_default_150 = torch.ops.aten.convolution.default(mean_dim_15, primals_185, primals_184, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_184 = None
        clone_default_47 = torch.ops.aten.clone.default(convolution_default_150)
        silu__default_47 = torch.ops.aten.silu_.default(convolution_default_150);  convolution_default_150 = None
        convolution_default_151 = torch.ops.aten.convolution.default(silu__default_47, primals_183, primals_182, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_182 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_151);  convolution_default_151 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(silu__default_46, sigmoid_default_15)
        split_with_sizes_default_40 = torch.ops.aten.split_with_sizes.default(mul_tensor_15, [792, 792], 1);  mul_tensor_15 = None
        getitem_272 = split_with_sizes_default_40[0]
        getitem_273 = split_with_sizes_default_40[1];  split_with_sizes_default_40 = None
        convolution_default_152 = torch.ops.aten.convolution.default(getitem_272, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_153 = torch.ops.aten.convolution.default(getitem_273, primals_181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_40 = torch.ops.aten.cat.default([convolution_default_152, convolution_default_153], 1);  convolution_default_152 = convolution_default_153 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(primals_471, 1);  primals_471 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(cat_default_40, primals_474, primals_475, primals_472, primals_473, True, 0.1, 1e-05);  primals_475 = None
        getitem_274 = native_batch_norm_default_56[0]
        getitem_275 = native_batch_norm_default_56[1]
        getitem_276 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(cat_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_274, add_tensor_66);  getitem_274 = None
        convolution_default_154 = torch.ops.aten.convolution.default(add_tensor_70, primals_188, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_71 = torch.ops.aten.add.Tensor(primals_476, 1);  primals_476 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_479, primals_480, primals_477, primals_478, True, 0.1, 1e-05);  primals_480 = None
        getitem_277 = native_batch_norm_default_57[0]
        getitem_278 = native_batch_norm_default_57[1]
        getitem_279 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_154, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_277);  getitem_277 = None
        mean_dim_16 = torch.ops.aten.mean.dim(relu__default_6, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_16, [128, 1536]);  mean_dim_16 = None
        t_default = torch.ops.aten.t.default(primals_187);  primals_187 = None
        addmm_default = torch.ops.aten.addmm.default(primals_186, view_default, t_default);  primals_186 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1536, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1536, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_58, to_dtype);  le_scalar = new_zeros_default_58 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_154, primals_479, primals_477, primals_478, getitem_278, getitem_279, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_154 = primals_479 = primals_477 = primals_478 = getitem_278 = getitem_279 = None
        getitem_280 = native_batch_norm_backward_default[0]
        getitem_281 = native_batch_norm_backward_default[1]
        getitem_282 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_280, add_tensor_70, primals_188, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_280 = add_tensor_70 = primals_188 = None
        getitem_283 = convolution_backward_default[0]
        getitem_284 = convolution_backward_default[1]
        getitem_285 = convolution_backward_default[2];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_283, cat_default_40, primals_474, primals_472, primals_473, getitem_275, getitem_276, True, 1e-05, [True, True, True]);  cat_default_40 = primals_474 = primals_472 = primals_473 = getitem_275 = getitem_276 = None
        getitem_286 = native_batch_norm_backward_default_1[0]
        getitem_287 = native_batch_norm_backward_default_1[1]
        getitem_288 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_286, 1, 0, 132)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_286, 1, 132, 264);  getitem_286 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(slice_tensor_1, getitem_273, primals_181, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_1 = getitem_273 = primals_181 = None
        getitem_289 = convolution_backward_default_1[0]
        getitem_290 = convolution_backward_default_1[1]
        getitem_291 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(slice_tensor, getitem_272, primals_180, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor = getitem_272 = primals_180 = None
        getitem_292 = convolution_backward_default_2[0]
        getitem_293 = convolution_backward_default_2[1]
        getitem_294 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        cat_default_41 = torch.ops.aten.cat.default([getitem_292, getitem_289], 1);  getitem_292 = getitem_289 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(cat_default_41, silu__default_46);  silu__default_46 = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(cat_default_41, sigmoid_default_15);  cat_default_41 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(mul_tensor_16, [2, 3], True);  mul_tensor_16 = None
        to_dtype_3 = torch.ops.aten.to.dtype(sum_dim_int_list_1, torch.float32);  sum_dim_int_list_1 = None
        to_dtype_4 = torch.ops.aten.to.dtype(sigmoid_default_15, torch.float32);  sigmoid_default_15 = None
        rsub_scalar = torch.ops.aten.rsub.Scalar(to_dtype_4, 1)
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype_4, rsub_scalar);  to_dtype_4 = rsub_scalar = None
        conj_physical_default = torch.ops.aten.conj_physical.default(mul_tensor_18);  mul_tensor_18 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(to_dtype_3, conj_physical_default);  to_dtype_3 = conj_physical_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_19, torch.float32);  mul_tensor_19 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(to_dtype_5, silu__default_47, primals_183, [1584], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_5 = silu__default_47 = primals_183 = None
        getitem_295 = convolution_backward_default_3[0]
        getitem_296 = convolution_backward_default_3[1]
        getitem_297 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_295, torch.float32);  getitem_295 = None
        to_dtype_7 = torch.ops.aten.to.dtype(clone_default_47, torch.float32);  clone_default_47 = None
        neg_default = torch.ops.aten.neg.default(to_dtype_7)
        exp_default = torch.ops.aten.exp.default(neg_default);  neg_default = None
        add_tensor_72 = torch.ops.aten.add.Tensor(exp_default, 1);  exp_default = None
        reciprocal_default = torch.ops.aten.reciprocal.default(add_tensor_72);  add_tensor_72 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(reciprocal_default, 1);  reciprocal_default = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(to_dtype_6, mul_tensor_20);  to_dtype_6 = None
        rsub_scalar_1 = torch.ops.aten.rsub.Scalar(mul_tensor_20, 1);  mul_tensor_20 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_7, rsub_scalar_1);  to_dtype_7 = rsub_scalar_1 = None
        add_tensor_73 = torch.ops.aten.add.Tensor(mul_tensor_22, 1);  mul_tensor_22 = None
        mul_tensor_23 = torch.ops.aten.mul.Tensor(mul_tensor_21, add_tensor_73);  mul_tensor_21 = add_tensor_73 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_23, torch.float32);  mul_tensor_23 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(to_dtype_8, mean_dim_15, primals_185, [132], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_8 = mean_dim_15 = primals_185 = None
        getitem_298 = convolution_backward_default_4[0]
        getitem_299 = convolution_backward_default_4[1]
        getitem_300 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        expand_default_1 = torch.ops.aten.expand.default(getitem_298, [128, 1584, 7, 7]);  getitem_298 = None
        div_scalar_1 = torch.ops.aten.div.Scalar(expand_default_1, 49);  expand_default_1 = None
        add_tensor_74 = torch.ops.aten.add.Tensor(mul_tensor_17, div_scalar_1);  mul_tensor_17 = div_scalar_1 = None
        to_dtype_9 = torch.ops.aten.to.dtype(add_tensor_74, torch.float32);  add_tensor_74 = None
        to_dtype_10 = torch.ops.aten.to.dtype(clone_default_46, torch.float32);  clone_default_46 = None
        neg_default_1 = torch.ops.aten.neg.default(to_dtype_10)
        exp_default_1 = torch.ops.aten.exp.default(neg_default_1);  neg_default_1 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(exp_default_1, 1);  exp_default_1 = None
        reciprocal_default_1 = torch.ops.aten.reciprocal.default(add_tensor_75);  add_tensor_75 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(reciprocal_default_1, 1);  reciprocal_default_1 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_9, mul_tensor_24);  to_dtype_9 = None
        rsub_scalar_2 = torch.ops.aten.rsub.Scalar(mul_tensor_24, 1);  mul_tensor_24 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_10, rsub_scalar_2);  to_dtype_10 = rsub_scalar_2 = None
        add_tensor_76 = torch.ops.aten.add.Tensor(mul_tensor_26, 1);  mul_tensor_26 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(mul_tensor_25, add_tensor_76);  mul_tensor_25 = add_tensor_76 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_27, torch.float32);  mul_tensor_27 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, cat_default_39, primals_469, primals_467, primals_468, getitem_270, getitem_271, True, 1e-05, [True, True, True]);  to_dtype_11 = cat_default_39 = primals_469 = primals_467 = primals_468 = getitem_270 = getitem_271 = None
        getitem_301 = native_batch_norm_backward_default_2[0]
        getitem_302 = native_batch_norm_backward_default_2[1]
        getitem_303 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_301, 1, 0, 396)
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_301, 1, 396, 792)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_301, 1, 792, 1188)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_301, 1, 1188, 1584);  getitem_301 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(slice_tensor_5, getitem_268, primals_178, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_5 = getitem_268 = primals_178 = None
        getitem_304 = convolution_backward_default_5[0]
        getitem_305 = convolution_backward_default_5[1]
        getitem_306 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(slice_tensor_4, getitem_267, primals_177, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_4 = getitem_267 = primals_177 = None
        getitem_307 = convolution_backward_default_6[0]
        getitem_308 = convolution_backward_default_6[1]
        getitem_309 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(slice_tensor_3, getitem_266, primals_176, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_3 = getitem_266 = primals_176 = None
        getitem_310 = convolution_backward_default_7[0]
        getitem_311 = convolution_backward_default_7[1]
        getitem_312 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(slice_tensor_2, getitem_265, primals_175, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_2 = getitem_265 = primals_175 = None
        getitem_313 = convolution_backward_default_8[0]
        getitem_314 = convolution_backward_default_8[1]
        getitem_315 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        cat_default_42 = torch.ops.aten.cat.default([getitem_313, getitem_310, getitem_307, getitem_304], 1);  getitem_313 = getitem_310 = getitem_307 = getitem_304 = None
        to_dtype_12 = torch.ops.aten.to.dtype(cat_default_42, torch.float32);  cat_default_42 = None
        to_dtype_13 = torch.ops.aten.to.dtype(clone_default_45, torch.float32);  clone_default_45 = None
        neg_default_2 = torch.ops.aten.neg.default(to_dtype_13)
        exp_default_2 = torch.ops.aten.exp.default(neg_default_2);  neg_default_2 = None
        add_tensor_77 = torch.ops.aten.add.Tensor(exp_default_2, 1);  exp_default_2 = None
        reciprocal_default_2 = torch.ops.aten.reciprocal.default(add_tensor_77);  add_tensor_77 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(reciprocal_default_2, 1);  reciprocal_default_2 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(to_dtype_12, mul_tensor_28);  to_dtype_12 = None
        rsub_scalar_3 = torch.ops.aten.rsub.Scalar(mul_tensor_28, 1);  mul_tensor_28 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_13, rsub_scalar_3);  to_dtype_13 = rsub_scalar_3 = None
        add_tensor_78 = torch.ops.aten.add.Tensor(mul_tensor_30, 1);  mul_tensor_30 = None
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_29, add_tensor_78);  mul_tensor_29 = add_tensor_78 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_31, torch.float32);  mul_tensor_31 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_145, primals_464, primals_462, primals_463, getitem_263, getitem_264, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_145 = primals_464 = primals_462 = primals_463 = getitem_263 = getitem_264 = None
        getitem_316 = native_batch_norm_backward_default_3[0]
        getitem_317 = native_batch_norm_backward_default_3[1]
        getitem_318 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_316, add_tensor_66, primals_179, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_316 = add_tensor_66 = primals_179 = None
        getitem_319 = convolution_backward_default_9[0]
        getitem_320 = convolution_backward_default_9[1]
        getitem_321 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(getitem_283, getitem_319);  getitem_283 = getitem_319 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_79, cat_default_38, primals_459, primals_457, primals_458, getitem_260, getitem_261, True, 1e-05, [True, True, True]);  cat_default_38 = primals_459 = primals_457 = primals_458 = getitem_260 = getitem_261 = None
        getitem_322 = native_batch_norm_backward_default_4[0]
        getitem_323 = native_batch_norm_backward_default_4[1]
        getitem_324 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_322, 1, 0, 132)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_322, 1, 132, 264);  getitem_322 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(slice_tensor_7, getitem_258, primals_170, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_7 = getitem_258 = primals_170 = None
        getitem_325 = convolution_backward_default_10[0]
        getitem_326 = convolution_backward_default_10[1]
        getitem_327 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(slice_tensor_6, getitem_257, primals_169, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_6 = getitem_257 = primals_169 = None
        getitem_328 = convolution_backward_default_11[0]
        getitem_329 = convolution_backward_default_11[1]
        getitem_330 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        cat_default_43 = torch.ops.aten.cat.default([getitem_328, getitem_325], 1);  getitem_328 = getitem_325 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(cat_default_43, silu__default_43);  silu__default_43 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(cat_default_43, sigmoid_default_14);  cat_default_43 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(mul_tensor_32, [2, 3], True);  mul_tensor_32 = None
        to_dtype_15 = torch.ops.aten.to.dtype(sum_dim_int_list_2, torch.float32);  sum_dim_int_list_2 = None
        to_dtype_16 = torch.ops.aten.to.dtype(sigmoid_default_14, torch.float32);  sigmoid_default_14 = None
        rsub_scalar_4 = torch.ops.aten.rsub.Scalar(to_dtype_16, 1)
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_16, rsub_scalar_4);  to_dtype_16 = rsub_scalar_4 = None
        conj_physical_default_1 = torch.ops.aten.conj_physical.default(mul_tensor_34);  mul_tensor_34 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(to_dtype_15, conj_physical_default_1);  to_dtype_15 = conj_physical_default_1 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_35, torch.float32);  mul_tensor_35 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(to_dtype_17, silu__default_44, primals_172, [1584], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_17 = silu__default_44 = primals_172 = None
        getitem_331 = convolution_backward_default_12[0]
        getitem_332 = convolution_backward_default_12[1]
        getitem_333 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_331, torch.float32);  getitem_331 = None
        to_dtype_19 = torch.ops.aten.to.dtype(clone_default_44, torch.float32);  clone_default_44 = None
        neg_default_3 = torch.ops.aten.neg.default(to_dtype_19)
        exp_default_3 = torch.ops.aten.exp.default(neg_default_3);  neg_default_3 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(exp_default_3, 1);  exp_default_3 = None
        reciprocal_default_3 = torch.ops.aten.reciprocal.default(add_tensor_80);  add_tensor_80 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(reciprocal_default_3, 1);  reciprocal_default_3 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(to_dtype_18, mul_tensor_36);  to_dtype_18 = None
        rsub_scalar_5 = torch.ops.aten.rsub.Scalar(mul_tensor_36, 1);  mul_tensor_36 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_19, rsub_scalar_5);  to_dtype_19 = rsub_scalar_5 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(mul_tensor_38, 1);  mul_tensor_38 = None
        mul_tensor_39 = torch.ops.aten.mul.Tensor(mul_tensor_37, add_tensor_81);  mul_tensor_37 = add_tensor_81 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_39, torch.float32);  mul_tensor_39 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(to_dtype_20, mean_dim_14, primals_174, [132], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_20 = mean_dim_14 = primals_174 = None
        getitem_334 = convolution_backward_default_13[0]
        getitem_335 = convolution_backward_default_13[1]
        getitem_336 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        expand_default_2 = torch.ops.aten.expand.default(getitem_334, [128, 1584, 7, 7]);  getitem_334 = None
        div_scalar_2 = torch.ops.aten.div.Scalar(expand_default_2, 49);  expand_default_2 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(mul_tensor_33, div_scalar_2);  mul_tensor_33 = div_scalar_2 = None
        to_dtype_21 = torch.ops.aten.to.dtype(add_tensor_82, torch.float32);  add_tensor_82 = None
        to_dtype_22 = torch.ops.aten.to.dtype(clone_default_43, torch.float32);  clone_default_43 = None
        neg_default_4 = torch.ops.aten.neg.default(to_dtype_22)
        exp_default_4 = torch.ops.aten.exp.default(neg_default_4);  neg_default_4 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(exp_default_4, 1);  exp_default_4 = None
        reciprocal_default_4 = torch.ops.aten.reciprocal.default(add_tensor_83);  add_tensor_83 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(reciprocal_default_4, 1);  reciprocal_default_4 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_21, mul_tensor_40);  to_dtype_21 = None
        rsub_scalar_6 = torch.ops.aten.rsub.Scalar(mul_tensor_40, 1);  mul_tensor_40 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_22, rsub_scalar_6);  to_dtype_22 = rsub_scalar_6 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(mul_tensor_42, 1);  mul_tensor_42 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(mul_tensor_41, add_tensor_84);  mul_tensor_41 = add_tensor_84 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_43, torch.float32);  mul_tensor_43 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, cat_default_37, primals_454, primals_452, primals_453, getitem_255, getitem_256, True, 1e-05, [True, True, True]);  to_dtype_23 = cat_default_37 = primals_454 = primals_452 = primals_453 = getitem_255 = getitem_256 = None
        getitem_337 = native_batch_norm_backward_default_5[0]
        getitem_338 = native_batch_norm_backward_default_5[1]
        getitem_339 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        slice_tensor_8 = torch.ops.aten.slice.Tensor(getitem_337, 1, 0, 396)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(getitem_337, 1, 396, 792)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_337, 1, 792, 1188)
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_337, 1, 1188, 1584);  getitem_337 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(slice_tensor_11, getitem_253, primals_167, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_11 = getitem_253 = primals_167 = None
        getitem_340 = convolution_backward_default_14[0]
        getitem_341 = convolution_backward_default_14[1]
        getitem_342 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(slice_tensor_10, getitem_252, primals_166, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_10 = getitem_252 = primals_166 = None
        getitem_343 = convolution_backward_default_15[0]
        getitem_344 = convolution_backward_default_15[1]
        getitem_345 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(slice_tensor_9, getitem_251, primals_165, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_9 = getitem_251 = primals_165 = None
        getitem_346 = convolution_backward_default_16[0]
        getitem_347 = convolution_backward_default_16[1]
        getitem_348 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(slice_tensor_8, getitem_250, primals_164, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_8 = getitem_250 = primals_164 = None
        getitem_349 = convolution_backward_default_17[0]
        getitem_350 = convolution_backward_default_17[1]
        getitem_351 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        cat_default_44 = torch.ops.aten.cat.default([getitem_349, getitem_346, getitem_343, getitem_340], 1);  getitem_349 = getitem_346 = getitem_343 = getitem_340 = None
        to_dtype_24 = torch.ops.aten.to.dtype(cat_default_44, torch.float32);  cat_default_44 = None
        to_dtype_25 = torch.ops.aten.to.dtype(clone_default_42, torch.float32);  clone_default_42 = None
        neg_default_5 = torch.ops.aten.neg.default(to_dtype_25)
        exp_default_5 = torch.ops.aten.exp.default(neg_default_5);  neg_default_5 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(exp_default_5, 1);  exp_default_5 = None
        reciprocal_default_5 = torch.ops.aten.reciprocal.default(add_tensor_85);  add_tensor_85 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(reciprocal_default_5, 1);  reciprocal_default_5 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(to_dtype_24, mul_tensor_44);  to_dtype_24 = None
        rsub_scalar_7 = torch.ops.aten.rsub.Scalar(mul_tensor_44, 1);  mul_tensor_44 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_25, rsub_scalar_7);  to_dtype_25 = rsub_scalar_7 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(mul_tensor_46, 1);  mul_tensor_46 = None
        mul_tensor_47 = torch.ops.aten.mul.Tensor(mul_tensor_45, add_tensor_86);  mul_tensor_45 = add_tensor_86 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_47, torch.float32);  mul_tensor_47 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_136, primals_449, primals_447, primals_448, getitem_248, getitem_249, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_136 = primals_449 = primals_447 = primals_448 = getitem_248 = getitem_249 = None
        getitem_352 = native_batch_norm_backward_default_6[0]
        getitem_353 = native_batch_norm_backward_default_6[1]
        getitem_354 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_352, add_tensor_62, primals_168, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_352 = add_tensor_62 = primals_168 = None
        getitem_355 = convolution_backward_default_18[0]
        getitem_356 = convolution_backward_default_18[1]
        getitem_357 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(add_tensor_79, getitem_355);  add_tensor_79 = getitem_355 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_87, cat_default_36, primals_444, primals_442, primals_443, getitem_245, getitem_246, True, 1e-05, [True, True, True]);  cat_default_36 = primals_444 = primals_442 = primals_443 = getitem_245 = getitem_246 = None
        getitem_358 = native_batch_norm_backward_default_7[0]
        getitem_359 = native_batch_norm_backward_default_7[1]
        getitem_360 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(getitem_358, 1, 0, 132)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(getitem_358, 1, 132, 264);  getitem_358 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(slice_tensor_13, getitem_243, primals_159, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_13 = getitem_243 = primals_159 = None
        getitem_361 = convolution_backward_default_19[0]
        getitem_362 = convolution_backward_default_19[1]
        getitem_363 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(slice_tensor_12, getitem_242, primals_158, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_12 = getitem_242 = primals_158 = None
        getitem_364 = convolution_backward_default_20[0]
        getitem_365 = convolution_backward_default_20[1]
        getitem_366 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        cat_default_45 = torch.ops.aten.cat.default([getitem_364, getitem_361], 1);  getitem_364 = getitem_361 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(cat_default_45, silu__default_40);  silu__default_40 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(cat_default_45, sigmoid_default_13);  cat_default_45 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(mul_tensor_48, [2, 3], True);  mul_tensor_48 = None
        to_dtype_27 = torch.ops.aten.to.dtype(sum_dim_int_list_3, torch.float32);  sum_dim_int_list_3 = None
        to_dtype_28 = torch.ops.aten.to.dtype(sigmoid_default_13, torch.float32);  sigmoid_default_13 = None
        rsub_scalar_8 = torch.ops.aten.rsub.Scalar(to_dtype_28, 1)
        mul_tensor_50 = torch.ops.aten.mul.Tensor(to_dtype_28, rsub_scalar_8);  to_dtype_28 = rsub_scalar_8 = None
        conj_physical_default_2 = torch.ops.aten.conj_physical.default(mul_tensor_50);  mul_tensor_50 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(to_dtype_27, conj_physical_default_2);  to_dtype_27 = conj_physical_default_2 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_51, torch.float32);  mul_tensor_51 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(to_dtype_29, silu__default_41, primals_161, [1584], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_29 = silu__default_41 = primals_161 = None
        getitem_367 = convolution_backward_default_21[0]
        getitem_368 = convolution_backward_default_21[1]
        getitem_369 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_367, torch.float32);  getitem_367 = None
        to_dtype_31 = torch.ops.aten.to.dtype(clone_default_41, torch.float32);  clone_default_41 = None
        neg_default_6 = torch.ops.aten.neg.default(to_dtype_31)
        exp_default_6 = torch.ops.aten.exp.default(neg_default_6);  neg_default_6 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(exp_default_6, 1);  exp_default_6 = None
        reciprocal_default_6 = torch.ops.aten.reciprocal.default(add_tensor_88);  add_tensor_88 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(reciprocal_default_6, 1);  reciprocal_default_6 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(to_dtype_30, mul_tensor_52);  to_dtype_30 = None
        rsub_scalar_9 = torch.ops.aten.rsub.Scalar(mul_tensor_52, 1);  mul_tensor_52 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_31, rsub_scalar_9);  to_dtype_31 = rsub_scalar_9 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(mul_tensor_54, 1);  mul_tensor_54 = None
        mul_tensor_55 = torch.ops.aten.mul.Tensor(mul_tensor_53, add_tensor_89);  mul_tensor_53 = add_tensor_89 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_55, torch.float32);  mul_tensor_55 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(to_dtype_32, mean_dim_13, primals_163, [132], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_32 = mean_dim_13 = primals_163 = None
        getitem_370 = convolution_backward_default_22[0]
        getitem_371 = convolution_backward_default_22[1]
        getitem_372 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        expand_default_3 = torch.ops.aten.expand.default(getitem_370, [128, 1584, 7, 7]);  getitem_370 = None
        div_scalar_3 = torch.ops.aten.div.Scalar(expand_default_3, 49);  expand_default_3 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(mul_tensor_49, div_scalar_3);  mul_tensor_49 = div_scalar_3 = None
        to_dtype_33 = torch.ops.aten.to.dtype(add_tensor_90, torch.float32);  add_tensor_90 = None
        to_dtype_34 = torch.ops.aten.to.dtype(clone_default_40, torch.float32);  clone_default_40 = None
        neg_default_7 = torch.ops.aten.neg.default(to_dtype_34)
        exp_default_7 = torch.ops.aten.exp.default(neg_default_7);  neg_default_7 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(exp_default_7, 1);  exp_default_7 = None
        reciprocal_default_7 = torch.ops.aten.reciprocal.default(add_tensor_91);  add_tensor_91 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(reciprocal_default_7, 1);  reciprocal_default_7 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_33, mul_tensor_56);  to_dtype_33 = None
        rsub_scalar_10 = torch.ops.aten.rsub.Scalar(mul_tensor_56, 1);  mul_tensor_56 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_34, rsub_scalar_10);  to_dtype_34 = rsub_scalar_10 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(mul_tensor_58, 1);  mul_tensor_58 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(mul_tensor_57, add_tensor_92);  mul_tensor_57 = add_tensor_92 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_59, torch.float32);  mul_tensor_59 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, cat_default_35, primals_439, primals_437, primals_438, getitem_240, getitem_241, True, 1e-05, [True, True, True]);  to_dtype_35 = cat_default_35 = primals_439 = primals_437 = primals_438 = getitem_240 = getitem_241 = None
        getitem_373 = native_batch_norm_backward_default_8[0]
        getitem_374 = native_batch_norm_backward_default_8[1]
        getitem_375 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(getitem_373, 1, 0, 396)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_373, 1, 396, 792)
        slice_tensor_16 = torch.ops.aten.slice.Tensor(getitem_373, 1, 792, 1188)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(getitem_373, 1, 1188, 1584);  getitem_373 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(slice_tensor_17, getitem_238, primals_156, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_17 = getitem_238 = primals_156 = None
        getitem_376 = convolution_backward_default_23[0]
        getitem_377 = convolution_backward_default_23[1]
        getitem_378 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(slice_tensor_16, getitem_237, primals_155, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_16 = getitem_237 = primals_155 = None
        getitem_379 = convolution_backward_default_24[0]
        getitem_380 = convolution_backward_default_24[1]
        getitem_381 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(slice_tensor_15, getitem_236, primals_154, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_15 = getitem_236 = primals_154 = None
        getitem_382 = convolution_backward_default_25[0]
        getitem_383 = convolution_backward_default_25[1]
        getitem_384 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(slice_tensor_14, getitem_235, primals_153, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 396, [True, True, False]);  slice_tensor_14 = getitem_235 = primals_153 = None
        getitem_385 = convolution_backward_default_26[0]
        getitem_386 = convolution_backward_default_26[1]
        getitem_387 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        cat_default_46 = torch.ops.aten.cat.default([getitem_385, getitem_382, getitem_379, getitem_376], 1);  getitem_385 = getitem_382 = getitem_379 = getitem_376 = None
        to_dtype_36 = torch.ops.aten.to.dtype(cat_default_46, torch.float32);  cat_default_46 = None
        to_dtype_37 = torch.ops.aten.to.dtype(clone_default_39, torch.float32);  clone_default_39 = None
        neg_default_8 = torch.ops.aten.neg.default(to_dtype_37)
        exp_default_8 = torch.ops.aten.exp.default(neg_default_8);  neg_default_8 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(exp_default_8, 1);  exp_default_8 = None
        reciprocal_default_8 = torch.ops.aten.reciprocal.default(add_tensor_93);  add_tensor_93 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(reciprocal_default_8, 1);  reciprocal_default_8 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(to_dtype_36, mul_tensor_60);  to_dtype_36 = None
        rsub_scalar_11 = torch.ops.aten.rsub.Scalar(mul_tensor_60, 1);  mul_tensor_60 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_37, rsub_scalar_11);  to_dtype_37 = rsub_scalar_11 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(mul_tensor_62, 1);  mul_tensor_62 = None
        mul_tensor_63 = torch.ops.aten.mul.Tensor(mul_tensor_61, add_tensor_94);  mul_tensor_61 = add_tensor_94 = None
        to_dtype_38 = torch.ops.aten.to.dtype(mul_tensor_63, torch.float32);  mul_tensor_63 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_127, primals_434, primals_432, primals_433, getitem_233, getitem_234, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_127 = primals_434 = primals_432 = primals_433 = getitem_233 = getitem_234 = None
        getitem_388 = native_batch_norm_backward_default_9[0]
        getitem_389 = native_batch_norm_backward_default_9[1]
        getitem_390 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_388, getitem_229, primals_157, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_388 = getitem_229 = primals_157 = None
        getitem_391 = convolution_backward_default_27[0]
        getitem_392 = convolution_backward_default_27[1]
        getitem_393 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_87, getitem_391);  add_tensor_87 = getitem_391 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_95, convolution_default_126, primals_429, primals_427, primals_428, getitem_230, getitem_231, True, 1e-05, [True, True, True]);  add_tensor_95 = convolution_default_126 = primals_429 = primals_427 = primals_428 = getitem_230 = getitem_231 = None
        getitem_394 = native_batch_norm_backward_default_10[0]
        getitem_395 = native_batch_norm_backward_default_10[1]
        getitem_396 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_394, mul_tensor_12, primals_148, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_394 = mul_tensor_12 = primals_148 = None
        getitem_397 = convolution_backward_default_28[0]
        getitem_398 = convolution_backward_default_28[1]
        getitem_399 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(getitem_397, silu__default_37);  silu__default_37 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(getitem_397, sigmoid_default_12);  getitem_397 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(mul_tensor_64, [2, 3], True);  mul_tensor_64 = None
        to_dtype_39 = torch.ops.aten.to.dtype(sum_dim_int_list_4, torch.float32);  sum_dim_int_list_4 = None
        to_dtype_40 = torch.ops.aten.to.dtype(sigmoid_default_12, torch.float32);  sigmoid_default_12 = None
        rsub_scalar_12 = torch.ops.aten.rsub.Scalar(to_dtype_40, 1)
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_40, rsub_scalar_12);  to_dtype_40 = rsub_scalar_12 = None
        conj_physical_default_3 = torch.ops.aten.conj_physical.default(mul_tensor_66);  mul_tensor_66 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(to_dtype_39, conj_physical_default_3);  to_dtype_39 = conj_physical_default_3 = None
        to_dtype_41 = torch.ops.aten.to.dtype(mul_tensor_67, torch.float32);  mul_tensor_67 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(to_dtype_41, silu__default_38, primals_150, [960], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_41 = silu__default_38 = primals_150 = None
        getitem_400 = convolution_backward_default_29[0]
        getitem_401 = convolution_backward_default_29[1]
        getitem_402 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_400, torch.float32);  getitem_400 = None
        to_dtype_43 = torch.ops.aten.to.dtype(clone_default_38, torch.float32);  clone_default_38 = None
        neg_default_9 = torch.ops.aten.neg.default(to_dtype_43)
        exp_default_9 = torch.ops.aten.exp.default(neg_default_9);  neg_default_9 = None
        add_tensor_96 = torch.ops.aten.add.Tensor(exp_default_9, 1);  exp_default_9 = None
        reciprocal_default_9 = torch.ops.aten.reciprocal.default(add_tensor_96);  add_tensor_96 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(reciprocal_default_9, 1);  reciprocal_default_9 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(to_dtype_42, mul_tensor_68);  to_dtype_42 = None
        rsub_scalar_13 = torch.ops.aten.rsub.Scalar(mul_tensor_68, 1);  mul_tensor_68 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_43, rsub_scalar_13);  to_dtype_43 = rsub_scalar_13 = None
        add_tensor_97 = torch.ops.aten.add.Tensor(mul_tensor_70, 1);  mul_tensor_70 = None
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mul_tensor_69, add_tensor_97);  mul_tensor_69 = add_tensor_97 = None
        to_dtype_44 = torch.ops.aten.to.dtype(mul_tensor_71, torch.float32);  mul_tensor_71 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(to_dtype_44, mean_dim_12, primals_152, [80], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_44 = mean_dim_12 = primals_152 = None
        getitem_403 = convolution_backward_default_30[0]
        getitem_404 = convolution_backward_default_30[1]
        getitem_405 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        expand_default_4 = torch.ops.aten.expand.default(getitem_403, [128, 960, 7, 7]);  getitem_403 = None
        div_scalar_4 = torch.ops.aten.div.Scalar(expand_default_4, 49);  expand_default_4 = None
        add_tensor_98 = torch.ops.aten.add.Tensor(mul_tensor_65, div_scalar_4);  mul_tensor_65 = div_scalar_4 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_98, torch.float32);  add_tensor_98 = None
        to_dtype_46 = torch.ops.aten.to.dtype(clone_default_37, torch.float32);  clone_default_37 = None
        neg_default_10 = torch.ops.aten.neg.default(to_dtype_46)
        exp_default_10 = torch.ops.aten.exp.default(neg_default_10);  neg_default_10 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(exp_default_10, 1);  exp_default_10 = None
        reciprocal_default_10 = torch.ops.aten.reciprocal.default(add_tensor_99);  add_tensor_99 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(reciprocal_default_10, 1);  reciprocal_default_10 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_45, mul_tensor_72);  to_dtype_45 = None
        rsub_scalar_14 = torch.ops.aten.rsub.Scalar(mul_tensor_72, 1);  mul_tensor_72 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_46, rsub_scalar_14);  to_dtype_46 = rsub_scalar_14 = None
        add_tensor_100 = torch.ops.aten.add.Tensor(mul_tensor_74, 1);  mul_tensor_74 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(mul_tensor_73, add_tensor_100);  mul_tensor_73 = add_tensor_100 = None
        to_dtype_47 = torch.ops.aten.to.dtype(mul_tensor_75, torch.float32);  mul_tensor_75 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, cat_default_34, primals_424, primals_422, primals_423, getitem_227, getitem_228, True, 1e-05, [True, True, True]);  to_dtype_47 = cat_default_34 = primals_424 = primals_422 = primals_423 = getitem_227 = getitem_228 = None
        getitem_406 = native_batch_norm_backward_default_11[0]
        getitem_407 = native_batch_norm_backward_default_11[1]
        getitem_408 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        slice_tensor_18 = torch.ops.aten.slice.Tensor(getitem_406, 1, 0, 240)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(getitem_406, 1, 240, 480)
        slice_tensor_20 = torch.ops.aten.slice.Tensor(getitem_406, 1, 480, 720)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(getitem_406, 1, 720, 960);  getitem_406 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(slice_tensor_21, getitem_225, primals_146, [0], [2, 2], [4, 4], [1, 1], False, [0, 0], 240, [True, True, False]);  slice_tensor_21 = getitem_225 = primals_146 = None
        getitem_409 = convolution_backward_default_31[0]
        getitem_410 = convolution_backward_default_31[1]
        getitem_411 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(slice_tensor_20, getitem_224, primals_145, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 240, [True, True, False]);  slice_tensor_20 = getitem_224 = primals_145 = None
        getitem_412 = convolution_backward_default_32[0]
        getitem_413 = convolution_backward_default_32[1]
        getitem_414 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(slice_tensor_19, getitem_223, primals_144, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 240, [True, True, False]);  slice_tensor_19 = getitem_223 = primals_144 = None
        getitem_415 = convolution_backward_default_33[0]
        getitem_416 = convolution_backward_default_33[1]
        getitem_417 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(slice_tensor_18, getitem_222, primals_143, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 240, [True, True, False]);  slice_tensor_18 = getitem_222 = primals_143 = None
        getitem_418 = convolution_backward_default_34[0]
        getitem_419 = convolution_backward_default_34[1]
        getitem_420 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        cat_default_47 = torch.ops.aten.cat.default([getitem_418, getitem_415, getitem_412, getitem_409], 1);  getitem_418 = getitem_415 = getitem_412 = getitem_409 = None
        to_dtype_48 = torch.ops.aten.to.dtype(cat_default_47, torch.float32);  cat_default_47 = None
        to_dtype_49 = torch.ops.aten.to.dtype(clone_default_36, torch.float32);  clone_default_36 = None
        neg_default_11 = torch.ops.aten.neg.default(to_dtype_49)
        exp_default_11 = torch.ops.aten.exp.default(neg_default_11);  neg_default_11 = None
        add_tensor_101 = torch.ops.aten.add.Tensor(exp_default_11, 1);  exp_default_11 = None
        reciprocal_default_11 = torch.ops.aten.reciprocal.default(add_tensor_101);  add_tensor_101 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(reciprocal_default_11, 1);  reciprocal_default_11 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(to_dtype_48, mul_tensor_76);  to_dtype_48 = None
        rsub_scalar_15 = torch.ops.aten.rsub.Scalar(mul_tensor_76, 1);  mul_tensor_76 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(to_dtype_49, rsub_scalar_15);  to_dtype_49 = rsub_scalar_15 = None
        add_tensor_102 = torch.ops.aten.add.Tensor(mul_tensor_78, 1);  mul_tensor_78 = None
        mul_tensor_79 = torch.ops.aten.mul.Tensor(mul_tensor_77, add_tensor_102);  mul_tensor_77 = add_tensor_102 = None
        to_dtype_50 = torch.ops.aten.to.dtype(mul_tensor_79, torch.float32);  mul_tensor_79 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_119, primals_419, primals_417, primals_418, getitem_220, getitem_221, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_119 = primals_419 = primals_417 = primals_418 = getitem_220 = getitem_221 = None
        getitem_421 = native_batch_norm_backward_default_12[0]
        getitem_422 = native_batch_norm_backward_default_12[1]
        getitem_423 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_421, add_tensor_55, primals_147, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_421 = add_tensor_55 = primals_147 = None
        getitem_424 = convolution_backward_default_35[0]
        getitem_425 = convolution_backward_default_35[1]
        getitem_426 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(getitem_424, cat_default_33, primals_414, primals_412, primals_413, getitem_217, getitem_218, True, 1e-05, [True, True, True]);  cat_default_33 = primals_414 = primals_412 = primals_413 = getitem_217 = getitem_218 = None
        getitem_427 = native_batch_norm_backward_default_13[0]
        getitem_428 = native_batch_norm_backward_default_13[1]
        getitem_429 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(getitem_427, 1, 0, 80)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(getitem_427, 1, 80, 160);  getitem_427 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(slice_tensor_23, getitem_215, primals_138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_23 = getitem_215 = primals_138 = None
        getitem_430 = convolution_backward_default_36[0]
        getitem_431 = convolution_backward_default_36[1]
        getitem_432 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(slice_tensor_22, getitem_214, primals_137, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_22 = getitem_214 = primals_137 = None
        getitem_433 = convolution_backward_default_37[0]
        getitem_434 = convolution_backward_default_37[1]
        getitem_435 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        cat_default_48 = torch.ops.aten.cat.default([getitem_433, getitem_430], 1);  getitem_433 = getitem_430 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(cat_default_48, silu__default_34);  silu__default_34 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(cat_default_48, sigmoid_default_11);  cat_default_48 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(mul_tensor_80, [2, 3], True);  mul_tensor_80 = None
        to_dtype_51 = torch.ops.aten.to.dtype(sum_dim_int_list_5, torch.float32);  sum_dim_int_list_5 = None
        to_dtype_52 = torch.ops.aten.to.dtype(sigmoid_default_11, torch.float32);  sigmoid_default_11 = None
        rsub_scalar_16 = torch.ops.aten.rsub.Scalar(to_dtype_52, 1)
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_52, rsub_scalar_16);  to_dtype_52 = rsub_scalar_16 = None
        conj_physical_default_4 = torch.ops.aten.conj_physical.default(mul_tensor_82);  mul_tensor_82 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(to_dtype_51, conj_physical_default_4);  to_dtype_51 = conj_physical_default_4 = None
        to_dtype_53 = torch.ops.aten.to.dtype(mul_tensor_83, torch.float32);  mul_tensor_83 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(to_dtype_53, silu__default_35, primals_140, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_53 = silu__default_35 = primals_140 = None
        getitem_436 = convolution_backward_default_38[0]
        getitem_437 = convolution_backward_default_38[1]
        getitem_438 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_436, torch.float32);  getitem_436 = None
        to_dtype_55 = torch.ops.aten.to.dtype(clone_default_35, torch.float32);  clone_default_35 = None
        neg_default_12 = torch.ops.aten.neg.default(to_dtype_55)
        exp_default_12 = torch.ops.aten.exp.default(neg_default_12);  neg_default_12 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(exp_default_12, 1);  exp_default_12 = None
        reciprocal_default_12 = torch.ops.aten.reciprocal.default(add_tensor_103);  add_tensor_103 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(reciprocal_default_12, 1);  reciprocal_default_12 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(to_dtype_54, mul_tensor_84);  to_dtype_54 = None
        rsub_scalar_17 = torch.ops.aten.rsub.Scalar(mul_tensor_84, 1);  mul_tensor_84 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_55, rsub_scalar_17);  to_dtype_55 = rsub_scalar_17 = None
        add_tensor_104 = torch.ops.aten.add.Tensor(mul_tensor_86, 1);  mul_tensor_86 = None
        mul_tensor_87 = torch.ops.aten.mul.Tensor(mul_tensor_85, add_tensor_104);  mul_tensor_85 = add_tensor_104 = None
        to_dtype_56 = torch.ops.aten.to.dtype(mul_tensor_87, torch.float32);  mul_tensor_87 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(to_dtype_56, mean_dim_11, primals_142, [80], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_56 = mean_dim_11 = primals_142 = None
        getitem_439 = convolution_backward_default_39[0]
        getitem_440 = convolution_backward_default_39[1]
        getitem_441 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        expand_default_5 = torch.ops.aten.expand.default(getitem_439, [128, 480, 14, 14]);  getitem_439 = None
        div_scalar_5 = torch.ops.aten.div.Scalar(expand_default_5, 196);  expand_default_5 = None
        add_tensor_105 = torch.ops.aten.add.Tensor(mul_tensor_81, div_scalar_5);  mul_tensor_81 = div_scalar_5 = None
        to_dtype_57 = torch.ops.aten.to.dtype(add_tensor_105, torch.float32);  add_tensor_105 = None
        to_dtype_58 = torch.ops.aten.to.dtype(clone_default_34, torch.float32);  clone_default_34 = None
        neg_default_13 = torch.ops.aten.neg.default(to_dtype_58)
        exp_default_13 = torch.ops.aten.exp.default(neg_default_13);  neg_default_13 = None
        add_tensor_106 = torch.ops.aten.add.Tensor(exp_default_13, 1);  exp_default_13 = None
        reciprocal_default_13 = torch.ops.aten.reciprocal.default(add_tensor_106);  add_tensor_106 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(reciprocal_default_13, 1);  reciprocal_default_13 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_57, mul_tensor_88);  to_dtype_57 = None
        rsub_scalar_18 = torch.ops.aten.rsub.Scalar(mul_tensor_88, 1);  mul_tensor_88 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_58, rsub_scalar_18);  to_dtype_58 = rsub_scalar_18 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(mul_tensor_90, 1);  mul_tensor_90 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(mul_tensor_89, add_tensor_107);  mul_tensor_89 = add_tensor_107 = None
        to_dtype_59 = torch.ops.aten.to.dtype(mul_tensor_91, torch.float32);  mul_tensor_91 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, cat_default_32, primals_409, primals_407, primals_408, getitem_212, getitem_213, True, 1e-05, [True, True, True]);  to_dtype_59 = cat_default_32 = primals_409 = primals_407 = primals_408 = getitem_212 = getitem_213 = None
        getitem_442 = native_batch_norm_backward_default_14[0]
        getitem_443 = native_batch_norm_backward_default_14[1]
        getitem_444 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        slice_tensor_24 = torch.ops.aten.slice.Tensor(getitem_442, 1, 0, 120)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(getitem_442, 1, 120, 240)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(getitem_442, 1, 240, 360)
        slice_tensor_27 = torch.ops.aten.slice.Tensor(getitem_442, 1, 360, 480);  getitem_442 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(slice_tensor_27, getitem_210, primals_134, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_27 = getitem_210 = primals_134 = None
        getitem_445 = convolution_backward_default_40[0]
        getitem_446 = convolution_backward_default_40[1]
        getitem_447 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(slice_tensor_26, getitem_209, primals_133, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_26 = getitem_209 = primals_133 = None
        getitem_448 = convolution_backward_default_41[0]
        getitem_449 = convolution_backward_default_41[1]
        getitem_450 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(slice_tensor_25, getitem_208, primals_132, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_25 = getitem_208 = primals_132 = None
        getitem_451 = convolution_backward_default_42[0]
        getitem_452 = convolution_backward_default_42[1]
        getitem_453 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(slice_tensor_24, getitem_207, primals_131, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_24 = getitem_207 = primals_131 = None
        getitem_454 = convolution_backward_default_43[0]
        getitem_455 = convolution_backward_default_43[1]
        getitem_456 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        cat_default_49 = torch.ops.aten.cat.default([getitem_454, getitem_451, getitem_448, getitem_445], 1);  getitem_454 = getitem_451 = getitem_448 = getitem_445 = None
        to_dtype_60 = torch.ops.aten.to.dtype(cat_default_49, torch.float32);  cat_default_49 = None
        to_dtype_61 = torch.ops.aten.to.dtype(clone_default_33, torch.float32);  clone_default_33 = None
        neg_default_14 = torch.ops.aten.neg.default(to_dtype_61)
        exp_default_14 = torch.ops.aten.exp.default(neg_default_14);  neg_default_14 = None
        add_tensor_108 = torch.ops.aten.add.Tensor(exp_default_14, 1);  exp_default_14 = None
        reciprocal_default_14 = torch.ops.aten.reciprocal.default(add_tensor_108);  add_tensor_108 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(reciprocal_default_14, 1);  reciprocal_default_14 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(to_dtype_60, mul_tensor_92);  to_dtype_60 = None
        rsub_scalar_19 = torch.ops.aten.rsub.Scalar(mul_tensor_92, 1);  mul_tensor_92 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_61, rsub_scalar_19);  to_dtype_61 = rsub_scalar_19 = None
        add_tensor_109 = torch.ops.aten.add.Tensor(mul_tensor_94, 1);  mul_tensor_94 = None
        mul_tensor_95 = torch.ops.aten.mul.Tensor(mul_tensor_93, add_tensor_109);  mul_tensor_93 = add_tensor_109 = None
        to_dtype_62 = torch.ops.aten.to.dtype(mul_tensor_95, torch.float32);  mul_tensor_95 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, cat_default_31, primals_404, primals_402, primals_403, getitem_205, getitem_206, True, 1e-05, [True, True, True]);  to_dtype_62 = cat_default_31 = primals_404 = primals_402 = primals_403 = getitem_205 = getitem_206 = None
        getitem_457 = native_batch_norm_backward_default_15[0]
        getitem_458 = native_batch_norm_backward_default_15[1]
        getitem_459 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        slice_tensor_28 = torch.ops.aten.slice.Tensor(getitem_457, 1, 0, 240)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(getitem_457, 1, 240, 480);  getitem_457 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(slice_tensor_29, getitem_203, primals_136, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_29 = getitem_203 = primals_136 = None
        getitem_460 = convolution_backward_default_44[0]
        getitem_461 = convolution_backward_default_44[1]
        getitem_462 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(slice_tensor_28, getitem_202, primals_135, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_28 = getitem_202 = primals_135 = None
        getitem_463 = convolution_backward_default_45[0]
        getitem_464 = convolution_backward_default_45[1]
        getitem_465 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        cat_default_50 = torch.ops.aten.cat.default([getitem_463, getitem_460], 1);  getitem_463 = getitem_460 = None
        add_tensor_110 = torch.ops.aten.add.Tensor(getitem_424, cat_default_50);  getitem_424 = cat_default_50 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_110, cat_default_30, primals_399, primals_397, primals_398, getitem_200, getitem_201, True, 1e-05, [True, True, True]);  cat_default_30 = primals_399 = primals_397 = primals_398 = getitem_200 = getitem_201 = None
        getitem_466 = native_batch_norm_backward_default_16[0]
        getitem_467 = native_batch_norm_backward_default_16[1]
        getitem_468 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        slice_tensor_30 = torch.ops.aten.slice.Tensor(getitem_466, 1, 0, 80)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(getitem_466, 1, 80, 160);  getitem_466 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(slice_tensor_31, getitem_198, primals_126, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_31 = getitem_198 = primals_126 = None
        getitem_469 = convolution_backward_default_46[0]
        getitem_470 = convolution_backward_default_46[1]
        getitem_471 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(slice_tensor_30, getitem_197, primals_125, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_30 = getitem_197 = primals_125 = None
        getitem_472 = convolution_backward_default_47[0]
        getitem_473 = convolution_backward_default_47[1]
        getitem_474 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        cat_default_51 = torch.ops.aten.cat.default([getitem_472, getitem_469], 1);  getitem_472 = getitem_469 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(cat_default_51, silu__default_31);  silu__default_31 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(cat_default_51, sigmoid_default_10);  cat_default_51 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(mul_tensor_96, [2, 3], True);  mul_tensor_96 = None
        to_dtype_63 = torch.ops.aten.to.dtype(sum_dim_int_list_6, torch.float32);  sum_dim_int_list_6 = None
        to_dtype_64 = torch.ops.aten.to.dtype(sigmoid_default_10, torch.float32);  sigmoid_default_10 = None
        rsub_scalar_20 = torch.ops.aten.rsub.Scalar(to_dtype_64, 1)
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_64, rsub_scalar_20);  to_dtype_64 = rsub_scalar_20 = None
        conj_physical_default_5 = torch.ops.aten.conj_physical.default(mul_tensor_98);  mul_tensor_98 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(to_dtype_63, conj_physical_default_5);  to_dtype_63 = conj_physical_default_5 = None
        to_dtype_65 = torch.ops.aten.to.dtype(mul_tensor_99, torch.float32);  mul_tensor_99 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(to_dtype_65, silu__default_32, primals_128, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_65 = silu__default_32 = primals_128 = None
        getitem_475 = convolution_backward_default_48[0]
        getitem_476 = convolution_backward_default_48[1]
        getitem_477 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_475, torch.float32);  getitem_475 = None
        to_dtype_67 = torch.ops.aten.to.dtype(clone_default_32, torch.float32);  clone_default_32 = None
        neg_default_15 = torch.ops.aten.neg.default(to_dtype_67)
        exp_default_15 = torch.ops.aten.exp.default(neg_default_15);  neg_default_15 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(exp_default_15, 1);  exp_default_15 = None
        reciprocal_default_15 = torch.ops.aten.reciprocal.default(add_tensor_111);  add_tensor_111 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(reciprocal_default_15, 1);  reciprocal_default_15 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(to_dtype_66, mul_tensor_100);  to_dtype_66 = None
        rsub_scalar_21 = torch.ops.aten.rsub.Scalar(mul_tensor_100, 1);  mul_tensor_100 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_67, rsub_scalar_21);  to_dtype_67 = rsub_scalar_21 = None
        add_tensor_112 = torch.ops.aten.add.Tensor(mul_tensor_102, 1);  mul_tensor_102 = None
        mul_tensor_103 = torch.ops.aten.mul.Tensor(mul_tensor_101, add_tensor_112);  mul_tensor_101 = add_tensor_112 = None
        to_dtype_68 = torch.ops.aten.to.dtype(mul_tensor_103, torch.float32);  mul_tensor_103 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(to_dtype_68, mean_dim_10, primals_130, [80], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_68 = mean_dim_10 = primals_130 = None
        getitem_478 = convolution_backward_default_49[0]
        getitem_479 = convolution_backward_default_49[1]
        getitem_480 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        expand_default_6 = torch.ops.aten.expand.default(getitem_478, [128, 480, 14, 14]);  getitem_478 = None
        div_scalar_6 = torch.ops.aten.div.Scalar(expand_default_6, 196);  expand_default_6 = None
        add_tensor_113 = torch.ops.aten.add.Tensor(mul_tensor_97, div_scalar_6);  mul_tensor_97 = div_scalar_6 = None
        to_dtype_69 = torch.ops.aten.to.dtype(add_tensor_113, torch.float32);  add_tensor_113 = None
        to_dtype_70 = torch.ops.aten.to.dtype(clone_default_31, torch.float32);  clone_default_31 = None
        neg_default_16 = torch.ops.aten.neg.default(to_dtype_70)
        exp_default_16 = torch.ops.aten.exp.default(neg_default_16);  neg_default_16 = None
        add_tensor_114 = torch.ops.aten.add.Tensor(exp_default_16, 1);  exp_default_16 = None
        reciprocal_default_16 = torch.ops.aten.reciprocal.default(add_tensor_114);  add_tensor_114 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(reciprocal_default_16, 1);  reciprocal_default_16 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_69, mul_tensor_104);  to_dtype_69 = None
        rsub_scalar_22 = torch.ops.aten.rsub.Scalar(mul_tensor_104, 1);  mul_tensor_104 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_70, rsub_scalar_22);  to_dtype_70 = rsub_scalar_22 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(mul_tensor_106, 1);  mul_tensor_106 = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(mul_tensor_105, add_tensor_115);  mul_tensor_105 = add_tensor_115 = None
        to_dtype_71 = torch.ops.aten.to.dtype(mul_tensor_107, torch.float32);  mul_tensor_107 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, cat_default_29, primals_394, primals_392, primals_393, getitem_195, getitem_196, True, 1e-05, [True, True, True]);  to_dtype_71 = cat_default_29 = primals_394 = primals_392 = primals_393 = getitem_195 = getitem_196 = None
        getitem_481 = native_batch_norm_backward_default_17[0]
        getitem_482 = native_batch_norm_backward_default_17[1]
        getitem_483 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        slice_tensor_32 = torch.ops.aten.slice.Tensor(getitem_481, 1, 0, 120)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(getitem_481, 1, 120, 240)
        slice_tensor_34 = torch.ops.aten.slice.Tensor(getitem_481, 1, 240, 360)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(getitem_481, 1, 360, 480);  getitem_481 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(slice_tensor_35, getitem_193, primals_122, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_35 = getitem_193 = primals_122 = None
        getitem_484 = convolution_backward_default_50[0]
        getitem_485 = convolution_backward_default_50[1]
        getitem_486 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(slice_tensor_34, getitem_192, primals_121, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_34 = getitem_192 = primals_121 = None
        getitem_487 = convolution_backward_default_51[0]
        getitem_488 = convolution_backward_default_51[1]
        getitem_489 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(slice_tensor_33, getitem_191, primals_120, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_33 = getitem_191 = primals_120 = None
        getitem_490 = convolution_backward_default_52[0]
        getitem_491 = convolution_backward_default_52[1]
        getitem_492 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(slice_tensor_32, getitem_190, primals_119, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_32 = getitem_190 = primals_119 = None
        getitem_493 = convolution_backward_default_53[0]
        getitem_494 = convolution_backward_default_53[1]
        getitem_495 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        cat_default_52 = torch.ops.aten.cat.default([getitem_493, getitem_490, getitem_487, getitem_484], 1);  getitem_493 = getitem_490 = getitem_487 = getitem_484 = None
        to_dtype_72 = torch.ops.aten.to.dtype(cat_default_52, torch.float32);  cat_default_52 = None
        to_dtype_73 = torch.ops.aten.to.dtype(clone_default_30, torch.float32);  clone_default_30 = None
        neg_default_17 = torch.ops.aten.neg.default(to_dtype_73)
        exp_default_17 = torch.ops.aten.exp.default(neg_default_17);  neg_default_17 = None
        add_tensor_116 = torch.ops.aten.add.Tensor(exp_default_17, 1);  exp_default_17 = None
        reciprocal_default_17 = torch.ops.aten.reciprocal.default(add_tensor_116);  add_tensor_116 = None
        mul_tensor_108 = torch.ops.aten.mul.Tensor(reciprocal_default_17, 1);  reciprocal_default_17 = None
        mul_tensor_109 = torch.ops.aten.mul.Tensor(to_dtype_72, mul_tensor_108);  to_dtype_72 = None
        rsub_scalar_23 = torch.ops.aten.rsub.Scalar(mul_tensor_108, 1);  mul_tensor_108 = None
        mul_tensor_110 = torch.ops.aten.mul.Tensor(to_dtype_73, rsub_scalar_23);  to_dtype_73 = rsub_scalar_23 = None
        add_tensor_117 = torch.ops.aten.add.Tensor(mul_tensor_110, 1);  mul_tensor_110 = None
        mul_tensor_111 = torch.ops.aten.mul.Tensor(mul_tensor_109, add_tensor_117);  mul_tensor_109 = add_tensor_117 = None
        to_dtype_74 = torch.ops.aten.to.dtype(mul_tensor_111, torch.float32);  mul_tensor_111 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, cat_default_28, primals_389, primals_387, primals_388, getitem_188, getitem_189, True, 1e-05, [True, True, True]);  to_dtype_74 = cat_default_28 = primals_389 = primals_387 = primals_388 = getitem_188 = getitem_189 = None
        getitem_496 = native_batch_norm_backward_default_18[0]
        getitem_497 = native_batch_norm_backward_default_18[1]
        getitem_498 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        slice_tensor_36 = torch.ops.aten.slice.Tensor(getitem_496, 1, 0, 240)
        slice_tensor_37 = torch.ops.aten.slice.Tensor(getitem_496, 1, 240, 480);  getitem_496 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(slice_tensor_37, getitem_186, primals_124, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_37 = getitem_186 = primals_124 = None
        getitem_499 = convolution_backward_default_54[0]
        getitem_500 = convolution_backward_default_54[1]
        getitem_501 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(slice_tensor_36, getitem_185, primals_123, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_36 = getitem_185 = primals_123 = None
        getitem_502 = convolution_backward_default_55[0]
        getitem_503 = convolution_backward_default_55[1]
        getitem_504 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        cat_default_53 = torch.ops.aten.cat.default([getitem_502, getitem_499], 1);  getitem_502 = getitem_499 = None
        add_tensor_118 = torch.ops.aten.add.Tensor(add_tensor_110, cat_default_53);  add_tensor_110 = cat_default_53 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_118, cat_default_27, primals_384, primals_382, primals_383, getitem_183, getitem_184, True, 1e-05, [True, True, True]);  cat_default_27 = primals_384 = primals_382 = primals_383 = getitem_183 = getitem_184 = None
        getitem_505 = native_batch_norm_backward_default_19[0]
        getitem_506 = native_batch_norm_backward_default_19[1]
        getitem_507 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        slice_tensor_38 = torch.ops.aten.slice.Tensor(getitem_505, 1, 0, 80)
        slice_tensor_39 = torch.ops.aten.slice.Tensor(getitem_505, 1, 80, 160);  getitem_505 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(slice_tensor_39, getitem_181, primals_114, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_39 = getitem_181 = primals_114 = None
        getitem_508 = convolution_backward_default_56[0]
        getitem_509 = convolution_backward_default_56[1]
        getitem_510 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(slice_tensor_38, getitem_180, primals_113, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_38 = getitem_180 = primals_113 = None
        getitem_511 = convolution_backward_default_57[0]
        getitem_512 = convolution_backward_default_57[1]
        getitem_513 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        cat_default_54 = torch.ops.aten.cat.default([getitem_511, getitem_508], 1);  getitem_511 = getitem_508 = None
        mul_tensor_112 = torch.ops.aten.mul.Tensor(cat_default_54, silu__default_28);  silu__default_28 = None
        mul_tensor_113 = torch.ops.aten.mul.Tensor(cat_default_54, sigmoid_default_9);  cat_default_54 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(mul_tensor_112, [2, 3], True);  mul_tensor_112 = None
        to_dtype_75 = torch.ops.aten.to.dtype(sum_dim_int_list_7, torch.float32);  sum_dim_int_list_7 = None
        to_dtype_76 = torch.ops.aten.to.dtype(sigmoid_default_9, torch.float32);  sigmoid_default_9 = None
        rsub_scalar_24 = torch.ops.aten.rsub.Scalar(to_dtype_76, 1)
        mul_tensor_114 = torch.ops.aten.mul.Tensor(to_dtype_76, rsub_scalar_24);  to_dtype_76 = rsub_scalar_24 = None
        conj_physical_default_6 = torch.ops.aten.conj_physical.default(mul_tensor_114);  mul_tensor_114 = None
        mul_tensor_115 = torch.ops.aten.mul.Tensor(to_dtype_75, conj_physical_default_6);  to_dtype_75 = conj_physical_default_6 = None
        to_dtype_77 = torch.ops.aten.to.dtype(mul_tensor_115, torch.float32);  mul_tensor_115 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(to_dtype_77, silu__default_29, primals_116, [480], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_77 = silu__default_29 = primals_116 = None
        getitem_514 = convolution_backward_default_58[0]
        getitem_515 = convolution_backward_default_58[1]
        getitem_516 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_514, torch.float32);  getitem_514 = None
        to_dtype_79 = torch.ops.aten.to.dtype(clone_default_29, torch.float32);  clone_default_29 = None
        neg_default_18 = torch.ops.aten.neg.default(to_dtype_79)
        exp_default_18 = torch.ops.aten.exp.default(neg_default_18);  neg_default_18 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(exp_default_18, 1);  exp_default_18 = None
        reciprocal_default_18 = torch.ops.aten.reciprocal.default(add_tensor_119);  add_tensor_119 = None
        mul_tensor_116 = torch.ops.aten.mul.Tensor(reciprocal_default_18, 1);  reciprocal_default_18 = None
        mul_tensor_117 = torch.ops.aten.mul.Tensor(to_dtype_78, mul_tensor_116);  to_dtype_78 = None
        rsub_scalar_25 = torch.ops.aten.rsub.Scalar(mul_tensor_116, 1);  mul_tensor_116 = None
        mul_tensor_118 = torch.ops.aten.mul.Tensor(to_dtype_79, rsub_scalar_25);  to_dtype_79 = rsub_scalar_25 = None
        add_tensor_120 = torch.ops.aten.add.Tensor(mul_tensor_118, 1);  mul_tensor_118 = None
        mul_tensor_119 = torch.ops.aten.mul.Tensor(mul_tensor_117, add_tensor_120);  mul_tensor_117 = add_tensor_120 = None
        to_dtype_80 = torch.ops.aten.to.dtype(mul_tensor_119, torch.float32);  mul_tensor_119 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(to_dtype_80, mean_dim_9, primals_118, [80], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_80 = mean_dim_9 = primals_118 = None
        getitem_517 = convolution_backward_default_59[0]
        getitem_518 = convolution_backward_default_59[1]
        getitem_519 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        expand_default_7 = torch.ops.aten.expand.default(getitem_517, [128, 480, 14, 14]);  getitem_517 = None
        div_scalar_7 = torch.ops.aten.div.Scalar(expand_default_7, 196);  expand_default_7 = None
        add_tensor_121 = torch.ops.aten.add.Tensor(mul_tensor_113, div_scalar_7);  mul_tensor_113 = div_scalar_7 = None
        to_dtype_81 = torch.ops.aten.to.dtype(add_tensor_121, torch.float32);  add_tensor_121 = None
        to_dtype_82 = torch.ops.aten.to.dtype(clone_default_28, torch.float32);  clone_default_28 = None
        neg_default_19 = torch.ops.aten.neg.default(to_dtype_82)
        exp_default_19 = torch.ops.aten.exp.default(neg_default_19);  neg_default_19 = None
        add_tensor_122 = torch.ops.aten.add.Tensor(exp_default_19, 1);  exp_default_19 = None
        reciprocal_default_19 = torch.ops.aten.reciprocal.default(add_tensor_122);  add_tensor_122 = None
        mul_tensor_120 = torch.ops.aten.mul.Tensor(reciprocal_default_19, 1);  reciprocal_default_19 = None
        mul_tensor_121 = torch.ops.aten.mul.Tensor(to_dtype_81, mul_tensor_120);  to_dtype_81 = None
        rsub_scalar_26 = torch.ops.aten.rsub.Scalar(mul_tensor_120, 1);  mul_tensor_120 = None
        mul_tensor_122 = torch.ops.aten.mul.Tensor(to_dtype_82, rsub_scalar_26);  to_dtype_82 = rsub_scalar_26 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(mul_tensor_122, 1);  mul_tensor_122 = None
        mul_tensor_123 = torch.ops.aten.mul.Tensor(mul_tensor_121, add_tensor_123);  mul_tensor_121 = add_tensor_123 = None
        to_dtype_83 = torch.ops.aten.to.dtype(mul_tensor_123, torch.float32);  mul_tensor_123 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, cat_default_26, primals_379, primals_377, primals_378, getitem_178, getitem_179, True, 1e-05, [True, True, True]);  to_dtype_83 = cat_default_26 = primals_379 = primals_377 = primals_378 = getitem_178 = getitem_179 = None
        getitem_520 = native_batch_norm_backward_default_20[0]
        getitem_521 = native_batch_norm_backward_default_20[1]
        getitem_522 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        slice_tensor_40 = torch.ops.aten.slice.Tensor(getitem_520, 1, 0, 120)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(getitem_520, 1, 120, 240)
        slice_tensor_42 = torch.ops.aten.slice.Tensor(getitem_520, 1, 240, 360)
        slice_tensor_43 = torch.ops.aten.slice.Tensor(getitem_520, 1, 360, 480);  getitem_520 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(slice_tensor_43, getitem_176, primals_110, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_43 = getitem_176 = primals_110 = None
        getitem_523 = convolution_backward_default_60[0]
        getitem_524 = convolution_backward_default_60[1]
        getitem_525 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(slice_tensor_42, getitem_175, primals_109, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_42 = getitem_175 = primals_109 = None
        getitem_526 = convolution_backward_default_61[0]
        getitem_527 = convolution_backward_default_61[1]
        getitem_528 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(slice_tensor_41, getitem_174, primals_108, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_41 = getitem_174 = primals_108 = None
        getitem_529 = convolution_backward_default_62[0]
        getitem_530 = convolution_backward_default_62[1]
        getitem_531 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(slice_tensor_40, getitem_173, primals_107, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 120, [True, True, False]);  slice_tensor_40 = getitem_173 = primals_107 = None
        getitem_532 = convolution_backward_default_63[0]
        getitem_533 = convolution_backward_default_63[1]
        getitem_534 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        cat_default_55 = torch.ops.aten.cat.default([getitem_532, getitem_529, getitem_526, getitem_523], 1);  getitem_532 = getitem_529 = getitem_526 = getitem_523 = None
        to_dtype_84 = torch.ops.aten.to.dtype(cat_default_55, torch.float32);  cat_default_55 = None
        to_dtype_85 = torch.ops.aten.to.dtype(clone_default_27, torch.float32);  clone_default_27 = None
        neg_default_20 = torch.ops.aten.neg.default(to_dtype_85)
        exp_default_20 = torch.ops.aten.exp.default(neg_default_20);  neg_default_20 = None
        add_tensor_124 = torch.ops.aten.add.Tensor(exp_default_20, 1);  exp_default_20 = None
        reciprocal_default_20 = torch.ops.aten.reciprocal.default(add_tensor_124);  add_tensor_124 = None
        mul_tensor_124 = torch.ops.aten.mul.Tensor(reciprocal_default_20, 1);  reciprocal_default_20 = None
        mul_tensor_125 = torch.ops.aten.mul.Tensor(to_dtype_84, mul_tensor_124);  to_dtype_84 = None
        rsub_scalar_27 = torch.ops.aten.rsub.Scalar(mul_tensor_124, 1);  mul_tensor_124 = None
        mul_tensor_126 = torch.ops.aten.mul.Tensor(to_dtype_85, rsub_scalar_27);  to_dtype_85 = rsub_scalar_27 = None
        add_tensor_125 = torch.ops.aten.add.Tensor(mul_tensor_126, 1);  mul_tensor_126 = None
        mul_tensor_127 = torch.ops.aten.mul.Tensor(mul_tensor_125, add_tensor_125);  mul_tensor_125 = add_tensor_125 = None
        to_dtype_86 = torch.ops.aten.to.dtype(mul_tensor_127, torch.float32);  mul_tensor_127 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, cat_default_25, primals_374, primals_372, primals_373, getitem_171, getitem_172, True, 1e-05, [True, True, True]);  to_dtype_86 = cat_default_25 = primals_374 = primals_372 = primals_373 = getitem_171 = getitem_172 = None
        getitem_535 = native_batch_norm_backward_default_21[0]
        getitem_536 = native_batch_norm_backward_default_21[1]
        getitem_537 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        slice_tensor_44 = torch.ops.aten.slice.Tensor(getitem_535, 1, 0, 240)
        slice_tensor_45 = torch.ops.aten.slice.Tensor(getitem_535, 1, 240, 480);  getitem_535 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(slice_tensor_45, getitem_169, primals_112, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_45 = getitem_169 = primals_112 = None
        getitem_538 = convolution_backward_default_64[0]
        getitem_539 = convolution_backward_default_64[1]
        getitem_540 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(slice_tensor_44, getitem_168, primals_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_44 = getitem_168 = primals_111 = None
        getitem_541 = convolution_backward_default_65[0]
        getitem_542 = convolution_backward_default_65[1]
        getitem_543 = convolution_backward_default_65[2];  convolution_backward_default_65 = None
        cat_default_56 = torch.ops.aten.cat.default([getitem_541, getitem_538], 1);  getitem_541 = getitem_538 = None
        add_tensor_126 = torch.ops.aten.add.Tensor(add_tensor_118, cat_default_56);  add_tensor_118 = cat_default_56 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_126, convolution_default_88, primals_369, primals_367, primals_368, getitem_166, getitem_167, True, 1e-05, [True, True, True]);  add_tensor_126 = convolution_default_88 = primals_369 = primals_367 = primals_368 = getitem_166 = getitem_167 = None
        getitem_544 = native_batch_norm_backward_default_22[0]
        getitem_545 = native_batch_norm_backward_default_22[1]
        getitem_546 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_544, mul_tensor_8, primals_102, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_544 = mul_tensor_8 = primals_102 = None
        getitem_547 = convolution_backward_default_66[0]
        getitem_548 = convolution_backward_default_66[1]
        getitem_549 = convolution_backward_default_66[2];  convolution_backward_default_66 = None
        mul_tensor_128 = torch.ops.aten.mul.Tensor(getitem_547, silu__default_25);  silu__default_25 = None
        mul_tensor_129 = torch.ops.aten.mul.Tensor(getitem_547, sigmoid_default_8);  getitem_547 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(mul_tensor_128, [2, 3], True);  mul_tensor_128 = None
        to_dtype_87 = torch.ops.aten.to.dtype(sum_dim_int_list_8, torch.float32);  sum_dim_int_list_8 = None
        to_dtype_88 = torch.ops.aten.to.dtype(sigmoid_default_8, torch.float32);  sigmoid_default_8 = None
        rsub_scalar_28 = torch.ops.aten.rsub.Scalar(to_dtype_88, 1)
        mul_tensor_130 = torch.ops.aten.mul.Tensor(to_dtype_88, rsub_scalar_28);  to_dtype_88 = rsub_scalar_28 = None
        conj_physical_default_7 = torch.ops.aten.conj_physical.default(mul_tensor_130);  mul_tensor_130 = None
        mul_tensor_131 = torch.ops.aten.mul.Tensor(to_dtype_87, conj_physical_default_7);  to_dtype_87 = conj_physical_default_7 = None
        to_dtype_89 = torch.ops.aten.to.dtype(mul_tensor_131, torch.float32);  mul_tensor_131 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(to_dtype_89, silu__default_26, primals_104, [624], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_89 = silu__default_26 = primals_104 = None
        getitem_550 = convolution_backward_default_67[0]
        getitem_551 = convolution_backward_default_67[1]
        getitem_552 = convolution_backward_default_67[2];  convolution_backward_default_67 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_550, torch.float32);  getitem_550 = None
        to_dtype_91 = torch.ops.aten.to.dtype(clone_default_26, torch.float32);  clone_default_26 = None
        neg_default_21 = torch.ops.aten.neg.default(to_dtype_91)
        exp_default_21 = torch.ops.aten.exp.default(neg_default_21);  neg_default_21 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(exp_default_21, 1);  exp_default_21 = None
        reciprocal_default_21 = torch.ops.aten.reciprocal.default(add_tensor_127);  add_tensor_127 = None
        mul_tensor_132 = torch.ops.aten.mul.Tensor(reciprocal_default_21, 1);  reciprocal_default_21 = None
        mul_tensor_133 = torch.ops.aten.mul.Tensor(to_dtype_90, mul_tensor_132);  to_dtype_90 = None
        rsub_scalar_29 = torch.ops.aten.rsub.Scalar(mul_tensor_132, 1);  mul_tensor_132 = None
        mul_tensor_134 = torch.ops.aten.mul.Tensor(to_dtype_91, rsub_scalar_29);  to_dtype_91 = rsub_scalar_29 = None
        add_tensor_128 = torch.ops.aten.add.Tensor(mul_tensor_134, 1);  mul_tensor_134 = None
        mul_tensor_135 = torch.ops.aten.mul.Tensor(mul_tensor_133, add_tensor_128);  mul_tensor_133 = add_tensor_128 = None
        to_dtype_92 = torch.ops.aten.to.dtype(mul_tensor_135, torch.float32);  mul_tensor_135 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(to_dtype_92, mean_dim_8, primals_106, [52], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_92 = mean_dim_8 = primals_106 = None
        getitem_553 = convolution_backward_default_68[0]
        getitem_554 = convolution_backward_default_68[1]
        getitem_555 = convolution_backward_default_68[2];  convolution_backward_default_68 = None
        expand_default_8 = torch.ops.aten.expand.default(getitem_553, [128, 624, 14, 14]);  getitem_553 = None
        div_scalar_8 = torch.ops.aten.div.Scalar(expand_default_8, 196);  expand_default_8 = None
        add_tensor_129 = torch.ops.aten.add.Tensor(mul_tensor_129, div_scalar_8);  mul_tensor_129 = div_scalar_8 = None
        to_dtype_93 = torch.ops.aten.to.dtype(add_tensor_129, torch.float32);  add_tensor_129 = None
        to_dtype_94 = torch.ops.aten.to.dtype(clone_default_25, torch.float32);  clone_default_25 = None
        neg_default_22 = torch.ops.aten.neg.default(to_dtype_94)
        exp_default_22 = torch.ops.aten.exp.default(neg_default_22);  neg_default_22 = None
        add_tensor_130 = torch.ops.aten.add.Tensor(exp_default_22, 1);  exp_default_22 = None
        reciprocal_default_22 = torch.ops.aten.reciprocal.default(add_tensor_130);  add_tensor_130 = None
        mul_tensor_136 = torch.ops.aten.mul.Tensor(reciprocal_default_22, 1);  reciprocal_default_22 = None
        mul_tensor_137 = torch.ops.aten.mul.Tensor(to_dtype_93, mul_tensor_136);  to_dtype_93 = None
        rsub_scalar_30 = torch.ops.aten.rsub.Scalar(mul_tensor_136, 1);  mul_tensor_136 = None
        mul_tensor_138 = torch.ops.aten.mul.Tensor(to_dtype_94, rsub_scalar_30);  to_dtype_94 = rsub_scalar_30 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(mul_tensor_138, 1);  mul_tensor_138 = None
        mul_tensor_139 = torch.ops.aten.mul.Tensor(mul_tensor_137, add_tensor_131);  mul_tensor_137 = add_tensor_131 = None
        to_dtype_95 = torch.ops.aten.to.dtype(mul_tensor_139, torch.float32);  mul_tensor_139 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_85, primals_364, primals_362, primals_363, getitem_163, getitem_164, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_85 = primals_364 = primals_362 = primals_363 = getitem_163 = getitem_164 = None
        getitem_556 = native_batch_norm_backward_default_23[0]
        getitem_557 = native_batch_norm_backward_default_23[1]
        getitem_558 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_556, silu__default_24, primals_100, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 624, [True, True, False]);  getitem_556 = silu__default_24 = primals_100 = None
        getitem_559 = convolution_backward_default_69[0]
        getitem_560 = convolution_backward_default_69[1]
        getitem_561 = convolution_backward_default_69[2];  convolution_backward_default_69 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_559, torch.float32);  getitem_559 = None
        to_dtype_97 = torch.ops.aten.to.dtype(clone_default_24, torch.float32);  clone_default_24 = None
        neg_default_23 = torch.ops.aten.neg.default(to_dtype_97)
        exp_default_23 = torch.ops.aten.exp.default(neg_default_23);  neg_default_23 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(exp_default_23, 1);  exp_default_23 = None
        reciprocal_default_23 = torch.ops.aten.reciprocal.default(add_tensor_132);  add_tensor_132 = None
        mul_tensor_140 = torch.ops.aten.mul.Tensor(reciprocal_default_23, 1);  reciprocal_default_23 = None
        mul_tensor_141 = torch.ops.aten.mul.Tensor(to_dtype_96, mul_tensor_140);  to_dtype_96 = None
        rsub_scalar_31 = torch.ops.aten.rsub.Scalar(mul_tensor_140, 1);  mul_tensor_140 = None
        mul_tensor_142 = torch.ops.aten.mul.Tensor(to_dtype_97, rsub_scalar_31);  to_dtype_97 = rsub_scalar_31 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(mul_tensor_142, 1);  mul_tensor_142 = None
        mul_tensor_143 = torch.ops.aten.mul.Tensor(mul_tensor_141, add_tensor_133);  mul_tensor_141 = add_tensor_133 = None
        to_dtype_98 = torch.ops.aten.to.dtype(mul_tensor_143, torch.float32);  mul_tensor_143 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_84, primals_359, primals_357, primals_358, getitem_160, getitem_161, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_84 = primals_359 = primals_357 = primals_358 = getitem_160 = getitem_161 = None
        getitem_562 = native_batch_norm_backward_default_24[0]
        getitem_563 = native_batch_norm_backward_default_24[1]
        getitem_564 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_562, add_tensor_40, primals_101, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_562 = add_tensor_40 = primals_101 = None
        getitem_565 = convolution_backward_default_70[0]
        getitem_566 = convolution_backward_default_70[1]
        getitem_567 = convolution_backward_default_70[2];  convolution_backward_default_70 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(getitem_565, cat_default_24, primals_354, primals_352, primals_353, getitem_157, getitem_158, True, 1e-05, [True, True, True]);  cat_default_24 = primals_354 = primals_352 = primals_353 = getitem_157 = getitem_158 = None
        getitem_568 = native_batch_norm_backward_default_25[0]
        getitem_569 = native_batch_norm_backward_default_25[1]
        getitem_570 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        slice_tensor_46 = torch.ops.aten.slice.Tensor(getitem_568, 1, 0, 52)
        slice_tensor_47 = torch.ops.aten.slice.Tensor(getitem_568, 1, 52, 104);  getitem_568 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(slice_tensor_47, getitem_155, primals_95, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_47 = getitem_155 = primals_95 = None
        getitem_571 = convolution_backward_default_71[0]
        getitem_572 = convolution_backward_default_71[1]
        getitem_573 = convolution_backward_default_71[2];  convolution_backward_default_71 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(slice_tensor_46, getitem_154, primals_94, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_46 = getitem_154 = primals_94 = None
        getitem_574 = convolution_backward_default_72[0]
        getitem_575 = convolution_backward_default_72[1]
        getitem_576 = convolution_backward_default_72[2];  convolution_backward_default_72 = None
        cat_default_57 = torch.ops.aten.cat.default([getitem_574, getitem_571], 1);  getitem_574 = getitem_571 = None
        mul_tensor_144 = torch.ops.aten.mul.Tensor(cat_default_57, silu__default_22);  silu__default_22 = None
        mul_tensor_145 = torch.ops.aten.mul.Tensor(cat_default_57, sigmoid_default_7);  cat_default_57 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(mul_tensor_144, [2, 3], True);  mul_tensor_144 = None
        to_dtype_99 = torch.ops.aten.to.dtype(sum_dim_int_list_9, torch.float32);  sum_dim_int_list_9 = None
        to_dtype_100 = torch.ops.aten.to.dtype(sigmoid_default_7, torch.float32);  sigmoid_default_7 = None
        rsub_scalar_32 = torch.ops.aten.rsub.Scalar(to_dtype_100, 1)
        mul_tensor_146 = torch.ops.aten.mul.Tensor(to_dtype_100, rsub_scalar_32);  to_dtype_100 = rsub_scalar_32 = None
        conj_physical_default_8 = torch.ops.aten.conj_physical.default(mul_tensor_146);  mul_tensor_146 = None
        mul_tensor_147 = torch.ops.aten.mul.Tensor(to_dtype_99, conj_physical_default_8);  to_dtype_99 = conj_physical_default_8 = None
        to_dtype_101 = torch.ops.aten.to.dtype(mul_tensor_147, torch.float32);  mul_tensor_147 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(to_dtype_101, silu__default_23, primals_97, [624], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_101 = silu__default_23 = primals_97 = None
        getitem_577 = convolution_backward_default_73[0]
        getitem_578 = convolution_backward_default_73[1]
        getitem_579 = convolution_backward_default_73[2];  convolution_backward_default_73 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_577, torch.float32);  getitem_577 = None
        to_dtype_103 = torch.ops.aten.to.dtype(clone_default_23, torch.float32);  clone_default_23 = None
        neg_default_24 = torch.ops.aten.neg.default(to_dtype_103)
        exp_default_24 = torch.ops.aten.exp.default(neg_default_24);  neg_default_24 = None
        add_tensor_134 = torch.ops.aten.add.Tensor(exp_default_24, 1);  exp_default_24 = None
        reciprocal_default_24 = torch.ops.aten.reciprocal.default(add_tensor_134);  add_tensor_134 = None
        mul_tensor_148 = torch.ops.aten.mul.Tensor(reciprocal_default_24, 1);  reciprocal_default_24 = None
        mul_tensor_149 = torch.ops.aten.mul.Tensor(to_dtype_102, mul_tensor_148);  to_dtype_102 = None
        rsub_scalar_33 = torch.ops.aten.rsub.Scalar(mul_tensor_148, 1);  mul_tensor_148 = None
        mul_tensor_150 = torch.ops.aten.mul.Tensor(to_dtype_103, rsub_scalar_33);  to_dtype_103 = rsub_scalar_33 = None
        add_tensor_135 = torch.ops.aten.add.Tensor(mul_tensor_150, 1);  mul_tensor_150 = None
        mul_tensor_151 = torch.ops.aten.mul.Tensor(mul_tensor_149, add_tensor_135);  mul_tensor_149 = add_tensor_135 = None
        to_dtype_104 = torch.ops.aten.to.dtype(mul_tensor_151, torch.float32);  mul_tensor_151 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(to_dtype_104, mean_dim_7, primals_99, [26], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_104 = mean_dim_7 = primals_99 = None
        getitem_580 = convolution_backward_default_74[0]
        getitem_581 = convolution_backward_default_74[1]
        getitem_582 = convolution_backward_default_74[2];  convolution_backward_default_74 = None
        expand_default_9 = torch.ops.aten.expand.default(getitem_580, [128, 624, 14, 14]);  getitem_580 = None
        div_scalar_9 = torch.ops.aten.div.Scalar(expand_default_9, 196);  expand_default_9 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(mul_tensor_145, div_scalar_9);  mul_tensor_145 = div_scalar_9 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_136, torch.float32);  add_tensor_136 = None
        to_dtype_106 = torch.ops.aten.to.dtype(clone_default_22, torch.float32);  clone_default_22 = None
        neg_default_25 = torch.ops.aten.neg.default(to_dtype_106)
        exp_default_25 = torch.ops.aten.exp.default(neg_default_25);  neg_default_25 = None
        add_tensor_137 = torch.ops.aten.add.Tensor(exp_default_25, 1);  exp_default_25 = None
        reciprocal_default_25 = torch.ops.aten.reciprocal.default(add_tensor_137);  add_tensor_137 = None
        mul_tensor_152 = torch.ops.aten.mul.Tensor(reciprocal_default_25, 1);  reciprocal_default_25 = None
        mul_tensor_153 = torch.ops.aten.mul.Tensor(to_dtype_105, mul_tensor_152);  to_dtype_105 = None
        rsub_scalar_34 = torch.ops.aten.rsub.Scalar(mul_tensor_152, 1);  mul_tensor_152 = None
        mul_tensor_154 = torch.ops.aten.mul.Tensor(to_dtype_106, rsub_scalar_34);  to_dtype_106 = rsub_scalar_34 = None
        add_tensor_138 = torch.ops.aten.add.Tensor(mul_tensor_154, 1);  mul_tensor_154 = None
        mul_tensor_155 = torch.ops.aten.mul.Tensor(mul_tensor_153, add_tensor_138);  mul_tensor_153 = add_tensor_138 = None
        to_dtype_107 = torch.ops.aten.to.dtype(mul_tensor_155, torch.float32);  mul_tensor_155 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, cat_default_23, primals_349, primals_347, primals_348, getitem_152, getitem_153, True, 1e-05, [True, True, True]);  to_dtype_107 = cat_default_23 = primals_349 = primals_347 = primals_348 = getitem_152 = getitem_153 = None
        getitem_583 = native_batch_norm_backward_default_26[0]
        getitem_584 = native_batch_norm_backward_default_26[1]
        getitem_585 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        slice_tensor_48 = torch.ops.aten.slice.Tensor(getitem_583, 1, 0, 156)
        slice_tensor_49 = torch.ops.aten.slice.Tensor(getitem_583, 1, 156, 312)
        slice_tensor_50 = torch.ops.aten.slice.Tensor(getitem_583, 1, 312, 468)
        slice_tensor_51 = torch.ops.aten.slice.Tensor(getitem_583, 1, 468, 624);  getitem_583 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(slice_tensor_51, getitem_150, primals_91, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_51 = getitem_150 = primals_91 = None
        getitem_586 = convolution_backward_default_75[0]
        getitem_587 = convolution_backward_default_75[1]
        getitem_588 = convolution_backward_default_75[2];  convolution_backward_default_75 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(slice_tensor_50, getitem_149, primals_90, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_50 = getitem_149 = primals_90 = None
        getitem_589 = convolution_backward_default_76[0]
        getitem_590 = convolution_backward_default_76[1]
        getitem_591 = convolution_backward_default_76[2];  convolution_backward_default_76 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(slice_tensor_49, getitem_148, primals_89, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_49 = getitem_148 = primals_89 = None
        getitem_592 = convolution_backward_default_77[0]
        getitem_593 = convolution_backward_default_77[1]
        getitem_594 = convolution_backward_default_77[2];  convolution_backward_default_77 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(slice_tensor_48, getitem_147, primals_88, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_48 = getitem_147 = primals_88 = None
        getitem_595 = convolution_backward_default_78[0]
        getitem_596 = convolution_backward_default_78[1]
        getitem_597 = convolution_backward_default_78[2];  convolution_backward_default_78 = None
        cat_default_58 = torch.ops.aten.cat.default([getitem_595, getitem_592, getitem_589, getitem_586], 1);  getitem_595 = getitem_592 = getitem_589 = getitem_586 = None
        to_dtype_108 = torch.ops.aten.to.dtype(cat_default_58, torch.float32);  cat_default_58 = None
        to_dtype_109 = torch.ops.aten.to.dtype(clone_default_21, torch.float32);  clone_default_21 = None
        neg_default_26 = torch.ops.aten.neg.default(to_dtype_109)
        exp_default_26 = torch.ops.aten.exp.default(neg_default_26);  neg_default_26 = None
        add_tensor_139 = torch.ops.aten.add.Tensor(exp_default_26, 1);  exp_default_26 = None
        reciprocal_default_26 = torch.ops.aten.reciprocal.default(add_tensor_139);  add_tensor_139 = None
        mul_tensor_156 = torch.ops.aten.mul.Tensor(reciprocal_default_26, 1);  reciprocal_default_26 = None
        mul_tensor_157 = torch.ops.aten.mul.Tensor(to_dtype_108, mul_tensor_156);  to_dtype_108 = None
        rsub_scalar_35 = torch.ops.aten.rsub.Scalar(mul_tensor_156, 1);  mul_tensor_156 = None
        mul_tensor_158 = torch.ops.aten.mul.Tensor(to_dtype_109, rsub_scalar_35);  to_dtype_109 = rsub_scalar_35 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(mul_tensor_158, 1);  mul_tensor_158 = None
        mul_tensor_159 = torch.ops.aten.mul.Tensor(mul_tensor_157, add_tensor_140);  mul_tensor_157 = add_tensor_140 = None
        to_dtype_110 = torch.ops.aten.to.dtype(mul_tensor_159, torch.float32);  mul_tensor_159 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, cat_default_22, primals_344, primals_342, primals_343, getitem_145, getitem_146, True, 1e-05, [True, True, True]);  to_dtype_110 = cat_default_22 = primals_344 = primals_342 = primals_343 = getitem_145 = getitem_146 = None
        getitem_598 = native_batch_norm_backward_default_27[0]
        getitem_599 = native_batch_norm_backward_default_27[1]
        getitem_600 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        slice_tensor_52 = torch.ops.aten.slice.Tensor(getitem_598, 1, 0, 312)
        slice_tensor_53 = torch.ops.aten.slice.Tensor(getitem_598, 1, 312, 624);  getitem_598 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(slice_tensor_53, getitem_143, primals_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_53 = getitem_143 = primals_93 = None
        getitem_601 = convolution_backward_default_79[0]
        getitem_602 = convolution_backward_default_79[1]
        getitem_603 = convolution_backward_default_79[2];  convolution_backward_default_79 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(slice_tensor_52, getitem_142, primals_92, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_52 = getitem_142 = primals_92 = None
        getitem_604 = convolution_backward_default_80[0]
        getitem_605 = convolution_backward_default_80[1]
        getitem_606 = convolution_backward_default_80[2];  convolution_backward_default_80 = None
        cat_default_59 = torch.ops.aten.cat.default([getitem_604, getitem_601], 1);  getitem_604 = getitem_601 = None
        add_tensor_141 = torch.ops.aten.add.Tensor(getitem_565, cat_default_59);  getitem_565 = cat_default_59 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_141, cat_default_21, primals_339, primals_337, primals_338, getitem_140, getitem_141, True, 1e-05, [True, True, True]);  cat_default_21 = primals_339 = primals_337 = primals_338 = getitem_140 = getitem_141 = None
        getitem_607 = native_batch_norm_backward_default_28[0]
        getitem_608 = native_batch_norm_backward_default_28[1]
        getitem_609 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        slice_tensor_54 = torch.ops.aten.slice.Tensor(getitem_607, 1, 0, 52)
        slice_tensor_55 = torch.ops.aten.slice.Tensor(getitem_607, 1, 52, 104);  getitem_607 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(slice_tensor_55, getitem_138, primals_83, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_55 = getitem_138 = primals_83 = None
        getitem_610 = convolution_backward_default_81[0]
        getitem_611 = convolution_backward_default_81[1]
        getitem_612 = convolution_backward_default_81[2];  convolution_backward_default_81 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(slice_tensor_54, getitem_137, primals_82, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_54 = getitem_137 = primals_82 = None
        getitem_613 = convolution_backward_default_82[0]
        getitem_614 = convolution_backward_default_82[1]
        getitem_615 = convolution_backward_default_82[2];  convolution_backward_default_82 = None
        cat_default_60 = torch.ops.aten.cat.default([getitem_613, getitem_610], 1);  getitem_613 = getitem_610 = None
        mul_tensor_160 = torch.ops.aten.mul.Tensor(cat_default_60, silu__default_19);  silu__default_19 = None
        mul_tensor_161 = torch.ops.aten.mul.Tensor(cat_default_60, sigmoid_default_6);  cat_default_60 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(mul_tensor_160, [2, 3], True);  mul_tensor_160 = None
        to_dtype_111 = torch.ops.aten.to.dtype(sum_dim_int_list_10, torch.float32);  sum_dim_int_list_10 = None
        to_dtype_112 = torch.ops.aten.to.dtype(sigmoid_default_6, torch.float32);  sigmoid_default_6 = None
        rsub_scalar_36 = torch.ops.aten.rsub.Scalar(to_dtype_112, 1)
        mul_tensor_162 = torch.ops.aten.mul.Tensor(to_dtype_112, rsub_scalar_36);  to_dtype_112 = rsub_scalar_36 = None
        conj_physical_default_9 = torch.ops.aten.conj_physical.default(mul_tensor_162);  mul_tensor_162 = None
        mul_tensor_163 = torch.ops.aten.mul.Tensor(to_dtype_111, conj_physical_default_9);  to_dtype_111 = conj_physical_default_9 = None
        to_dtype_113 = torch.ops.aten.to.dtype(mul_tensor_163, torch.float32);  mul_tensor_163 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(to_dtype_113, silu__default_20, primals_85, [624], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_113 = silu__default_20 = primals_85 = None
        getitem_616 = convolution_backward_default_83[0]
        getitem_617 = convolution_backward_default_83[1]
        getitem_618 = convolution_backward_default_83[2];  convolution_backward_default_83 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_616, torch.float32);  getitem_616 = None
        to_dtype_115 = torch.ops.aten.to.dtype(clone_default_20, torch.float32);  clone_default_20 = None
        neg_default_27 = torch.ops.aten.neg.default(to_dtype_115)
        exp_default_27 = torch.ops.aten.exp.default(neg_default_27);  neg_default_27 = None
        add_tensor_142 = torch.ops.aten.add.Tensor(exp_default_27, 1);  exp_default_27 = None
        reciprocal_default_27 = torch.ops.aten.reciprocal.default(add_tensor_142);  add_tensor_142 = None
        mul_tensor_164 = torch.ops.aten.mul.Tensor(reciprocal_default_27, 1);  reciprocal_default_27 = None
        mul_tensor_165 = torch.ops.aten.mul.Tensor(to_dtype_114, mul_tensor_164);  to_dtype_114 = None
        rsub_scalar_37 = torch.ops.aten.rsub.Scalar(mul_tensor_164, 1);  mul_tensor_164 = None
        mul_tensor_166 = torch.ops.aten.mul.Tensor(to_dtype_115, rsub_scalar_37);  to_dtype_115 = rsub_scalar_37 = None
        add_tensor_143 = torch.ops.aten.add.Tensor(mul_tensor_166, 1);  mul_tensor_166 = None
        mul_tensor_167 = torch.ops.aten.mul.Tensor(mul_tensor_165, add_tensor_143);  mul_tensor_165 = add_tensor_143 = None
        to_dtype_116 = torch.ops.aten.to.dtype(mul_tensor_167, torch.float32);  mul_tensor_167 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(to_dtype_116, mean_dim_6, primals_87, [26], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_116 = mean_dim_6 = primals_87 = None
        getitem_619 = convolution_backward_default_84[0]
        getitem_620 = convolution_backward_default_84[1]
        getitem_621 = convolution_backward_default_84[2];  convolution_backward_default_84 = None
        expand_default_10 = torch.ops.aten.expand.default(getitem_619, [128, 624, 14, 14]);  getitem_619 = None
        div_scalar_10 = torch.ops.aten.div.Scalar(expand_default_10, 196);  expand_default_10 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(mul_tensor_161, div_scalar_10);  mul_tensor_161 = div_scalar_10 = None
        to_dtype_117 = torch.ops.aten.to.dtype(add_tensor_144, torch.float32);  add_tensor_144 = None
        to_dtype_118 = torch.ops.aten.to.dtype(clone_default_19, torch.float32);  clone_default_19 = None
        neg_default_28 = torch.ops.aten.neg.default(to_dtype_118)
        exp_default_28 = torch.ops.aten.exp.default(neg_default_28);  neg_default_28 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(exp_default_28, 1);  exp_default_28 = None
        reciprocal_default_28 = torch.ops.aten.reciprocal.default(add_tensor_145);  add_tensor_145 = None
        mul_tensor_168 = torch.ops.aten.mul.Tensor(reciprocal_default_28, 1);  reciprocal_default_28 = None
        mul_tensor_169 = torch.ops.aten.mul.Tensor(to_dtype_117, mul_tensor_168);  to_dtype_117 = None
        rsub_scalar_38 = torch.ops.aten.rsub.Scalar(mul_tensor_168, 1);  mul_tensor_168 = None
        mul_tensor_170 = torch.ops.aten.mul.Tensor(to_dtype_118, rsub_scalar_38);  to_dtype_118 = rsub_scalar_38 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(mul_tensor_170, 1);  mul_tensor_170 = None
        mul_tensor_171 = torch.ops.aten.mul.Tensor(mul_tensor_169, add_tensor_146);  mul_tensor_169 = add_tensor_146 = None
        to_dtype_119 = torch.ops.aten.to.dtype(mul_tensor_171, torch.float32);  mul_tensor_171 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, cat_default_20, primals_334, primals_332, primals_333, getitem_135, getitem_136, True, 1e-05, [True, True, True]);  to_dtype_119 = cat_default_20 = primals_334 = primals_332 = primals_333 = getitem_135 = getitem_136 = None
        getitem_622 = native_batch_norm_backward_default_29[0]
        getitem_623 = native_batch_norm_backward_default_29[1]
        getitem_624 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        slice_tensor_56 = torch.ops.aten.slice.Tensor(getitem_622, 1, 0, 156)
        slice_tensor_57 = torch.ops.aten.slice.Tensor(getitem_622, 1, 156, 312)
        slice_tensor_58 = torch.ops.aten.slice.Tensor(getitem_622, 1, 312, 468)
        slice_tensor_59 = torch.ops.aten.slice.Tensor(getitem_622, 1, 468, 624);  getitem_622 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(slice_tensor_59, getitem_133, primals_79, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_59 = getitem_133 = primals_79 = None
        getitem_625 = convolution_backward_default_85[0]
        getitem_626 = convolution_backward_default_85[1]
        getitem_627 = convolution_backward_default_85[2];  convolution_backward_default_85 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(slice_tensor_58, getitem_132, primals_78, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_58 = getitem_132 = primals_78 = None
        getitem_628 = convolution_backward_default_86[0]
        getitem_629 = convolution_backward_default_86[1]
        getitem_630 = convolution_backward_default_86[2];  convolution_backward_default_86 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(slice_tensor_57, getitem_131, primals_77, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_57 = getitem_131 = primals_77 = None
        getitem_631 = convolution_backward_default_87[0]
        getitem_632 = convolution_backward_default_87[1]
        getitem_633 = convolution_backward_default_87[2];  convolution_backward_default_87 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(slice_tensor_56, getitem_130, primals_76, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_56 = getitem_130 = primals_76 = None
        getitem_634 = convolution_backward_default_88[0]
        getitem_635 = convolution_backward_default_88[1]
        getitem_636 = convolution_backward_default_88[2];  convolution_backward_default_88 = None
        cat_default_61 = torch.ops.aten.cat.default([getitem_634, getitem_631, getitem_628, getitem_625], 1);  getitem_634 = getitem_631 = getitem_628 = getitem_625 = None
        to_dtype_120 = torch.ops.aten.to.dtype(cat_default_61, torch.float32);  cat_default_61 = None
        to_dtype_121 = torch.ops.aten.to.dtype(clone_default_18, torch.float32);  clone_default_18 = None
        neg_default_29 = torch.ops.aten.neg.default(to_dtype_121)
        exp_default_29 = torch.ops.aten.exp.default(neg_default_29);  neg_default_29 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(exp_default_29, 1);  exp_default_29 = None
        reciprocal_default_29 = torch.ops.aten.reciprocal.default(add_tensor_147);  add_tensor_147 = None
        mul_tensor_172 = torch.ops.aten.mul.Tensor(reciprocal_default_29, 1);  reciprocal_default_29 = None
        mul_tensor_173 = torch.ops.aten.mul.Tensor(to_dtype_120, mul_tensor_172);  to_dtype_120 = None
        rsub_scalar_39 = torch.ops.aten.rsub.Scalar(mul_tensor_172, 1);  mul_tensor_172 = None
        mul_tensor_174 = torch.ops.aten.mul.Tensor(to_dtype_121, rsub_scalar_39);  to_dtype_121 = rsub_scalar_39 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(mul_tensor_174, 1);  mul_tensor_174 = None
        mul_tensor_175 = torch.ops.aten.mul.Tensor(mul_tensor_173, add_tensor_148);  mul_tensor_173 = add_tensor_148 = None
        to_dtype_122 = torch.ops.aten.to.dtype(mul_tensor_175, torch.float32);  mul_tensor_175 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, cat_default_19, primals_329, primals_327, primals_328, getitem_128, getitem_129, True, 1e-05, [True, True, True]);  to_dtype_122 = cat_default_19 = primals_329 = primals_327 = primals_328 = getitem_128 = getitem_129 = None
        getitem_637 = native_batch_norm_backward_default_30[0]
        getitem_638 = native_batch_norm_backward_default_30[1]
        getitem_639 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        slice_tensor_60 = torch.ops.aten.slice.Tensor(getitem_637, 1, 0, 312)
        slice_tensor_61 = torch.ops.aten.slice.Tensor(getitem_637, 1, 312, 624);  getitem_637 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(slice_tensor_61, getitem_126, primals_81, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_61 = getitem_126 = primals_81 = None
        getitem_640 = convolution_backward_default_89[0]
        getitem_641 = convolution_backward_default_89[1]
        getitem_642 = convolution_backward_default_89[2];  convolution_backward_default_89 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(slice_tensor_60, getitem_125, primals_80, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_60 = getitem_125 = primals_80 = None
        getitem_643 = convolution_backward_default_90[0]
        getitem_644 = convolution_backward_default_90[1]
        getitem_645 = convolution_backward_default_90[2];  convolution_backward_default_90 = None
        cat_default_62 = torch.ops.aten.cat.default([getitem_643, getitem_640], 1);  getitem_643 = getitem_640 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(add_tensor_141, cat_default_62);  add_tensor_141 = cat_default_62 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_149, cat_default_18, primals_324, primals_322, primals_323, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  cat_default_18 = primals_324 = primals_322 = primals_323 = getitem_123 = getitem_124 = None
        getitem_646 = native_batch_norm_backward_default_31[0]
        getitem_647 = native_batch_norm_backward_default_31[1]
        getitem_648 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        slice_tensor_62 = torch.ops.aten.slice.Tensor(getitem_646, 1, 0, 52)
        slice_tensor_63 = torch.ops.aten.slice.Tensor(getitem_646, 1, 52, 104);  getitem_646 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(slice_tensor_63, getitem_121, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_63 = getitem_121 = primals_71 = None
        getitem_649 = convolution_backward_default_91[0]
        getitem_650 = convolution_backward_default_91[1]
        getitem_651 = convolution_backward_default_91[2];  convolution_backward_default_91 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(slice_tensor_62, getitem_120, primals_70, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_62 = getitem_120 = primals_70 = None
        getitem_652 = convolution_backward_default_92[0]
        getitem_653 = convolution_backward_default_92[1]
        getitem_654 = convolution_backward_default_92[2];  convolution_backward_default_92 = None
        cat_default_63 = torch.ops.aten.cat.default([getitem_652, getitem_649], 1);  getitem_652 = getitem_649 = None
        mul_tensor_176 = torch.ops.aten.mul.Tensor(cat_default_63, silu__default_16);  silu__default_16 = None
        mul_tensor_177 = torch.ops.aten.mul.Tensor(cat_default_63, sigmoid_default_5);  cat_default_63 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(mul_tensor_176, [2, 3], True);  mul_tensor_176 = None
        to_dtype_123 = torch.ops.aten.to.dtype(sum_dim_int_list_11, torch.float32);  sum_dim_int_list_11 = None
        to_dtype_124 = torch.ops.aten.to.dtype(sigmoid_default_5, torch.float32);  sigmoid_default_5 = None
        rsub_scalar_40 = torch.ops.aten.rsub.Scalar(to_dtype_124, 1)
        mul_tensor_178 = torch.ops.aten.mul.Tensor(to_dtype_124, rsub_scalar_40);  to_dtype_124 = rsub_scalar_40 = None
        conj_physical_default_10 = torch.ops.aten.conj_physical.default(mul_tensor_178);  mul_tensor_178 = None
        mul_tensor_179 = torch.ops.aten.mul.Tensor(to_dtype_123, conj_physical_default_10);  to_dtype_123 = conj_physical_default_10 = None
        to_dtype_125 = torch.ops.aten.to.dtype(mul_tensor_179, torch.float32);  mul_tensor_179 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(to_dtype_125, silu__default_17, primals_73, [624], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_125 = silu__default_17 = primals_73 = None
        getitem_655 = convolution_backward_default_93[0]
        getitem_656 = convolution_backward_default_93[1]
        getitem_657 = convolution_backward_default_93[2];  convolution_backward_default_93 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_655, torch.float32);  getitem_655 = None
        to_dtype_127 = torch.ops.aten.to.dtype(clone_default_17, torch.float32);  clone_default_17 = None
        neg_default_30 = torch.ops.aten.neg.default(to_dtype_127)
        exp_default_30 = torch.ops.aten.exp.default(neg_default_30);  neg_default_30 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(exp_default_30, 1);  exp_default_30 = None
        reciprocal_default_30 = torch.ops.aten.reciprocal.default(add_tensor_150);  add_tensor_150 = None
        mul_tensor_180 = torch.ops.aten.mul.Tensor(reciprocal_default_30, 1);  reciprocal_default_30 = None
        mul_tensor_181 = torch.ops.aten.mul.Tensor(to_dtype_126, mul_tensor_180);  to_dtype_126 = None
        rsub_scalar_41 = torch.ops.aten.rsub.Scalar(mul_tensor_180, 1);  mul_tensor_180 = None
        mul_tensor_182 = torch.ops.aten.mul.Tensor(to_dtype_127, rsub_scalar_41);  to_dtype_127 = rsub_scalar_41 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(mul_tensor_182, 1);  mul_tensor_182 = None
        mul_tensor_183 = torch.ops.aten.mul.Tensor(mul_tensor_181, add_tensor_151);  mul_tensor_181 = add_tensor_151 = None
        to_dtype_128 = torch.ops.aten.to.dtype(mul_tensor_183, torch.float32);  mul_tensor_183 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(to_dtype_128, mean_dim_5, primals_75, [26], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_128 = mean_dim_5 = primals_75 = None
        getitem_658 = convolution_backward_default_94[0]
        getitem_659 = convolution_backward_default_94[1]
        getitem_660 = convolution_backward_default_94[2];  convolution_backward_default_94 = None
        expand_default_11 = torch.ops.aten.expand.default(getitem_658, [128, 624, 14, 14]);  getitem_658 = None
        div_scalar_11 = torch.ops.aten.div.Scalar(expand_default_11, 196);  expand_default_11 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(mul_tensor_177, div_scalar_11);  mul_tensor_177 = div_scalar_11 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_152, torch.float32);  add_tensor_152 = None
        to_dtype_130 = torch.ops.aten.to.dtype(clone_default_16, torch.float32);  clone_default_16 = None
        neg_default_31 = torch.ops.aten.neg.default(to_dtype_130)
        exp_default_31 = torch.ops.aten.exp.default(neg_default_31);  neg_default_31 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(exp_default_31, 1);  exp_default_31 = None
        reciprocal_default_31 = torch.ops.aten.reciprocal.default(add_tensor_153);  add_tensor_153 = None
        mul_tensor_184 = torch.ops.aten.mul.Tensor(reciprocal_default_31, 1);  reciprocal_default_31 = None
        mul_tensor_185 = torch.ops.aten.mul.Tensor(to_dtype_129, mul_tensor_184);  to_dtype_129 = None
        rsub_scalar_42 = torch.ops.aten.rsub.Scalar(mul_tensor_184, 1);  mul_tensor_184 = None
        mul_tensor_186 = torch.ops.aten.mul.Tensor(to_dtype_130, rsub_scalar_42);  to_dtype_130 = rsub_scalar_42 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(mul_tensor_186, 1);  mul_tensor_186 = None
        mul_tensor_187 = torch.ops.aten.mul.Tensor(mul_tensor_185, add_tensor_154);  mul_tensor_185 = add_tensor_154 = None
        to_dtype_131 = torch.ops.aten.to.dtype(mul_tensor_187, torch.float32);  mul_tensor_187 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, cat_default_17, primals_319, primals_317, primals_318, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  to_dtype_131 = cat_default_17 = primals_319 = primals_317 = primals_318 = getitem_118 = getitem_119 = None
        getitem_661 = native_batch_norm_backward_default_32[0]
        getitem_662 = native_batch_norm_backward_default_32[1]
        getitem_663 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        slice_tensor_64 = torch.ops.aten.slice.Tensor(getitem_661, 1, 0, 156)
        slice_tensor_65 = torch.ops.aten.slice.Tensor(getitem_661, 1, 156, 312)
        slice_tensor_66 = torch.ops.aten.slice.Tensor(getitem_661, 1, 312, 468)
        slice_tensor_67 = torch.ops.aten.slice.Tensor(getitem_661, 1, 468, 624);  getitem_661 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(slice_tensor_67, getitem_116, primals_67, [0], [1, 1], [4, 4], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_67 = getitem_116 = primals_67 = None
        getitem_664 = convolution_backward_default_95[0]
        getitem_665 = convolution_backward_default_95[1]
        getitem_666 = convolution_backward_default_95[2];  convolution_backward_default_95 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(slice_tensor_66, getitem_115, primals_66, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_66 = getitem_115 = primals_66 = None
        getitem_667 = convolution_backward_default_96[0]
        getitem_668 = convolution_backward_default_96[1]
        getitem_669 = convolution_backward_default_96[2];  convolution_backward_default_96 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(slice_tensor_65, getitem_114, primals_65, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_65 = getitem_114 = primals_65 = None
        getitem_670 = convolution_backward_default_97[0]
        getitem_671 = convolution_backward_default_97[1]
        getitem_672 = convolution_backward_default_97[2];  convolution_backward_default_97 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(slice_tensor_64, getitem_113, primals_64, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 156, [True, True, False]);  slice_tensor_64 = getitem_113 = primals_64 = None
        getitem_673 = convolution_backward_default_98[0]
        getitem_674 = convolution_backward_default_98[1]
        getitem_675 = convolution_backward_default_98[2];  convolution_backward_default_98 = None
        cat_default_64 = torch.ops.aten.cat.default([getitem_673, getitem_670, getitem_667, getitem_664], 1);  getitem_673 = getitem_670 = getitem_667 = getitem_664 = None
        to_dtype_132 = torch.ops.aten.to.dtype(cat_default_64, torch.float32);  cat_default_64 = None
        to_dtype_133 = torch.ops.aten.to.dtype(clone_default_15, torch.float32);  clone_default_15 = None
        neg_default_32 = torch.ops.aten.neg.default(to_dtype_133)
        exp_default_32 = torch.ops.aten.exp.default(neg_default_32);  neg_default_32 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(exp_default_32, 1);  exp_default_32 = None
        reciprocal_default_32 = torch.ops.aten.reciprocal.default(add_tensor_155);  add_tensor_155 = None
        mul_tensor_188 = torch.ops.aten.mul.Tensor(reciprocal_default_32, 1);  reciprocal_default_32 = None
        mul_tensor_189 = torch.ops.aten.mul.Tensor(to_dtype_132, mul_tensor_188);  to_dtype_132 = None
        rsub_scalar_43 = torch.ops.aten.rsub.Scalar(mul_tensor_188, 1);  mul_tensor_188 = None
        mul_tensor_190 = torch.ops.aten.mul.Tensor(to_dtype_133, rsub_scalar_43);  to_dtype_133 = rsub_scalar_43 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(mul_tensor_190, 1);  mul_tensor_190 = None
        mul_tensor_191 = torch.ops.aten.mul.Tensor(mul_tensor_189, add_tensor_156);  mul_tensor_189 = add_tensor_156 = None
        to_dtype_134 = torch.ops.aten.to.dtype(mul_tensor_191, torch.float32);  mul_tensor_191 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, cat_default_16, primals_314, primals_312, primals_313, getitem_111, getitem_112, True, 1e-05, [True, True, True]);  to_dtype_134 = cat_default_16 = primals_314 = primals_312 = primals_313 = getitem_111 = getitem_112 = None
        getitem_676 = native_batch_norm_backward_default_33[0]
        getitem_677 = native_batch_norm_backward_default_33[1]
        getitem_678 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        slice_tensor_68 = torch.ops.aten.slice.Tensor(getitem_676, 1, 0, 312)
        slice_tensor_69 = torch.ops.aten.slice.Tensor(getitem_676, 1, 312, 624);  getitem_676 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(slice_tensor_69, getitem_109, primals_69, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_69 = getitem_109 = primals_69 = None
        getitem_679 = convolution_backward_default_99[0]
        getitem_680 = convolution_backward_default_99[1]
        getitem_681 = convolution_backward_default_99[2];  convolution_backward_default_99 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(slice_tensor_68, getitem_108, primals_68, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_68 = getitem_108 = primals_68 = None
        getitem_682 = convolution_backward_default_100[0]
        getitem_683 = convolution_backward_default_100[1]
        getitem_684 = convolution_backward_default_100[2];  convolution_backward_default_100 = None
        cat_default_65 = torch.ops.aten.cat.default([getitem_682, getitem_679], 1);  getitem_682 = getitem_679 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(add_tensor_149, cat_default_65);  add_tensor_149 = cat_default_65 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_157, convolution_default_53, primals_309, primals_307, primals_308, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  add_tensor_157 = convolution_default_53 = primals_309 = primals_307 = primals_308 = getitem_106 = getitem_107 = None
        getitem_685 = native_batch_norm_backward_default_34[0]
        getitem_686 = native_batch_norm_backward_default_34[1]
        getitem_687 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_685, mul_tensor_4, primals_59, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_685 = mul_tensor_4 = primals_59 = None
        getitem_688 = convolution_backward_default_101[0]
        getitem_689 = convolution_backward_default_101[1]
        getitem_690 = convolution_backward_default_101[2];  convolution_backward_default_101 = None
        mul_tensor_192 = torch.ops.aten.mul.Tensor(getitem_688, silu__default_13);  silu__default_13 = None
        mul_tensor_193 = torch.ops.aten.mul.Tensor(getitem_688, sigmoid_default_4);  getitem_688 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(mul_tensor_192, [2, 3], True);  mul_tensor_192 = None
        to_dtype_135 = torch.ops.aten.to.dtype(sum_dim_int_list_12, torch.float32);  sum_dim_int_list_12 = None
        to_dtype_136 = torch.ops.aten.to.dtype(sigmoid_default_4, torch.float32);  sigmoid_default_4 = None
        rsub_scalar_44 = torch.ops.aten.rsub.Scalar(to_dtype_136, 1)
        mul_tensor_194 = torch.ops.aten.mul.Tensor(to_dtype_136, rsub_scalar_44);  to_dtype_136 = rsub_scalar_44 = None
        conj_physical_default_11 = torch.ops.aten.conj_physical.default(mul_tensor_194);  mul_tensor_194 = None
        mul_tensor_195 = torch.ops.aten.mul.Tensor(to_dtype_135, conj_physical_default_11);  to_dtype_135 = conj_physical_default_11 = None
        to_dtype_137 = torch.ops.aten.to.dtype(mul_tensor_195, torch.float32);  mul_tensor_195 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(to_dtype_137, silu__default_14, primals_61, [336], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_137 = silu__default_14 = primals_61 = None
        getitem_691 = convolution_backward_default_102[0]
        getitem_692 = convolution_backward_default_102[1]
        getitem_693 = convolution_backward_default_102[2];  convolution_backward_default_102 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_691, torch.float32);  getitem_691 = None
        to_dtype_139 = torch.ops.aten.to.dtype(clone_default_14, torch.float32);  clone_default_14 = None
        neg_default_33 = torch.ops.aten.neg.default(to_dtype_139)
        exp_default_33 = torch.ops.aten.exp.default(neg_default_33);  neg_default_33 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(exp_default_33, 1);  exp_default_33 = None
        reciprocal_default_33 = torch.ops.aten.reciprocal.default(add_tensor_158);  add_tensor_158 = None
        mul_tensor_196 = torch.ops.aten.mul.Tensor(reciprocal_default_33, 1);  reciprocal_default_33 = None
        mul_tensor_197 = torch.ops.aten.mul.Tensor(to_dtype_138, mul_tensor_196);  to_dtype_138 = None
        rsub_scalar_45 = torch.ops.aten.rsub.Scalar(mul_tensor_196, 1);  mul_tensor_196 = None
        mul_tensor_198 = torch.ops.aten.mul.Tensor(to_dtype_139, rsub_scalar_45);  to_dtype_139 = rsub_scalar_45 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(mul_tensor_198, 1);  mul_tensor_198 = None
        mul_tensor_199 = torch.ops.aten.mul.Tensor(mul_tensor_197, add_tensor_159);  mul_tensor_197 = add_tensor_159 = None
        to_dtype_140 = torch.ops.aten.to.dtype(mul_tensor_199, torch.float32);  mul_tensor_199 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(to_dtype_140, mean_dim_4, primals_63, [14], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_140 = mean_dim_4 = primals_63 = None
        getitem_694 = convolution_backward_default_103[0]
        getitem_695 = convolution_backward_default_103[1]
        getitem_696 = convolution_backward_default_103[2];  convolution_backward_default_103 = None
        expand_default_12 = torch.ops.aten.expand.default(getitem_694, [128, 336, 14, 14]);  getitem_694 = None
        div_scalar_12 = torch.ops.aten.div.Scalar(expand_default_12, 196);  expand_default_12 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(mul_tensor_193, div_scalar_12);  mul_tensor_193 = div_scalar_12 = None
        to_dtype_141 = torch.ops.aten.to.dtype(add_tensor_160, torch.float32);  add_tensor_160 = None
        to_dtype_142 = torch.ops.aten.to.dtype(clone_default_13, torch.float32);  clone_default_13 = None
        neg_default_34 = torch.ops.aten.neg.default(to_dtype_142)
        exp_default_34 = torch.ops.aten.exp.default(neg_default_34);  neg_default_34 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(exp_default_34, 1);  exp_default_34 = None
        reciprocal_default_34 = torch.ops.aten.reciprocal.default(add_tensor_161);  add_tensor_161 = None
        mul_tensor_200 = torch.ops.aten.mul.Tensor(reciprocal_default_34, 1);  reciprocal_default_34 = None
        mul_tensor_201 = torch.ops.aten.mul.Tensor(to_dtype_141, mul_tensor_200);  to_dtype_141 = None
        rsub_scalar_46 = torch.ops.aten.rsub.Scalar(mul_tensor_200, 1);  mul_tensor_200 = None
        mul_tensor_202 = torch.ops.aten.mul.Tensor(to_dtype_142, rsub_scalar_46);  to_dtype_142 = rsub_scalar_46 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(mul_tensor_202, 1);  mul_tensor_202 = None
        mul_tensor_203 = torch.ops.aten.mul.Tensor(mul_tensor_201, add_tensor_162);  mul_tensor_201 = add_tensor_162 = None
        to_dtype_143 = torch.ops.aten.to.dtype(mul_tensor_203, torch.float32);  mul_tensor_203 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, cat_default_15, primals_304, primals_302, primals_303, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  to_dtype_143 = cat_default_15 = primals_304 = primals_302 = primals_303 = getitem_103 = getitem_104 = None
        getitem_697 = native_batch_norm_backward_default_35[0]
        getitem_698 = native_batch_norm_backward_default_35[1]
        getitem_699 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        slice_tensor_70 = torch.ops.aten.slice.Tensor(getitem_697, 1, 0, 112)
        slice_tensor_71 = torch.ops.aten.slice.Tensor(getitem_697, 1, 112, 224)
        slice_tensor_72 = torch.ops.aten.slice.Tensor(getitem_697, 1, 224, 336);  getitem_697 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(slice_tensor_72, getitem_101, primals_57, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 112, [True, True, False]);  slice_tensor_72 = getitem_101 = primals_57 = None
        getitem_700 = convolution_backward_default_104[0]
        getitem_701 = convolution_backward_default_104[1]
        getitem_702 = convolution_backward_default_104[2];  convolution_backward_default_104 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(slice_tensor_71, getitem_100, primals_56, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 112, [True, True, False]);  slice_tensor_71 = getitem_100 = primals_56 = None
        getitem_703 = convolution_backward_default_105[0]
        getitem_704 = convolution_backward_default_105[1]
        getitem_705 = convolution_backward_default_105[2];  convolution_backward_default_105 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(slice_tensor_70, getitem_99, primals_55, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 112, [True, True, False]);  slice_tensor_70 = getitem_99 = primals_55 = None
        getitem_706 = convolution_backward_default_106[0]
        getitem_707 = convolution_backward_default_106[1]
        getitem_708 = convolution_backward_default_106[2];  convolution_backward_default_106 = None
        cat_default_66 = torch.ops.aten.cat.default([getitem_706, getitem_703, getitem_700], 1);  getitem_706 = getitem_703 = getitem_700 = None
        to_dtype_144 = torch.ops.aten.to.dtype(cat_default_66, torch.float32);  cat_default_66 = None
        to_dtype_145 = torch.ops.aten.to.dtype(clone_default_12, torch.float32);  clone_default_12 = None
        neg_default_35 = torch.ops.aten.neg.default(to_dtype_145)
        exp_default_35 = torch.ops.aten.exp.default(neg_default_35);  neg_default_35 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(exp_default_35, 1);  exp_default_35 = None
        reciprocal_default_35 = torch.ops.aten.reciprocal.default(add_tensor_163);  add_tensor_163 = None
        mul_tensor_204 = torch.ops.aten.mul.Tensor(reciprocal_default_35, 1);  reciprocal_default_35 = None
        mul_tensor_205 = torch.ops.aten.mul.Tensor(to_dtype_144, mul_tensor_204);  to_dtype_144 = None
        rsub_scalar_47 = torch.ops.aten.rsub.Scalar(mul_tensor_204, 1);  mul_tensor_204 = None
        mul_tensor_206 = torch.ops.aten.mul.Tensor(to_dtype_145, rsub_scalar_47);  to_dtype_145 = rsub_scalar_47 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(mul_tensor_206, 1);  mul_tensor_206 = None
        mul_tensor_207 = torch.ops.aten.mul.Tensor(mul_tensor_205, add_tensor_164);  mul_tensor_205 = add_tensor_164 = None
        to_dtype_146 = torch.ops.aten.to.dtype(mul_tensor_207, torch.float32);  mul_tensor_207 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_47, primals_299, primals_297, primals_298, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_47 = primals_299 = primals_297 = primals_298 = getitem_97 = getitem_98 = None
        getitem_709 = native_batch_norm_backward_default_36[0]
        getitem_710 = native_batch_norm_backward_default_36[1]
        getitem_711 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_709, add_tensor_25, primals_58, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_709 = add_tensor_25 = primals_58 = None
        getitem_712 = convolution_backward_default_107[0]
        getitem_713 = convolution_backward_default_107[1]
        getitem_714 = convolution_backward_default_107[2];  convolution_backward_default_107 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(getitem_712, cat_default_14, primals_294, primals_292, primals_293, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  cat_default_14 = primals_294 = primals_292 = primals_293 = getitem_94 = getitem_95 = None
        getitem_715 = native_batch_norm_backward_default_37[0]
        getitem_716 = native_batch_norm_backward_default_37[1]
        getitem_717 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        slice_tensor_73 = torch.ops.aten.slice.Tensor(getitem_715, 1, 0, 28)
        slice_tensor_74 = torch.ops.aten.slice.Tensor(getitem_715, 1, 28, 56);  getitem_715 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(slice_tensor_74, getitem_92, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_74 = getitem_92 = primals_50 = None
        getitem_718 = convolution_backward_default_108[0]
        getitem_719 = convolution_backward_default_108[1]
        getitem_720 = convolution_backward_default_108[2];  convolution_backward_default_108 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(slice_tensor_73, getitem_91, primals_49, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_73 = getitem_91 = primals_49 = None
        getitem_721 = convolution_backward_default_109[0]
        getitem_722 = convolution_backward_default_109[1]
        getitem_723 = convolution_backward_default_109[2];  convolution_backward_default_109 = None
        cat_default_67 = torch.ops.aten.cat.default([getitem_721, getitem_718], 1);  getitem_721 = getitem_718 = None
        mul_tensor_208 = torch.ops.aten.mul.Tensor(cat_default_67, silu__default_10);  silu__default_10 = None
        mul_tensor_209 = torch.ops.aten.mul.Tensor(cat_default_67, sigmoid_default_3);  cat_default_67 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(mul_tensor_208, [2, 3], True);  mul_tensor_208 = None
        to_dtype_147 = torch.ops.aten.to.dtype(sum_dim_int_list_13, torch.float32);  sum_dim_int_list_13 = None
        to_dtype_148 = torch.ops.aten.to.dtype(sigmoid_default_3, torch.float32);  sigmoid_default_3 = None
        rsub_scalar_48 = torch.ops.aten.rsub.Scalar(to_dtype_148, 1)
        mul_tensor_210 = torch.ops.aten.mul.Tensor(to_dtype_148, rsub_scalar_48);  to_dtype_148 = rsub_scalar_48 = None
        conj_physical_default_12 = torch.ops.aten.conj_physical.default(mul_tensor_210);  mul_tensor_210 = None
        mul_tensor_211 = torch.ops.aten.mul.Tensor(to_dtype_147, conj_physical_default_12);  to_dtype_147 = conj_physical_default_12 = None
        to_dtype_149 = torch.ops.aten.to.dtype(mul_tensor_211, torch.float32);  mul_tensor_211 = None
        convolution_backward_default_110 = torch.ops.aten.convolution_backward.default(to_dtype_149, silu__default_11, primals_52, [336], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_149 = silu__default_11 = primals_52 = None
        getitem_724 = convolution_backward_default_110[0]
        getitem_725 = convolution_backward_default_110[1]
        getitem_726 = convolution_backward_default_110[2];  convolution_backward_default_110 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_724, torch.float32);  getitem_724 = None
        to_dtype_151 = torch.ops.aten.to.dtype(clone_default_11, torch.float32);  clone_default_11 = None
        neg_default_36 = torch.ops.aten.neg.default(to_dtype_151)
        exp_default_36 = torch.ops.aten.exp.default(neg_default_36);  neg_default_36 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(exp_default_36, 1);  exp_default_36 = None
        reciprocal_default_36 = torch.ops.aten.reciprocal.default(add_tensor_165);  add_tensor_165 = None
        mul_tensor_212 = torch.ops.aten.mul.Tensor(reciprocal_default_36, 1);  reciprocal_default_36 = None
        mul_tensor_213 = torch.ops.aten.mul.Tensor(to_dtype_150, mul_tensor_212);  to_dtype_150 = None
        rsub_scalar_49 = torch.ops.aten.rsub.Scalar(mul_tensor_212, 1);  mul_tensor_212 = None
        mul_tensor_214 = torch.ops.aten.mul.Tensor(to_dtype_151, rsub_scalar_49);  to_dtype_151 = rsub_scalar_49 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(mul_tensor_214, 1);  mul_tensor_214 = None
        mul_tensor_215 = torch.ops.aten.mul.Tensor(mul_tensor_213, add_tensor_166);  mul_tensor_213 = add_tensor_166 = None
        to_dtype_152 = torch.ops.aten.to.dtype(mul_tensor_215, torch.float32);  mul_tensor_215 = None
        convolution_backward_default_111 = torch.ops.aten.convolution_backward.default(to_dtype_152, mean_dim_3, primals_54, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_152 = mean_dim_3 = primals_54 = None
        getitem_727 = convolution_backward_default_111[0]
        getitem_728 = convolution_backward_default_111[1]
        getitem_729 = convolution_backward_default_111[2];  convolution_backward_default_111 = None
        expand_default_13 = torch.ops.aten.expand.default(getitem_727, [128, 336, 28, 28]);  getitem_727 = None
        div_scalar_13 = torch.ops.aten.div.Scalar(expand_default_13, 784);  expand_default_13 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(mul_tensor_209, div_scalar_13);  mul_tensor_209 = div_scalar_13 = None
        to_dtype_153 = torch.ops.aten.to.dtype(add_tensor_167, torch.float32);  add_tensor_167 = None
        to_dtype_154 = torch.ops.aten.to.dtype(clone_default_10, torch.float32);  clone_default_10 = None
        neg_default_37 = torch.ops.aten.neg.default(to_dtype_154)
        exp_default_37 = torch.ops.aten.exp.default(neg_default_37);  neg_default_37 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(exp_default_37, 1);  exp_default_37 = None
        reciprocal_default_37 = torch.ops.aten.reciprocal.default(add_tensor_168);  add_tensor_168 = None
        mul_tensor_216 = torch.ops.aten.mul.Tensor(reciprocal_default_37, 1);  reciprocal_default_37 = None
        mul_tensor_217 = torch.ops.aten.mul.Tensor(to_dtype_153, mul_tensor_216);  to_dtype_153 = None
        rsub_scalar_50 = torch.ops.aten.rsub.Scalar(mul_tensor_216, 1);  mul_tensor_216 = None
        mul_tensor_218 = torch.ops.aten.mul.Tensor(to_dtype_154, rsub_scalar_50);  to_dtype_154 = rsub_scalar_50 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(mul_tensor_218, 1);  mul_tensor_218 = None
        mul_tensor_219 = torch.ops.aten.mul.Tensor(mul_tensor_217, add_tensor_169);  mul_tensor_217 = add_tensor_169 = None
        to_dtype_155 = torch.ops.aten.to.dtype(mul_tensor_219, torch.float32);  mul_tensor_219 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, cat_default_13, primals_289, primals_287, primals_288, getitem_89, getitem_90, True, 1e-05, [True, True, True]);  to_dtype_155 = cat_default_13 = primals_289 = primals_287 = primals_288 = getitem_89 = getitem_90 = None
        getitem_730 = native_batch_norm_backward_default_38[0]
        getitem_731 = native_batch_norm_backward_default_38[1]
        getitem_732 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        slice_tensor_75 = torch.ops.aten.slice.Tensor(getitem_730, 1, 0, 168)
        slice_tensor_76 = torch.ops.aten.slice.Tensor(getitem_730, 1, 168, 336);  getitem_730 = None
        convolution_backward_default_112 = torch.ops.aten.convolution_backward.default(slice_tensor_76, getitem_87, primals_46, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  slice_tensor_76 = getitem_87 = primals_46 = None
        getitem_733 = convolution_backward_default_112[0]
        getitem_734 = convolution_backward_default_112[1]
        getitem_735 = convolution_backward_default_112[2];  convolution_backward_default_112 = None
        convolution_backward_default_113 = torch.ops.aten.convolution_backward.default(slice_tensor_75, getitem_86, primals_45, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  slice_tensor_75 = getitem_86 = primals_45 = None
        getitem_736 = convolution_backward_default_113[0]
        getitem_737 = convolution_backward_default_113[1]
        getitem_738 = convolution_backward_default_113[2];  convolution_backward_default_113 = None
        cat_default_68 = torch.ops.aten.cat.default([getitem_736, getitem_733], 1);  getitem_736 = getitem_733 = None
        to_dtype_156 = torch.ops.aten.to.dtype(cat_default_68, torch.float32);  cat_default_68 = None
        to_dtype_157 = torch.ops.aten.to.dtype(clone_default_9, torch.float32);  clone_default_9 = None
        neg_default_38 = torch.ops.aten.neg.default(to_dtype_157)
        exp_default_38 = torch.ops.aten.exp.default(neg_default_38);  neg_default_38 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(exp_default_38, 1);  exp_default_38 = None
        reciprocal_default_38 = torch.ops.aten.reciprocal.default(add_tensor_170);  add_tensor_170 = None
        mul_tensor_220 = torch.ops.aten.mul.Tensor(reciprocal_default_38, 1);  reciprocal_default_38 = None
        mul_tensor_221 = torch.ops.aten.mul.Tensor(to_dtype_156, mul_tensor_220);  to_dtype_156 = None
        rsub_scalar_51 = torch.ops.aten.rsub.Scalar(mul_tensor_220, 1);  mul_tensor_220 = None
        mul_tensor_222 = torch.ops.aten.mul.Tensor(to_dtype_157, rsub_scalar_51);  to_dtype_157 = rsub_scalar_51 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(mul_tensor_222, 1);  mul_tensor_222 = None
        mul_tensor_223 = torch.ops.aten.mul.Tensor(mul_tensor_221, add_tensor_171);  mul_tensor_221 = add_tensor_171 = None
        to_dtype_158 = torch.ops.aten.to.dtype(mul_tensor_223, torch.float32);  mul_tensor_223 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, cat_default_12, primals_284, primals_282, primals_283, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  to_dtype_158 = cat_default_12 = primals_284 = primals_282 = primals_283 = getitem_84 = getitem_85 = None
        getitem_739 = native_batch_norm_backward_default_39[0]
        getitem_740 = native_batch_norm_backward_default_39[1]
        getitem_741 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        slice_tensor_77 = torch.ops.aten.slice.Tensor(getitem_739, 1, 0, 168)
        slice_tensor_78 = torch.ops.aten.slice.Tensor(getitem_739, 1, 168, 336);  getitem_739 = None
        convolution_backward_default_114 = torch.ops.aten.convolution_backward.default(slice_tensor_78, getitem_82, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_78 = getitem_82 = primals_48 = None
        getitem_742 = convolution_backward_default_114[0]
        getitem_743 = convolution_backward_default_114[1]
        getitem_744 = convolution_backward_default_114[2];  convolution_backward_default_114 = None
        convolution_backward_default_115 = torch.ops.aten.convolution_backward.default(slice_tensor_77, getitem_81, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_77 = getitem_81 = primals_47 = None
        getitem_745 = convolution_backward_default_115[0]
        getitem_746 = convolution_backward_default_115[1]
        getitem_747 = convolution_backward_default_115[2];  convolution_backward_default_115 = None
        cat_default_69 = torch.ops.aten.cat.default([getitem_745, getitem_742], 1);  getitem_745 = getitem_742 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(getitem_712, cat_default_69);  getitem_712 = cat_default_69 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_172, cat_default_11, primals_279, primals_277, primals_278, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  cat_default_11 = primals_279 = primals_277 = primals_278 = getitem_79 = getitem_80 = None
        getitem_748 = native_batch_norm_backward_default_40[0]
        getitem_749 = native_batch_norm_backward_default_40[1]
        getitem_750 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        slice_tensor_79 = torch.ops.aten.slice.Tensor(getitem_748, 1, 0, 28)
        slice_tensor_80 = torch.ops.aten.slice.Tensor(getitem_748, 1, 28, 56);  getitem_748 = None
        convolution_backward_default_116 = torch.ops.aten.convolution_backward.default(slice_tensor_80, getitem_77, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_80 = getitem_77 = primals_40 = None
        getitem_751 = convolution_backward_default_116[0]
        getitem_752 = convolution_backward_default_116[1]
        getitem_753 = convolution_backward_default_116[2];  convolution_backward_default_116 = None
        convolution_backward_default_117 = torch.ops.aten.convolution_backward.default(slice_tensor_79, getitem_76, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_79 = getitem_76 = primals_39 = None
        getitem_754 = convolution_backward_default_117[0]
        getitem_755 = convolution_backward_default_117[1]
        getitem_756 = convolution_backward_default_117[2];  convolution_backward_default_117 = None
        cat_default_70 = torch.ops.aten.cat.default([getitem_754, getitem_751], 1);  getitem_754 = getitem_751 = None
        mul_tensor_224 = torch.ops.aten.mul.Tensor(cat_default_70, silu__default_7);  silu__default_7 = None
        mul_tensor_225 = torch.ops.aten.mul.Tensor(cat_default_70, sigmoid_default_2);  cat_default_70 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(mul_tensor_224, [2, 3], True);  mul_tensor_224 = None
        to_dtype_159 = torch.ops.aten.to.dtype(sum_dim_int_list_14, torch.float32);  sum_dim_int_list_14 = None
        to_dtype_160 = torch.ops.aten.to.dtype(sigmoid_default_2, torch.float32);  sigmoid_default_2 = None
        rsub_scalar_52 = torch.ops.aten.rsub.Scalar(to_dtype_160, 1)
        mul_tensor_226 = torch.ops.aten.mul.Tensor(to_dtype_160, rsub_scalar_52);  to_dtype_160 = rsub_scalar_52 = None
        conj_physical_default_13 = torch.ops.aten.conj_physical.default(mul_tensor_226);  mul_tensor_226 = None
        mul_tensor_227 = torch.ops.aten.mul.Tensor(to_dtype_159, conj_physical_default_13);  to_dtype_159 = conj_physical_default_13 = None
        to_dtype_161 = torch.ops.aten.to.dtype(mul_tensor_227, torch.float32);  mul_tensor_227 = None
        convolution_backward_default_118 = torch.ops.aten.convolution_backward.default(to_dtype_161, silu__default_8, primals_42, [336], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_161 = silu__default_8 = primals_42 = None
        getitem_757 = convolution_backward_default_118[0]
        getitem_758 = convolution_backward_default_118[1]
        getitem_759 = convolution_backward_default_118[2];  convolution_backward_default_118 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_757, torch.float32);  getitem_757 = None
        to_dtype_163 = torch.ops.aten.to.dtype(clone_default_8, torch.float32);  clone_default_8 = None
        neg_default_39 = torch.ops.aten.neg.default(to_dtype_163)
        exp_default_39 = torch.ops.aten.exp.default(neg_default_39);  neg_default_39 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(exp_default_39, 1);  exp_default_39 = None
        reciprocal_default_39 = torch.ops.aten.reciprocal.default(add_tensor_173);  add_tensor_173 = None
        mul_tensor_228 = torch.ops.aten.mul.Tensor(reciprocal_default_39, 1);  reciprocal_default_39 = None
        mul_tensor_229 = torch.ops.aten.mul.Tensor(to_dtype_162, mul_tensor_228);  to_dtype_162 = None
        rsub_scalar_53 = torch.ops.aten.rsub.Scalar(mul_tensor_228, 1);  mul_tensor_228 = None
        mul_tensor_230 = torch.ops.aten.mul.Tensor(to_dtype_163, rsub_scalar_53);  to_dtype_163 = rsub_scalar_53 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(mul_tensor_230, 1);  mul_tensor_230 = None
        mul_tensor_231 = torch.ops.aten.mul.Tensor(mul_tensor_229, add_tensor_174);  mul_tensor_229 = add_tensor_174 = None
        to_dtype_164 = torch.ops.aten.to.dtype(mul_tensor_231, torch.float32);  mul_tensor_231 = None
        convolution_backward_default_119 = torch.ops.aten.convolution_backward.default(to_dtype_164, mean_dim_2, primals_44, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_164 = mean_dim_2 = primals_44 = None
        getitem_760 = convolution_backward_default_119[0]
        getitem_761 = convolution_backward_default_119[1]
        getitem_762 = convolution_backward_default_119[2];  convolution_backward_default_119 = None
        expand_default_14 = torch.ops.aten.expand.default(getitem_760, [128, 336, 28, 28]);  getitem_760 = None
        div_scalar_14 = torch.ops.aten.div.Scalar(expand_default_14, 784);  expand_default_14 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(mul_tensor_225, div_scalar_14);  mul_tensor_225 = div_scalar_14 = None
        to_dtype_165 = torch.ops.aten.to.dtype(add_tensor_175, torch.float32);  add_tensor_175 = None
        to_dtype_166 = torch.ops.aten.to.dtype(clone_default_7, torch.float32);  clone_default_7 = None
        neg_default_40 = torch.ops.aten.neg.default(to_dtype_166)
        exp_default_40 = torch.ops.aten.exp.default(neg_default_40);  neg_default_40 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(exp_default_40, 1);  exp_default_40 = None
        reciprocal_default_40 = torch.ops.aten.reciprocal.default(add_tensor_176);  add_tensor_176 = None
        mul_tensor_232 = torch.ops.aten.mul.Tensor(reciprocal_default_40, 1);  reciprocal_default_40 = None
        mul_tensor_233 = torch.ops.aten.mul.Tensor(to_dtype_165, mul_tensor_232);  to_dtype_165 = None
        rsub_scalar_54 = torch.ops.aten.rsub.Scalar(mul_tensor_232, 1);  mul_tensor_232 = None
        mul_tensor_234 = torch.ops.aten.mul.Tensor(to_dtype_166, rsub_scalar_54);  to_dtype_166 = rsub_scalar_54 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(mul_tensor_234, 1);  mul_tensor_234 = None
        mul_tensor_235 = torch.ops.aten.mul.Tensor(mul_tensor_233, add_tensor_177);  mul_tensor_233 = add_tensor_177 = None
        to_dtype_167 = torch.ops.aten.to.dtype(mul_tensor_235, torch.float32);  mul_tensor_235 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, cat_default_10, primals_274, primals_272, primals_273, getitem_74, getitem_75, True, 1e-05, [True, True, True]);  to_dtype_167 = cat_default_10 = primals_274 = primals_272 = primals_273 = getitem_74 = getitem_75 = None
        getitem_763 = native_batch_norm_backward_default_41[0]
        getitem_764 = native_batch_norm_backward_default_41[1]
        getitem_765 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        slice_tensor_81 = torch.ops.aten.slice.Tensor(getitem_763, 1, 0, 168)
        slice_tensor_82 = torch.ops.aten.slice.Tensor(getitem_763, 1, 168, 336);  getitem_763 = None
        convolution_backward_default_120 = torch.ops.aten.convolution_backward.default(slice_tensor_82, getitem_72, primals_36, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  slice_tensor_82 = getitem_72 = primals_36 = None
        getitem_766 = convolution_backward_default_120[0]
        getitem_767 = convolution_backward_default_120[1]
        getitem_768 = convolution_backward_default_120[2];  convolution_backward_default_120 = None
        convolution_backward_default_121 = torch.ops.aten.convolution_backward.default(slice_tensor_81, getitem_71, primals_35, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  slice_tensor_81 = getitem_71 = primals_35 = None
        getitem_769 = convolution_backward_default_121[0]
        getitem_770 = convolution_backward_default_121[1]
        getitem_771 = convolution_backward_default_121[2];  convolution_backward_default_121 = None
        cat_default_71 = torch.ops.aten.cat.default([getitem_769, getitem_766], 1);  getitem_769 = getitem_766 = None
        to_dtype_168 = torch.ops.aten.to.dtype(cat_default_71, torch.float32);  cat_default_71 = None
        to_dtype_169 = torch.ops.aten.to.dtype(clone_default_6, torch.float32);  clone_default_6 = None
        neg_default_41 = torch.ops.aten.neg.default(to_dtype_169)
        exp_default_41 = torch.ops.aten.exp.default(neg_default_41);  neg_default_41 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(exp_default_41, 1);  exp_default_41 = None
        reciprocal_default_41 = torch.ops.aten.reciprocal.default(add_tensor_178);  add_tensor_178 = None
        mul_tensor_236 = torch.ops.aten.mul.Tensor(reciprocal_default_41, 1);  reciprocal_default_41 = None
        mul_tensor_237 = torch.ops.aten.mul.Tensor(to_dtype_168, mul_tensor_236);  to_dtype_168 = None
        rsub_scalar_55 = torch.ops.aten.rsub.Scalar(mul_tensor_236, 1);  mul_tensor_236 = None
        mul_tensor_238 = torch.ops.aten.mul.Tensor(to_dtype_169, rsub_scalar_55);  to_dtype_169 = rsub_scalar_55 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(mul_tensor_238, 1);  mul_tensor_238 = None
        mul_tensor_239 = torch.ops.aten.mul.Tensor(mul_tensor_237, add_tensor_179);  mul_tensor_237 = add_tensor_179 = None
        to_dtype_170 = torch.ops.aten.to.dtype(mul_tensor_239, torch.float32);  mul_tensor_239 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, cat_default_9, primals_269, primals_267, primals_268, getitem_69, getitem_70, True, 1e-05, [True, True, True]);  to_dtype_170 = cat_default_9 = primals_269 = primals_267 = primals_268 = getitem_69 = getitem_70 = None
        getitem_772 = native_batch_norm_backward_default_42[0]
        getitem_773 = native_batch_norm_backward_default_42[1]
        getitem_774 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        slice_tensor_83 = torch.ops.aten.slice.Tensor(getitem_772, 1, 0, 168)
        slice_tensor_84 = torch.ops.aten.slice.Tensor(getitem_772, 1, 168, 336);  getitem_772 = None
        convolution_backward_default_122 = torch.ops.aten.convolution_backward.default(slice_tensor_84, getitem_67, primals_38, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_84 = getitem_67 = primals_38 = None
        getitem_775 = convolution_backward_default_122[0]
        getitem_776 = convolution_backward_default_122[1]
        getitem_777 = convolution_backward_default_122[2];  convolution_backward_default_122 = None
        convolution_backward_default_123 = torch.ops.aten.convolution_backward.default(slice_tensor_83, getitem_66, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_83 = getitem_66 = primals_37 = None
        getitem_778 = convolution_backward_default_123[0]
        getitem_779 = convolution_backward_default_123[1]
        getitem_780 = convolution_backward_default_123[2];  convolution_backward_default_123 = None
        cat_default_72 = torch.ops.aten.cat.default([getitem_778, getitem_775], 1);  getitem_778 = getitem_775 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(add_tensor_172, cat_default_72);  add_tensor_172 = cat_default_72 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_180, cat_default_8, primals_264, primals_262, primals_263, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  cat_default_8 = primals_264 = primals_262 = primals_263 = getitem_64 = getitem_65 = None
        getitem_781 = native_batch_norm_backward_default_43[0]
        getitem_782 = native_batch_norm_backward_default_43[1]
        getitem_783 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        slice_tensor_85 = torch.ops.aten.slice.Tensor(getitem_781, 1, 0, 28)
        slice_tensor_86 = torch.ops.aten.slice.Tensor(getitem_781, 1, 28, 56);  getitem_781 = None
        convolution_backward_default_124 = torch.ops.aten.convolution_backward.default(slice_tensor_86, getitem_62, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_86 = getitem_62 = primals_30 = None
        getitem_784 = convolution_backward_default_124[0]
        getitem_785 = convolution_backward_default_124[1]
        getitem_786 = convolution_backward_default_124[2];  convolution_backward_default_124 = None
        convolution_backward_default_125 = torch.ops.aten.convolution_backward.default(slice_tensor_85, getitem_61, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_85 = getitem_61 = primals_29 = None
        getitem_787 = convolution_backward_default_125[0]
        getitem_788 = convolution_backward_default_125[1]
        getitem_789 = convolution_backward_default_125[2];  convolution_backward_default_125 = None
        cat_default_73 = torch.ops.aten.cat.default([getitem_787, getitem_784], 1);  getitem_787 = getitem_784 = None
        mul_tensor_240 = torch.ops.aten.mul.Tensor(cat_default_73, silu__default_4);  silu__default_4 = None
        mul_tensor_241 = torch.ops.aten.mul.Tensor(cat_default_73, sigmoid_default_1);  cat_default_73 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(mul_tensor_240, [2, 3], True);  mul_tensor_240 = None
        to_dtype_171 = torch.ops.aten.to.dtype(sum_dim_int_list_15, torch.float32);  sum_dim_int_list_15 = None
        to_dtype_172 = torch.ops.aten.to.dtype(sigmoid_default_1, torch.float32);  sigmoid_default_1 = None
        rsub_scalar_56 = torch.ops.aten.rsub.Scalar(to_dtype_172, 1)
        mul_tensor_242 = torch.ops.aten.mul.Tensor(to_dtype_172, rsub_scalar_56);  to_dtype_172 = rsub_scalar_56 = None
        conj_physical_default_14 = torch.ops.aten.conj_physical.default(mul_tensor_242);  mul_tensor_242 = None
        mul_tensor_243 = torch.ops.aten.mul.Tensor(to_dtype_171, conj_physical_default_14);  to_dtype_171 = conj_physical_default_14 = None
        to_dtype_173 = torch.ops.aten.to.dtype(mul_tensor_243, torch.float32);  mul_tensor_243 = None
        convolution_backward_default_126 = torch.ops.aten.convolution_backward.default(to_dtype_173, silu__default_5, primals_32, [336], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_173 = silu__default_5 = primals_32 = None
        getitem_790 = convolution_backward_default_126[0]
        getitem_791 = convolution_backward_default_126[1]
        getitem_792 = convolution_backward_default_126[2];  convolution_backward_default_126 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_790, torch.float32);  getitem_790 = None
        to_dtype_175 = torch.ops.aten.to.dtype(clone_default_5, torch.float32);  clone_default_5 = None
        neg_default_42 = torch.ops.aten.neg.default(to_dtype_175)
        exp_default_42 = torch.ops.aten.exp.default(neg_default_42);  neg_default_42 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(exp_default_42, 1);  exp_default_42 = None
        reciprocal_default_42 = torch.ops.aten.reciprocal.default(add_tensor_181);  add_tensor_181 = None
        mul_tensor_244 = torch.ops.aten.mul.Tensor(reciprocal_default_42, 1);  reciprocal_default_42 = None
        mul_tensor_245 = torch.ops.aten.mul.Tensor(to_dtype_174, mul_tensor_244);  to_dtype_174 = None
        rsub_scalar_57 = torch.ops.aten.rsub.Scalar(mul_tensor_244, 1);  mul_tensor_244 = None
        mul_tensor_246 = torch.ops.aten.mul.Tensor(to_dtype_175, rsub_scalar_57);  to_dtype_175 = rsub_scalar_57 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(mul_tensor_246, 1);  mul_tensor_246 = None
        mul_tensor_247 = torch.ops.aten.mul.Tensor(mul_tensor_245, add_tensor_182);  mul_tensor_245 = add_tensor_182 = None
        to_dtype_176 = torch.ops.aten.to.dtype(mul_tensor_247, torch.float32);  mul_tensor_247 = None
        convolution_backward_default_127 = torch.ops.aten.convolution_backward.default(to_dtype_176, mean_dim_1, primals_34, [28], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_176 = mean_dim_1 = primals_34 = None
        getitem_793 = convolution_backward_default_127[0]
        getitem_794 = convolution_backward_default_127[1]
        getitem_795 = convolution_backward_default_127[2];  convolution_backward_default_127 = None
        expand_default_15 = torch.ops.aten.expand.default(getitem_793, [128, 336, 28, 28]);  getitem_793 = None
        div_scalar_15 = torch.ops.aten.div.Scalar(expand_default_15, 784);  expand_default_15 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(mul_tensor_241, div_scalar_15);  mul_tensor_241 = div_scalar_15 = None
        to_dtype_177 = torch.ops.aten.to.dtype(add_tensor_183, torch.float32);  add_tensor_183 = None
        to_dtype_178 = torch.ops.aten.to.dtype(clone_default_4, torch.float32);  clone_default_4 = None
        neg_default_43 = torch.ops.aten.neg.default(to_dtype_178)
        exp_default_43 = torch.ops.aten.exp.default(neg_default_43);  neg_default_43 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(exp_default_43, 1);  exp_default_43 = None
        reciprocal_default_43 = torch.ops.aten.reciprocal.default(add_tensor_184);  add_tensor_184 = None
        mul_tensor_248 = torch.ops.aten.mul.Tensor(reciprocal_default_43, 1);  reciprocal_default_43 = None
        mul_tensor_249 = torch.ops.aten.mul.Tensor(to_dtype_177, mul_tensor_248);  to_dtype_177 = None
        rsub_scalar_58 = torch.ops.aten.rsub.Scalar(mul_tensor_248, 1);  mul_tensor_248 = None
        mul_tensor_250 = torch.ops.aten.mul.Tensor(to_dtype_178, rsub_scalar_58);  to_dtype_178 = rsub_scalar_58 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(mul_tensor_250, 1);  mul_tensor_250 = None
        mul_tensor_251 = torch.ops.aten.mul.Tensor(mul_tensor_249, add_tensor_185);  mul_tensor_249 = add_tensor_185 = None
        to_dtype_179 = torch.ops.aten.to.dtype(mul_tensor_251, torch.float32);  mul_tensor_251 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, cat_default_7, primals_259, primals_257, primals_258, getitem_59, getitem_60, True, 1e-05, [True, True, True]);  to_dtype_179 = cat_default_7 = primals_259 = primals_257 = primals_258 = getitem_59 = getitem_60 = None
        getitem_796 = native_batch_norm_backward_default_44[0]
        getitem_797 = native_batch_norm_backward_default_44[1]
        getitem_798 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        slice_tensor_87 = torch.ops.aten.slice.Tensor(getitem_796, 1, 0, 168)
        slice_tensor_88 = torch.ops.aten.slice.Tensor(getitem_796, 1, 168, 336);  getitem_796 = None
        convolution_backward_default_128 = torch.ops.aten.convolution_backward.default(slice_tensor_88, getitem_57, primals_26, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 168, [True, True, False]);  slice_tensor_88 = getitem_57 = primals_26 = None
        getitem_799 = convolution_backward_default_128[0]
        getitem_800 = convolution_backward_default_128[1]
        getitem_801 = convolution_backward_default_128[2];  convolution_backward_default_128 = None
        convolution_backward_default_129 = torch.ops.aten.convolution_backward.default(slice_tensor_87, getitem_56, primals_25, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 168, [True, True, False]);  slice_tensor_87 = getitem_56 = primals_25 = None
        getitem_802 = convolution_backward_default_129[0]
        getitem_803 = convolution_backward_default_129[1]
        getitem_804 = convolution_backward_default_129[2];  convolution_backward_default_129 = None
        cat_default_74 = torch.ops.aten.cat.default([getitem_802, getitem_799], 1);  getitem_802 = getitem_799 = None
        to_dtype_180 = torch.ops.aten.to.dtype(cat_default_74, torch.float32);  cat_default_74 = None
        to_dtype_181 = torch.ops.aten.to.dtype(clone_default_3, torch.float32);  clone_default_3 = None
        neg_default_44 = torch.ops.aten.neg.default(to_dtype_181)
        exp_default_44 = torch.ops.aten.exp.default(neg_default_44);  neg_default_44 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(exp_default_44, 1);  exp_default_44 = None
        reciprocal_default_44 = torch.ops.aten.reciprocal.default(add_tensor_186);  add_tensor_186 = None
        mul_tensor_252 = torch.ops.aten.mul.Tensor(reciprocal_default_44, 1);  reciprocal_default_44 = None
        mul_tensor_253 = torch.ops.aten.mul.Tensor(to_dtype_180, mul_tensor_252);  to_dtype_180 = None
        rsub_scalar_59 = torch.ops.aten.rsub.Scalar(mul_tensor_252, 1);  mul_tensor_252 = None
        mul_tensor_254 = torch.ops.aten.mul.Tensor(to_dtype_181, rsub_scalar_59);  to_dtype_181 = rsub_scalar_59 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(mul_tensor_254, 1);  mul_tensor_254 = None
        mul_tensor_255 = torch.ops.aten.mul.Tensor(mul_tensor_253, add_tensor_187);  mul_tensor_253 = add_tensor_187 = None
        to_dtype_182 = torch.ops.aten.to.dtype(mul_tensor_255, torch.float32);  mul_tensor_255 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, cat_default_6, primals_254, primals_252, primals_253, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_182 = cat_default_6 = primals_254 = primals_252 = primals_253 = getitem_54 = getitem_55 = None
        getitem_805 = native_batch_norm_backward_default_45[0]
        getitem_806 = native_batch_norm_backward_default_45[1]
        getitem_807 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        slice_tensor_89 = torch.ops.aten.slice.Tensor(getitem_805, 1, 0, 168)
        slice_tensor_90 = torch.ops.aten.slice.Tensor(getitem_805, 1, 168, 336);  getitem_805 = None
        convolution_backward_default_130 = torch.ops.aten.convolution_backward.default(slice_tensor_90, getitem_52, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_90 = getitem_52 = primals_28 = None
        getitem_808 = convolution_backward_default_130[0]
        getitem_809 = convolution_backward_default_130[1]
        getitem_810 = convolution_backward_default_130[2];  convolution_backward_default_130 = None
        convolution_backward_default_131 = torch.ops.aten.convolution_backward.default(slice_tensor_89, getitem_51, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_89 = getitem_51 = primals_27 = None
        getitem_811 = convolution_backward_default_131[0]
        getitem_812 = convolution_backward_default_131[1]
        getitem_813 = convolution_backward_default_131[2];  convolution_backward_default_131 = None
        cat_default_75 = torch.ops.aten.cat.default([getitem_811, getitem_808], 1);  getitem_811 = getitem_808 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(add_tensor_180, cat_default_75);  add_tensor_180 = cat_default_75 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_188, convolution_default_22, primals_249, primals_247, primals_248, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  add_tensor_188 = convolution_default_22 = primals_249 = primals_247 = primals_248 = getitem_49 = getitem_50 = None
        getitem_814 = native_batch_norm_backward_default_46[0]
        getitem_815 = native_batch_norm_backward_default_46[1]
        getitem_816 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_132 = torch.ops.aten.convolution_backward.default(getitem_814, mul_tensor, primals_20, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_814 = mul_tensor = primals_20 = None
        getitem_817 = convolution_backward_default_132[0]
        getitem_818 = convolution_backward_default_132[1]
        getitem_819 = convolution_backward_default_132[2];  convolution_backward_default_132 = None
        mul_tensor_256 = torch.ops.aten.mul.Tensor(getitem_817, silu__default_1);  silu__default_1 = None
        mul_tensor_257 = torch.ops.aten.mul.Tensor(getitem_817, sigmoid_default);  getitem_817 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(mul_tensor_256, [2, 3], True);  mul_tensor_256 = None
        to_dtype_183 = torch.ops.aten.to.dtype(sum_dim_int_list_16, torch.float32);  sum_dim_int_list_16 = None
        to_dtype_184 = torch.ops.aten.to.dtype(sigmoid_default, torch.float32);  sigmoid_default = None
        rsub_scalar_60 = torch.ops.aten.rsub.Scalar(to_dtype_184, 1)
        mul_tensor_258 = torch.ops.aten.mul.Tensor(to_dtype_184, rsub_scalar_60);  to_dtype_184 = rsub_scalar_60 = None
        conj_physical_default_15 = torch.ops.aten.conj_physical.default(mul_tensor_258);  mul_tensor_258 = None
        mul_tensor_259 = torch.ops.aten.mul.Tensor(to_dtype_183, conj_physical_default_15);  to_dtype_183 = conj_physical_default_15 = None
        to_dtype_185 = torch.ops.aten.to.dtype(mul_tensor_259, torch.float32);  mul_tensor_259 = None
        convolution_backward_default_133 = torch.ops.aten.convolution_backward.default(to_dtype_185, silu__default_2, primals_22, [240], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_185 = silu__default_2 = primals_22 = None
        getitem_820 = convolution_backward_default_133[0]
        getitem_821 = convolution_backward_default_133[1]
        getitem_822 = convolution_backward_default_133[2];  convolution_backward_default_133 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_820, torch.float32);  getitem_820 = None
        to_dtype_187 = torch.ops.aten.to.dtype(clone_default_2, torch.float32);  clone_default_2 = None
        neg_default_45 = torch.ops.aten.neg.default(to_dtype_187)
        exp_default_45 = torch.ops.aten.exp.default(neg_default_45);  neg_default_45 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(exp_default_45, 1);  exp_default_45 = None
        reciprocal_default_45 = torch.ops.aten.reciprocal.default(add_tensor_189);  add_tensor_189 = None
        mul_tensor_260 = torch.ops.aten.mul.Tensor(reciprocal_default_45, 1);  reciprocal_default_45 = None
        mul_tensor_261 = torch.ops.aten.mul.Tensor(to_dtype_186, mul_tensor_260);  to_dtype_186 = None
        rsub_scalar_61 = torch.ops.aten.rsub.Scalar(mul_tensor_260, 1);  mul_tensor_260 = None
        mul_tensor_262 = torch.ops.aten.mul.Tensor(to_dtype_187, rsub_scalar_61);  to_dtype_187 = rsub_scalar_61 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(mul_tensor_262, 1);  mul_tensor_262 = None
        mul_tensor_263 = torch.ops.aten.mul.Tensor(mul_tensor_261, add_tensor_190);  mul_tensor_261 = add_tensor_190 = None
        to_dtype_188 = torch.ops.aten.to.dtype(mul_tensor_263, torch.float32);  mul_tensor_263 = None
        convolution_backward_default_134 = torch.ops.aten.convolution_backward.default(to_dtype_188, mean_dim, primals_24, [20], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  to_dtype_188 = mean_dim = primals_24 = None
        getitem_823 = convolution_backward_default_134[0]
        getitem_824 = convolution_backward_default_134[1]
        getitem_825 = convolution_backward_default_134[2];  convolution_backward_default_134 = None
        expand_default_16 = torch.ops.aten.expand.default(getitem_823, [128, 240, 28, 28]);  getitem_823 = None
        div_scalar_16 = torch.ops.aten.div.Scalar(expand_default_16, 784);  expand_default_16 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(mul_tensor_257, div_scalar_16);  mul_tensor_257 = div_scalar_16 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_191, torch.float32);  add_tensor_191 = None
        to_dtype_190 = torch.ops.aten.to.dtype(clone_default_1, torch.float32);  clone_default_1 = None
        neg_default_46 = torch.ops.aten.neg.default(to_dtype_190)
        exp_default_46 = torch.ops.aten.exp.default(neg_default_46);  neg_default_46 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(exp_default_46, 1);  exp_default_46 = None
        reciprocal_default_46 = torch.ops.aten.reciprocal.default(add_tensor_192);  add_tensor_192 = None
        mul_tensor_264 = torch.ops.aten.mul.Tensor(reciprocal_default_46, 1);  reciprocal_default_46 = None
        mul_tensor_265 = torch.ops.aten.mul.Tensor(to_dtype_189, mul_tensor_264);  to_dtype_189 = None
        rsub_scalar_62 = torch.ops.aten.rsub.Scalar(mul_tensor_264, 1);  mul_tensor_264 = None
        mul_tensor_266 = torch.ops.aten.mul.Tensor(to_dtype_190, rsub_scalar_62);  to_dtype_190 = rsub_scalar_62 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(mul_tensor_266, 1);  mul_tensor_266 = None
        mul_tensor_267 = torch.ops.aten.mul.Tensor(mul_tensor_265, add_tensor_193);  mul_tensor_265 = add_tensor_193 = None
        to_dtype_191 = torch.ops.aten.to.dtype(mul_tensor_267, torch.float32);  mul_tensor_267 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, cat_default_5, primals_244, primals_242, primals_243, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  to_dtype_191 = cat_default_5 = primals_244 = primals_242 = primals_243 = getitem_46 = getitem_47 = None
        getitem_826 = native_batch_norm_backward_default_47[0]
        getitem_827 = native_batch_norm_backward_default_47[1]
        getitem_828 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        slice_tensor_91 = torch.ops.aten.slice.Tensor(getitem_826, 1, 0, 60)
        slice_tensor_92 = torch.ops.aten.slice.Tensor(getitem_826, 1, 60, 120)
        slice_tensor_93 = torch.ops.aten.slice.Tensor(getitem_826, 1, 120, 180)
        slice_tensor_94 = torch.ops.aten.slice.Tensor(getitem_826, 1, 180, 240);  getitem_826 = None
        convolution_backward_default_135 = torch.ops.aten.convolution_backward.default(slice_tensor_94, getitem_44, primals_18, [0], [2, 2], [4, 4], [1, 1], False, [0, 0], 60, [True, True, False]);  slice_tensor_94 = getitem_44 = primals_18 = None
        getitem_829 = convolution_backward_default_135[0]
        getitem_830 = convolution_backward_default_135[1]
        getitem_831 = convolution_backward_default_135[2];  convolution_backward_default_135 = None
        convolution_backward_default_136 = torch.ops.aten.convolution_backward.default(slice_tensor_93, getitem_43, primals_17, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 60, [True, True, False]);  slice_tensor_93 = getitem_43 = primals_17 = None
        getitem_832 = convolution_backward_default_136[0]
        getitem_833 = convolution_backward_default_136[1]
        getitem_834 = convolution_backward_default_136[2];  convolution_backward_default_136 = None
        convolution_backward_default_137 = torch.ops.aten.convolution_backward.default(slice_tensor_92, getitem_42, primals_16, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 60, [True, True, False]);  slice_tensor_92 = getitem_42 = primals_16 = None
        getitem_835 = convolution_backward_default_137[0]
        getitem_836 = convolution_backward_default_137[1]
        getitem_837 = convolution_backward_default_137[2];  convolution_backward_default_137 = None
        convolution_backward_default_138 = torch.ops.aten.convolution_backward.default(slice_tensor_91, getitem_41, primals_15, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 60, [True, True, False]);  slice_tensor_91 = getitem_41 = primals_15 = None
        getitem_838 = convolution_backward_default_138[0]
        getitem_839 = convolution_backward_default_138[1]
        getitem_840 = convolution_backward_default_138[2];  convolution_backward_default_138 = None
        cat_default_76 = torch.ops.aten.cat.default([getitem_838, getitem_835, getitem_832, getitem_829], 1);  getitem_838 = getitem_835 = getitem_832 = getitem_829 = None
        to_dtype_192 = torch.ops.aten.to.dtype(cat_default_76, torch.float32);  cat_default_76 = None
        to_dtype_193 = torch.ops.aten.to.dtype(clone_default, torch.float32);  clone_default = None
        neg_default_47 = torch.ops.aten.neg.default(to_dtype_193)
        exp_default_47 = torch.ops.aten.exp.default(neg_default_47);  neg_default_47 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(exp_default_47, 1);  exp_default_47 = None
        reciprocal_default_47 = torch.ops.aten.reciprocal.default(add_tensor_194);  add_tensor_194 = None
        mul_tensor_268 = torch.ops.aten.mul.Tensor(reciprocal_default_47, 1);  reciprocal_default_47 = None
        mul_tensor_269 = torch.ops.aten.mul.Tensor(to_dtype_192, mul_tensor_268);  to_dtype_192 = None
        rsub_scalar_63 = torch.ops.aten.rsub.Scalar(mul_tensor_268, 1);  mul_tensor_268 = None
        mul_tensor_270 = torch.ops.aten.mul.Tensor(to_dtype_193, rsub_scalar_63);  to_dtype_193 = rsub_scalar_63 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(mul_tensor_270, 1);  mul_tensor_270 = None
        mul_tensor_271 = torch.ops.aten.mul.Tensor(mul_tensor_269, add_tensor_195);  mul_tensor_269 = add_tensor_195 = None
        to_dtype_194 = torch.ops.aten.to.dtype(mul_tensor_271, torch.float32);  mul_tensor_271 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_15, primals_239, primals_237, primals_238, getitem_39, getitem_40, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default_15 = primals_239 = primals_237 = primals_238 = getitem_39 = getitem_40 = None
        getitem_841 = native_batch_norm_backward_default_48[0]
        getitem_842 = native_batch_norm_backward_default_48[1]
        getitem_843 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_139 = torch.ops.aten.convolution_backward.default(getitem_841, add_tensor_10, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_841 = add_tensor_10 = primals_19 = None
        getitem_844 = convolution_backward_default_139[0]
        getitem_845 = convolution_backward_default_139[1]
        getitem_846 = convolution_backward_default_139[2];  convolution_backward_default_139 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(getitem_844, cat_default_4, primals_234, primals_232, primals_233, getitem_36, getitem_37, True, 1e-05, [True, True, True]);  cat_default_4 = primals_234 = primals_232 = primals_233 = getitem_36 = getitem_37 = None
        getitem_847 = native_batch_norm_backward_default_49[0]
        getitem_848 = native_batch_norm_backward_default_49[1]
        getitem_849 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        slice_tensor_95 = torch.ops.aten.slice.Tensor(getitem_847, 1, 0, 20)
        slice_tensor_96 = torch.ops.aten.slice.Tensor(getitem_847, 1, 20, 40);  getitem_847 = None
        convolution_backward_default_140 = torch.ops.aten.convolution_backward.default(slice_tensor_96, getitem_34, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_96 = getitem_34 = primals_14 = None
        getitem_850 = convolution_backward_default_140[0]
        getitem_851 = convolution_backward_default_140[1]
        getitem_852 = convolution_backward_default_140[2];  convolution_backward_default_140 = None
        convolution_backward_default_141 = torch.ops.aten.convolution_backward.default(slice_tensor_95, getitem_33, primals_13, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_95 = getitem_33 = primals_13 = None
        getitem_853 = convolution_backward_default_141[0]
        getitem_854 = convolution_backward_default_141[1]
        getitem_855 = convolution_backward_default_141[2];  convolution_backward_default_141 = None
        cat_default_77 = torch.ops.aten.cat.default([getitem_853, getitem_850], 1);  getitem_853 = getitem_850 = None
        to_dtype_195 = torch.ops.aten.to.dtype(cat_default_77, torch.float32);  cat_default_77 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_59, to_dtype_195);  le_scalar_1 = new_zeros_default_59 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_12, primals_229, primals_227, primals_228, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  to_dtype_197 = convolution_default_12 = primals_229 = primals_227 = primals_228 = getitem_31 = getitem_32 = None
        getitem_856 = native_batch_norm_backward_default_50[0]
        getitem_857 = native_batch_norm_backward_default_50[1]
        getitem_858 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_142 = torch.ops.aten.convolution_backward.default(getitem_856, relu__default_4, primals_10, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 120, [True, True, False]);  getitem_856 = primals_10 = None
        getitem_859 = convolution_backward_default_142[0]
        getitem_860 = convolution_backward_default_142[1]
        getitem_861 = convolution_backward_default_142[2];  convolution_backward_default_142 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_859, torch.float32);  getitem_859 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_60, to_dtype_198);  le_scalar_2 = new_zeros_default_60 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, cat_default_3, primals_224, primals_222, primals_223, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  to_dtype_200 = cat_default_3 = primals_224 = primals_222 = primals_223 = getitem_28 = getitem_29 = None
        getitem_862 = native_batch_norm_backward_default_51[0]
        getitem_863 = native_batch_norm_backward_default_51[1]
        getitem_864 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        slice_tensor_97 = torch.ops.aten.slice.Tensor(getitem_862, 1, 0, 60)
        slice_tensor_98 = torch.ops.aten.slice.Tensor(getitem_862, 1, 60, 120);  getitem_862 = None
        convolution_backward_default_143 = torch.ops.aten.convolution_backward.default(slice_tensor_98, getitem_26, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_98 = getitem_26 = primals_12 = None
        getitem_865 = convolution_backward_default_143[0]
        getitem_866 = convolution_backward_default_143[1]
        getitem_867 = convolution_backward_default_143[2];  convolution_backward_default_143 = None
        convolution_backward_default_144 = torch.ops.aten.convolution_backward.default(slice_tensor_97, getitem_25, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_97 = getitem_25 = primals_11 = None
        getitem_868 = convolution_backward_default_144[0]
        getitem_869 = convolution_backward_default_144[1]
        getitem_870 = convolution_backward_default_144[2];  convolution_backward_default_144 = None
        cat_default_78 = torch.ops.aten.cat.default([getitem_868, getitem_865], 1);  getitem_868 = getitem_865 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(getitem_844, cat_default_78);  getitem_844 = cat_default_78 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_196, cat_default_2, primals_219, primals_217, primals_218, getitem_23, getitem_24, True, 1e-05, [True, True, True]);  add_tensor_196 = cat_default_2 = primals_219 = primals_217 = primals_218 = getitem_23 = getitem_24 = None
        getitem_871 = native_batch_norm_backward_default_52[0]
        getitem_872 = native_batch_norm_backward_default_52[1]
        getitem_873 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        slice_tensor_99 = torch.ops.aten.slice.Tensor(getitem_871, 1, 0, 20)
        slice_tensor_100 = torch.ops.aten.slice.Tensor(getitem_871, 1, 20, 40);  getitem_871 = None
        convolution_backward_default_145 = torch.ops.aten.convolution_backward.default(slice_tensor_100, getitem_21, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_100 = getitem_21 = primals_9 = None
        getitem_874 = convolution_backward_default_145[0]
        getitem_875 = convolution_backward_default_145[1]
        getitem_876 = convolution_backward_default_145[2];  convolution_backward_default_145 = None
        convolution_backward_default_146 = torch.ops.aten.convolution_backward.default(slice_tensor_99, getitem_20, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_99 = getitem_20 = primals_8 = None
        getitem_877 = convolution_backward_default_146[0]
        getitem_878 = convolution_backward_default_146[1]
        getitem_879 = convolution_backward_default_146[2];  convolution_backward_default_146 = None
        cat_default_79 = torch.ops.aten.cat.default([getitem_877, getitem_874], 1);  getitem_877 = getitem_874 = None
        to_dtype_201 = torch.ops.aten.to.dtype(cat_default_79, torch.float32);  cat_default_79 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_61, to_dtype_201);  le_scalar_3 = new_zeros_default_61 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, cat_default_1, primals_214, primals_212, primals_213, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  to_dtype_203 = cat_default_1 = primals_214 = primals_212 = primals_213 = getitem_18 = getitem_19 = None
        getitem_880 = native_batch_norm_backward_default_53[0]
        getitem_881 = native_batch_norm_backward_default_53[1]
        getitem_882 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        slice_tensor_101 = torch.ops.aten.slice.Tensor(getitem_880, 1, 0, 64)
        slice_tensor_102 = torch.ops.aten.slice.Tensor(getitem_880, 1, 64, 128)
        slice_tensor_103 = torch.ops.aten.slice.Tensor(getitem_880, 1, 128, 192);  getitem_880 = None
        convolution_backward_default_147 = torch.ops.aten.convolution_backward.default(slice_tensor_103, getitem_16, primals_5, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 64, [True, True, False]);  slice_tensor_103 = getitem_16 = primals_5 = None
        getitem_883 = convolution_backward_default_147[0]
        getitem_884 = convolution_backward_default_147[1]
        getitem_885 = convolution_backward_default_147[2];  convolution_backward_default_147 = None
        convolution_backward_default_148 = torch.ops.aten.convolution_backward.default(slice_tensor_102, getitem_15, primals_4, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 64, [True, True, False]);  slice_tensor_102 = getitem_15 = primals_4 = None
        getitem_886 = convolution_backward_default_148[0]
        getitem_887 = convolution_backward_default_148[1]
        getitem_888 = convolution_backward_default_148[2];  convolution_backward_default_148 = None
        convolution_backward_default_149 = torch.ops.aten.convolution_backward.default(slice_tensor_101, getitem_14, primals_3, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 64, [True, True, False]);  slice_tensor_101 = getitem_14 = primals_3 = None
        getitem_889 = convolution_backward_default_149[0]
        getitem_890 = convolution_backward_default_149[1]
        getitem_891 = convolution_backward_default_149[2];  convolution_backward_default_149 = None
        cat_default_80 = torch.ops.aten.cat.default([getitem_889, getitem_886, getitem_883], 1);  getitem_889 = getitem_886 = getitem_883 = None
        to_dtype_204 = torch.ops.aten.to.dtype(cat_default_80, torch.float32);  cat_default_80 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_62, to_dtype_204);  le_scalar_4 = new_zeros_default_62 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, cat_default, primals_209, primals_207, primals_208, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  to_dtype_206 = cat_default = primals_209 = primals_207 = primals_208 = getitem_12 = getitem_13 = None
        getitem_892 = native_batch_norm_backward_default_54[0]
        getitem_893 = native_batch_norm_backward_default_54[1]
        getitem_894 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        slice_tensor_104 = torch.ops.aten.slice.Tensor(getitem_892, 1, 0, 96)
        slice_tensor_105 = torch.ops.aten.slice.Tensor(getitem_892, 1, 96, 192);  getitem_892 = None
        convolution_backward_default_150 = torch.ops.aten.convolution_backward.default(slice_tensor_105, getitem_10, primals_7, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_105 = getitem_10 = primals_7 = None
        getitem_895 = convolution_backward_default_150[0]
        getitem_896 = convolution_backward_default_150[1]
        getitem_897 = convolution_backward_default_150[2];  convolution_backward_default_150 = None
        convolution_backward_default_151 = torch.ops.aten.convolution_backward.default(slice_tensor_104, getitem_9, primals_6, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  slice_tensor_104 = getitem_9 = primals_6 = None
        getitem_898 = convolution_backward_default_151[0]
        getitem_899 = convolution_backward_default_151[1]
        getitem_900 = convolution_backward_default_151[2];  convolution_backward_default_151 = None
        cat_default_81 = torch.ops.aten.cat.default([getitem_898, getitem_895], 1);  getitem_898 = getitem_895 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(cat_default_81, convolution_default_2, primals_204, primals_202, primals_203, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  convolution_default_2 = primals_204 = primals_202 = primals_203 = getitem_7 = getitem_8 = None
        getitem_901 = native_batch_norm_backward_default_55[0]
        getitem_902 = native_batch_norm_backward_default_55[1]
        getitem_903 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_152 = torch.ops.aten.convolution_backward.default(getitem_901, relu__default_1, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_901 = primals_2 = None
        getitem_904 = convolution_backward_default_152[0]
        getitem_905 = convolution_backward_default_152[1]
        getitem_906 = convolution_backward_default_152[2];  convolution_backward_default_152 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_904, torch.float32);  getitem_904 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_63, to_dtype_207);  le_scalar_5 = new_zeros_default_63 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_1, primals_199, primals_197, primals_198, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_1 = primals_199 = primals_197 = primals_198 = getitem_4 = getitem_5 = None
        getitem_907 = native_batch_norm_backward_default_56[0]
        getitem_908 = native_batch_norm_backward_default_56[1]
        getitem_909 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_153 = torch.ops.aten.convolution_backward.default(getitem_907, relu__default, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 32, [True, True, False]);  getitem_907 = primals_1 = None
        getitem_910 = convolution_backward_default_153[0]
        getitem_911 = convolution_backward_default_153[1]
        getitem_912 = convolution_backward_default_153[2];  convolution_backward_default_153 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(cat_default_81, getitem_910);  cat_default_81 = getitem_910 = None
        to_dtype_210 = torch.ops.aten.to.dtype(add_tensor_197, torch.float32);  add_tensor_197 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_64, to_dtype_210);  le_scalar_6 = new_zeros_default_64 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default, primals_194, primals_192, primals_193, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_212 = convolution_default = primals_194 = primals_192 = primals_193 = getitem_1 = getitem_2 = None
        getitem_913 = native_batch_norm_backward_default_57[0]
        getitem_914 = native_batch_norm_backward_default_57[1]
        getitem_915 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_154 = torch.ops.aten.convolution_backward.default(getitem_913, primals_190, primals_189, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_913 = primals_190 = primals_189 = None
        getitem_916 = convolution_backward_default_154[0]
        getitem_917 = convolution_backward_default_154[1]
        getitem_918 = convolution_backward_default_154[2];  convolution_backward_default_154 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_26, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_31, add_tensor_33, add_tensor_34, add_tensor_35, add_tensor_37, add_tensor_38, add_tensor_39, add_tensor_41, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_45, add_tensor_46, add_tensor_48, add_tensor_49, add_tensor_50, add_tensor_52, add_tensor_53, add_tensor_54, add_tensor_56, add_tensor_57, add_tensor_58, add_tensor_59, add_tensor_60, add_tensor_61, add_tensor_63, add_tensor_64, add_tensor_65, add_tensor_67, add_tensor_68, add_tensor_69, add_tensor_71, getitem_911, getitem_905, getitem_890, getitem_887, getitem_884, getitem_899, getitem_896, getitem_878, getitem_875, getitem_860, getitem_869, getitem_866, getitem_854, getitem_851, getitem_839, getitem_836, getitem_833, getitem_830, getitem_845, getitem_818, getitem_822, getitem_821, getitem_825, getitem_824, getitem_803, getitem_800, getitem_812, getitem_809, getitem_788, getitem_785, getitem_792, getitem_791, getitem_795, getitem_794, getitem_770, getitem_767, getitem_779, getitem_776, getitem_755, getitem_752, getitem_759, getitem_758, getitem_762, getitem_761, getitem_737, getitem_734, getitem_746, getitem_743, getitem_722, getitem_719, getitem_726, getitem_725, getitem_729, getitem_728, getitem_707, getitem_704, getitem_701, getitem_713, getitem_689, getitem_693, getitem_692, getitem_696, getitem_695, getitem_674, getitem_671, getitem_668, getitem_665, getitem_683, getitem_680, getitem_653, getitem_650, getitem_657, getitem_656, getitem_660, getitem_659, getitem_635, getitem_632, getitem_629, getitem_626, getitem_644, getitem_641, getitem_614, getitem_611, getitem_618, getitem_617, getitem_621, getitem_620, getitem_596, getitem_593, getitem_590, getitem_587, getitem_605, getitem_602, getitem_575, getitem_572, getitem_579, getitem_578, getitem_582, getitem_581, getitem_560, getitem_566, getitem_548, getitem_552, getitem_551, getitem_555, getitem_554, getitem_533, getitem_530, getitem_527, getitem_524, getitem_542, getitem_539, getitem_512, getitem_509, getitem_516, getitem_515, getitem_519, getitem_518, getitem_494, getitem_491, getitem_488, getitem_485, getitem_503, getitem_500, getitem_473, getitem_470, getitem_477, getitem_476, getitem_480, getitem_479, getitem_455, getitem_452, getitem_449, getitem_446, getitem_464, getitem_461, getitem_434, getitem_431, getitem_438, getitem_437, getitem_441, getitem_440, getitem_419, getitem_416, getitem_413, getitem_410, getitem_425, getitem_398, getitem_402, getitem_401, getitem_405, getitem_404, getitem_386, getitem_383, getitem_380, getitem_377, getitem_392, getitem_365, getitem_362, getitem_369, getitem_368, getitem_372, getitem_371, getitem_350, getitem_347, getitem_344, getitem_341, getitem_356, getitem_329, getitem_326, getitem_333, getitem_332, getitem_336, getitem_335, getitem_314, getitem_311, getitem_308, getitem_305, getitem_320, getitem_293, getitem_290, getitem_297, getitem_296, getitem_300, getitem_299, view_default_1, t_default_4, getitem_284, getitem_917, None, None, None, None, getitem_914, getitem_915, None, None, None, getitem_908, getitem_909, None, None, None, getitem_902, getitem_903, None, None, None, getitem_893, getitem_894, None, None, None, getitem_881, getitem_882, None, None, None, getitem_872, getitem_873, None, None, None, getitem_863, getitem_864, None, None, None, getitem_857, getitem_858, None, None, None, getitem_848, getitem_849, None, None, None, getitem_842, getitem_843, None, None, None, getitem_827, getitem_828, None, None, None, getitem_815, getitem_816, None, None, None, getitem_806, getitem_807, None, None, None, getitem_797, getitem_798, None, None, None, getitem_782, getitem_783, None, None, None, getitem_773, getitem_774, None, None, None, getitem_764, getitem_765, None, None, None, getitem_749, getitem_750, None, None, None, getitem_740, getitem_741, None, None, None, getitem_731, getitem_732, None, None, None, getitem_716, getitem_717, None, None, None, getitem_710, getitem_711, None, None, None, getitem_698, getitem_699, None, None, None, getitem_686, getitem_687, None, None, None, getitem_677, getitem_678, None, None, None, getitem_662, getitem_663, None, None, None, getitem_647, getitem_648, None, None, None, getitem_638, getitem_639, None, None, None, getitem_623, getitem_624, None, None, None, getitem_608, getitem_609, None, None, None, getitem_599, getitem_600, None, None, None, getitem_584, getitem_585, None, None, None, getitem_569, getitem_570, None, None, None, getitem_563, getitem_564, None, None, None, getitem_557, getitem_558, None, None, None, getitem_545, getitem_546, None, None, None, getitem_536, getitem_537, None, None, None, getitem_521, getitem_522, None, None, None, getitem_506, getitem_507, None, None, None, getitem_497, getitem_498, None, None, None, getitem_482, getitem_483, None, None, None, getitem_467, getitem_468, None, None, None, getitem_458, getitem_459, None, None, None, getitem_443, getitem_444, None, None, None, getitem_428, getitem_429, None, None, None, getitem_422, getitem_423, None, None, None, getitem_407, getitem_408, None, None, None, getitem_395, getitem_396, None, None, None, getitem_389, getitem_390, None, None, None, getitem_374, getitem_375, None, None, None, getitem_359, getitem_360, None, None, None, getitem_353, getitem_354, None, None, None, getitem_338, getitem_339, None, None, None, getitem_323, getitem_324, None, None, None, getitem_317, getitem_318, None, None, None, getitem_302, getitem_303, None, None, None, getitem_287, getitem_288, None, None, None, getitem_281, getitem_282]
        
