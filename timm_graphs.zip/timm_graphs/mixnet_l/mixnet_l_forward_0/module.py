
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/mixnet_l/mixnet_l_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480):
        convolution_default = torch.ops.aten.convolution.default(primals_190, primals_189, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_191, 1);  primals_191 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_194, primals_195, primals_192, primals_193, True, 0.1, 1e-05);  primals_195 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 32)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_196, 1);  primals_196 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_199, primals_200, primals_197, primals_198, True, 0.1, 1e-05);  primals_200 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_201, 1);  primals_201 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_204, primals_205, primals_202, primals_203, True, 0.1, 1e-05);  primals_205 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(getitem_6, relu__default);  getitem_6 = None
        split_with_sizes_default = torch.ops.aten.split_with_sizes.default(add_tensor_3, [16, 16], 1);  add_tensor_3 = None
        getitem_9 = split_with_sizes_default[0]
        getitem_10 = split_with_sizes_default[1];  split_with_sizes_default = None
        convolution_default_3 = torch.ops.aten.convolution.default(getitem_9, primals_6, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_4 = torch.ops.aten.convolution.default(getitem_10, primals_7, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default = torch.ops.aten.cat.default([convolution_default_3, convolution_default_4], 1);  convolution_default_3 = convolution_default_4 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_206, 1);  primals_206 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(cat_default, primals_209, primals_210, primals_207, primals_208, True, 0.1, 1e-05);  primals_210 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        split_with_sizes_default_1 = torch.ops.aten.split_with_sizes.default(relu__default_2, [64, 64, 64], 1)
        getitem_14 = split_with_sizes_default_1[0]
        getitem_15 = split_with_sizes_default_1[1]
        getitem_16 = split_with_sizes_default_1[2];  split_with_sizes_default_1 = None
        convolution_default_5 = torch.ops.aten.convolution.default(getitem_14, primals_3, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 64)
        convolution_default_6 = torch.ops.aten.convolution.default(getitem_15, primals_4, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 64)
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_16, primals_5, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 64)
        cat_default_1 = torch.ops.aten.cat.default([convolution_default_5, convolution_default_6, convolution_default_7], 1);  convolution_default_5 = convolution_default_6 = convolution_default_7 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_211, 1);  primals_211 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_214, primals_215, primals_212, primals_213, True, 0.1, 1e-05);  primals_215 = None
        getitem_17 = native_batch_norm_default_4[0]
        getitem_18 = native_batch_norm_default_4[1]
        getitem_19 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        split_with_sizes_default_2 = torch.ops.aten.split_with_sizes.default(relu__default_3, [96, 96], 1)
        getitem_20 = split_with_sizes_default_2[0]
        getitem_21 = split_with_sizes_default_2[1];  split_with_sizes_default_2 = None
        convolution_default_8 = torch.ops.aten.convolution.default(getitem_20, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_9 = torch.ops.aten.convolution.default(getitem_21, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_2 = torch.ops.aten.cat.default([convolution_default_8, convolution_default_9], 1);  convolution_default_8 = convolution_default_9 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_216, 1);  primals_216 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(cat_default_2, primals_219, primals_220, primals_217, primals_218, True, 0.1, 1e-05);  primals_220 = None
        getitem_22 = native_batch_norm_default_5[0]
        getitem_23 = native_batch_norm_default_5[1]
        getitem_24 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        split_with_sizes_default_3 = torch.ops.aten.split_with_sizes.default(getitem_22, [20, 20], 1)
        getitem_25 = split_with_sizes_default_3[0]
        getitem_26 = split_with_sizes_default_3[1];  split_with_sizes_default_3 = None
        convolution_default_10 = torch.ops.aten.convolution.default(getitem_25, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_11 = torch.ops.aten.convolution.default(getitem_26, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_3 = torch.ops.aten.cat.default([convolution_default_10, convolution_default_11], 1);  convolution_default_10 = convolution_default_11 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_221, 1);  primals_221 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_224, primals_225, primals_222, primals_223, True, 0.1, 1e-05);  primals_225 = None
        getitem_27 = native_batch_norm_default_6[0]
        getitem_28 = native_batch_norm_default_6[1]
        getitem_29 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_27);  getitem_27 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_4, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_226, 1);  primals_226 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_229, primals_230, primals_227, primals_228, True, 0.1, 1e-05);  primals_230 = None
        getitem_30 = native_batch_norm_default_7[0]
        getitem_31 = native_batch_norm_default_7[1]
        getitem_32 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        split_with_sizes_default_4 = torch.ops.aten.split_with_sizes.default(relu__default_5, [60, 60], 1)
        getitem_33 = split_with_sizes_default_4[0]
        getitem_34 = split_with_sizes_default_4[1];  split_with_sizes_default_4 = None
        convolution_default_13 = torch.ops.aten.convolution.default(getitem_33, primals_13, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_14 = torch.ops.aten.convolution.default(getitem_34, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_4 = torch.ops.aten.cat.default([convolution_default_13, convolution_default_14], 1);  convolution_default_13 = convolution_default_14 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_231, 1);  primals_231 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(cat_default_4, primals_234, primals_235, primals_232, primals_233, True, 0.1, 1e-05);  primals_235 = None
        getitem_35 = native_batch_norm_default_8[0]
        getitem_36 = native_batch_norm_default_8[1]
        getitem_37 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(getitem_35, getitem_22);  getitem_35 = getitem_22 = None
        convolution_default_15 = torch.ops.aten.convolution.default(add_tensor_10, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_236, 1);  primals_236 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_239, primals_240, primals_237, primals_238, True, 0.1, 1e-05);  primals_240 = None
        getitem_38 = native_batch_norm_default_9[0]
        getitem_39 = native_batch_norm_default_9[1]
        getitem_40 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        silu__default = torch.ops.aten.silu_.default(getitem_38)
        split_with_sizes_default_5 = torch.ops.aten.split_with_sizes.default(silu__default, [60, 60, 60, 60], 1);  silu__default = None
        getitem_41 = split_with_sizes_default_5[0]
        getitem_42 = split_with_sizes_default_5[1]
        getitem_43 = split_with_sizes_default_5[2]
        getitem_44 = split_with_sizes_default_5[3];  split_with_sizes_default_5 = None
        convolution_default_16 = torch.ops.aten.convolution.default(getitem_41, primals_15, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 60)
        convolution_default_17 = torch.ops.aten.convolution.default(getitem_42, primals_16, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 60)
        convolution_default_18 = torch.ops.aten.convolution.default(getitem_43, primals_17, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 60)
        convolution_default_19 = torch.ops.aten.convolution.default(getitem_44, primals_18, None, [2, 2], [4, 4], [1, 1], False, [0, 0], 60)
        cat_default_5 = torch.ops.aten.cat.default([convolution_default_16, convolution_default_17, convolution_default_18, convolution_default_19], 1);  convolution_default_16 = convolution_default_17 = convolution_default_18 = convolution_default_19 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_241, 1);  primals_241 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(cat_default_5, primals_244, primals_245, primals_242, primals_243, True, 0.1, 1e-05);  primals_245 = None
        getitem_45 = native_batch_norm_default_10[0]
        getitem_46 = native_batch_norm_default_10[1]
        getitem_47 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        silu__default_1 = torch.ops.aten.silu_.default(getitem_45)
        mean_dim = torch.ops.aten.mean.dim(silu__default_1, [2, 3], True)
        convolution_default_20 = torch.ops.aten.convolution.default(mean_dim, primals_24, primals_23, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_23 = None
        silu__default_2 = torch.ops.aten.silu_.default(convolution_default_20)
        convolution_default_21 = torch.ops.aten.convolution.default(silu__default_2, primals_22, primals_21, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_21 = None
        sigmoid_default = torch.ops.aten.sigmoid.default(convolution_default_21);  convolution_default_21 = None
        mul_tensor = torch.ops.aten.mul.Tensor(silu__default_1, sigmoid_default)
        convolution_default_22 = torch.ops.aten.convolution.default(mul_tensor, primals_20, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_246, 1);  primals_246 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_249, primals_250, primals_247, primals_248, True, 0.1, 1e-05);  primals_250 = None
        getitem_48 = native_batch_norm_default_11[0]
        getitem_49 = native_batch_norm_default_11[1]
        getitem_50 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        split_with_sizes_default_6 = torch.ops.aten.split_with_sizes.default(getitem_48, [28, 28], 1)
        getitem_51 = split_with_sizes_default_6[0]
        getitem_52 = split_with_sizes_default_6[1];  split_with_sizes_default_6 = None
        convolution_default_23 = torch.ops.aten.convolution.default(getitem_51, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_24 = torch.ops.aten.convolution.default(getitem_52, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_6 = torch.ops.aten.cat.default([convolution_default_23, convolution_default_24], 1);  convolution_default_23 = convolution_default_24 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_251, 1);  primals_251 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(cat_default_6, primals_254, primals_255, primals_252, primals_253, True, 0.1, 1e-05);  primals_255 = None
        getitem_53 = native_batch_norm_default_12[0]
        getitem_54 = native_batch_norm_default_12[1]
        getitem_55 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        silu__default_3 = torch.ops.aten.silu_.default(getitem_53)
        split_with_sizes_default_7 = torch.ops.aten.split_with_sizes.default(silu__default_3, [168, 168], 1);  silu__default_3 = None
        getitem_56 = split_with_sizes_default_7[0]
        getitem_57 = split_with_sizes_default_7[1];  split_with_sizes_default_7 = None
        convolution_default_25 = torch.ops.aten.convolution.default(getitem_56, primals_25, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_26 = torch.ops.aten.convolution.default(getitem_57, primals_26, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        cat_default_7 = torch.ops.aten.cat.default([convolution_default_25, convolution_default_26], 1);  convolution_default_25 = convolution_default_26 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_256, 1);  primals_256 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(cat_default_7, primals_259, primals_260, primals_257, primals_258, True, 0.1, 1e-05);  primals_260 = None
        getitem_58 = native_batch_norm_default_13[0]
        getitem_59 = native_batch_norm_default_13[1]
        getitem_60 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        silu__default_4 = torch.ops.aten.silu_.default(getitem_58)
        mean_dim_1 = torch.ops.aten.mean.dim(silu__default_4, [2, 3], True)
        convolution_default_27 = torch.ops.aten.convolution.default(mean_dim_1, primals_34, primals_33, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_33 = None
        silu__default_5 = torch.ops.aten.silu_.default(convolution_default_27)
        convolution_default_28 = torch.ops.aten.convolution.default(silu__default_5, primals_32, primals_31, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_31 = None
        sigmoid_default_1 = torch.ops.aten.sigmoid.default(convolution_default_28);  convolution_default_28 = None
        mul_tensor_1 = torch.ops.aten.mul.Tensor(silu__default_4, sigmoid_default_1)
        split_with_sizes_default_8 = torch.ops.aten.split_with_sizes.default(mul_tensor_1, [168, 168], 1);  mul_tensor_1 = None
        getitem_61 = split_with_sizes_default_8[0]
        getitem_62 = split_with_sizes_default_8[1];  split_with_sizes_default_8 = None
        convolution_default_29 = torch.ops.aten.convolution.default(getitem_61, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_30 = torch.ops.aten.convolution.default(getitem_62, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_8 = torch.ops.aten.cat.default([convolution_default_29, convolution_default_30], 1);  convolution_default_29 = convolution_default_30 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_261, 1);  primals_261 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(cat_default_8, primals_264, primals_265, primals_262, primals_263, True, 0.1, 1e-05);  primals_265 = None
        getitem_63 = native_batch_norm_default_14[0]
        getitem_64 = native_batch_norm_default_14[1]
        getitem_65 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(getitem_63, getitem_48);  getitem_63 = getitem_48 = None
        split_with_sizes_default_9 = torch.ops.aten.split_with_sizes.default(add_tensor_17, [28, 28], 1)
        getitem_66 = split_with_sizes_default_9[0]
        getitem_67 = split_with_sizes_default_9[1];  split_with_sizes_default_9 = None
        convolution_default_31 = torch.ops.aten.convolution.default(getitem_66, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_32 = torch.ops.aten.convolution.default(getitem_67, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_9 = torch.ops.aten.cat.default([convolution_default_31, convolution_default_32], 1);  convolution_default_31 = convolution_default_32 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_266, 1);  primals_266 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(cat_default_9, primals_269, primals_270, primals_267, primals_268, True, 0.1, 1e-05);  primals_270 = None
        getitem_68 = native_batch_norm_default_15[0]
        getitem_69 = native_batch_norm_default_15[1]
        getitem_70 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        silu__default_6 = torch.ops.aten.silu_.default(getitem_68)
        split_with_sizes_default_10 = torch.ops.aten.split_with_sizes.default(silu__default_6, [168, 168], 1);  silu__default_6 = None
        getitem_71 = split_with_sizes_default_10[0]
        getitem_72 = split_with_sizes_default_10[1];  split_with_sizes_default_10 = None
        convolution_default_33 = torch.ops.aten.convolution.default(getitem_71, primals_35, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_34 = torch.ops.aten.convolution.default(getitem_72, primals_36, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        cat_default_10 = torch.ops.aten.cat.default([convolution_default_33, convolution_default_34], 1);  convolution_default_33 = convolution_default_34 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_271, 1);  primals_271 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(cat_default_10, primals_274, primals_275, primals_272, primals_273, True, 0.1, 1e-05);  primals_275 = None
        getitem_73 = native_batch_norm_default_16[0]
        getitem_74 = native_batch_norm_default_16[1]
        getitem_75 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        silu__default_7 = torch.ops.aten.silu_.default(getitem_73)
        mean_dim_2 = torch.ops.aten.mean.dim(silu__default_7, [2, 3], True)
        convolution_default_35 = torch.ops.aten.convolution.default(mean_dim_2, primals_44, primals_43, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_43 = None
        silu__default_8 = torch.ops.aten.silu_.default(convolution_default_35)
        convolution_default_36 = torch.ops.aten.convolution.default(silu__default_8, primals_42, primals_41, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_41 = None
        sigmoid_default_2 = torch.ops.aten.sigmoid.default(convolution_default_36);  convolution_default_36 = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(silu__default_7, sigmoid_default_2)
        split_with_sizes_default_11 = torch.ops.aten.split_with_sizes.default(mul_tensor_2, [168, 168], 1);  mul_tensor_2 = None
        getitem_76 = split_with_sizes_default_11[0]
        getitem_77 = split_with_sizes_default_11[1];  split_with_sizes_default_11 = None
        convolution_default_37 = torch.ops.aten.convolution.default(getitem_76, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_38 = torch.ops.aten.convolution.default(getitem_77, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_11 = torch.ops.aten.cat.default([convolution_default_37, convolution_default_38], 1);  convolution_default_37 = convolution_default_38 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_276, 1);  primals_276 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(cat_default_11, primals_279, primals_280, primals_277, primals_278, True, 0.1, 1e-05);  primals_280 = None
        getitem_78 = native_batch_norm_default_17[0]
        getitem_79 = native_batch_norm_default_17[1]
        getitem_80 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(getitem_78, add_tensor_17);  getitem_78 = add_tensor_17 = None
        split_with_sizes_default_12 = torch.ops.aten.split_with_sizes.default(add_tensor_21, [28, 28], 1)
        getitem_81 = split_with_sizes_default_12[0]
        getitem_82 = split_with_sizes_default_12[1];  split_with_sizes_default_12 = None
        convolution_default_39 = torch.ops.aten.convolution.default(getitem_81, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_82, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_12 = torch.ops.aten.cat.default([convolution_default_39, convolution_default_40], 1);  convolution_default_39 = convolution_default_40 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(primals_281, 1);  primals_281 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(cat_default_12, primals_284, primals_285, primals_282, primals_283, True, 0.1, 1e-05);  primals_285 = None
        getitem_83 = native_batch_norm_default_18[0]
        getitem_84 = native_batch_norm_default_18[1]
        getitem_85 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        silu__default_9 = torch.ops.aten.silu_.default(getitem_83)
        split_with_sizes_default_13 = torch.ops.aten.split_with_sizes.default(silu__default_9, [168, 168], 1);  silu__default_9 = None
        getitem_86 = split_with_sizes_default_13[0]
        getitem_87 = split_with_sizes_default_13[1];  split_with_sizes_default_13 = None
        convolution_default_41 = torch.ops.aten.convolution.default(getitem_86, primals_45, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 168)
        convolution_default_42 = torch.ops.aten.convolution.default(getitem_87, primals_46, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 168)
        cat_default_13 = torch.ops.aten.cat.default([convolution_default_41, convolution_default_42], 1);  convolution_default_41 = convolution_default_42 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_286, 1);  primals_286 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(cat_default_13, primals_289, primals_290, primals_287, primals_288, True, 0.1, 1e-05);  primals_290 = None
        getitem_88 = native_batch_norm_default_19[0]
        getitem_89 = native_batch_norm_default_19[1]
        getitem_90 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        silu__default_10 = torch.ops.aten.silu_.default(getitem_88)
        mean_dim_3 = torch.ops.aten.mean.dim(silu__default_10, [2, 3], True)
        convolution_default_43 = torch.ops.aten.convolution.default(mean_dim_3, primals_54, primals_53, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_53 = None
        silu__default_11 = torch.ops.aten.silu_.default(convolution_default_43)
        convolution_default_44 = torch.ops.aten.convolution.default(silu__default_11, primals_52, primals_51, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_51 = None
        sigmoid_default_3 = torch.ops.aten.sigmoid.default(convolution_default_44);  convolution_default_44 = None
        mul_tensor_3 = torch.ops.aten.mul.Tensor(silu__default_10, sigmoid_default_3)
        split_with_sizes_default_14 = torch.ops.aten.split_with_sizes.default(mul_tensor_3, [168, 168], 1);  mul_tensor_3 = None
        getitem_91 = split_with_sizes_default_14[0]
        getitem_92 = split_with_sizes_default_14[1];  split_with_sizes_default_14 = None
        convolution_default_45 = torch.ops.aten.convolution.default(getitem_91, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_46 = torch.ops.aten.convolution.default(getitem_92, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_14 = torch.ops.aten.cat.default([convolution_default_45, convolution_default_46], 1);  convolution_default_45 = convolution_default_46 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_291, 1);  primals_291 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(cat_default_14, primals_294, primals_295, primals_292, primals_293, True, 0.1, 1e-05);  primals_295 = None
        getitem_93 = native_batch_norm_default_20[0]
        getitem_94 = native_batch_norm_default_20[1]
        getitem_95 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(getitem_93, add_tensor_21);  getitem_93 = add_tensor_21 = None
        convolution_default_47 = torch.ops.aten.convolution.default(add_tensor_25, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(primals_296, 1);  primals_296 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_299, primals_300, primals_297, primals_298, True, 0.1, 1e-05);  primals_300 = None
        getitem_96 = native_batch_norm_default_21[0]
        getitem_97 = native_batch_norm_default_21[1]
        getitem_98 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        silu__default_12 = torch.ops.aten.silu_.default(getitem_96)
        split_with_sizes_default_15 = torch.ops.aten.split_with_sizes.default(silu__default_12, [112, 112, 112], 1);  silu__default_12 = None
        getitem_99 = split_with_sizes_default_15[0]
        getitem_100 = split_with_sizes_default_15[1]
        getitem_101 = split_with_sizes_default_15[2];  split_with_sizes_default_15 = None
        convolution_default_48 = torch.ops.aten.convolution.default(getitem_99, primals_55, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 112)
        convolution_default_49 = torch.ops.aten.convolution.default(getitem_100, primals_56, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 112)
        convolution_default_50 = torch.ops.aten.convolution.default(getitem_101, primals_57, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 112)
        cat_default_15 = torch.ops.aten.cat.default([convolution_default_48, convolution_default_49, convolution_default_50], 1);  convolution_default_48 = convolution_default_49 = convolution_default_50 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(primals_301, 1);  primals_301 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(cat_default_15, primals_304, primals_305, primals_302, primals_303, True, 0.1, 1e-05);  primals_305 = None
        getitem_102 = native_batch_norm_default_22[0]
        getitem_103 = native_batch_norm_default_22[1]
        getitem_104 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        silu__default_13 = torch.ops.aten.silu_.default(getitem_102)
        mean_dim_4 = torch.ops.aten.mean.dim(silu__default_13, [2, 3], True)
        convolution_default_51 = torch.ops.aten.convolution.default(mean_dim_4, primals_63, primals_62, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_62 = None
        silu__default_14 = torch.ops.aten.silu_.default(convolution_default_51)
        convolution_default_52 = torch.ops.aten.convolution.default(silu__default_14, primals_61, primals_60, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_60 = None
        sigmoid_default_4 = torch.ops.aten.sigmoid.default(convolution_default_52);  convolution_default_52 = None
        mul_tensor_4 = torch.ops.aten.mul.Tensor(silu__default_13, sigmoid_default_4)
        convolution_default_53 = torch.ops.aten.convolution.default(mul_tensor_4, primals_59, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_306, 1);  primals_306 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_309, primals_310, primals_307, primals_308, True, 0.1, 1e-05);  primals_310 = None
        getitem_105 = native_batch_norm_default_23[0]
        getitem_106 = native_batch_norm_default_23[1]
        getitem_107 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        split_with_sizes_default_16 = torch.ops.aten.split_with_sizes.default(getitem_105, [52, 52], 1)
        getitem_108 = split_with_sizes_default_16[0]
        getitem_109 = split_with_sizes_default_16[1];  split_with_sizes_default_16 = None
        convolution_default_54 = torch.ops.aten.convolution.default(getitem_108, primals_68, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_55 = torch.ops.aten.convolution.default(getitem_109, primals_69, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_16 = torch.ops.aten.cat.default([convolution_default_54, convolution_default_55], 1);  convolution_default_54 = convolution_default_55 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_311, 1);  primals_311 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(cat_default_16, primals_314, primals_315, primals_312, primals_313, True, 0.1, 1e-05);  primals_315 = None
        getitem_110 = native_batch_norm_default_24[0]
        getitem_111 = native_batch_norm_default_24[1]
        getitem_112 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        silu__default_15 = torch.ops.aten.silu_.default(getitem_110)
        split_with_sizes_default_17 = torch.ops.aten.split_with_sizes.default(silu__default_15, [156, 156, 156, 156], 1);  silu__default_15 = None
        getitem_113 = split_with_sizes_default_17[0]
        getitem_114 = split_with_sizes_default_17[1]
        getitem_115 = split_with_sizes_default_17[2]
        getitem_116 = split_with_sizes_default_17[3];  split_with_sizes_default_17 = None
        convolution_default_56 = torch.ops.aten.convolution.default(getitem_113, primals_64, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 156)
        convolution_default_57 = torch.ops.aten.convolution.default(getitem_114, primals_65, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 156)
        convolution_default_58 = torch.ops.aten.convolution.default(getitem_115, primals_66, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 156)
        convolution_default_59 = torch.ops.aten.convolution.default(getitem_116, primals_67, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 156)
        cat_default_17 = torch.ops.aten.cat.default([convolution_default_56, convolution_default_57, convolution_default_58, convolution_default_59], 1);  convolution_default_56 = convolution_default_57 = convolution_default_58 = convolution_default_59 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(primals_316, 1);  primals_316 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(cat_default_17, primals_319, primals_320, primals_317, primals_318, True, 0.1, 1e-05);  primals_320 = None
        getitem_117 = native_batch_norm_default_25[0]
        getitem_118 = native_batch_norm_default_25[1]
        getitem_119 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        silu__default_16 = torch.ops.aten.silu_.default(getitem_117)
        mean_dim_5 = torch.ops.aten.mean.dim(silu__default_16, [2, 3], True)
        convolution_default_60 = torch.ops.aten.convolution.default(mean_dim_5, primals_75, primals_74, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_74 = None
        silu__default_17 = torch.ops.aten.silu_.default(convolution_default_60)
        convolution_default_61 = torch.ops.aten.convolution.default(silu__default_17, primals_73, primals_72, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_72 = None
        sigmoid_default_5 = torch.ops.aten.sigmoid.default(convolution_default_61);  convolution_default_61 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(silu__default_16, sigmoid_default_5)
        split_with_sizes_default_18 = torch.ops.aten.split_with_sizes.default(mul_tensor_5, [312, 312], 1);  mul_tensor_5 = None
        getitem_120 = split_with_sizes_default_18[0]
        getitem_121 = split_with_sizes_default_18[1];  split_with_sizes_default_18 = None
        convolution_default_62 = torch.ops.aten.convolution.default(getitem_120, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_63 = torch.ops.aten.convolution.default(getitem_121, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_18 = torch.ops.aten.cat.default([convolution_default_62, convolution_default_63], 1);  convolution_default_62 = convolution_default_63 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_321, 1);  primals_321 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(cat_default_18, primals_324, primals_325, primals_322, primals_323, True, 0.1, 1e-05);  primals_325 = None
        getitem_122 = native_batch_norm_default_26[0]
        getitem_123 = native_batch_norm_default_26[1]
        getitem_124 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(getitem_122, getitem_105);  getitem_122 = getitem_105 = None
        split_with_sizes_default_19 = torch.ops.aten.split_with_sizes.default(add_tensor_32, [52, 52], 1)
        getitem_125 = split_with_sizes_default_19[0]
        getitem_126 = split_with_sizes_default_19[1];  split_with_sizes_default_19 = None
        convolution_default_64 = torch.ops.aten.convolution.default(getitem_125, primals_80, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_65 = torch.ops.aten.convolution.default(getitem_126, primals_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_19 = torch.ops.aten.cat.default([convolution_default_64, convolution_default_65], 1);  convolution_default_64 = convolution_default_65 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_326, 1);  primals_326 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(cat_default_19, primals_329, primals_330, primals_327, primals_328, True, 0.1, 1e-05);  primals_330 = None
        getitem_127 = native_batch_norm_default_27[0]
        getitem_128 = native_batch_norm_default_27[1]
        getitem_129 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        silu__default_18 = torch.ops.aten.silu_.default(getitem_127)
        split_with_sizes_default_20 = torch.ops.aten.split_with_sizes.default(silu__default_18, [156, 156, 156, 156], 1);  silu__default_18 = None
        getitem_130 = split_with_sizes_default_20[0]
        getitem_131 = split_with_sizes_default_20[1]
        getitem_132 = split_with_sizes_default_20[2]
        getitem_133 = split_with_sizes_default_20[3];  split_with_sizes_default_20 = None
        convolution_default_66 = torch.ops.aten.convolution.default(getitem_130, primals_76, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 156)
        convolution_default_67 = torch.ops.aten.convolution.default(getitem_131, primals_77, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 156)
        convolution_default_68 = torch.ops.aten.convolution.default(getitem_132, primals_78, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 156)
        convolution_default_69 = torch.ops.aten.convolution.default(getitem_133, primals_79, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 156)
        cat_default_20 = torch.ops.aten.cat.default([convolution_default_66, convolution_default_67, convolution_default_68, convolution_default_69], 1);  convolution_default_66 = convolution_default_67 = convolution_default_68 = convolution_default_69 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(primals_331, 1);  primals_331 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(cat_default_20, primals_334, primals_335, primals_332, primals_333, True, 0.1, 1e-05);  primals_335 = None
        getitem_134 = native_batch_norm_default_28[0]
        getitem_135 = native_batch_norm_default_28[1]
        getitem_136 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        silu__default_19 = torch.ops.aten.silu_.default(getitem_134)
        mean_dim_6 = torch.ops.aten.mean.dim(silu__default_19, [2, 3], True)
        convolution_default_70 = torch.ops.aten.convolution.default(mean_dim_6, primals_87, primals_86, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_86 = None
        silu__default_20 = torch.ops.aten.silu_.default(convolution_default_70)
        convolution_default_71 = torch.ops.aten.convolution.default(silu__default_20, primals_85, primals_84, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_84 = None
        sigmoid_default_6 = torch.ops.aten.sigmoid.default(convolution_default_71);  convolution_default_71 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(silu__default_19, sigmoid_default_6)
        split_with_sizes_default_21 = torch.ops.aten.split_with_sizes.default(mul_tensor_6, [312, 312], 1);  mul_tensor_6 = None
        getitem_137 = split_with_sizes_default_21[0]
        getitem_138 = split_with_sizes_default_21[1];  split_with_sizes_default_21 = None
        convolution_default_72 = torch.ops.aten.convolution.default(getitem_137, primals_82, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_73 = torch.ops.aten.convolution.default(getitem_138, primals_83, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_21 = torch.ops.aten.cat.default([convolution_default_72, convolution_default_73], 1);  convolution_default_72 = convolution_default_73 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_336, 1);  primals_336 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(cat_default_21, primals_339, primals_340, primals_337, primals_338, True, 0.1, 1e-05);  primals_340 = None
        getitem_139 = native_batch_norm_default_29[0]
        getitem_140 = native_batch_norm_default_29[1]
        getitem_141 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(getitem_139, add_tensor_32);  getitem_139 = add_tensor_32 = None
        split_with_sizes_default_22 = torch.ops.aten.split_with_sizes.default(add_tensor_36, [52, 52], 1)
        getitem_142 = split_with_sizes_default_22[0]
        getitem_143 = split_with_sizes_default_22[1];  split_with_sizes_default_22 = None
        convolution_default_74 = torch.ops.aten.convolution.default(getitem_142, primals_92, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_75 = torch.ops.aten.convolution.default(getitem_143, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_22 = torch.ops.aten.cat.default([convolution_default_74, convolution_default_75], 1);  convolution_default_74 = convolution_default_75 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_341, 1);  primals_341 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(cat_default_22, primals_344, primals_345, primals_342, primals_343, True, 0.1, 1e-05);  primals_345 = None
        getitem_144 = native_batch_norm_default_30[0]
        getitem_145 = native_batch_norm_default_30[1]
        getitem_146 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        silu__default_21 = torch.ops.aten.silu_.default(getitem_144)
        split_with_sizes_default_23 = torch.ops.aten.split_with_sizes.default(silu__default_21, [156, 156, 156, 156], 1);  silu__default_21 = None
        getitem_147 = split_with_sizes_default_23[0]
        getitem_148 = split_with_sizes_default_23[1]
        getitem_149 = split_with_sizes_default_23[2]
        getitem_150 = split_with_sizes_default_23[3];  split_with_sizes_default_23 = None
        convolution_default_76 = torch.ops.aten.convolution.default(getitem_147, primals_88, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 156)
        convolution_default_77 = torch.ops.aten.convolution.default(getitem_148, primals_89, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 156)
        convolution_default_78 = torch.ops.aten.convolution.default(getitem_149, primals_90, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 156)
        convolution_default_79 = torch.ops.aten.convolution.default(getitem_150, primals_91, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 156)
        cat_default_23 = torch.ops.aten.cat.default([convolution_default_76, convolution_default_77, convolution_default_78, convolution_default_79], 1);  convolution_default_76 = convolution_default_77 = convolution_default_78 = convolution_default_79 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(primals_346, 1);  primals_346 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(cat_default_23, primals_349, primals_350, primals_347, primals_348, True, 0.1, 1e-05);  primals_350 = None
        getitem_151 = native_batch_norm_default_31[0]
        getitem_152 = native_batch_norm_default_31[1]
        getitem_153 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        silu__default_22 = torch.ops.aten.silu_.default(getitem_151)
        mean_dim_7 = torch.ops.aten.mean.dim(silu__default_22, [2, 3], True)
        convolution_default_80 = torch.ops.aten.convolution.default(mean_dim_7, primals_99, primals_98, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_98 = None
        silu__default_23 = torch.ops.aten.silu_.default(convolution_default_80)
        convolution_default_81 = torch.ops.aten.convolution.default(silu__default_23, primals_97, primals_96, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_96 = None
        sigmoid_default_7 = torch.ops.aten.sigmoid.default(convolution_default_81);  convolution_default_81 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(silu__default_22, sigmoid_default_7)
        split_with_sizes_default_24 = torch.ops.aten.split_with_sizes.default(mul_tensor_7, [312, 312], 1);  mul_tensor_7 = None
        getitem_154 = split_with_sizes_default_24[0]
        getitem_155 = split_with_sizes_default_24[1];  split_with_sizes_default_24 = None
        convolution_default_82 = torch.ops.aten.convolution.default(getitem_154, primals_94, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_83 = torch.ops.aten.convolution.default(getitem_155, primals_95, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_24 = torch.ops.aten.cat.default([convolution_default_82, convolution_default_83], 1);  convolution_default_82 = convolution_default_83 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_351, 1);  primals_351 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(cat_default_24, primals_354, primals_355, primals_352, primals_353, True, 0.1, 1e-05);  primals_355 = None
        getitem_156 = native_batch_norm_default_32[0]
        getitem_157 = native_batch_norm_default_32[1]
        getitem_158 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(getitem_156, add_tensor_36);  getitem_156 = add_tensor_36 = None
        convolution_default_84 = torch.ops.aten.convolution.default(add_tensor_40, primals_101, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_356, 1);  primals_356 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_84, primals_359, primals_360, primals_357, primals_358, True, 0.1, 1e-05);  primals_360 = None
        getitem_159 = native_batch_norm_default_33[0]
        getitem_160 = native_batch_norm_default_33[1]
        getitem_161 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        silu__default_24 = torch.ops.aten.silu_.default(getitem_159)
        convolution_default_85 = torch.ops.aten.convolution.default(silu__default_24, primals_100, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 624)
        add_tensor_42 = torch.ops.aten.add.Tensor(primals_361, 1);  primals_361 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_364, primals_365, primals_362, primals_363, True, 0.1, 1e-05);  primals_365 = None
        getitem_162 = native_batch_norm_default_34[0]
        getitem_163 = native_batch_norm_default_34[1]
        getitem_164 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        silu__default_25 = torch.ops.aten.silu_.default(getitem_162)
        mean_dim_8 = torch.ops.aten.mean.dim(silu__default_25, [2, 3], True)
        convolution_default_86 = torch.ops.aten.convolution.default(mean_dim_8, primals_106, primals_105, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_105 = None
        silu__default_26 = torch.ops.aten.silu_.default(convolution_default_86)
        convolution_default_87 = torch.ops.aten.convolution.default(silu__default_26, primals_104, primals_103, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_103 = None
        sigmoid_default_8 = torch.ops.aten.sigmoid.default(convolution_default_87);  convolution_default_87 = None
        mul_tensor_8 = torch.ops.aten.mul.Tensor(silu__default_25, sigmoid_default_8)
        convolution_default_88 = torch.ops.aten.convolution.default(mul_tensor_8, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_366, 1);  primals_366 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_369, primals_370, primals_367, primals_368, True, 0.1, 1e-05);  primals_370 = None
        getitem_165 = native_batch_norm_default_35[0]
        getitem_166 = native_batch_norm_default_35[1]
        getitem_167 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        split_with_sizes_default_25 = torch.ops.aten.split_with_sizes.default(getitem_165, [80, 80], 1)
        getitem_168 = split_with_sizes_default_25[0]
        getitem_169 = split_with_sizes_default_25[1];  split_with_sizes_default_25 = None
        convolution_default_89 = torch.ops.aten.convolution.default(getitem_168, primals_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_90 = torch.ops.aten.convolution.default(getitem_169, primals_112, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_25 = torch.ops.aten.cat.default([convolution_default_89, convolution_default_90], 1);  convolution_default_89 = convolution_default_90 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_371, 1);  primals_371 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(cat_default_25, primals_374, primals_375, primals_372, primals_373, True, 0.1, 1e-05);  primals_375 = None
        getitem_170 = native_batch_norm_default_36[0]
        getitem_171 = native_batch_norm_default_36[1]
        getitem_172 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        silu__default_27 = torch.ops.aten.silu_.default(getitem_170)
        split_with_sizes_default_26 = torch.ops.aten.split_with_sizes.default(silu__default_27, [120, 120, 120, 120], 1);  silu__default_27 = None
        getitem_173 = split_with_sizes_default_26[0]
        getitem_174 = split_with_sizes_default_26[1]
        getitem_175 = split_with_sizes_default_26[2]
        getitem_176 = split_with_sizes_default_26[3];  split_with_sizes_default_26 = None
        convolution_default_91 = torch.ops.aten.convolution.default(getitem_173, primals_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        convolution_default_92 = torch.ops.aten.convolution.default(getitem_174, primals_108, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 120)
        convolution_default_93 = torch.ops.aten.convolution.default(getitem_175, primals_109, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 120)
        convolution_default_94 = torch.ops.aten.convolution.default(getitem_176, primals_110, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 120)
        cat_default_26 = torch.ops.aten.cat.default([convolution_default_91, convolution_default_92, convolution_default_93, convolution_default_94], 1);  convolution_default_91 = convolution_default_92 = convolution_default_93 = convolution_default_94 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(primals_376, 1);  primals_376 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(cat_default_26, primals_379, primals_380, primals_377, primals_378, True, 0.1, 1e-05);  primals_380 = None
        getitem_177 = native_batch_norm_default_37[0]
        getitem_178 = native_batch_norm_default_37[1]
        getitem_179 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        silu__default_28 = torch.ops.aten.silu_.default(getitem_177)
        mean_dim_9 = torch.ops.aten.mean.dim(silu__default_28, [2, 3], True)
        convolution_default_95 = torch.ops.aten.convolution.default(mean_dim_9, primals_118, primals_117, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_117 = None
        silu__default_29 = torch.ops.aten.silu_.default(convolution_default_95)
        convolution_default_96 = torch.ops.aten.convolution.default(silu__default_29, primals_116, primals_115, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_115 = None
        sigmoid_default_9 = torch.ops.aten.sigmoid.default(convolution_default_96);  convolution_default_96 = None
        mul_tensor_9 = torch.ops.aten.mul.Tensor(silu__default_28, sigmoid_default_9)
        split_with_sizes_default_27 = torch.ops.aten.split_with_sizes.default(mul_tensor_9, [240, 240], 1);  mul_tensor_9 = None
        getitem_180 = split_with_sizes_default_27[0]
        getitem_181 = split_with_sizes_default_27[1];  split_with_sizes_default_27 = None
        convolution_default_97 = torch.ops.aten.convolution.default(getitem_180, primals_113, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_98 = torch.ops.aten.convolution.default(getitem_181, primals_114, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_27 = torch.ops.aten.cat.default([convolution_default_97, convolution_default_98], 1);  convolution_default_97 = convolution_default_98 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_381, 1);  primals_381 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(cat_default_27, primals_384, primals_385, primals_382, primals_383, True, 0.1, 1e-05);  primals_385 = None
        getitem_182 = native_batch_norm_default_38[0]
        getitem_183 = native_batch_norm_default_38[1]
        getitem_184 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(getitem_182, getitem_165);  getitem_182 = getitem_165 = None
        split_with_sizes_default_28 = torch.ops.aten.split_with_sizes.default(add_tensor_47, [80, 80], 1)
        getitem_185 = split_with_sizes_default_28[0]
        getitem_186 = split_with_sizes_default_28[1];  split_with_sizes_default_28 = None
        convolution_default_99 = torch.ops.aten.convolution.default(getitem_185, primals_123, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_100 = torch.ops.aten.convolution.default(getitem_186, primals_124, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_28 = torch.ops.aten.cat.default([convolution_default_99, convolution_default_100], 1);  convolution_default_99 = convolution_default_100 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_386, 1);  primals_386 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(cat_default_28, primals_389, primals_390, primals_387, primals_388, True, 0.1, 1e-05);  primals_390 = None
        getitem_187 = native_batch_norm_default_39[0]
        getitem_188 = native_batch_norm_default_39[1]
        getitem_189 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        silu__default_30 = torch.ops.aten.silu_.default(getitem_187)
        split_with_sizes_default_29 = torch.ops.aten.split_with_sizes.default(silu__default_30, [120, 120, 120, 120], 1);  silu__default_30 = None
        getitem_190 = split_with_sizes_default_29[0]
        getitem_191 = split_with_sizes_default_29[1]
        getitem_192 = split_with_sizes_default_29[2]
        getitem_193 = split_with_sizes_default_29[3];  split_with_sizes_default_29 = None
        convolution_default_101 = torch.ops.aten.convolution.default(getitem_190, primals_119, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        convolution_default_102 = torch.ops.aten.convolution.default(getitem_191, primals_120, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 120)
        convolution_default_103 = torch.ops.aten.convolution.default(getitem_192, primals_121, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 120)
        convolution_default_104 = torch.ops.aten.convolution.default(getitem_193, primals_122, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 120)
        cat_default_29 = torch.ops.aten.cat.default([convolution_default_101, convolution_default_102, convolution_default_103, convolution_default_104], 1);  convolution_default_101 = convolution_default_102 = convolution_default_103 = convolution_default_104 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(primals_391, 1);  primals_391 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(cat_default_29, primals_394, primals_395, primals_392, primals_393, True, 0.1, 1e-05);  primals_395 = None
        getitem_194 = native_batch_norm_default_40[0]
        getitem_195 = native_batch_norm_default_40[1]
        getitem_196 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        silu__default_31 = torch.ops.aten.silu_.default(getitem_194)
        mean_dim_10 = torch.ops.aten.mean.dim(silu__default_31, [2, 3], True)
        convolution_default_105 = torch.ops.aten.convolution.default(mean_dim_10, primals_130, primals_129, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_129 = None
        silu__default_32 = torch.ops.aten.silu_.default(convolution_default_105)
        convolution_default_106 = torch.ops.aten.convolution.default(silu__default_32, primals_128, primals_127, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_127 = None
        sigmoid_default_10 = torch.ops.aten.sigmoid.default(convolution_default_106);  convolution_default_106 = None
        mul_tensor_10 = torch.ops.aten.mul.Tensor(silu__default_31, sigmoid_default_10)
        split_with_sizes_default_30 = torch.ops.aten.split_with_sizes.default(mul_tensor_10, [240, 240], 1);  mul_tensor_10 = None
        getitem_197 = split_with_sizes_default_30[0]
        getitem_198 = split_with_sizes_default_30[1];  split_with_sizes_default_30 = None
        convolution_default_107 = torch.ops.aten.convolution.default(getitem_197, primals_125, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_108 = torch.ops.aten.convolution.default(getitem_198, primals_126, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_30 = torch.ops.aten.cat.default([convolution_default_107, convolution_default_108], 1);  convolution_default_107 = convolution_default_108 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_396, 1);  primals_396 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(cat_default_30, primals_399, primals_400, primals_397, primals_398, True, 0.1, 1e-05);  primals_400 = None
        getitem_199 = native_batch_norm_default_41[0]
        getitem_200 = native_batch_norm_default_41[1]
        getitem_201 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(getitem_199, add_tensor_47);  getitem_199 = add_tensor_47 = None
        split_with_sizes_default_31 = torch.ops.aten.split_with_sizes.default(add_tensor_51, [80, 80], 1)
        getitem_202 = split_with_sizes_default_31[0]
        getitem_203 = split_with_sizes_default_31[1];  split_with_sizes_default_31 = None
        convolution_default_109 = torch.ops.aten.convolution.default(getitem_202, primals_135, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_110 = torch.ops.aten.convolution.default(getitem_203, primals_136, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_31 = torch.ops.aten.cat.default([convolution_default_109, convolution_default_110], 1);  convolution_default_109 = convolution_default_110 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_401, 1);  primals_401 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(cat_default_31, primals_404, primals_405, primals_402, primals_403, True, 0.1, 1e-05);  primals_405 = None
        getitem_204 = native_batch_norm_default_42[0]
        getitem_205 = native_batch_norm_default_42[1]
        getitem_206 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        silu__default_33 = torch.ops.aten.silu_.default(getitem_204)
        split_with_sizes_default_32 = torch.ops.aten.split_with_sizes.default(silu__default_33, [120, 120, 120, 120], 1);  silu__default_33 = None
        getitem_207 = split_with_sizes_default_32[0]
        getitem_208 = split_with_sizes_default_32[1]
        getitem_209 = split_with_sizes_default_32[2]
        getitem_210 = split_with_sizes_default_32[3];  split_with_sizes_default_32 = None
        convolution_default_111 = torch.ops.aten.convolution.default(getitem_207, primals_131, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 120)
        convolution_default_112 = torch.ops.aten.convolution.default(getitem_208, primals_132, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 120)
        convolution_default_113 = torch.ops.aten.convolution.default(getitem_209, primals_133, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 120)
        convolution_default_114 = torch.ops.aten.convolution.default(getitem_210, primals_134, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 120)
        cat_default_32 = torch.ops.aten.cat.default([convolution_default_111, convolution_default_112, convolution_default_113, convolution_default_114], 1);  convolution_default_111 = convolution_default_112 = convolution_default_113 = convolution_default_114 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(primals_406, 1);  primals_406 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(cat_default_32, primals_409, primals_410, primals_407, primals_408, True, 0.1, 1e-05);  primals_410 = None
        getitem_211 = native_batch_norm_default_43[0]
        getitem_212 = native_batch_norm_default_43[1]
        getitem_213 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        silu__default_34 = torch.ops.aten.silu_.default(getitem_211)
        mean_dim_11 = torch.ops.aten.mean.dim(silu__default_34, [2, 3], True)
        convolution_default_115 = torch.ops.aten.convolution.default(mean_dim_11, primals_142, primals_141, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_141 = None
        silu__default_35 = torch.ops.aten.silu_.default(convolution_default_115)
        convolution_default_116 = torch.ops.aten.convolution.default(silu__default_35, primals_140, primals_139, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_139 = None
        sigmoid_default_11 = torch.ops.aten.sigmoid.default(convolution_default_116);  convolution_default_116 = None
        mul_tensor_11 = torch.ops.aten.mul.Tensor(silu__default_34, sigmoid_default_11)
        split_with_sizes_default_33 = torch.ops.aten.split_with_sizes.default(mul_tensor_11, [240, 240], 1);  mul_tensor_11 = None
        getitem_214 = split_with_sizes_default_33[0]
        getitem_215 = split_with_sizes_default_33[1];  split_with_sizes_default_33 = None
        convolution_default_117 = torch.ops.aten.convolution.default(getitem_214, primals_137, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_118 = torch.ops.aten.convolution.default(getitem_215, primals_138, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_33 = torch.ops.aten.cat.default([convolution_default_117, convolution_default_118], 1);  convolution_default_117 = convolution_default_118 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_411, 1);  primals_411 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(cat_default_33, primals_414, primals_415, primals_412, primals_413, True, 0.1, 1e-05);  primals_415 = None
        getitem_216 = native_batch_norm_default_44[0]
        getitem_217 = native_batch_norm_default_44[1]
        getitem_218 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(getitem_216, add_tensor_51);  getitem_216 = add_tensor_51 = None
        convolution_default_119 = torch.ops.aten.convolution.default(add_tensor_55, primals_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_416, 1);  primals_416 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_119, primals_419, primals_420, primals_417, primals_418, True, 0.1, 1e-05);  primals_420 = None
        getitem_219 = native_batch_norm_default_45[0]
        getitem_220 = native_batch_norm_default_45[1]
        getitem_221 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        silu__default_36 = torch.ops.aten.silu_.default(getitem_219)
        split_with_sizes_default_34 = torch.ops.aten.split_with_sizes.default(silu__default_36, [240, 240, 240, 240], 1);  silu__default_36 = None
        getitem_222 = split_with_sizes_default_34[0]
        getitem_223 = split_with_sizes_default_34[1]
        getitem_224 = split_with_sizes_default_34[2]
        getitem_225 = split_with_sizes_default_34[3];  split_with_sizes_default_34 = None
        convolution_default_120 = torch.ops.aten.convolution.default(getitem_222, primals_143, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 240)
        convolution_default_121 = torch.ops.aten.convolution.default(getitem_223, primals_144, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 240)
        convolution_default_122 = torch.ops.aten.convolution.default(getitem_224, primals_145, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 240)
        convolution_default_123 = torch.ops.aten.convolution.default(getitem_225, primals_146, None, [2, 2], [4, 4], [1, 1], False, [0, 0], 240)
        cat_default_34 = torch.ops.aten.cat.default([convolution_default_120, convolution_default_121, convolution_default_122, convolution_default_123], 1);  convolution_default_120 = convolution_default_121 = convolution_default_122 = convolution_default_123 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_421, 1);  primals_421 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(cat_default_34, primals_424, primals_425, primals_422, primals_423, True, 0.1, 1e-05);  primals_425 = None
        getitem_226 = native_batch_norm_default_46[0]
        getitem_227 = native_batch_norm_default_46[1]
        getitem_228 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        silu__default_37 = torch.ops.aten.silu_.default(getitem_226)
        mean_dim_12 = torch.ops.aten.mean.dim(silu__default_37, [2, 3], True)
        convolution_default_124 = torch.ops.aten.convolution.default(mean_dim_12, primals_152, primals_151, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_151 = None
        silu__default_38 = torch.ops.aten.silu_.default(convolution_default_124)
        convolution_default_125 = torch.ops.aten.convolution.default(silu__default_38, primals_150, primals_149, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_149 = None
        sigmoid_default_12 = torch.ops.aten.sigmoid.default(convolution_default_125);  convolution_default_125 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(silu__default_37, sigmoid_default_12)
        convolution_default_126 = torch.ops.aten.convolution.default(mul_tensor_12, primals_148, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_58 = torch.ops.aten.add.Tensor(primals_426, 1);  primals_426 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_126, primals_429, primals_430, primals_427, primals_428, True, 0.1, 1e-05);  primals_430 = None
        getitem_229 = native_batch_norm_default_47[0]
        getitem_230 = native_batch_norm_default_47[1]
        getitem_231 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        convolution_default_127 = torch.ops.aten.convolution.default(getitem_229, primals_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_59 = torch.ops.aten.add.Tensor(primals_431, 1);  primals_431 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_127, primals_434, primals_435, primals_432, primals_433, True, 0.1, 1e-05);  primals_435 = None
        getitem_232 = native_batch_norm_default_48[0]
        getitem_233 = native_batch_norm_default_48[1]
        getitem_234 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        silu__default_39 = torch.ops.aten.silu_.default(getitem_232)
        split_with_sizes_default_35 = torch.ops.aten.split_with_sizes.default(silu__default_39, [396, 396, 396, 396], 1);  silu__default_39 = None
        getitem_235 = split_with_sizes_default_35[0]
        getitem_236 = split_with_sizes_default_35[1]
        getitem_237 = split_with_sizes_default_35[2]
        getitem_238 = split_with_sizes_default_35[3];  split_with_sizes_default_35 = None
        convolution_default_128 = torch.ops.aten.convolution.default(getitem_235, primals_153, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 396)
        convolution_default_129 = torch.ops.aten.convolution.default(getitem_236, primals_154, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 396)
        convolution_default_130 = torch.ops.aten.convolution.default(getitem_237, primals_155, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 396)
        convolution_default_131 = torch.ops.aten.convolution.default(getitem_238, primals_156, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 396)
        cat_default_35 = torch.ops.aten.cat.default([convolution_default_128, convolution_default_129, convolution_default_130, convolution_default_131], 1);  convolution_default_128 = convolution_default_129 = convolution_default_130 = convolution_default_131 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(primals_436, 1);  primals_436 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(cat_default_35, primals_439, primals_440, primals_437, primals_438, True, 0.1, 1e-05);  primals_440 = None
        getitem_239 = native_batch_norm_default_49[0]
        getitem_240 = native_batch_norm_default_49[1]
        getitem_241 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        silu__default_40 = torch.ops.aten.silu_.default(getitem_239)
        mean_dim_13 = torch.ops.aten.mean.dim(silu__default_40, [2, 3], True)
        convolution_default_132 = torch.ops.aten.convolution.default(mean_dim_13, primals_163, primals_162, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_162 = None
        silu__default_41 = torch.ops.aten.silu_.default(convolution_default_132)
        convolution_default_133 = torch.ops.aten.convolution.default(silu__default_41, primals_161, primals_160, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_160 = None
        sigmoid_default_13 = torch.ops.aten.sigmoid.default(convolution_default_133);  convolution_default_133 = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(silu__default_40, sigmoid_default_13)
        split_with_sizes_default_36 = torch.ops.aten.split_with_sizes.default(mul_tensor_13, [792, 792], 1);  mul_tensor_13 = None
        getitem_242 = split_with_sizes_default_36[0]
        getitem_243 = split_with_sizes_default_36[1];  split_with_sizes_default_36 = None
        convolution_default_134 = torch.ops.aten.convolution.default(getitem_242, primals_158, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_135 = torch.ops.aten.convolution.default(getitem_243, primals_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_36 = torch.ops.aten.cat.default([convolution_default_134, convolution_default_135], 1);  convolution_default_134 = convolution_default_135 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_441, 1);  primals_441 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(cat_default_36, primals_444, primals_445, primals_442, primals_443, True, 0.1, 1e-05);  primals_445 = None
        getitem_244 = native_batch_norm_default_50[0]
        getitem_245 = native_batch_norm_default_50[1]
        getitem_246 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_244, getitem_229);  getitem_244 = None
        convolution_default_136 = torch.ops.aten.convolution.default(add_tensor_62, primals_168, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_63 = torch.ops.aten.add.Tensor(primals_446, 1);  primals_446 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_136, primals_449, primals_450, primals_447, primals_448, True, 0.1, 1e-05);  primals_450 = None
        getitem_247 = native_batch_norm_default_51[0]
        getitem_248 = native_batch_norm_default_51[1]
        getitem_249 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        silu__default_42 = torch.ops.aten.silu_.default(getitem_247)
        split_with_sizes_default_37 = torch.ops.aten.split_with_sizes.default(silu__default_42, [396, 396, 396, 396], 1);  silu__default_42 = None
        getitem_250 = split_with_sizes_default_37[0]
        getitem_251 = split_with_sizes_default_37[1]
        getitem_252 = split_with_sizes_default_37[2]
        getitem_253 = split_with_sizes_default_37[3];  split_with_sizes_default_37 = None
        convolution_default_137 = torch.ops.aten.convolution.default(getitem_250, primals_164, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 396)
        convolution_default_138 = torch.ops.aten.convolution.default(getitem_251, primals_165, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 396)
        convolution_default_139 = torch.ops.aten.convolution.default(getitem_252, primals_166, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 396)
        convolution_default_140 = torch.ops.aten.convolution.default(getitem_253, primals_167, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 396)
        cat_default_37 = torch.ops.aten.cat.default([convolution_default_137, convolution_default_138, convolution_default_139, convolution_default_140], 1);  convolution_default_137 = convolution_default_138 = convolution_default_139 = convolution_default_140 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(primals_451, 1);  primals_451 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(cat_default_37, primals_454, primals_455, primals_452, primals_453, True, 0.1, 1e-05);  primals_455 = None
        getitem_254 = native_batch_norm_default_52[0]
        getitem_255 = native_batch_norm_default_52[1]
        getitem_256 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        silu__default_43 = torch.ops.aten.silu_.default(getitem_254)
        mean_dim_14 = torch.ops.aten.mean.dim(silu__default_43, [2, 3], True)
        convolution_default_141 = torch.ops.aten.convolution.default(mean_dim_14, primals_174, primals_173, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_173 = None
        silu__default_44 = torch.ops.aten.silu_.default(convolution_default_141)
        convolution_default_142 = torch.ops.aten.convolution.default(silu__default_44, primals_172, primals_171, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_171 = None
        sigmoid_default_14 = torch.ops.aten.sigmoid.default(convolution_default_142);  convolution_default_142 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(silu__default_43, sigmoid_default_14)
        split_with_sizes_default_38 = torch.ops.aten.split_with_sizes.default(mul_tensor_14, [792, 792], 1);  mul_tensor_14 = None
        getitem_257 = split_with_sizes_default_38[0]
        getitem_258 = split_with_sizes_default_38[1];  split_with_sizes_default_38 = None
        convolution_default_143 = torch.ops.aten.convolution.default(getitem_257, primals_169, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_144 = torch.ops.aten.convolution.default(getitem_258, primals_170, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_38 = torch.ops.aten.cat.default([convolution_default_143, convolution_default_144], 1);  convolution_default_143 = convolution_default_144 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(primals_456, 1);  primals_456 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(cat_default_38, primals_459, primals_460, primals_457, primals_458, True, 0.1, 1e-05);  primals_460 = None
        getitem_259 = native_batch_norm_default_53[0]
        getitem_260 = native_batch_norm_default_53[1]
        getitem_261 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(getitem_259, add_tensor_62);  getitem_259 = None
        convolution_default_145 = torch.ops.aten.convolution.default(add_tensor_66, primals_179, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_67 = torch.ops.aten.add.Tensor(primals_461, 1);  primals_461 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_145, primals_464, primals_465, primals_462, primals_463, True, 0.1, 1e-05);  primals_465 = None
        getitem_262 = native_batch_norm_default_54[0]
        getitem_263 = native_batch_norm_default_54[1]
        getitem_264 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        silu__default_45 = torch.ops.aten.silu_.default(getitem_262)
        split_with_sizes_default_39 = torch.ops.aten.split_with_sizes.default(silu__default_45, [396, 396, 396, 396], 1);  silu__default_45 = None
        getitem_265 = split_with_sizes_default_39[0]
        getitem_266 = split_with_sizes_default_39[1]
        getitem_267 = split_with_sizes_default_39[2]
        getitem_268 = split_with_sizes_default_39[3];  split_with_sizes_default_39 = None
        convolution_default_146 = torch.ops.aten.convolution.default(getitem_265, primals_175, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 396)
        convolution_default_147 = torch.ops.aten.convolution.default(getitem_266, primals_176, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 396)
        convolution_default_148 = torch.ops.aten.convolution.default(getitem_267, primals_177, None, [1, 1], [3, 3], [1, 1], False, [0, 0], 396)
        convolution_default_149 = torch.ops.aten.convolution.default(getitem_268, primals_178, None, [1, 1], [4, 4], [1, 1], False, [0, 0], 396)
        cat_default_39 = torch.ops.aten.cat.default([convolution_default_146, convolution_default_147, convolution_default_148, convolution_default_149], 1);  convolution_default_146 = convolution_default_147 = convolution_default_148 = convolution_default_149 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(primals_466, 1);  primals_466 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(cat_default_39, primals_469, primals_470, primals_467, primals_468, True, 0.1, 1e-05);  primals_470 = None
        getitem_269 = native_batch_norm_default_55[0]
        getitem_270 = native_batch_norm_default_55[1]
        getitem_271 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        silu__default_46 = torch.ops.aten.silu_.default(getitem_269)
        mean_dim_15 = torch.ops.aten.mean.dim(silu__default_46, [2, 3], True)
        convolution_default_150 = torch.ops.aten.convolution.default(mean_dim_15, primals_185, primals_184, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_184 = None
        silu__default_47 = torch.ops.aten.silu_.default(convolution_default_150)
        convolution_default_151 = torch.ops.aten.convolution.default(silu__default_47, primals_183, primals_182, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_182 = None
        sigmoid_default_15 = torch.ops.aten.sigmoid.default(convolution_default_151);  convolution_default_151 = None
        mul_tensor_15 = torch.ops.aten.mul.Tensor(silu__default_46, sigmoid_default_15)
        split_with_sizes_default_40 = torch.ops.aten.split_with_sizes.default(mul_tensor_15, [792, 792], 1);  mul_tensor_15 = None
        getitem_272 = split_with_sizes_default_40[0]
        getitem_273 = split_with_sizes_default_40[1];  split_with_sizes_default_40 = None
        convolution_default_152 = torch.ops.aten.convolution.default(getitem_272, primals_180, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        convolution_default_153 = torch.ops.aten.convolution.default(getitem_273, primals_181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        cat_default_40 = torch.ops.aten.cat.default([convolution_default_152, convolution_default_153], 1);  convolution_default_152 = convolution_default_153 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(primals_471, 1);  primals_471 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(cat_default_40, primals_474, primals_475, primals_472, primals_473, True, 0.1, 1e-05);  primals_475 = None
        getitem_274 = native_batch_norm_default_56[0]
        getitem_275 = native_batch_norm_default_56[1]
        getitem_276 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(getitem_274, add_tensor_66);  getitem_274 = None
        convolution_default_154 = torch.ops.aten.convolution.default(add_tensor_70, primals_188, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_71 = torch.ops.aten.add.Tensor(primals_476, 1);  primals_476 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_154, primals_479, primals_480, primals_477, primals_478, True, 0.1, 1e-05);  primals_480 = None
        getitem_277 = native_batch_norm_default_57[0]
        getitem_278 = native_batch_norm_default_57[1]
        getitem_279 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_277);  getitem_277 = None
        mean_dim_16 = torch.ops.aten.mean.dim(relu__default_6, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim_16, [128, 1536]);  mean_dim_16 = None
        t_default = torch.ops.aten.t.default(primals_187);  primals_187 = None
        addmm_default = torch.ops.aten.addmm.default(primals_186, view_default, t_default);  primals_186 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_4, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_11, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_22, add_tensor_23, add_tensor_24, add_tensor_26, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_30, add_tensor_31, add_tensor_33, add_tensor_34, add_tensor_35, add_tensor_37, add_tensor_38, add_tensor_39, add_tensor_41, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_45, add_tensor_46, add_tensor_48, add_tensor_49, add_tensor_50, add_tensor_52, add_tensor_53, add_tensor_54, add_tensor_56, add_tensor_57, add_tensor_58, add_tensor_59, add_tensor_60, add_tensor_61, add_tensor_63, add_tensor_64, add_tensor_65, add_tensor_67, add_tensor_68, add_tensor_69, add_tensor_71, primals_387, primals_234, getitem_160, primals_100, primals_222, getitem_58, cat_default_39, getitem_23, primals_109, primals_392, getitem_59, primals_224, primals_154, getitem_163, getitem_268, getitem_266, primals_108, primals_114, primals_110, cat_default_14, primals_116, primals_223, primals_383, mean_dim_1, primals_156, getitem_275, primals_113, primals_155, primals_382, primals_153, primals_378, getitem_159, primals_228, getitem_185, getitem_91, primals_388, getitem_112, getitem_20, getitem_269, primals_97, convolution_default_119, primals_107, cat_default_2, convolution_default_85, sigmoid_default_3, getitem_161, primals_159, primals_102, getitem_60, primals_394, getitem_21, silu__default_24, primals_229, primals_150, silu__default_4, getitem_111, primals_389, convolution_default, mean_dim_15, getitem_92, primals_111, getitem_276, primals_106, convolution_default_27, primals_384, primals_157, primals_158, getitem_110, primals_232, primals_101, getitem_265, cat_default_17, primals_112, relu__default_3, getitem_267, primals_104, primals_233, primals_99, mean_dim_8, primals_379, getitem_162, getitem_270, silu__default_5, primals_227, primals_152, primals_393, getitem_164, primals_298, getitem_131, convolution_default_105, getitem_251, primals_479, primals_477, getitem_226, primals_83, primals_247, getitem_134, convolution_default_150, primals_299, getitem_80, getitem_87, silu__default_37, getitem_246, primals_249, primals_307, primals_190, primals_308, getitem_81, getitem_102, primals_248, silu__default_46, cat_default_34, primals_259, mean_dim_6, primals_297, getitem_101, getitem_228, primals_82, primals_312, primals_302, primals_92, primals_254, getitem_121, getitem_227, getitem_14, getitem_247, primals_189, mean_dim_4, primals_123, primals_262, getitem_103, primals_253, primals_258, getitem_82, relu__default_2, getitem_248, getitem_16, mean_dim_12, getitem_79, sigmoid_default_15, getitem_252, cat_default_40, getitem_15, silu__default_32, cat_default_12, convolution_default_136, getitem_249, getitem_85, primals_303, primals_88, primals_257, primals_309, getitem_84, primals_91, getitem_12, silu__default_17, cat_default_37, getitem_271, getitem_245, primals_90, getitem_83, getitem_272, getitem_123, primals_478, getitem_250, silu__default_31, getitem_120, primals_81, cat_default_18, primals_95, primals_304, convolution_default_124, silu__default_47, getitem_273, primals_252, add_tensor_62, primals_188, primals_93, silu__default_38, primals_89, cat_default_1, sigmoid_default_5, cat_default_28, primals_94, getitem_13, add_tensor_66, primals_37, silu__default_25, primals_34, getitem_181, primals_30, convolution_default_60, getitem_107, getitem_155, silu__default_29, getitem_206, primals_444, cat_default_21, getitem_208, primals_334, getitem_279, getitem_260, cat_default_38, primals_447, relu__default_6, getitem_10, getitem_119, getitem_205, convolution_default_95, t_default, getitem_106, getitem_257, view_default, convolution_default_145, silu__default_20, primals_192, getitem_118, convolution_default_70, cat_default_32, getitem_9, silu__default_16, primals_337, getitem_117, sigmoid_default_7, silu__default_26, getitem_262, primals_36, getitem_207, getitem_243, primals_35, getitem_138, silu__default_23, getitem_204, getitem_180, primals_32, getitem_263, primals_442, primals_38, convolution_default_88, primals_448, mean_dim_5, getitem_258, sigmoid_default_6, convolution_default_86, silu__default_28, primals_39, getitem_264, sigmoid_default_8, getitem_261, getitem_154, getitem_203, mul_tensor_8, primals_443, cat_default_24, getitem_137, sigmoid_default_9, cat_default_27, primals_203, mul_tensor_4, silu__default_22, primals_202, primals_11, primals_338, primals_209, primals_2, primals_199, getitem_2, getitem_222, cat_default_5, getitem_7, primals_77, getitem_39, getitem_197, primals_197, primals_73, relu__default_1, getitem_41, primals_1, primals_332, getitem_201, primals_78, primals_12, primals_204, getitem_40, convolution_default_1, primals_322, cat_default_30, primals_5, relu__default, cat_default_31, silu__default_44, primals_13, primals_327, primals_217, getitem_223, getitem_4, primals_213, getitem_200, getitem_109, primals_6, primals_80, primals_219, getitem_8, convolution_default_141, primals_323, getitem_5, getitem_225, primals_343, primals_10, primals_76, add_tensor_10, primals_9, sigmoid_default_10, primals_7, primals_4, primals_207, primals_8, primals_218, primals_208, silu__default_14, getitem_43, getitem_198, primals_324, sigmoid_default_4, primals_342, getitem_42, getitem_202, primals_3, primals_344, convolution_default_2, primals_329, getitem_38, getitem_153, primals_79, primals_214, primals_75, getitem_44, getitem_108, primals_333, primals_212, primals_328, getitem_224, primals_339, primals_198, cat_default, convolution_default_80, sigmoid_default_14, getitem_235, primals_179, primals_348, getitem_177, getitem_191, primals_469, getitem_148, getitem_238, primals_347, add_tensor_40, getitem_171, convolution_default_84, getitem_210, getitem_241, getitem_143, getitem_157, primals_180, getitem_90, getitem_240, primals_194, getitem_158, cat_default_26, getitem_209, getitem_147, getitem_152, primals_349, getitem_89, getitem_141, getitem_150, primals_174, getitem_151, primals_474, getitem_195, primals_473, getitem_239, primals_176, mean_dim_10, primals_472, primals_172, getitem_88, mean_dim_7, convolution_default_154, primals_183, primals_353, primals_178, primals_181, cat_default_23, getitem_174, getitem_196, primals_175, primals_352, getitem_170, primals_357, getitem_169, primals_468, primals_359, getitem_192, add_tensor_70, getitem_237, getitem_145, getitem_234, getitem_146, getitem_142, cat_default_22, getitem_149, primals_354, getitem_144, primals_161, primals_185, getitem_236, getitem_140, getitem_173, getitem_194, primals_193, mean_dim_13, getitem_172, primals_177, mean_dim_3, getitem_193, primals_358, primals_133, primals_278, getitem_230, primals_277, primals_124, convolution_default_47, primals_125, cat_default_15, primals_288, primals_417, getitem_211, primals_49, primals_263, getitem_233, mean_dim_9, getitem_100, convolution_default_53, convolution_default_115, primals_314, primals_47, getitem_25, primals_48, primals_267, getitem_99, primals_54, primals_137, primals_44, primals_269, cat_default_33, primals_414, getitem_214, primals_413, getitem_212, primals_369, getitem_97, primals_136, primals_319, primals_264, mean_dim_11, primals_273, primals_412, silu__default_34, cat_default_13, sigmoid_default_12, primals_131, primals_284, getitem_19, primals_45, getitem_95, primals_126, primals_294, primals_318, primals_364, primals_292, primals_52, primals_374, getitem_26, add_tensor_25, primals_268, getitem_24, primals_50, primals_274, primals_142, getitem_1, primals_40, primals_372, primals_135, primals_132, getitem_94, primals_422, primals_42, primals_130, primals_279, primals_362, primals_423, primals_418, cat_default_3, silu__default_35, primals_128, primals_373, getitem_179, getitem_98, sigmoid_default_11, getitem_231, convolution_default_127, primals_55, primals_363, primals_368, getitem_215, convolution_default_126, getitem_232, cat_default_35, mul_tensor_12, primals_293, getitem_229, getitem_278, primals_313, getitem_213, primals_287, primals_134, primals_283, getitem_18, primals_367, primals_140, primals_317, primals_282, primals_377, getitem_96, primals_138, primals_419, primals_46, getitem_178, primals_289, primals_272, primals_120, primals_398, primals_453, getitem_45, primals_449, primals_467, cat_default_19, getitem_127, primals_243, getitem_124, primals_403, getitem_86, getitem_129, silu__default_7, mean_dim_14, getitem_256, primals_458, primals_464, convolution_default_43, getitem_253, primals_404, primals_462, convolution_default_35, getitem_114, primals_454, primals_238, silu__default_10, silu__default_11, primals_407, silu__default_8, getitem_130, cat_default_20, primals_242, primals_397, primals_119, getitem_113, getitem_125, primals_409, cat_default_29, getitem_254, primals_399, primals_452, mean_dim, primals_118, primals_402, primals_459, getitem_190, sigmoid_default_2, sigmoid_default_13, primals_239, primals_463, getitem_128, getitem_126, primals_85, getitem_76, getitem_189, cat_default_11, primals_122, primals_408, primals_121, getitem_46, getitem_71, getitem_77, silu__default_40, primals_237, primals_87, getitem_47, primals_244, getitem_255, silu__default_43, primals_457, getitem_188, primals_166, getitem_49, primals_437, primals_429, getitem_33, primals_17, getitem_50, getitem_184, cat_default_4, getitem_51, getitem_70, getitem_219, primals_29, getitem_61, primals_147, primals_20, convolution_default_15, getitem_116, primals_63, getitem_167, relu__default_5, getitem_68, primals_144, convolution_default_12, silu__default_1, primals_69, getitem_32, getitem_62, primals_439, primals_24, relu__default_4, primals_65, getitem_52, primals_71, cat_default_16, silu__default_19, primals_16, getitem_34, getitem_132, getitem_28, primals_67, sigmoid_default_1, primals_427, convolution_default_20, getitem_175, primals_64, primals_27, getitem_218, primals_26, primals_56, primals_146, primals_18, convolution_default_51, getitem_133, getitem_69, getitem_217, primals_14, getitem_31, getitem_135, getitem_136, getitem_166, getitem_54, primals_19, primals_61, primals_433, primals_424, getitem_37, silu__default_2, primals_170, cat_default_6, getitem_64, primals_438, getitem_53, cat_default_8, primals_165, silu__default_13, getitem_66, cat_default_10, getitem_115, primals_22, primals_169, getitem_72, getitem_176, getitem_187, silu__default_41, getitem_168, primals_57, cat_default_36, primals_25, primals_148, primals_58, primals_428, primals_59, mul_tensor, getitem_57, mean_dim_2, primals_434, convolution_default_132, sigmoid_default, getitem_183, getitem_29, primals_70, getitem_55, getitem_74, getitem_36, getitem_65, getitem_104, cat_default_25, getitem_186, getitem_221, primals_28, primals_68, cat_default_9, getitem_67, primals_66, primals_15, convolution_default_22, getitem_73, primals_168, getitem_220, getitem_242, primals_143, primals_145, primals_164, getitem_56, getitem_75, primals_432, cat_default_7, add_tensor_55, primals_163, primals_167]
        
