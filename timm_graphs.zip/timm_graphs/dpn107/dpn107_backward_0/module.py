
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/dpn107/dpn107_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_330, primals_459, primals_458, primals_329, primals_333, primals_328, primals_460, primals_334, primals_335, getitem_175, getitem_193, getitem_58, primals_33, relu__default_57, cat_default_11, relu__default_63, getitem_57, getitem_192, primals_32, cat_default_37, primals_28, primals_35, getitem_177, getitem_178, getitem_195, primals_34, cat_default_41, relu__default_18, getitem_196, primals_30, convolution_default_18, primals_37, getitem_61, getitem_60, primals_38, primals_31, primals_29, relu__default_58, primals_36, primals_39, relu__default_19, relu__default_64, convolution_default_58, convolution_default_19, convolution_default_64, primals_178, primals_359, primals_364, primals_363, primals_188, primals_360, cat_default_1, primals_365, primals_175, primals_185, primals_184, primals_180, primals_355, primals_183, primals_354, relu__default_5, convolution_default, primals_368, primals_358, relu__default_3, primals_179, primals_409, primals_495, getitem_76, primals_488, primals_415, getitem_10, primals_490, primals_425, primals_414, getitem_75, primals_408, primals_423, primals_489, cat_default_15, primals_483, primals_493, primals_413, primals_419, primals_410, relu__default_24, primals_424, convolution_default_24, primals_494, getitem_78, primals_420, primals_484, primals_405, getitem_79, relu__default_25, primals_418, primals_485, convolution_default_25, getitem_112, getitem_111, getitem_210, getitem_94, getitem_211, cat_default_23, getitem_334, getitem_333, getitem_93, cat_default_19, relu__default_69, getitem_213, cat_default_45, getitem_214, relu__default_30, convolution_default_30, relu__default_36, getitem_96, convolution_default_36, relu__default, getitem_114, getitem_25, getitem_97, cat_default_3, getitem_2, relu__default_31, getitem_115, relu__default_70, relu__default_37, convolution_default_31, convolution_default_37, convolution_default_70, getitem_1, getitem_229, primals_658, relu__default_100, getitem_228, primals_534, primals_269, primals_655, primals_654, primals_278, primals_528, primals_274, primals_270, cat_default_65, relu__default_75, getitem_306, primals_664, primals_524, primals_659, primals_535, getitem_231, cat_default_49, primals_533, getitem_232, getitem_307, primals_663, primals_660, primals_529, relu__default_101, primals_665, primals_268, convolution_default_101, primals_265, primals_525, primals_530, primals_273, convolution_default_76, relu__default_76, primals_538, primals_275, primals_60, getitem_294, cat_default_63, primals_403, primals_314, getitem_295, primals_398, primals_55, primals_59, primals_400, primals_325, primals_319, primals_323, primals_53, primals_320, relu__default_97, primals_324, primals_56, primals_318, convolution_default_97, primals_54, primals_404, getitem_297, primals_399, primals_313, primals_57, primals_58, primals_395, getitem_298, primals_315, primals_111, primals_199, primals_195, primals_109, primals_189, primals_194, primals_198, primals_108, primals_200, primals_110, primals_193, primals_190, getitem_127, primals_303, getitem_247, relu__default_41, getitem_265, convolution_default_41, getitem_246, getitem_264, primals_299, relu__default_81, getitem_130, getitem_129, relu__default_87, primals_309, primals_304, getitem_249, relu__default_42, getitem_267, cat_default_53, getitem_250, primals_310, cat_default_57, cat_default_27, primals_300, primals_305, primals_298, primals_308, getitem_268, relu__default_82, convolution_default_82, primals_14, primals_209, primals_263, primals_15, primals_213, primals_214, primals_215, primals_17, primals_208, primals_264, primals_13, primals_205, primals_204, primals_210, primals_203, primals_218, primals_16, primals_219, primals_220, primals_294, getitem_145, relu__default_106, relu__default_47, convolution_default_47, cat_default_69, getitem_324, getitem_148, getitem_325, getitem_147, relu__default_48, primals_293, cat_default_31, relu__default_107, primals_295, convolution_default_107, getitem_162, getitem_19, getitem_163, primals_553, getitem_18, getitem_4, getitem_45, getitem_46, relu__default_53, convolution_default_53, relu__default_14, primals_560, primals_394, primals_435, primals_388, getitem_166, getitem_165, primals_390, getitem_48, primals_433, primals_393, relu__default_54, primals_554, primals_389, primals_555, cat_default_9, primals_559, primals_429, getitem_49, primals_558, primals_428, getitem_3, convolution_default_15, relu__default_15, primals_430, primals_434, getitem_64, getitem_180, getitem_63, primals_474, getitem_181, primals_224, relu__default_59, relu__default_20, convolution_default_59, primals_128, primals_229, primals_480, primals_479, primals_228, primals_473, getitem_184, getitem_183, getitem_66, cat_default_13, getitem_67, primals_233, relu__default_60, primals_46, primals_230, primals_478, primals_475, primals_225, primals_129, primals_130, primals_234, convolution_default_21, primals_223, relu__default_21, primals_235, getitem_82, getitem_81, primals_369, relu__default_26, primals_370, getitem_84, cat_default_17, getitem_85, relu__default_27, convolution_default_27, getitem_199, getitem_217, getitem_198, getitem_216, relu__default_65, relu__default_71, convolution_default_65, convolution_default_71, getitem_202, getitem_201, getitem_220, getitem_219, relu__default_66, relu__default_72, getitem_24, getitem_100, getitem_235, getitem_99, getitem_234, getitem_283, getitem_282, relu__default_32, relu__default_77, relu__default_93, convolution_default_77, getitem_102, getitem_238, cat_default_21, getitem_237, getitem_16, primals_614, relu__default_78, cat_default_61, primals_615, primals_613, getitem_103, getitem_285, getitem_286, primals_67, primals_148, primals_71, primals_74, primals_62, primals_150, primals_73, primals_64, primals_66, primals_69, primals_72, primals_153, primals_68, primals_65, primals_63, primals_143, primals_145, convolution_default_5, primals_149, primals_70, primals_61, primals_144, getitem_309, getitem_310, relu__default_102, getitem_118, getitem_117, convolution_default_102, getitem_313, getitem_312, relu__default_38, relu__default_103, cat_default_67, getitem_121, getitem_120, relu__default_39, primals_373, primals_285, primals_290, primals_289, primals_375, primals_445, primals_438, primals_284, primals_443, primals_288, primals_444, primals_440, primals_374, primals_439, getitem_132, primals_115, getitem_133, primals_119, primals_114, primals_125, relu__default_43, getitem_253, getitem_252, convolution_default_43, primals_113, getitem_36, cat_default_7, getitem_136, primals_120, getitem_135, relu__default_83, convolution_default_11, primals_123, convolution_default_83, relu__default_11, relu__default_44, getitem_256, primals_118, getitem_255, getitem_37, convolution_default_44, primals_51, primals_50, primals_52, primals_49, relu__default_10, getitem_138, relu__default_1, relu__default_84, primals_48, primals_47, primals_124, getitem_139, getitem_7, getitem_6, primals_450, primals_519, getitem_150, getitem_151, primals_454, primals_455, relu__default_49, primals_509, primals_510, convolution_default_49, primals_453, primals_518, getitem_154, getitem_153, primals_505, primals_449, primals_514, primals_523, primals_520, primals_515, relu__default_50, primals_513, convolution_default_50, primals_508, getitem_156, getitem_157, primals_504, primals_448, relu__default_8, getitem_169, cat_default_35, getitem_27, getitem_168, getitem_28, convolution_default_8, relu__default_55, relu__default_9, convolution_default_55, getitem_31, getitem_30, getitem_172, getitem_171, convolution_default_9, relu__default_56, convolution_default_56, getitem_33, getitem_174, getitem_34, getitem_327, relu__default_88, primals_283, convolution_default_88, getitem_328, getitem_52, getitem_51, relu__default_108, getitem_271, convolution_default_108, getitem_270, primals_625, primals_618, primals_620, relu__default_16, getitem_331, primals_628, getitem_332, getitem_330, convolution_default_16, relu__default_89, getitem_273, getitem_55, convolution_default_89, primals_623, getitem_54, relu__default_109, primals_619, primals_280, getitem_274, primals_279, relu__default_17, primals_624, relu__default_90, primals_97, primals_134, getitem_187, relu__default_98, getitem_205, convolution_default_98, getitem_186, primals_139, cat_default_43, primals_100, primals_138, getitem_13, cat_default_39, primals_99, getitem_204, getitem_301, getitem_300, primals_96, relu__default_61, primals_140, convolution_default_61, relu__default_67, convolution_default_67, getitem_12, relu__default_99, getitem_190, getitem_189, convolution_default_3, getitem_208, getitem_207, primals_95, getitem_304, relu__default_62, primals_133, primals_93, relu__default_68, convolution_default_62, primals_98, convolution_default_68, primals_135, primals_94, getitem_303, getitem_223, cat_default_47, getitem_222, primals_350, relu__default_73, convolution_default_73, primals_353, getitem_226, getitem_225, relu__default_74, convolution_default_74, primals_644, primals_89, getitem_70, primals_87, getitem_69, primals_643, primals_91, relu__default_22, convolution_default_22, primals_90, primals_638, primals_86, getitem_73, getitem_72, primals_640, primals_639, relu__default_23, primals_88, primals_92, primals_645, primals_569, primals_648, getitem_241, convolution_default_2, getitem_240, primals_379, primals_564, getitem_88, getitem_9, cat_default_51, getitem_87, primals_574, primals_384, primals_259, primals_385, primals_254, primals_260, primals_503, primals_650, primals_383, primals_575, relu__default_28, primals_565, primals_500, primals_378, relu__default_79, convolution_default_28, convolution_default_79, getitem_243, primals_498, primals_499, getitem_91, primals_563, getitem_90, primals_380, primals_568, primals_570, primals_255, getitem_244, primals_578, primals_653, relu__default_29, relu__default_80, primals_258, primals_649, primals_579, convolution_default_80, primals_573, primals_598, primals_1, relu__default_33, convolution_default_33, primals_9, primals_593, primals_5, primals_103, primals_599, getitem_106, primals_104, primals_10, primals_106, getitem_105, primals_3, primals_603, primals_102, primals_6, relu__default_34, primals_604, primals_609, getitem_108, primals_595, convolution_default_34, primals_105, primals_610, primals_4, primals_8, primals_605, primals_7, getitem_109, cat_default_5, primals_12, primals_107, primals_11, relu__default_35, primals_608, primals_2, primals_101, primals_594, primals_600, getitem_316, getitem_315, relu__default_94, primals_45, convolution_default_94, primals_43, cat_default_25, relu__default_104, getitem_123, getitem_289, convolution_default_104, getitem_288, primals_40, getitem_319, getitem_318, primals_41, relu__default_95, getitem_124, primals_42, getitem_291, convolution_default_95, relu__default_105, relu__default_40, convolution_default_105, relu__default_7, primals_44, convolution_default_40, getitem_292, relu__default_96, getitem_321, getitem_322, getitem_126, primals_80, primals_544, primals_22, relu__default_4, primals_26, getitem_259, relu__default_2, primals_588, primals_82, primals_585, getitem_258, primals_549, primals_25, primals_540, cat_default_55, primals_83, primals_633, primals_590, primals_548, primals_629, primals_84, primals_583, primals_75, primals_539, primals_76, primals_580, primals_18, convolution_default_6, getitem_21, primals_79, primals_24, relu__default_85, convolution_default_85, primals_543, primals_545, primals_77, getitem_261, primals_630, primals_78, primals_550, primals_584, primals_81, getitem_262, primals_589, primals_21, primals_85, primals_635, primals_634, relu__default_86, primals_20, relu__default_6, primals_19, convolution_default_86, primals_27, getitem_22, primals_23, relu__default_45, relu__default_51, cat_default_33, getitem_141, cat_default_29, getitem_142, getitem_159, getitem_160, relu__default_46, relu__default_52, convolution_default_46, convolution_default_52, primals_339, primals_348, getitem_144, primals_174, getitem_277, primals_464, getitem_39, getitem_276, primals_245, primals_240, primals_163, cat_default_59, primals_164, primals_253, primals_344, relu__default_12, getitem_40, primals_165, convolution_default_12, primals_349, primals_168, primals_238, getitem_43, primals_343, primals_338, getitem_42, primals_160, primals_243, primals_249, primals_159, relu__default_91, primals_468, primals_158, relu__default_13, convolution_default_91, getitem_279, primals_239, primals_250, primals_170, getitem_15, primals_469, primals_169, primals_470, primals_465, primals_173, primals_155, primals_463, primals_154, primals_248, primals_345, getitem_280, primals_340, relu__default_92, convolution_default_92, primals_244, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50, tangents_51, tangents_52, tangents_53, tangents_54, tangents_55, tangents_56, tangents_57, tangents_58, tangents_59, tangents_60, tangents_61, tangents_62, tangents_63, tangents_64, tangents_65, tangents_66, tangents_67, tangents_68, tangents_69, tangents_70, tangents_71, tangents_72, tangents_73, tangents_74, tangents_75, tangents_76, tangents_77, tangents_78, tangents_79, tangents_80, tangents_81, tangents_82, tangents_83, tangents_84, tangents_85, tangents_86, tangents_87, tangents_88, tangents_89, tangents_90, tangents_91, tangents_92, tangents_93, tangents_94, tangents_95, tangents_96, tangents_97, tangents_98, tangents_99, tangents_100, tangents_101, tangents_102, tangents_103, tangents_104, tangents_105, tangents_106, tangents_107, tangents_108, tangents_109, tangents_110, tangents_111, tangents_112):
        to_dtype_2 = torch.ops.aten.to.dtype(tangents_1, torch.float32);  tangents_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_332, torch.float32);  getitem_332 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_3, 0)
        mul_tensor_3 = torch.ops.aten.mul.Tensor(to_dtype_2, 1)
        mul_tensor_4 = torch.ops.aten.mul.Tensor(mul_tensor_3, 1.0);  mul_tensor_3 = None
        mul_tensor_5 = torch.ops.aten.mul.Tensor(to_dtype_3, 1);  to_dtype_3 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_5);  mul_tensor_5 = None
        mul_tensor_6 = torch.ops.aten.mul.Tensor(mul_tensor_4, exp_default_1);  mul_tensor_4 = exp_default_1 = None
        mul_tensor_7 = torch.ops.aten.mul.Tensor(to_dtype_2, 1);  to_dtype_2 = None
        where_self_1 = torch.ops.aten.where.self(le_scalar, mul_tensor_6, mul_tensor_7);  le_scalar = mul_tensor_6 = mul_tensor_7 = None
        to_dtype_4 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_4, cat_default_69, primals_665, primals_663, primals_664, getitem_333, getitem_334, True, 0.001, [True, True, True]);  to_dtype_4 = cat_default_69 = primals_665 = primals_663 = primals_664 = getitem_333 = getitem_334 = None
        getitem_335 = native_batch_norm_backward_default[0]
        getitem_336 = native_batch_norm_backward_default[1]
        getitem_337 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        slice_tensor_312 = torch.ops.aten.slice.Tensor(getitem_335, 1, 0, 2048)
        slice_tensor_313 = torch.ops.aten.slice.Tensor(getitem_335, 1, 2048, 2688);  getitem_335 = None
        slice_tensor_314 = torch.ops.aten.slice.Tensor(slice_tensor_313, 1, 0, 512)
        slice_tensor_315 = torch.ops.aten.slice.Tensor(slice_tensor_313, 1, 512, 640);  slice_tensor_313 = None
        slice_backward_default = torch.ops.aten.slice_backward.default(slice_tensor_315, [64, 128, 7, 7], 3, 0, 9223372036854775807, 1);  slice_tensor_315 = None
        slice_backward_default_1 = torch.ops.aten.slice_backward.default(slice_backward_default, [64, 128, 7, 7], 2, 0, 9223372036854775807, 1);  slice_backward_default = None
        slice_backward_default_2 = torch.ops.aten.slice_backward.default(slice_backward_default_1, [64, 2176, 7, 7], 1, 2048, 9223372036854775807, 1);  slice_backward_default_1 = None
        slice_backward_default_3 = torch.ops.aten.slice_backward.default(slice_backward_default_2, [64, 2176, 7, 7], 0, 0, 9223372036854775807, 1);  slice_backward_default_2 = None
        slice_backward_default_4 = torch.ops.aten.slice_backward.default(slice_tensor_312, [64, 2048, 7, 7], 3, 0, 9223372036854775807, 1)
        slice_backward_default_5 = torch.ops.aten.slice_backward.default(slice_backward_default_4, [64, 2048, 7, 7], 2, 0, 9223372036854775807, 1);  slice_backward_default_4 = None
        slice_backward_default_6 = torch.ops.aten.slice_backward.default(slice_backward_default_5, [64, 2176, 7, 7], 1, 0, 2048, 1);  slice_backward_default_5 = None
        slice_backward_default_7 = torch.ops.aten.slice_backward.default(slice_backward_default_6, [64, 2176, 7, 7], 0, 0, 9223372036854775807, 1);  slice_backward_default_6 = None
        add_tensor_146 = torch.ops.aten.add.Tensor(slice_backward_default_3, slice_backward_default_7);  slice_backward_default_3 = slice_backward_default_7 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(add_tensor_146, relu__default_109, primals_87, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_146 = primals_87 = None
        getitem_338 = convolution_backward_default[0]
        getitem_339 = convolution_backward_default[1];  convolution_backward_default = None
        to_dtype_5 = torch.ops.aten.to.dtype(getitem_338, torch.float32);  getitem_338 = None
        to_dtype_6 = torch.ops.aten.to.dtype(relu__default_109, torch.float32);  relu__default_109 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_6, 0);  to_dtype_6 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(to_dtype_5, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_111, to_dtype_5);  le_scalar_1 = new_zeros_default_111 = to_dtype_5 = None
        to_dtype_7 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_7, convolution_default_108, primals_660, primals_658, primals_659, getitem_330, getitem_331, True, 0.001, [True, True, True]);  to_dtype_7 = convolution_default_108 = primals_660 = primals_658 = primals_659 = getitem_330 = getitem_331 = None
        getitem_341 = native_batch_norm_backward_default_1[0]
        getitem_342 = native_batch_norm_backward_default_1[1]
        getitem_343 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_341, relu__default_108, primals_88, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_341 = primals_88 = None
        getitem_344 = convolution_backward_default_1[0]
        getitem_345 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        to_dtype_8 = torch.ops.aten.to.dtype(getitem_344, torch.float32);  getitem_344 = None
        to_dtype_9 = torch.ops.aten.to.dtype(relu__default_108, torch.float32);  relu__default_108 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_9, 0);  to_dtype_9 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(to_dtype_8, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_112, to_dtype_8);  le_scalar_2 = new_zeros_default_112 = to_dtype_8 = None
        to_dtype_10 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_10, convolution_default_107, primals_655, primals_653, primals_654, getitem_327, getitem_328, True, 0.001, [True, True, True]);  to_dtype_10 = convolution_default_107 = primals_655 = primals_653 = primals_654 = getitem_327 = getitem_328 = None
        getitem_347 = native_batch_norm_backward_default_2[0]
        getitem_348 = native_batch_norm_backward_default_2[1]
        getitem_349 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_347, relu__default_107, primals_86, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_347 = primals_86 = None
        getitem_350 = convolution_backward_default_2[0]
        getitem_351 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_11 = torch.ops.aten.to.dtype(getitem_350, torch.float32);  getitem_350 = None
        to_dtype_12 = torch.ops.aten.to.dtype(relu__default_107, torch.float32);  relu__default_107 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_12, 0);  to_dtype_12 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(to_dtype_11, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_113, to_dtype_11);  le_scalar_3 = new_zeros_default_113 = to_dtype_11 = None
        to_dtype_13 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_13, cat_default_67, primals_650, primals_648, primals_649, getitem_324, getitem_325, True, 0.001, [True, True, True]);  to_dtype_13 = cat_default_67 = primals_650 = primals_648 = primals_649 = getitem_324 = getitem_325 = None
        getitem_353 = native_batch_norm_backward_default_3[0]
        getitem_354 = native_batch_norm_backward_default_3[1]
        getitem_355 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        slice_tensor_316 = torch.ops.aten.slice.Tensor(getitem_353, 1, 0, 2048)
        slice_tensor_317 = torch.ops.aten.slice.Tensor(getitem_353, 1, 2048, 2560);  getitem_353 = None
        add_tensor_147 = torch.ops.aten.add.Tensor(slice_tensor_312, slice_tensor_316);  slice_tensor_312 = slice_tensor_316 = None
        add_tensor_148 = torch.ops.aten.add.Tensor(slice_tensor_314, slice_tensor_317);  slice_tensor_314 = slice_tensor_317 = None
        slice_tensor_318 = torch.ops.aten.slice.Tensor(add_tensor_148, 1, 0, 384)
        slice_tensor_319 = torch.ops.aten.slice.Tensor(add_tensor_148, 1, 384, 512);  add_tensor_148 = None
        slice_backward_default_8 = torch.ops.aten.slice_backward.default(slice_tensor_319, [64, 128, 7, 7], 3, 0, 9223372036854775807, 1);  slice_tensor_319 = None
        slice_backward_default_9 = torch.ops.aten.slice_backward.default(slice_backward_default_8, [64, 128, 7, 7], 2, 0, 9223372036854775807, 1);  slice_backward_default_8 = None
        slice_backward_default_10 = torch.ops.aten.slice_backward.default(slice_backward_default_9, [64, 2176, 7, 7], 1, 2048, 9223372036854775807, 1);  slice_backward_default_9 = None
        slice_backward_default_11 = torch.ops.aten.slice_backward.default(slice_backward_default_10, [64, 2176, 7, 7], 0, 0, 9223372036854775807, 1);  slice_backward_default_10 = None
        slice_backward_default_12 = torch.ops.aten.slice_backward.default(add_tensor_147, [64, 2048, 7, 7], 3, 0, 9223372036854775807, 1)
        slice_backward_default_13 = torch.ops.aten.slice_backward.default(slice_backward_default_12, [64, 2048, 7, 7], 2, 0, 9223372036854775807, 1);  slice_backward_default_12 = None
        slice_backward_default_14 = torch.ops.aten.slice_backward.default(slice_backward_default_13, [64, 2176, 7, 7], 1, 0, 2048, 1);  slice_backward_default_13 = None
        slice_backward_default_15 = torch.ops.aten.slice_backward.default(slice_backward_default_14, [64, 2176, 7, 7], 0, 0, 9223372036854775807, 1);  slice_backward_default_14 = None
        add_tensor_149 = torch.ops.aten.add.Tensor(slice_backward_default_11, slice_backward_default_15);  slice_backward_default_11 = slice_backward_default_15 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(add_tensor_149, relu__default_106, primals_84, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_149 = primals_84 = None
        getitem_356 = convolution_backward_default_3[0]
        getitem_357 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_14 = torch.ops.aten.to.dtype(getitem_356, torch.float32);  getitem_356 = None
        to_dtype_15 = torch.ops.aten.to.dtype(relu__default_106, torch.float32);  relu__default_106 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_15, 0);  to_dtype_15 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(to_dtype_14, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_114, to_dtype_14);  le_scalar_4 = new_zeros_default_114 = to_dtype_14 = None
        to_dtype_16 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_16, convolution_default_105, primals_645, primals_643, primals_644, getitem_321, getitem_322, True, 0.001, [True, True, True]);  to_dtype_16 = convolution_default_105 = primals_645 = primals_643 = primals_644 = getitem_321 = getitem_322 = None
        getitem_359 = native_batch_norm_backward_default_4[0]
        getitem_360 = native_batch_norm_backward_default_4[1]
        getitem_361 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_359, relu__default_105, primals_85, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_359 = primals_85 = None
        getitem_362 = convolution_backward_default_4[0]
        getitem_363 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        to_dtype_17 = torch.ops.aten.to.dtype(getitem_362, torch.float32);  getitem_362 = None
        to_dtype_18 = torch.ops.aten.to.dtype(relu__default_105, torch.float32);  relu__default_105 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_18, 0);  to_dtype_18 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(to_dtype_17, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_115, to_dtype_17);  le_scalar_5 = new_zeros_default_115 = to_dtype_17 = None
        to_dtype_19 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_19, convolution_default_104, primals_640, primals_638, primals_639, getitem_318, getitem_319, True, 0.001, [True, True, True]);  to_dtype_19 = convolution_default_104 = primals_640 = primals_638 = primals_639 = getitem_318 = getitem_319 = None
        getitem_365 = native_batch_norm_backward_default_5[0]
        getitem_366 = native_batch_norm_backward_default_5[1]
        getitem_367 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_365, relu__default_104, primals_83, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_365 = primals_83 = None
        getitem_368 = convolution_backward_default_5[0]
        getitem_369 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_20 = torch.ops.aten.to.dtype(getitem_368, torch.float32);  getitem_368 = None
        to_dtype_21 = torch.ops.aten.to.dtype(relu__default_104, torch.float32);  relu__default_104 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_21, 0);  to_dtype_21 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(to_dtype_20, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_116, to_dtype_20);  le_scalar_6 = new_zeros_default_116 = to_dtype_20 = None
        to_dtype_22 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_22, cat_default_65, primals_635, primals_633, primals_634, getitem_315, getitem_316, True, 0.001, [True, True, True]);  to_dtype_22 = cat_default_65 = primals_635 = primals_633 = primals_634 = getitem_315 = getitem_316 = None
        getitem_371 = native_batch_norm_backward_default_6[0]
        getitem_372 = native_batch_norm_backward_default_6[1]
        getitem_373 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        slice_tensor_320 = torch.ops.aten.slice.Tensor(getitem_371, 1, 0, 2048)
        slice_tensor_321 = torch.ops.aten.slice.Tensor(getitem_371, 1, 2048, 2432);  getitem_371 = None
        add_tensor_150 = torch.ops.aten.add.Tensor(add_tensor_147, slice_tensor_320);  add_tensor_147 = slice_tensor_320 = None
        add_tensor_151 = torch.ops.aten.add.Tensor(slice_tensor_318, slice_tensor_321);  slice_tensor_318 = slice_tensor_321 = None
        slice_tensor_322 = torch.ops.aten.slice.Tensor(add_tensor_151, 1, 0, 256)
        slice_tensor_323 = torch.ops.aten.slice.Tensor(add_tensor_151, 1, 256, 384);  add_tensor_151 = None
        slice_backward_default_16 = torch.ops.aten.slice_backward.default(slice_tensor_323, [64, 128, 7, 7], 3, 0, 9223372036854775807, 1);  slice_tensor_323 = None
        slice_backward_default_17 = torch.ops.aten.slice_backward.default(slice_backward_default_16, [64, 128, 7, 7], 2, 0, 9223372036854775807, 1);  slice_backward_default_16 = None
        slice_backward_default_18 = torch.ops.aten.slice_backward.default(slice_backward_default_17, [64, 2176, 7, 7], 1, 2048, 9223372036854775807, 1);  slice_backward_default_17 = None
        slice_backward_default_19 = torch.ops.aten.slice_backward.default(slice_backward_default_18, [64, 2176, 7, 7], 0, 0, 9223372036854775807, 1);  slice_backward_default_18 = None
        slice_backward_default_20 = torch.ops.aten.slice_backward.default(add_tensor_150, [64, 2048, 7, 7], 3, 0, 9223372036854775807, 1)
        slice_backward_default_21 = torch.ops.aten.slice_backward.default(slice_backward_default_20, [64, 2048, 7, 7], 2, 0, 9223372036854775807, 1);  slice_backward_default_20 = None
        slice_backward_default_22 = torch.ops.aten.slice_backward.default(slice_backward_default_21, [64, 2176, 7, 7], 1, 0, 2048, 1);  slice_backward_default_21 = None
        slice_backward_default_23 = torch.ops.aten.slice_backward.default(slice_backward_default_22, [64, 2176, 7, 7], 0, 0, 9223372036854775807, 1);  slice_backward_default_22 = None
        add_tensor_152 = torch.ops.aten.add.Tensor(slice_backward_default_19, slice_backward_default_23);  slice_backward_default_19 = slice_backward_default_23 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(add_tensor_152, relu__default_103, primals_80, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_152 = primals_80 = None
        getitem_374 = convolution_backward_default_6[0]
        getitem_375 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        to_dtype_23 = torch.ops.aten.to.dtype(getitem_374, torch.float32);  getitem_374 = None
        to_dtype_24 = torch.ops.aten.to.dtype(relu__default_103, torch.float32);  relu__default_103 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_24, 0);  to_dtype_24 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(to_dtype_23, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_117, to_dtype_23);  le_scalar_7 = new_zeros_default_117 = to_dtype_23 = None
        to_dtype_25 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_25, convolution_default_102, primals_630, primals_628, primals_629, getitem_312, getitem_313, True, 0.001, [True, True, True]);  to_dtype_25 = convolution_default_102 = primals_630 = primals_628 = primals_629 = getitem_312 = getitem_313 = None
        getitem_377 = native_batch_norm_backward_default_7[0]
        getitem_378 = native_batch_norm_backward_default_7[1]
        getitem_379 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_377, relu__default_102, primals_82, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_377 = primals_82 = None
        getitem_380 = convolution_backward_default_7[0]
        getitem_381 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        to_dtype_26 = torch.ops.aten.to.dtype(getitem_380, torch.float32);  getitem_380 = None
        to_dtype_27 = torch.ops.aten.to.dtype(relu__default_102, torch.float32);  relu__default_102 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_27, 0);  to_dtype_27 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(to_dtype_26, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_118, to_dtype_26);  le_scalar_8 = new_zeros_default_118 = to_dtype_26 = None
        to_dtype_28 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_28, convolution_default_101, primals_625, primals_623, primals_624, getitem_309, getitem_310, True, 0.001, [True, True, True]);  to_dtype_28 = convolution_default_101 = primals_625 = primals_623 = primals_624 = getitem_309 = getitem_310 = None
        getitem_383 = native_batch_norm_backward_default_8[0]
        getitem_384 = native_batch_norm_backward_default_8[1]
        getitem_385 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_383, relu__default_101, primals_79, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_383 = primals_79 = None
        getitem_386 = convolution_backward_default_8[0]
        getitem_387 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        to_dtype_29 = torch.ops.aten.to.dtype(getitem_386, torch.float32);  getitem_386 = None
        to_dtype_30 = torch.ops.aten.to.dtype(relu__default_101, torch.float32);  relu__default_101 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_30, 0);  to_dtype_30 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(to_dtype_29, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_119, to_dtype_29);  le_scalar_9 = new_zeros_default_119 = to_dtype_29 = None
        to_dtype_31 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_31, cat_default_63, primals_620, primals_618, primals_619, getitem_306, getitem_307, True, 0.001, [True, True, True]);  to_dtype_31 = primals_620 = primals_618 = primals_619 = getitem_306 = getitem_307 = None
        getitem_389 = native_batch_norm_backward_default_9[0]
        getitem_390 = native_batch_norm_backward_default_9[1]
        getitem_391 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        slice_backward_default_24 = torch.ops.aten.slice_backward.default(slice_tensor_322, [64, 256, 7, 7], 3, 0, 9223372036854775807, 1);  slice_tensor_322 = None
        slice_backward_default_25 = torch.ops.aten.slice_backward.default(slice_backward_default_24, [64, 256, 7, 7], 2, 0, 9223372036854775807, 1);  slice_backward_default_24 = None
        slice_backward_default_26 = torch.ops.aten.slice_backward.default(slice_backward_default_25, [64, 2304, 7, 7], 1, 2048, 9223372036854775807, 1);  slice_backward_default_25 = None
        slice_backward_default_27 = torch.ops.aten.slice_backward.default(slice_backward_default_26, [64, 2304, 7, 7], 0, 0, 9223372036854775807, 1);  slice_backward_default_26 = None
        slice_backward_default_28 = torch.ops.aten.slice_backward.default(add_tensor_150, [64, 2048, 7, 7], 3, 0, 9223372036854775807, 1);  add_tensor_150 = None
        slice_backward_default_29 = torch.ops.aten.slice_backward.default(slice_backward_default_28, [64, 2048, 7, 7], 2, 0, 9223372036854775807, 1);  slice_backward_default_28 = None
        slice_backward_default_30 = torch.ops.aten.slice_backward.default(slice_backward_default_29, [64, 2304, 7, 7], 1, 0, 2048, 1);  slice_backward_default_29 = None
        slice_backward_default_31 = torch.ops.aten.slice_backward.default(slice_backward_default_30, [64, 2304, 7, 7], 0, 0, 9223372036854775807, 1);  slice_backward_default_30 = None
        add_tensor_153 = torch.ops.aten.add.Tensor(slice_backward_default_27, slice_backward_default_31);  slice_backward_default_27 = slice_backward_default_31 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(add_tensor_153, relu__default_100, primals_81, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_153 = primals_81 = None
        getitem_392 = convolution_backward_default_9[0]
        getitem_393 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        to_dtype_32 = torch.ops.aten.to.dtype(getitem_392, torch.float32);  getitem_392 = None
        to_dtype_33 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_33, 0);  to_dtype_33 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(to_dtype_32, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_120, to_dtype_32);  le_scalar_10 = new_zeros_default_120 = to_dtype_32 = None
        to_dtype_34 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_34, cat_default_63, primals_615, primals_613, primals_614, getitem_303, getitem_304, True, 0.001, [True, True, True]);  to_dtype_34 = cat_default_63 = primals_615 = primals_613 = primals_614 = getitem_303 = getitem_304 = None
        getitem_395 = native_batch_norm_backward_default_10[0]
        getitem_396 = native_batch_norm_backward_default_10[1]
        getitem_397 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        add_tensor_154 = torch.ops.aten.add.Tensor(getitem_389, getitem_395);  getitem_389 = getitem_395 = None
        slice_tensor_324 = torch.ops.aten.slice.Tensor(add_tensor_154, 1, 0, 1024)
        slice_tensor_325 = torch.ops.aten.slice.Tensor(add_tensor_154, 1, 1024, 2432);  add_tensor_154 = None
        slice_tensor_326 = torch.ops.aten.slice.Tensor(slice_tensor_325, 1, 0, 1344)
        slice_tensor_327 = torch.ops.aten.slice.Tensor(slice_tensor_325, 1, 1344, 1408);  slice_tensor_325 = None
        slice_backward_default_32 = torch.ops.aten.slice_backward.default(slice_tensor_327, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_327 = None
        slice_backward_default_33 = torch.ops.aten.slice_backward.default(slice_backward_default_32, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_32 = None
        slice_backward_default_34 = torch.ops.aten.slice_backward.default(slice_backward_default_33, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_33 = None
        slice_backward_default_35 = torch.ops.aten.slice_backward.default(slice_backward_default_34, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_34 = None
        slice_backward_default_36 = torch.ops.aten.slice_backward.default(slice_tensor_324, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_37 = torch.ops.aten.slice_backward.default(slice_backward_default_36, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_36 = None
        slice_backward_default_38 = torch.ops.aten.slice_backward.default(slice_backward_default_37, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_37 = None
        slice_backward_default_39 = torch.ops.aten.slice_backward.default(slice_backward_default_38, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_38 = None
        add_tensor_155 = torch.ops.aten.add.Tensor(slice_backward_default_35, slice_backward_default_39);  slice_backward_default_35 = slice_backward_default_39 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(add_tensor_155, relu__default_99, primals_77, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_155 = primals_77 = None
        getitem_398 = convolution_backward_default_10[0]
        getitem_399 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_35 = torch.ops.aten.to.dtype(getitem_398, torch.float32);  getitem_398 = None
        to_dtype_36 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_36, 0);  to_dtype_36 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(to_dtype_35, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_121, to_dtype_35);  le_scalar_11 = new_zeros_default_121 = to_dtype_35 = None
        to_dtype_37 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_37, convolution_default_98, primals_610, primals_608, primals_609, getitem_300, getitem_301, True, 0.001, [True, True, True]);  to_dtype_37 = convolution_default_98 = primals_610 = primals_608 = primals_609 = getitem_300 = getitem_301 = None
        getitem_401 = native_batch_norm_backward_default_11[0]
        getitem_402 = native_batch_norm_backward_default_11[1]
        getitem_403 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_401, relu__default_98, primals_78, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_401 = primals_78 = None
        getitem_404 = convolution_backward_default_11[0]
        getitem_405 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_38 = torch.ops.aten.to.dtype(getitem_404, torch.float32);  getitem_404 = None
        to_dtype_39 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_39, 0);  to_dtype_39 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(to_dtype_38, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_122, to_dtype_38);  le_scalar_12 = new_zeros_default_122 = to_dtype_38 = None
        to_dtype_40 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_40, convolution_default_97, primals_605, primals_603, primals_604, getitem_297, getitem_298, True, 0.001, [True, True, True]);  to_dtype_40 = convolution_default_97 = primals_605 = primals_603 = primals_604 = getitem_297 = getitem_298 = None
        getitem_407 = native_batch_norm_backward_default_12[0]
        getitem_408 = native_batch_norm_backward_default_12[1]
        getitem_409 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_407, relu__default_97, primals_76, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_407 = primals_76 = None
        getitem_410 = convolution_backward_default_12[0]
        getitem_411 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        to_dtype_41 = torch.ops.aten.to.dtype(getitem_410, torch.float32);  getitem_410 = None
        to_dtype_42 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_42, 0);  to_dtype_42 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(to_dtype_41, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_123, to_dtype_41);  le_scalar_13 = new_zeros_default_123 = to_dtype_41 = None
        to_dtype_43 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_43, cat_default_61, primals_600, primals_598, primals_599, getitem_294, getitem_295, True, 0.001, [True, True, True]);  to_dtype_43 = cat_default_61 = primals_600 = primals_598 = primals_599 = getitem_294 = getitem_295 = None
        getitem_413 = native_batch_norm_backward_default_13[0]
        getitem_414 = native_batch_norm_backward_default_13[1]
        getitem_415 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        slice_tensor_328 = torch.ops.aten.slice.Tensor(getitem_413, 1, 0, 1024)
        slice_tensor_329 = torch.ops.aten.slice.Tensor(getitem_413, 1, 1024, 2368);  getitem_413 = None
        add_tensor_156 = torch.ops.aten.add.Tensor(slice_tensor_324, slice_tensor_328);  slice_tensor_324 = slice_tensor_328 = None
        add_tensor_157 = torch.ops.aten.add.Tensor(slice_tensor_326, slice_tensor_329);  slice_tensor_326 = slice_tensor_329 = None
        slice_tensor_330 = torch.ops.aten.slice.Tensor(add_tensor_157, 1, 0, 1280)
        slice_tensor_331 = torch.ops.aten.slice.Tensor(add_tensor_157, 1, 1280, 1344);  add_tensor_157 = None
        slice_backward_default_40 = torch.ops.aten.slice_backward.default(slice_tensor_331, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_331 = None
        slice_backward_default_41 = torch.ops.aten.slice_backward.default(slice_backward_default_40, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_40 = None
        slice_backward_default_42 = torch.ops.aten.slice_backward.default(slice_backward_default_41, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_41 = None
        slice_backward_default_43 = torch.ops.aten.slice_backward.default(slice_backward_default_42, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_42 = None
        slice_backward_default_44 = torch.ops.aten.slice_backward.default(add_tensor_156, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_45 = torch.ops.aten.slice_backward.default(slice_backward_default_44, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_44 = None
        slice_backward_default_46 = torch.ops.aten.slice_backward.default(slice_backward_default_45, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_45 = None
        slice_backward_default_47 = torch.ops.aten.slice_backward.default(slice_backward_default_46, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_46 = None
        add_tensor_158 = torch.ops.aten.add.Tensor(slice_backward_default_43, slice_backward_default_47);  slice_backward_default_43 = slice_backward_default_47 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(add_tensor_158, relu__default_96, primals_74, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_158 = primals_74 = None
        getitem_416 = convolution_backward_default_13[0]
        getitem_417 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_44 = torch.ops.aten.to.dtype(getitem_416, torch.float32);  getitem_416 = None
        to_dtype_45 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_45, 0);  to_dtype_45 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(to_dtype_44, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_124, to_dtype_44);  le_scalar_14 = new_zeros_default_124 = to_dtype_44 = None
        to_dtype_46 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_46, convolution_default_95, primals_595, primals_593, primals_594, getitem_291, getitem_292, True, 0.001, [True, True, True]);  to_dtype_46 = convolution_default_95 = primals_595 = primals_593 = primals_594 = getitem_291 = getitem_292 = None
        getitem_419 = native_batch_norm_backward_default_14[0]
        getitem_420 = native_batch_norm_backward_default_14[1]
        getitem_421 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_419, relu__default_95, primals_75, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_419 = primals_75 = None
        getitem_422 = convolution_backward_default_14[0]
        getitem_423 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_47 = torch.ops.aten.to.dtype(getitem_422, torch.float32);  getitem_422 = None
        to_dtype_48 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_48, 0);  to_dtype_48 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(to_dtype_47, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_125, to_dtype_47);  le_scalar_15 = new_zeros_default_125 = to_dtype_47 = None
        to_dtype_49 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_49, convolution_default_94, primals_590, primals_588, primals_589, getitem_288, getitem_289, True, 0.001, [True, True, True]);  to_dtype_49 = convolution_default_94 = primals_590 = primals_588 = primals_589 = getitem_288 = getitem_289 = None
        getitem_425 = native_batch_norm_backward_default_15[0]
        getitem_426 = native_batch_norm_backward_default_15[1]
        getitem_427 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_425, relu__default_94, primals_73, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_425 = primals_73 = None
        getitem_428 = convolution_backward_default_15[0]
        getitem_429 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        to_dtype_50 = torch.ops.aten.to.dtype(getitem_428, torch.float32);  getitem_428 = None
        to_dtype_51 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_51, 0);  to_dtype_51 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(to_dtype_50, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_126, to_dtype_50);  le_scalar_16 = new_zeros_default_126 = to_dtype_50 = None
        to_dtype_52 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_52, cat_default_59, primals_585, primals_583, primals_584, getitem_285, getitem_286, True, 0.001, [True, True, True]);  to_dtype_52 = cat_default_59 = primals_585 = primals_583 = primals_584 = getitem_285 = getitem_286 = None
        getitem_431 = native_batch_norm_backward_default_16[0]
        getitem_432 = native_batch_norm_backward_default_16[1]
        getitem_433 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        slice_tensor_332 = torch.ops.aten.slice.Tensor(getitem_431, 1, 0, 1024)
        slice_tensor_333 = torch.ops.aten.slice.Tensor(getitem_431, 1, 1024, 2304);  getitem_431 = None
        add_tensor_159 = torch.ops.aten.add.Tensor(add_tensor_156, slice_tensor_332);  add_tensor_156 = slice_tensor_332 = None
        add_tensor_160 = torch.ops.aten.add.Tensor(slice_tensor_330, slice_tensor_333);  slice_tensor_330 = slice_tensor_333 = None
        slice_tensor_334 = torch.ops.aten.slice.Tensor(add_tensor_160, 1, 0, 1216)
        slice_tensor_335 = torch.ops.aten.slice.Tensor(add_tensor_160, 1, 1216, 1280);  add_tensor_160 = None
        slice_backward_default_48 = torch.ops.aten.slice_backward.default(slice_tensor_335, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_335 = None
        slice_backward_default_49 = torch.ops.aten.slice_backward.default(slice_backward_default_48, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_48 = None
        slice_backward_default_50 = torch.ops.aten.slice_backward.default(slice_backward_default_49, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_49 = None
        slice_backward_default_51 = torch.ops.aten.slice_backward.default(slice_backward_default_50, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_50 = None
        slice_backward_default_52 = torch.ops.aten.slice_backward.default(add_tensor_159, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_53 = torch.ops.aten.slice_backward.default(slice_backward_default_52, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_52 = None
        slice_backward_default_54 = torch.ops.aten.slice_backward.default(slice_backward_default_53, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_53 = None
        slice_backward_default_55 = torch.ops.aten.slice_backward.default(slice_backward_default_54, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_54 = None
        add_tensor_161 = torch.ops.aten.add.Tensor(slice_backward_default_51, slice_backward_default_55);  slice_backward_default_51 = slice_backward_default_55 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(add_tensor_161, relu__default_93, primals_71, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_161 = primals_71 = None
        getitem_434 = convolution_backward_default_16[0]
        getitem_435 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        to_dtype_53 = torch.ops.aten.to.dtype(getitem_434, torch.float32);  getitem_434 = None
        to_dtype_54 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_54, 0);  to_dtype_54 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(to_dtype_53, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_127, to_dtype_53);  le_scalar_17 = new_zeros_default_127 = to_dtype_53 = None
        to_dtype_55 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_55, convolution_default_92, primals_580, primals_578, primals_579, getitem_282, getitem_283, True, 0.001, [True, True, True]);  to_dtype_55 = convolution_default_92 = primals_580 = primals_578 = primals_579 = getitem_282 = getitem_283 = None
        getitem_437 = native_batch_norm_backward_default_17[0]
        getitem_438 = native_batch_norm_backward_default_17[1]
        getitem_439 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_437, relu__default_92, primals_72, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_437 = primals_72 = None
        getitem_440 = convolution_backward_default_17[0]
        getitem_441 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        to_dtype_56 = torch.ops.aten.to.dtype(getitem_440, torch.float32);  getitem_440 = None
        to_dtype_57 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_57, 0);  to_dtype_57 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(to_dtype_56, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_128, to_dtype_56);  le_scalar_18 = new_zeros_default_128 = to_dtype_56 = None
        to_dtype_58 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_58, convolution_default_91, primals_575, primals_573, primals_574, getitem_279, getitem_280, True, 0.001, [True, True, True]);  to_dtype_58 = convolution_default_91 = primals_575 = primals_573 = primals_574 = getitem_279 = getitem_280 = None
        getitem_443 = native_batch_norm_backward_default_18[0]
        getitem_444 = native_batch_norm_backward_default_18[1]
        getitem_445 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_443, relu__default_91, primals_70, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_443 = primals_70 = None
        getitem_446 = convolution_backward_default_18[0]
        getitem_447 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        to_dtype_59 = torch.ops.aten.to.dtype(getitem_446, torch.float32);  getitem_446 = None
        to_dtype_60 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_60, 0);  to_dtype_60 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(to_dtype_59, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_129, to_dtype_59);  le_scalar_19 = new_zeros_default_129 = to_dtype_59 = None
        to_dtype_61 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_61, cat_default_57, primals_570, primals_568, primals_569, getitem_276, getitem_277, True, 0.001, [True, True, True]);  to_dtype_61 = cat_default_57 = primals_570 = primals_568 = primals_569 = getitem_276 = getitem_277 = None
        getitem_449 = native_batch_norm_backward_default_19[0]
        getitem_450 = native_batch_norm_backward_default_19[1]
        getitem_451 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        slice_tensor_336 = torch.ops.aten.slice.Tensor(getitem_449, 1, 0, 1024)
        slice_tensor_337 = torch.ops.aten.slice.Tensor(getitem_449, 1, 1024, 2240);  getitem_449 = None
        add_tensor_162 = torch.ops.aten.add.Tensor(add_tensor_159, slice_tensor_336);  add_tensor_159 = slice_tensor_336 = None
        add_tensor_163 = torch.ops.aten.add.Tensor(slice_tensor_334, slice_tensor_337);  slice_tensor_334 = slice_tensor_337 = None
        slice_tensor_338 = torch.ops.aten.slice.Tensor(add_tensor_163, 1, 0, 1152)
        slice_tensor_339 = torch.ops.aten.slice.Tensor(add_tensor_163, 1, 1152, 1216);  add_tensor_163 = None
        slice_backward_default_56 = torch.ops.aten.slice_backward.default(slice_tensor_339, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_339 = None
        slice_backward_default_57 = torch.ops.aten.slice_backward.default(slice_backward_default_56, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_56 = None
        slice_backward_default_58 = torch.ops.aten.slice_backward.default(slice_backward_default_57, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_57 = None
        slice_backward_default_59 = torch.ops.aten.slice_backward.default(slice_backward_default_58, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_58 = None
        slice_backward_default_60 = torch.ops.aten.slice_backward.default(add_tensor_162, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_61 = torch.ops.aten.slice_backward.default(slice_backward_default_60, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_60 = None
        slice_backward_default_62 = torch.ops.aten.slice_backward.default(slice_backward_default_61, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_61 = None
        slice_backward_default_63 = torch.ops.aten.slice_backward.default(slice_backward_default_62, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_62 = None
        add_tensor_164 = torch.ops.aten.add.Tensor(slice_backward_default_59, slice_backward_default_63);  slice_backward_default_59 = slice_backward_default_63 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(add_tensor_164, relu__default_90, primals_68, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_164 = primals_68 = None
        getitem_452 = convolution_backward_default_19[0]
        getitem_453 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        to_dtype_62 = torch.ops.aten.to.dtype(getitem_452, torch.float32);  getitem_452 = None
        to_dtype_63 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_63, 0);  to_dtype_63 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(to_dtype_62, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_130, to_dtype_62);  le_scalar_20 = new_zeros_default_130 = to_dtype_62 = None
        to_dtype_64 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_64, convolution_default_89, primals_565, primals_563, primals_564, getitem_273, getitem_274, True, 0.001, [True, True, True]);  to_dtype_64 = convolution_default_89 = primals_565 = primals_563 = primals_564 = getitem_273 = getitem_274 = None
        getitem_455 = native_batch_norm_backward_default_20[0]
        getitem_456 = native_batch_norm_backward_default_20[1]
        getitem_457 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_455, relu__default_89, primals_69, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_455 = primals_69 = None
        getitem_458 = convolution_backward_default_20[0]
        getitem_459 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_65 = torch.ops.aten.to.dtype(getitem_458, torch.float32);  getitem_458 = None
        to_dtype_66 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_66, 0);  to_dtype_66 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(to_dtype_65, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_131, to_dtype_65);  le_scalar_21 = new_zeros_default_131 = to_dtype_65 = None
        to_dtype_67 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_67, convolution_default_88, primals_560, primals_558, primals_559, getitem_270, getitem_271, True, 0.001, [True, True, True]);  to_dtype_67 = convolution_default_88 = primals_560 = primals_558 = primals_559 = getitem_270 = getitem_271 = None
        getitem_461 = native_batch_norm_backward_default_21[0]
        getitem_462 = native_batch_norm_backward_default_21[1]
        getitem_463 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_461, relu__default_88, primals_67, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_461 = primals_67 = None
        getitem_464 = convolution_backward_default_21[0]
        getitem_465 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        to_dtype_68 = torch.ops.aten.to.dtype(getitem_464, torch.float32);  getitem_464 = None
        to_dtype_69 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_69, 0);  to_dtype_69 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype_68, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_132, to_dtype_68);  le_scalar_22 = new_zeros_default_132 = to_dtype_68 = None
        to_dtype_70 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_70, cat_default_55, primals_555, primals_553, primals_554, getitem_267, getitem_268, True, 0.001, [True, True, True]);  to_dtype_70 = cat_default_55 = primals_555 = primals_553 = primals_554 = getitem_267 = getitem_268 = None
        getitem_467 = native_batch_norm_backward_default_22[0]
        getitem_468 = native_batch_norm_backward_default_22[1]
        getitem_469 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        slice_tensor_340 = torch.ops.aten.slice.Tensor(getitem_467, 1, 0, 1024)
        slice_tensor_341 = torch.ops.aten.slice.Tensor(getitem_467, 1, 1024, 2176);  getitem_467 = None
        add_tensor_165 = torch.ops.aten.add.Tensor(add_tensor_162, slice_tensor_340);  add_tensor_162 = slice_tensor_340 = None
        add_tensor_166 = torch.ops.aten.add.Tensor(slice_tensor_338, slice_tensor_341);  slice_tensor_338 = slice_tensor_341 = None
        slice_tensor_342 = torch.ops.aten.slice.Tensor(add_tensor_166, 1, 0, 1088)
        slice_tensor_343 = torch.ops.aten.slice.Tensor(add_tensor_166, 1, 1088, 1152);  add_tensor_166 = None
        slice_backward_default_64 = torch.ops.aten.slice_backward.default(slice_tensor_343, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_343 = None
        slice_backward_default_65 = torch.ops.aten.slice_backward.default(slice_backward_default_64, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_64 = None
        slice_backward_default_66 = torch.ops.aten.slice_backward.default(slice_backward_default_65, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_65 = None
        slice_backward_default_67 = torch.ops.aten.slice_backward.default(slice_backward_default_66, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_66 = None
        slice_backward_default_68 = torch.ops.aten.slice_backward.default(add_tensor_165, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_69 = torch.ops.aten.slice_backward.default(slice_backward_default_68, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_68 = None
        slice_backward_default_70 = torch.ops.aten.slice_backward.default(slice_backward_default_69, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_69 = None
        slice_backward_default_71 = torch.ops.aten.slice_backward.default(slice_backward_default_70, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_70 = None
        add_tensor_167 = torch.ops.aten.add.Tensor(slice_backward_default_67, slice_backward_default_71);  slice_backward_default_67 = slice_backward_default_71 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(add_tensor_167, relu__default_87, primals_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_167 = primals_61 = None
        getitem_470 = convolution_backward_default_22[0]
        getitem_471 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        to_dtype_71 = torch.ops.aten.to.dtype(getitem_470, torch.float32);  getitem_470 = None
        to_dtype_72 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_72, 0);  to_dtype_72 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_71, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_133, to_dtype_71);  le_scalar_23 = new_zeros_default_133 = to_dtype_71 = None
        to_dtype_73 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_73, convolution_default_86, primals_550, primals_548, primals_549, getitem_264, getitem_265, True, 0.001, [True, True, True]);  to_dtype_73 = convolution_default_86 = primals_550 = primals_548 = primals_549 = getitem_264 = getitem_265 = None
        getitem_473 = native_batch_norm_backward_default_23[0]
        getitem_474 = native_batch_norm_backward_default_23[1]
        getitem_475 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_473, relu__default_86, primals_62, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_473 = primals_62 = None
        getitem_476 = convolution_backward_default_23[0]
        getitem_477 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        to_dtype_74 = torch.ops.aten.to.dtype(getitem_476, torch.float32);  getitem_476 = None
        to_dtype_75 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_75, 0);  to_dtype_75 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_74, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_134, to_dtype_74);  le_scalar_24 = new_zeros_default_134 = to_dtype_74 = None
        to_dtype_76 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_76, convolution_default_85, primals_545, primals_543, primals_544, getitem_261, getitem_262, True, 0.001, [True, True, True]);  to_dtype_76 = convolution_default_85 = primals_545 = primals_543 = primals_544 = getitem_261 = getitem_262 = None
        getitem_479 = native_batch_norm_backward_default_24[0]
        getitem_480 = native_batch_norm_backward_default_24[1]
        getitem_481 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_479, relu__default_85, primals_60, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_479 = primals_60 = None
        getitem_482 = convolution_backward_default_24[0]
        getitem_483 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_77 = torch.ops.aten.to.dtype(getitem_482, torch.float32);  getitem_482 = None
        to_dtype_78 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_78, 0);  to_dtype_78 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_77, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_135, to_dtype_77);  le_scalar_25 = new_zeros_default_135 = to_dtype_77 = None
        to_dtype_79 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_79, cat_default_53, primals_540, primals_538, primals_539, getitem_258, getitem_259, True, 0.001, [True, True, True]);  to_dtype_79 = cat_default_53 = primals_540 = primals_538 = primals_539 = getitem_258 = getitem_259 = None
        getitem_485 = native_batch_norm_backward_default_25[0]
        getitem_486 = native_batch_norm_backward_default_25[1]
        getitem_487 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        slice_tensor_344 = torch.ops.aten.slice.Tensor(getitem_485, 1, 0, 1024)
        slice_tensor_345 = torch.ops.aten.slice.Tensor(getitem_485, 1, 1024, 2112);  getitem_485 = None
        add_tensor_168 = torch.ops.aten.add.Tensor(add_tensor_165, slice_tensor_344);  add_tensor_165 = slice_tensor_344 = None
        add_tensor_169 = torch.ops.aten.add.Tensor(slice_tensor_342, slice_tensor_345);  slice_tensor_342 = slice_tensor_345 = None
        slice_tensor_346 = torch.ops.aten.slice.Tensor(add_tensor_169, 1, 0, 1024)
        slice_tensor_347 = torch.ops.aten.slice.Tensor(add_tensor_169, 1, 1024, 1088);  add_tensor_169 = None
        slice_backward_default_72 = torch.ops.aten.slice_backward.default(slice_tensor_347, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_347 = None
        slice_backward_default_73 = torch.ops.aten.slice_backward.default(slice_backward_default_72, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_72 = None
        slice_backward_default_74 = torch.ops.aten.slice_backward.default(slice_backward_default_73, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_73 = None
        slice_backward_default_75 = torch.ops.aten.slice_backward.default(slice_backward_default_74, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_74 = None
        slice_backward_default_76 = torch.ops.aten.slice_backward.default(add_tensor_168, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_77 = torch.ops.aten.slice_backward.default(slice_backward_default_76, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_76 = None
        slice_backward_default_78 = torch.ops.aten.slice_backward.default(slice_backward_default_77, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_77 = None
        slice_backward_default_79 = torch.ops.aten.slice_backward.default(slice_backward_default_78, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_78 = None
        add_tensor_170 = torch.ops.aten.add.Tensor(slice_backward_default_75, slice_backward_default_79);  slice_backward_default_75 = slice_backward_default_79 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(add_tensor_170, relu__default_84, primals_58, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_170 = primals_58 = None
        getitem_488 = convolution_backward_default_25[0]
        getitem_489 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_80 = torch.ops.aten.to.dtype(getitem_488, torch.float32);  getitem_488 = None
        to_dtype_81 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_81, 0);  to_dtype_81 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_80, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_136, to_dtype_80);  le_scalar_26 = new_zeros_default_136 = to_dtype_80 = None
        to_dtype_82 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_82, convolution_default_83, primals_535, primals_533, primals_534, getitem_255, getitem_256, True, 0.001, [True, True, True]);  to_dtype_82 = convolution_default_83 = primals_535 = primals_533 = primals_534 = getitem_255 = getitem_256 = None
        getitem_491 = native_batch_norm_backward_default_26[0]
        getitem_492 = native_batch_norm_backward_default_26[1]
        getitem_493 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_491, relu__default_83, primals_59, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_491 = primals_59 = None
        getitem_494 = convolution_backward_default_26[0]
        getitem_495 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        to_dtype_83 = torch.ops.aten.to.dtype(getitem_494, torch.float32);  getitem_494 = None
        to_dtype_84 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_84, 0);  to_dtype_84 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_83, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_137, to_dtype_83);  le_scalar_27 = new_zeros_default_137 = to_dtype_83 = None
        to_dtype_85 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_85, convolution_default_82, primals_530, primals_528, primals_529, getitem_252, getitem_253, True, 0.001, [True, True, True]);  to_dtype_85 = convolution_default_82 = primals_530 = primals_528 = primals_529 = getitem_252 = getitem_253 = None
        getitem_497 = native_batch_norm_backward_default_27[0]
        getitem_498 = native_batch_norm_backward_default_27[1]
        getitem_499 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_497, relu__default_82, primals_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_497 = primals_57 = None
        getitem_500 = convolution_backward_default_27[0]
        getitem_501 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        to_dtype_86 = torch.ops.aten.to.dtype(getitem_500, torch.float32);  getitem_500 = None
        to_dtype_87 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_87, 0);  to_dtype_87 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_86, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_138, to_dtype_86);  le_scalar_28 = new_zeros_default_138 = to_dtype_86 = None
        to_dtype_88 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_88, cat_default_51, primals_525, primals_523, primals_524, getitem_249, getitem_250, True, 0.001, [True, True, True]);  to_dtype_88 = cat_default_51 = primals_525 = primals_523 = primals_524 = getitem_249 = getitem_250 = None
        getitem_503 = native_batch_norm_backward_default_28[0]
        getitem_504 = native_batch_norm_backward_default_28[1]
        getitem_505 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        slice_tensor_348 = torch.ops.aten.slice.Tensor(getitem_503, 1, 0, 1024)
        slice_tensor_349 = torch.ops.aten.slice.Tensor(getitem_503, 1, 1024, 2048);  getitem_503 = None
        add_tensor_171 = torch.ops.aten.add.Tensor(add_tensor_168, slice_tensor_348);  add_tensor_168 = slice_tensor_348 = None
        add_tensor_172 = torch.ops.aten.add.Tensor(slice_tensor_346, slice_tensor_349);  slice_tensor_346 = slice_tensor_349 = None
        slice_tensor_350 = torch.ops.aten.slice.Tensor(add_tensor_172, 1, 0, 960)
        slice_tensor_351 = torch.ops.aten.slice.Tensor(add_tensor_172, 1, 960, 1024);  add_tensor_172 = None
        slice_backward_default_80 = torch.ops.aten.slice_backward.default(slice_tensor_351, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_351 = None
        slice_backward_default_81 = torch.ops.aten.slice_backward.default(slice_backward_default_80, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_80 = None
        slice_backward_default_82 = torch.ops.aten.slice_backward.default(slice_backward_default_81, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_81 = None
        slice_backward_default_83 = torch.ops.aten.slice_backward.default(slice_backward_default_82, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_82 = None
        slice_backward_default_84 = torch.ops.aten.slice_backward.default(add_tensor_171, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_85 = torch.ops.aten.slice_backward.default(slice_backward_default_84, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_84 = None
        slice_backward_default_86 = torch.ops.aten.slice_backward.default(slice_backward_default_85, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_85 = None
        slice_backward_default_87 = torch.ops.aten.slice_backward.default(slice_backward_default_86, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_86 = None
        add_tensor_173 = torch.ops.aten.add.Tensor(slice_backward_default_83, slice_backward_default_87);  slice_backward_default_83 = slice_backward_default_87 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(add_tensor_173, relu__default_81, primals_55, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_173 = primals_55 = None
        getitem_506 = convolution_backward_default_28[0]
        getitem_507 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_89 = torch.ops.aten.to.dtype(getitem_506, torch.float32);  getitem_506 = None
        to_dtype_90 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_90, 0);  to_dtype_90 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_89, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_139, to_dtype_89);  le_scalar_29 = new_zeros_default_139 = to_dtype_89 = None
        to_dtype_91 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_91, convolution_default_80, primals_520, primals_518, primals_519, getitem_246, getitem_247, True, 0.001, [True, True, True]);  to_dtype_91 = convolution_default_80 = primals_520 = primals_518 = primals_519 = getitem_246 = getitem_247 = None
        getitem_509 = native_batch_norm_backward_default_29[0]
        getitem_510 = native_batch_norm_backward_default_29[1]
        getitem_511 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_509, relu__default_80, primals_56, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_509 = primals_56 = None
        getitem_512 = convolution_backward_default_29[0]
        getitem_513 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        to_dtype_92 = torch.ops.aten.to.dtype(getitem_512, torch.float32);  getitem_512 = None
        to_dtype_93 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_93, 0);  to_dtype_93 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_92, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_140, to_dtype_92);  le_scalar_30 = new_zeros_default_140 = to_dtype_92 = None
        to_dtype_94 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_94, convolution_default_79, primals_515, primals_513, primals_514, getitem_243, getitem_244, True, 0.001, [True, True, True]);  to_dtype_94 = convolution_default_79 = primals_515 = primals_513 = primals_514 = getitem_243 = getitem_244 = None
        getitem_515 = native_batch_norm_backward_default_30[0]
        getitem_516 = native_batch_norm_backward_default_30[1]
        getitem_517 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_515, relu__default_79, primals_54, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_515 = primals_54 = None
        getitem_518 = convolution_backward_default_30[0]
        getitem_519 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        to_dtype_95 = torch.ops.aten.to.dtype(getitem_518, torch.float32);  getitem_518 = None
        to_dtype_96 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_96, 0);  to_dtype_96 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_95, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_141, to_dtype_95);  le_scalar_31 = new_zeros_default_141 = to_dtype_95 = None
        to_dtype_97 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_97, cat_default_49, primals_510, primals_508, primals_509, getitem_240, getitem_241, True, 0.001, [True, True, True]);  to_dtype_97 = cat_default_49 = primals_510 = primals_508 = primals_509 = getitem_240 = getitem_241 = None
        getitem_521 = native_batch_norm_backward_default_31[0]
        getitem_522 = native_batch_norm_backward_default_31[1]
        getitem_523 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        slice_tensor_352 = torch.ops.aten.slice.Tensor(getitem_521, 1, 0, 1024)
        slice_tensor_353 = torch.ops.aten.slice.Tensor(getitem_521, 1, 1024, 1984);  getitem_521 = None
        add_tensor_174 = torch.ops.aten.add.Tensor(add_tensor_171, slice_tensor_352);  add_tensor_171 = slice_tensor_352 = None
        add_tensor_175 = torch.ops.aten.add.Tensor(slice_tensor_350, slice_tensor_353);  slice_tensor_350 = slice_tensor_353 = None
        slice_tensor_354 = torch.ops.aten.slice.Tensor(add_tensor_175, 1, 0, 896)
        slice_tensor_355 = torch.ops.aten.slice.Tensor(add_tensor_175, 1, 896, 960);  add_tensor_175 = None
        slice_backward_default_88 = torch.ops.aten.slice_backward.default(slice_tensor_355, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_355 = None
        slice_backward_default_89 = torch.ops.aten.slice_backward.default(slice_backward_default_88, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_88 = None
        slice_backward_default_90 = torch.ops.aten.slice_backward.default(slice_backward_default_89, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_89 = None
        slice_backward_default_91 = torch.ops.aten.slice_backward.default(slice_backward_default_90, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_90 = None
        slice_backward_default_92 = torch.ops.aten.slice_backward.default(add_tensor_174, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_93 = torch.ops.aten.slice_backward.default(slice_backward_default_92, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_92 = None
        slice_backward_default_94 = torch.ops.aten.slice_backward.default(slice_backward_default_93, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_93 = None
        slice_backward_default_95 = torch.ops.aten.slice_backward.default(slice_backward_default_94, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_94 = None
        add_tensor_176 = torch.ops.aten.add.Tensor(slice_backward_default_91, slice_backward_default_95);  slice_backward_default_91 = slice_backward_default_95 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(add_tensor_176, relu__default_78, primals_52, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_176 = primals_52 = None
        getitem_524 = convolution_backward_default_31[0]
        getitem_525 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_98 = torch.ops.aten.to.dtype(getitem_524, torch.float32);  getitem_524 = None
        to_dtype_99 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_99, 0);  to_dtype_99 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_98, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_142, to_dtype_98);  le_scalar_32 = new_zeros_default_142 = to_dtype_98 = None
        to_dtype_100 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_100, convolution_default_77, primals_505, primals_503, primals_504, getitem_237, getitem_238, True, 0.001, [True, True, True]);  to_dtype_100 = convolution_default_77 = primals_505 = primals_503 = primals_504 = getitem_237 = getitem_238 = None
        getitem_527 = native_batch_norm_backward_default_32[0]
        getitem_528 = native_batch_norm_backward_default_32[1]
        getitem_529 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_527, relu__default_77, primals_53, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_527 = primals_53 = None
        getitem_530 = convolution_backward_default_32[0]
        getitem_531 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_101 = torch.ops.aten.to.dtype(getitem_530, torch.float32);  getitem_530 = None
        to_dtype_102 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_102, 0);  to_dtype_102 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_101, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_143, to_dtype_101);  le_scalar_33 = new_zeros_default_143 = to_dtype_101 = None
        to_dtype_103 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_103, convolution_default_76, primals_500, primals_498, primals_499, getitem_234, getitem_235, True, 0.001, [True, True, True]);  to_dtype_103 = convolution_default_76 = primals_500 = primals_498 = primals_499 = getitem_234 = getitem_235 = None
        getitem_533 = native_batch_norm_backward_default_33[0]
        getitem_534 = native_batch_norm_backward_default_33[1]
        getitem_535 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_533, relu__default_76, primals_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_533 = primals_51 = None
        getitem_536 = convolution_backward_default_33[0]
        getitem_537 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        to_dtype_104 = torch.ops.aten.to.dtype(getitem_536, torch.float32);  getitem_536 = None
        to_dtype_105 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_105, 0);  to_dtype_105 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_104, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_144, to_dtype_104);  le_scalar_34 = new_zeros_default_144 = to_dtype_104 = None
        to_dtype_106 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_106, cat_default_47, primals_495, primals_493, primals_494, getitem_231, getitem_232, True, 0.001, [True, True, True]);  to_dtype_106 = cat_default_47 = primals_495 = primals_493 = primals_494 = getitem_231 = getitem_232 = None
        getitem_539 = native_batch_norm_backward_default_34[0]
        getitem_540 = native_batch_norm_backward_default_34[1]
        getitem_541 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        slice_tensor_356 = torch.ops.aten.slice.Tensor(getitem_539, 1, 0, 1024)
        slice_tensor_357 = torch.ops.aten.slice.Tensor(getitem_539, 1, 1024, 1920);  getitem_539 = None
        add_tensor_177 = torch.ops.aten.add.Tensor(add_tensor_174, slice_tensor_356);  add_tensor_174 = slice_tensor_356 = None
        add_tensor_178 = torch.ops.aten.add.Tensor(slice_tensor_354, slice_tensor_357);  slice_tensor_354 = slice_tensor_357 = None
        slice_tensor_358 = torch.ops.aten.slice.Tensor(add_tensor_178, 1, 0, 832)
        slice_tensor_359 = torch.ops.aten.slice.Tensor(add_tensor_178, 1, 832, 896);  add_tensor_178 = None
        slice_backward_default_96 = torch.ops.aten.slice_backward.default(slice_tensor_359, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_359 = None
        slice_backward_default_97 = torch.ops.aten.slice_backward.default(slice_backward_default_96, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_96 = None
        slice_backward_default_98 = torch.ops.aten.slice_backward.default(slice_backward_default_97, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_97 = None
        slice_backward_default_99 = torch.ops.aten.slice_backward.default(slice_backward_default_98, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_98 = None
        slice_backward_default_100 = torch.ops.aten.slice_backward.default(add_tensor_177, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_101 = torch.ops.aten.slice_backward.default(slice_backward_default_100, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_100 = None
        slice_backward_default_102 = torch.ops.aten.slice_backward.default(slice_backward_default_101, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_101 = None
        slice_backward_default_103 = torch.ops.aten.slice_backward.default(slice_backward_default_102, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_102 = None
        add_tensor_179 = torch.ops.aten.add.Tensor(slice_backward_default_99, slice_backward_default_103);  slice_backward_default_99 = slice_backward_default_103 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(add_tensor_179, relu__default_75, primals_49, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_179 = primals_49 = None
        getitem_542 = convolution_backward_default_34[0]
        getitem_543 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_107 = torch.ops.aten.to.dtype(getitem_542, torch.float32);  getitem_542 = None
        to_dtype_108 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_108, 0);  to_dtype_108 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_107, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_145, to_dtype_107);  le_scalar_35 = new_zeros_default_145 = to_dtype_107 = None
        to_dtype_109 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_109, convolution_default_74, primals_490, primals_488, primals_489, getitem_228, getitem_229, True, 0.001, [True, True, True]);  to_dtype_109 = convolution_default_74 = primals_490 = primals_488 = primals_489 = getitem_228 = getitem_229 = None
        getitem_545 = native_batch_norm_backward_default_35[0]
        getitem_546 = native_batch_norm_backward_default_35[1]
        getitem_547 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_545, relu__default_74, primals_50, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_545 = primals_50 = None
        getitem_548 = convolution_backward_default_35[0]
        getitem_549 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_110 = torch.ops.aten.to.dtype(getitem_548, torch.float32);  getitem_548 = None
        to_dtype_111 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_111, 0);  to_dtype_111 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_110, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_146, to_dtype_110);  le_scalar_36 = new_zeros_default_146 = to_dtype_110 = None
        to_dtype_112 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_112, convolution_default_73, primals_485, primals_483, primals_484, getitem_225, getitem_226, True, 0.001, [True, True, True]);  to_dtype_112 = convolution_default_73 = primals_485 = primals_483 = primals_484 = getitem_225 = getitem_226 = None
        getitem_551 = native_batch_norm_backward_default_36[0]
        getitem_552 = native_batch_norm_backward_default_36[1]
        getitem_553 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_551, relu__default_73, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_551 = primals_48 = None
        getitem_554 = convolution_backward_default_36[0]
        getitem_555 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        to_dtype_113 = torch.ops.aten.to.dtype(getitem_554, torch.float32);  getitem_554 = None
        to_dtype_114 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_114, 0);  to_dtype_114 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_113, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_147, to_dtype_113);  le_scalar_37 = new_zeros_default_147 = to_dtype_113 = None
        to_dtype_115 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_115, cat_default_45, primals_480, primals_478, primals_479, getitem_222, getitem_223, True, 0.001, [True, True, True]);  to_dtype_115 = cat_default_45 = primals_480 = primals_478 = primals_479 = getitem_222 = getitem_223 = None
        getitem_557 = native_batch_norm_backward_default_37[0]
        getitem_558 = native_batch_norm_backward_default_37[1]
        getitem_559 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        slice_tensor_360 = torch.ops.aten.slice.Tensor(getitem_557, 1, 0, 1024)
        slice_tensor_361 = torch.ops.aten.slice.Tensor(getitem_557, 1, 1024, 1856);  getitem_557 = None
        add_tensor_180 = torch.ops.aten.add.Tensor(add_tensor_177, slice_tensor_360);  add_tensor_177 = slice_tensor_360 = None
        add_tensor_181 = torch.ops.aten.add.Tensor(slice_tensor_358, slice_tensor_361);  slice_tensor_358 = slice_tensor_361 = None
        slice_tensor_362 = torch.ops.aten.slice.Tensor(add_tensor_181, 1, 0, 768)
        slice_tensor_363 = torch.ops.aten.slice.Tensor(add_tensor_181, 1, 768, 832);  add_tensor_181 = None
        slice_backward_default_104 = torch.ops.aten.slice_backward.default(slice_tensor_363, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_363 = None
        slice_backward_default_105 = torch.ops.aten.slice_backward.default(slice_backward_default_104, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_104 = None
        slice_backward_default_106 = torch.ops.aten.slice_backward.default(slice_backward_default_105, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_105 = None
        slice_backward_default_107 = torch.ops.aten.slice_backward.default(slice_backward_default_106, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_106 = None
        slice_backward_default_108 = torch.ops.aten.slice_backward.default(add_tensor_180, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_109 = torch.ops.aten.slice_backward.default(slice_backward_default_108, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_108 = None
        slice_backward_default_110 = torch.ops.aten.slice_backward.default(slice_backward_default_109, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_109 = None
        slice_backward_default_111 = torch.ops.aten.slice_backward.default(slice_backward_default_110, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_110 = None
        add_tensor_182 = torch.ops.aten.add.Tensor(slice_backward_default_107, slice_backward_default_111);  slice_backward_default_107 = slice_backward_default_111 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(add_tensor_182, relu__default_72, primals_46, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_182 = primals_46 = None
        getitem_560 = convolution_backward_default_37[0]
        getitem_561 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        to_dtype_116 = torch.ops.aten.to.dtype(getitem_560, torch.float32);  getitem_560 = None
        to_dtype_117 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_117, 0);  to_dtype_117 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_116, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_148, to_dtype_116);  le_scalar_38 = new_zeros_default_148 = to_dtype_116 = None
        to_dtype_118 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_118, convolution_default_71, primals_475, primals_473, primals_474, getitem_219, getitem_220, True, 0.001, [True, True, True]);  to_dtype_118 = convolution_default_71 = primals_475 = primals_473 = primals_474 = getitem_219 = getitem_220 = None
        getitem_563 = native_batch_norm_backward_default_38[0]
        getitem_564 = native_batch_norm_backward_default_38[1]
        getitem_565 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_563, relu__default_71, primals_47, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_563 = primals_47 = None
        getitem_566 = convolution_backward_default_38[0]
        getitem_567 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_119 = torch.ops.aten.to.dtype(getitem_566, torch.float32);  getitem_566 = None
        to_dtype_120 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_120, 0);  to_dtype_120 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_119, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_149, to_dtype_119);  le_scalar_39 = new_zeros_default_149 = to_dtype_119 = None
        to_dtype_121 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_121, convolution_default_70, primals_470, primals_468, primals_469, getitem_216, getitem_217, True, 0.001, [True, True, True]);  to_dtype_121 = convolution_default_70 = primals_470 = primals_468 = primals_469 = getitem_216 = getitem_217 = None
        getitem_569 = native_batch_norm_backward_default_39[0]
        getitem_570 = native_batch_norm_backward_default_39[1]
        getitem_571 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_569, relu__default_70, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_569 = primals_45 = None
        getitem_572 = convolution_backward_default_39[0]
        getitem_573 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_122 = torch.ops.aten.to.dtype(getitem_572, torch.float32);  getitem_572 = None
        to_dtype_123 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_123, 0);  to_dtype_123 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_122, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_150, to_dtype_122);  le_scalar_40 = new_zeros_default_150 = to_dtype_122 = None
        to_dtype_124 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_124, cat_default_43, primals_465, primals_463, primals_464, getitem_213, getitem_214, True, 0.001, [True, True, True]);  to_dtype_124 = cat_default_43 = primals_465 = primals_463 = primals_464 = getitem_213 = getitem_214 = None
        getitem_575 = native_batch_norm_backward_default_40[0]
        getitem_576 = native_batch_norm_backward_default_40[1]
        getitem_577 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        slice_tensor_364 = torch.ops.aten.slice.Tensor(getitem_575, 1, 0, 1024)
        slice_tensor_365 = torch.ops.aten.slice.Tensor(getitem_575, 1, 1024, 1792);  getitem_575 = None
        add_tensor_183 = torch.ops.aten.add.Tensor(add_tensor_180, slice_tensor_364);  add_tensor_180 = slice_tensor_364 = None
        add_tensor_184 = torch.ops.aten.add.Tensor(slice_tensor_362, slice_tensor_365);  slice_tensor_362 = slice_tensor_365 = None
        slice_tensor_366 = torch.ops.aten.slice.Tensor(add_tensor_184, 1, 0, 704)
        slice_tensor_367 = torch.ops.aten.slice.Tensor(add_tensor_184, 1, 704, 768);  add_tensor_184 = None
        slice_backward_default_112 = torch.ops.aten.slice_backward.default(slice_tensor_367, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_367 = None
        slice_backward_default_113 = torch.ops.aten.slice_backward.default(slice_backward_default_112, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_112 = None
        slice_backward_default_114 = torch.ops.aten.slice_backward.default(slice_backward_default_113, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_113 = None
        slice_backward_default_115 = torch.ops.aten.slice_backward.default(slice_backward_default_114, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_114 = None
        slice_backward_default_116 = torch.ops.aten.slice_backward.default(add_tensor_183, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_117 = torch.ops.aten.slice_backward.default(slice_backward_default_116, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_116 = None
        slice_backward_default_118 = torch.ops.aten.slice_backward.default(slice_backward_default_117, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_117 = None
        slice_backward_default_119 = torch.ops.aten.slice_backward.default(slice_backward_default_118, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_118 = None
        add_tensor_185 = torch.ops.aten.add.Tensor(slice_backward_default_115, slice_backward_default_119);  slice_backward_default_115 = slice_backward_default_119 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(add_tensor_185, relu__default_69, primals_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_185 = primals_43 = None
        getitem_578 = convolution_backward_default_40[0]
        getitem_579 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        to_dtype_125 = torch.ops.aten.to.dtype(getitem_578, torch.float32);  getitem_578 = None
        to_dtype_126 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_126, 0);  to_dtype_126 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_125, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_151, to_dtype_125);  le_scalar_41 = new_zeros_default_151 = to_dtype_125 = None
        to_dtype_127 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_127, convolution_default_68, primals_460, primals_458, primals_459, getitem_210, getitem_211, True, 0.001, [True, True, True]);  to_dtype_127 = convolution_default_68 = primals_460 = primals_458 = primals_459 = getitem_210 = getitem_211 = None
        getitem_581 = native_batch_norm_backward_default_41[0]
        getitem_582 = native_batch_norm_backward_default_41[1]
        getitem_583 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_581, relu__default_68, primals_44, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_581 = primals_44 = None
        getitem_584 = convolution_backward_default_41[0]
        getitem_585 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_128 = torch.ops.aten.to.dtype(getitem_584, torch.float32);  getitem_584 = None
        to_dtype_129 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_129, 0);  to_dtype_129 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_128, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_152, to_dtype_128);  le_scalar_42 = new_zeros_default_152 = to_dtype_128 = None
        to_dtype_130 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_130, convolution_default_67, primals_455, primals_453, primals_454, getitem_207, getitem_208, True, 0.001, [True, True, True]);  to_dtype_130 = convolution_default_67 = primals_455 = primals_453 = primals_454 = getitem_207 = getitem_208 = None
        getitem_587 = native_batch_norm_backward_default_42[0]
        getitem_588 = native_batch_norm_backward_default_42[1]
        getitem_589 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_587, relu__default_67, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_587 = primals_42 = None
        getitem_590 = convolution_backward_default_42[0]
        getitem_591 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_131 = torch.ops.aten.to.dtype(getitem_590, torch.float32);  getitem_590 = None
        to_dtype_132 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_132, 0);  to_dtype_132 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_131, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_153, to_dtype_131);  le_scalar_43 = new_zeros_default_153 = to_dtype_131 = None
        to_dtype_133 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_133, cat_default_41, primals_450, primals_448, primals_449, getitem_204, getitem_205, True, 0.001, [True, True, True]);  to_dtype_133 = cat_default_41 = primals_450 = primals_448 = primals_449 = getitem_204 = getitem_205 = None
        getitem_593 = native_batch_norm_backward_default_43[0]
        getitem_594 = native_batch_norm_backward_default_43[1]
        getitem_595 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        slice_tensor_368 = torch.ops.aten.slice.Tensor(getitem_593, 1, 0, 1024)
        slice_tensor_369 = torch.ops.aten.slice.Tensor(getitem_593, 1, 1024, 1728);  getitem_593 = None
        add_tensor_186 = torch.ops.aten.add.Tensor(add_tensor_183, slice_tensor_368);  add_tensor_183 = slice_tensor_368 = None
        add_tensor_187 = torch.ops.aten.add.Tensor(slice_tensor_366, slice_tensor_369);  slice_tensor_366 = slice_tensor_369 = None
        slice_tensor_370 = torch.ops.aten.slice.Tensor(add_tensor_187, 1, 0, 640)
        slice_tensor_371 = torch.ops.aten.slice.Tensor(add_tensor_187, 1, 640, 704);  add_tensor_187 = None
        slice_backward_default_120 = torch.ops.aten.slice_backward.default(slice_tensor_371, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_371 = None
        slice_backward_default_121 = torch.ops.aten.slice_backward.default(slice_backward_default_120, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_120 = None
        slice_backward_default_122 = torch.ops.aten.slice_backward.default(slice_backward_default_121, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_121 = None
        slice_backward_default_123 = torch.ops.aten.slice_backward.default(slice_backward_default_122, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_122 = None
        slice_backward_default_124 = torch.ops.aten.slice_backward.default(add_tensor_186, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_125 = torch.ops.aten.slice_backward.default(slice_backward_default_124, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_124 = None
        slice_backward_default_126 = torch.ops.aten.slice_backward.default(slice_backward_default_125, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_125 = None
        slice_backward_default_127 = torch.ops.aten.slice_backward.default(slice_backward_default_126, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_126 = None
        add_tensor_188 = torch.ops.aten.add.Tensor(slice_backward_default_123, slice_backward_default_127);  slice_backward_default_123 = slice_backward_default_127 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(add_tensor_188, relu__default_66, primals_40, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_188 = primals_40 = None
        getitem_596 = convolution_backward_default_43[0]
        getitem_597 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        to_dtype_134 = torch.ops.aten.to.dtype(getitem_596, torch.float32);  getitem_596 = None
        to_dtype_135 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_135, 0);  to_dtype_135 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_134, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_154, to_dtype_134);  le_scalar_44 = new_zeros_default_154 = to_dtype_134 = None
        to_dtype_136 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_136, convolution_default_65, primals_445, primals_443, primals_444, getitem_201, getitem_202, True, 0.001, [True, True, True]);  to_dtype_136 = convolution_default_65 = primals_445 = primals_443 = primals_444 = getitem_201 = getitem_202 = None
        getitem_599 = native_batch_norm_backward_default_44[0]
        getitem_600 = native_batch_norm_backward_default_44[1]
        getitem_601 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_599, relu__default_65, primals_41, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_599 = primals_41 = None
        getitem_602 = convolution_backward_default_44[0]
        getitem_603 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        to_dtype_137 = torch.ops.aten.to.dtype(getitem_602, torch.float32);  getitem_602 = None
        to_dtype_138 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_138, 0);  to_dtype_138 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_137, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_155, to_dtype_137);  le_scalar_45 = new_zeros_default_155 = to_dtype_137 = None
        to_dtype_139 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_139, convolution_default_64, primals_440, primals_438, primals_439, getitem_198, getitem_199, True, 0.001, [True, True, True]);  to_dtype_139 = convolution_default_64 = primals_440 = primals_438 = primals_439 = getitem_198 = getitem_199 = None
        getitem_605 = native_batch_norm_backward_default_45[0]
        getitem_606 = native_batch_norm_backward_default_45[1]
        getitem_607 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_605, relu__default_64, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_605 = primals_39 = None
        getitem_608 = convolution_backward_default_45[0]
        getitem_609 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        to_dtype_140 = torch.ops.aten.to.dtype(getitem_608, torch.float32);  getitem_608 = None
        to_dtype_141 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_141, 0);  to_dtype_141 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_140, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_156, to_dtype_140);  le_scalar_46 = new_zeros_default_156 = to_dtype_140 = None
        to_dtype_142 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_142, cat_default_39, primals_435, primals_433, primals_434, getitem_195, getitem_196, True, 0.001, [True, True, True]);  to_dtype_142 = cat_default_39 = primals_435 = primals_433 = primals_434 = getitem_195 = getitem_196 = None
        getitem_611 = native_batch_norm_backward_default_46[0]
        getitem_612 = native_batch_norm_backward_default_46[1]
        getitem_613 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        slice_tensor_372 = torch.ops.aten.slice.Tensor(getitem_611, 1, 0, 1024)
        slice_tensor_373 = torch.ops.aten.slice.Tensor(getitem_611, 1, 1024, 1664);  getitem_611 = None
        add_tensor_189 = torch.ops.aten.add.Tensor(add_tensor_186, slice_tensor_372);  add_tensor_186 = slice_tensor_372 = None
        add_tensor_190 = torch.ops.aten.add.Tensor(slice_tensor_370, slice_tensor_373);  slice_tensor_370 = slice_tensor_373 = None
        slice_tensor_374 = torch.ops.aten.slice.Tensor(add_tensor_190, 1, 0, 576)
        slice_tensor_375 = torch.ops.aten.slice.Tensor(add_tensor_190, 1, 576, 640);  add_tensor_190 = None
        slice_backward_default_128 = torch.ops.aten.slice_backward.default(slice_tensor_375, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_375 = None
        slice_backward_default_129 = torch.ops.aten.slice_backward.default(slice_backward_default_128, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_128 = None
        slice_backward_default_130 = torch.ops.aten.slice_backward.default(slice_backward_default_129, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_129 = None
        slice_backward_default_131 = torch.ops.aten.slice_backward.default(slice_backward_default_130, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_130 = None
        slice_backward_default_132 = torch.ops.aten.slice_backward.default(add_tensor_189, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_133 = torch.ops.aten.slice_backward.default(slice_backward_default_132, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_132 = None
        slice_backward_default_134 = torch.ops.aten.slice_backward.default(slice_backward_default_133, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_133 = None
        slice_backward_default_135 = torch.ops.aten.slice_backward.default(slice_backward_default_134, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_134 = None
        add_tensor_191 = torch.ops.aten.add.Tensor(slice_backward_default_131, slice_backward_default_135);  slice_backward_default_131 = slice_backward_default_135 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(add_tensor_191, relu__default_63, primals_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_191 = primals_37 = None
        getitem_614 = convolution_backward_default_46[0]
        getitem_615 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_143 = torch.ops.aten.to.dtype(getitem_614, torch.float32);  getitem_614 = None
        to_dtype_144 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_144, 0);  to_dtype_144 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_143, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_157, to_dtype_143);  le_scalar_47 = new_zeros_default_157 = to_dtype_143 = None
        to_dtype_145 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_145, convolution_default_62, primals_430, primals_428, primals_429, getitem_192, getitem_193, True, 0.001, [True, True, True]);  to_dtype_145 = convolution_default_62 = primals_430 = primals_428 = primals_429 = getitem_192 = getitem_193 = None
        getitem_617 = native_batch_norm_backward_default_47[0]
        getitem_618 = native_batch_norm_backward_default_47[1]
        getitem_619 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_617, relu__default_62, primals_38, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_617 = primals_38 = None
        getitem_620 = convolution_backward_default_47[0]
        getitem_621 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        to_dtype_146 = torch.ops.aten.to.dtype(getitem_620, torch.float32);  getitem_620 = None
        to_dtype_147 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_147, 0);  to_dtype_147 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_146, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_158, to_dtype_146);  le_scalar_48 = new_zeros_default_158 = to_dtype_146 = None
        to_dtype_148 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_148, convolution_default_61, primals_425, primals_423, primals_424, getitem_189, getitem_190, True, 0.001, [True, True, True]);  to_dtype_148 = convolution_default_61 = primals_425 = primals_423 = primals_424 = getitem_189 = getitem_190 = None
        getitem_623 = native_batch_norm_backward_default_48[0]
        getitem_624 = native_batch_norm_backward_default_48[1]
        getitem_625 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_623, relu__default_61, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_623 = primals_36 = None
        getitem_626 = convolution_backward_default_48[0]
        getitem_627 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        to_dtype_149 = torch.ops.aten.to.dtype(getitem_626, torch.float32);  getitem_626 = None
        to_dtype_150 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_150, 0);  to_dtype_150 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_149, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_159, to_dtype_149);  le_scalar_49 = new_zeros_default_159 = to_dtype_149 = None
        to_dtype_151 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_151, cat_default_37, primals_420, primals_418, primals_419, getitem_186, getitem_187, True, 0.001, [True, True, True]);  to_dtype_151 = cat_default_37 = primals_420 = primals_418 = primals_419 = getitem_186 = getitem_187 = None
        getitem_629 = native_batch_norm_backward_default_49[0]
        getitem_630 = native_batch_norm_backward_default_49[1]
        getitem_631 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        slice_tensor_376 = torch.ops.aten.slice.Tensor(getitem_629, 1, 0, 1024)
        slice_tensor_377 = torch.ops.aten.slice.Tensor(getitem_629, 1, 1024, 1600);  getitem_629 = None
        add_tensor_192 = torch.ops.aten.add.Tensor(add_tensor_189, slice_tensor_376);  add_tensor_189 = slice_tensor_376 = None
        add_tensor_193 = torch.ops.aten.add.Tensor(slice_tensor_374, slice_tensor_377);  slice_tensor_374 = slice_tensor_377 = None
        slice_tensor_378 = torch.ops.aten.slice.Tensor(add_tensor_193, 1, 0, 512)
        slice_tensor_379 = torch.ops.aten.slice.Tensor(add_tensor_193, 1, 512, 576);  add_tensor_193 = None
        slice_backward_default_136 = torch.ops.aten.slice_backward.default(slice_tensor_379, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_379 = None
        slice_backward_default_137 = torch.ops.aten.slice_backward.default(slice_backward_default_136, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_136 = None
        slice_backward_default_138 = torch.ops.aten.slice_backward.default(slice_backward_default_137, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_137 = None
        slice_backward_default_139 = torch.ops.aten.slice_backward.default(slice_backward_default_138, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_138 = None
        slice_backward_default_140 = torch.ops.aten.slice_backward.default(add_tensor_192, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_141 = torch.ops.aten.slice_backward.default(slice_backward_default_140, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_140 = None
        slice_backward_default_142 = torch.ops.aten.slice_backward.default(slice_backward_default_141, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_141 = None
        slice_backward_default_143 = torch.ops.aten.slice_backward.default(slice_backward_default_142, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_142 = None
        add_tensor_194 = torch.ops.aten.add.Tensor(slice_backward_default_139, slice_backward_default_143);  slice_backward_default_139 = slice_backward_default_143 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(add_tensor_194, relu__default_60, primals_34, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_194 = primals_34 = None
        getitem_632 = convolution_backward_default_49[0]
        getitem_633 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        to_dtype_152 = torch.ops.aten.to.dtype(getitem_632, torch.float32);  getitem_632 = None
        to_dtype_153 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_153, 0);  to_dtype_153 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_152, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_160, to_dtype_152);  le_scalar_50 = new_zeros_default_160 = to_dtype_152 = None
        to_dtype_154 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_154, convolution_default_59, primals_415, primals_413, primals_414, getitem_183, getitem_184, True, 0.001, [True, True, True]);  to_dtype_154 = convolution_default_59 = primals_415 = primals_413 = primals_414 = getitem_183 = getitem_184 = None
        getitem_635 = native_batch_norm_backward_default_50[0]
        getitem_636 = native_batch_norm_backward_default_50[1]
        getitem_637 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_635, relu__default_59, primals_35, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_635 = primals_35 = None
        getitem_638 = convolution_backward_default_50[0]
        getitem_639 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        to_dtype_155 = torch.ops.aten.to.dtype(getitem_638, torch.float32);  getitem_638 = None
        to_dtype_156 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_156, 0);  to_dtype_156 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_155, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_161, to_dtype_155);  le_scalar_51 = new_zeros_default_161 = to_dtype_155 = None
        to_dtype_157 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_157, convolution_default_58, primals_410, primals_408, primals_409, getitem_180, getitem_181, True, 0.001, [True, True, True]);  to_dtype_157 = convolution_default_58 = primals_410 = primals_408 = primals_409 = getitem_180 = getitem_181 = None
        getitem_641 = native_batch_norm_backward_default_51[0]
        getitem_642 = native_batch_norm_backward_default_51[1]
        getitem_643 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_641, relu__default_58, primals_33, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_641 = primals_33 = None
        getitem_644 = convolution_backward_default_51[0]
        getitem_645 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        to_dtype_158 = torch.ops.aten.to.dtype(getitem_644, torch.float32);  getitem_644 = None
        to_dtype_159 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_159, 0);  to_dtype_159 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_158, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_162, to_dtype_158);  le_scalar_52 = new_zeros_default_162 = to_dtype_158 = None
        to_dtype_160 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_160, cat_default_35, primals_405, primals_403, primals_404, getitem_177, getitem_178, True, 0.001, [True, True, True]);  to_dtype_160 = cat_default_35 = primals_405 = primals_403 = primals_404 = getitem_177 = getitem_178 = None
        getitem_647 = native_batch_norm_backward_default_52[0]
        getitem_648 = native_batch_norm_backward_default_52[1]
        getitem_649 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        slice_tensor_380 = torch.ops.aten.slice.Tensor(getitem_647, 1, 0, 1024)
        slice_tensor_381 = torch.ops.aten.slice.Tensor(getitem_647, 1, 1024, 1536);  getitem_647 = None
        add_tensor_195 = torch.ops.aten.add.Tensor(add_tensor_192, slice_tensor_380);  add_tensor_192 = slice_tensor_380 = None
        add_tensor_196 = torch.ops.aten.add.Tensor(slice_tensor_378, slice_tensor_381);  slice_tensor_378 = slice_tensor_381 = None
        slice_tensor_382 = torch.ops.aten.slice.Tensor(add_tensor_196, 1, 0, 448)
        slice_tensor_383 = torch.ops.aten.slice.Tensor(add_tensor_196, 1, 448, 512);  add_tensor_196 = None
        slice_backward_default_144 = torch.ops.aten.slice_backward.default(slice_tensor_383, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_383 = None
        slice_backward_default_145 = torch.ops.aten.slice_backward.default(slice_backward_default_144, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_144 = None
        slice_backward_default_146 = torch.ops.aten.slice_backward.default(slice_backward_default_145, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_145 = None
        slice_backward_default_147 = torch.ops.aten.slice_backward.default(slice_backward_default_146, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_146 = None
        slice_backward_default_148 = torch.ops.aten.slice_backward.default(add_tensor_195, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_149 = torch.ops.aten.slice_backward.default(slice_backward_default_148, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_148 = None
        slice_backward_default_150 = torch.ops.aten.slice_backward.default(slice_backward_default_149, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_149 = None
        slice_backward_default_151 = torch.ops.aten.slice_backward.default(slice_backward_default_150, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_150 = None
        add_tensor_197 = torch.ops.aten.add.Tensor(slice_backward_default_147, slice_backward_default_151);  slice_backward_default_147 = slice_backward_default_151 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(add_tensor_197, relu__default_57, primals_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_197 = primals_31 = None
        getitem_650 = convolution_backward_default_52[0]
        getitem_651 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        to_dtype_161 = torch.ops.aten.to.dtype(getitem_650, torch.float32);  getitem_650 = None
        to_dtype_162 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_162, 0);  to_dtype_162 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_161, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_163, to_dtype_161);  le_scalar_53 = new_zeros_default_163 = to_dtype_161 = None
        to_dtype_163 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_163, convolution_default_56, primals_400, primals_398, primals_399, getitem_174, getitem_175, True, 0.001, [True, True, True]);  to_dtype_163 = convolution_default_56 = primals_400 = primals_398 = primals_399 = getitem_174 = getitem_175 = None
        getitem_653 = native_batch_norm_backward_default_53[0]
        getitem_654 = native_batch_norm_backward_default_53[1]
        getitem_655 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_653, relu__default_56, primals_32, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_653 = primals_32 = None
        getitem_656 = convolution_backward_default_53[0]
        getitem_657 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        to_dtype_164 = torch.ops.aten.to.dtype(getitem_656, torch.float32);  getitem_656 = None
        to_dtype_165 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_165, 0);  to_dtype_165 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_164, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_164, to_dtype_164);  le_scalar_54 = new_zeros_default_164 = to_dtype_164 = None
        to_dtype_166 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_166, convolution_default_55, primals_395, primals_393, primals_394, getitem_171, getitem_172, True, 0.001, [True, True, True]);  to_dtype_166 = convolution_default_55 = primals_395 = primals_393 = primals_394 = getitem_171 = getitem_172 = None
        getitem_659 = native_batch_norm_backward_default_54[0]
        getitem_660 = native_batch_norm_backward_default_54[1]
        getitem_661 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_659, relu__default_55, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_659 = primals_30 = None
        getitem_662 = convolution_backward_default_54[0]
        getitem_663 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        to_dtype_167 = torch.ops.aten.to.dtype(getitem_662, torch.float32);  getitem_662 = None
        to_dtype_168 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_168, 0);  to_dtype_168 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_167, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_165, to_dtype_167);  le_scalar_55 = new_zeros_default_165 = to_dtype_167 = None
        to_dtype_169 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_169, cat_default_33, primals_390, primals_388, primals_389, getitem_168, getitem_169, True, 0.001, [True, True, True]);  to_dtype_169 = cat_default_33 = primals_390 = primals_388 = primals_389 = getitem_168 = getitem_169 = None
        getitem_665 = native_batch_norm_backward_default_55[0]
        getitem_666 = native_batch_norm_backward_default_55[1]
        getitem_667 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        slice_tensor_384 = torch.ops.aten.slice.Tensor(getitem_665, 1, 0, 1024)
        slice_tensor_385 = torch.ops.aten.slice.Tensor(getitem_665, 1, 1024, 1472);  getitem_665 = None
        add_tensor_198 = torch.ops.aten.add.Tensor(add_tensor_195, slice_tensor_384);  add_tensor_195 = slice_tensor_384 = None
        add_tensor_199 = torch.ops.aten.add.Tensor(slice_tensor_382, slice_tensor_385);  slice_tensor_382 = slice_tensor_385 = None
        slice_tensor_386 = torch.ops.aten.slice.Tensor(add_tensor_199, 1, 0, 384)
        slice_tensor_387 = torch.ops.aten.slice.Tensor(add_tensor_199, 1, 384, 448);  add_tensor_199 = None
        slice_backward_default_152 = torch.ops.aten.slice_backward.default(slice_tensor_387, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_387 = None
        slice_backward_default_153 = torch.ops.aten.slice_backward.default(slice_backward_default_152, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_152 = None
        slice_backward_default_154 = torch.ops.aten.slice_backward.default(slice_backward_default_153, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_153 = None
        slice_backward_default_155 = torch.ops.aten.slice_backward.default(slice_backward_default_154, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_154 = None
        slice_backward_default_156 = torch.ops.aten.slice_backward.default(add_tensor_198, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_157 = torch.ops.aten.slice_backward.default(slice_backward_default_156, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_156 = None
        slice_backward_default_158 = torch.ops.aten.slice_backward.default(slice_backward_default_157, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_157 = None
        slice_backward_default_159 = torch.ops.aten.slice_backward.default(slice_backward_default_158, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_158 = None
        add_tensor_200 = torch.ops.aten.add.Tensor(slice_backward_default_155, slice_backward_default_159);  slice_backward_default_155 = slice_backward_default_159 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(add_tensor_200, relu__default_54, primals_28, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_200 = primals_28 = None
        getitem_668 = convolution_backward_default_55[0]
        getitem_669 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        to_dtype_170 = torch.ops.aten.to.dtype(getitem_668, torch.float32);  getitem_668 = None
        to_dtype_171 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_171, 0);  to_dtype_171 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_170, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_166, to_dtype_170);  le_scalar_56 = new_zeros_default_166 = to_dtype_170 = None
        to_dtype_172 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_172, convolution_default_53, primals_385, primals_383, primals_384, getitem_165, getitem_166, True, 0.001, [True, True, True]);  to_dtype_172 = convolution_default_53 = primals_385 = primals_383 = primals_384 = getitem_165 = getitem_166 = None
        getitem_671 = native_batch_norm_backward_default_56[0]
        getitem_672 = native_batch_norm_backward_default_56[1]
        getitem_673 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_671, relu__default_53, primals_29, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_671 = primals_29 = None
        getitem_674 = convolution_backward_default_56[0]
        getitem_675 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        to_dtype_173 = torch.ops.aten.to.dtype(getitem_674, torch.float32);  getitem_674 = None
        to_dtype_174 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_174, 0);  to_dtype_174 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_173, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_167, to_dtype_173);  le_scalar_57 = new_zeros_default_167 = to_dtype_173 = None
        to_dtype_175 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_175, convolution_default_52, primals_380, primals_378, primals_379, getitem_162, getitem_163, True, 0.001, [True, True, True]);  to_dtype_175 = convolution_default_52 = primals_380 = primals_378 = primals_379 = getitem_162 = getitem_163 = None
        getitem_677 = native_batch_norm_backward_default_57[0]
        getitem_678 = native_batch_norm_backward_default_57[1]
        getitem_679 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_677, relu__default_52, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_677 = primals_27 = None
        getitem_680 = convolution_backward_default_57[0]
        getitem_681 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        to_dtype_176 = torch.ops.aten.to.dtype(getitem_680, torch.float32);  getitem_680 = None
        to_dtype_177 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_177, 0);  to_dtype_177 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_176, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_168, to_dtype_176);  le_scalar_58 = new_zeros_default_168 = to_dtype_176 = None
        to_dtype_178 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_178, cat_default_31, primals_375, primals_373, primals_374, getitem_159, getitem_160, True, 0.001, [True, True, True]);  to_dtype_178 = cat_default_31 = primals_375 = primals_373 = primals_374 = getitem_159 = getitem_160 = None
        getitem_683 = native_batch_norm_backward_default_58[0]
        getitem_684 = native_batch_norm_backward_default_58[1]
        getitem_685 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        slice_tensor_388 = torch.ops.aten.slice.Tensor(getitem_683, 1, 0, 1024)
        slice_tensor_389 = torch.ops.aten.slice.Tensor(getitem_683, 1, 1024, 1408);  getitem_683 = None
        add_tensor_201 = torch.ops.aten.add.Tensor(add_tensor_198, slice_tensor_388);  add_tensor_198 = slice_tensor_388 = None
        add_tensor_202 = torch.ops.aten.add.Tensor(slice_tensor_386, slice_tensor_389);  slice_tensor_386 = slice_tensor_389 = None
        slice_tensor_390 = torch.ops.aten.slice.Tensor(add_tensor_202, 1, 0, 320)
        slice_tensor_391 = torch.ops.aten.slice.Tensor(add_tensor_202, 1, 320, 384);  add_tensor_202 = None
        slice_backward_default_160 = torch.ops.aten.slice_backward.default(slice_tensor_391, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_391 = None
        slice_backward_default_161 = torch.ops.aten.slice_backward.default(slice_backward_default_160, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_160 = None
        slice_backward_default_162 = torch.ops.aten.slice_backward.default(slice_backward_default_161, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_161 = None
        slice_backward_default_163 = torch.ops.aten.slice_backward.default(slice_backward_default_162, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_162 = None
        slice_backward_default_164 = torch.ops.aten.slice_backward.default(add_tensor_201, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_165 = torch.ops.aten.slice_backward.default(slice_backward_default_164, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_164 = None
        slice_backward_default_166 = torch.ops.aten.slice_backward.default(slice_backward_default_165, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_165 = None
        slice_backward_default_167 = torch.ops.aten.slice_backward.default(slice_backward_default_166, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_166 = None
        add_tensor_203 = torch.ops.aten.add.Tensor(slice_backward_default_163, slice_backward_default_167);  slice_backward_default_163 = slice_backward_default_167 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(add_tensor_203, relu__default_51, primals_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_203 = primals_25 = None
        getitem_686 = convolution_backward_default_58[0]
        getitem_687 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        to_dtype_179 = torch.ops.aten.to.dtype(getitem_686, torch.float32);  getitem_686 = None
        to_dtype_180 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_180, 0);  to_dtype_180 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_179, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_169, to_dtype_179);  le_scalar_59 = new_zeros_default_169 = to_dtype_179 = None
        to_dtype_181 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_181, convolution_default_50, primals_370, primals_368, primals_369, getitem_156, getitem_157, True, 0.001, [True, True, True]);  to_dtype_181 = convolution_default_50 = primals_370 = primals_368 = primals_369 = getitem_156 = getitem_157 = None
        getitem_689 = native_batch_norm_backward_default_59[0]
        getitem_690 = native_batch_norm_backward_default_59[1]
        getitem_691 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_689, relu__default_50, primals_26, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_689 = primals_26 = None
        getitem_692 = convolution_backward_default_59[0]
        getitem_693 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_182 = torch.ops.aten.to.dtype(getitem_692, torch.float32);  getitem_692 = None
        to_dtype_183 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_183, 0);  to_dtype_183 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_182, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_170, to_dtype_182);  le_scalar_60 = new_zeros_default_170 = to_dtype_182 = None
        to_dtype_184 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_184, convolution_default_49, primals_365, primals_363, primals_364, getitem_153, getitem_154, True, 0.001, [True, True, True]);  to_dtype_184 = convolution_default_49 = primals_365 = primals_363 = primals_364 = getitem_153 = getitem_154 = None
        getitem_695 = native_batch_norm_backward_default_60[0]
        getitem_696 = native_batch_norm_backward_default_60[1]
        getitem_697 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_695, relu__default_49, primals_24, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_695 = primals_24 = None
        getitem_698 = convolution_backward_default_60[0]
        getitem_699 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        to_dtype_185 = torch.ops.aten.to.dtype(getitem_698, torch.float32);  getitem_698 = None
        to_dtype_186 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_186, 0);  to_dtype_186 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_185, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_171, to_dtype_185);  le_scalar_61 = new_zeros_default_171 = to_dtype_185 = None
        to_dtype_187 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_187, cat_default_29, primals_360, primals_358, primals_359, getitem_150, getitem_151, True, 0.001, [True, True, True]);  to_dtype_187 = cat_default_29 = primals_360 = primals_358 = primals_359 = getitem_150 = getitem_151 = None
        getitem_701 = native_batch_norm_backward_default_61[0]
        getitem_702 = native_batch_norm_backward_default_61[1]
        getitem_703 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        slice_tensor_392 = torch.ops.aten.slice.Tensor(getitem_701, 1, 0, 1024)
        slice_tensor_393 = torch.ops.aten.slice.Tensor(getitem_701, 1, 1024, 1344);  getitem_701 = None
        add_tensor_204 = torch.ops.aten.add.Tensor(add_tensor_201, slice_tensor_392);  add_tensor_201 = slice_tensor_392 = None
        add_tensor_205 = torch.ops.aten.add.Tensor(slice_tensor_390, slice_tensor_393);  slice_tensor_390 = slice_tensor_393 = None
        slice_tensor_394 = torch.ops.aten.slice.Tensor(add_tensor_205, 1, 0, 256)
        slice_tensor_395 = torch.ops.aten.slice.Tensor(add_tensor_205, 1, 256, 320);  add_tensor_205 = None
        slice_backward_default_168 = torch.ops.aten.slice_backward.default(slice_tensor_395, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_395 = None
        slice_backward_default_169 = torch.ops.aten.slice_backward.default(slice_backward_default_168, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_168 = None
        slice_backward_default_170 = torch.ops.aten.slice_backward.default(slice_backward_default_169, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_169 = None
        slice_backward_default_171 = torch.ops.aten.slice_backward.default(slice_backward_default_170, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_170 = None
        slice_backward_default_172 = torch.ops.aten.slice_backward.default(add_tensor_204, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_173 = torch.ops.aten.slice_backward.default(slice_backward_default_172, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_172 = None
        slice_backward_default_174 = torch.ops.aten.slice_backward.default(slice_backward_default_173, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_173 = None
        slice_backward_default_175 = torch.ops.aten.slice_backward.default(slice_backward_default_174, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_174 = None
        add_tensor_206 = torch.ops.aten.add.Tensor(slice_backward_default_171, slice_backward_default_175);  slice_backward_default_171 = slice_backward_default_175 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(add_tensor_206, relu__default_48, primals_22, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_206 = primals_22 = None
        getitem_704 = convolution_backward_default_61[0]
        getitem_705 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        to_dtype_188 = torch.ops.aten.to.dtype(getitem_704, torch.float32);  getitem_704 = None
        to_dtype_189 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_189, 0);  to_dtype_189 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_188, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_172, to_dtype_188);  le_scalar_62 = new_zeros_default_172 = to_dtype_188 = None
        to_dtype_190 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_190, convolution_default_47, primals_355, primals_353, primals_354, getitem_147, getitem_148, True, 0.001, [True, True, True]);  to_dtype_190 = convolution_default_47 = primals_355 = primals_353 = primals_354 = getitem_147 = getitem_148 = None
        getitem_707 = native_batch_norm_backward_default_62[0]
        getitem_708 = native_batch_norm_backward_default_62[1]
        getitem_709 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_707, relu__default_47, primals_23, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_707 = primals_23 = None
        getitem_710 = convolution_backward_default_62[0]
        getitem_711 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        to_dtype_191 = torch.ops.aten.to.dtype(getitem_710, torch.float32);  getitem_710 = None
        to_dtype_192 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_192, 0);  to_dtype_192 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_191, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_173, to_dtype_191);  le_scalar_63 = new_zeros_default_173 = to_dtype_191 = None
        to_dtype_193 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_193, convolution_default_46, primals_350, primals_348, primals_349, getitem_144, getitem_145, True, 0.001, [True, True, True]);  to_dtype_193 = convolution_default_46 = primals_350 = primals_348 = primals_349 = getitem_144 = getitem_145 = None
        getitem_713 = native_batch_norm_backward_default_63[0]
        getitem_714 = native_batch_norm_backward_default_63[1]
        getitem_715 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_713, relu__default_46, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_713 = primals_21 = None
        getitem_716 = convolution_backward_default_63[0]
        getitem_717 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        to_dtype_194 = torch.ops.aten.to.dtype(getitem_716, torch.float32);  getitem_716 = None
        to_dtype_195 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_195, 0);  to_dtype_195 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_194, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_174, to_dtype_194);  le_scalar_64 = new_zeros_default_174 = to_dtype_194 = None
        to_dtype_196 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_196, cat_default_27, primals_345, primals_343, primals_344, getitem_141, getitem_142, True, 0.001, [True, True, True]);  to_dtype_196 = cat_default_27 = primals_345 = primals_343 = primals_344 = getitem_141 = getitem_142 = None
        getitem_719 = native_batch_norm_backward_default_64[0]
        getitem_720 = native_batch_norm_backward_default_64[1]
        getitem_721 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        slice_tensor_396 = torch.ops.aten.slice.Tensor(getitem_719, 1, 0, 1024)
        slice_tensor_397 = torch.ops.aten.slice.Tensor(getitem_719, 1, 1024, 1280);  getitem_719 = None
        add_tensor_207 = torch.ops.aten.add.Tensor(add_tensor_204, slice_tensor_396);  add_tensor_204 = slice_tensor_396 = None
        add_tensor_208 = torch.ops.aten.add.Tensor(slice_tensor_394, slice_tensor_397);  slice_tensor_394 = slice_tensor_397 = None
        slice_tensor_398 = torch.ops.aten.slice.Tensor(add_tensor_208, 1, 0, 192)
        slice_tensor_399 = torch.ops.aten.slice.Tensor(add_tensor_208, 1, 192, 256);  add_tensor_208 = None
        slice_backward_default_176 = torch.ops.aten.slice_backward.default(slice_tensor_399, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_399 = None
        slice_backward_default_177 = torch.ops.aten.slice_backward.default(slice_backward_default_176, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_176 = None
        slice_backward_default_178 = torch.ops.aten.slice_backward.default(slice_backward_default_177, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_177 = None
        slice_backward_default_179 = torch.ops.aten.slice_backward.default(slice_backward_default_178, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_178 = None
        slice_backward_default_180 = torch.ops.aten.slice_backward.default(add_tensor_207, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_181 = torch.ops.aten.slice_backward.default(slice_backward_default_180, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_180 = None
        slice_backward_default_182 = torch.ops.aten.slice_backward.default(slice_backward_default_181, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_181 = None
        slice_backward_default_183 = torch.ops.aten.slice_backward.default(slice_backward_default_182, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_182 = None
        add_tensor_209 = torch.ops.aten.add.Tensor(slice_backward_default_179, slice_backward_default_183);  slice_backward_default_179 = slice_backward_default_183 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(add_tensor_209, relu__default_45, primals_19, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_209 = primals_19 = None
        getitem_722 = convolution_backward_default_64[0]
        getitem_723 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        to_dtype_197 = torch.ops.aten.to.dtype(getitem_722, torch.float32);  getitem_722 = None
        to_dtype_198 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_198, 0);  to_dtype_198 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_197, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_175, to_dtype_197);  le_scalar_65 = new_zeros_default_175 = to_dtype_197 = None
        to_dtype_199 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_199, convolution_default_44, primals_340, primals_338, primals_339, getitem_138, getitem_139, True, 0.001, [True, True, True]);  to_dtype_199 = convolution_default_44 = primals_340 = primals_338 = primals_339 = getitem_138 = getitem_139 = None
        getitem_725 = native_batch_norm_backward_default_65[0]
        getitem_726 = native_batch_norm_backward_default_65[1]
        getitem_727 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_725, relu__default_44, primals_20, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_725 = primals_20 = None
        getitem_728 = convolution_backward_default_65[0]
        getitem_729 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        to_dtype_200 = torch.ops.aten.to.dtype(getitem_728, torch.float32);  getitem_728 = None
        to_dtype_201 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_201, 0);  to_dtype_201 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_200, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_176, to_dtype_200);  le_scalar_66 = new_zeros_default_176 = to_dtype_200 = None
        to_dtype_202 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_202, convolution_default_43, primals_335, primals_333, primals_334, getitem_135, getitem_136, True, 0.001, [True, True, True]);  to_dtype_202 = convolution_default_43 = primals_335 = primals_333 = primals_334 = getitem_135 = getitem_136 = None
        getitem_731 = native_batch_norm_backward_default_66[0]
        getitem_732 = native_batch_norm_backward_default_66[1]
        getitem_733 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_731, relu__default_43, primals_18, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_731 = primals_18 = None
        getitem_734 = convolution_backward_default_66[0]
        getitem_735 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        to_dtype_203 = torch.ops.aten.to.dtype(getitem_734, torch.float32);  getitem_734 = None
        to_dtype_204 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_204, 0);  to_dtype_204 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_203, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_177, to_dtype_203);  le_scalar_67 = new_zeros_default_177 = to_dtype_203 = None
        to_dtype_205 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_205, cat_default_25, primals_330, primals_328, primals_329, getitem_132, getitem_133, True, 0.001, [True, True, True]);  to_dtype_205 = cat_default_25 = primals_330 = primals_328 = primals_329 = getitem_132 = getitem_133 = None
        getitem_737 = native_batch_norm_backward_default_67[0]
        getitem_738 = native_batch_norm_backward_default_67[1]
        getitem_739 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        slice_tensor_400 = torch.ops.aten.slice.Tensor(getitem_737, 1, 0, 1024)
        slice_tensor_401 = torch.ops.aten.slice.Tensor(getitem_737, 1, 1024, 1216);  getitem_737 = None
        add_tensor_210 = torch.ops.aten.add.Tensor(add_tensor_207, slice_tensor_400);  add_tensor_207 = slice_tensor_400 = None
        add_tensor_211 = torch.ops.aten.add.Tensor(slice_tensor_398, slice_tensor_401);  slice_tensor_398 = slice_tensor_401 = None
        slice_tensor_402 = torch.ops.aten.slice.Tensor(add_tensor_211, 1, 0, 128)
        slice_tensor_403 = torch.ops.aten.slice.Tensor(add_tensor_211, 1, 128, 192);  add_tensor_211 = None
        slice_backward_default_184 = torch.ops.aten.slice_backward.default(slice_tensor_403, [64, 64, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_403 = None
        slice_backward_default_185 = torch.ops.aten.slice_backward.default(slice_backward_default_184, [64, 64, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_184 = None
        slice_backward_default_186 = torch.ops.aten.slice_backward.default(slice_backward_default_185, [64, 1088, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_185 = None
        slice_backward_default_187 = torch.ops.aten.slice_backward.default(slice_backward_default_186, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_186 = None
        slice_backward_default_188 = torch.ops.aten.slice_backward.default(add_tensor_210, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1)
        slice_backward_default_189 = torch.ops.aten.slice_backward.default(slice_backward_default_188, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_188 = None
        slice_backward_default_190 = torch.ops.aten.slice_backward.default(slice_backward_default_189, [64, 1088, 14, 14], 1, 0, 1024, 1);  slice_backward_default_189 = None
        slice_backward_default_191 = torch.ops.aten.slice_backward.default(slice_backward_default_190, [64, 1088, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_190 = None
        add_tensor_212 = torch.ops.aten.add.Tensor(slice_backward_default_187, slice_backward_default_191);  slice_backward_default_187 = slice_backward_default_191 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(add_tensor_212, relu__default_42, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_212 = primals_15 = None
        getitem_740 = convolution_backward_default_67[0]
        getitem_741 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        to_dtype_206 = torch.ops.aten.to.dtype(getitem_740, torch.float32);  getitem_740 = None
        to_dtype_207 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_207, 0);  to_dtype_207 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_206, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_178, to_dtype_206);  le_scalar_68 = new_zeros_default_178 = to_dtype_206 = None
        to_dtype_208 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_208, convolution_default_41, primals_325, primals_323, primals_324, getitem_129, getitem_130, True, 0.001, [True, True, True]);  to_dtype_208 = convolution_default_41 = primals_325 = primals_323 = primals_324 = getitem_129 = getitem_130 = None
        getitem_743 = native_batch_norm_backward_default_68[0]
        getitem_744 = native_batch_norm_backward_default_68[1]
        getitem_745 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_743, relu__default_41, primals_17, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_743 = primals_17 = None
        getitem_746 = convolution_backward_default_68[0]
        getitem_747 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        to_dtype_209 = torch.ops.aten.to.dtype(getitem_746, torch.float32);  getitem_746 = None
        to_dtype_210 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_210, 0);  to_dtype_210 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_209, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_179, to_dtype_209);  le_scalar_69 = new_zeros_default_179 = to_dtype_209 = None
        to_dtype_211 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_211, convolution_default_40, primals_320, primals_318, primals_319, getitem_126, getitem_127, True, 0.001, [True, True, True]);  to_dtype_211 = convolution_default_40 = primals_320 = primals_318 = primals_319 = getitem_126 = getitem_127 = None
        getitem_749 = native_batch_norm_backward_default_69[0]
        getitem_750 = native_batch_norm_backward_default_69[1]
        getitem_751 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_749, relu__default_40, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_749 = primals_14 = None
        getitem_752 = convolution_backward_default_69[0]
        getitem_753 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        to_dtype_212 = torch.ops.aten.to.dtype(getitem_752, torch.float32);  getitem_752 = None
        to_dtype_213 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_213, 0);  to_dtype_213 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_212, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_180, to_dtype_212);  le_scalar_70 = new_zeros_default_180 = to_dtype_212 = None
        to_dtype_214 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_214, cat_default_23, primals_315, primals_313, primals_314, getitem_123, getitem_124, True, 0.001, [True, True, True]);  to_dtype_214 = primals_315 = primals_313 = primals_314 = getitem_123 = getitem_124 = None
        getitem_755 = native_batch_norm_backward_default_70[0]
        getitem_756 = native_batch_norm_backward_default_70[1]
        getitem_757 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        slice_backward_default_192 = torch.ops.aten.slice_backward.default(slice_tensor_402, [64, 128, 14, 14], 3, 0, 9223372036854775807, 1);  slice_tensor_402 = None
        slice_backward_default_193 = torch.ops.aten.slice_backward.default(slice_backward_default_192, [64, 128, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_192 = None
        slice_backward_default_194 = torch.ops.aten.slice_backward.default(slice_backward_default_193, [64, 1152, 14, 14], 1, 1024, 9223372036854775807, 1);  slice_backward_default_193 = None
        slice_backward_default_195 = torch.ops.aten.slice_backward.default(slice_backward_default_194, [64, 1152, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_194 = None
        slice_backward_default_196 = torch.ops.aten.slice_backward.default(add_tensor_210, [64, 1024, 14, 14], 3, 0, 9223372036854775807, 1);  add_tensor_210 = None
        slice_backward_default_197 = torch.ops.aten.slice_backward.default(slice_backward_default_196, [64, 1024, 14, 14], 2, 0, 9223372036854775807, 1);  slice_backward_default_196 = None
        slice_backward_default_198 = torch.ops.aten.slice_backward.default(slice_backward_default_197, [64, 1152, 14, 14], 1, 0, 1024, 1);  slice_backward_default_197 = None
        slice_backward_default_199 = torch.ops.aten.slice_backward.default(slice_backward_default_198, [64, 1152, 14, 14], 0, 0, 9223372036854775807, 1);  slice_backward_default_198 = None
        add_tensor_213 = torch.ops.aten.add.Tensor(slice_backward_default_195, slice_backward_default_199);  slice_backward_default_195 = slice_backward_default_199 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(add_tensor_213, relu__default_39, primals_16, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_213 = primals_16 = None
        getitem_758 = convolution_backward_default_70[0]
        getitem_759 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        to_dtype_215 = torch.ops.aten.to.dtype(getitem_758, torch.float32);  getitem_758 = None
        to_dtype_216 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_216, 0);  to_dtype_216 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_215, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_181, to_dtype_215);  le_scalar_71 = new_zeros_default_181 = to_dtype_215 = None
        to_dtype_217 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_217, cat_default_23, primals_310, primals_308, primals_309, getitem_120, getitem_121, True, 0.001, [True, True, True]);  to_dtype_217 = cat_default_23 = primals_310 = primals_308 = primals_309 = getitem_120 = getitem_121 = None
        getitem_761 = native_batch_norm_backward_default_71[0]
        getitem_762 = native_batch_norm_backward_default_71[1]
        getitem_763 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        add_tensor_214 = torch.ops.aten.add.Tensor(getitem_755, getitem_761);  getitem_755 = getitem_761 = None
        slice_tensor_404 = torch.ops.aten.slice.Tensor(add_tensor_214, 1, 0, 512)
        slice_tensor_405 = torch.ops.aten.slice.Tensor(add_tensor_214, 1, 512, 1152);  add_tensor_214 = None
        slice_tensor_406 = torch.ops.aten.slice.Tensor(slice_tensor_405, 1, 0, 576)
        slice_tensor_407 = torch.ops.aten.slice.Tensor(slice_tensor_405, 1, 576, 640);  slice_tensor_405 = None
        slice_backward_default_200 = torch.ops.aten.slice_backward.default(slice_tensor_407, [64, 64, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_407 = None
        slice_backward_default_201 = torch.ops.aten.slice_backward.default(slice_backward_default_200, [64, 64, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_200 = None
        slice_backward_default_202 = torch.ops.aten.slice_backward.default(slice_backward_default_201, [64, 576, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_201 = None
        slice_backward_default_203 = torch.ops.aten.slice_backward.default(slice_backward_default_202, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_202 = None
        slice_backward_default_204 = torch.ops.aten.slice_backward.default(slice_tensor_404, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1)
        slice_backward_default_205 = torch.ops.aten.slice_backward.default(slice_backward_default_204, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_204 = None
        slice_backward_default_206 = torch.ops.aten.slice_backward.default(slice_backward_default_205, [64, 576, 28, 28], 1, 0, 512, 1);  slice_backward_default_205 = None
        slice_backward_default_207 = torch.ops.aten.slice_backward.default(slice_backward_default_206, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_206 = None
        add_tensor_215 = torch.ops.aten.add.Tensor(slice_backward_default_203, slice_backward_default_207);  slice_backward_default_203 = slice_backward_default_207 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(add_tensor_215, relu__default_38, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_215 = primals_12 = None
        getitem_764 = convolution_backward_default_71[0]
        getitem_765 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        to_dtype_218 = torch.ops.aten.to.dtype(getitem_764, torch.float32);  getitem_764 = None
        to_dtype_219 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_219, 0);  to_dtype_219 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_218, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_182, to_dtype_218);  le_scalar_72 = new_zeros_default_182 = to_dtype_218 = None
        to_dtype_220 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_220, convolution_default_37, primals_305, primals_303, primals_304, getitem_117, getitem_118, True, 0.001, [True, True, True]);  to_dtype_220 = convolution_default_37 = primals_305 = primals_303 = primals_304 = getitem_117 = getitem_118 = None
        getitem_767 = native_batch_norm_backward_default_72[0]
        getitem_768 = native_batch_norm_backward_default_72[1]
        getitem_769 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_767, relu__default_37, primals_13, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_767 = primals_13 = None
        getitem_770 = convolution_backward_default_72[0]
        getitem_771 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        to_dtype_221 = torch.ops.aten.to.dtype(getitem_770, torch.float32);  getitem_770 = None
        to_dtype_222 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_222, 0);  to_dtype_222 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_221, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_183, to_dtype_221);  le_scalar_73 = new_zeros_default_183 = to_dtype_221 = None
        to_dtype_223 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_223, convolution_default_36, primals_300, primals_298, primals_299, getitem_114, getitem_115, True, 0.001, [True, True, True]);  to_dtype_223 = convolution_default_36 = primals_300 = primals_298 = primals_299 = getitem_114 = getitem_115 = None
        getitem_773 = native_batch_norm_backward_default_73[0]
        getitem_774 = native_batch_norm_backward_default_73[1]
        getitem_775 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_773, relu__default_36, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_773 = primals_11 = None
        getitem_776 = convolution_backward_default_73[0]
        getitem_777 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        to_dtype_224 = torch.ops.aten.to.dtype(getitem_776, torch.float32);  getitem_776 = None
        to_dtype_225 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_225, 0);  to_dtype_225 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_224, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_184, to_dtype_224);  le_scalar_74 = new_zeros_default_184 = to_dtype_224 = None
        to_dtype_226 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_226, cat_default_21, primals_295, primals_293, primals_294, getitem_111, getitem_112, True, 0.001, [True, True, True]);  to_dtype_226 = cat_default_21 = primals_295 = primals_293 = primals_294 = getitem_111 = getitem_112 = None
        getitem_779 = native_batch_norm_backward_default_74[0]
        getitem_780 = native_batch_norm_backward_default_74[1]
        getitem_781 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        slice_tensor_408 = torch.ops.aten.slice.Tensor(getitem_779, 1, 0, 512)
        slice_tensor_409 = torch.ops.aten.slice.Tensor(getitem_779, 1, 512, 1088);  getitem_779 = None
        add_tensor_216 = torch.ops.aten.add.Tensor(slice_tensor_404, slice_tensor_408);  slice_tensor_404 = slice_tensor_408 = None
        add_tensor_217 = torch.ops.aten.add.Tensor(slice_tensor_406, slice_tensor_409);  slice_tensor_406 = slice_tensor_409 = None
        slice_tensor_410 = torch.ops.aten.slice.Tensor(add_tensor_217, 1, 0, 512)
        slice_tensor_411 = torch.ops.aten.slice.Tensor(add_tensor_217, 1, 512, 576);  add_tensor_217 = None
        slice_backward_default_208 = torch.ops.aten.slice_backward.default(slice_tensor_411, [64, 64, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_411 = None
        slice_backward_default_209 = torch.ops.aten.slice_backward.default(slice_backward_default_208, [64, 64, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_208 = None
        slice_backward_default_210 = torch.ops.aten.slice_backward.default(slice_backward_default_209, [64, 576, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_209 = None
        slice_backward_default_211 = torch.ops.aten.slice_backward.default(slice_backward_default_210, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_210 = None
        slice_backward_default_212 = torch.ops.aten.slice_backward.default(add_tensor_216, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1)
        slice_backward_default_213 = torch.ops.aten.slice_backward.default(slice_backward_default_212, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_212 = None
        slice_backward_default_214 = torch.ops.aten.slice_backward.default(slice_backward_default_213, [64, 576, 28, 28], 1, 0, 512, 1);  slice_backward_default_213 = None
        slice_backward_default_215 = torch.ops.aten.slice_backward.default(slice_backward_default_214, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_214 = None
        add_tensor_218 = torch.ops.aten.add.Tensor(slice_backward_default_211, slice_backward_default_215);  slice_backward_default_211 = slice_backward_default_215 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(add_tensor_218, relu__default_35, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_218 = primals_9 = None
        getitem_782 = convolution_backward_default_74[0]
        getitem_783 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        to_dtype_227 = torch.ops.aten.to.dtype(getitem_782, torch.float32);  getitem_782 = None
        to_dtype_228 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_228, 0);  to_dtype_228 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_227, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_185, to_dtype_227);  le_scalar_75 = new_zeros_default_185 = to_dtype_227 = None
        to_dtype_229 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_229, convolution_default_34, primals_290, primals_288, primals_289, getitem_108, getitem_109, True, 0.001, [True, True, True]);  to_dtype_229 = convolution_default_34 = primals_290 = primals_288 = primals_289 = getitem_108 = getitem_109 = None
        getitem_785 = native_batch_norm_backward_default_75[0]
        getitem_786 = native_batch_norm_backward_default_75[1]
        getitem_787 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_785, relu__default_34, primals_10, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_785 = primals_10 = None
        getitem_788 = convolution_backward_default_75[0]
        getitem_789 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        to_dtype_230 = torch.ops.aten.to.dtype(getitem_788, torch.float32);  getitem_788 = None
        to_dtype_231 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_231, 0);  to_dtype_231 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_230, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_186, to_dtype_230);  le_scalar_76 = new_zeros_default_186 = to_dtype_230 = None
        to_dtype_232 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_232, convolution_default_33, primals_285, primals_283, primals_284, getitem_105, getitem_106, True, 0.001, [True, True, True]);  to_dtype_232 = convolution_default_33 = primals_285 = primals_283 = primals_284 = getitem_105 = getitem_106 = None
        getitem_791 = native_batch_norm_backward_default_76[0]
        getitem_792 = native_batch_norm_backward_default_76[1]
        getitem_793 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_791, relu__default_33, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_791 = primals_8 = None
        getitem_794 = convolution_backward_default_76[0]
        getitem_795 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        to_dtype_233 = torch.ops.aten.to.dtype(getitem_794, torch.float32);  getitem_794 = None
        to_dtype_234 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_234, 0);  to_dtype_234 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_233, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_187, to_dtype_233);  le_scalar_77 = new_zeros_default_187 = to_dtype_233 = None
        to_dtype_235 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_235, cat_default_19, primals_280, primals_278, primals_279, getitem_102, getitem_103, True, 0.001, [True, True, True]);  to_dtype_235 = cat_default_19 = primals_280 = primals_278 = primals_279 = getitem_102 = getitem_103 = None
        getitem_797 = native_batch_norm_backward_default_77[0]
        getitem_798 = native_batch_norm_backward_default_77[1]
        getitem_799 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        slice_tensor_412 = torch.ops.aten.slice.Tensor(getitem_797, 1, 0, 512)
        slice_tensor_413 = torch.ops.aten.slice.Tensor(getitem_797, 1, 512, 1024);  getitem_797 = None
        add_tensor_219 = torch.ops.aten.add.Tensor(add_tensor_216, slice_tensor_412);  add_tensor_216 = slice_tensor_412 = None
        add_tensor_220 = torch.ops.aten.add.Tensor(slice_tensor_410, slice_tensor_413);  slice_tensor_410 = slice_tensor_413 = None
        slice_tensor_414 = torch.ops.aten.slice.Tensor(add_tensor_220, 1, 0, 448)
        slice_tensor_415 = torch.ops.aten.slice.Tensor(add_tensor_220, 1, 448, 512);  add_tensor_220 = None
        slice_backward_default_216 = torch.ops.aten.slice_backward.default(slice_tensor_415, [64, 64, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_415 = None
        slice_backward_default_217 = torch.ops.aten.slice_backward.default(slice_backward_default_216, [64, 64, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_216 = None
        slice_backward_default_218 = torch.ops.aten.slice_backward.default(slice_backward_default_217, [64, 576, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_217 = None
        slice_backward_default_219 = torch.ops.aten.slice_backward.default(slice_backward_default_218, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_218 = None
        slice_backward_default_220 = torch.ops.aten.slice_backward.default(add_tensor_219, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1)
        slice_backward_default_221 = torch.ops.aten.slice_backward.default(slice_backward_default_220, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_220 = None
        slice_backward_default_222 = torch.ops.aten.slice_backward.default(slice_backward_default_221, [64, 576, 28, 28], 1, 0, 512, 1);  slice_backward_default_221 = None
        slice_backward_default_223 = torch.ops.aten.slice_backward.default(slice_backward_default_222, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_222 = None
        add_tensor_221 = torch.ops.aten.add.Tensor(slice_backward_default_219, slice_backward_default_223);  slice_backward_default_219 = slice_backward_default_223 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(add_tensor_221, relu__default_32, primals_6, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_221 = primals_6 = None
        getitem_800 = convolution_backward_default_77[0]
        getitem_801 = convolution_backward_default_77[1];  convolution_backward_default_77 = None
        to_dtype_236 = torch.ops.aten.to.dtype(getitem_800, torch.float32);  getitem_800 = None
        to_dtype_237 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_237, 0);  to_dtype_237 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_236, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_188, to_dtype_236);  le_scalar_78 = new_zeros_default_188 = to_dtype_236 = None
        to_dtype_238 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_238, convolution_default_31, primals_275, primals_273, primals_274, getitem_99, getitem_100, True, 0.001, [True, True, True]);  to_dtype_238 = convolution_default_31 = primals_275 = primals_273 = primals_274 = getitem_99 = getitem_100 = None
        getitem_803 = native_batch_norm_backward_default_78[0]
        getitem_804 = native_batch_norm_backward_default_78[1]
        getitem_805 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_803, relu__default_31, primals_7, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_803 = primals_7 = None
        getitem_806 = convolution_backward_default_78[0]
        getitem_807 = convolution_backward_default_78[1];  convolution_backward_default_78 = None
        to_dtype_239 = torch.ops.aten.to.dtype(getitem_806, torch.float32);  getitem_806 = None
        to_dtype_240 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_240, 0);  to_dtype_240 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_239, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_189, to_dtype_239);  le_scalar_79 = new_zeros_default_189 = to_dtype_239 = None
        to_dtype_241 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_241, convolution_default_30, primals_270, primals_268, primals_269, getitem_96, getitem_97, True, 0.001, [True, True, True]);  to_dtype_241 = convolution_default_30 = primals_270 = primals_268 = primals_269 = getitem_96 = getitem_97 = None
        getitem_809 = native_batch_norm_backward_default_79[0]
        getitem_810 = native_batch_norm_backward_default_79[1]
        getitem_811 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_809, relu__default_30, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_809 = primals_5 = None
        getitem_812 = convolution_backward_default_79[0]
        getitem_813 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        to_dtype_242 = torch.ops.aten.to.dtype(getitem_812, torch.float32);  getitem_812 = None
        to_dtype_243 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_243, 0);  to_dtype_243 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_242, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_190, to_dtype_242);  le_scalar_80 = new_zeros_default_190 = to_dtype_242 = None
        to_dtype_244 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_244, cat_default_17, primals_265, primals_263, primals_264, getitem_93, getitem_94, True, 0.001, [True, True, True]);  to_dtype_244 = cat_default_17 = primals_265 = primals_263 = primals_264 = getitem_93 = getitem_94 = None
        getitem_815 = native_batch_norm_backward_default_80[0]
        getitem_816 = native_batch_norm_backward_default_80[1]
        getitem_817 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        slice_tensor_416 = torch.ops.aten.slice.Tensor(getitem_815, 1, 0, 512)
        slice_tensor_417 = torch.ops.aten.slice.Tensor(getitem_815, 1, 512, 960);  getitem_815 = None
        add_tensor_222 = torch.ops.aten.add.Tensor(add_tensor_219, slice_tensor_416);  add_tensor_219 = slice_tensor_416 = None
        add_tensor_223 = torch.ops.aten.add.Tensor(slice_tensor_414, slice_tensor_417);  slice_tensor_414 = slice_tensor_417 = None
        slice_tensor_418 = torch.ops.aten.slice.Tensor(add_tensor_223, 1, 0, 384)
        slice_tensor_419 = torch.ops.aten.slice.Tensor(add_tensor_223, 1, 384, 448);  add_tensor_223 = None
        slice_backward_default_224 = torch.ops.aten.slice_backward.default(slice_tensor_419, [64, 64, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_419 = None
        slice_backward_default_225 = torch.ops.aten.slice_backward.default(slice_backward_default_224, [64, 64, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_224 = None
        slice_backward_default_226 = torch.ops.aten.slice_backward.default(slice_backward_default_225, [64, 576, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_225 = None
        slice_backward_default_227 = torch.ops.aten.slice_backward.default(slice_backward_default_226, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_226 = None
        slice_backward_default_228 = torch.ops.aten.slice_backward.default(add_tensor_222, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1)
        slice_backward_default_229 = torch.ops.aten.slice_backward.default(slice_backward_default_228, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_228 = None
        slice_backward_default_230 = torch.ops.aten.slice_backward.default(slice_backward_default_229, [64, 576, 28, 28], 1, 0, 512, 1);  slice_backward_default_229 = None
        slice_backward_default_231 = torch.ops.aten.slice_backward.default(slice_backward_default_230, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_230 = None
        add_tensor_224 = torch.ops.aten.add.Tensor(slice_backward_default_227, slice_backward_default_231);  slice_backward_default_227 = slice_backward_default_231 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(add_tensor_224, relu__default_29, primals_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_224 = primals_3 = None
        getitem_818 = convolution_backward_default_80[0]
        getitem_819 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        to_dtype_245 = torch.ops.aten.to.dtype(getitem_818, torch.float32);  getitem_818 = None
        to_dtype_246 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_246, 0);  to_dtype_246 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_245, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_191, to_dtype_245);  le_scalar_81 = new_zeros_default_191 = to_dtype_245 = None
        to_dtype_247 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_247, convolution_default_28, primals_260, primals_258, primals_259, getitem_90, getitem_91, True, 0.001, [True, True, True]);  to_dtype_247 = convolution_default_28 = primals_260 = primals_258 = primals_259 = getitem_90 = getitem_91 = None
        getitem_821 = native_batch_norm_backward_default_81[0]
        getitem_822 = native_batch_norm_backward_default_81[1]
        getitem_823 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_821, relu__default_28, primals_4, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_821 = primals_4 = None
        getitem_824 = convolution_backward_default_81[0]
        getitem_825 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        to_dtype_248 = torch.ops.aten.to.dtype(getitem_824, torch.float32);  getitem_824 = None
        to_dtype_249 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_249, 0);  to_dtype_249 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_248, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_192, to_dtype_248);  le_scalar_82 = new_zeros_default_192 = to_dtype_248 = None
        to_dtype_250 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_250, convolution_default_27, primals_255, primals_253, primals_254, getitem_87, getitem_88, True, 0.001, [True, True, True]);  to_dtype_250 = convolution_default_27 = primals_255 = primals_253 = primals_254 = getitem_87 = getitem_88 = None
        getitem_827 = native_batch_norm_backward_default_82[0]
        getitem_828 = native_batch_norm_backward_default_82[1]
        getitem_829 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_827, relu__default_27, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_827 = primals_2 = None
        getitem_830 = convolution_backward_default_82[0]
        getitem_831 = convolution_backward_default_82[1];  convolution_backward_default_82 = None
        to_dtype_251 = torch.ops.aten.to.dtype(getitem_830, torch.float32);  getitem_830 = None
        to_dtype_252 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_252, 0);  to_dtype_252 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_251, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_193, to_dtype_251);  le_scalar_83 = new_zeros_default_193 = to_dtype_251 = None
        to_dtype_253 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_253, cat_default_15, primals_250, primals_248, primals_249, getitem_84, getitem_85, True, 0.001, [True, True, True]);  to_dtype_253 = cat_default_15 = primals_250 = primals_248 = primals_249 = getitem_84 = getitem_85 = None
        getitem_833 = native_batch_norm_backward_default_83[0]
        getitem_834 = native_batch_norm_backward_default_83[1]
        getitem_835 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        slice_tensor_420 = torch.ops.aten.slice.Tensor(getitem_833, 1, 0, 512)
        slice_tensor_421 = torch.ops.aten.slice.Tensor(getitem_833, 1, 512, 896);  getitem_833 = None
        add_tensor_225 = torch.ops.aten.add.Tensor(add_tensor_222, slice_tensor_420);  add_tensor_222 = slice_tensor_420 = None
        add_tensor_226 = torch.ops.aten.add.Tensor(slice_tensor_418, slice_tensor_421);  slice_tensor_418 = slice_tensor_421 = None
        slice_tensor_422 = torch.ops.aten.slice.Tensor(add_tensor_226, 1, 0, 320)
        slice_tensor_423 = torch.ops.aten.slice.Tensor(add_tensor_226, 1, 320, 384);  add_tensor_226 = None
        slice_backward_default_232 = torch.ops.aten.slice_backward.default(slice_tensor_423, [64, 64, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_423 = None
        slice_backward_default_233 = torch.ops.aten.slice_backward.default(slice_backward_default_232, [64, 64, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_232 = None
        slice_backward_default_234 = torch.ops.aten.slice_backward.default(slice_backward_default_233, [64, 576, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_233 = None
        slice_backward_default_235 = torch.ops.aten.slice_backward.default(slice_backward_default_234, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_234 = None
        slice_backward_default_236 = torch.ops.aten.slice_backward.default(add_tensor_225, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1)
        slice_backward_default_237 = torch.ops.aten.slice_backward.default(slice_backward_default_236, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_236 = None
        slice_backward_default_238 = torch.ops.aten.slice_backward.default(slice_backward_default_237, [64, 576, 28, 28], 1, 0, 512, 1);  slice_backward_default_237 = None
        slice_backward_default_239 = torch.ops.aten.slice_backward.default(slice_backward_default_238, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_238 = None
        add_tensor_227 = torch.ops.aten.add.Tensor(slice_backward_default_235, slice_backward_default_239);  slice_backward_default_235 = slice_backward_default_239 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(add_tensor_227, relu__default_26, primals_109, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_227 = primals_109 = None
        getitem_836 = convolution_backward_default_83[0]
        getitem_837 = convolution_backward_default_83[1];  convolution_backward_default_83 = None
        to_dtype_254 = torch.ops.aten.to.dtype(getitem_836, torch.float32);  getitem_836 = None
        to_dtype_255 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_255, 0);  to_dtype_255 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_254, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_194, to_dtype_254);  le_scalar_84 = new_zeros_default_194 = to_dtype_254 = None
        to_dtype_256 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_256, convolution_default_25, primals_245, primals_243, primals_244, getitem_81, getitem_82, True, 0.001, [True, True, True]);  to_dtype_256 = convolution_default_25 = primals_245 = primals_243 = primals_244 = getitem_81 = getitem_82 = None
        getitem_839 = native_batch_norm_backward_default_84[0]
        getitem_840 = native_batch_norm_backward_default_84[1]
        getitem_841 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_839, relu__default_25, primals_110, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_839 = primals_110 = None
        getitem_842 = convolution_backward_default_84[0]
        getitem_843 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        to_dtype_257 = torch.ops.aten.to.dtype(getitem_842, torch.float32);  getitem_842 = None
        to_dtype_258 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_258, 0);  to_dtype_258 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_257, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_195, to_dtype_257);  le_scalar_85 = new_zeros_default_195 = to_dtype_257 = None
        to_dtype_259 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_259, convolution_default_24, primals_240, primals_238, primals_239, getitem_78, getitem_79, True, 0.001, [True, True, True]);  to_dtype_259 = convolution_default_24 = primals_240 = primals_238 = primals_239 = getitem_78 = getitem_79 = None
        getitem_845 = native_batch_norm_backward_default_85[0]
        getitem_846 = native_batch_norm_backward_default_85[1]
        getitem_847 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_845, relu__default_24, primals_108, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_845 = primals_108 = None
        getitem_848 = convolution_backward_default_85[0]
        getitem_849 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        to_dtype_260 = torch.ops.aten.to.dtype(getitem_848, torch.float32);  getitem_848 = None
        to_dtype_261 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_261, 0);  to_dtype_261 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_260, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_196, to_dtype_260);  le_scalar_86 = new_zeros_default_196 = to_dtype_260 = None
        to_dtype_262 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_262, cat_default_13, primals_235, primals_233, primals_234, getitem_75, getitem_76, True, 0.001, [True, True, True]);  to_dtype_262 = cat_default_13 = primals_235 = primals_233 = primals_234 = getitem_75 = getitem_76 = None
        getitem_851 = native_batch_norm_backward_default_86[0]
        getitem_852 = native_batch_norm_backward_default_86[1]
        getitem_853 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        slice_tensor_424 = torch.ops.aten.slice.Tensor(getitem_851, 1, 0, 512)
        slice_tensor_425 = torch.ops.aten.slice.Tensor(getitem_851, 1, 512, 832);  getitem_851 = None
        add_tensor_228 = torch.ops.aten.add.Tensor(add_tensor_225, slice_tensor_424);  add_tensor_225 = slice_tensor_424 = None
        add_tensor_229 = torch.ops.aten.add.Tensor(slice_tensor_422, slice_tensor_425);  slice_tensor_422 = slice_tensor_425 = None
        slice_tensor_426 = torch.ops.aten.slice.Tensor(add_tensor_229, 1, 0, 256)
        slice_tensor_427 = torch.ops.aten.slice.Tensor(add_tensor_229, 1, 256, 320);  add_tensor_229 = None
        slice_backward_default_240 = torch.ops.aten.slice_backward.default(slice_tensor_427, [64, 64, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_427 = None
        slice_backward_default_241 = torch.ops.aten.slice_backward.default(slice_backward_default_240, [64, 64, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_240 = None
        slice_backward_default_242 = torch.ops.aten.slice_backward.default(slice_backward_default_241, [64, 576, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_241 = None
        slice_backward_default_243 = torch.ops.aten.slice_backward.default(slice_backward_default_242, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_242 = None
        slice_backward_default_244 = torch.ops.aten.slice_backward.default(add_tensor_228, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1)
        slice_backward_default_245 = torch.ops.aten.slice_backward.default(slice_backward_default_244, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_244 = None
        slice_backward_default_246 = torch.ops.aten.slice_backward.default(slice_backward_default_245, [64, 576, 28, 28], 1, 0, 512, 1);  slice_backward_default_245 = None
        slice_backward_default_247 = torch.ops.aten.slice_backward.default(slice_backward_default_246, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_246 = None
        add_tensor_230 = torch.ops.aten.add.Tensor(slice_backward_default_243, slice_backward_default_247);  slice_backward_default_243 = slice_backward_default_247 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(add_tensor_230, relu__default_23, primals_106, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_230 = primals_106 = None
        getitem_854 = convolution_backward_default_86[0]
        getitem_855 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        to_dtype_263 = torch.ops.aten.to.dtype(getitem_854, torch.float32);  getitem_854 = None
        to_dtype_264 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_264, 0);  to_dtype_264 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_263, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_197, to_dtype_263);  le_scalar_87 = new_zeros_default_197 = to_dtype_263 = None
        to_dtype_265 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_265, convolution_default_22, primals_230, primals_228, primals_229, getitem_72, getitem_73, True, 0.001, [True, True, True]);  to_dtype_265 = convolution_default_22 = primals_230 = primals_228 = primals_229 = getitem_72 = getitem_73 = None
        getitem_857 = native_batch_norm_backward_default_87[0]
        getitem_858 = native_batch_norm_backward_default_87[1]
        getitem_859 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_857, relu__default_22, primals_107, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_857 = primals_107 = None
        getitem_860 = convolution_backward_default_87[0]
        getitem_861 = convolution_backward_default_87[1];  convolution_backward_default_87 = None
        to_dtype_266 = torch.ops.aten.to.dtype(getitem_860, torch.float32);  getitem_860 = None
        to_dtype_267 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_267, 0);  to_dtype_267 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_266, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_198, to_dtype_266);  le_scalar_88 = new_zeros_default_198 = to_dtype_266 = None
        to_dtype_268 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_268, convolution_default_21, primals_225, primals_223, primals_224, getitem_69, getitem_70, True, 0.001, [True, True, True]);  to_dtype_268 = convolution_default_21 = primals_225 = primals_223 = primals_224 = getitem_69 = getitem_70 = None
        getitem_863 = native_batch_norm_backward_default_88[0]
        getitem_864 = native_batch_norm_backward_default_88[1]
        getitem_865 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_863, relu__default_21, primals_105, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_863 = primals_105 = None
        getitem_866 = convolution_backward_default_88[0]
        getitem_867 = convolution_backward_default_88[1];  convolution_backward_default_88 = None
        to_dtype_269 = torch.ops.aten.to.dtype(getitem_866, torch.float32);  getitem_866 = None
        to_dtype_270 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_270, 0);  to_dtype_270 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_269, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_199, to_dtype_269);  le_scalar_89 = new_zeros_default_199 = to_dtype_269 = None
        to_dtype_271 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_271, cat_default_11, primals_220, primals_218, primals_219, getitem_66, getitem_67, True, 0.001, [True, True, True]);  to_dtype_271 = cat_default_11 = primals_220 = primals_218 = primals_219 = getitem_66 = getitem_67 = None
        getitem_869 = native_batch_norm_backward_default_89[0]
        getitem_870 = native_batch_norm_backward_default_89[1]
        getitem_871 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        slice_tensor_428 = torch.ops.aten.slice.Tensor(getitem_869, 1, 0, 512)
        slice_tensor_429 = torch.ops.aten.slice.Tensor(getitem_869, 1, 512, 768);  getitem_869 = None
        add_tensor_231 = torch.ops.aten.add.Tensor(add_tensor_228, slice_tensor_428);  add_tensor_228 = slice_tensor_428 = None
        add_tensor_232 = torch.ops.aten.add.Tensor(slice_tensor_426, slice_tensor_429);  slice_tensor_426 = slice_tensor_429 = None
        slice_tensor_430 = torch.ops.aten.slice.Tensor(add_tensor_232, 1, 0, 192)
        slice_tensor_431 = torch.ops.aten.slice.Tensor(add_tensor_232, 1, 192, 256);  add_tensor_232 = None
        slice_backward_default_248 = torch.ops.aten.slice_backward.default(slice_tensor_431, [64, 64, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_431 = None
        slice_backward_default_249 = torch.ops.aten.slice_backward.default(slice_backward_default_248, [64, 64, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_248 = None
        slice_backward_default_250 = torch.ops.aten.slice_backward.default(slice_backward_default_249, [64, 576, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_249 = None
        slice_backward_default_251 = torch.ops.aten.slice_backward.default(slice_backward_default_250, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_250 = None
        slice_backward_default_252 = torch.ops.aten.slice_backward.default(add_tensor_231, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1)
        slice_backward_default_253 = torch.ops.aten.slice_backward.default(slice_backward_default_252, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_252 = None
        slice_backward_default_254 = torch.ops.aten.slice_backward.default(slice_backward_default_253, [64, 576, 28, 28], 1, 0, 512, 1);  slice_backward_default_253 = None
        slice_backward_default_255 = torch.ops.aten.slice_backward.default(slice_backward_default_254, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_254 = None
        add_tensor_233 = torch.ops.aten.add.Tensor(slice_backward_default_251, slice_backward_default_255);  slice_backward_default_251 = slice_backward_default_255 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(add_tensor_233, relu__default_20, primals_103, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_233 = primals_103 = None
        getitem_872 = convolution_backward_default_89[0]
        getitem_873 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        to_dtype_272 = torch.ops.aten.to.dtype(getitem_872, torch.float32);  getitem_872 = None
        to_dtype_273 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_273, 0);  to_dtype_273 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_272, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_200, to_dtype_272);  le_scalar_90 = new_zeros_default_200 = to_dtype_272 = None
        to_dtype_274 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_274, convolution_default_19, primals_215, primals_213, primals_214, getitem_63, getitem_64, True, 0.001, [True, True, True]);  to_dtype_274 = convolution_default_19 = primals_215 = primals_213 = primals_214 = getitem_63 = getitem_64 = None
        getitem_875 = native_batch_norm_backward_default_90[0]
        getitem_876 = native_batch_norm_backward_default_90[1]
        getitem_877 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_875, relu__default_19, primals_104, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_875 = primals_104 = None
        getitem_878 = convolution_backward_default_90[0]
        getitem_879 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        to_dtype_275 = torch.ops.aten.to.dtype(getitem_878, torch.float32);  getitem_878 = None
        to_dtype_276 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_276, 0);  to_dtype_276 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_275, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_201, to_dtype_275);  le_scalar_91 = new_zeros_default_201 = to_dtype_275 = None
        to_dtype_277 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_277, convolution_default_18, primals_210, primals_208, primals_209, getitem_60, getitem_61, True, 0.001, [True, True, True]);  to_dtype_277 = convolution_default_18 = primals_210 = primals_208 = primals_209 = getitem_60 = getitem_61 = None
        getitem_881 = native_batch_norm_backward_default_91[0]
        getitem_882 = native_batch_norm_backward_default_91[1]
        getitem_883 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_881, relu__default_18, primals_102, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_881 = primals_102 = None
        getitem_884 = convolution_backward_default_91[0]
        getitem_885 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        to_dtype_278 = torch.ops.aten.to.dtype(getitem_884, torch.float32);  getitem_884 = None
        to_dtype_279 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_279, 0);  to_dtype_279 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_278, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_202, to_dtype_278);  le_scalar_92 = new_zeros_default_202 = to_dtype_278 = None
        to_dtype_280 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_280, cat_default_9, primals_205, primals_203, primals_204, getitem_57, getitem_58, True, 0.001, [True, True, True]);  to_dtype_280 = cat_default_9 = primals_205 = primals_203 = primals_204 = getitem_57 = getitem_58 = None
        getitem_887 = native_batch_norm_backward_default_92[0]
        getitem_888 = native_batch_norm_backward_default_92[1]
        getitem_889 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        slice_tensor_432 = torch.ops.aten.slice.Tensor(getitem_887, 1, 0, 512)
        slice_tensor_433 = torch.ops.aten.slice.Tensor(getitem_887, 1, 512, 704);  getitem_887 = None
        add_tensor_234 = torch.ops.aten.add.Tensor(add_tensor_231, slice_tensor_432);  add_tensor_231 = slice_tensor_432 = None
        add_tensor_235 = torch.ops.aten.add.Tensor(slice_tensor_430, slice_tensor_433);  slice_tensor_430 = slice_tensor_433 = None
        slice_tensor_434 = torch.ops.aten.slice.Tensor(add_tensor_235, 1, 0, 128)
        slice_tensor_435 = torch.ops.aten.slice.Tensor(add_tensor_235, 1, 128, 192);  add_tensor_235 = None
        slice_backward_default_256 = torch.ops.aten.slice_backward.default(slice_tensor_435, [64, 64, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_435 = None
        slice_backward_default_257 = torch.ops.aten.slice_backward.default(slice_backward_default_256, [64, 64, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_256 = None
        slice_backward_default_258 = torch.ops.aten.slice_backward.default(slice_backward_default_257, [64, 576, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_257 = None
        slice_backward_default_259 = torch.ops.aten.slice_backward.default(slice_backward_default_258, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_258 = None
        slice_backward_default_260 = torch.ops.aten.slice_backward.default(add_tensor_234, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1)
        slice_backward_default_261 = torch.ops.aten.slice_backward.default(slice_backward_default_260, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_260 = None
        slice_backward_default_262 = torch.ops.aten.slice_backward.default(slice_backward_default_261, [64, 576, 28, 28], 1, 0, 512, 1);  slice_backward_default_261 = None
        slice_backward_default_263 = torch.ops.aten.slice_backward.default(slice_backward_default_262, [64, 576, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_262 = None
        add_tensor_236 = torch.ops.aten.add.Tensor(slice_backward_default_259, slice_backward_default_263);  slice_backward_default_259 = slice_backward_default_263 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(add_tensor_236, relu__default_17, primals_99, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_236 = primals_99 = None
        getitem_890 = convolution_backward_default_92[0]
        getitem_891 = convolution_backward_default_92[1];  convolution_backward_default_92 = None
        to_dtype_281 = torch.ops.aten.to.dtype(getitem_890, torch.float32);  getitem_890 = None
        to_dtype_282 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_282, 0);  to_dtype_282 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_281, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_203, to_dtype_281);  le_scalar_93 = new_zeros_default_203 = to_dtype_281 = None
        to_dtype_283 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_283, convolution_default_16, primals_200, primals_198, primals_199, getitem_54, getitem_55, True, 0.001, [True, True, True]);  to_dtype_283 = convolution_default_16 = primals_200 = primals_198 = primals_199 = getitem_54 = getitem_55 = None
        getitem_893 = native_batch_norm_backward_default_93[0]
        getitem_894 = native_batch_norm_backward_default_93[1]
        getitem_895 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_893, relu__default_16, primals_101, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_893 = primals_101 = None
        getitem_896 = convolution_backward_default_93[0]
        getitem_897 = convolution_backward_default_93[1];  convolution_backward_default_93 = None
        to_dtype_284 = torch.ops.aten.to.dtype(getitem_896, torch.float32);  getitem_896 = None
        to_dtype_285 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_285, 0);  to_dtype_285 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_284, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_204, to_dtype_284);  le_scalar_94 = new_zeros_default_204 = to_dtype_284 = None
        to_dtype_286 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_286, convolution_default_15, primals_195, primals_193, primals_194, getitem_51, getitem_52, True, 0.001, [True, True, True]);  to_dtype_286 = convolution_default_15 = primals_195 = primals_193 = primals_194 = getitem_51 = getitem_52 = None
        getitem_899 = native_batch_norm_backward_default_94[0]
        getitem_900 = native_batch_norm_backward_default_94[1]
        getitem_901 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_899, relu__default_15, primals_98, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_899 = primals_98 = None
        getitem_902 = convolution_backward_default_94[0]
        getitem_903 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        to_dtype_287 = torch.ops.aten.to.dtype(getitem_902, torch.float32);  getitem_902 = None
        to_dtype_288 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_288, 0);  to_dtype_288 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_287, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_205, to_dtype_287);  le_scalar_95 = new_zeros_default_205 = to_dtype_287 = None
        to_dtype_289 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_289, cat_default_7, primals_190, primals_188, primals_189, getitem_48, getitem_49, True, 0.001, [True, True, True]);  to_dtype_289 = primals_190 = primals_188 = primals_189 = getitem_48 = getitem_49 = None
        getitem_905 = native_batch_norm_backward_default_95[0]
        getitem_906 = native_batch_norm_backward_default_95[1]
        getitem_907 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        slice_backward_default_264 = torch.ops.aten.slice_backward.default(slice_tensor_434, [64, 128, 28, 28], 3, 0, 9223372036854775807, 1);  slice_tensor_434 = None
        slice_backward_default_265 = torch.ops.aten.slice_backward.default(slice_backward_default_264, [64, 128, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_264 = None
        slice_backward_default_266 = torch.ops.aten.slice_backward.default(slice_backward_default_265, [64, 640, 28, 28], 1, 512, 9223372036854775807, 1);  slice_backward_default_265 = None
        slice_backward_default_267 = torch.ops.aten.slice_backward.default(slice_backward_default_266, [64, 640, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_266 = None
        slice_backward_default_268 = torch.ops.aten.slice_backward.default(add_tensor_234, [64, 512, 28, 28], 3, 0, 9223372036854775807, 1);  add_tensor_234 = None
        slice_backward_default_269 = torch.ops.aten.slice_backward.default(slice_backward_default_268, [64, 512, 28, 28], 2, 0, 9223372036854775807, 1);  slice_backward_default_268 = None
        slice_backward_default_270 = torch.ops.aten.slice_backward.default(slice_backward_default_269, [64, 640, 28, 28], 1, 0, 512, 1);  slice_backward_default_269 = None
        slice_backward_default_271 = torch.ops.aten.slice_backward.default(slice_backward_default_270, [64, 640, 28, 28], 0, 0, 9223372036854775807, 1);  slice_backward_default_270 = None
        add_tensor_237 = torch.ops.aten.add.Tensor(slice_backward_default_267, slice_backward_default_271);  slice_backward_default_267 = slice_backward_default_271 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(add_tensor_237, relu__default_14, primals_100, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_237 = primals_100 = None
        getitem_908 = convolution_backward_default_95[0]
        getitem_909 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        to_dtype_290 = torch.ops.aten.to.dtype(getitem_908, torch.float32);  getitem_908 = None
        to_dtype_291 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_291, 0);  to_dtype_291 = None
        new_zeros_default_206 = torch.ops.aten.new_zeros.default(to_dtype_290, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_206, to_dtype_290);  le_scalar_96 = new_zeros_default_206 = to_dtype_290 = None
        to_dtype_292 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_292, cat_default_7, primals_185, primals_183, primals_184, getitem_45, getitem_46, True, 0.001, [True, True, True]);  to_dtype_292 = cat_default_7 = primals_185 = primals_183 = primals_184 = getitem_45 = getitem_46 = None
        getitem_911 = native_batch_norm_backward_default_96[0]
        getitem_912 = native_batch_norm_backward_default_96[1]
        getitem_913 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        add_tensor_238 = torch.ops.aten.add.Tensor(getitem_905, getitem_911);  getitem_905 = getitem_911 = None
        slice_tensor_436 = torch.ops.aten.slice.Tensor(add_tensor_238, 1, 0, 256)
        slice_tensor_437 = torch.ops.aten.slice.Tensor(add_tensor_238, 1, 256, 376);  add_tensor_238 = None
        slice_tensor_438 = torch.ops.aten.slice.Tensor(slice_tensor_437, 1, 0, 100)
        slice_tensor_439 = torch.ops.aten.slice.Tensor(slice_tensor_437, 1, 100, 120);  slice_tensor_437 = None
        slice_backward_default_272 = torch.ops.aten.slice_backward.default(slice_tensor_439, [64, 20, 56, 56], 3, 0, 9223372036854775807, 1);  slice_tensor_439 = None
        slice_backward_default_273 = torch.ops.aten.slice_backward.default(slice_backward_default_272, [64, 20, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_272 = None
        slice_backward_default_274 = torch.ops.aten.slice_backward.default(slice_backward_default_273, [64, 276, 56, 56], 1, 256, 9223372036854775807, 1);  slice_backward_default_273 = None
        slice_backward_default_275 = torch.ops.aten.slice_backward.default(slice_backward_default_274, [64, 276, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_274 = None
        slice_backward_default_276 = torch.ops.aten.slice_backward.default(slice_tensor_436, [64, 256, 56, 56], 3, 0, 9223372036854775807, 1)
        slice_backward_default_277 = torch.ops.aten.slice_backward.default(slice_backward_default_276, [64, 256, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_276 = None
        slice_backward_default_278 = torch.ops.aten.slice_backward.default(slice_backward_default_277, [64, 276, 56, 56], 1, 0, 256, 1);  slice_backward_default_277 = None
        slice_backward_default_279 = torch.ops.aten.slice_backward.default(slice_backward_default_278, [64, 276, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_278 = None
        add_tensor_239 = torch.ops.aten.add.Tensor(slice_backward_default_275, slice_backward_default_279);  slice_backward_default_275 = slice_backward_default_279 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(add_tensor_239, relu__default_13, primals_96, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_239 = primals_96 = None
        getitem_914 = convolution_backward_default_96[0]
        getitem_915 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        to_dtype_293 = torch.ops.aten.to.dtype(getitem_914, torch.float32);  getitem_914 = None
        to_dtype_294 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_294, 0);  to_dtype_294 = None
        new_zeros_default_207 = torch.ops.aten.new_zeros.default(to_dtype_293, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_207, to_dtype_293);  le_scalar_97 = new_zeros_default_207 = to_dtype_293 = None
        to_dtype_295 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_295, convolution_default_12, primals_180, primals_178, primals_179, getitem_42, getitem_43, True, 0.001, [True, True, True]);  to_dtype_295 = convolution_default_12 = primals_180 = primals_178 = primals_179 = getitem_42 = getitem_43 = None
        getitem_917 = native_batch_norm_backward_default_97[0]
        getitem_918 = native_batch_norm_backward_default_97[1]
        getitem_919 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_917, relu__default_12, primals_97, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_917 = primals_97 = None
        getitem_920 = convolution_backward_default_97[0]
        getitem_921 = convolution_backward_default_97[1];  convolution_backward_default_97 = None
        to_dtype_296 = torch.ops.aten.to.dtype(getitem_920, torch.float32);  getitem_920 = None
        to_dtype_297 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_297, 0);  to_dtype_297 = None
        new_zeros_default_208 = torch.ops.aten.new_zeros.default(to_dtype_296, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_208, to_dtype_296);  le_scalar_98 = new_zeros_default_208 = to_dtype_296 = None
        to_dtype_298 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_298, convolution_default_11, primals_175, primals_173, primals_174, getitem_39, getitem_40, True, 0.001, [True, True, True]);  to_dtype_298 = convolution_default_11 = primals_175 = primals_173 = primals_174 = getitem_39 = getitem_40 = None
        getitem_923 = native_batch_norm_backward_default_98[0]
        getitem_924 = native_batch_norm_backward_default_98[1]
        getitem_925 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_923, relu__default_11, primals_95, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_923 = primals_95 = None
        getitem_926 = convolution_backward_default_98[0]
        getitem_927 = convolution_backward_default_98[1];  convolution_backward_default_98 = None
        to_dtype_299 = torch.ops.aten.to.dtype(getitem_926, torch.float32);  getitem_926 = None
        to_dtype_300 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_300, 0);  to_dtype_300 = None
        new_zeros_default_209 = torch.ops.aten.new_zeros.default(to_dtype_299, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_209, to_dtype_299);  le_scalar_99 = new_zeros_default_209 = to_dtype_299 = None
        to_dtype_301 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_301, cat_default_5, primals_170, primals_168, primals_169, getitem_36, getitem_37, True, 0.001, [True, True, True]);  to_dtype_301 = cat_default_5 = primals_170 = primals_168 = primals_169 = getitem_36 = getitem_37 = None
        getitem_929 = native_batch_norm_backward_default_99[0]
        getitem_930 = native_batch_norm_backward_default_99[1]
        getitem_931 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        slice_tensor_440 = torch.ops.aten.slice.Tensor(getitem_929, 1, 0, 256)
        slice_tensor_441 = torch.ops.aten.slice.Tensor(getitem_929, 1, 256, 356);  getitem_929 = None
        add_tensor_240 = torch.ops.aten.add.Tensor(slice_tensor_436, slice_tensor_440);  slice_tensor_436 = slice_tensor_440 = None
        add_tensor_241 = torch.ops.aten.add.Tensor(slice_tensor_438, slice_tensor_441);  slice_tensor_438 = slice_tensor_441 = None
        slice_tensor_442 = torch.ops.aten.slice.Tensor(add_tensor_241, 1, 0, 80)
        slice_tensor_443 = torch.ops.aten.slice.Tensor(add_tensor_241, 1, 80, 100);  add_tensor_241 = None
        slice_backward_default_280 = torch.ops.aten.slice_backward.default(slice_tensor_443, [64, 20, 56, 56], 3, 0, 9223372036854775807, 1);  slice_tensor_443 = None
        slice_backward_default_281 = torch.ops.aten.slice_backward.default(slice_backward_default_280, [64, 20, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_280 = None
        slice_backward_default_282 = torch.ops.aten.slice_backward.default(slice_backward_default_281, [64, 276, 56, 56], 1, 256, 9223372036854775807, 1);  slice_backward_default_281 = None
        slice_backward_default_283 = torch.ops.aten.slice_backward.default(slice_backward_default_282, [64, 276, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_282 = None
        slice_backward_default_284 = torch.ops.aten.slice_backward.default(add_tensor_240, [64, 256, 56, 56], 3, 0, 9223372036854775807, 1)
        slice_backward_default_285 = torch.ops.aten.slice_backward.default(slice_backward_default_284, [64, 256, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_284 = None
        slice_backward_default_286 = torch.ops.aten.slice_backward.default(slice_backward_default_285, [64, 276, 56, 56], 1, 0, 256, 1);  slice_backward_default_285 = None
        slice_backward_default_287 = torch.ops.aten.slice_backward.default(slice_backward_default_286, [64, 276, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_286 = None
        add_tensor_242 = torch.ops.aten.add.Tensor(slice_backward_default_283, slice_backward_default_287);  slice_backward_default_283 = slice_backward_default_287 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(add_tensor_242, relu__default_10, primals_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_242 = primals_93 = None
        getitem_932 = convolution_backward_default_99[0]
        getitem_933 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        to_dtype_302 = torch.ops.aten.to.dtype(getitem_932, torch.float32);  getitem_932 = None
        to_dtype_303 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_303, 0);  to_dtype_303 = None
        new_zeros_default_210 = torch.ops.aten.new_zeros.default(to_dtype_302, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_101 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_210, to_dtype_302);  le_scalar_100 = new_zeros_default_210 = to_dtype_302 = None
        to_dtype_304 = torch.ops.aten.to.dtype(where_self_101, torch.float32);  where_self_101 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_304, convolution_default_9, primals_165, primals_163, primals_164, getitem_33, getitem_34, True, 0.001, [True, True, True]);  to_dtype_304 = convolution_default_9 = primals_165 = primals_163 = primals_164 = getitem_33 = getitem_34 = None
        getitem_935 = native_batch_norm_backward_default_100[0]
        getitem_936 = native_batch_norm_backward_default_100[1]
        getitem_937 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_935, relu__default_9, primals_94, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_935 = primals_94 = None
        getitem_938 = convolution_backward_default_100[0]
        getitem_939 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        to_dtype_305 = torch.ops.aten.to.dtype(getitem_938, torch.float32);  getitem_938 = None
        to_dtype_306 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_101 = torch.ops.aten.le.Scalar(to_dtype_306, 0);  to_dtype_306 = None
        new_zeros_default_211 = torch.ops.aten.new_zeros.default(to_dtype_305, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_102 = torch.ops.aten.where.self(le_scalar_101, new_zeros_default_211, to_dtype_305);  le_scalar_101 = new_zeros_default_211 = to_dtype_305 = None
        to_dtype_307 = torch.ops.aten.to.dtype(where_self_102, torch.float32);  where_self_102 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_307, convolution_default_8, primals_160, primals_158, primals_159, getitem_30, getitem_31, True, 0.001, [True, True, True]);  to_dtype_307 = convolution_default_8 = primals_160 = primals_158 = primals_159 = getitem_30 = getitem_31 = None
        getitem_941 = native_batch_norm_backward_default_101[0]
        getitem_942 = native_batch_norm_backward_default_101[1]
        getitem_943 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_941, relu__default_8, primals_92, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_941 = primals_92 = None
        getitem_944 = convolution_backward_default_101[0]
        getitem_945 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        to_dtype_308 = torch.ops.aten.to.dtype(getitem_944, torch.float32);  getitem_944 = None
        to_dtype_309 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_102 = torch.ops.aten.le.Scalar(to_dtype_309, 0);  to_dtype_309 = None
        new_zeros_default_212 = torch.ops.aten.new_zeros.default(to_dtype_308, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_103 = torch.ops.aten.where.self(le_scalar_102, new_zeros_default_212, to_dtype_308);  le_scalar_102 = new_zeros_default_212 = to_dtype_308 = None
        to_dtype_310 = torch.ops.aten.to.dtype(where_self_103, torch.float32);  where_self_103 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_310, cat_default_3, primals_155, primals_153, primals_154, getitem_27, getitem_28, True, 0.001, [True, True, True]);  to_dtype_310 = cat_default_3 = primals_155 = primals_153 = primals_154 = getitem_27 = getitem_28 = None
        getitem_947 = native_batch_norm_backward_default_102[0]
        getitem_948 = native_batch_norm_backward_default_102[1]
        getitem_949 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        slice_tensor_444 = torch.ops.aten.slice.Tensor(getitem_947, 1, 0, 256)
        slice_tensor_445 = torch.ops.aten.slice.Tensor(getitem_947, 1, 256, 336);  getitem_947 = None
        add_tensor_243 = torch.ops.aten.add.Tensor(add_tensor_240, slice_tensor_444);  add_tensor_240 = slice_tensor_444 = None
        add_tensor_244 = torch.ops.aten.add.Tensor(slice_tensor_442, slice_tensor_445);  slice_tensor_442 = slice_tensor_445 = None
        slice_tensor_446 = torch.ops.aten.slice.Tensor(add_tensor_244, 1, 0, 60)
        slice_tensor_447 = torch.ops.aten.slice.Tensor(add_tensor_244, 1, 60, 80);  add_tensor_244 = None
        slice_backward_default_288 = torch.ops.aten.slice_backward.default(slice_tensor_447, [64, 20, 56, 56], 3, 0, 9223372036854775807, 1);  slice_tensor_447 = None
        slice_backward_default_289 = torch.ops.aten.slice_backward.default(slice_backward_default_288, [64, 20, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_288 = None
        slice_backward_default_290 = torch.ops.aten.slice_backward.default(slice_backward_default_289, [64, 276, 56, 56], 1, 256, 9223372036854775807, 1);  slice_backward_default_289 = None
        slice_backward_default_291 = torch.ops.aten.slice_backward.default(slice_backward_default_290, [64, 276, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_290 = None
        slice_backward_default_292 = torch.ops.aten.slice_backward.default(add_tensor_243, [64, 256, 56, 56], 3, 0, 9223372036854775807, 1)
        slice_backward_default_293 = torch.ops.aten.slice_backward.default(slice_backward_default_292, [64, 256, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_292 = None
        slice_backward_default_294 = torch.ops.aten.slice_backward.default(slice_backward_default_293, [64, 276, 56, 56], 1, 0, 256, 1);  slice_backward_default_293 = None
        slice_backward_default_295 = torch.ops.aten.slice_backward.default(slice_backward_default_294, [64, 276, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_294 = None
        add_tensor_245 = torch.ops.aten.add.Tensor(slice_backward_default_291, slice_backward_default_295);  slice_backward_default_291 = slice_backward_default_295 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(add_tensor_245, relu__default_7, primals_90, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_245 = primals_90 = None
        getitem_950 = convolution_backward_default_102[0]
        getitem_951 = convolution_backward_default_102[1];  convolution_backward_default_102 = None
        to_dtype_311 = torch.ops.aten.to.dtype(getitem_950, torch.float32);  getitem_950 = None
        to_dtype_312 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_103 = torch.ops.aten.le.Scalar(to_dtype_312, 0);  to_dtype_312 = None
        new_zeros_default_213 = torch.ops.aten.new_zeros.default(to_dtype_311, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_104 = torch.ops.aten.where.self(le_scalar_103, new_zeros_default_213, to_dtype_311);  le_scalar_103 = new_zeros_default_213 = to_dtype_311 = None
        to_dtype_313 = torch.ops.aten.to.dtype(where_self_104, torch.float32);  where_self_104 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_313, convolution_default_6, primals_150, primals_148, primals_149, getitem_24, getitem_25, True, 0.001, [True, True, True]);  to_dtype_313 = convolution_default_6 = primals_150 = primals_148 = primals_149 = getitem_24 = getitem_25 = None
        getitem_953 = native_batch_norm_backward_default_103[0]
        getitem_954 = native_batch_norm_backward_default_103[1]
        getitem_955 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_953, relu__default_6, primals_91, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_953 = primals_91 = None
        getitem_956 = convolution_backward_default_103[0]
        getitem_957 = convolution_backward_default_103[1];  convolution_backward_default_103 = None
        to_dtype_314 = torch.ops.aten.to.dtype(getitem_956, torch.float32);  getitem_956 = None
        to_dtype_315 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_104 = torch.ops.aten.le.Scalar(to_dtype_315, 0);  to_dtype_315 = None
        new_zeros_default_214 = torch.ops.aten.new_zeros.default(to_dtype_314, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_105 = torch.ops.aten.where.self(le_scalar_104, new_zeros_default_214, to_dtype_314);  le_scalar_104 = new_zeros_default_214 = to_dtype_314 = None
        to_dtype_316 = torch.ops.aten.to.dtype(where_self_105, torch.float32);  where_self_105 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_316, convolution_default_5, primals_145, primals_143, primals_144, getitem_21, getitem_22, True, 0.001, [True, True, True]);  to_dtype_316 = convolution_default_5 = primals_145 = primals_143 = primals_144 = getitem_21 = getitem_22 = None
        getitem_959 = native_batch_norm_backward_default_104[0]
        getitem_960 = native_batch_norm_backward_default_104[1]
        getitem_961 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_959, relu__default_5, primals_89, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_959 = primals_89 = None
        getitem_962 = convolution_backward_default_104[0]
        getitem_963 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        to_dtype_317 = torch.ops.aten.to.dtype(getitem_962, torch.float32);  getitem_962 = None
        to_dtype_318 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_105 = torch.ops.aten.le.Scalar(to_dtype_318, 0);  to_dtype_318 = None
        new_zeros_default_215 = torch.ops.aten.new_zeros.default(to_dtype_317, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_106 = torch.ops.aten.where.self(le_scalar_105, new_zeros_default_215, to_dtype_317);  le_scalar_105 = new_zeros_default_215 = to_dtype_317 = None
        to_dtype_319 = torch.ops.aten.to.dtype(where_self_106, torch.float32);  where_self_106 = None
        native_batch_norm_backward_default_105 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_319, cat_default_1, primals_140, primals_138, primals_139, getitem_18, getitem_19, True, 0.001, [True, True, True]);  to_dtype_319 = cat_default_1 = primals_140 = primals_138 = primals_139 = getitem_18 = getitem_19 = None
        getitem_965 = native_batch_norm_backward_default_105[0]
        getitem_966 = native_batch_norm_backward_default_105[1]
        getitem_967 = native_batch_norm_backward_default_105[2];  native_batch_norm_backward_default_105 = None
        slice_tensor_448 = torch.ops.aten.slice.Tensor(getitem_965, 1, 0, 256)
        slice_tensor_449 = torch.ops.aten.slice.Tensor(getitem_965, 1, 256, 316);  getitem_965 = None
        add_tensor_246 = torch.ops.aten.add.Tensor(add_tensor_243, slice_tensor_448);  add_tensor_243 = slice_tensor_448 = None
        add_tensor_247 = torch.ops.aten.add.Tensor(slice_tensor_446, slice_tensor_449);  slice_tensor_446 = slice_tensor_449 = None
        slice_tensor_450 = torch.ops.aten.slice.Tensor(add_tensor_247, 1, 0, 40)
        slice_tensor_451 = torch.ops.aten.slice.Tensor(add_tensor_247, 1, 40, 60);  add_tensor_247 = None
        slice_backward_default_296 = torch.ops.aten.slice_backward.default(slice_tensor_451, [64, 20, 56, 56], 3, 0, 9223372036854775807, 1);  slice_tensor_451 = None
        slice_backward_default_297 = torch.ops.aten.slice_backward.default(slice_backward_default_296, [64, 20, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_296 = None
        slice_backward_default_298 = torch.ops.aten.slice_backward.default(slice_backward_default_297, [64, 276, 56, 56], 1, 256, 9223372036854775807, 1);  slice_backward_default_297 = None
        slice_backward_default_299 = torch.ops.aten.slice_backward.default(slice_backward_default_298, [64, 276, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_298 = None
        slice_backward_default_300 = torch.ops.aten.slice_backward.default(add_tensor_246, [64, 256, 56, 56], 3, 0, 9223372036854775807, 1)
        slice_backward_default_301 = torch.ops.aten.slice_backward.default(slice_backward_default_300, [64, 256, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_300 = None
        slice_backward_default_302 = torch.ops.aten.slice_backward.default(slice_backward_default_301, [64, 276, 56, 56], 1, 0, 256, 1);  slice_backward_default_301 = None
        slice_backward_default_303 = torch.ops.aten.slice_backward.default(slice_backward_default_302, [64, 276, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_302 = None
        add_tensor_248 = torch.ops.aten.add.Tensor(slice_backward_default_299, slice_backward_default_303);  slice_backward_default_299 = slice_backward_default_303 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(add_tensor_248, relu__default_4, primals_64, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_248 = primals_64 = None
        getitem_968 = convolution_backward_default_105[0]
        getitem_969 = convolution_backward_default_105[1];  convolution_backward_default_105 = None
        to_dtype_320 = torch.ops.aten.to.dtype(getitem_968, torch.float32);  getitem_968 = None
        to_dtype_321 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_106 = torch.ops.aten.le.Scalar(to_dtype_321, 0);  to_dtype_321 = None
        new_zeros_default_216 = torch.ops.aten.new_zeros.default(to_dtype_320, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_107 = torch.ops.aten.where.self(le_scalar_106, new_zeros_default_216, to_dtype_320);  le_scalar_106 = new_zeros_default_216 = to_dtype_320 = None
        to_dtype_322 = torch.ops.aten.to.dtype(where_self_107, torch.float32);  where_self_107 = None
        native_batch_norm_backward_default_106 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_322, convolution_default_3, primals_135, primals_133, primals_134, getitem_15, getitem_16, True, 0.001, [True, True, True]);  to_dtype_322 = convolution_default_3 = primals_135 = primals_133 = primals_134 = getitem_15 = getitem_16 = None
        getitem_971 = native_batch_norm_backward_default_106[0]
        getitem_972 = native_batch_norm_backward_default_106[1]
        getitem_973 = native_batch_norm_backward_default_106[2];  native_batch_norm_backward_default_106 = None
        convolution_backward_default_106 = torch.ops.aten.convolution_backward.default(getitem_971, relu__default_3, primals_66, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 50, [True, True, False]);  getitem_971 = primals_66 = None
        getitem_974 = convolution_backward_default_106[0]
        getitem_975 = convolution_backward_default_106[1];  convolution_backward_default_106 = None
        to_dtype_323 = torch.ops.aten.to.dtype(getitem_974, torch.float32);  getitem_974 = None
        to_dtype_324 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_107 = torch.ops.aten.le.Scalar(to_dtype_324, 0);  to_dtype_324 = None
        new_zeros_default_217 = torch.ops.aten.new_zeros.default(to_dtype_323, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_108 = torch.ops.aten.where.self(le_scalar_107, new_zeros_default_217, to_dtype_323);  le_scalar_107 = new_zeros_default_217 = to_dtype_323 = None
        to_dtype_325 = torch.ops.aten.to.dtype(where_self_108, torch.float32);  where_self_108 = None
        native_batch_norm_backward_default_107 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_325, convolution_default_2, primals_130, primals_128, primals_129, getitem_12, getitem_13, True, 0.001, [True, True, True]);  to_dtype_325 = convolution_default_2 = primals_130 = primals_128 = primals_129 = getitem_12 = getitem_13 = None
        getitem_977 = native_batch_norm_backward_default_107[0]
        getitem_978 = native_batch_norm_backward_default_107[1]
        getitem_979 = native_batch_norm_backward_default_107[2];  native_batch_norm_backward_default_107 = None
        convolution_backward_default_107 = torch.ops.aten.convolution_backward.default(getitem_977, relu__default_2, primals_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_977 = primals_63 = None
        getitem_980 = convolution_backward_default_107[0]
        getitem_981 = convolution_backward_default_107[1];  convolution_backward_default_107 = None
        to_dtype_326 = torch.ops.aten.to.dtype(getitem_980, torch.float32);  getitem_980 = None
        to_dtype_327 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_108 = torch.ops.aten.le.Scalar(to_dtype_327, 0);  to_dtype_327 = None
        new_zeros_default_218 = torch.ops.aten.new_zeros.default(to_dtype_326, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_109 = torch.ops.aten.where.self(le_scalar_108, new_zeros_default_218, to_dtype_326);  le_scalar_108 = new_zeros_default_218 = to_dtype_326 = None
        to_dtype_328 = torch.ops.aten.to.dtype(where_self_109, torch.float32);  where_self_109 = None
        native_batch_norm_backward_default_108 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_328, getitem_3, primals_125, primals_123, primals_124, getitem_9, getitem_10, True, 0.001, [True, True, True]);  to_dtype_328 = primals_125 = primals_123 = primals_124 = getitem_9 = getitem_10 = None
        getitem_983 = native_batch_norm_backward_default_108[0]
        getitem_984 = native_batch_norm_backward_default_108[1]
        getitem_985 = native_batch_norm_backward_default_108[2];  native_batch_norm_backward_default_108 = None
        slice_backward_default_304 = torch.ops.aten.slice_backward.default(slice_tensor_450, [64, 40, 56, 56], 3, 0, 9223372036854775807, 1);  slice_tensor_450 = None
        slice_backward_default_305 = torch.ops.aten.slice_backward.default(slice_backward_default_304, [64, 40, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_304 = None
        slice_backward_default_306 = torch.ops.aten.slice_backward.default(slice_backward_default_305, [64, 296, 56, 56], 1, 256, 9223372036854775807, 1);  slice_backward_default_305 = None
        slice_backward_default_307 = torch.ops.aten.slice_backward.default(slice_backward_default_306, [64, 296, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_306 = None
        slice_backward_default_308 = torch.ops.aten.slice_backward.default(add_tensor_246, [64, 256, 56, 56], 3, 0, 9223372036854775807, 1);  add_tensor_246 = None
        slice_backward_default_309 = torch.ops.aten.slice_backward.default(slice_backward_default_308, [64, 256, 56, 56], 2, 0, 9223372036854775807, 1);  slice_backward_default_308 = None
        slice_backward_default_310 = torch.ops.aten.slice_backward.default(slice_backward_default_309, [64, 296, 56, 56], 1, 0, 256, 1);  slice_backward_default_309 = None
        slice_backward_default_311 = torch.ops.aten.slice_backward.default(slice_backward_default_310, [64, 296, 56, 56], 0, 0, 9223372036854775807, 1);  slice_backward_default_310 = None
        add_tensor_249 = torch.ops.aten.add.Tensor(slice_backward_default_307, slice_backward_default_311);  slice_backward_default_307 = slice_backward_default_311 = None
        convolution_backward_default_108 = torch.ops.aten.convolution_backward.default(add_tensor_249, relu__default_1, primals_65, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_249 = primals_65 = None
        getitem_986 = convolution_backward_default_108[0]
        getitem_987 = convolution_backward_default_108[1];  convolution_backward_default_108 = None
        to_dtype_329 = torch.ops.aten.to.dtype(getitem_986, torch.float32);  getitem_986 = None
        to_dtype_330 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_109 = torch.ops.aten.le.Scalar(to_dtype_330, 0);  to_dtype_330 = None
        new_zeros_default_219 = torch.ops.aten.new_zeros.default(to_dtype_329, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_110 = torch.ops.aten.where.self(le_scalar_109, new_zeros_default_219, to_dtype_329);  le_scalar_109 = new_zeros_default_219 = to_dtype_329 = None
        to_dtype_331 = torch.ops.aten.to.dtype(where_self_110, torch.float32);  where_self_110 = None
        native_batch_norm_backward_default_109 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_331, getitem_3, primals_120, primals_118, primals_119, getitem_6, getitem_7, True, 0.001, [True, True, True]);  to_dtype_331 = getitem_3 = primals_120 = primals_118 = primals_119 = getitem_6 = getitem_7 = None
        getitem_989 = native_batch_norm_backward_default_109[0]
        getitem_990 = native_batch_norm_backward_default_109[1]
        getitem_991 = native_batch_norm_backward_default_109[2];  native_batch_norm_backward_default_109 = None
        add_tensor_250 = torch.ops.aten.add.Tensor(getitem_983, getitem_989);  getitem_983 = getitem_989 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_250, relu__default, [3, 3], [2, 2], [1, 1], [1, 1], False, getitem_4);  add_tensor_250 = getitem_4 = None
        to_dtype_332 = torch.ops.aten.to.dtype(max_pool2d_with_indices_backward_default, torch.float32);  max_pool2d_with_indices_backward_default = None
        to_dtype_333 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_110 = torch.ops.aten.le.Scalar(to_dtype_333, 0);  to_dtype_333 = None
        new_zeros_default_220 = torch.ops.aten.new_zeros.default(to_dtype_332, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_111 = torch.ops.aten.where.self(le_scalar_110, new_zeros_default_220, to_dtype_332);  le_scalar_110 = new_zeros_default_220 = to_dtype_332 = None
        to_dtype_334 = torch.ops.aten.to.dtype(where_self_111, torch.float32);  where_self_111 = None
        native_batch_norm_backward_default_110 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_334, convolution_default, primals_115, primals_113, primals_114, getitem_1, getitem_2, True, 0.001, [True, True, True]);  to_dtype_334 = convolution_default = primals_115 = primals_113 = primals_114 = getitem_1 = getitem_2 = None
        getitem_992 = native_batch_norm_backward_default_110[0]
        getitem_993 = native_batch_norm_backward_default_110[1]
        getitem_994 = native_batch_norm_backward_default_110[2];  native_batch_norm_backward_default_110 = None
        convolution_backward_default_109 = torch.ops.aten.convolution_backward.default(getitem_992, primals_111, primals_1, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_992 = primals_111 = primals_1 = None
        getitem_996 = convolution_backward_default_109[1];  convolution_backward_default_109 = None
        return [getitem_996, getitem_831, getitem_819, getitem_825, getitem_813, getitem_801, getitem_807, getitem_795, getitem_783, getitem_789, getitem_777, getitem_765, getitem_771, getitem_753, getitem_741, getitem_759, getitem_747, getitem_735, getitem_723, getitem_729, getitem_717, getitem_705, getitem_711, getitem_699, getitem_687, getitem_693, getitem_681, getitem_669, getitem_675, getitem_663, getitem_651, getitem_657, getitem_645, getitem_633, getitem_639, getitem_627, getitem_615, getitem_621, getitem_609, getitem_597, getitem_603, getitem_591, getitem_579, getitem_585, getitem_573, getitem_561, getitem_567, getitem_555, getitem_543, getitem_549, getitem_537, getitem_525, getitem_531, getitem_519, getitem_507, getitem_513, getitem_501, getitem_489, getitem_495, getitem_483, getitem_471, getitem_477, getitem_981, getitem_969, getitem_987, getitem_975, getitem_465, getitem_453, getitem_459, getitem_447, getitem_435, getitem_441, getitem_429, getitem_417, getitem_423, getitem_411, getitem_399, getitem_405, getitem_387, getitem_375, getitem_393, getitem_381, getitem_369, getitem_357, getitem_363, getitem_351, getitem_339, getitem_345, getitem_963, getitem_951, getitem_957, getitem_945, getitem_933, getitem_939, getitem_927, getitem_915, getitem_921, getitem_903, getitem_891, getitem_909, getitem_897, getitem_885, getitem_873, getitem_879, getitem_867, getitem_855, getitem_861, getitem_849, getitem_837, getitem_843, None, None, None, None, getitem_993, getitem_994, None, None, None, getitem_990, getitem_991, None, None, None, getitem_984, getitem_985, None, None, None, getitem_978, getitem_979, None, None, None, getitem_972, getitem_973, None, None, None, getitem_966, getitem_967, None, None, None, getitem_960, getitem_961, None, None, None, getitem_954, getitem_955, None, None, None, getitem_948, getitem_949, None, None, None, getitem_942, getitem_943, None, None, None, getitem_936, getitem_937, None, None, None, getitem_930, getitem_931, None, None, None, getitem_924, getitem_925, None, None, None, getitem_918, getitem_919, None, None, None, getitem_912, getitem_913, None, None, None, getitem_906, getitem_907, None, None, None, getitem_900, getitem_901, None, None, None, getitem_894, getitem_895, None, None, None, getitem_888, getitem_889, None, None, None, getitem_882, getitem_883, None, None, None, getitem_876, getitem_877, None, None, None, getitem_870, getitem_871, None, None, None, getitem_864, getitem_865, None, None, None, getitem_858, getitem_859, None, None, None, getitem_852, getitem_853, None, None, None, getitem_846, getitem_847, None, None, None, getitem_840, getitem_841, None, None, None, getitem_834, getitem_835, None, None, None, getitem_828, getitem_829, None, None, None, getitem_822, getitem_823, None, None, None, getitem_816, getitem_817, None, None, None, getitem_810, getitem_811, None, None, None, getitem_804, getitem_805, None, None, None, getitem_798, getitem_799, None, None, None, getitem_792, getitem_793, None, None, None, getitem_786, getitem_787, None, None, None, getitem_780, getitem_781, None, None, None, getitem_774, getitem_775, None, None, None, getitem_768, getitem_769, None, None, None, getitem_762, getitem_763, None, None, None, getitem_756, getitem_757, None, None, None, getitem_750, getitem_751, None, None, None, getitem_744, getitem_745, None, None, None, getitem_738, getitem_739, None, None, None, getitem_732, getitem_733, None, None, None, getitem_726, getitem_727, None, None, None, getitem_720, getitem_721, None, None, None, getitem_714, getitem_715, None, None, None, getitem_708, getitem_709, None, None, None, getitem_702, getitem_703, None, None, None, getitem_696, getitem_697, None, None, None, getitem_690, getitem_691, None, None, None, getitem_684, getitem_685, None, None, None, getitem_678, getitem_679, None, None, None, getitem_672, getitem_673, None, None, None, getitem_666, getitem_667, None, None, None, getitem_660, getitem_661, None, None, None, getitem_654, getitem_655, None, None, None, getitem_648, getitem_649, None, None, None, getitem_642, getitem_643, None, None, None, getitem_636, getitem_637, None, None, None, getitem_630, getitem_631, None, None, None, getitem_624, getitem_625, None, None, None, getitem_618, getitem_619, None, None, None, getitem_612, getitem_613, None, None, None, getitem_606, getitem_607, None, None, None, getitem_600, getitem_601, None, None, None, getitem_594, getitem_595, None, None, None, getitem_588, getitem_589, None, None, None, getitem_582, getitem_583, None, None, None, getitem_576, getitem_577, None, None, None, getitem_570, getitem_571, None, None, None, getitem_564, getitem_565, None, None, None, getitem_558, getitem_559, None, None, None, getitem_552, getitem_553, None, None, None, getitem_546, getitem_547, None, None, None, getitem_540, getitem_541, None, None, None, getitem_534, getitem_535, None, None, None, getitem_528, getitem_529, None, None, None, getitem_522, getitem_523, None, None, None, getitem_516, getitem_517, None, None, None, getitem_510, getitem_511, None, None, None, getitem_504, getitem_505, None, None, None, getitem_498, getitem_499, None, None, None, getitem_492, getitem_493, None, None, None, getitem_486, getitem_487, None, None, None, getitem_480, getitem_481, None, None, None, getitem_474, getitem_475, None, None, None, getitem_468, getitem_469, None, None, None, getitem_462, getitem_463, None, None, None, getitem_456, getitem_457, None, None, None, getitem_450, getitem_451, None, None, None, getitem_444, getitem_445, None, None, None, getitem_438, getitem_439, None, None, None, getitem_432, getitem_433, None, None, None, getitem_426, getitem_427, None, None, None, getitem_420, getitem_421, None, None, None, getitem_414, getitem_415, None, None, None, getitem_408, getitem_409, None, None, None, getitem_402, getitem_403, None, None, None, getitem_396, getitem_397, None, None, None, getitem_390, getitem_391, None, None, None, getitem_384, getitem_385, None, None, None, getitem_378, getitem_379, None, None, None, getitem_372, getitem_373, None, None, None, getitem_366, getitem_367, None, None, None, getitem_360, getitem_361, None, None, None, getitem_354, getitem_355, None, None, None, getitem_348, getitem_349, None, None, None, getitem_342, getitem_343, None, None, None, getitem_336, getitem_337]
        
