
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/dpn107/dpn107_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, primals_394, primals_395, primals_396, primals_397, primals_398, primals_399, primals_400, primals_401, primals_402, primals_403, primals_404, primals_405, primals_406, primals_407, primals_408, primals_409, primals_410, primals_411, primals_412, primals_413, primals_414, primals_415, primals_416, primals_417, primals_418, primals_419, primals_420, primals_421, primals_422, primals_423, primals_424, primals_425, primals_426, primals_427, primals_428, primals_429, primals_430, primals_431, primals_432, primals_433, primals_434, primals_435, primals_436, primals_437, primals_438, primals_439, primals_440, primals_441, primals_442, primals_443, primals_444, primals_445, primals_446, primals_447, primals_448, primals_449, primals_450, primals_451, primals_452, primals_453, primals_454, primals_455, primals_456, primals_457, primals_458, primals_459, primals_460, primals_461, primals_462, primals_463, primals_464, primals_465, primals_466, primals_467, primals_468, primals_469, primals_470, primals_471, primals_472, primals_473, primals_474, primals_475, primals_476, primals_477, primals_478, primals_479, primals_480, primals_481, primals_482, primals_483, primals_484, primals_485, primals_486, primals_487, primals_488, primals_489, primals_490, primals_491, primals_492, primals_493, primals_494, primals_495, primals_496, primals_497, primals_498, primals_499, primals_500, primals_501, primals_502, primals_503, primals_504, primals_505, primals_506, primals_507, primals_508, primals_509, primals_510, primals_511, primals_512, primals_513, primals_514, primals_515, primals_516, primals_517, primals_518, primals_519, primals_520, primals_521, primals_522, primals_523, primals_524, primals_525, primals_526, primals_527, primals_528, primals_529, primals_530, primals_531, primals_532, primals_533, primals_534, primals_535, primals_536, primals_537, primals_538, primals_539, primals_540, primals_541, primals_542, primals_543, primals_544, primals_545, primals_546, primals_547, primals_548, primals_549, primals_550, primals_551, primals_552, primals_553, primals_554, primals_555, primals_556, primals_557, primals_558, primals_559, primals_560, primals_561, primals_562, primals_563, primals_564, primals_565, primals_566, primals_567, primals_568, primals_569, primals_570, primals_571, primals_572, primals_573, primals_574, primals_575, primals_576, primals_577, primals_578, primals_579, primals_580, primals_581, primals_582, primals_583, primals_584, primals_585, primals_586, primals_587, primals_588, primals_589, primals_590, primals_591, primals_592, primals_593, primals_594, primals_595, primals_596, primals_597, primals_598, primals_599, primals_600, primals_601, primals_602, primals_603, primals_604, primals_605, primals_606, primals_607, primals_608, primals_609, primals_610, primals_611, primals_612, primals_613, primals_614, primals_615, primals_616, primals_617, primals_618, primals_619, primals_620, primals_621, primals_622, primals_623, primals_624, primals_625, primals_626, primals_627, primals_628, primals_629, primals_630, primals_631, primals_632, primals_633, primals_634, primals_635, primals_636, primals_637, primals_638, primals_639, primals_640, primals_641, primals_642, primals_643, primals_644, primals_645, primals_646, primals_647, primals_648, primals_649, primals_650, primals_651, primals_652, primals_653, primals_654, primals_655, primals_656, primals_657, primals_658, primals_659, primals_660, primals_661, primals_662, primals_663, primals_664, primals_665, primals_666):
        convolution_default = torch.ops.aten.convolution.default(primals_111, primals_1, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_112, 1);  primals_112 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_115, primals_116, primals_113, primals_114, True, 0.1, 0.001);  primals_116 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(relu__default, [3, 3], [2, 2], [1, 1])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_117, 1);  primals_117 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(getitem_3, primals_120, primals_121, primals_118, primals_119, True, 0.1, 0.001);  primals_121 = None
        getitem_5 = native_batch_norm_default_1[0]
        getitem_6 = native_batch_norm_default_1[1]
        getitem_7 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default_1, primals_65, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor = torch.ops.aten.slice.Tensor(convolution_default_1, 0, 0, 9223372036854775807)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(slice_tensor, 1, 0, 256);  slice_tensor = None
        slice_tensor_2 = torch.ops.aten.slice.Tensor(slice_tensor_1, 2, 0, 9223372036854775807);  slice_tensor_1 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(slice_tensor_2, 3, 0, 9223372036854775807);  slice_tensor_2 = None
        slice_tensor_4 = torch.ops.aten.slice.Tensor(convolution_default_1, 0, 0, 9223372036854775807);  convolution_default_1 = None
        slice_tensor_5 = torch.ops.aten.slice.Tensor(slice_tensor_4, 1, 256, 9223372036854775807);  slice_tensor_4 = None
        slice_tensor_6 = torch.ops.aten.slice.Tensor(slice_tensor_5, 2, 0, 9223372036854775807);  slice_tensor_5 = None
        slice_tensor_7 = torch.ops.aten.slice.Tensor(slice_tensor_6, 3, 0, 9223372036854775807);  slice_tensor_6 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_122, 1);  primals_122 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(getitem_3, primals_125, primals_126, primals_123, primals_124, True, 0.1, 0.001);  primals_126 = None
        getitem_8 = native_batch_norm_default_2[0]
        getitem_9 = native_batch_norm_default_2[1]
        getitem_10 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_8);  getitem_8 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_2, primals_63, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_127, 1);  primals_127 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_130, primals_131, primals_128, primals_129, True, 0.1, 0.001);  primals_131 = None
        getitem_11 = native_batch_norm_default_3[0]
        getitem_12 = native_batch_norm_default_3[1]
        getitem_13 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_11);  getitem_11 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_3, primals_66, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_4 = torch.ops.aten.add.Tensor(primals_132, 1);  primals_132 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_135, primals_136, primals_133, primals_134, True, 0.1, 0.001);  primals_136 = None
        getitem_14 = native_batch_norm_default_4[0]
        getitem_15 = native_batch_norm_default_4[1]
        getitem_16 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_4, primals_64, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(convolution_default_4, 0, 0, 9223372036854775807)
        slice_tensor_9 = torch.ops.aten.slice.Tensor(slice_tensor_8, 1, 0, 256);  slice_tensor_8 = None
        slice_tensor_10 = torch.ops.aten.slice.Tensor(slice_tensor_9, 2, 0, 9223372036854775807);  slice_tensor_9 = None
        slice_tensor_11 = torch.ops.aten.slice.Tensor(slice_tensor_10, 3, 0, 9223372036854775807);  slice_tensor_10 = None
        slice_tensor_12 = torch.ops.aten.slice.Tensor(convolution_default_4, 0, 0, 9223372036854775807);  convolution_default_4 = None
        slice_tensor_13 = torch.ops.aten.slice.Tensor(slice_tensor_12, 1, 256, 9223372036854775807);  slice_tensor_12 = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(slice_tensor_13, 2, 0, 9223372036854775807);  slice_tensor_13 = None
        slice_tensor_15 = torch.ops.aten.slice.Tensor(slice_tensor_14, 3, 0, 9223372036854775807);  slice_tensor_14 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(slice_tensor_3, slice_tensor_11);  slice_tensor_3 = slice_tensor_11 = None
        cat_default = torch.ops.aten.cat.default([slice_tensor_7, slice_tensor_15], 1);  slice_tensor_7 = slice_tensor_15 = None
        cat_default_1 = torch.ops.aten.cat.default([add_tensor_5, cat_default], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_137, 1);  primals_137 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(cat_default_1, primals_140, primals_141, primals_138, primals_139, True, 0.1, 0.001);  primals_141 = None
        getitem_17 = native_batch_norm_default_5[0]
        getitem_18 = native_batch_norm_default_5[1]
        getitem_19 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_17);  getitem_17 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_5, primals_89, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_142, 1);  primals_142 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_145, primals_146, primals_143, primals_144, True, 0.1, 0.001);  primals_146 = None
        getitem_20 = native_batch_norm_default_6[0]
        getitem_21 = native_batch_norm_default_6[1]
        getitem_22 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_6, primals_91, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_147, 1);  primals_147 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_150, primals_151, primals_148, primals_149, True, 0.1, 0.001);  primals_151 = None
        getitem_23 = native_batch_norm_default_7[0]
        getitem_24 = native_batch_norm_default_7[1]
        getitem_25 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_23);  getitem_23 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_7, primals_90, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_16 = torch.ops.aten.slice.Tensor(convolution_default_7, 0, 0, 9223372036854775807)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(slice_tensor_16, 1, 0, 256);  slice_tensor_16 = None
        slice_tensor_18 = torch.ops.aten.slice.Tensor(slice_tensor_17, 2, 0, 9223372036854775807);  slice_tensor_17 = None
        slice_tensor_19 = torch.ops.aten.slice.Tensor(slice_tensor_18, 3, 0, 9223372036854775807);  slice_tensor_18 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(convolution_default_7, 0, 0, 9223372036854775807);  convolution_default_7 = None
        slice_tensor_21 = torch.ops.aten.slice.Tensor(slice_tensor_20, 1, 256, 9223372036854775807);  slice_tensor_20 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(slice_tensor_21, 2, 0, 9223372036854775807);  slice_tensor_21 = None
        slice_tensor_23 = torch.ops.aten.slice.Tensor(slice_tensor_22, 3, 0, 9223372036854775807);  slice_tensor_22 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_5, slice_tensor_19);  add_tensor_5 = slice_tensor_19 = None
        cat_default_2 = torch.ops.aten.cat.default([cat_default, slice_tensor_23], 1);  cat_default = slice_tensor_23 = None
        cat_default_3 = torch.ops.aten.cat.default([add_tensor_9, cat_default_2], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_152, 1);  primals_152 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(cat_default_3, primals_155, primals_156, primals_153, primals_154, True, 0.1, 0.001);  primals_156 = None
        getitem_26 = native_batch_norm_default_8[0]
        getitem_27 = native_batch_norm_default_8[1]
        getitem_28 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_8, primals_92, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(primals_157, 1);  primals_157 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_160, primals_161, primals_158, primals_159, True, 0.1, 0.001);  primals_161 = None
        getitem_29 = native_batch_norm_default_9[0]
        getitem_30 = native_batch_norm_default_9[1]
        getitem_31 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_29);  getitem_29 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_9, primals_94, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_162, 1);  primals_162 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_165, primals_166, primals_163, primals_164, True, 0.1, 0.001);  primals_166 = None
        getitem_32 = native_batch_norm_default_10[0]
        getitem_33 = native_batch_norm_default_10[1]
        getitem_34 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_10, primals_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_24 = torch.ops.aten.slice.Tensor(convolution_default_10, 0, 0, 9223372036854775807)
        slice_tensor_25 = torch.ops.aten.slice.Tensor(slice_tensor_24, 1, 0, 256);  slice_tensor_24 = None
        slice_tensor_26 = torch.ops.aten.slice.Tensor(slice_tensor_25, 2, 0, 9223372036854775807);  slice_tensor_25 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(slice_tensor_26, 3, 0, 9223372036854775807);  slice_tensor_26 = None
        slice_tensor_28 = torch.ops.aten.slice.Tensor(convolution_default_10, 0, 0, 9223372036854775807);  convolution_default_10 = None
        slice_tensor_29 = torch.ops.aten.slice.Tensor(slice_tensor_28, 1, 256, 9223372036854775807);  slice_tensor_28 = None
        slice_tensor_30 = torch.ops.aten.slice.Tensor(slice_tensor_29, 2, 0, 9223372036854775807);  slice_tensor_29 = None
        slice_tensor_31 = torch.ops.aten.slice.Tensor(slice_tensor_30, 3, 0, 9223372036854775807);  slice_tensor_30 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(add_tensor_9, slice_tensor_27);  add_tensor_9 = slice_tensor_27 = None
        cat_default_4 = torch.ops.aten.cat.default([cat_default_2, slice_tensor_31], 1);  cat_default_2 = slice_tensor_31 = None
        cat_default_5 = torch.ops.aten.cat.default([add_tensor_13, cat_default_4], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_167, 1);  primals_167 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(cat_default_5, primals_170, primals_171, primals_168, primals_169, True, 0.1, 0.001);  primals_171 = None
        getitem_35 = native_batch_norm_default_11[0]
        getitem_36 = native_batch_norm_default_11[1]
        getitem_37 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_35);  getitem_35 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_11, primals_95, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(primals_172, 1);  primals_172 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_175, primals_176, primals_173, primals_174, True, 0.1, 0.001);  primals_176 = None
        getitem_38 = native_batch_norm_default_12[0]
        getitem_39 = native_batch_norm_default_12[1]
        getitem_40 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_12, primals_97, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_177, 1);  primals_177 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_180, primals_181, primals_178, primals_179, True, 0.1, 0.001);  primals_181 = None
        getitem_41 = native_batch_norm_default_13[0]
        getitem_42 = native_batch_norm_default_13[1]
        getitem_43 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_41);  getitem_41 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_13, primals_96, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_32 = torch.ops.aten.slice.Tensor(convolution_default_13, 0, 0, 9223372036854775807)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(slice_tensor_32, 1, 0, 256);  slice_tensor_32 = None
        slice_tensor_34 = torch.ops.aten.slice.Tensor(slice_tensor_33, 2, 0, 9223372036854775807);  slice_tensor_33 = None
        slice_tensor_35 = torch.ops.aten.slice.Tensor(slice_tensor_34, 3, 0, 9223372036854775807);  slice_tensor_34 = None
        slice_tensor_36 = torch.ops.aten.slice.Tensor(convolution_default_13, 0, 0, 9223372036854775807);  convolution_default_13 = None
        slice_tensor_37 = torch.ops.aten.slice.Tensor(slice_tensor_36, 1, 256, 9223372036854775807);  slice_tensor_36 = None
        slice_tensor_38 = torch.ops.aten.slice.Tensor(slice_tensor_37, 2, 0, 9223372036854775807);  slice_tensor_37 = None
        slice_tensor_39 = torch.ops.aten.slice.Tensor(slice_tensor_38, 3, 0, 9223372036854775807);  slice_tensor_38 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_13, slice_tensor_35);  add_tensor_13 = slice_tensor_35 = None
        cat_default_6 = torch.ops.aten.cat.default([cat_default_4, slice_tensor_39], 1);  cat_default_4 = slice_tensor_39 = None
        cat_default_7 = torch.ops.aten.cat.default([add_tensor_17, cat_default_6], 1);  add_tensor_17 = cat_default_6 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_182, 1);  primals_182 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(cat_default_7, primals_185, primals_186, primals_183, primals_184, True, 0.1, 0.001);  primals_186 = None
        getitem_44 = native_batch_norm_default_14[0]
        getitem_45 = native_batch_norm_default_14[1]
        getitem_46 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_14, primals_100, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_40 = torch.ops.aten.slice.Tensor(convolution_default_14, 0, 0, 9223372036854775807)
        slice_tensor_41 = torch.ops.aten.slice.Tensor(slice_tensor_40, 1, 0, 512);  slice_tensor_40 = None
        slice_tensor_42 = torch.ops.aten.slice.Tensor(slice_tensor_41, 2, 0, 9223372036854775807);  slice_tensor_41 = None
        slice_tensor_43 = torch.ops.aten.slice.Tensor(slice_tensor_42, 3, 0, 9223372036854775807);  slice_tensor_42 = None
        slice_tensor_44 = torch.ops.aten.slice.Tensor(convolution_default_14, 0, 0, 9223372036854775807);  convolution_default_14 = None
        slice_tensor_45 = torch.ops.aten.slice.Tensor(slice_tensor_44, 1, 512, 9223372036854775807);  slice_tensor_44 = None
        slice_tensor_46 = torch.ops.aten.slice.Tensor(slice_tensor_45, 2, 0, 9223372036854775807);  slice_tensor_45 = None
        slice_tensor_47 = torch.ops.aten.slice.Tensor(slice_tensor_46, 3, 0, 9223372036854775807);  slice_tensor_46 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_187, 1);  primals_187 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(cat_default_7, primals_190, primals_191, primals_188, primals_189, True, 0.1, 0.001);  primals_191 = None
        getitem_47 = native_batch_norm_default_15[0]
        getitem_48 = native_batch_norm_default_15[1]
        getitem_49 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_47);  getitem_47 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_15, primals_98, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_192, 1);  primals_192 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_195, primals_196, primals_193, primals_194, True, 0.1, 0.001);  primals_196 = None
        getitem_50 = native_batch_norm_default_16[0]
        getitem_51 = native_batch_norm_default_16[1]
        getitem_52 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_16, primals_101, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_197, 1);  primals_197 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_200, primals_201, primals_198, primals_199, True, 0.1, 0.001);  primals_201 = None
        getitem_53 = native_batch_norm_default_17[0]
        getitem_54 = native_batch_norm_default_17[1]
        getitem_55 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_53);  getitem_53 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_17, primals_99, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_48 = torch.ops.aten.slice.Tensor(convolution_default_17, 0, 0, 9223372036854775807)
        slice_tensor_49 = torch.ops.aten.slice.Tensor(slice_tensor_48, 1, 0, 512);  slice_tensor_48 = None
        slice_tensor_50 = torch.ops.aten.slice.Tensor(slice_tensor_49, 2, 0, 9223372036854775807);  slice_tensor_49 = None
        slice_tensor_51 = torch.ops.aten.slice.Tensor(slice_tensor_50, 3, 0, 9223372036854775807);  slice_tensor_50 = None
        slice_tensor_52 = torch.ops.aten.slice.Tensor(convolution_default_17, 0, 0, 9223372036854775807);  convolution_default_17 = None
        slice_tensor_53 = torch.ops.aten.slice.Tensor(slice_tensor_52, 1, 512, 9223372036854775807);  slice_tensor_52 = None
        slice_tensor_54 = torch.ops.aten.slice.Tensor(slice_tensor_53, 2, 0, 9223372036854775807);  slice_tensor_53 = None
        slice_tensor_55 = torch.ops.aten.slice.Tensor(slice_tensor_54, 3, 0, 9223372036854775807);  slice_tensor_54 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(slice_tensor_43, slice_tensor_51);  slice_tensor_43 = slice_tensor_51 = None
        cat_default_8 = torch.ops.aten.cat.default([slice_tensor_47, slice_tensor_55], 1);  slice_tensor_47 = slice_tensor_55 = None
        cat_default_9 = torch.ops.aten.cat.default([add_tensor_22, cat_default_8], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_202, 1);  primals_202 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(cat_default_9, primals_205, primals_206, primals_203, primals_204, True, 0.1, 0.001);  primals_206 = None
        getitem_56 = native_batch_norm_default_18[0]
        getitem_57 = native_batch_norm_default_18[1]
        getitem_58 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_18, primals_102, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_207, 1);  primals_207 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_210, primals_211, primals_208, primals_209, True, 0.1, 0.001);  primals_211 = None
        getitem_59 = native_batch_norm_default_19[0]
        getitem_60 = native_batch_norm_default_19[1]
        getitem_61 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_59);  getitem_59 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_19, primals_104, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_212, 1);  primals_212 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_215, primals_216, primals_213, primals_214, True, 0.1, 0.001);  primals_216 = None
        getitem_62 = native_batch_norm_default_20[0]
        getitem_63 = native_batch_norm_default_20[1]
        getitem_64 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_62);  getitem_62 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_20, primals_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_56 = torch.ops.aten.slice.Tensor(convolution_default_20, 0, 0, 9223372036854775807)
        slice_tensor_57 = torch.ops.aten.slice.Tensor(slice_tensor_56, 1, 0, 512);  slice_tensor_56 = None
        slice_tensor_58 = torch.ops.aten.slice.Tensor(slice_tensor_57, 2, 0, 9223372036854775807);  slice_tensor_57 = None
        slice_tensor_59 = torch.ops.aten.slice.Tensor(slice_tensor_58, 3, 0, 9223372036854775807);  slice_tensor_58 = None
        slice_tensor_60 = torch.ops.aten.slice.Tensor(convolution_default_20, 0, 0, 9223372036854775807);  convolution_default_20 = None
        slice_tensor_61 = torch.ops.aten.slice.Tensor(slice_tensor_60, 1, 512, 9223372036854775807);  slice_tensor_60 = None
        slice_tensor_62 = torch.ops.aten.slice.Tensor(slice_tensor_61, 2, 0, 9223372036854775807);  slice_tensor_61 = None
        slice_tensor_63 = torch.ops.aten.slice.Tensor(slice_tensor_62, 3, 0, 9223372036854775807);  slice_tensor_62 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(add_tensor_22, slice_tensor_59);  add_tensor_22 = slice_tensor_59 = None
        cat_default_10 = torch.ops.aten.cat.default([cat_default_8, slice_tensor_63], 1);  cat_default_8 = slice_tensor_63 = None
        cat_default_11 = torch.ops.aten.cat.default([add_tensor_26, cat_default_10], 1)
        add_tensor_27 = torch.ops.aten.add.Tensor(primals_217, 1);  primals_217 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(cat_default_11, primals_220, primals_221, primals_218, primals_219, True, 0.1, 0.001);  primals_221 = None
        getitem_65 = native_batch_norm_default_21[0]
        getitem_66 = native_batch_norm_default_21[1]
        getitem_67 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_65);  getitem_65 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_21, primals_105, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_222, 1);  primals_222 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_225, primals_226, primals_223, primals_224, True, 0.1, 0.001);  primals_226 = None
        getitem_68 = native_batch_norm_default_22[0]
        getitem_69 = native_batch_norm_default_22[1]
        getitem_70 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_68);  getitem_68 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_22, primals_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_227, 1);  primals_227 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_230, primals_231, primals_228, primals_229, True, 0.1, 0.001);  primals_231 = None
        getitem_71 = native_batch_norm_default_23[0]
        getitem_72 = native_batch_norm_default_23[1]
        getitem_73 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_71);  getitem_71 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_23, primals_106, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_64 = torch.ops.aten.slice.Tensor(convolution_default_23, 0, 0, 9223372036854775807)
        slice_tensor_65 = torch.ops.aten.slice.Tensor(slice_tensor_64, 1, 0, 512);  slice_tensor_64 = None
        slice_tensor_66 = torch.ops.aten.slice.Tensor(slice_tensor_65, 2, 0, 9223372036854775807);  slice_tensor_65 = None
        slice_tensor_67 = torch.ops.aten.slice.Tensor(slice_tensor_66, 3, 0, 9223372036854775807);  slice_tensor_66 = None
        slice_tensor_68 = torch.ops.aten.slice.Tensor(convolution_default_23, 0, 0, 9223372036854775807);  convolution_default_23 = None
        slice_tensor_69 = torch.ops.aten.slice.Tensor(slice_tensor_68, 1, 512, 9223372036854775807);  slice_tensor_68 = None
        slice_tensor_70 = torch.ops.aten.slice.Tensor(slice_tensor_69, 2, 0, 9223372036854775807);  slice_tensor_69 = None
        slice_tensor_71 = torch.ops.aten.slice.Tensor(slice_tensor_70, 3, 0, 9223372036854775807);  slice_tensor_70 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(add_tensor_26, slice_tensor_67);  add_tensor_26 = slice_tensor_67 = None
        cat_default_12 = torch.ops.aten.cat.default([cat_default_10, slice_tensor_71], 1);  cat_default_10 = slice_tensor_71 = None
        cat_default_13 = torch.ops.aten.cat.default([add_tensor_30, cat_default_12], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_232, 1);  primals_232 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(cat_default_13, primals_235, primals_236, primals_233, primals_234, True, 0.1, 0.001);  primals_236 = None
        getitem_74 = native_batch_norm_default_24[0]
        getitem_75 = native_batch_norm_default_24[1]
        getitem_76 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_74);  getitem_74 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_24, primals_108, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_237, 1);  primals_237 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_240, primals_241, primals_238, primals_239, True, 0.1, 0.001);  primals_241 = None
        getitem_77 = native_batch_norm_default_25[0]
        getitem_78 = native_batch_norm_default_25[1]
        getitem_79 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_25, primals_110, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_242, 1);  primals_242 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_245, primals_246, primals_243, primals_244, True, 0.1, 0.001);  primals_246 = None
        getitem_80 = native_batch_norm_default_26[0]
        getitem_81 = native_batch_norm_default_26[1]
        getitem_82 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_80);  getitem_80 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_26, primals_109, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_72 = torch.ops.aten.slice.Tensor(convolution_default_26, 0, 0, 9223372036854775807)
        slice_tensor_73 = torch.ops.aten.slice.Tensor(slice_tensor_72, 1, 0, 512);  slice_tensor_72 = None
        slice_tensor_74 = torch.ops.aten.slice.Tensor(slice_tensor_73, 2, 0, 9223372036854775807);  slice_tensor_73 = None
        slice_tensor_75 = torch.ops.aten.slice.Tensor(slice_tensor_74, 3, 0, 9223372036854775807);  slice_tensor_74 = None
        slice_tensor_76 = torch.ops.aten.slice.Tensor(convolution_default_26, 0, 0, 9223372036854775807);  convolution_default_26 = None
        slice_tensor_77 = torch.ops.aten.slice.Tensor(slice_tensor_76, 1, 512, 9223372036854775807);  slice_tensor_76 = None
        slice_tensor_78 = torch.ops.aten.slice.Tensor(slice_tensor_77, 2, 0, 9223372036854775807);  slice_tensor_77 = None
        slice_tensor_79 = torch.ops.aten.slice.Tensor(slice_tensor_78, 3, 0, 9223372036854775807);  slice_tensor_78 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_30, slice_tensor_75);  add_tensor_30 = slice_tensor_75 = None
        cat_default_14 = torch.ops.aten.cat.default([cat_default_12, slice_tensor_79], 1);  cat_default_12 = slice_tensor_79 = None
        cat_default_15 = torch.ops.aten.cat.default([add_tensor_34, cat_default_14], 1)
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_247, 1);  primals_247 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(cat_default_15, primals_250, primals_251, primals_248, primals_249, True, 0.1, 0.001);  primals_251 = None
        getitem_83 = native_batch_norm_default_27[0]
        getitem_84 = native_batch_norm_default_27[1]
        getitem_85 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_27, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_252, 1);  primals_252 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_255, primals_256, primals_253, primals_254, True, 0.1, 0.001);  primals_256 = None
        getitem_86 = native_batch_norm_default_28[0]
        getitem_87 = native_batch_norm_default_28[1]
        getitem_88 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_86);  getitem_86 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_28, primals_4, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_37 = torch.ops.aten.add.Tensor(primals_257, 1);  primals_257 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_260, primals_261, primals_258, primals_259, True, 0.1, 0.001);  primals_261 = None
        getitem_89 = native_batch_norm_default_29[0]
        getitem_90 = native_batch_norm_default_29[1]
        getitem_91 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_29, primals_3, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_80 = torch.ops.aten.slice.Tensor(convolution_default_29, 0, 0, 9223372036854775807)
        slice_tensor_81 = torch.ops.aten.slice.Tensor(slice_tensor_80, 1, 0, 512);  slice_tensor_80 = None
        slice_tensor_82 = torch.ops.aten.slice.Tensor(slice_tensor_81, 2, 0, 9223372036854775807);  slice_tensor_81 = None
        slice_tensor_83 = torch.ops.aten.slice.Tensor(slice_tensor_82, 3, 0, 9223372036854775807);  slice_tensor_82 = None
        slice_tensor_84 = torch.ops.aten.slice.Tensor(convolution_default_29, 0, 0, 9223372036854775807);  convolution_default_29 = None
        slice_tensor_85 = torch.ops.aten.slice.Tensor(slice_tensor_84, 1, 512, 9223372036854775807);  slice_tensor_84 = None
        slice_tensor_86 = torch.ops.aten.slice.Tensor(slice_tensor_85, 2, 0, 9223372036854775807);  slice_tensor_85 = None
        slice_tensor_87 = torch.ops.aten.slice.Tensor(slice_tensor_86, 3, 0, 9223372036854775807);  slice_tensor_86 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(add_tensor_34, slice_tensor_83);  add_tensor_34 = slice_tensor_83 = None
        cat_default_16 = torch.ops.aten.cat.default([cat_default_14, slice_tensor_87], 1);  cat_default_14 = slice_tensor_87 = None
        cat_default_17 = torch.ops.aten.cat.default([add_tensor_38, cat_default_16], 1)
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_262, 1);  primals_262 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(cat_default_17, primals_265, primals_266, primals_263, primals_264, True, 0.1, 0.001);  primals_266 = None
        getitem_92 = native_batch_norm_default_30[0]
        getitem_93 = native_batch_norm_default_30[1]
        getitem_94 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_92);  getitem_92 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_30, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_267, 1);  primals_267 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_270, primals_271, primals_268, primals_269, True, 0.1, 0.001);  primals_271 = None
        getitem_95 = native_batch_norm_default_31[0]
        getitem_96 = native_batch_norm_default_31[1]
        getitem_97 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_31, primals_7, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_41 = torch.ops.aten.add.Tensor(primals_272, 1);  primals_272 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_275, primals_276, primals_273, primals_274, True, 0.1, 0.001);  primals_276 = None
        getitem_98 = native_batch_norm_default_32[0]
        getitem_99 = native_batch_norm_default_32[1]
        getitem_100 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_98);  getitem_98 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_32, primals_6, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_88 = torch.ops.aten.slice.Tensor(convolution_default_32, 0, 0, 9223372036854775807)
        slice_tensor_89 = torch.ops.aten.slice.Tensor(slice_tensor_88, 1, 0, 512);  slice_tensor_88 = None
        slice_tensor_90 = torch.ops.aten.slice.Tensor(slice_tensor_89, 2, 0, 9223372036854775807);  slice_tensor_89 = None
        slice_tensor_91 = torch.ops.aten.slice.Tensor(slice_tensor_90, 3, 0, 9223372036854775807);  slice_tensor_90 = None
        slice_tensor_92 = torch.ops.aten.slice.Tensor(convolution_default_32, 0, 0, 9223372036854775807);  convolution_default_32 = None
        slice_tensor_93 = torch.ops.aten.slice.Tensor(slice_tensor_92, 1, 512, 9223372036854775807);  slice_tensor_92 = None
        slice_tensor_94 = torch.ops.aten.slice.Tensor(slice_tensor_93, 2, 0, 9223372036854775807);  slice_tensor_93 = None
        slice_tensor_95 = torch.ops.aten.slice.Tensor(slice_tensor_94, 3, 0, 9223372036854775807);  slice_tensor_94 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_38, slice_tensor_91);  add_tensor_38 = slice_tensor_91 = None
        cat_default_18 = torch.ops.aten.cat.default([cat_default_16, slice_tensor_95], 1);  cat_default_16 = slice_tensor_95 = None
        cat_default_19 = torch.ops.aten.cat.default([add_tensor_42, cat_default_18], 1)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_277, 1);  primals_277 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(cat_default_19, primals_280, primals_281, primals_278, primals_279, True, 0.1, 0.001);  primals_281 = None
        getitem_101 = native_batch_norm_default_33[0]
        getitem_102 = native_batch_norm_default_33[1]
        getitem_103 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_101);  getitem_101 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_33, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_282, 1);  primals_282 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_285, primals_286, primals_283, primals_284, True, 0.1, 0.001);  primals_286 = None
        getitem_104 = native_batch_norm_default_34[0]
        getitem_105 = native_batch_norm_default_34[1]
        getitem_106 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_104);  getitem_104 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_34, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_45 = torch.ops.aten.add.Tensor(primals_287, 1);  primals_287 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_290, primals_291, primals_288, primals_289, True, 0.1, 0.001);  primals_291 = None
        getitem_107 = native_batch_norm_default_35[0]
        getitem_108 = native_batch_norm_default_35[1]
        getitem_109 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_35, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_96 = torch.ops.aten.slice.Tensor(convolution_default_35, 0, 0, 9223372036854775807)
        slice_tensor_97 = torch.ops.aten.slice.Tensor(slice_tensor_96, 1, 0, 512);  slice_tensor_96 = None
        slice_tensor_98 = torch.ops.aten.slice.Tensor(slice_tensor_97, 2, 0, 9223372036854775807);  slice_tensor_97 = None
        slice_tensor_99 = torch.ops.aten.slice.Tensor(slice_tensor_98, 3, 0, 9223372036854775807);  slice_tensor_98 = None
        slice_tensor_100 = torch.ops.aten.slice.Tensor(convolution_default_35, 0, 0, 9223372036854775807);  convolution_default_35 = None
        slice_tensor_101 = torch.ops.aten.slice.Tensor(slice_tensor_100, 1, 512, 9223372036854775807);  slice_tensor_100 = None
        slice_tensor_102 = torch.ops.aten.slice.Tensor(slice_tensor_101, 2, 0, 9223372036854775807);  slice_tensor_101 = None
        slice_tensor_103 = torch.ops.aten.slice.Tensor(slice_tensor_102, 3, 0, 9223372036854775807);  slice_tensor_102 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_42, slice_tensor_99);  add_tensor_42 = slice_tensor_99 = None
        cat_default_20 = torch.ops.aten.cat.default([cat_default_18, slice_tensor_103], 1);  cat_default_18 = slice_tensor_103 = None
        cat_default_21 = torch.ops.aten.cat.default([add_tensor_46, cat_default_20], 1)
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_292, 1);  primals_292 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(cat_default_21, primals_295, primals_296, primals_293, primals_294, True, 0.1, 0.001);  primals_296 = None
        getitem_110 = native_batch_norm_default_36[0]
        getitem_111 = native_batch_norm_default_36[1]
        getitem_112 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_110);  getitem_110 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_36, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_297, 1);  primals_297 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_300, primals_301, primals_298, primals_299, True, 0.1, 0.001);  primals_301 = None
        getitem_113 = native_batch_norm_default_37[0]
        getitem_114 = native_batch_norm_default_37[1]
        getitem_115 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_37, primals_13, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_49 = torch.ops.aten.add.Tensor(primals_302, 1);  primals_302 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_305, primals_306, primals_303, primals_304, True, 0.1, 0.001);  primals_306 = None
        getitem_116 = native_batch_norm_default_38[0]
        getitem_117 = native_batch_norm_default_38[1]
        getitem_118 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_116);  getitem_116 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_38, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_104 = torch.ops.aten.slice.Tensor(convolution_default_38, 0, 0, 9223372036854775807)
        slice_tensor_105 = torch.ops.aten.slice.Tensor(slice_tensor_104, 1, 0, 512);  slice_tensor_104 = None
        slice_tensor_106 = torch.ops.aten.slice.Tensor(slice_tensor_105, 2, 0, 9223372036854775807);  slice_tensor_105 = None
        slice_tensor_107 = torch.ops.aten.slice.Tensor(slice_tensor_106, 3, 0, 9223372036854775807);  slice_tensor_106 = None
        slice_tensor_108 = torch.ops.aten.slice.Tensor(convolution_default_38, 0, 0, 9223372036854775807);  convolution_default_38 = None
        slice_tensor_109 = torch.ops.aten.slice.Tensor(slice_tensor_108, 1, 512, 9223372036854775807);  slice_tensor_108 = None
        slice_tensor_110 = torch.ops.aten.slice.Tensor(slice_tensor_109, 2, 0, 9223372036854775807);  slice_tensor_109 = None
        slice_tensor_111 = torch.ops.aten.slice.Tensor(slice_tensor_110, 3, 0, 9223372036854775807);  slice_tensor_110 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(add_tensor_46, slice_tensor_107);  add_tensor_46 = slice_tensor_107 = None
        cat_default_22 = torch.ops.aten.cat.default([cat_default_20, slice_tensor_111], 1);  cat_default_20 = slice_tensor_111 = None
        cat_default_23 = torch.ops.aten.cat.default([add_tensor_50, cat_default_22], 1);  add_tensor_50 = cat_default_22 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_307, 1);  primals_307 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(cat_default_23, primals_310, primals_311, primals_308, primals_309, True, 0.1, 0.001);  primals_311 = None
        getitem_119 = native_batch_norm_default_39[0]
        getitem_120 = native_batch_norm_default_39[1]
        getitem_121 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_39, primals_16, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_112 = torch.ops.aten.slice.Tensor(convolution_default_39, 0, 0, 9223372036854775807)
        slice_tensor_113 = torch.ops.aten.slice.Tensor(slice_tensor_112, 1, 0, 1024);  slice_tensor_112 = None
        slice_tensor_114 = torch.ops.aten.slice.Tensor(slice_tensor_113, 2, 0, 9223372036854775807);  slice_tensor_113 = None
        slice_tensor_115 = torch.ops.aten.slice.Tensor(slice_tensor_114, 3, 0, 9223372036854775807);  slice_tensor_114 = None
        slice_tensor_116 = torch.ops.aten.slice.Tensor(convolution_default_39, 0, 0, 9223372036854775807);  convolution_default_39 = None
        slice_tensor_117 = torch.ops.aten.slice.Tensor(slice_tensor_116, 1, 1024, 9223372036854775807);  slice_tensor_116 = None
        slice_tensor_118 = torch.ops.aten.slice.Tensor(slice_tensor_117, 2, 0, 9223372036854775807);  slice_tensor_117 = None
        slice_tensor_119 = torch.ops.aten.slice.Tensor(slice_tensor_118, 3, 0, 9223372036854775807);  slice_tensor_118 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(primals_312, 1);  primals_312 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(cat_default_23, primals_315, primals_316, primals_313, primals_314, True, 0.1, 0.001);  primals_316 = None
        getitem_122 = native_batch_norm_default_40[0]
        getitem_123 = native_batch_norm_default_40[1]
        getitem_124 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_122);  getitem_122 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_40, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_53 = torch.ops.aten.add.Tensor(primals_317, 1);  primals_317 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_320, primals_321, primals_318, primals_319, True, 0.1, 0.001);  primals_321 = None
        getitem_125 = native_batch_norm_default_41[0]
        getitem_126 = native_batch_norm_default_41[1]
        getitem_127 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_41, primals_17, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_322, 1);  primals_322 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_325, primals_326, primals_323, primals_324, True, 0.1, 0.001);  primals_326 = None
        getitem_128 = native_batch_norm_default_42[0]
        getitem_129 = native_batch_norm_default_42[1]
        getitem_130 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_128);  getitem_128 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_42, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_120 = torch.ops.aten.slice.Tensor(convolution_default_42, 0, 0, 9223372036854775807)
        slice_tensor_121 = torch.ops.aten.slice.Tensor(slice_tensor_120, 1, 0, 1024);  slice_tensor_120 = None
        slice_tensor_122 = torch.ops.aten.slice.Tensor(slice_tensor_121, 2, 0, 9223372036854775807);  slice_tensor_121 = None
        slice_tensor_123 = torch.ops.aten.slice.Tensor(slice_tensor_122, 3, 0, 9223372036854775807);  slice_tensor_122 = None
        slice_tensor_124 = torch.ops.aten.slice.Tensor(convolution_default_42, 0, 0, 9223372036854775807);  convolution_default_42 = None
        slice_tensor_125 = torch.ops.aten.slice.Tensor(slice_tensor_124, 1, 1024, 9223372036854775807);  slice_tensor_124 = None
        slice_tensor_126 = torch.ops.aten.slice.Tensor(slice_tensor_125, 2, 0, 9223372036854775807);  slice_tensor_125 = None
        slice_tensor_127 = torch.ops.aten.slice.Tensor(slice_tensor_126, 3, 0, 9223372036854775807);  slice_tensor_126 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(slice_tensor_115, slice_tensor_123);  slice_tensor_115 = slice_tensor_123 = None
        cat_default_24 = torch.ops.aten.cat.default([slice_tensor_119, slice_tensor_127], 1);  slice_tensor_119 = slice_tensor_127 = None
        cat_default_25 = torch.ops.aten.cat.default([add_tensor_55, cat_default_24], 1)
        add_tensor_56 = torch.ops.aten.add.Tensor(primals_327, 1);  primals_327 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(cat_default_25, primals_330, primals_331, primals_328, primals_329, True, 0.1, 0.001);  primals_331 = None
        getitem_131 = native_batch_norm_default_43[0]
        getitem_132 = native_batch_norm_default_43[1]
        getitem_133 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_43, primals_18, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_332, 1);  primals_332 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_335, primals_336, primals_333, primals_334, True, 0.1, 0.001);  primals_336 = None
        getitem_134 = native_batch_norm_default_44[0]
        getitem_135 = native_batch_norm_default_44[1]
        getitem_136 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_134);  getitem_134 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_44, primals_20, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_58 = torch.ops.aten.add.Tensor(primals_337, 1);  primals_337 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_340, primals_341, primals_338, primals_339, True, 0.1, 0.001);  primals_341 = None
        getitem_137 = native_batch_norm_default_45[0]
        getitem_138 = native_batch_norm_default_45[1]
        getitem_139 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_137);  getitem_137 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_45, primals_19, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_128 = torch.ops.aten.slice.Tensor(convolution_default_45, 0, 0, 9223372036854775807)
        slice_tensor_129 = torch.ops.aten.slice.Tensor(slice_tensor_128, 1, 0, 1024);  slice_tensor_128 = None
        slice_tensor_130 = torch.ops.aten.slice.Tensor(slice_tensor_129, 2, 0, 9223372036854775807);  slice_tensor_129 = None
        slice_tensor_131 = torch.ops.aten.slice.Tensor(slice_tensor_130, 3, 0, 9223372036854775807);  slice_tensor_130 = None
        slice_tensor_132 = torch.ops.aten.slice.Tensor(convolution_default_45, 0, 0, 9223372036854775807);  convolution_default_45 = None
        slice_tensor_133 = torch.ops.aten.slice.Tensor(slice_tensor_132, 1, 1024, 9223372036854775807);  slice_tensor_132 = None
        slice_tensor_134 = torch.ops.aten.slice.Tensor(slice_tensor_133, 2, 0, 9223372036854775807);  slice_tensor_133 = None
        slice_tensor_135 = torch.ops.aten.slice.Tensor(slice_tensor_134, 3, 0, 9223372036854775807);  slice_tensor_134 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(add_tensor_55, slice_tensor_131);  add_tensor_55 = slice_tensor_131 = None
        cat_default_26 = torch.ops.aten.cat.default([cat_default_24, slice_tensor_135], 1);  cat_default_24 = slice_tensor_135 = None
        cat_default_27 = torch.ops.aten.cat.default([add_tensor_59, cat_default_26], 1)
        add_tensor_60 = torch.ops.aten.add.Tensor(primals_342, 1);  primals_342 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(cat_default_27, primals_345, primals_346, primals_343, primals_344, True, 0.1, 0.001);  primals_346 = None
        getitem_140 = native_batch_norm_default_46[0]
        getitem_141 = native_batch_norm_default_46[1]
        getitem_142 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_140);  getitem_140 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_46, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_347, 1);  primals_347 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_350, primals_351, primals_348, primals_349, True, 0.1, 0.001);  primals_351 = None
        getitem_143 = native_batch_norm_default_47[0]
        getitem_144 = native_batch_norm_default_47[1]
        getitem_145 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_143);  getitem_143 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_47, primals_23, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_62 = torch.ops.aten.add.Tensor(primals_352, 1);  primals_352 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_355, primals_356, primals_353, primals_354, True, 0.1, 0.001);  primals_356 = None
        getitem_146 = native_batch_norm_default_48[0]
        getitem_147 = native_batch_norm_default_48[1]
        getitem_148 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_48, primals_22, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_136 = torch.ops.aten.slice.Tensor(convolution_default_48, 0, 0, 9223372036854775807)
        slice_tensor_137 = torch.ops.aten.slice.Tensor(slice_tensor_136, 1, 0, 1024);  slice_tensor_136 = None
        slice_tensor_138 = torch.ops.aten.slice.Tensor(slice_tensor_137, 2, 0, 9223372036854775807);  slice_tensor_137 = None
        slice_tensor_139 = torch.ops.aten.slice.Tensor(slice_tensor_138, 3, 0, 9223372036854775807);  slice_tensor_138 = None
        slice_tensor_140 = torch.ops.aten.slice.Tensor(convolution_default_48, 0, 0, 9223372036854775807);  convolution_default_48 = None
        slice_tensor_141 = torch.ops.aten.slice.Tensor(slice_tensor_140, 1, 1024, 9223372036854775807);  slice_tensor_140 = None
        slice_tensor_142 = torch.ops.aten.slice.Tensor(slice_tensor_141, 2, 0, 9223372036854775807);  slice_tensor_141 = None
        slice_tensor_143 = torch.ops.aten.slice.Tensor(slice_tensor_142, 3, 0, 9223372036854775807);  slice_tensor_142 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(add_tensor_59, slice_tensor_139);  add_tensor_59 = slice_tensor_139 = None
        cat_default_28 = torch.ops.aten.cat.default([cat_default_26, slice_tensor_143], 1);  cat_default_26 = slice_tensor_143 = None
        cat_default_29 = torch.ops.aten.cat.default([add_tensor_63, cat_default_28], 1)
        add_tensor_64 = torch.ops.aten.add.Tensor(primals_357, 1);  primals_357 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(cat_default_29, primals_360, primals_361, primals_358, primals_359, True, 0.1, 0.001);  primals_361 = None
        getitem_149 = native_batch_norm_default_49[0]
        getitem_150 = native_batch_norm_default_49[1]
        getitem_151 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_149);  getitem_149 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_49, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_65 = torch.ops.aten.add.Tensor(primals_362, 1);  primals_362 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_365, primals_366, primals_363, primals_364, True, 0.1, 0.001);  primals_366 = None
        getitem_152 = native_batch_norm_default_50[0]
        getitem_153 = native_batch_norm_default_50[1]
        getitem_154 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_50, primals_26, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_66 = torch.ops.aten.add.Tensor(primals_367, 1);  primals_367 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_370, primals_371, primals_368, primals_369, True, 0.1, 0.001);  primals_371 = None
        getitem_155 = native_batch_norm_default_51[0]
        getitem_156 = native_batch_norm_default_51[1]
        getitem_157 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_155);  getitem_155 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_51, primals_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_144 = torch.ops.aten.slice.Tensor(convolution_default_51, 0, 0, 9223372036854775807)
        slice_tensor_145 = torch.ops.aten.slice.Tensor(slice_tensor_144, 1, 0, 1024);  slice_tensor_144 = None
        slice_tensor_146 = torch.ops.aten.slice.Tensor(slice_tensor_145, 2, 0, 9223372036854775807);  slice_tensor_145 = None
        slice_tensor_147 = torch.ops.aten.slice.Tensor(slice_tensor_146, 3, 0, 9223372036854775807);  slice_tensor_146 = None
        slice_tensor_148 = torch.ops.aten.slice.Tensor(convolution_default_51, 0, 0, 9223372036854775807);  convolution_default_51 = None
        slice_tensor_149 = torch.ops.aten.slice.Tensor(slice_tensor_148, 1, 1024, 9223372036854775807);  slice_tensor_148 = None
        slice_tensor_150 = torch.ops.aten.slice.Tensor(slice_tensor_149, 2, 0, 9223372036854775807);  slice_tensor_149 = None
        slice_tensor_151 = torch.ops.aten.slice.Tensor(slice_tensor_150, 3, 0, 9223372036854775807);  slice_tensor_150 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(add_tensor_63, slice_tensor_147);  add_tensor_63 = slice_tensor_147 = None
        cat_default_30 = torch.ops.aten.cat.default([cat_default_28, slice_tensor_151], 1);  cat_default_28 = slice_tensor_151 = None
        cat_default_31 = torch.ops.aten.cat.default([add_tensor_67, cat_default_30], 1)
        add_tensor_68 = torch.ops.aten.add.Tensor(primals_372, 1);  primals_372 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(cat_default_31, primals_375, primals_376, primals_373, primals_374, True, 0.1, 0.001);  primals_376 = None
        getitem_158 = native_batch_norm_default_52[0]
        getitem_159 = native_batch_norm_default_52[1]
        getitem_160 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_52, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_69 = torch.ops.aten.add.Tensor(primals_377, 1);  primals_377 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_380, primals_381, primals_378, primals_379, True, 0.1, 0.001);  primals_381 = None
        getitem_161 = native_batch_norm_default_53[0]
        getitem_162 = native_batch_norm_default_53[1]
        getitem_163 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_161);  getitem_161 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_53, primals_29, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_70 = torch.ops.aten.add.Tensor(primals_382, 1);  primals_382 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_385, primals_386, primals_383, primals_384, True, 0.1, 0.001);  primals_386 = None
        getitem_164 = native_batch_norm_default_54[0]
        getitem_165 = native_batch_norm_default_54[1]
        getitem_166 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_54, primals_28, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_152 = torch.ops.aten.slice.Tensor(convolution_default_54, 0, 0, 9223372036854775807)
        slice_tensor_153 = torch.ops.aten.slice.Tensor(slice_tensor_152, 1, 0, 1024);  slice_tensor_152 = None
        slice_tensor_154 = torch.ops.aten.slice.Tensor(slice_tensor_153, 2, 0, 9223372036854775807);  slice_tensor_153 = None
        slice_tensor_155 = torch.ops.aten.slice.Tensor(slice_tensor_154, 3, 0, 9223372036854775807);  slice_tensor_154 = None
        slice_tensor_156 = torch.ops.aten.slice.Tensor(convolution_default_54, 0, 0, 9223372036854775807);  convolution_default_54 = None
        slice_tensor_157 = torch.ops.aten.slice.Tensor(slice_tensor_156, 1, 1024, 9223372036854775807);  slice_tensor_156 = None
        slice_tensor_158 = torch.ops.aten.slice.Tensor(slice_tensor_157, 2, 0, 9223372036854775807);  slice_tensor_157 = None
        slice_tensor_159 = torch.ops.aten.slice.Tensor(slice_tensor_158, 3, 0, 9223372036854775807);  slice_tensor_158 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(add_tensor_67, slice_tensor_155);  add_tensor_67 = slice_tensor_155 = None
        cat_default_32 = torch.ops.aten.cat.default([cat_default_30, slice_tensor_159], 1);  cat_default_30 = slice_tensor_159 = None
        cat_default_33 = torch.ops.aten.cat.default([add_tensor_71, cat_default_32], 1)
        add_tensor_72 = torch.ops.aten.add.Tensor(primals_387, 1);  primals_387 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(cat_default_33, primals_390, primals_391, primals_388, primals_389, True, 0.1, 0.001);  primals_391 = None
        getitem_167 = native_batch_norm_default_55[0]
        getitem_168 = native_batch_norm_default_55[1]
        getitem_169 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_167);  getitem_167 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_55, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_73 = torch.ops.aten.add.Tensor(primals_392, 1);  primals_392 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_395, primals_396, primals_393, primals_394, True, 0.1, 0.001);  primals_396 = None
        getitem_170 = native_batch_norm_default_56[0]
        getitem_171 = native_batch_norm_default_56[1]
        getitem_172 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_56, primals_32, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_74 = torch.ops.aten.add.Tensor(primals_397, 1);  primals_397 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_400, primals_401, primals_398, primals_399, True, 0.1, 0.001);  primals_401 = None
        getitem_173 = native_batch_norm_default_57[0]
        getitem_174 = native_batch_norm_default_57[1]
        getitem_175 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_173);  getitem_173 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_57, primals_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_160 = torch.ops.aten.slice.Tensor(convolution_default_57, 0, 0, 9223372036854775807)
        slice_tensor_161 = torch.ops.aten.slice.Tensor(slice_tensor_160, 1, 0, 1024);  slice_tensor_160 = None
        slice_tensor_162 = torch.ops.aten.slice.Tensor(slice_tensor_161, 2, 0, 9223372036854775807);  slice_tensor_161 = None
        slice_tensor_163 = torch.ops.aten.slice.Tensor(slice_tensor_162, 3, 0, 9223372036854775807);  slice_tensor_162 = None
        slice_tensor_164 = torch.ops.aten.slice.Tensor(convolution_default_57, 0, 0, 9223372036854775807);  convolution_default_57 = None
        slice_tensor_165 = torch.ops.aten.slice.Tensor(slice_tensor_164, 1, 1024, 9223372036854775807);  slice_tensor_164 = None
        slice_tensor_166 = torch.ops.aten.slice.Tensor(slice_tensor_165, 2, 0, 9223372036854775807);  slice_tensor_165 = None
        slice_tensor_167 = torch.ops.aten.slice.Tensor(slice_tensor_166, 3, 0, 9223372036854775807);  slice_tensor_166 = None
        add_tensor_75 = torch.ops.aten.add.Tensor(add_tensor_71, slice_tensor_163);  add_tensor_71 = slice_tensor_163 = None
        cat_default_34 = torch.ops.aten.cat.default([cat_default_32, slice_tensor_167], 1);  cat_default_32 = slice_tensor_167 = None
        cat_default_35 = torch.ops.aten.cat.default([add_tensor_75, cat_default_34], 1)
        add_tensor_76 = torch.ops.aten.add.Tensor(primals_402, 1);  primals_402 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(cat_default_35, primals_405, primals_406, primals_403, primals_404, True, 0.1, 0.001);  primals_406 = None
        getitem_176 = native_batch_norm_default_58[0]
        getitem_177 = native_batch_norm_default_58[1]
        getitem_178 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_58, primals_33, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_77 = torch.ops.aten.add.Tensor(primals_407, 1);  primals_407 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_410, primals_411, primals_408, primals_409, True, 0.1, 0.001);  primals_411 = None
        getitem_179 = native_batch_norm_default_59[0]
        getitem_180 = native_batch_norm_default_59[1]
        getitem_181 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_179);  getitem_179 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_59, primals_35, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_78 = torch.ops.aten.add.Tensor(primals_412, 1);  primals_412 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_415, primals_416, primals_413, primals_414, True, 0.1, 0.001);  primals_416 = None
        getitem_182 = native_batch_norm_default_60[0]
        getitem_183 = native_batch_norm_default_60[1]
        getitem_184 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_60, primals_34, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_168 = torch.ops.aten.slice.Tensor(convolution_default_60, 0, 0, 9223372036854775807)
        slice_tensor_169 = torch.ops.aten.slice.Tensor(slice_tensor_168, 1, 0, 1024);  slice_tensor_168 = None
        slice_tensor_170 = torch.ops.aten.slice.Tensor(slice_tensor_169, 2, 0, 9223372036854775807);  slice_tensor_169 = None
        slice_tensor_171 = torch.ops.aten.slice.Tensor(slice_tensor_170, 3, 0, 9223372036854775807);  slice_tensor_170 = None
        slice_tensor_172 = torch.ops.aten.slice.Tensor(convolution_default_60, 0, 0, 9223372036854775807);  convolution_default_60 = None
        slice_tensor_173 = torch.ops.aten.slice.Tensor(slice_tensor_172, 1, 1024, 9223372036854775807);  slice_tensor_172 = None
        slice_tensor_174 = torch.ops.aten.slice.Tensor(slice_tensor_173, 2, 0, 9223372036854775807);  slice_tensor_173 = None
        slice_tensor_175 = torch.ops.aten.slice.Tensor(slice_tensor_174, 3, 0, 9223372036854775807);  slice_tensor_174 = None
        add_tensor_79 = torch.ops.aten.add.Tensor(add_tensor_75, slice_tensor_171);  add_tensor_75 = slice_tensor_171 = None
        cat_default_36 = torch.ops.aten.cat.default([cat_default_34, slice_tensor_175], 1);  cat_default_34 = slice_tensor_175 = None
        cat_default_37 = torch.ops.aten.cat.default([add_tensor_79, cat_default_36], 1)
        add_tensor_80 = torch.ops.aten.add.Tensor(primals_417, 1);  primals_417 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(cat_default_37, primals_420, primals_421, primals_418, primals_419, True, 0.1, 0.001);  primals_421 = None
        getitem_185 = native_batch_norm_default_61[0]
        getitem_186 = native_batch_norm_default_61[1]
        getitem_187 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_185);  getitem_185 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_61, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_81 = torch.ops.aten.add.Tensor(primals_422, 1);  primals_422 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_425, primals_426, primals_423, primals_424, True, 0.1, 0.001);  primals_426 = None
        getitem_188 = native_batch_norm_default_62[0]
        getitem_189 = native_batch_norm_default_62[1]
        getitem_190 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_62, primals_38, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_82 = torch.ops.aten.add.Tensor(primals_427, 1);  primals_427 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_430, primals_431, primals_428, primals_429, True, 0.1, 0.001);  primals_431 = None
        getitem_191 = native_batch_norm_default_63[0]
        getitem_192 = native_batch_norm_default_63[1]
        getitem_193 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_191);  getitem_191 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_63, primals_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_176 = torch.ops.aten.slice.Tensor(convolution_default_63, 0, 0, 9223372036854775807)
        slice_tensor_177 = torch.ops.aten.slice.Tensor(slice_tensor_176, 1, 0, 1024);  slice_tensor_176 = None
        slice_tensor_178 = torch.ops.aten.slice.Tensor(slice_tensor_177, 2, 0, 9223372036854775807);  slice_tensor_177 = None
        slice_tensor_179 = torch.ops.aten.slice.Tensor(slice_tensor_178, 3, 0, 9223372036854775807);  slice_tensor_178 = None
        slice_tensor_180 = torch.ops.aten.slice.Tensor(convolution_default_63, 0, 0, 9223372036854775807);  convolution_default_63 = None
        slice_tensor_181 = torch.ops.aten.slice.Tensor(slice_tensor_180, 1, 1024, 9223372036854775807);  slice_tensor_180 = None
        slice_tensor_182 = torch.ops.aten.slice.Tensor(slice_tensor_181, 2, 0, 9223372036854775807);  slice_tensor_181 = None
        slice_tensor_183 = torch.ops.aten.slice.Tensor(slice_tensor_182, 3, 0, 9223372036854775807);  slice_tensor_182 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(add_tensor_79, slice_tensor_179);  add_tensor_79 = slice_tensor_179 = None
        cat_default_38 = torch.ops.aten.cat.default([cat_default_36, slice_tensor_183], 1);  cat_default_36 = slice_tensor_183 = None
        cat_default_39 = torch.ops.aten.cat.default([add_tensor_83, cat_default_38], 1)
        add_tensor_84 = torch.ops.aten.add.Tensor(primals_432, 1);  primals_432 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(cat_default_39, primals_435, primals_436, primals_433, primals_434, True, 0.1, 0.001);  primals_436 = None
        getitem_194 = native_batch_norm_default_64[0]
        getitem_195 = native_batch_norm_default_64[1]
        getitem_196 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_64, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_85 = torch.ops.aten.add.Tensor(primals_437, 1);  primals_437 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_440, primals_441, primals_438, primals_439, True, 0.1, 0.001);  primals_441 = None
        getitem_197 = native_batch_norm_default_65[0]
        getitem_198 = native_batch_norm_default_65[1]
        getitem_199 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_197);  getitem_197 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_65, primals_41, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_86 = torch.ops.aten.add.Tensor(primals_442, 1);  primals_442 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(convolution_default_65, primals_445, primals_446, primals_443, primals_444, True, 0.1, 0.001);  primals_446 = None
        getitem_200 = native_batch_norm_default_66[0]
        getitem_201 = native_batch_norm_default_66[1]
        getitem_202 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_66, primals_40, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_184 = torch.ops.aten.slice.Tensor(convolution_default_66, 0, 0, 9223372036854775807)
        slice_tensor_185 = torch.ops.aten.slice.Tensor(slice_tensor_184, 1, 0, 1024);  slice_tensor_184 = None
        slice_tensor_186 = torch.ops.aten.slice.Tensor(slice_tensor_185, 2, 0, 9223372036854775807);  slice_tensor_185 = None
        slice_tensor_187 = torch.ops.aten.slice.Tensor(slice_tensor_186, 3, 0, 9223372036854775807);  slice_tensor_186 = None
        slice_tensor_188 = torch.ops.aten.slice.Tensor(convolution_default_66, 0, 0, 9223372036854775807);  convolution_default_66 = None
        slice_tensor_189 = torch.ops.aten.slice.Tensor(slice_tensor_188, 1, 1024, 9223372036854775807);  slice_tensor_188 = None
        slice_tensor_190 = torch.ops.aten.slice.Tensor(slice_tensor_189, 2, 0, 9223372036854775807);  slice_tensor_189 = None
        slice_tensor_191 = torch.ops.aten.slice.Tensor(slice_tensor_190, 3, 0, 9223372036854775807);  slice_tensor_190 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(add_tensor_83, slice_tensor_187);  add_tensor_83 = slice_tensor_187 = None
        cat_default_40 = torch.ops.aten.cat.default([cat_default_38, slice_tensor_191], 1);  cat_default_38 = slice_tensor_191 = None
        cat_default_41 = torch.ops.aten.cat.default([add_tensor_87, cat_default_40], 1)
        add_tensor_88 = torch.ops.aten.add.Tensor(primals_447, 1);  primals_447 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(cat_default_41, primals_450, primals_451, primals_448, primals_449, True, 0.1, 0.001);  primals_451 = None
        getitem_203 = native_batch_norm_default_67[0]
        getitem_204 = native_batch_norm_default_67[1]
        getitem_205 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_203);  getitem_203 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_67, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_89 = torch.ops.aten.add.Tensor(primals_452, 1);  primals_452 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(convolution_default_67, primals_455, primals_456, primals_453, primals_454, True, 0.1, 0.001);  primals_456 = None
        getitem_206 = native_batch_norm_default_68[0]
        getitem_207 = native_batch_norm_default_68[1]
        getitem_208 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_68, primals_44, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_90 = torch.ops.aten.add.Tensor(primals_457, 1);  primals_457 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(convolution_default_68, primals_460, primals_461, primals_458, primals_459, True, 0.1, 0.001);  primals_461 = None
        getitem_209 = native_batch_norm_default_69[0]
        getitem_210 = native_batch_norm_default_69[1]
        getitem_211 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_209);  getitem_209 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_69, primals_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_192 = torch.ops.aten.slice.Tensor(convolution_default_69, 0, 0, 9223372036854775807)
        slice_tensor_193 = torch.ops.aten.slice.Tensor(slice_tensor_192, 1, 0, 1024);  slice_tensor_192 = None
        slice_tensor_194 = torch.ops.aten.slice.Tensor(slice_tensor_193, 2, 0, 9223372036854775807);  slice_tensor_193 = None
        slice_tensor_195 = torch.ops.aten.slice.Tensor(slice_tensor_194, 3, 0, 9223372036854775807);  slice_tensor_194 = None
        slice_tensor_196 = torch.ops.aten.slice.Tensor(convolution_default_69, 0, 0, 9223372036854775807);  convolution_default_69 = None
        slice_tensor_197 = torch.ops.aten.slice.Tensor(slice_tensor_196, 1, 1024, 9223372036854775807);  slice_tensor_196 = None
        slice_tensor_198 = torch.ops.aten.slice.Tensor(slice_tensor_197, 2, 0, 9223372036854775807);  slice_tensor_197 = None
        slice_tensor_199 = torch.ops.aten.slice.Tensor(slice_tensor_198, 3, 0, 9223372036854775807);  slice_tensor_198 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(add_tensor_87, slice_tensor_195);  add_tensor_87 = slice_tensor_195 = None
        cat_default_42 = torch.ops.aten.cat.default([cat_default_40, slice_tensor_199], 1);  cat_default_40 = slice_tensor_199 = None
        cat_default_43 = torch.ops.aten.cat.default([add_tensor_91, cat_default_42], 1)
        add_tensor_92 = torch.ops.aten.add.Tensor(primals_462, 1);  primals_462 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(cat_default_43, primals_465, primals_466, primals_463, primals_464, True, 0.1, 0.001);  primals_466 = None
        getitem_212 = native_batch_norm_default_70[0]
        getitem_213 = native_batch_norm_default_70[1]
        getitem_214 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_70, primals_45, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_93 = torch.ops.aten.add.Tensor(primals_467, 1);  primals_467 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(convolution_default_70, primals_470, primals_471, primals_468, primals_469, True, 0.1, 0.001);  primals_471 = None
        getitem_215 = native_batch_norm_default_71[0]
        getitem_216 = native_batch_norm_default_71[1]
        getitem_217 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_215);  getitem_215 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_71, primals_47, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_94 = torch.ops.aten.add.Tensor(primals_472, 1);  primals_472 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(convolution_default_71, primals_475, primals_476, primals_473, primals_474, True, 0.1, 0.001);  primals_476 = None
        getitem_218 = native_batch_norm_default_72[0]
        getitem_219 = native_batch_norm_default_72[1]
        getitem_220 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_72, primals_46, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_200 = torch.ops.aten.slice.Tensor(convolution_default_72, 0, 0, 9223372036854775807)
        slice_tensor_201 = torch.ops.aten.slice.Tensor(slice_tensor_200, 1, 0, 1024);  slice_tensor_200 = None
        slice_tensor_202 = torch.ops.aten.slice.Tensor(slice_tensor_201, 2, 0, 9223372036854775807);  slice_tensor_201 = None
        slice_tensor_203 = torch.ops.aten.slice.Tensor(slice_tensor_202, 3, 0, 9223372036854775807);  slice_tensor_202 = None
        slice_tensor_204 = torch.ops.aten.slice.Tensor(convolution_default_72, 0, 0, 9223372036854775807);  convolution_default_72 = None
        slice_tensor_205 = torch.ops.aten.slice.Tensor(slice_tensor_204, 1, 1024, 9223372036854775807);  slice_tensor_204 = None
        slice_tensor_206 = torch.ops.aten.slice.Tensor(slice_tensor_205, 2, 0, 9223372036854775807);  slice_tensor_205 = None
        slice_tensor_207 = torch.ops.aten.slice.Tensor(slice_tensor_206, 3, 0, 9223372036854775807);  slice_tensor_206 = None
        add_tensor_95 = torch.ops.aten.add.Tensor(add_tensor_91, slice_tensor_203);  add_tensor_91 = slice_tensor_203 = None
        cat_default_44 = torch.ops.aten.cat.default([cat_default_42, slice_tensor_207], 1);  cat_default_42 = slice_tensor_207 = None
        cat_default_45 = torch.ops.aten.cat.default([add_tensor_95, cat_default_44], 1)
        add_tensor_96 = torch.ops.aten.add.Tensor(primals_477, 1);  primals_477 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(cat_default_45, primals_480, primals_481, primals_478, primals_479, True, 0.1, 0.001);  primals_481 = None
        getitem_221 = native_batch_norm_default_73[0]
        getitem_222 = native_batch_norm_default_73[1]
        getitem_223 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_221);  getitem_221 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_73, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_97 = torch.ops.aten.add.Tensor(primals_482, 1);  primals_482 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(convolution_default_73, primals_485, primals_486, primals_483, primals_484, True, 0.1, 0.001);  primals_486 = None
        getitem_224 = native_batch_norm_default_74[0]
        getitem_225 = native_batch_norm_default_74[1]
        getitem_226 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_224);  getitem_224 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_74, primals_50, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_98 = torch.ops.aten.add.Tensor(primals_487, 1);  primals_487 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(convolution_default_74, primals_490, primals_491, primals_488, primals_489, True, 0.1, 0.001);  primals_491 = None
        getitem_227 = native_batch_norm_default_75[0]
        getitem_228 = native_batch_norm_default_75[1]
        getitem_229 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_227);  getitem_227 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_75, primals_49, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_208 = torch.ops.aten.slice.Tensor(convolution_default_75, 0, 0, 9223372036854775807)
        slice_tensor_209 = torch.ops.aten.slice.Tensor(slice_tensor_208, 1, 0, 1024);  slice_tensor_208 = None
        slice_tensor_210 = torch.ops.aten.slice.Tensor(slice_tensor_209, 2, 0, 9223372036854775807);  slice_tensor_209 = None
        slice_tensor_211 = torch.ops.aten.slice.Tensor(slice_tensor_210, 3, 0, 9223372036854775807);  slice_tensor_210 = None
        slice_tensor_212 = torch.ops.aten.slice.Tensor(convolution_default_75, 0, 0, 9223372036854775807);  convolution_default_75 = None
        slice_tensor_213 = torch.ops.aten.slice.Tensor(slice_tensor_212, 1, 1024, 9223372036854775807);  slice_tensor_212 = None
        slice_tensor_214 = torch.ops.aten.slice.Tensor(slice_tensor_213, 2, 0, 9223372036854775807);  slice_tensor_213 = None
        slice_tensor_215 = torch.ops.aten.slice.Tensor(slice_tensor_214, 3, 0, 9223372036854775807);  slice_tensor_214 = None
        add_tensor_99 = torch.ops.aten.add.Tensor(add_tensor_95, slice_tensor_211);  add_tensor_95 = slice_tensor_211 = None
        cat_default_46 = torch.ops.aten.cat.default([cat_default_44, slice_tensor_215], 1);  cat_default_44 = slice_tensor_215 = None
        cat_default_47 = torch.ops.aten.cat.default([add_tensor_99, cat_default_46], 1)
        add_tensor_100 = torch.ops.aten.add.Tensor(primals_492, 1);  primals_492 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(cat_default_47, primals_495, primals_496, primals_493, primals_494, True, 0.1, 0.001);  primals_496 = None
        getitem_230 = native_batch_norm_default_76[0]
        getitem_231 = native_batch_norm_default_76[1]
        getitem_232 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_76, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_101 = torch.ops.aten.add.Tensor(primals_497, 1);  primals_497 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(convolution_default_76, primals_500, primals_501, primals_498, primals_499, True, 0.1, 0.001);  primals_501 = None
        getitem_233 = native_batch_norm_default_77[0]
        getitem_234 = native_batch_norm_default_77[1]
        getitem_235 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_233);  getitem_233 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_77, primals_53, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_102 = torch.ops.aten.add.Tensor(primals_502, 1);  primals_502 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(convolution_default_77, primals_505, primals_506, primals_503, primals_504, True, 0.1, 0.001);  primals_506 = None
        getitem_236 = native_batch_norm_default_78[0]
        getitem_237 = native_batch_norm_default_78[1]
        getitem_238 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_78, primals_52, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_216 = torch.ops.aten.slice.Tensor(convolution_default_78, 0, 0, 9223372036854775807)
        slice_tensor_217 = torch.ops.aten.slice.Tensor(slice_tensor_216, 1, 0, 1024);  slice_tensor_216 = None
        slice_tensor_218 = torch.ops.aten.slice.Tensor(slice_tensor_217, 2, 0, 9223372036854775807);  slice_tensor_217 = None
        slice_tensor_219 = torch.ops.aten.slice.Tensor(slice_tensor_218, 3, 0, 9223372036854775807);  slice_tensor_218 = None
        slice_tensor_220 = torch.ops.aten.slice.Tensor(convolution_default_78, 0, 0, 9223372036854775807);  convolution_default_78 = None
        slice_tensor_221 = torch.ops.aten.slice.Tensor(slice_tensor_220, 1, 1024, 9223372036854775807);  slice_tensor_220 = None
        slice_tensor_222 = torch.ops.aten.slice.Tensor(slice_tensor_221, 2, 0, 9223372036854775807);  slice_tensor_221 = None
        slice_tensor_223 = torch.ops.aten.slice.Tensor(slice_tensor_222, 3, 0, 9223372036854775807);  slice_tensor_222 = None
        add_tensor_103 = torch.ops.aten.add.Tensor(add_tensor_99, slice_tensor_219);  add_tensor_99 = slice_tensor_219 = None
        cat_default_48 = torch.ops.aten.cat.default([cat_default_46, slice_tensor_223], 1);  cat_default_46 = slice_tensor_223 = None
        cat_default_49 = torch.ops.aten.cat.default([add_tensor_103, cat_default_48], 1)
        add_tensor_104 = torch.ops.aten.add.Tensor(primals_507, 1);  primals_507 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(cat_default_49, primals_510, primals_511, primals_508, primals_509, True, 0.1, 0.001);  primals_511 = None
        getitem_239 = native_batch_norm_default_79[0]
        getitem_240 = native_batch_norm_default_79[1]
        getitem_241 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_239);  getitem_239 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_79, primals_54, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_105 = torch.ops.aten.add.Tensor(primals_512, 1);  primals_512 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(convolution_default_79, primals_515, primals_516, primals_513, primals_514, True, 0.1, 0.001);  primals_516 = None
        getitem_242 = native_batch_norm_default_80[0]
        getitem_243 = native_batch_norm_default_80[1]
        getitem_244 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_80, primals_56, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_106 = torch.ops.aten.add.Tensor(primals_517, 1);  primals_517 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(convolution_default_80, primals_520, primals_521, primals_518, primals_519, True, 0.1, 0.001);  primals_521 = None
        getitem_245 = native_batch_norm_default_81[0]
        getitem_246 = native_batch_norm_default_81[1]
        getitem_247 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_245);  getitem_245 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_81, primals_55, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_224 = torch.ops.aten.slice.Tensor(convolution_default_81, 0, 0, 9223372036854775807)
        slice_tensor_225 = torch.ops.aten.slice.Tensor(slice_tensor_224, 1, 0, 1024);  slice_tensor_224 = None
        slice_tensor_226 = torch.ops.aten.slice.Tensor(slice_tensor_225, 2, 0, 9223372036854775807);  slice_tensor_225 = None
        slice_tensor_227 = torch.ops.aten.slice.Tensor(slice_tensor_226, 3, 0, 9223372036854775807);  slice_tensor_226 = None
        slice_tensor_228 = torch.ops.aten.slice.Tensor(convolution_default_81, 0, 0, 9223372036854775807);  convolution_default_81 = None
        slice_tensor_229 = torch.ops.aten.slice.Tensor(slice_tensor_228, 1, 1024, 9223372036854775807);  slice_tensor_228 = None
        slice_tensor_230 = torch.ops.aten.slice.Tensor(slice_tensor_229, 2, 0, 9223372036854775807);  slice_tensor_229 = None
        slice_tensor_231 = torch.ops.aten.slice.Tensor(slice_tensor_230, 3, 0, 9223372036854775807);  slice_tensor_230 = None
        add_tensor_107 = torch.ops.aten.add.Tensor(add_tensor_103, slice_tensor_227);  add_tensor_103 = slice_tensor_227 = None
        cat_default_50 = torch.ops.aten.cat.default([cat_default_48, slice_tensor_231], 1);  cat_default_48 = slice_tensor_231 = None
        cat_default_51 = torch.ops.aten.cat.default([add_tensor_107, cat_default_50], 1)
        add_tensor_108 = torch.ops.aten.add.Tensor(primals_522, 1);  primals_522 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(cat_default_51, primals_525, primals_526, primals_523, primals_524, True, 0.1, 0.001);  primals_526 = None
        getitem_248 = native_batch_norm_default_82[0]
        getitem_249 = native_batch_norm_default_82[1]
        getitem_250 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_82, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_109 = torch.ops.aten.add.Tensor(primals_527, 1);  primals_527 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(convolution_default_82, primals_530, primals_531, primals_528, primals_529, True, 0.1, 0.001);  primals_531 = None
        getitem_251 = native_batch_norm_default_83[0]
        getitem_252 = native_batch_norm_default_83[1]
        getitem_253 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_251);  getitem_251 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_83, primals_59, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_110 = torch.ops.aten.add.Tensor(primals_532, 1);  primals_532 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(convolution_default_83, primals_535, primals_536, primals_533, primals_534, True, 0.1, 0.001);  primals_536 = None
        getitem_254 = native_batch_norm_default_84[0]
        getitem_255 = native_batch_norm_default_84[1]
        getitem_256 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_84, primals_58, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_232 = torch.ops.aten.slice.Tensor(convolution_default_84, 0, 0, 9223372036854775807)
        slice_tensor_233 = torch.ops.aten.slice.Tensor(slice_tensor_232, 1, 0, 1024);  slice_tensor_232 = None
        slice_tensor_234 = torch.ops.aten.slice.Tensor(slice_tensor_233, 2, 0, 9223372036854775807);  slice_tensor_233 = None
        slice_tensor_235 = torch.ops.aten.slice.Tensor(slice_tensor_234, 3, 0, 9223372036854775807);  slice_tensor_234 = None
        slice_tensor_236 = torch.ops.aten.slice.Tensor(convolution_default_84, 0, 0, 9223372036854775807);  convolution_default_84 = None
        slice_tensor_237 = torch.ops.aten.slice.Tensor(slice_tensor_236, 1, 1024, 9223372036854775807);  slice_tensor_236 = None
        slice_tensor_238 = torch.ops.aten.slice.Tensor(slice_tensor_237, 2, 0, 9223372036854775807);  slice_tensor_237 = None
        slice_tensor_239 = torch.ops.aten.slice.Tensor(slice_tensor_238, 3, 0, 9223372036854775807);  slice_tensor_238 = None
        add_tensor_111 = torch.ops.aten.add.Tensor(add_tensor_107, slice_tensor_235);  add_tensor_107 = slice_tensor_235 = None
        cat_default_52 = torch.ops.aten.cat.default([cat_default_50, slice_tensor_239], 1);  cat_default_50 = slice_tensor_239 = None
        cat_default_53 = torch.ops.aten.cat.default([add_tensor_111, cat_default_52], 1)
        add_tensor_112 = torch.ops.aten.add.Tensor(primals_537, 1);  primals_537 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(cat_default_53, primals_540, primals_541, primals_538, primals_539, True, 0.1, 0.001);  primals_541 = None
        getitem_257 = native_batch_norm_default_85[0]
        getitem_258 = native_batch_norm_default_85[1]
        getitem_259 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_257);  getitem_257 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_85, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_113 = torch.ops.aten.add.Tensor(primals_542, 1);  primals_542 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(convolution_default_85, primals_545, primals_546, primals_543, primals_544, True, 0.1, 0.001);  primals_546 = None
        getitem_260 = native_batch_norm_default_86[0]
        getitem_261 = native_batch_norm_default_86[1]
        getitem_262 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_86, primals_62, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_114 = torch.ops.aten.add.Tensor(primals_547, 1);  primals_547 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(convolution_default_86, primals_550, primals_551, primals_548, primals_549, True, 0.1, 0.001);  primals_551 = None
        getitem_263 = native_batch_norm_default_87[0]
        getitem_264 = native_batch_norm_default_87[1]
        getitem_265 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_263);  getitem_263 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_87, primals_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_240 = torch.ops.aten.slice.Tensor(convolution_default_87, 0, 0, 9223372036854775807)
        slice_tensor_241 = torch.ops.aten.slice.Tensor(slice_tensor_240, 1, 0, 1024);  slice_tensor_240 = None
        slice_tensor_242 = torch.ops.aten.slice.Tensor(slice_tensor_241, 2, 0, 9223372036854775807);  slice_tensor_241 = None
        slice_tensor_243 = torch.ops.aten.slice.Tensor(slice_tensor_242, 3, 0, 9223372036854775807);  slice_tensor_242 = None
        slice_tensor_244 = torch.ops.aten.slice.Tensor(convolution_default_87, 0, 0, 9223372036854775807);  convolution_default_87 = None
        slice_tensor_245 = torch.ops.aten.slice.Tensor(slice_tensor_244, 1, 1024, 9223372036854775807);  slice_tensor_244 = None
        slice_tensor_246 = torch.ops.aten.slice.Tensor(slice_tensor_245, 2, 0, 9223372036854775807);  slice_tensor_245 = None
        slice_tensor_247 = torch.ops.aten.slice.Tensor(slice_tensor_246, 3, 0, 9223372036854775807);  slice_tensor_246 = None
        add_tensor_115 = torch.ops.aten.add.Tensor(add_tensor_111, slice_tensor_243);  add_tensor_111 = slice_tensor_243 = None
        cat_default_54 = torch.ops.aten.cat.default([cat_default_52, slice_tensor_247], 1);  cat_default_52 = slice_tensor_247 = None
        cat_default_55 = torch.ops.aten.cat.default([add_tensor_115, cat_default_54], 1)
        add_tensor_116 = torch.ops.aten.add.Tensor(primals_552, 1);  primals_552 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(cat_default_55, primals_555, primals_556, primals_553, primals_554, True, 0.1, 0.001);  primals_556 = None
        getitem_266 = native_batch_norm_default_88[0]
        getitem_267 = native_batch_norm_default_88[1]
        getitem_268 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_88, primals_67, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_117 = torch.ops.aten.add.Tensor(primals_557, 1);  primals_557 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(convolution_default_88, primals_560, primals_561, primals_558, primals_559, True, 0.1, 0.001);  primals_561 = None
        getitem_269 = native_batch_norm_default_89[0]
        getitem_270 = native_batch_norm_default_89[1]
        getitem_271 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_269);  getitem_269 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_89, primals_69, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_118 = torch.ops.aten.add.Tensor(primals_562, 1);  primals_562 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(convolution_default_89, primals_565, primals_566, primals_563, primals_564, True, 0.1, 0.001);  primals_566 = None
        getitem_272 = native_batch_norm_default_90[0]
        getitem_273 = native_batch_norm_default_90[1]
        getitem_274 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        relu__default_90 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_90, primals_68, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_248 = torch.ops.aten.slice.Tensor(convolution_default_90, 0, 0, 9223372036854775807)
        slice_tensor_249 = torch.ops.aten.slice.Tensor(slice_tensor_248, 1, 0, 1024);  slice_tensor_248 = None
        slice_tensor_250 = torch.ops.aten.slice.Tensor(slice_tensor_249, 2, 0, 9223372036854775807);  slice_tensor_249 = None
        slice_tensor_251 = torch.ops.aten.slice.Tensor(slice_tensor_250, 3, 0, 9223372036854775807);  slice_tensor_250 = None
        slice_tensor_252 = torch.ops.aten.slice.Tensor(convolution_default_90, 0, 0, 9223372036854775807);  convolution_default_90 = None
        slice_tensor_253 = torch.ops.aten.slice.Tensor(slice_tensor_252, 1, 1024, 9223372036854775807);  slice_tensor_252 = None
        slice_tensor_254 = torch.ops.aten.slice.Tensor(slice_tensor_253, 2, 0, 9223372036854775807);  slice_tensor_253 = None
        slice_tensor_255 = torch.ops.aten.slice.Tensor(slice_tensor_254, 3, 0, 9223372036854775807);  slice_tensor_254 = None
        add_tensor_119 = torch.ops.aten.add.Tensor(add_tensor_115, slice_tensor_251);  add_tensor_115 = slice_tensor_251 = None
        cat_default_56 = torch.ops.aten.cat.default([cat_default_54, slice_tensor_255], 1);  cat_default_54 = slice_tensor_255 = None
        cat_default_57 = torch.ops.aten.cat.default([add_tensor_119, cat_default_56], 1)
        add_tensor_120 = torch.ops.aten.add.Tensor(primals_567, 1);  primals_567 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(cat_default_57, primals_570, primals_571, primals_568, primals_569, True, 0.1, 0.001);  primals_571 = None
        getitem_275 = native_batch_norm_default_91[0]
        getitem_276 = native_batch_norm_default_91[1]
        getitem_277 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_275);  getitem_275 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_91, primals_70, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_121 = torch.ops.aten.add.Tensor(primals_572, 1);  primals_572 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(convolution_default_91, primals_575, primals_576, primals_573, primals_574, True, 0.1, 0.001);  primals_576 = None
        getitem_278 = native_batch_norm_default_92[0]
        getitem_279 = native_batch_norm_default_92[1]
        getitem_280 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_92, primals_72, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_122 = torch.ops.aten.add.Tensor(primals_577, 1);  primals_577 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(convolution_default_92, primals_580, primals_581, primals_578, primals_579, True, 0.1, 0.001);  primals_581 = None
        getitem_281 = native_batch_norm_default_93[0]
        getitem_282 = native_batch_norm_default_93[1]
        getitem_283 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_281);  getitem_281 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_93, primals_71, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_256 = torch.ops.aten.slice.Tensor(convolution_default_93, 0, 0, 9223372036854775807)
        slice_tensor_257 = torch.ops.aten.slice.Tensor(slice_tensor_256, 1, 0, 1024);  slice_tensor_256 = None
        slice_tensor_258 = torch.ops.aten.slice.Tensor(slice_tensor_257, 2, 0, 9223372036854775807);  slice_tensor_257 = None
        slice_tensor_259 = torch.ops.aten.slice.Tensor(slice_tensor_258, 3, 0, 9223372036854775807);  slice_tensor_258 = None
        slice_tensor_260 = torch.ops.aten.slice.Tensor(convolution_default_93, 0, 0, 9223372036854775807);  convolution_default_93 = None
        slice_tensor_261 = torch.ops.aten.slice.Tensor(slice_tensor_260, 1, 1024, 9223372036854775807);  slice_tensor_260 = None
        slice_tensor_262 = torch.ops.aten.slice.Tensor(slice_tensor_261, 2, 0, 9223372036854775807);  slice_tensor_261 = None
        slice_tensor_263 = torch.ops.aten.slice.Tensor(slice_tensor_262, 3, 0, 9223372036854775807);  slice_tensor_262 = None
        add_tensor_123 = torch.ops.aten.add.Tensor(add_tensor_119, slice_tensor_259);  add_tensor_119 = slice_tensor_259 = None
        cat_default_58 = torch.ops.aten.cat.default([cat_default_56, slice_tensor_263], 1);  cat_default_56 = slice_tensor_263 = None
        cat_default_59 = torch.ops.aten.cat.default([add_tensor_123, cat_default_58], 1)
        add_tensor_124 = torch.ops.aten.add.Tensor(primals_582, 1);  primals_582 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(cat_default_59, primals_585, primals_586, primals_583, primals_584, True, 0.1, 0.001);  primals_586 = None
        getitem_284 = native_batch_norm_default_94[0]
        getitem_285 = native_batch_norm_default_94[1]
        getitem_286 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_94, primals_73, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_125 = torch.ops.aten.add.Tensor(primals_587, 1);  primals_587 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(convolution_default_94, primals_590, primals_591, primals_588, primals_589, True, 0.1, 0.001);  primals_591 = None
        getitem_287 = native_batch_norm_default_95[0]
        getitem_288 = native_batch_norm_default_95[1]
        getitem_289 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_287);  getitem_287 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_95, primals_75, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_126 = torch.ops.aten.add.Tensor(primals_592, 1);  primals_592 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(convolution_default_95, primals_595, primals_596, primals_593, primals_594, True, 0.1, 0.001);  primals_596 = None
        getitem_290 = native_batch_norm_default_96[0]
        getitem_291 = native_batch_norm_default_96[1]
        getitem_292 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_96, primals_74, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_264 = torch.ops.aten.slice.Tensor(convolution_default_96, 0, 0, 9223372036854775807)
        slice_tensor_265 = torch.ops.aten.slice.Tensor(slice_tensor_264, 1, 0, 1024);  slice_tensor_264 = None
        slice_tensor_266 = torch.ops.aten.slice.Tensor(slice_tensor_265, 2, 0, 9223372036854775807);  slice_tensor_265 = None
        slice_tensor_267 = torch.ops.aten.slice.Tensor(slice_tensor_266, 3, 0, 9223372036854775807);  slice_tensor_266 = None
        slice_tensor_268 = torch.ops.aten.slice.Tensor(convolution_default_96, 0, 0, 9223372036854775807);  convolution_default_96 = None
        slice_tensor_269 = torch.ops.aten.slice.Tensor(slice_tensor_268, 1, 1024, 9223372036854775807);  slice_tensor_268 = None
        slice_tensor_270 = torch.ops.aten.slice.Tensor(slice_tensor_269, 2, 0, 9223372036854775807);  slice_tensor_269 = None
        slice_tensor_271 = torch.ops.aten.slice.Tensor(slice_tensor_270, 3, 0, 9223372036854775807);  slice_tensor_270 = None
        add_tensor_127 = torch.ops.aten.add.Tensor(add_tensor_123, slice_tensor_267);  add_tensor_123 = slice_tensor_267 = None
        cat_default_60 = torch.ops.aten.cat.default([cat_default_58, slice_tensor_271], 1);  cat_default_58 = slice_tensor_271 = None
        cat_default_61 = torch.ops.aten.cat.default([add_tensor_127, cat_default_60], 1)
        add_tensor_128 = torch.ops.aten.add.Tensor(primals_597, 1);  primals_597 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(cat_default_61, primals_600, primals_601, primals_598, primals_599, True, 0.1, 0.001);  primals_601 = None
        getitem_293 = native_batch_norm_default_97[0]
        getitem_294 = native_batch_norm_default_97[1]
        getitem_295 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_293);  getitem_293 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_97, primals_76, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_129 = torch.ops.aten.add.Tensor(primals_602, 1);  primals_602 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(convolution_default_97, primals_605, primals_606, primals_603, primals_604, True, 0.1, 0.001);  primals_606 = None
        getitem_296 = native_batch_norm_default_98[0]
        getitem_297 = native_batch_norm_default_98[1]
        getitem_298 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_296);  getitem_296 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_98, primals_78, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_130 = torch.ops.aten.add.Tensor(primals_607, 1);  primals_607 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(convolution_default_98, primals_610, primals_611, primals_608, primals_609, True, 0.1, 0.001);  primals_611 = None
        getitem_299 = native_batch_norm_default_99[0]
        getitem_300 = native_batch_norm_default_99[1]
        getitem_301 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_299);  getitem_299 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_99, primals_77, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_272 = torch.ops.aten.slice.Tensor(convolution_default_99, 0, 0, 9223372036854775807)
        slice_tensor_273 = torch.ops.aten.slice.Tensor(slice_tensor_272, 1, 0, 1024);  slice_tensor_272 = None
        slice_tensor_274 = torch.ops.aten.slice.Tensor(slice_tensor_273, 2, 0, 9223372036854775807);  slice_tensor_273 = None
        slice_tensor_275 = torch.ops.aten.slice.Tensor(slice_tensor_274, 3, 0, 9223372036854775807);  slice_tensor_274 = None
        slice_tensor_276 = torch.ops.aten.slice.Tensor(convolution_default_99, 0, 0, 9223372036854775807);  convolution_default_99 = None
        slice_tensor_277 = torch.ops.aten.slice.Tensor(slice_tensor_276, 1, 1024, 9223372036854775807);  slice_tensor_276 = None
        slice_tensor_278 = torch.ops.aten.slice.Tensor(slice_tensor_277, 2, 0, 9223372036854775807);  slice_tensor_277 = None
        slice_tensor_279 = torch.ops.aten.slice.Tensor(slice_tensor_278, 3, 0, 9223372036854775807);  slice_tensor_278 = None
        add_tensor_131 = torch.ops.aten.add.Tensor(add_tensor_127, slice_tensor_275);  add_tensor_127 = slice_tensor_275 = None
        cat_default_62 = torch.ops.aten.cat.default([cat_default_60, slice_tensor_279], 1);  cat_default_60 = slice_tensor_279 = None
        cat_default_63 = torch.ops.aten.cat.default([add_tensor_131, cat_default_62], 1);  add_tensor_131 = cat_default_62 = None
        add_tensor_132 = torch.ops.aten.add.Tensor(primals_612, 1);  primals_612 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(cat_default_63, primals_615, primals_616, primals_613, primals_614, True, 0.1, 0.001);  primals_616 = None
        getitem_302 = native_batch_norm_default_100[0]
        getitem_303 = native_batch_norm_default_100[1]
        getitem_304 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        relu__default_100 = torch.ops.aten.relu_.default(getitem_302);  getitem_302 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_100, primals_81, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_280 = torch.ops.aten.slice.Tensor(convolution_default_100, 0, 0, 9223372036854775807)
        slice_tensor_281 = torch.ops.aten.slice.Tensor(slice_tensor_280, 1, 0, 2048);  slice_tensor_280 = None
        slice_tensor_282 = torch.ops.aten.slice.Tensor(slice_tensor_281, 2, 0, 9223372036854775807);  slice_tensor_281 = None
        slice_tensor_283 = torch.ops.aten.slice.Tensor(slice_tensor_282, 3, 0, 9223372036854775807);  slice_tensor_282 = None
        slice_tensor_284 = torch.ops.aten.slice.Tensor(convolution_default_100, 0, 0, 9223372036854775807);  convolution_default_100 = None
        slice_tensor_285 = torch.ops.aten.slice.Tensor(slice_tensor_284, 1, 2048, 9223372036854775807);  slice_tensor_284 = None
        slice_tensor_286 = torch.ops.aten.slice.Tensor(slice_tensor_285, 2, 0, 9223372036854775807);  slice_tensor_285 = None
        slice_tensor_287 = torch.ops.aten.slice.Tensor(slice_tensor_286, 3, 0, 9223372036854775807);  slice_tensor_286 = None
        add_tensor_133 = torch.ops.aten.add.Tensor(primals_617, 1);  primals_617 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(cat_default_63, primals_620, primals_621, primals_618, primals_619, True, 0.1, 0.001);  primals_621 = None
        getitem_305 = native_batch_norm_default_101[0]
        getitem_306 = native_batch_norm_default_101[1]
        getitem_307 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        relu__default_101 = torch.ops.aten.relu_.default(getitem_305);  getitem_305 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_101, primals_79, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_134 = torch.ops.aten.add.Tensor(primals_622, 1);  primals_622 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(convolution_default_101, primals_625, primals_626, primals_623, primals_624, True, 0.1, 0.001);  primals_626 = None
        getitem_308 = native_batch_norm_default_102[0]
        getitem_309 = native_batch_norm_default_102[1]
        getitem_310 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        relu__default_102 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_102, primals_82, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_135 = torch.ops.aten.add.Tensor(primals_627, 1);  primals_627 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(convolution_default_102, primals_630, primals_631, primals_628, primals_629, True, 0.1, 0.001);  primals_631 = None
        getitem_311 = native_batch_norm_default_103[0]
        getitem_312 = native_batch_norm_default_103[1]
        getitem_313 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        relu__default_103 = torch.ops.aten.relu_.default(getitem_311);  getitem_311 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_103, primals_80, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_288 = torch.ops.aten.slice.Tensor(convolution_default_103, 0, 0, 9223372036854775807)
        slice_tensor_289 = torch.ops.aten.slice.Tensor(slice_tensor_288, 1, 0, 2048);  slice_tensor_288 = None
        slice_tensor_290 = torch.ops.aten.slice.Tensor(slice_tensor_289, 2, 0, 9223372036854775807);  slice_tensor_289 = None
        slice_tensor_291 = torch.ops.aten.slice.Tensor(slice_tensor_290, 3, 0, 9223372036854775807);  slice_tensor_290 = None
        slice_tensor_292 = torch.ops.aten.slice.Tensor(convolution_default_103, 0, 0, 9223372036854775807);  convolution_default_103 = None
        slice_tensor_293 = torch.ops.aten.slice.Tensor(slice_tensor_292, 1, 2048, 9223372036854775807);  slice_tensor_292 = None
        slice_tensor_294 = torch.ops.aten.slice.Tensor(slice_tensor_293, 2, 0, 9223372036854775807);  slice_tensor_293 = None
        slice_tensor_295 = torch.ops.aten.slice.Tensor(slice_tensor_294, 3, 0, 9223372036854775807);  slice_tensor_294 = None
        add_tensor_136 = torch.ops.aten.add.Tensor(slice_tensor_283, slice_tensor_291);  slice_tensor_283 = slice_tensor_291 = None
        cat_default_64 = torch.ops.aten.cat.default([slice_tensor_287, slice_tensor_295], 1);  slice_tensor_287 = slice_tensor_295 = None
        cat_default_65 = torch.ops.aten.cat.default([add_tensor_136, cat_default_64], 1)
        add_tensor_137 = torch.ops.aten.add.Tensor(primals_632, 1);  primals_632 = None
        native_batch_norm_default_104 = torch.ops.aten.native_batch_norm.default(cat_default_65, primals_635, primals_636, primals_633, primals_634, True, 0.1, 0.001);  primals_636 = None
        getitem_314 = native_batch_norm_default_104[0]
        getitem_315 = native_batch_norm_default_104[1]
        getitem_316 = native_batch_norm_default_104[2];  native_batch_norm_default_104 = None
        relu__default_104 = torch.ops.aten.relu_.default(getitem_314);  getitem_314 = None
        convolution_default_104 = torch.ops.aten.convolution.default(relu__default_104, primals_83, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_138 = torch.ops.aten.add.Tensor(primals_637, 1);  primals_637 = None
        native_batch_norm_default_105 = torch.ops.aten.native_batch_norm.default(convolution_default_104, primals_640, primals_641, primals_638, primals_639, True, 0.1, 0.001);  primals_641 = None
        getitem_317 = native_batch_norm_default_105[0]
        getitem_318 = native_batch_norm_default_105[1]
        getitem_319 = native_batch_norm_default_105[2];  native_batch_norm_default_105 = None
        relu__default_105 = torch.ops.aten.relu_.default(getitem_317);  getitem_317 = None
        convolution_default_105 = torch.ops.aten.convolution.default(relu__default_105, primals_85, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_139 = torch.ops.aten.add.Tensor(primals_642, 1);  primals_642 = None
        native_batch_norm_default_106 = torch.ops.aten.native_batch_norm.default(convolution_default_105, primals_645, primals_646, primals_643, primals_644, True, 0.1, 0.001);  primals_646 = None
        getitem_320 = native_batch_norm_default_106[0]
        getitem_321 = native_batch_norm_default_106[1]
        getitem_322 = native_batch_norm_default_106[2];  native_batch_norm_default_106 = None
        relu__default_106 = torch.ops.aten.relu_.default(getitem_320);  getitem_320 = None
        convolution_default_106 = torch.ops.aten.convolution.default(relu__default_106, primals_84, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_296 = torch.ops.aten.slice.Tensor(convolution_default_106, 0, 0, 9223372036854775807)
        slice_tensor_297 = torch.ops.aten.slice.Tensor(slice_tensor_296, 1, 0, 2048);  slice_tensor_296 = None
        slice_tensor_298 = torch.ops.aten.slice.Tensor(slice_tensor_297, 2, 0, 9223372036854775807);  slice_tensor_297 = None
        slice_tensor_299 = torch.ops.aten.slice.Tensor(slice_tensor_298, 3, 0, 9223372036854775807);  slice_tensor_298 = None
        slice_tensor_300 = torch.ops.aten.slice.Tensor(convolution_default_106, 0, 0, 9223372036854775807);  convolution_default_106 = None
        slice_tensor_301 = torch.ops.aten.slice.Tensor(slice_tensor_300, 1, 2048, 9223372036854775807);  slice_tensor_300 = None
        slice_tensor_302 = torch.ops.aten.slice.Tensor(slice_tensor_301, 2, 0, 9223372036854775807);  slice_tensor_301 = None
        slice_tensor_303 = torch.ops.aten.slice.Tensor(slice_tensor_302, 3, 0, 9223372036854775807);  slice_tensor_302 = None
        add_tensor_140 = torch.ops.aten.add.Tensor(add_tensor_136, slice_tensor_299);  add_tensor_136 = slice_tensor_299 = None
        cat_default_66 = torch.ops.aten.cat.default([cat_default_64, slice_tensor_303], 1);  cat_default_64 = slice_tensor_303 = None
        cat_default_67 = torch.ops.aten.cat.default([add_tensor_140, cat_default_66], 1)
        add_tensor_141 = torch.ops.aten.add.Tensor(primals_647, 1);  primals_647 = None
        native_batch_norm_default_107 = torch.ops.aten.native_batch_norm.default(cat_default_67, primals_650, primals_651, primals_648, primals_649, True, 0.1, 0.001);  primals_651 = None
        getitem_323 = native_batch_norm_default_107[0]
        getitem_324 = native_batch_norm_default_107[1]
        getitem_325 = native_batch_norm_default_107[2];  native_batch_norm_default_107 = None
        relu__default_107 = torch.ops.aten.relu_.default(getitem_323);  getitem_323 = None
        convolution_default_107 = torch.ops.aten.convolution.default(relu__default_107, primals_86, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_142 = torch.ops.aten.add.Tensor(primals_652, 1);  primals_652 = None
        native_batch_norm_default_108 = torch.ops.aten.native_batch_norm.default(convolution_default_107, primals_655, primals_656, primals_653, primals_654, True, 0.1, 0.001);  primals_656 = None
        getitem_326 = native_batch_norm_default_108[0]
        getitem_327 = native_batch_norm_default_108[1]
        getitem_328 = native_batch_norm_default_108[2];  native_batch_norm_default_108 = None
        relu__default_108 = torch.ops.aten.relu_.default(getitem_326);  getitem_326 = None
        convolution_default_108 = torch.ops.aten.convolution.default(relu__default_108, primals_88, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 50)
        add_tensor_143 = torch.ops.aten.add.Tensor(primals_657, 1);  primals_657 = None
        native_batch_norm_default_109 = torch.ops.aten.native_batch_norm.default(convolution_default_108, primals_660, primals_661, primals_658, primals_659, True, 0.1, 0.001);  primals_661 = None
        getitem_329 = native_batch_norm_default_109[0]
        getitem_330 = native_batch_norm_default_109[1]
        getitem_331 = native_batch_norm_default_109[2];  native_batch_norm_default_109 = None
        relu__default_109 = torch.ops.aten.relu_.default(getitem_329);  getitem_329 = None
        convolution_default_109 = torch.ops.aten.convolution.default(relu__default_109, primals_87, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        slice_tensor_304 = torch.ops.aten.slice.Tensor(convolution_default_109, 0, 0, 9223372036854775807)
        slice_tensor_305 = torch.ops.aten.slice.Tensor(slice_tensor_304, 1, 0, 2048);  slice_tensor_304 = None
        slice_tensor_306 = torch.ops.aten.slice.Tensor(slice_tensor_305, 2, 0, 9223372036854775807);  slice_tensor_305 = None
        slice_tensor_307 = torch.ops.aten.slice.Tensor(slice_tensor_306, 3, 0, 9223372036854775807);  slice_tensor_306 = None
        slice_tensor_308 = torch.ops.aten.slice.Tensor(convolution_default_109, 0, 0, 9223372036854775807);  convolution_default_109 = None
        slice_tensor_309 = torch.ops.aten.slice.Tensor(slice_tensor_308, 1, 2048, 9223372036854775807);  slice_tensor_308 = None
        slice_tensor_310 = torch.ops.aten.slice.Tensor(slice_tensor_309, 2, 0, 9223372036854775807);  slice_tensor_309 = None
        slice_tensor_311 = torch.ops.aten.slice.Tensor(slice_tensor_310, 3, 0, 9223372036854775807);  slice_tensor_310 = None
        add_tensor_144 = torch.ops.aten.add.Tensor(add_tensor_140, slice_tensor_307);  add_tensor_140 = slice_tensor_307 = None
        cat_default_68 = torch.ops.aten.cat.default([cat_default_66, slice_tensor_311], 1);  cat_default_66 = slice_tensor_311 = None
        cat_default_69 = torch.ops.aten.cat.default([add_tensor_144, cat_default_68], 1);  add_tensor_144 = cat_default_68 = None
        add_tensor_145 = torch.ops.aten.add.Tensor(primals_662, 1);  primals_662 = None
        native_batch_norm_default_110 = torch.ops.aten.native_batch_norm.default(cat_default_69, primals_665, primals_666, primals_663, primals_664, True, 0.1, 0.001);  primals_666 = None
        getitem_332 = native_batch_norm_default_110[0]
        getitem_333 = native_batch_norm_default_110[1]
        getitem_334 = native_batch_norm_default_110[2];  native_batch_norm_default_110 = None
        to_dtype = torch.ops.aten.to.dtype(getitem_332, torch.float32)
        gt_scalar = torch.ops.aten.gt.Scalar(to_dtype, 0)
        mul_tensor = torch.ops.aten.mul.Tensor(to_dtype, 1)
        mul_tensor_1 = torch.ops.aten.mul.Tensor(to_dtype, 1);  to_dtype = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_1);  mul_tensor_1 = None
        sub_tensor = torch.ops.aten.sub.Tensor(exp_default, 1);  exp_default = None
        mul_tensor_2 = torch.ops.aten.mul.Tensor(sub_tensor, 1.0);  sub_tensor = None
        where_self = torch.ops.aten.where.self(gt_scalar, mul_tensor, mul_tensor_2);  gt_scalar = mul_tensor = mul_tensor_2 = None
        to_dtype_1 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        return [to_dtype_1, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_4, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_10, add_tensor_11, add_tensor_12, add_tensor_14, add_tensor_15, add_tensor_16, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_23, add_tensor_24, add_tensor_25, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_35, add_tensor_36, add_tensor_37, add_tensor_39, add_tensor_40, add_tensor_41, add_tensor_43, add_tensor_44, add_tensor_45, add_tensor_47, add_tensor_48, add_tensor_49, add_tensor_51, add_tensor_52, add_tensor_53, add_tensor_54, add_tensor_56, add_tensor_57, add_tensor_58, add_tensor_60, add_tensor_61, add_tensor_62, add_tensor_64, add_tensor_65, add_tensor_66, add_tensor_68, add_tensor_69, add_tensor_70, add_tensor_72, add_tensor_73, add_tensor_74, add_tensor_76, add_tensor_77, add_tensor_78, add_tensor_80, add_tensor_81, add_tensor_82, add_tensor_84, add_tensor_85, add_tensor_86, add_tensor_88, add_tensor_89, add_tensor_90, add_tensor_92, add_tensor_93, add_tensor_94, add_tensor_96, add_tensor_97, add_tensor_98, add_tensor_100, add_tensor_101, add_tensor_102, add_tensor_104, add_tensor_105, add_tensor_106, add_tensor_108, add_tensor_109, add_tensor_110, add_tensor_112, add_tensor_113, add_tensor_114, add_tensor_116, add_tensor_117, add_tensor_118, add_tensor_120, add_tensor_121, add_tensor_122, add_tensor_124, add_tensor_125, add_tensor_126, add_tensor_128, add_tensor_129, add_tensor_130, add_tensor_132, add_tensor_133, add_tensor_134, add_tensor_135, add_tensor_137, add_tensor_138, add_tensor_139, add_tensor_141, add_tensor_142, add_tensor_143, add_tensor_145, primals_330, primals_459, primals_458, primals_329, primals_333, primals_328, primals_460, primals_334, primals_335, getitem_175, getitem_193, getitem_58, primals_33, relu__default_57, cat_default_11, relu__default_63, getitem_57, getitem_192, primals_32, cat_default_37, primals_28, primals_35, getitem_177, getitem_178, getitem_195, primals_34, cat_default_41, relu__default_18, getitem_196, primals_30, convolution_default_18, primals_37, getitem_61, getitem_60, primals_38, primals_31, primals_29, relu__default_58, primals_36, primals_39, relu__default_19, relu__default_64, convolution_default_58, convolution_default_19, convolution_default_64, primals_178, primals_359, primals_364, primals_363, primals_188, primals_360, cat_default_1, primals_365, primals_175, primals_185, primals_184, primals_180, primals_355, primals_183, primals_354, relu__default_5, convolution_default, primals_368, primals_358, relu__default_3, primals_179, primals_409, primals_495, getitem_76, primals_488, primals_415, getitem_10, primals_490, primals_425, primals_414, getitem_75, primals_408, primals_423, primals_489, cat_default_15, primals_483, primals_493, primals_413, primals_419, primals_410, relu__default_24, primals_424, convolution_default_24, primals_494, getitem_78, primals_420, primals_484, primals_405, getitem_79, relu__default_25, primals_418, primals_485, convolution_default_25, getitem_112, getitem_111, getitem_210, getitem_94, getitem_211, cat_default_23, getitem_334, getitem_333, getitem_93, cat_default_19, relu__default_69, getitem_213, cat_default_45, getitem_214, relu__default_30, convolution_default_30, relu__default_36, getitem_96, convolution_default_36, relu__default, getitem_114, getitem_25, getitem_97, cat_default_3, getitem_2, relu__default_31, getitem_115, relu__default_70, relu__default_37, convolution_default_31, convolution_default_37, convolution_default_70, getitem_1, getitem_229, primals_658, relu__default_100, getitem_228, primals_534, primals_269, primals_655, primals_654, primals_278, primals_528, primals_274, primals_270, cat_default_65, relu__default_75, getitem_306, primals_664, primals_524, primals_659, primals_535, getitem_231, cat_default_49, primals_533, getitem_232, getitem_307, primals_663, primals_660, primals_529, relu__default_101, primals_665, primals_268, convolution_default_101, primals_265, primals_525, primals_530, primals_273, convolution_default_76, relu__default_76, primals_538, primals_275, primals_60, getitem_294, cat_default_63, primals_403, primals_314, getitem_295, primals_398, primals_55, primals_59, primals_400, primals_325, primals_319, primals_323, primals_53, primals_320, relu__default_97, primals_324, primals_56, primals_318, convolution_default_97, primals_54, primals_404, getitem_297, primals_399, primals_313, primals_57, primals_58, primals_395, getitem_298, primals_315, primals_111, primals_199, primals_195, primals_109, primals_189, primals_194, primals_198, primals_108, primals_200, primals_110, primals_193, primals_190, getitem_127, primals_303, getitem_247, relu__default_41, getitem_265, convolution_default_41, getitem_246, getitem_264, primals_299, relu__default_81, getitem_130, getitem_129, relu__default_87, primals_309, primals_304, getitem_249, relu__default_42, getitem_267, cat_default_53, getitem_250, primals_310, cat_default_57, cat_default_27, primals_300, primals_305, primals_298, primals_308, getitem_268, relu__default_82, convolution_default_82, primals_14, primals_209, primals_263, primals_15, primals_213, primals_214, primals_215, primals_17, primals_208, primals_264, primals_13, primals_205, primals_204, primals_210, primals_203, primals_218, primals_16, primals_219, primals_220, primals_294, getitem_145, relu__default_106, relu__default_47, convolution_default_47, cat_default_69, getitem_324, getitem_148, getitem_325, getitem_147, relu__default_48, primals_293, cat_default_31, relu__default_107, primals_295, convolution_default_107, getitem_162, getitem_19, getitem_163, primals_553, getitem_18, getitem_4, getitem_45, getitem_46, relu__default_53, convolution_default_53, relu__default_14, primals_560, primals_394, primals_435, primals_388, getitem_166, getitem_165, primals_390, getitem_48, primals_433, primals_393, relu__default_54, primals_554, primals_389, primals_555, cat_default_9, primals_559, primals_429, getitem_49, primals_558, primals_428, getitem_3, convolution_default_15, relu__default_15, primals_430, primals_434, getitem_64, getitem_180, getitem_63, primals_474, getitem_181, primals_224, relu__default_59, relu__default_20, convolution_default_59, primals_128, primals_229, primals_480, primals_479, primals_228, primals_473, getitem_184, getitem_183, getitem_66, cat_default_13, getitem_67, primals_233, relu__default_60, primals_46, primals_230, primals_478, primals_475, primals_225, primals_129, primals_130, primals_234, convolution_default_21, primals_223, relu__default_21, primals_235, getitem_82, getitem_81, primals_369, relu__default_26, primals_370, getitem_84, cat_default_17, getitem_85, relu__default_27, convolution_default_27, getitem_199, getitem_217, getitem_198, getitem_216, relu__default_65, relu__default_71, convolution_default_65, convolution_default_71, getitem_202, getitem_201, getitem_220, getitem_219, relu__default_66, relu__default_72, getitem_24, getitem_100, getitem_235, getitem_99, getitem_234, getitem_283, getitem_282, relu__default_32, relu__default_77, relu__default_93, convolution_default_77, getitem_102, getitem_238, cat_default_21, getitem_237, getitem_16, primals_614, relu__default_78, cat_default_61, primals_615, primals_613, getitem_103, getitem_285, getitem_286, primals_67, primals_148, primals_71, primals_74, primals_62, primals_150, primals_73, primals_64, primals_66, primals_69, primals_72, primals_153, primals_68, primals_65, primals_63, primals_143, primals_145, convolution_default_5, primals_149, primals_70, primals_61, primals_144, getitem_309, getitem_310, relu__default_102, getitem_118, getitem_117, convolution_default_102, getitem_313, getitem_312, relu__default_38, relu__default_103, cat_default_67, getitem_121, getitem_120, relu__default_39, primals_373, primals_285, primals_290, primals_289, primals_375, primals_445, primals_438, primals_284, primals_443, primals_288, primals_444, primals_440, primals_374, primals_439, getitem_132, primals_115, getitem_133, primals_119, primals_114, primals_125, relu__default_43, getitem_253, getitem_252, convolution_default_43, primals_113, getitem_36, cat_default_7, getitem_136, primals_120, getitem_135, relu__default_83, convolution_default_11, primals_123, convolution_default_83, relu__default_11, relu__default_44, getitem_256, primals_118, getitem_255, getitem_37, convolution_default_44, primals_51, primals_50, primals_52, primals_49, relu__default_10, getitem_138, relu__default_1, relu__default_84, primals_48, primals_47, primals_124, getitem_139, getitem_7, getitem_6, primals_450, primals_519, getitem_150, getitem_151, primals_454, primals_455, relu__default_49, primals_509, primals_510, convolution_default_49, primals_453, primals_518, getitem_154, getitem_153, primals_505, primals_449, primals_514, primals_523, primals_520, primals_515, relu__default_50, primals_513, convolution_default_50, primals_508, getitem_156, getitem_157, primals_504, primals_448, relu__default_8, getitem_169, cat_default_35, getitem_27, getitem_168, getitem_28, convolution_default_8, relu__default_55, relu__default_9, convolution_default_55, getitem_31, getitem_30, getitem_172, getitem_171, convolution_default_9, relu__default_56, convolution_default_56, getitem_33, getitem_174, getitem_34, getitem_327, relu__default_88, primals_283, convolution_default_88, getitem_328, getitem_52, getitem_51, relu__default_108, getitem_271, convolution_default_108, getitem_270, primals_625, primals_618, primals_620, relu__default_16, getitem_331, primals_628, getitem_332, getitem_330, convolution_default_16, relu__default_89, getitem_273, getitem_55, convolution_default_89, primals_623, getitem_54, relu__default_109, primals_619, primals_280, getitem_274, primals_279, relu__default_17, primals_624, relu__default_90, primals_97, primals_134, getitem_187, relu__default_98, getitem_205, convolution_default_98, getitem_186, primals_139, cat_default_43, primals_100, primals_138, getitem_13, cat_default_39, primals_99, getitem_204, getitem_301, getitem_300, primals_96, relu__default_61, primals_140, convolution_default_61, relu__default_67, convolution_default_67, getitem_12, relu__default_99, getitem_190, getitem_189, convolution_default_3, getitem_208, getitem_207, primals_95, getitem_304, relu__default_62, primals_133, primals_93, relu__default_68, convolution_default_62, primals_98, convolution_default_68, primals_135, primals_94, getitem_303, getitem_223, cat_default_47, getitem_222, primals_350, relu__default_73, convolution_default_73, primals_353, getitem_226, getitem_225, relu__default_74, convolution_default_74, primals_644, primals_89, getitem_70, primals_87, getitem_69, primals_643, primals_91, relu__default_22, convolution_default_22, primals_90, primals_638, primals_86, getitem_73, getitem_72, primals_640, primals_639, relu__default_23, primals_88, primals_92, primals_645, primals_569, primals_648, getitem_241, convolution_default_2, getitem_240, primals_379, primals_564, getitem_88, getitem_9, cat_default_51, getitem_87, primals_574, primals_384, primals_259, primals_385, primals_254, primals_260, primals_503, primals_650, primals_383, primals_575, relu__default_28, primals_565, primals_500, primals_378, relu__default_79, convolution_default_28, convolution_default_79, getitem_243, primals_498, primals_499, getitem_91, primals_563, getitem_90, primals_380, primals_568, primals_570, primals_255, getitem_244, primals_578, primals_653, relu__default_29, relu__default_80, primals_258, primals_649, primals_579, convolution_default_80, primals_573, primals_598, primals_1, relu__default_33, convolution_default_33, primals_9, primals_593, primals_5, primals_103, primals_599, getitem_106, primals_104, primals_10, primals_106, getitem_105, primals_3, primals_603, primals_102, primals_6, relu__default_34, primals_604, primals_609, getitem_108, primals_595, convolution_default_34, primals_105, primals_610, primals_4, primals_8, primals_605, primals_7, getitem_109, cat_default_5, primals_12, primals_107, primals_11, relu__default_35, primals_608, primals_2, primals_101, primals_594, primals_600, getitem_316, getitem_315, relu__default_94, primals_45, convolution_default_94, primals_43, cat_default_25, relu__default_104, getitem_123, getitem_289, convolution_default_104, getitem_288, primals_40, getitem_319, getitem_318, primals_41, relu__default_95, getitem_124, primals_42, getitem_291, convolution_default_95, relu__default_105, relu__default_40, convolution_default_105, relu__default_7, primals_44, convolution_default_40, getitem_292, relu__default_96, getitem_321, getitem_322, getitem_126, primals_80, primals_544, primals_22, relu__default_4, primals_26, getitem_259, relu__default_2, primals_588, primals_82, primals_585, getitem_258, primals_549, primals_25, primals_540, cat_default_55, primals_83, primals_633, primals_590, primals_548, primals_629, primals_84, primals_583, primals_75, primals_539, primals_76, primals_580, primals_18, convolution_default_6, getitem_21, primals_79, primals_24, relu__default_85, convolution_default_85, primals_543, primals_545, primals_77, getitem_261, primals_630, primals_78, primals_550, primals_584, primals_81, getitem_262, primals_589, primals_21, primals_85, primals_635, primals_634, relu__default_86, primals_20, relu__default_6, primals_19, convolution_default_86, primals_27, getitem_22, primals_23, relu__default_45, relu__default_51, cat_default_33, getitem_141, cat_default_29, getitem_142, getitem_159, getitem_160, relu__default_46, relu__default_52, convolution_default_46, convolution_default_52, primals_339, primals_348, getitem_144, primals_174, getitem_277, primals_464, getitem_39, getitem_276, primals_245, primals_240, primals_163, cat_default_59, primals_164, primals_253, primals_344, relu__default_12, getitem_40, primals_165, convolution_default_12, primals_349, primals_168, primals_238, getitem_43, primals_343, primals_338, getitem_42, primals_160, primals_243, primals_249, primals_159, relu__default_91, primals_468, primals_158, relu__default_13, convolution_default_91, getitem_279, primals_239, primals_250, primals_170, getitem_15, primals_469, primals_169, primals_470, primals_465, primals_173, primals_155, primals_463, primals_154, primals_248, primals_345, getitem_280, primals_340, relu__default_92, convolution_default_92, primals_244]
        
