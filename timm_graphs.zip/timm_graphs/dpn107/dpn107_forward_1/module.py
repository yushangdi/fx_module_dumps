
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/dpn107/dpn107_forward_1/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3):
        mean_dim = torch.ops.aten.mean.dim(primals_3, [-1, -2], True);  primals_3 = None
        convolution_default = torch.ops.aten.convolution.default(mean_dim, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        view_default = torch.ops.aten.view.default(convolution_default, [64, 1000]);  convolution_default = None
        return [view_default, mean_dim, primals_2]
        
