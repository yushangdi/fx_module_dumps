
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/dpn107/dpn107_backward_1/state_dict.pt'))

    
    
    def forward(self, mean_dim, primals_2, tangents_1):
        view_default_1 = torch.ops.aten.view.default(tangents_1, [64, 1000, 1, 1]);  tangents_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(view_default_1, mean_dim, primals_2, [1000], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_1 = mean_dim = primals_2 = None
        getitem = convolution_backward_default[0]
        getitem_1 = convolution_backward_default[1]
        getitem_2 = convolution_backward_default[2];  convolution_backward_default = None
        expand_default = torch.ops.aten.expand.default(getitem, [64, 2688, 7, 7]);  getitem = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        return [getitem_2, getitem_1, div_scalar]
        
