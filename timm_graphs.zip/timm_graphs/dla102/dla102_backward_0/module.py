
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/dla102/dla102_backward_0/state_dict.pt'))

    
    
    def forward(self, primals_136, getitem_177, getitem_180, relu__default_93, cat_default_13, primals_145, getitem_329, getitem_173, primals_131, getitem_328, getitem_306, primals_348, getitem_305, primals_148, primals_574, primals_369, convolution_default_1, getitem_25, relu__default_50, getitem_24, convolution_default_36, primals_40, convolution_default_56, primals_121, primals_579, getitem_2, primals_480, primals_144, primals_474, getitem_1, primals_576, primals_47, primals_122, primals_479, relu__default_6, relu__default_99, primals_125, primals_361, primals_482, primals_481, relu__default_51, primals_571, cat_default_6, primals_140, primals_120, relu__default, primals_130, convolution_default_8, mean_dim, primals_139, convolution_default_33, getitem_174, primals_138, getitem_307, convolution_default_104, primals_41, primals_570, primals_49, getitem_308, primals_50, primals_137, primals_346, relu__default_30, getitem_332, primals_359, convolution_default_97, getitem_331, primals_364, primals_477, getitem_28, getitem_27, relu__default_33, primals_48, convolution_default_55, primals_473, getitem_4, relu__default_100, primals_42, getitem_310, primals_575, getitem_5, getitem_311, primals_46, primals_127, relu__default_7, primals_374, primals_366, primals_143, primals_347, primals_126, relu__default_1, primals_365, convolution_default_98, primals_371, convolution_default_9, primals_132, primals_135, primals_360, primals_370, getitem_176, primals_373, primals_478, primals_119, convolution_default_2, primals_372, primals_45, primals_569, getitem_31, getitem_55, relu__default_56, primals_538, getitem_249, getitem_30, convolution_default_29, getitem_8, getitem_212, relu__default_91, relu__default_13, primals_443, getitem_7, primals_164, convolution_default_16, primals_74, primals_150, primals_157, convolution_default_17, primals_32, primals_533, getitem_94, getitem_147, primals_158, primals_534, relu__default_8, primals_154, convolution_default_78, relu__default_75, getitem_279, primals_155, primals_449, relu__default_2, primals_31, primals_161, getitem_195, primals_163, primals_210, convolution_default_38, primals_149, primals_322, primals_30, primals_540, getitem_155, relu__default_55, primals_211, primals_445, getitem_58, getitem_57, convolution_default_52, getitem_93, cat_default_5, getitem_252, relu__default_84, primals_539, cat_default, primals_77, getitem_194, convolution_default_10, getitem_129, primals_153, primals_529, getitem_9, getitem_156, relu__default_61, getitem_278, primals_162, primals_450, getitem_10, relu__default_14, getitem_209, convolution_default_88, primals_172, getitem_146, primals_532, getitem_34, relu__default_64, primals_457, convolution_default_3, convolution_default_59, primals_156, getitem_33, getitem_210, relu__default_52, primals_209, primals_323, getitem_13, getitem_282, relu__default_26, getitem_12, relu__default_9, relu__default_49, primals_448, getitem_140, getitem_192, convolution_default_79, primals_29, convolution_default_60, getitem_121, primals_327, primals_72, primals_324, getitem_219, primals_330, getitem_60, primals_35, primals_444, relu__default_35, convolution_default_4, cat_default_1, getitem_61, primals_169, primals_329, primals_541, primals_78, getitem_164, convolution_default_89, primals_542, getitem_213, primals_453, convolution_default_80, primals_73, relu__default_15, getitem_141, primals_328, convolution_default_11, convolution_default_44, relu__default_43, primals_36, getitem_218, cat_default_8, primals_168, convolution_default_53, primals_455, primals_37, primals_454, primals_537, primals_167, primals_456, getitem_36, getitem_120, getitem_191, convolution_default_65, relu__default_76, primals_395, relu__default_40, primals_89, convolution_default_25, getitem_91, getitem_165, getitem_162, getitem_90, primals_383, cat_default_7, primals_180, getitem_186, getitem_185, primals_26, getitem_168, primals_221, getitem_258, cat_default_10, getitem_85, relu__default_45, primals_394, getitem_243, relu__default_72, primals_88, primals_390, getitem_84, primals_222, primals_262, convolution_default_50, convolution_default_76, primals_220, getitem_183, primals_24, relu__default_23, relu__default_77, getitem_303, getitem_114, primals_83, getitem_197, primals_219, primals_216, relu__default_53, primals_388, convolution_default_81, primals_181, primals_384, primals_93, convolution_default_51, getitem_302, getitem_153, getitem_242, getitem_246, convolution_default_26, getitem_115, getitem_245, primals_25, primals_182, primals_385, getitem_198, getitem_261, relu__default_57, getitem_260, primals_215, primals_263, getitem_88, getitem_182, primals_90, getitem_87, relu__default_42, relu__default_73, convolution_default_46, getitem_161, primals_80, primals_20, convolution_default_61, relu__default_78, primals_19, primals_179, primals_214, primals_18, relu__default_24, convolution_default_77, getitem_201, primals_21, getitem_158, primals_264, primals_393, primals_79, primals_84, convolution_default_49, primals_85, convolution_default_47, primals_223, convolution_default_27, relu__default_46, primals_178, getitem_167, getitem_152, convolution_default_62, getitem_257, relu__default_83, getitem_200, convolution_default_82, primals_389, getitem_159, relu__default_86, primals_204, getitem_70, convolution_default_31, getitem_111, primals_270, primals_584, relu__default_92, getitem_69, getitem_285, getitem_284, primals_332, primals_593, getitem_100, primals_269, primals_342, convolution_default_21, primals_272, primals_378, relu__default_18, relu__default_63, primals_205, primals_267, primals_594, primals_200, primals_377, primals_275, primals_585, primals_335, primals_198, getitem_112, convolution_default_90, primals_206, primals_197, primals_343, primals_379, getitem_73, relu__default_28, primals_380, primals_581, getitem_72, getitem_281, primals_588, convolution_default_42, getitem_288, convolution_default_66, getitem_287, primals_595, convolution_default_57, primals_583, relu__default_19, primals_336, primals_268, convolution_default_35, relu__default_70, relu__default_87, relu__default_32, relu__default_74, primals_331, primals_589, convolution_default_67, getitem_99, primals_337, convolution_default_22, primals_271, getitem_215, primals_590, relu__default_38, primals_277, getitem_216, primals_203, getitem_248, primals_338, primals_580, convolution_default_91, primals_582, relu__default_62, primals_199, primals_276, primals_341, getitem_75, primals_310, primals_528, relu__default_79, getitem_314, getitem_313, getitem_291, primals_192, primals_519, relu__default_66, relu__default_85, getitem_222, convolution_default_71, primals_301, getitem_225, primals_514, getitem_264, primals_185, getitem_290, getitem_263, primals_509, relu__default_88, primals_521, primals_503, getitem_240, relu__default_94, convolution_default_92, primals_304, convolution_default_54, convolution_default_99, primals_520, primals_281, primals_506, primals_522, primals_195, getitem_294, primals_523, getitem_293, convolution_default_83, getitem_317, primals_286, getitem_316, primals_282, primals_319, relu__default_67, primals_186, primals_187, getitem_227, relu__default_89, cat_default_9, getitem_267, getitem_266, primals_196, relu__default_95, relu__default_65, primals_190, primals_311, primals_305, primals_314, primals_313, convolution_default_93, getitem_224, relu__default_71, relu__default_80, primals_306, primals_504, convolution_default_100, primals_312, relu__default_44, getitem_228, getitem_239, convolution_default_48, convolution_default_70, relu__default_96, primals_515, getitem_296, primals_318, primals_527, primals_510, convolution_default_84, primals_285, primals_524, convolution_default_69, convolution_default_94, primals_511, convolution_default_75, cat_default_11, primals_191, primals_280, primals_309, getitem_221, primals_317, getitem_179, convolution_default_74, getitem_251, getitem_319, getitem_320, getitem_297, primals_505, primals_516, primals_467, convolution_default_7, primals_605, primals_618, relu__default_37, primals_95, primals_253, primals_486, primals_614, convolution_default_40, primals_610, convolution_default, getitem_40, primals_14, primals_96, convolution_default_28, getitem_126, primals_487, primals_102, primals_355, getitem_39, primals_619, primals_254, primals_630, primals_97, primals_469, primals_613, primals_632, relu__default_29, primals_472, primals_251, convolution_default_32, primals_15, primals_623, getitem_43, primals_468, getitem_42, primals_103, relu__default_25, primals_98, getitem_103, primals_611, primals_612, primals_627, primals_258, primals_596, primals_101, primals_491, primals_617, primals_498, primals_485, primals_609, getitem_106, primals_600, convolution_default_12, primals_252, primals_604, primals_356, primals_462, primals_631, primals_8, primals_463, primals_499, primals_628, getitem_45, primals_497, primals_599, primals_464, primals_606, getitem_46, primals_492, primals_601, primals_461, getitem_105, primals_248, primals_458, primals_622, primals_257, relu__default_10, primals_633, primals_247, primals_629, primals_12, primals_259, primals_246, relu__default_58, primals_13, getitem_127, primals_94, primals_490, primals_496, cat_default_3, primals_624, convolution_default_13, primals_9, primals_495, primals_500, getitem_102, convolution_default_14, primals_54, primals_439, primals_436, primals_546, primals_60, primals_112, primals_237, primals_234, primals_556, primals_432, convolution_default_101, convolution_default_102, primals_174, primals_111, getitem_49, primals_106, primals_557, getitem_48, getitem_143, primals_68, primals_232, convolution_default_73, primals_55, primals_173, getitem_150, getitem_323, relu__default_11, getitem_322, getitem_134, primals_113, primals_224, convolution_default_58, primals_107, convolution_default_41, primals_59, primals_63, primals_239, primals_64, relu__default_97, primals_177, convolution_default_72, relu__default_41, primals_66, primals_69, primals_553, primals_53, primals_552, getitem_52, primals_228, relu__default_12, primals_116, getitem_51, relu__default_69, primals_437, getitem_149, getitem_135, getitem_144, getitem_138, getitem_326, primals_65, getitem_137, getitem_230, getitem_325, primals_545, getitem_188, primals_227, relu__default_54, primals_58, getitem_234, convolution_default_15, primals_435, primals_67, primals_115, primals_229, primals_431, convolution_default_45, getitem_231, relu__default_98, primals_233, primals_548, primals_438, relu__default_39, primals_114, primals_238, primals_440, convolution_default_103, getitem_54, relu__default_68, primals_547, primals_108, convolution_default_43, primals_551, getitem_189, getitem_233, convolution_default_18, getitem_15, getitem_76, primals_566, getitem_269, relu__default_90, primals_430, primals_296, primals_397, convolution_default_37, primals_353, getitem_16, getitem_270, getitem_117, convolution_default_63, relu__default_20, getitem_96, relu__default_60, primals_290, convolution_default_23, relu__default_34, primals_1, relu__default_3, convolution_default_24, getitem_203, relu__default_81, primals_421, convolution_default_85, convolution_default_5, getitem_64, primals_561, getitem_300, primals_396, getitem_63, primals_289, primals_398, primals_401, convolution_default_30, getitem_108, getitem_118, getitem_299, primals_293, primals_287, primals_243, primals_415, getitem_97, primals_408, getitem_79, primals_422, primals_426, getitem_78, primals_294, relu__default_16, primals_352, getitem_19, getitem_273, primals_354, cat_default_4, getitem_204, getitem_18, relu__default_27, primals_420, primals_406, primals_416, primals_565, primals_4, primals_411, primals_558, relu__default_21, relu__default_31, relu__default_59, relu__default_82, convolution_default_95, relu__default_5, primals_300, relu__default_4, convolution_default_19, getitem_207, getitem_236, getitem_254, primals_241, cat_default_12, primals_299, primals_563, primals_425, getitem_255, convolution_default_96, primals_5, getitem_67, relu__default_48, primals_6, primals_414, convolution_default_6, getitem_66, primals_403, convolution_default_64, convolution_default_86, primals_402, primals_427, getitem_109, primals_295, primals_419, primals_351, primals_413, getitem_81, relu__default_36, primals_564, getitem_21, relu__default_17, cat_default_2, getitem_275, getitem_82, primals_242, convolution_default_39, convolution_default_68, primals_412, relu__default_47, getitem_206, getitem_237, primals_240, primals_407, getitem_170, getitem_272, primals_288, convolution_default_20, primals_562, getitem_22, getitem_276, relu__default_22, getitem_123, getitem_124, getitem_171, convolution_default_34, convolution_default_87, tangents_1):
        view_default_1 = torch.ops.aten.view.default(tangents_1, [128, 1000, 1, 1]);  tangents_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(view_default_1, mean_dim, primals_8, [1000], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_1 = mean_dim = primals_8 = None
        getitem_333 = convolution_backward_default[0]
        getitem_334 = convolution_backward_default[1]
        getitem_335 = convolution_backward_default[2];  convolution_backward_default = None
        expand_default = torch.ops.aten.expand.default(getitem_333, [128, 1024, 7, 7]);  getitem_333 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_100, torch.float32);  relu__default_100 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_105, to_dtype);  le_scalar = new_zeros_default_105 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_104, primals_595, primals_593, primals_594, getitem_331, getitem_332, True, 1e-05, [True, True, True]);  convolution_default_104 = primals_595 = primals_593 = primals_594 = getitem_331 = getitem_332 = None
        getitem_336 = native_batch_norm_backward_default[0]
        getitem_337 = native_batch_norm_backward_default[1]
        getitem_338 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_336, cat_default_13, primals_596, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_336 = cat_default_13 = primals_596 = None
        getitem_339 = convolution_backward_default_1[0]
        getitem_340 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        slice_tensor = torch.ops.aten.slice.Tensor(getitem_339, 1, 0, 1024)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(getitem_339, 1, 1024, 2048)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(getitem_339, 1, 2048, 2560);  getitem_339 = None
        add_tensor = torch.ops.aten.add.Tensor(to_dtype_2, slice_tensor);  to_dtype_2 = slice_tensor = None
        to_dtype_3 = torch.ops.aten.to.dtype(add_tensor, torch.float32);  add_tensor = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_106, to_dtype_3);  le_scalar_1 = new_zeros_default_106 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        add_tensor_1 = torch.ops.aten.add.Tensor(slice_tensor_1, to_dtype_5);  slice_tensor_1 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_103, primals_629, primals_627, primals_628, getitem_328, getitem_329, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_103 = primals_629 = primals_627 = primals_628 = getitem_328 = getitem_329 = None
        getitem_342 = native_batch_norm_backward_default_1[0]
        getitem_343 = native_batch_norm_backward_default_1[1]
        getitem_344 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_342, relu__default_98, primals_632, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_342 = primals_632 = None
        getitem_345 = convolution_backward_default_2[0]
        getitem_346 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_345, torch.float32);  getitem_345 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_107, to_dtype_6);  le_scalar_2 = new_zeros_default_107 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_102, primals_624, primals_622, primals_623, getitem_325, getitem_326, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_102 = primals_624 = primals_622 = primals_623 = getitem_325 = getitem_326 = None
        getitem_348 = native_batch_norm_backward_default_2[0]
        getitem_349 = native_batch_norm_backward_default_2[1]
        getitem_350 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_348, relu__default_97, primals_631, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_348 = primals_631 = None
        getitem_351 = convolution_backward_default_3[0]
        getitem_352 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_351, torch.float32);  getitem_351 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_108, to_dtype_9);  le_scalar_3 = new_zeros_default_108 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_101, primals_619, primals_617, primals_618, getitem_322, getitem_323, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_101 = primals_619 = primals_617 = primals_618 = getitem_322 = getitem_323 = None
        getitem_354 = native_batch_norm_backward_default_3[0]
        getitem_355 = native_batch_norm_backward_default_3[1]
        getitem_356 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_354, relu__default_96, primals_630, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_354 = primals_630 = None
        getitem_357 = convolution_backward_default_4[0]
        getitem_358 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        add_tensor_2 = torch.ops.aten.add.Tensor(add_tensor_1, getitem_357);  add_tensor_1 = getitem_357 = None
        to_dtype_12 = torch.ops.aten.to.dtype(add_tensor_2, torch.float32);  add_tensor_2 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_109 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_109, to_dtype_12);  le_scalar_4 = new_zeros_default_109 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_100, primals_611, primals_609, primals_610, getitem_319, getitem_320, True, 1e-05, [True, True, True]);  convolution_default_100 = primals_611 = primals_609 = primals_610 = getitem_319 = getitem_320 = None
        getitem_360 = native_batch_norm_backward_default_4[0]
        getitem_361 = native_batch_norm_backward_default_4[1]
        getitem_362 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_360, relu__default_95, primals_614, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_360 = primals_614 = None
        getitem_363 = convolution_backward_default_5[0]
        getitem_364 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_363, torch.float32);  getitem_363 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_110 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_110, to_dtype_15);  le_scalar_5 = new_zeros_default_110 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_99, primals_606, primals_604, primals_605, getitem_316, getitem_317, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_99 = primals_606 = primals_604 = primals_605 = getitem_316 = getitem_317 = None
        getitem_366 = native_batch_norm_backward_default_5[0]
        getitem_367 = native_batch_norm_backward_default_5[1]
        getitem_368 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_366, relu__default_94, primals_613, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_366 = primals_613 = None
        getitem_369 = convolution_backward_default_6[0]
        getitem_370 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_369, torch.float32);  getitem_369 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_111 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_111, to_dtype_18);  le_scalar_6 = new_zeros_default_111 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_98, primals_601, primals_599, primals_600, getitem_313, getitem_314, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_98 = primals_601 = primals_599 = primals_600 = getitem_313 = getitem_314 = None
        getitem_372 = native_batch_norm_backward_default_6[0]
        getitem_373 = native_batch_norm_backward_default_6[1]
        getitem_374 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_372, relu__default_93, primals_612, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_372 = primals_612 = None
        getitem_375 = convolution_backward_default_7[0]
        getitem_376 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_97, primals_590, primals_588, primals_589, getitem_310, getitem_311, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_97 = primals_590 = primals_588 = primals_589 = getitem_310 = getitem_311 = None
        getitem_378 = native_batch_norm_backward_default_7[0]
        getitem_379 = native_batch_norm_backward_default_7[1]
        getitem_380 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_378, getitem_307, primals_585, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_378 = getitem_307 = primals_585 = None
        getitem_381 = convolution_backward_default_8[0]
        getitem_382 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        add_tensor_3 = torch.ops.aten.add.Tensor(slice_tensor_2, getitem_381);  slice_tensor_2 = getitem_381 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(add_tensor_3, relu__default_93, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_308);  add_tensor_3 = getitem_308 = None
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_375, max_pool2d_with_indices_backward_default);  getitem_375 = max_pool2d_with_indices_backward_default = None
        to_dtype_21 = torch.ops.aten.to.dtype(add_tensor_4, torch.float32);  add_tensor_4 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_112 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_112, to_dtype_21);  le_scalar_7 = new_zeros_default_112 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_96, primals_547, primals_545, primals_546, getitem_305, getitem_306, True, 1e-05, [True, True, True]);  convolution_default_96 = primals_547 = primals_545 = primals_546 = getitem_305 = getitem_306 = None
        getitem_384 = native_batch_norm_backward_default_8[0]
        getitem_385 = native_batch_norm_backward_default_8[1]
        getitem_386 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_384, cat_default_12, primals_548, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_384 = cat_default_12 = primals_548 = None
        getitem_387 = convolution_backward_default_9[0]
        getitem_388 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        slice_tensor_3 = torch.ops.aten.slice.Tensor(getitem_387, 1, 0, 512)
        slice_tensor_4 = torch.ops.aten.slice.Tensor(getitem_387, 1, 512, 1024)
        slice_tensor_5 = torch.ops.aten.slice.Tensor(getitem_387, 1, 1024, 1280)
        slice_tensor_6 = torch.ops.aten.slice.Tensor(getitem_387, 1, 1280, 1792)
        slice_tensor_7 = torch.ops.aten.slice.Tensor(getitem_387, 1, 1792, 2304)
        slice_tensor_8 = torch.ops.aten.slice.Tensor(getitem_387, 1, 2304, 2816);  getitem_387 = None
        add_tensor_5 = torch.ops.aten.add.Tensor(to_dtype_23, slice_tensor_3);  to_dtype_23 = slice_tensor_3 = None
        to_dtype_24 = torch.ops.aten.to.dtype(add_tensor_5, torch.float32);  add_tensor_5 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_113 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_113, to_dtype_24);  le_scalar_8 = new_zeros_default_113 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        add_tensor_6 = torch.ops.aten.add.Tensor(slice_tensor_4, to_dtype_26);  slice_tensor_4 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_95, primals_581, primals_579, primals_580, getitem_302, getitem_303, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_95 = primals_581 = primals_579 = primals_580 = getitem_302 = getitem_303 = None
        getitem_390 = native_batch_norm_backward_default_9[0]
        getitem_391 = native_batch_norm_backward_default_9[1]
        getitem_392 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_390, relu__default_91, primals_584, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_390 = primals_584 = None
        getitem_393 = convolution_backward_default_10[0]
        getitem_394 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_393, torch.float32);  getitem_393 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_114 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_114, to_dtype_27);  le_scalar_9 = new_zeros_default_114 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_94, primals_576, primals_574, primals_575, getitem_299, getitem_300, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_94 = primals_576 = primals_574 = primals_575 = getitem_299 = getitem_300 = None
        getitem_396 = native_batch_norm_backward_default_10[0]
        getitem_397 = native_batch_norm_backward_default_10[1]
        getitem_398 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_396, relu__default_90, primals_583, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_396 = primals_583 = None
        getitem_399 = convolution_backward_default_11[0]
        getitem_400 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_399, torch.float32);  getitem_399 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_115 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_115, to_dtype_30);  le_scalar_10 = new_zeros_default_115 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_93, primals_571, primals_569, primals_570, getitem_296, getitem_297, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_93 = primals_571 = primals_569 = primals_570 = getitem_296 = getitem_297 = None
        getitem_402 = native_batch_norm_backward_default_11[0]
        getitem_403 = native_batch_norm_backward_default_11[1]
        getitem_404 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_402, relu__default_89, primals_582, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_402 = primals_582 = None
        getitem_405 = convolution_backward_default_12[0]
        getitem_406 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        add_tensor_7 = torch.ops.aten.add.Tensor(add_tensor_6, getitem_405);  add_tensor_6 = getitem_405 = None
        to_dtype_33 = torch.ops.aten.to.dtype(add_tensor_7, torch.float32);  add_tensor_7 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_116 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_116, to_dtype_33);  le_scalar_11 = new_zeros_default_116 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        add_tensor_8 = torch.ops.aten.add.Tensor(slice_tensor_8, to_dtype_35);  slice_tensor_8 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_92, primals_563, primals_561, primals_562, getitem_293, getitem_294, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_92 = primals_563 = primals_561 = primals_562 = getitem_293 = getitem_294 = None
        getitem_408 = native_batch_norm_backward_default_12[0]
        getitem_409 = native_batch_norm_backward_default_12[1]
        getitem_410 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_408, relu__default_88, primals_566, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_408 = primals_566 = None
        getitem_411 = convolution_backward_default_13[0]
        getitem_412 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_411, torch.float32);  getitem_411 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_117 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_117, to_dtype_36);  le_scalar_12 = new_zeros_default_117 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_91, primals_558, primals_556, primals_557, getitem_290, getitem_291, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_91 = primals_558 = primals_556 = primals_557 = getitem_290 = getitem_291 = None
        getitem_414 = native_batch_norm_backward_default_13[0]
        getitem_415 = native_batch_norm_backward_default_13[1]
        getitem_416 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_414, relu__default_87, primals_565, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_414 = primals_565 = None
        getitem_417 = convolution_backward_default_14[0]
        getitem_418 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_417, torch.float32);  getitem_417 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_118 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_118, to_dtype_39);  le_scalar_13 = new_zeros_default_118 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_90, primals_553, primals_551, primals_552, getitem_287, getitem_288, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_90 = primals_553 = primals_551 = primals_552 = getitem_287 = getitem_288 = None
        getitem_420 = native_batch_norm_backward_default_14[0]
        getitem_421 = native_batch_norm_backward_default_14[1]
        getitem_422 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_420, relu__default_86, primals_564, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_420 = primals_564 = None
        getitem_423 = convolution_backward_default_15[0]
        getitem_424 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        add_tensor_9 = torch.ops.aten.add.Tensor(add_tensor_8, getitem_423);  add_tensor_8 = getitem_423 = None
        to_dtype_42 = torch.ops.aten.to.dtype(add_tensor_9, torch.float32);  add_tensor_9 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_119 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_119, to_dtype_42);  le_scalar_14 = new_zeros_default_119 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_89, primals_505, primals_503, primals_504, getitem_284, getitem_285, True, 1e-05, [True, True, True]);  convolution_default_89 = primals_505 = primals_503 = primals_504 = getitem_284 = getitem_285 = None
        getitem_426 = native_batch_norm_backward_default_15[0]
        getitem_427 = native_batch_norm_backward_default_15[1]
        getitem_428 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_426, cat_default_11, primals_506, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_426 = cat_default_11 = primals_506 = None
        getitem_429 = convolution_backward_default_16[0]
        getitem_430 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        slice_tensor_9 = torch.ops.aten.slice.Tensor(getitem_429, 1, 0, 512)
        slice_tensor_10 = torch.ops.aten.slice.Tensor(getitem_429, 1, 512, 1024);  getitem_429 = None
        add_tensor_10 = torch.ops.aten.add.Tensor(to_dtype_44, slice_tensor_9);  to_dtype_44 = slice_tensor_9 = None
        to_dtype_45 = torch.ops.aten.to.dtype(add_tensor_10, torch.float32);  add_tensor_10 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_120 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_120, to_dtype_45);  le_scalar_15 = new_zeros_default_120 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        add_tensor_11 = torch.ops.aten.add.Tensor(slice_tensor_10, to_dtype_47);  slice_tensor_10 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_88, primals_539, primals_537, primals_538, getitem_281, getitem_282, True, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_88 = primals_539 = primals_537 = primals_538 = getitem_281 = getitem_282 = None
        getitem_432 = native_batch_norm_backward_default_16[0]
        getitem_433 = native_batch_norm_backward_default_16[1]
        getitem_434 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_432, relu__default_84, primals_542, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_432 = primals_542 = None
        getitem_435 = convolution_backward_default_17[0]
        getitem_436 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_435, torch.float32);  getitem_435 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_121 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_121, to_dtype_48);  le_scalar_16 = new_zeros_default_121 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_87, primals_534, primals_532, primals_533, getitem_278, getitem_279, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_87 = primals_534 = primals_532 = primals_533 = getitem_278 = getitem_279 = None
        getitem_438 = native_batch_norm_backward_default_17[0]
        getitem_439 = native_batch_norm_backward_default_17[1]
        getitem_440 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_438, relu__default_83, primals_541, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_438 = primals_541 = None
        getitem_441 = convolution_backward_default_18[0]
        getitem_442 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_441, torch.float32);  getitem_441 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_122 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_122, to_dtype_51);  le_scalar_17 = new_zeros_default_122 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_86, primals_529, primals_527, primals_528, getitem_275, getitem_276, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_86 = primals_529 = primals_527 = primals_528 = getitem_275 = getitem_276 = None
        getitem_444 = native_batch_norm_backward_default_18[0]
        getitem_445 = native_batch_norm_backward_default_18[1]
        getitem_446 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_444, relu__default_82, primals_540, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_444 = primals_540 = None
        getitem_447 = convolution_backward_default_19[0]
        getitem_448 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        add_tensor_12 = torch.ops.aten.add.Tensor(add_tensor_11, getitem_447);  add_tensor_11 = getitem_447 = None
        to_dtype_54 = torch.ops.aten.to.dtype(add_tensor_12, torch.float32);  add_tensor_12 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_123 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_123, to_dtype_54);  le_scalar_18 = new_zeros_default_123 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        add_tensor_13 = torch.ops.aten.add.Tensor(slice_tensor_7, to_dtype_56);  slice_tensor_7 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_85, primals_521, primals_519, primals_520, getitem_272, getitem_273, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_85 = primals_521 = primals_519 = primals_520 = getitem_272 = getitem_273 = None
        getitem_450 = native_batch_norm_backward_default_19[0]
        getitem_451 = native_batch_norm_backward_default_19[1]
        getitem_452 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_450, relu__default_81, primals_524, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_450 = primals_524 = None
        getitem_453 = convolution_backward_default_20[0]
        getitem_454 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_453, torch.float32);  getitem_453 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_124 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_124, to_dtype_57);  le_scalar_19 = new_zeros_default_124 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_84, primals_516, primals_514, primals_515, getitem_269, getitem_270, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_84 = primals_516 = primals_514 = primals_515 = getitem_269 = getitem_270 = None
        getitem_456 = native_batch_norm_backward_default_20[0]
        getitem_457 = native_batch_norm_backward_default_20[1]
        getitem_458 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_456, relu__default_80, primals_523, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_456 = primals_523 = None
        getitem_459 = convolution_backward_default_21[0]
        getitem_460 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_459, torch.float32);  getitem_459 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_125 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_125, to_dtype_60);  le_scalar_20 = new_zeros_default_125 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_83, primals_511, primals_509, primals_510, getitem_266, getitem_267, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_83 = primals_511 = primals_509 = primals_510 = getitem_266 = getitem_267 = None
        getitem_462 = native_batch_norm_backward_default_21[0]
        getitem_463 = native_batch_norm_backward_default_21[1]
        getitem_464 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_462, relu__default_79, primals_522, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_462 = primals_522 = None
        getitem_465 = convolution_backward_default_22[0]
        getitem_466 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        add_tensor_14 = torch.ops.aten.add.Tensor(add_tensor_13, getitem_465);  add_tensor_13 = getitem_465 = None
        to_dtype_63 = torch.ops.aten.to.dtype(add_tensor_14, torch.float32);  add_tensor_14 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_126 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_126, to_dtype_63);  le_scalar_21 = new_zeros_default_126 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_82, primals_463, primals_461, primals_462, getitem_263, getitem_264, True, 1e-05, [True, True, True]);  convolution_default_82 = primals_463 = primals_461 = primals_462 = getitem_263 = getitem_264 = None
        getitem_468 = native_batch_norm_backward_default_22[0]
        getitem_469 = native_batch_norm_backward_default_22[1]
        getitem_470 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_468, cat_default_10, primals_464, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_468 = cat_default_10 = primals_464 = None
        getitem_471 = convolution_backward_default_23[0]
        getitem_472 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        slice_tensor_11 = torch.ops.aten.slice.Tensor(getitem_471, 1, 0, 512)
        slice_tensor_12 = torch.ops.aten.slice.Tensor(getitem_471, 1, 512, 1024)
        slice_tensor_13 = torch.ops.aten.slice.Tensor(getitem_471, 1, 1024, 1536);  getitem_471 = None
        add_tensor_15 = torch.ops.aten.add.Tensor(to_dtype_65, slice_tensor_11);  to_dtype_65 = slice_tensor_11 = None
        to_dtype_66 = torch.ops.aten.to.dtype(add_tensor_15, torch.float32);  add_tensor_15 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_127 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_127, to_dtype_66);  le_scalar_22 = new_zeros_default_127 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        add_tensor_16 = torch.ops.aten.add.Tensor(slice_tensor_12, to_dtype_68);  slice_tensor_12 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_81, primals_497, primals_495, primals_496, getitem_260, getitem_261, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_81 = primals_497 = primals_495 = primals_496 = getitem_260 = getitem_261 = None
        getitem_474 = native_batch_norm_backward_default_23[0]
        getitem_475 = native_batch_norm_backward_default_23[1]
        getitem_476 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_474, relu__default_77, primals_500, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_474 = primals_500 = None
        getitem_477 = convolution_backward_default_24[0]
        getitem_478 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_477, torch.float32);  getitem_477 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_128 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_128, to_dtype_69);  le_scalar_23 = new_zeros_default_128 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_80, primals_492, primals_490, primals_491, getitem_257, getitem_258, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_80 = primals_492 = primals_490 = primals_491 = getitem_257 = getitem_258 = None
        getitem_480 = native_batch_norm_backward_default_24[0]
        getitem_481 = native_batch_norm_backward_default_24[1]
        getitem_482 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_480, relu__default_76, primals_499, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_480 = primals_499 = None
        getitem_483 = convolution_backward_default_25[0]
        getitem_484 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_483, torch.float32);  getitem_483 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_129 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_129, to_dtype_72);  le_scalar_24 = new_zeros_default_129 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_79, primals_487, primals_485, primals_486, getitem_254, getitem_255, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_79 = primals_487 = primals_485 = primals_486 = getitem_254 = getitem_255 = None
        getitem_486 = native_batch_norm_backward_default_25[0]
        getitem_487 = native_batch_norm_backward_default_25[1]
        getitem_488 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_486, relu__default_75, primals_498, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_486 = primals_498 = None
        getitem_489 = convolution_backward_default_26[0]
        getitem_490 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        add_tensor_17 = torch.ops.aten.add.Tensor(add_tensor_16, getitem_489);  add_tensor_16 = getitem_489 = None
        to_dtype_75 = torch.ops.aten.to.dtype(add_tensor_17, torch.float32);  add_tensor_17 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_130 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_130, to_dtype_75);  le_scalar_25 = new_zeros_default_130 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        add_tensor_18 = torch.ops.aten.add.Tensor(slice_tensor_13, to_dtype_77);  slice_tensor_13 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_78, primals_479, primals_477, primals_478, getitem_251, getitem_252, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_78 = primals_479 = primals_477 = primals_478 = getitem_251 = getitem_252 = None
        getitem_492 = native_batch_norm_backward_default_26[0]
        getitem_493 = native_batch_norm_backward_default_26[1]
        getitem_494 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_492, relu__default_74, primals_482, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_492 = primals_482 = None
        getitem_495 = convolution_backward_default_27[0]
        getitem_496 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_495, torch.float32);  getitem_495 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_131 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_131, to_dtype_78);  le_scalar_26 = new_zeros_default_131 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_77, primals_474, primals_472, primals_473, getitem_248, getitem_249, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_77 = primals_474 = primals_472 = primals_473 = getitem_248 = getitem_249 = None
        getitem_498 = native_batch_norm_backward_default_27[0]
        getitem_499 = native_batch_norm_backward_default_27[1]
        getitem_500 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_498, relu__default_73, primals_481, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_498 = primals_481 = None
        getitem_501 = convolution_backward_default_28[0]
        getitem_502 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_501, torch.float32);  getitem_501 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_132 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_132, to_dtype_81);  le_scalar_27 = new_zeros_default_132 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_76, primals_469, primals_467, primals_468, getitem_245, getitem_246, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_76 = primals_469 = primals_467 = primals_468 = getitem_245 = getitem_246 = None
        getitem_504 = native_batch_norm_backward_default_28[0]
        getitem_505 = native_batch_norm_backward_default_28[1]
        getitem_506 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_504, relu__default_72, primals_480, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_504 = primals_480 = None
        getitem_507 = convolution_backward_default_29[0]
        getitem_508 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        add_tensor_19 = torch.ops.aten.add.Tensor(add_tensor_18, getitem_507);  add_tensor_18 = getitem_507 = None
        to_dtype_84 = torch.ops.aten.to.dtype(add_tensor_19, torch.float32);  add_tensor_19 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_133 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_133, to_dtype_84);  le_scalar_28 = new_zeros_default_133 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_75, primals_421, primals_419, primals_420, getitem_242, getitem_243, True, 1e-05, [True, True, True]);  convolution_default_75 = primals_421 = primals_419 = primals_420 = getitem_242 = getitem_243 = None
        getitem_510 = native_batch_norm_backward_default_29[0]
        getitem_511 = native_batch_norm_backward_default_29[1]
        getitem_512 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_510, cat_default_9, primals_422, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_510 = cat_default_9 = primals_422 = None
        getitem_513 = convolution_backward_default_30[0]
        getitem_514 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        slice_tensor_14 = torch.ops.aten.slice.Tensor(getitem_513, 1, 0, 512)
        slice_tensor_15 = torch.ops.aten.slice.Tensor(getitem_513, 1, 512, 1024);  getitem_513 = None
        add_tensor_20 = torch.ops.aten.add.Tensor(to_dtype_86, slice_tensor_14);  to_dtype_86 = slice_tensor_14 = None
        to_dtype_87 = torch.ops.aten.to.dtype(add_tensor_20, torch.float32);  add_tensor_20 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_134 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_134, to_dtype_87);  le_scalar_29 = new_zeros_default_134 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        add_tensor_21 = torch.ops.aten.add.Tensor(slice_tensor_15, to_dtype_89);  slice_tensor_15 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_74, primals_455, primals_453, primals_454, getitem_239, getitem_240, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_74 = primals_455 = primals_453 = primals_454 = getitem_239 = getitem_240 = None
        getitem_516 = native_batch_norm_backward_default_30[0]
        getitem_517 = native_batch_norm_backward_default_30[1]
        getitem_518 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_516, relu__default_70, primals_458, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_516 = primals_458 = None
        getitem_519 = convolution_backward_default_31[0]
        getitem_520 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_519, torch.float32);  getitem_519 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_135 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_135, to_dtype_90);  le_scalar_30 = new_zeros_default_135 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_73, primals_450, primals_448, primals_449, getitem_236, getitem_237, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_73 = primals_450 = primals_448 = primals_449 = getitem_236 = getitem_237 = None
        getitem_522 = native_batch_norm_backward_default_31[0]
        getitem_523 = native_batch_norm_backward_default_31[1]
        getitem_524 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_522, relu__default_69, primals_457, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_522 = primals_457 = None
        getitem_525 = convolution_backward_default_32[0]
        getitem_526 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_525, torch.float32);  getitem_525 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_136 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_136, to_dtype_93);  le_scalar_31 = new_zeros_default_136 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_72, primals_445, primals_443, primals_444, getitem_233, getitem_234, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_72 = primals_445 = primals_443 = primals_444 = getitem_233 = getitem_234 = None
        getitem_528 = native_batch_norm_backward_default_32[0]
        getitem_529 = native_batch_norm_backward_default_32[1]
        getitem_530 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_528, relu__default_68, primals_456, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_528 = primals_456 = None
        getitem_531 = convolution_backward_default_33[0]
        getitem_532 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        add_tensor_22 = torch.ops.aten.add.Tensor(add_tensor_21, getitem_531);  add_tensor_21 = getitem_531 = None
        to_dtype_96 = torch.ops.aten.to.dtype(add_tensor_22, torch.float32);  add_tensor_22 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_137 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_137, to_dtype_96);  le_scalar_32 = new_zeros_default_137 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        add_tensor_23 = torch.ops.aten.add.Tensor(slice_tensor_6, to_dtype_98);  slice_tensor_6 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_71, primals_437, primals_435, primals_436, getitem_230, getitem_231, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_71 = primals_437 = primals_435 = primals_436 = getitem_230 = getitem_231 = None
        getitem_534 = native_batch_norm_backward_default_33[0]
        getitem_535 = native_batch_norm_backward_default_33[1]
        getitem_536 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_534, relu__default_67, primals_440, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_534 = primals_440 = None
        getitem_537 = convolution_backward_default_34[0]
        getitem_538 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_537, torch.float32);  getitem_537 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_138 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_138, to_dtype_99);  le_scalar_33 = new_zeros_default_138 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_70, primals_432, primals_430, primals_431, getitem_227, getitem_228, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_70 = primals_432 = primals_430 = primals_431 = getitem_227 = getitem_228 = None
        getitem_540 = native_batch_norm_backward_default_34[0]
        getitem_541 = native_batch_norm_backward_default_34[1]
        getitem_542 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_540, relu__default_66, primals_439, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_540 = primals_439 = None
        getitem_543 = convolution_backward_default_35[0]
        getitem_544 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_543, torch.float32);  getitem_543 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_139 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_139, to_dtype_102);  le_scalar_34 = new_zeros_default_139 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_69, primals_427, primals_425, primals_426, getitem_224, getitem_225, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_69 = primals_427 = primals_425 = primals_426 = getitem_224 = getitem_225 = None
        getitem_546 = native_batch_norm_backward_default_35[0]
        getitem_547 = native_batch_norm_backward_default_35[1]
        getitem_548 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_546, relu__default_65, primals_438, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_546 = primals_438 = None
        getitem_549 = convolution_backward_default_36[0]
        getitem_550 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        add_tensor_24 = torch.ops.aten.add.Tensor(add_tensor_23, getitem_549);  add_tensor_23 = getitem_549 = None
        to_dtype_105 = torch.ops.aten.to.dtype(add_tensor_24, torch.float32);  add_tensor_24 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_140 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_140, to_dtype_105);  le_scalar_35 = new_zeros_default_140 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_68, primals_379, primals_377, primals_378, getitem_221, getitem_222, True, 1e-05, [True, True, True]);  convolution_default_68 = primals_379 = primals_377 = primals_378 = getitem_221 = getitem_222 = None
        getitem_552 = native_batch_norm_backward_default_36[0]
        getitem_553 = native_batch_norm_backward_default_36[1]
        getitem_554 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_552, cat_default_8, primals_380, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_552 = cat_default_8 = primals_380 = None
        getitem_555 = convolution_backward_default_37[0]
        getitem_556 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        slice_tensor_16 = torch.ops.aten.slice.Tensor(getitem_555, 1, 0, 512)
        slice_tensor_17 = torch.ops.aten.slice.Tensor(getitem_555, 1, 512, 1024)
        slice_tensor_18 = torch.ops.aten.slice.Tensor(getitem_555, 1, 1024, 1536)
        slice_tensor_19 = torch.ops.aten.slice.Tensor(getitem_555, 1, 1536, 2048);  getitem_555 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(to_dtype_107, slice_tensor_16);  to_dtype_107 = slice_tensor_16 = None
        to_dtype_108 = torch.ops.aten.to.dtype(add_tensor_25, torch.float32);  add_tensor_25 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_141 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_141, to_dtype_108);  le_scalar_36 = new_zeros_default_141 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(slice_tensor_17, to_dtype_110);  slice_tensor_17 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_67, primals_413, primals_411, primals_412, getitem_218, getitem_219, True, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_67 = primals_413 = primals_411 = primals_412 = getitem_218 = getitem_219 = None
        getitem_558 = native_batch_norm_backward_default_37[0]
        getitem_559 = native_batch_norm_backward_default_37[1]
        getitem_560 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_558, relu__default_63, primals_416, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_558 = primals_416 = None
        getitem_561 = convolution_backward_default_38[0]
        getitem_562 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_561, torch.float32);  getitem_561 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_142 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_142, to_dtype_111);  le_scalar_37 = new_zeros_default_142 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_66, primals_408, primals_406, primals_407, getitem_215, getitem_216, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_66 = primals_408 = primals_406 = primals_407 = getitem_215 = getitem_216 = None
        getitem_564 = native_batch_norm_backward_default_38[0]
        getitem_565 = native_batch_norm_backward_default_38[1]
        getitem_566 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_564, relu__default_62, primals_415, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_564 = primals_415 = None
        getitem_567 = convolution_backward_default_39[0]
        getitem_568 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_567, torch.float32);  getitem_567 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_143 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_143, to_dtype_114);  le_scalar_38 = new_zeros_default_143 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_65, primals_403, primals_401, primals_402, getitem_212, getitem_213, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_65 = primals_403 = primals_401 = primals_402 = getitem_212 = getitem_213 = None
        getitem_570 = native_batch_norm_backward_default_39[0]
        getitem_571 = native_batch_norm_backward_default_39[1]
        getitem_572 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_570, relu__default_61, primals_414, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_570 = primals_414 = None
        getitem_573 = convolution_backward_default_40[0]
        getitem_574 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(add_tensor_26, getitem_573);  add_tensor_26 = getitem_573 = None
        to_dtype_117 = torch.ops.aten.to.dtype(add_tensor_27, torch.float32);  add_tensor_27 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_144 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_144, to_dtype_117);  le_scalar_39 = new_zeros_default_144 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(slice_tensor_19, to_dtype_119);  slice_tensor_19 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_64, primals_395, primals_393, primals_394, getitem_209, getitem_210, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_64 = primals_395 = primals_393 = primals_394 = getitem_209 = getitem_210 = None
        getitem_576 = native_batch_norm_backward_default_40[0]
        getitem_577 = native_batch_norm_backward_default_40[1]
        getitem_578 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_576, relu__default_60, primals_398, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_576 = primals_398 = None
        getitem_579 = convolution_backward_default_41[0]
        getitem_580 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_579, torch.float32);  getitem_579 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_145 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_145, to_dtype_120);  le_scalar_40 = new_zeros_default_145 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_63, primals_390, primals_388, primals_389, getitem_206, getitem_207, True, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_63 = primals_390 = primals_388 = primals_389 = getitem_206 = getitem_207 = None
        getitem_582 = native_batch_norm_backward_default_41[0]
        getitem_583 = native_batch_norm_backward_default_41[1]
        getitem_584 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_582, relu__default_59, primals_397, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_582 = primals_397 = None
        getitem_585 = convolution_backward_default_42[0]
        getitem_586 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_585, torch.float32);  getitem_585 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_146 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_146, to_dtype_123);  le_scalar_41 = new_zeros_default_146 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_62, primals_385, primals_383, primals_384, getitem_203, getitem_204, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_62 = primals_385 = primals_383 = primals_384 = getitem_203 = getitem_204 = None
        getitem_588 = native_batch_norm_backward_default_42[0]
        getitem_589 = native_batch_norm_backward_default_42[1]
        getitem_590 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_588, relu__default_58, primals_396, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_588 = primals_396 = None
        getitem_591 = convolution_backward_default_43[0]
        getitem_592 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(add_tensor_28, getitem_591);  add_tensor_28 = getitem_591 = None
        to_dtype_126 = torch.ops.aten.to.dtype(add_tensor_29, torch.float32);  add_tensor_29 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_147 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_147, to_dtype_126);  le_scalar_42 = new_zeros_default_147 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_61, primals_337, primals_335, primals_336, getitem_200, getitem_201, True, 1e-05, [True, True, True]);  convolution_default_61 = primals_337 = primals_335 = primals_336 = getitem_200 = getitem_201 = None
        getitem_594 = native_batch_norm_backward_default_43[0]
        getitem_595 = native_batch_norm_backward_default_43[1]
        getitem_596 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_594, cat_default_7, primals_338, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_594 = cat_default_7 = primals_338 = None
        getitem_597 = convolution_backward_default_44[0]
        getitem_598 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        slice_tensor_20 = torch.ops.aten.slice.Tensor(getitem_597, 1, 0, 512)
        slice_tensor_21 = torch.ops.aten.slice.Tensor(getitem_597, 1, 512, 1024);  getitem_597 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(to_dtype_128, slice_tensor_20);  to_dtype_128 = slice_tensor_20 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_30, torch.float32);  add_tensor_30 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_148 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_148, to_dtype_129);  le_scalar_43 = new_zeros_default_148 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(slice_tensor_21, to_dtype_131);  slice_tensor_21 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default_60, primals_371, primals_369, primals_370, getitem_197, getitem_198, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default_60 = primals_371 = primals_369 = primals_370 = getitem_197 = getitem_198 = None
        getitem_600 = native_batch_norm_backward_default_44[0]
        getitem_601 = native_batch_norm_backward_default_44[1]
        getitem_602 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_600, relu__default_56, primals_374, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_600 = primals_374 = None
        getitem_603 = convolution_backward_default_45[0]
        getitem_604 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_603, torch.float32);  getitem_603 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_149 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_149, to_dtype_132);  le_scalar_44 = new_zeros_default_149 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_134, convolution_default_59, primals_366, primals_364, primals_365, getitem_194, getitem_195, True, 1e-05, [True, True, True]);  to_dtype_134 = convolution_default_59 = primals_366 = primals_364 = primals_365 = getitem_194 = getitem_195 = None
        getitem_606 = native_batch_norm_backward_default_45[0]
        getitem_607 = native_batch_norm_backward_default_45[1]
        getitem_608 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_606, relu__default_55, primals_373, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_606 = primals_373 = None
        getitem_609 = convolution_backward_default_46[0]
        getitem_610 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_609, torch.float32);  getitem_609 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_150 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_150, to_dtype_135);  le_scalar_45 = new_zeros_default_150 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_137, convolution_default_58, primals_361, primals_359, primals_360, getitem_191, getitem_192, True, 1e-05, [True, True, True]);  to_dtype_137 = convolution_default_58 = primals_361 = primals_359 = primals_360 = getitem_191 = getitem_192 = None
        getitem_612 = native_batch_norm_backward_default_46[0]
        getitem_613 = native_batch_norm_backward_default_46[1]
        getitem_614 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_612, relu__default_54, primals_372, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_612 = primals_372 = None
        getitem_615 = convolution_backward_default_47[0]
        getitem_616 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(add_tensor_31, getitem_615);  add_tensor_31 = getitem_615 = None
        to_dtype_138 = torch.ops.aten.to.dtype(add_tensor_32, torch.float32);  add_tensor_32 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_151 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_151, to_dtype_138);  le_scalar_46 = new_zeros_default_151 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(slice_tensor_18, to_dtype_140);  slice_tensor_18 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_140, convolution_default_57, primals_353, primals_351, primals_352, getitem_188, getitem_189, True, 1e-05, [True, True, True]);  to_dtype_140 = convolution_default_57 = primals_353 = primals_351 = primals_352 = getitem_188 = getitem_189 = None
        getitem_618 = native_batch_norm_backward_default_47[0]
        getitem_619 = native_batch_norm_backward_default_47[1]
        getitem_620 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_618, relu__default_53, primals_356, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_618 = primals_356 = None
        getitem_621 = convolution_backward_default_48[0]
        getitem_622 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_621, torch.float32);  getitem_621 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_152 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_152, to_dtype_141);  le_scalar_47 = new_zeros_default_152 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_143, convolution_default_56, primals_348, primals_346, primals_347, getitem_185, getitem_186, True, 1e-05, [True, True, True]);  to_dtype_143 = convolution_default_56 = primals_348 = primals_346 = primals_347 = getitem_185 = getitem_186 = None
        getitem_624 = native_batch_norm_backward_default_48[0]
        getitem_625 = native_batch_norm_backward_default_48[1]
        getitem_626 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_624, relu__default_52, primals_355, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_624 = primals_355 = None
        getitem_627 = convolution_backward_default_49[0]
        getitem_628 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_627, torch.float32);  getitem_627 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_153 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_153, to_dtype_144);  le_scalar_48 = new_zeros_default_153 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_146, convolution_default_55, primals_343, primals_341, primals_342, getitem_182, getitem_183, True, 1e-05, [True, True, True]);  to_dtype_146 = convolution_default_55 = primals_343 = primals_341 = primals_342 = getitem_182 = getitem_183 = None
        getitem_630 = native_batch_norm_backward_default_49[0]
        getitem_631 = native_batch_norm_backward_default_49[1]
        getitem_632 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_630, relu__default_51, primals_354, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_630 = primals_354 = None
        getitem_633 = convolution_backward_default_50[0]
        getitem_634 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, getitem_633);  add_tensor_33 = getitem_633 = None
        to_dtype_147 = torch.ops.aten.to.dtype(add_tensor_34, torch.float32);  add_tensor_34 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_154 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_154, to_dtype_147);  le_scalar_49 = new_zeros_default_154 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_149, convolution_default_54, primals_295, primals_293, primals_294, getitem_179, getitem_180, True, 1e-05, [True, True, True]);  convolution_default_54 = primals_295 = primals_293 = primals_294 = getitem_179 = getitem_180 = None
        getitem_636 = native_batch_norm_backward_default_50[0]
        getitem_637 = native_batch_norm_backward_default_50[1]
        getitem_638 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_636, cat_default_6, primals_296, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_636 = cat_default_6 = primals_296 = None
        getitem_639 = convolution_backward_default_51[0]
        getitem_640 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        slice_tensor_22 = torch.ops.aten.slice.Tensor(getitem_639, 1, 0, 512)
        slice_tensor_23 = torch.ops.aten.slice.Tensor(getitem_639, 1, 512, 1024)
        slice_tensor_24 = torch.ops.aten.slice.Tensor(getitem_639, 1, 1024, 1536);  getitem_639 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(to_dtype_149, slice_tensor_22);  to_dtype_149 = slice_tensor_22 = None
        to_dtype_150 = torch.ops.aten.to.dtype(add_tensor_35, torch.float32);  add_tensor_35 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_155 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_155, to_dtype_150);  le_scalar_50 = new_zeros_default_155 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(slice_tensor_23, to_dtype_152);  slice_tensor_23 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_152, convolution_default_53, primals_329, primals_327, primals_328, getitem_176, getitem_177, True, 1e-05, [True, True, True]);  to_dtype_152 = convolution_default_53 = primals_329 = primals_327 = primals_328 = getitem_176 = getitem_177 = None
        getitem_642 = native_batch_norm_backward_default_51[0]
        getitem_643 = native_batch_norm_backward_default_51[1]
        getitem_644 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_642, relu__default_49, primals_332, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_642 = primals_332 = None
        getitem_645 = convolution_backward_default_52[0]
        getitem_646 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_645, torch.float32);  getitem_645 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_156 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_156, to_dtype_153);  le_scalar_51 = new_zeros_default_156 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_155, convolution_default_52, primals_324, primals_322, primals_323, getitem_173, getitem_174, True, 1e-05, [True, True, True]);  to_dtype_155 = convolution_default_52 = primals_324 = primals_322 = primals_323 = getitem_173 = getitem_174 = None
        getitem_648 = native_batch_norm_backward_default_52[0]
        getitem_649 = native_batch_norm_backward_default_52[1]
        getitem_650 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_648, relu__default_48, primals_331, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_648 = primals_331 = None
        getitem_651 = convolution_backward_default_53[0]
        getitem_652 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_651, torch.float32);  getitem_651 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_157 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_157, to_dtype_156);  le_scalar_52 = new_zeros_default_157 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_158, convolution_default_51, primals_319, primals_317, primals_318, getitem_170, getitem_171, True, 1e-05, [True, True, True]);  to_dtype_158 = convolution_default_51 = primals_319 = primals_317 = primals_318 = getitem_170 = getitem_171 = None
        getitem_654 = native_batch_norm_backward_default_53[0]
        getitem_655 = native_batch_norm_backward_default_53[1]
        getitem_656 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_654, relu__default_47, primals_330, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_654 = primals_330 = None
        getitem_657 = convolution_backward_default_54[0]
        getitem_658 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_36, getitem_657);  add_tensor_36 = getitem_657 = None
        to_dtype_159 = torch.ops.aten.to.dtype(add_tensor_37, torch.float32);  add_tensor_37 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_158 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_158, to_dtype_159);  le_scalar_53 = new_zeros_default_158 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(slice_tensor_24, to_dtype_161);  slice_tensor_24 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_161, convolution_default_50, primals_311, primals_309, primals_310, getitem_167, getitem_168, True, 1e-05, [True, True, True]);  to_dtype_161 = convolution_default_50 = primals_311 = primals_309 = primals_310 = getitem_167 = getitem_168 = None
        getitem_660 = native_batch_norm_backward_default_54[0]
        getitem_661 = native_batch_norm_backward_default_54[1]
        getitem_662 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_660, relu__default_46, primals_314, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_660 = primals_314 = None
        getitem_663 = convolution_backward_default_55[0]
        getitem_664 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_663, torch.float32);  getitem_663 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_159 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_159, to_dtype_162);  le_scalar_54 = new_zeros_default_159 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_164, convolution_default_49, primals_306, primals_304, primals_305, getitem_164, getitem_165, True, 1e-05, [True, True, True]);  to_dtype_164 = convolution_default_49 = primals_306 = primals_304 = primals_305 = getitem_164 = getitem_165 = None
        getitem_666 = native_batch_norm_backward_default_55[0]
        getitem_667 = native_batch_norm_backward_default_55[1]
        getitem_668 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_666, relu__default_45, primals_313, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_666 = primals_313 = None
        getitem_669 = convolution_backward_default_56[0]
        getitem_670 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_669, torch.float32);  getitem_669 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_160 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_160, to_dtype_165);  le_scalar_55 = new_zeros_default_160 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_167, convolution_default_48, primals_301, primals_299, primals_300, getitem_161, getitem_162, True, 1e-05, [True, True, True]);  to_dtype_167 = convolution_default_48 = primals_301 = primals_299 = primals_300 = getitem_161 = getitem_162 = None
        getitem_672 = native_batch_norm_backward_default_56[0]
        getitem_673 = native_batch_norm_backward_default_56[1]
        getitem_674 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_672, relu__default_44, primals_312, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_672 = primals_312 = None
        getitem_675 = convolution_backward_default_57[0]
        getitem_676 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(add_tensor_38, getitem_675);  add_tensor_38 = getitem_675 = None
        to_dtype_168 = torch.ops.aten.to.dtype(add_tensor_39, torch.float32);  add_tensor_39 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_161 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_161, to_dtype_168);  le_scalar_56 = new_zeros_default_161 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_170, convolution_default_47, primals_253, primals_251, primals_252, getitem_158, getitem_159, True, 1e-05, [True, True, True]);  convolution_default_47 = primals_253 = primals_251 = primals_252 = getitem_158 = getitem_159 = None
        getitem_678 = native_batch_norm_backward_default_57[0]
        getitem_679 = native_batch_norm_backward_default_57[1]
        getitem_680 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_678, cat_default_5, primals_254, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_678 = cat_default_5 = primals_254 = None
        getitem_681 = convolution_backward_default_58[0]
        getitem_682 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        slice_tensor_25 = torch.ops.aten.slice.Tensor(getitem_681, 1, 0, 512)
        slice_tensor_26 = torch.ops.aten.slice.Tensor(getitem_681, 1, 512, 1024);  getitem_681 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(to_dtype_170, slice_tensor_25);  to_dtype_170 = slice_tensor_25 = None
        to_dtype_171 = torch.ops.aten.to.dtype(add_tensor_40, torch.float32);  add_tensor_40 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_162 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_162, to_dtype_171);  le_scalar_57 = new_zeros_default_162 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(slice_tensor_26, to_dtype_173);  slice_tensor_26 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_173, convolution_default_46, primals_287, primals_285, primals_286, getitem_155, getitem_156, True, 1e-05, [True, True, True]);  to_dtype_173 = convolution_default_46 = primals_287 = primals_285 = primals_286 = getitem_155 = getitem_156 = None
        getitem_684 = native_batch_norm_backward_default_58[0]
        getitem_685 = native_batch_norm_backward_default_58[1]
        getitem_686 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_684, relu__default_42, primals_290, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_684 = primals_290 = None
        getitem_687 = convolution_backward_default_59[0]
        getitem_688 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_687, torch.float32);  getitem_687 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_163 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_163, to_dtype_174);  le_scalar_58 = new_zeros_default_163 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_176, convolution_default_45, primals_282, primals_280, primals_281, getitem_152, getitem_153, True, 1e-05, [True, True, True]);  to_dtype_176 = convolution_default_45 = primals_282 = primals_280 = primals_281 = getitem_152 = getitem_153 = None
        getitem_690 = native_batch_norm_backward_default_59[0]
        getitem_691 = native_batch_norm_backward_default_59[1]
        getitem_692 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_690, relu__default_41, primals_289, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_690 = primals_289 = None
        getitem_693 = convolution_backward_default_60[0]
        getitem_694 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_693, torch.float32);  getitem_693 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_164 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_164, to_dtype_177);  le_scalar_59 = new_zeros_default_164 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_179, convolution_default_44, primals_277, primals_275, primals_276, getitem_149, getitem_150, True, 1e-05, [True, True, True]);  to_dtype_179 = convolution_default_44 = primals_277 = primals_275 = primals_276 = getitem_149 = getitem_150 = None
        getitem_696 = native_batch_norm_backward_default_60[0]
        getitem_697 = native_batch_norm_backward_default_60[1]
        getitem_698 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_696, relu__default_40, primals_288, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_696 = primals_288 = None
        getitem_699 = convolution_backward_default_61[0]
        getitem_700 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, getitem_699);  add_tensor_41 = getitem_699 = None
        to_dtype_180 = torch.ops.aten.to.dtype(add_tensor_42, torch.float32);  add_tensor_42 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_165 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_165, to_dtype_180);  le_scalar_60 = new_zeros_default_165 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_43, primals_269, primals_267, primals_268, getitem_146, getitem_147, True, 1e-05, [True, True, True]);  convolution_default_43 = primals_269 = primals_267 = primals_268 = getitem_146 = getitem_147 = None
        getitem_702 = native_batch_norm_backward_default_61[0]
        getitem_703 = native_batch_norm_backward_default_61[1]
        getitem_704 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_702, relu__default_39, primals_272, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_702 = primals_272 = None
        getitem_705 = convolution_backward_default_62[0]
        getitem_706 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_705, torch.float32);  getitem_705 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_166 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_166, to_dtype_183);  le_scalar_61 = new_zeros_default_166 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_185, convolution_default_42, primals_264, primals_262, primals_263, getitem_143, getitem_144, True, 1e-05, [True, True, True]);  to_dtype_185 = convolution_default_42 = primals_264 = primals_262 = primals_263 = getitem_143 = getitem_144 = None
        getitem_708 = native_batch_norm_backward_default_62[0]
        getitem_709 = native_batch_norm_backward_default_62[1]
        getitem_710 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_708, relu__default_38, primals_271, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_708 = primals_271 = None
        getitem_711 = convolution_backward_default_63[0]
        getitem_712 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_711, torch.float32);  getitem_711 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_167 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_167, to_dtype_186);  le_scalar_62 = new_zeros_default_167 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_188, convolution_default_41, primals_259, primals_257, primals_258, getitem_140, getitem_141, True, 1e-05, [True, True, True]);  to_dtype_188 = convolution_default_41 = primals_259 = primals_257 = primals_258 = getitem_140 = getitem_141 = None
        getitem_714 = native_batch_norm_backward_default_63[0]
        getitem_715 = native_batch_norm_backward_default_63[1]
        getitem_716 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_714, relu__default_37, primals_270, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_714 = primals_270 = None
        getitem_717 = convolution_backward_default_64[0]
        getitem_718 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_182, convolution_default_40, primals_248, primals_246, primals_247, getitem_137, getitem_138, True, 1e-05, [True, True, True]);  to_dtype_182 = convolution_default_40 = primals_248 = primals_246 = primals_247 = getitem_137 = getitem_138 = None
        getitem_720 = native_batch_norm_backward_default_64[0]
        getitem_721 = native_batch_norm_backward_default_64[1]
        getitem_722 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(getitem_720, getitem_134, primals_243, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_720 = getitem_134 = primals_243 = None
        getitem_723 = convolution_backward_default_65[0]
        getitem_724 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        max_pool2d_with_indices_backward_default_1 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_723, relu__default_37, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_135);  getitem_723 = getitem_135 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(getitem_717, max_pool2d_with_indices_backward_default_1);  getitem_717 = max_pool2d_with_indices_backward_default_1 = None
        max_pool2d_with_indices_backward_default_2 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_5, relu__default_37, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_129);  slice_tensor_5 = getitem_129 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(add_tensor_43, max_pool2d_with_indices_backward_default_2);  add_tensor_43 = max_pool2d_with_indices_backward_default_2 = None
        to_dtype_189 = torch.ops.aten.to.dtype(add_tensor_44, torch.float32);  add_tensor_44 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_168 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_168, to_dtype_189);  le_scalar_63 = new_zeros_default_168 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_191, convolution_default_39, primals_205, primals_203, primals_204, getitem_126, getitem_127, True, 1e-05, [True, True, True]);  convolution_default_39 = primals_205 = primals_203 = primals_204 = getitem_126 = getitem_127 = None
        getitem_726 = native_batch_norm_backward_default_65[0]
        getitem_727 = native_batch_norm_backward_default_65[1]
        getitem_728 = native_batch_norm_backward_default_65[2];  native_batch_norm_backward_default_65 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_726, cat_default_4, primals_206, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_726 = cat_default_4 = primals_206 = None
        getitem_729 = convolution_backward_default_66[0]
        getitem_730 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        slice_tensor_27 = torch.ops.aten.slice.Tensor(getitem_729, 1, 0, 256)
        slice_tensor_28 = torch.ops.aten.slice.Tensor(getitem_729, 1, 256, 512)
        slice_tensor_29 = torch.ops.aten.slice.Tensor(getitem_729, 1, 512, 640)
        slice_tensor_30 = torch.ops.aten.slice.Tensor(getitem_729, 1, 640, 896)
        slice_tensor_31 = torch.ops.aten.slice.Tensor(getitem_729, 1, 896, 1152);  getitem_729 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(to_dtype_191, slice_tensor_27);  to_dtype_191 = slice_tensor_27 = None
        to_dtype_192 = torch.ops.aten.to.dtype(add_tensor_45, torch.float32);  add_tensor_45 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_169 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_169, to_dtype_192);  le_scalar_64 = new_zeros_default_169 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(slice_tensor_28, to_dtype_194);  slice_tensor_28 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_194, convolution_default_38, primals_239, primals_237, primals_238, getitem_123, getitem_124, True, 1e-05, [True, True, True]);  to_dtype_194 = convolution_default_38 = primals_239 = primals_237 = primals_238 = getitem_123 = getitem_124 = None
        getitem_732 = native_batch_norm_backward_default_66[0]
        getitem_733 = native_batch_norm_backward_default_66[1]
        getitem_734 = native_batch_norm_backward_default_66[2];  native_batch_norm_backward_default_66 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_732, relu__default_35, primals_242, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_732 = primals_242 = None
        getitem_735 = convolution_backward_default_67[0]
        getitem_736 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        to_dtype_195 = torch.ops.aten.to.dtype(getitem_735, torch.float32);  getitem_735 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_170 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_170, to_dtype_195);  le_scalar_65 = new_zeros_default_170 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_197, convolution_default_37, primals_234, primals_232, primals_233, getitem_120, getitem_121, True, 1e-05, [True, True, True]);  to_dtype_197 = convolution_default_37 = primals_234 = primals_232 = primals_233 = getitem_120 = getitem_121 = None
        getitem_738 = native_batch_norm_backward_default_67[0]
        getitem_739 = native_batch_norm_backward_default_67[1]
        getitem_740 = native_batch_norm_backward_default_67[2];  native_batch_norm_backward_default_67 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(getitem_738, relu__default_34, primals_241, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_738 = primals_241 = None
        getitem_741 = convolution_backward_default_68[0]
        getitem_742 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_741, torch.float32);  getitem_741 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_171 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_171, to_dtype_198);  le_scalar_66 = new_zeros_default_171 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_200, convolution_default_36, primals_229, primals_227, primals_228, getitem_117, getitem_118, True, 1e-05, [True, True, True]);  to_dtype_200 = convolution_default_36 = primals_229 = primals_227 = primals_228 = getitem_117 = getitem_118 = None
        getitem_744 = native_batch_norm_backward_default_68[0]
        getitem_745 = native_batch_norm_backward_default_68[1]
        getitem_746 = native_batch_norm_backward_default_68[2];  native_batch_norm_backward_default_68 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_744, relu__default_33, primals_240, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_744 = primals_240 = None
        getitem_747 = convolution_backward_default_69[0]
        getitem_748 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(add_tensor_46, getitem_747);  add_tensor_46 = getitem_747 = None
        to_dtype_201 = torch.ops.aten.to.dtype(add_tensor_47, torch.float32);  add_tensor_47 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_172 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_172, to_dtype_201);  le_scalar_67 = new_zeros_default_172 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(slice_tensor_31, to_dtype_203);  slice_tensor_31 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_203, convolution_default_35, primals_221, primals_219, primals_220, getitem_114, getitem_115, True, 1e-05, [True, True, True]);  to_dtype_203 = convolution_default_35 = primals_221 = primals_219 = primals_220 = getitem_114 = getitem_115 = None
        getitem_750 = native_batch_norm_backward_default_69[0]
        getitem_751 = native_batch_norm_backward_default_69[1]
        getitem_752 = native_batch_norm_backward_default_69[2];  native_batch_norm_backward_default_69 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_750, relu__default_32, primals_224, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_750 = primals_224 = None
        getitem_753 = convolution_backward_default_70[0]
        getitem_754 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_753, torch.float32);  getitem_753 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_173 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_173, to_dtype_204);  le_scalar_68 = new_zeros_default_173 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_206, convolution_default_34, primals_216, primals_214, primals_215, getitem_111, getitem_112, True, 1e-05, [True, True, True]);  to_dtype_206 = convolution_default_34 = primals_216 = primals_214 = primals_215 = getitem_111 = getitem_112 = None
        getitem_756 = native_batch_norm_backward_default_70[0]
        getitem_757 = native_batch_norm_backward_default_70[1]
        getitem_758 = native_batch_norm_backward_default_70[2];  native_batch_norm_backward_default_70 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(getitem_756, relu__default_31, primals_223, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_756 = primals_223 = None
        getitem_759 = convolution_backward_default_71[0]
        getitem_760 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_759, torch.float32);  getitem_759 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_174 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_174, to_dtype_207);  le_scalar_69 = new_zeros_default_174 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_209, convolution_default_33, primals_211, primals_209, primals_210, getitem_108, getitem_109, True, 1e-05, [True, True, True]);  to_dtype_209 = convolution_default_33 = primals_211 = primals_209 = primals_210 = getitem_108 = getitem_109 = None
        getitem_762 = native_batch_norm_backward_default_71[0]
        getitem_763 = native_batch_norm_backward_default_71[1]
        getitem_764 = native_batch_norm_backward_default_71[2];  native_batch_norm_backward_default_71 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_762, relu__default_30, primals_222, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_762 = primals_222 = None
        getitem_765 = convolution_backward_default_72[0]
        getitem_766 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, getitem_765);  add_tensor_48 = getitem_765 = None
        to_dtype_210 = torch.ops.aten.to.dtype(add_tensor_49, torch.float32);  add_tensor_49 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_175 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_175, to_dtype_210);  le_scalar_70 = new_zeros_default_175 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_212, convolution_default_32, primals_163, primals_161, primals_162, getitem_105, getitem_106, True, 1e-05, [True, True, True]);  convolution_default_32 = primals_163 = primals_161 = primals_162 = getitem_105 = getitem_106 = None
        getitem_768 = native_batch_norm_backward_default_72[0]
        getitem_769 = native_batch_norm_backward_default_72[1]
        getitem_770 = native_batch_norm_backward_default_72[2];  native_batch_norm_backward_default_72 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_768, cat_default_3, primals_164, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_768 = cat_default_3 = primals_164 = None
        getitem_771 = convolution_backward_default_73[0]
        getitem_772 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        slice_tensor_32 = torch.ops.aten.slice.Tensor(getitem_771, 1, 0, 256)
        slice_tensor_33 = torch.ops.aten.slice.Tensor(getitem_771, 1, 256, 512);  getitem_771 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(to_dtype_212, slice_tensor_32);  to_dtype_212 = slice_tensor_32 = None
        to_dtype_213 = torch.ops.aten.to.dtype(add_tensor_50, torch.float32);  add_tensor_50 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_176 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_176, to_dtype_213);  le_scalar_71 = new_zeros_default_176 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(slice_tensor_33, to_dtype_215);  slice_tensor_33 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_215, convolution_default_31, primals_197, primals_195, primals_196, getitem_102, getitem_103, True, 1e-05, [True, True, True]);  to_dtype_215 = convolution_default_31 = primals_197 = primals_195 = primals_196 = getitem_102 = getitem_103 = None
        getitem_774 = native_batch_norm_backward_default_73[0]
        getitem_775 = native_batch_norm_backward_default_73[1]
        getitem_776 = native_batch_norm_backward_default_73[2];  native_batch_norm_backward_default_73 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(getitem_774, relu__default_28, primals_200, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_774 = primals_200 = None
        getitem_777 = convolution_backward_default_74[0]
        getitem_778 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_777, torch.float32);  getitem_777 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_177 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_177, to_dtype_216);  le_scalar_72 = new_zeros_default_177 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_218, convolution_default_30, primals_192, primals_190, primals_191, getitem_99, getitem_100, True, 1e-05, [True, True, True]);  to_dtype_218 = convolution_default_30 = primals_192 = primals_190 = primals_191 = getitem_99 = getitem_100 = None
        getitem_780 = native_batch_norm_backward_default_74[0]
        getitem_781 = native_batch_norm_backward_default_74[1]
        getitem_782 = native_batch_norm_backward_default_74[2];  native_batch_norm_backward_default_74 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_780, relu__default_27, primals_199, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_780 = primals_199 = None
        getitem_783 = convolution_backward_default_75[0]
        getitem_784 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_783, torch.float32);  getitem_783 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_178 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_178, to_dtype_219);  le_scalar_73 = new_zeros_default_178 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_221, convolution_default_29, primals_187, primals_185, primals_186, getitem_96, getitem_97, True, 1e-05, [True, True, True]);  to_dtype_221 = convolution_default_29 = primals_187 = primals_185 = primals_186 = getitem_96 = getitem_97 = None
        getitem_786 = native_batch_norm_backward_default_75[0]
        getitem_787 = native_batch_norm_backward_default_75[1]
        getitem_788 = native_batch_norm_backward_default_75[2];  native_batch_norm_backward_default_75 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_786, relu__default_26, primals_198, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_786 = primals_198 = None
        getitem_789 = convolution_backward_default_76[0]
        getitem_790 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_51, getitem_789);  add_tensor_51 = getitem_789 = None
        to_dtype_222 = torch.ops.aten.to.dtype(add_tensor_52, torch.float32);  add_tensor_52 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_179 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_179, to_dtype_222);  le_scalar_74 = new_zeros_default_179 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(slice_tensor_30, to_dtype_224);  slice_tensor_30 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_224, convolution_default_28, primals_179, primals_177, primals_178, getitem_93, getitem_94, True, 1e-05, [True, True, True]);  to_dtype_224 = convolution_default_28 = primals_179 = primals_177 = primals_178 = getitem_93 = getitem_94 = None
        getitem_792 = native_batch_norm_backward_default_76[0]
        getitem_793 = native_batch_norm_backward_default_76[1]
        getitem_794 = native_batch_norm_backward_default_76[2];  native_batch_norm_backward_default_76 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(getitem_792, relu__default_25, primals_182, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_792 = primals_182 = None
        getitem_795 = convolution_backward_default_77[0]
        getitem_796 = convolution_backward_default_77[1];  convolution_backward_default_77 = None
        to_dtype_225 = torch.ops.aten.to.dtype(getitem_795, torch.float32);  getitem_795 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_180 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_180, to_dtype_225);  le_scalar_75 = new_zeros_default_180 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_227, convolution_default_27, primals_174, primals_172, primals_173, getitem_90, getitem_91, True, 1e-05, [True, True, True]);  to_dtype_227 = convolution_default_27 = primals_174 = primals_172 = primals_173 = getitem_90 = getitem_91 = None
        getitem_798 = native_batch_norm_backward_default_77[0]
        getitem_799 = native_batch_norm_backward_default_77[1]
        getitem_800 = native_batch_norm_backward_default_77[2];  native_batch_norm_backward_default_77 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_798, relu__default_24, primals_181, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_798 = primals_181 = None
        getitem_801 = convolution_backward_default_78[0]
        getitem_802 = convolution_backward_default_78[1];  convolution_backward_default_78 = None
        to_dtype_228 = torch.ops.aten.to.dtype(getitem_801, torch.float32);  getitem_801 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_181 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_181, to_dtype_228);  le_scalar_76 = new_zeros_default_181 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_230, convolution_default_26, primals_169, primals_167, primals_168, getitem_87, getitem_88, True, 1e-05, [True, True, True]);  to_dtype_230 = convolution_default_26 = primals_169 = primals_167 = primals_168 = getitem_87 = getitem_88 = None
        getitem_804 = native_batch_norm_backward_default_78[0]
        getitem_805 = native_batch_norm_backward_default_78[1]
        getitem_806 = native_batch_norm_backward_default_78[2];  native_batch_norm_backward_default_78 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_804, relu__default_23, primals_180, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_804 = primals_180 = None
        getitem_807 = convolution_backward_default_79[0]
        getitem_808 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_53, getitem_807);  add_tensor_53 = getitem_807 = None
        to_dtype_231 = torch.ops.aten.to.dtype(add_tensor_54, torch.float32);  add_tensor_54 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_182 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_182, to_dtype_231);  le_scalar_77 = new_zeros_default_182 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_233, convolution_default_25, primals_121, primals_119, primals_120, getitem_84, getitem_85, True, 1e-05, [True, True, True]);  convolution_default_25 = primals_121 = primals_119 = primals_120 = getitem_84 = getitem_85 = None
        getitem_810 = native_batch_norm_backward_default_79[0]
        getitem_811 = native_batch_norm_backward_default_79[1]
        getitem_812 = native_batch_norm_backward_default_79[2];  native_batch_norm_backward_default_79 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(getitem_810, cat_default_2, primals_122, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_810 = cat_default_2 = primals_122 = None
        getitem_813 = convolution_backward_default_80[0]
        getitem_814 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        slice_tensor_34 = torch.ops.aten.slice.Tensor(getitem_813, 1, 0, 256)
        slice_tensor_35 = torch.ops.aten.slice.Tensor(getitem_813, 1, 256, 512)
        slice_tensor_36 = torch.ops.aten.slice.Tensor(getitem_813, 1, 512, 768);  getitem_813 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(to_dtype_233, slice_tensor_34);  to_dtype_233 = slice_tensor_34 = None
        to_dtype_234 = torch.ops.aten.to.dtype(add_tensor_55, torch.float32);  add_tensor_55 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_183 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_183, to_dtype_234);  le_scalar_78 = new_zeros_default_183 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(slice_tensor_35, to_dtype_236);  slice_tensor_35 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_236, convolution_default_24, primals_155, primals_153, primals_154, getitem_81, getitem_82, True, 1e-05, [True, True, True]);  to_dtype_236 = convolution_default_24 = primals_155 = primals_153 = primals_154 = getitem_81 = getitem_82 = None
        getitem_816 = native_batch_norm_backward_default_80[0]
        getitem_817 = native_batch_norm_backward_default_80[1]
        getitem_818 = native_batch_norm_backward_default_80[2];  native_batch_norm_backward_default_80 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_816, relu__default_21, primals_158, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_816 = primals_158 = None
        getitem_819 = convolution_backward_default_81[0]
        getitem_820 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_819, torch.float32);  getitem_819 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_184 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_184, to_dtype_237);  le_scalar_79 = new_zeros_default_184 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_239, convolution_default_23, primals_150, primals_148, primals_149, getitem_78, getitem_79, True, 1e-05, [True, True, True]);  to_dtype_239 = convolution_default_23 = primals_150 = primals_148 = primals_149 = getitem_78 = getitem_79 = None
        getitem_822 = native_batch_norm_backward_default_81[0]
        getitem_823 = native_batch_norm_backward_default_81[1]
        getitem_824 = native_batch_norm_backward_default_81[2];  native_batch_norm_backward_default_81 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_822, relu__default_20, primals_157, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_822 = primals_157 = None
        getitem_825 = convolution_backward_default_82[0]
        getitem_826 = convolution_backward_default_82[1];  convolution_backward_default_82 = None
        to_dtype_240 = torch.ops.aten.to.dtype(getitem_825, torch.float32);  getitem_825 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_185 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_185, to_dtype_240);  le_scalar_80 = new_zeros_default_185 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_242, convolution_default_22, primals_145, primals_143, primals_144, getitem_75, getitem_76, True, 1e-05, [True, True, True]);  to_dtype_242 = convolution_default_22 = primals_145 = primals_143 = primals_144 = getitem_75 = getitem_76 = None
        getitem_828 = native_batch_norm_backward_default_82[0]
        getitem_829 = native_batch_norm_backward_default_82[1]
        getitem_830 = native_batch_norm_backward_default_82[2];  native_batch_norm_backward_default_82 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_828, relu__default_19, primals_156, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_828 = primals_156 = None
        getitem_831 = convolution_backward_default_83[0]
        getitem_832 = convolution_backward_default_83[1];  convolution_backward_default_83 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_56, getitem_831);  add_tensor_56 = getitem_831 = None
        to_dtype_243 = torch.ops.aten.to.dtype(add_tensor_57, torch.float32);  add_tensor_57 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_186 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_186, to_dtype_243);  le_scalar_81 = new_zeros_default_186 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(slice_tensor_36, to_dtype_245);  slice_tensor_36 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_245, convolution_default_21, primals_137, primals_135, primals_136, getitem_72, getitem_73, True, 1e-05, [True, True, True]);  to_dtype_245 = convolution_default_21 = primals_137 = primals_135 = primals_136 = getitem_72 = getitem_73 = None
        getitem_834 = native_batch_norm_backward_default_83[0]
        getitem_835 = native_batch_norm_backward_default_83[1]
        getitem_836 = native_batch_norm_backward_default_83[2];  native_batch_norm_backward_default_83 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(getitem_834, relu__default_18, primals_140, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_834 = primals_140 = None
        getitem_837 = convolution_backward_default_84[0]
        getitem_838 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_837, torch.float32);  getitem_837 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_187 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_187, to_dtype_246);  le_scalar_82 = new_zeros_default_187 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_248, convolution_default_20, primals_132, primals_130, primals_131, getitem_69, getitem_70, True, 1e-05, [True, True, True]);  to_dtype_248 = convolution_default_20 = primals_132 = primals_130 = primals_131 = getitem_69 = getitem_70 = None
        getitem_840 = native_batch_norm_backward_default_84[0]
        getitem_841 = native_batch_norm_backward_default_84[1]
        getitem_842 = native_batch_norm_backward_default_84[2];  native_batch_norm_backward_default_84 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_840, relu__default_17, primals_139, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_840 = primals_139 = None
        getitem_843 = convolution_backward_default_85[0]
        getitem_844 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_843, torch.float32);  getitem_843 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_188 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_188, to_dtype_249);  le_scalar_83 = new_zeros_default_188 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_251, convolution_default_19, primals_127, primals_125, primals_126, getitem_66, getitem_67, True, 1e-05, [True, True, True]);  to_dtype_251 = convolution_default_19 = primals_127 = primals_125 = primals_126 = getitem_66 = getitem_67 = None
        getitem_846 = native_batch_norm_backward_default_85[0]
        getitem_847 = native_batch_norm_backward_default_85[1]
        getitem_848 = native_batch_norm_backward_default_85[2];  native_batch_norm_backward_default_85 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_846, relu__default_16, primals_138, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_846 = primals_138 = None
        getitem_849 = convolution_backward_default_86[0]
        getitem_850 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(add_tensor_58, getitem_849);  add_tensor_58 = getitem_849 = None
        to_dtype_252 = torch.ops.aten.to.dtype(add_tensor_59, torch.float32);  add_tensor_59 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_189 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_189, to_dtype_252);  le_scalar_84 = new_zeros_default_189 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_254, convolution_default_18, primals_79, primals_77, primals_78, getitem_63, getitem_64, True, 1e-05, [True, True, True]);  convolution_default_18 = primals_79 = primals_77 = primals_78 = getitem_63 = getitem_64 = None
        getitem_852 = native_batch_norm_backward_default_86[0]
        getitem_853 = native_batch_norm_backward_default_86[1]
        getitem_854 = native_batch_norm_backward_default_86[2];  native_batch_norm_backward_default_86 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(getitem_852, cat_default_1, primals_80, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_852 = cat_default_1 = primals_80 = None
        getitem_855 = convolution_backward_default_87[0]
        getitem_856 = convolution_backward_default_87[1];  convolution_backward_default_87 = None
        slice_tensor_37 = torch.ops.aten.slice.Tensor(getitem_855, 1, 0, 256)
        slice_tensor_38 = torch.ops.aten.slice.Tensor(getitem_855, 1, 256, 512);  getitem_855 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(to_dtype_254, slice_tensor_37);  to_dtype_254 = slice_tensor_37 = None
        to_dtype_255 = torch.ops.aten.to.dtype(add_tensor_60, torch.float32);  add_tensor_60 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_190 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_190, to_dtype_255);  le_scalar_85 = new_zeros_default_190 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(slice_tensor_38, to_dtype_257);  slice_tensor_38 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_257, convolution_default_17, primals_113, primals_111, primals_112, getitem_60, getitem_61, True, 1e-05, [True, True, True]);  to_dtype_257 = convolution_default_17 = primals_113 = primals_111 = primals_112 = getitem_60 = getitem_61 = None
        getitem_858 = native_batch_norm_backward_default_87[0]
        getitem_859 = native_batch_norm_backward_default_87[1]
        getitem_860 = native_batch_norm_backward_default_87[2];  native_batch_norm_backward_default_87 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_858, relu__default_14, primals_116, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_858 = primals_116 = None
        getitem_861 = convolution_backward_default_88[0]
        getitem_862 = convolution_backward_default_88[1];  convolution_backward_default_88 = None
        to_dtype_258 = torch.ops.aten.to.dtype(getitem_861, torch.float32);  getitem_861 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_191 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_191, to_dtype_258);  le_scalar_86 = new_zeros_default_191 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_260, convolution_default_16, primals_108, primals_106, primals_107, getitem_57, getitem_58, True, 1e-05, [True, True, True]);  to_dtype_260 = convolution_default_16 = primals_108 = primals_106 = primals_107 = getitem_57 = getitem_58 = None
        getitem_864 = native_batch_norm_backward_default_88[0]
        getitem_865 = native_batch_norm_backward_default_88[1]
        getitem_866 = native_batch_norm_backward_default_88[2];  native_batch_norm_backward_default_88 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_864, relu__default_13, primals_115, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_864 = primals_115 = None
        getitem_867 = convolution_backward_default_89[0]
        getitem_868 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_867, torch.float32);  getitem_867 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_192 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_192, to_dtype_261);  le_scalar_87 = new_zeros_default_192 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_263, convolution_default_15, primals_103, primals_101, primals_102, getitem_54, getitem_55, True, 1e-05, [True, True, True]);  to_dtype_263 = convolution_default_15 = primals_103 = primals_101 = primals_102 = getitem_54 = getitem_55 = None
        getitem_870 = native_batch_norm_backward_default_89[0]
        getitem_871 = native_batch_norm_backward_default_89[1]
        getitem_872 = native_batch_norm_backward_default_89[2];  native_batch_norm_backward_default_89 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(getitem_870, relu__default_12, primals_114, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_870 = primals_114 = None
        getitem_873 = convolution_backward_default_90[0]
        getitem_874 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(add_tensor_61, getitem_873);  add_tensor_61 = getitem_873 = None
        to_dtype_264 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_193 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_193, to_dtype_264);  le_scalar_88 = new_zeros_default_193 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_14, primals_95, primals_93, primals_94, getitem_51, getitem_52, True, 1e-05, [True, True, True]);  convolution_default_14 = primals_95 = primals_93 = primals_94 = getitem_51 = getitem_52 = None
        getitem_876 = native_batch_norm_backward_default_90[0]
        getitem_877 = native_batch_norm_backward_default_90[1]
        getitem_878 = native_batch_norm_backward_default_90[2];  native_batch_norm_backward_default_90 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_876, relu__default_11, primals_98, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_876 = primals_98 = None
        getitem_879 = convolution_backward_default_91[0]
        getitem_880 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_879, torch.float32);  getitem_879 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_194 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_194, to_dtype_267);  le_scalar_89 = new_zeros_default_194 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_269, convolution_default_13, primals_90, primals_88, primals_89, getitem_48, getitem_49, True, 1e-05, [True, True, True]);  to_dtype_269 = convolution_default_13 = primals_90 = primals_88 = primals_89 = getitem_48 = getitem_49 = None
        getitem_882 = native_batch_norm_backward_default_91[0]
        getitem_883 = native_batch_norm_backward_default_91[1]
        getitem_884 = native_batch_norm_backward_default_91[2];  native_batch_norm_backward_default_91 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_882, relu__default_10, primals_97, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_882 = primals_97 = None
        getitem_885 = convolution_backward_default_92[0]
        getitem_886 = convolution_backward_default_92[1];  convolution_backward_default_92 = None
        to_dtype_270 = torch.ops.aten.to.dtype(getitem_885, torch.float32);  getitem_885 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_195 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_195, to_dtype_270);  le_scalar_90 = new_zeros_default_195 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_272, convolution_default_12, primals_85, primals_83, primals_84, getitem_45, getitem_46, True, 1e-05, [True, True, True]);  to_dtype_272 = convolution_default_12 = primals_85 = primals_83 = primals_84 = getitem_45 = getitem_46 = None
        getitem_888 = native_batch_norm_backward_default_92[0]
        getitem_889 = native_batch_norm_backward_default_92[1]
        getitem_890 = native_batch_norm_backward_default_92[2];  native_batch_norm_backward_default_92 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(getitem_888, relu__default_9, primals_96, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_888 = primals_96 = None
        getitem_891 = convolution_backward_default_93[0]
        getitem_892 = convolution_backward_default_93[1];  convolution_backward_default_93 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_266, convolution_default_11, primals_74, primals_72, primals_73, getitem_42, getitem_43, True, 1e-05, [True, True, True]);  to_dtype_266 = convolution_default_11 = primals_74 = primals_72 = primals_73 = getitem_42 = getitem_43 = None
        getitem_894 = native_batch_norm_backward_default_93[0]
        getitem_895 = native_batch_norm_backward_default_93[1]
        getitem_896 = native_batch_norm_backward_default_93[2];  native_batch_norm_backward_default_93 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_894, getitem_39, primals_69, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_894 = getitem_39 = primals_69 = None
        getitem_897 = convolution_backward_default_94[0]
        getitem_898 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        max_pool2d_with_indices_backward_default_3 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_897, relu__default_9, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_40);  getitem_897 = getitem_40 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(getitem_891, max_pool2d_with_indices_backward_default_3);  getitem_891 = max_pool2d_with_indices_backward_default_3 = None
        max_pool2d_with_indices_backward_default_4 = torch.ops.aten.max_pool2d_with_indices_backward.default(slice_tensor_29, relu__default_9, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_36);  slice_tensor_29 = getitem_36 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_63, max_pool2d_with_indices_backward_default_4);  add_tensor_63 = max_pool2d_with_indices_backward_default_4 = None
        to_dtype_273 = torch.ops.aten.to.dtype(add_tensor_64, torch.float32);  add_tensor_64 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_196 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_196, to_dtype_273);  le_scalar_91 = new_zeros_default_196 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_275, convolution_default_10, primals_31, primals_29, primals_30, getitem_33, getitem_34, True, 1e-05, [True, True, True]);  convolution_default_10 = primals_31 = primals_29 = primals_30 = getitem_33 = getitem_34 = None
        getitem_900 = native_batch_norm_backward_default_94[0]
        getitem_901 = native_batch_norm_backward_default_94[1]
        getitem_902 = native_batch_norm_backward_default_94[2];  native_batch_norm_backward_default_94 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_900, cat_default, primals_32, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_900 = cat_default = primals_32 = None
        getitem_903 = convolution_backward_default_95[0]
        getitem_904 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        slice_tensor_39 = torch.ops.aten.slice.Tensor(getitem_903, 1, 0, 128)
        slice_tensor_40 = torch.ops.aten.slice.Tensor(getitem_903, 1, 128, 256);  getitem_903 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(to_dtype_275, slice_tensor_39);  to_dtype_275 = slice_tensor_39 = None
        to_dtype_276 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_197 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_197, to_dtype_276);  le_scalar_92 = new_zeros_default_197 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(slice_tensor_40, to_dtype_278);  slice_tensor_40 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_278, convolution_default_9, primals_65, primals_63, primals_64, getitem_30, getitem_31, True, 1e-05, [True, True, True]);  to_dtype_278 = convolution_default_9 = primals_65 = primals_63 = primals_64 = getitem_30 = getitem_31 = None
        getitem_906 = native_batch_norm_backward_default_95[0]
        getitem_907 = native_batch_norm_backward_default_95[1]
        getitem_908 = native_batch_norm_backward_default_95[2];  native_batch_norm_backward_default_95 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_906, relu__default_7, primals_68, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_906 = primals_68 = None
        getitem_909 = convolution_backward_default_96[0]
        getitem_910 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_909, torch.float32);  getitem_909 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_198 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_198, to_dtype_279);  le_scalar_93 = new_zeros_default_198 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_281, convolution_default_8, primals_60, primals_58, primals_59, getitem_27, getitem_28, True, 1e-05, [True, True, True]);  to_dtype_281 = convolution_default_8 = primals_60 = primals_58 = primals_59 = getitem_27 = getitem_28 = None
        getitem_912 = native_batch_norm_backward_default_96[0]
        getitem_913 = native_batch_norm_backward_default_96[1]
        getitem_914 = native_batch_norm_backward_default_96[2];  native_batch_norm_backward_default_96 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(getitem_912, relu__default_6, primals_67, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_912 = primals_67 = None
        getitem_915 = convolution_backward_default_97[0]
        getitem_916 = convolution_backward_default_97[1];  convolution_backward_default_97 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_915, torch.float32);  getitem_915 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_199 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_199, to_dtype_282);  le_scalar_94 = new_zeros_default_199 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_284, convolution_default_7, primals_55, primals_53, primals_54, getitem_24, getitem_25, True, 1e-05, [True, True, True]);  to_dtype_284 = convolution_default_7 = primals_55 = primals_53 = primals_54 = getitem_24 = getitem_25 = None
        getitem_918 = native_batch_norm_backward_default_97[0]
        getitem_919 = native_batch_norm_backward_default_97[1]
        getitem_920 = native_batch_norm_backward_default_97[2];  native_batch_norm_backward_default_97 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_918, relu__default_5, primals_66, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_918 = primals_66 = None
        getitem_921 = convolution_backward_default_98[0]
        getitem_922 = convolution_backward_default_98[1];  convolution_backward_default_98 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(add_tensor_66, getitem_921);  add_tensor_66 = getitem_921 = None
        to_dtype_285 = torch.ops.aten.to.dtype(add_tensor_67, torch.float32);  add_tensor_67 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_200 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_200, to_dtype_285);  le_scalar_95 = new_zeros_default_200 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_287, convolution_default_6, primals_47, primals_45, primals_46, getitem_21, getitem_22, True, 1e-05, [True, True, True]);  convolution_default_6 = primals_47 = primals_45 = primals_46 = getitem_21 = getitem_22 = None
        getitem_924 = native_batch_norm_backward_default_98[0]
        getitem_925 = native_batch_norm_backward_default_98[1]
        getitem_926 = native_batch_norm_backward_default_98[2];  native_batch_norm_backward_default_98 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_924, relu__default_4, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_924 = primals_50 = None
        getitem_927 = convolution_backward_default_99[0]
        getitem_928 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        to_dtype_288 = torch.ops.aten.to.dtype(getitem_927, torch.float32);  getitem_927 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_201 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_201, to_dtype_288);  le_scalar_96 = new_zeros_default_201 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_290, convolution_default_5, primals_42, primals_40, primals_41, getitem_18, getitem_19, True, 1e-05, [True, True, True]);  to_dtype_290 = convolution_default_5 = primals_42 = primals_40 = primals_41 = getitem_18 = getitem_19 = None
        getitem_930 = native_batch_norm_backward_default_99[0]
        getitem_931 = native_batch_norm_backward_default_99[1]
        getitem_932 = native_batch_norm_backward_default_99[2];  native_batch_norm_backward_default_99 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(getitem_930, relu__default_3, primals_49, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_930 = primals_49 = None
        getitem_933 = convolution_backward_default_100[0]
        getitem_934 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_933, torch.float32);  getitem_933 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_202 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_202, to_dtype_291);  le_scalar_97 = new_zeros_default_202 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_293, convolution_default_4, primals_37, primals_35, primals_36, getitem_15, getitem_16, True, 1e-05, [True, True, True]);  to_dtype_293 = convolution_default_4 = primals_37 = primals_35 = primals_36 = getitem_15 = getitem_16 = None
        getitem_936 = native_batch_norm_backward_default_100[0]
        getitem_937 = native_batch_norm_backward_default_100[1]
        getitem_938 = native_batch_norm_backward_default_100[2];  native_batch_norm_backward_default_100 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_936, relu__default_2, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_936 = primals_48 = None
        getitem_939 = convolution_backward_default_101[0]
        getitem_940 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_287, convolution_default_3, primals_26, primals_24, primals_25, getitem_12, getitem_13, True, 1e-05, [True, True, True]);  to_dtype_287 = convolution_default_3 = primals_26 = primals_24 = primals_25 = getitem_12 = getitem_13 = None
        getitem_942 = native_batch_norm_backward_default_101[0]
        getitem_943 = native_batch_norm_backward_default_101[1]
        getitem_944 = native_batch_norm_backward_default_101[2];  native_batch_norm_backward_default_101 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_942, getitem_9, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_942 = getitem_9 = primals_21 = None
        getitem_945 = convolution_backward_default_102[0]
        getitem_946 = convolution_backward_default_102[1];  convolution_backward_default_102 = None
        max_pool2d_with_indices_backward_default_5 = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_945, relu__default_2, [2, 2], [2, 2], [0, 0], [1, 1], False, getitem_10);  getitem_945 = getitem_10 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(getitem_939, max_pool2d_with_indices_backward_default_5);  getitem_939 = max_pool2d_with_indices_backward_default_5 = None
        to_dtype_294 = torch.ops.aten.to.dtype(add_tensor_68, torch.float32);  add_tensor_68 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_203 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_203, to_dtype_294);  le_scalar_98 = new_zeros_default_203 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_296, convolution_default_2, primals_20, primals_18, primals_19, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_296 = convolution_default_2 = primals_20 = primals_18 = primals_19 = getitem_7 = getitem_8 = None
        getitem_948 = native_batch_norm_backward_default_102[0]
        getitem_949 = native_batch_norm_backward_default_102[1]
        getitem_950 = native_batch_norm_backward_default_102[2];  native_batch_norm_backward_default_102 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(getitem_948, relu__default_1, primals_15, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_948 = primals_15 = None
        getitem_951 = convolution_backward_default_103[0]
        getitem_952 = convolution_backward_default_103[1];  convolution_backward_default_103 = None
        to_dtype_297 = torch.ops.aten.to.dtype(getitem_951, torch.float32);  getitem_951 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_204 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_204, to_dtype_297);  le_scalar_99 = new_zeros_default_204 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_299, convolution_default_1, primals_14, primals_12, primals_13, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_299 = convolution_default_1 = primals_14 = primals_12 = primals_13 = getitem_4 = getitem_5 = None
        getitem_954 = native_batch_norm_backward_default_103[0]
        getitem_955 = native_batch_norm_backward_default_103[1]
        getitem_956 = native_batch_norm_backward_default_103[2];  native_batch_norm_backward_default_103 = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(getitem_954, relu__default, primals_9, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_954 = primals_9 = None
        getitem_957 = convolution_backward_default_104[0]
        getitem_958 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        to_dtype_300 = torch.ops.aten.to.dtype(getitem_957, torch.float32);  getitem_957 = None
        to_dtype_301 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_100 = torch.ops.aten.le.Scalar(to_dtype_301, 0);  to_dtype_301 = None
        new_zeros_default_205 = torch.ops.aten.new_zeros.default(to_dtype_300, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_100 = torch.ops.aten.where.self(le_scalar_100, new_zeros_default_205, to_dtype_300);  le_scalar_100 = new_zeros_default_205 = to_dtype_300 = None
        to_dtype_302 = torch.ops.aten.to.dtype(where_self_100, torch.float32);  where_self_100 = None
        native_batch_norm_backward_default_104 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_302, convolution_default, primals_6, primals_4, primals_5, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_302 = convolution_default = primals_6 = primals_4 = primals_5 = getitem_1 = getitem_2 = None
        getitem_960 = native_batch_norm_backward_default_104[0]
        getitem_961 = native_batch_norm_backward_default_104[1]
        getitem_962 = native_batch_norm_backward_default_104[2];  native_batch_norm_backward_default_104 = None
        convolution_backward_default_105 = torch.ops.aten.convolution_backward.default(getitem_960, primals_633, primals_1, [0], [1, 1], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_960 = primals_633 = primals_1 = None
        getitem_964 = convolution_backward_default_105[1];  convolution_backward_default_105 = None
        return [getitem_964, getitem_962, None, None, None, getitem_961, getitem_335, getitem_334, getitem_958, getitem_956, None, None, None, getitem_955, getitem_952, getitem_950, None, None, None, getitem_949, getitem_946, getitem_944, None, None, None, getitem_943, getitem_902, None, None, None, getitem_901, getitem_904, getitem_938, None, None, None, getitem_937, getitem_932, None, None, None, getitem_931, getitem_926, None, None, None, getitem_925, getitem_940, getitem_934, getitem_928, getitem_920, None, None, None, getitem_919, getitem_914, None, None, None, getitem_913, getitem_908, None, None, None, getitem_907, getitem_922, getitem_916, getitem_910, getitem_898, getitem_896, None, None, None, getitem_895, getitem_854, None, None, None, getitem_853, getitem_856, getitem_890, None, None, None, getitem_889, getitem_884, None, None, None, getitem_883, getitem_878, None, None, None, getitem_877, getitem_892, getitem_886, getitem_880, getitem_872, None, None, None, getitem_871, getitem_866, None, None, None, getitem_865, getitem_860, None, None, None, getitem_859, getitem_874, getitem_868, getitem_862, getitem_812, None, None, None, getitem_811, getitem_814, getitem_848, None, None, None, getitem_847, getitem_842, None, None, None, getitem_841, getitem_836, None, None, None, getitem_835, getitem_850, getitem_844, getitem_838, getitem_830, None, None, None, getitem_829, getitem_824, None, None, None, getitem_823, getitem_818, None, None, None, getitem_817, getitem_832, getitem_826, getitem_820, getitem_770, None, None, None, getitem_769, getitem_772, getitem_806, None, None, None, getitem_805, getitem_800, None, None, None, getitem_799, getitem_794, None, None, None, getitem_793, getitem_808, getitem_802, getitem_796, getitem_788, None, None, None, getitem_787, getitem_782, None, None, None, getitem_781, getitem_776, None, None, None, getitem_775, getitem_790, getitem_784, getitem_778, getitem_728, None, None, None, getitem_727, getitem_730, getitem_764, None, None, None, getitem_763, getitem_758, None, None, None, getitem_757, getitem_752, None, None, None, getitem_751, getitem_766, getitem_760, getitem_754, getitem_746, None, None, None, getitem_745, getitem_740, None, None, None, getitem_739, getitem_734, None, None, None, getitem_733, getitem_748, getitem_742, getitem_736, getitem_724, getitem_722, None, None, None, getitem_721, getitem_680, None, None, None, getitem_679, getitem_682, getitem_716, None, None, None, getitem_715, getitem_710, None, None, None, getitem_709, getitem_704, None, None, None, getitem_703, getitem_718, getitem_712, getitem_706, getitem_698, None, None, None, getitem_697, getitem_692, None, None, None, getitem_691, getitem_686, None, None, None, getitem_685, getitem_700, getitem_694, getitem_688, getitem_638, None, None, None, getitem_637, getitem_640, getitem_674, None, None, None, getitem_673, getitem_668, None, None, None, getitem_667, getitem_662, None, None, None, getitem_661, getitem_676, getitem_670, getitem_664, getitem_656, None, None, None, getitem_655, getitem_650, None, None, None, getitem_649, getitem_644, None, None, None, getitem_643, getitem_658, getitem_652, getitem_646, getitem_596, None, None, None, getitem_595, getitem_598, getitem_632, None, None, None, getitem_631, getitem_626, None, None, None, getitem_625, getitem_620, None, None, None, getitem_619, getitem_634, getitem_628, getitem_622, getitem_614, None, None, None, getitem_613, getitem_608, None, None, None, getitem_607, getitem_602, None, None, None, getitem_601, getitem_616, getitem_610, getitem_604, getitem_554, None, None, None, getitem_553, getitem_556, getitem_590, None, None, None, getitem_589, getitem_584, None, None, None, getitem_583, getitem_578, None, None, None, getitem_577, getitem_592, getitem_586, getitem_580, getitem_572, None, None, None, getitem_571, getitem_566, None, None, None, getitem_565, getitem_560, None, None, None, getitem_559, getitem_574, getitem_568, getitem_562, getitem_512, None, None, None, getitem_511, getitem_514, getitem_548, None, None, None, getitem_547, getitem_542, None, None, None, getitem_541, getitem_536, None, None, None, getitem_535, getitem_550, getitem_544, getitem_538, getitem_530, None, None, None, getitem_529, getitem_524, None, None, None, getitem_523, getitem_518, None, None, None, getitem_517, getitem_532, getitem_526, getitem_520, getitem_470, None, None, None, getitem_469, getitem_472, getitem_506, None, None, None, getitem_505, getitem_500, None, None, None, getitem_499, getitem_494, None, None, None, getitem_493, getitem_508, getitem_502, getitem_496, getitem_488, None, None, None, getitem_487, getitem_482, None, None, None, getitem_481, getitem_476, None, None, None, getitem_475, getitem_490, getitem_484, getitem_478, getitem_428, None, None, None, getitem_427, getitem_430, getitem_464, None, None, None, getitem_463, getitem_458, None, None, None, getitem_457, getitem_452, None, None, None, getitem_451, getitem_466, getitem_460, getitem_454, getitem_446, None, None, None, getitem_445, getitem_440, None, None, None, getitem_439, getitem_434, None, None, None, getitem_433, getitem_448, getitem_442, getitem_436, getitem_386, None, None, None, getitem_385, getitem_388, getitem_422, None, None, None, getitem_421, getitem_416, None, None, None, getitem_415, getitem_410, None, None, None, getitem_409, getitem_424, getitem_418, getitem_412, getitem_404, None, None, None, getitem_403, getitem_398, None, None, None, getitem_397, getitem_392, None, None, None, getitem_391, getitem_406, getitem_400, getitem_394, getitem_382, getitem_380, None, None, None, getitem_379, getitem_338, None, None, None, getitem_337, getitem_340, getitem_374, None, None, None, getitem_373, getitem_368, None, None, None, getitem_367, getitem_362, None, None, None, getitem_361, getitem_376, getitem_370, getitem_364, getitem_356, None, None, None, getitem_355, getitem_350, None, None, None, getitem_349, getitem_344, None, None, None, getitem_343, getitem_358, getitem_352, getitem_346, None]
        
