
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/vit_base_patch16_224/vit_base_patch16_224_backward_0/state_dict.pt'))

    
    
    def forward(self, getitem_83, _unsafe_view_default_24, view_default_45, getitem_82, primals_69, t_default_36, view_default_99, _softmax_default_4, _unsafe_view_default_30, view_default_55, primals_24, primals_23, primals_71, _unsafe_view_default_25, add_tensor_11, primals_22, _unsafe_view_default_27, primals_35, t_default_37, primals_34, _softmax_default_5, primals_70, primals_21, add_tensor_20, view_default_44, view_default_94, primals_33, _unsafe_view_default_31, view_default_47, primals_60, view_default_95, add_tensor_19, primals_72, view_default_54, t_default_17, add_tensor_9, _unsafe_view_default_33, primals_48, primals_57, _unsafe_view_default_6, _unsafe_view_default_39, primals_149, view_default_118, getitem_16, view_default_7, view_default_97, getitem_88, primals_58, getitem_28, getitem_17, view_default_15, view_default_64, t_default_27, getitem_89, view_default_17, getitem_29, primals_148, t_default_47, view_default_71, primals_59, view_default_31, getitem_64, primals_36, _softmax_default_1, t_default_38, primals_143, t_default_6, getitem_65, getitem_109, view_default_98, view_default_18, t_default_12, _unsafe_view_default_7, getitem_110, t_default_48, _unsafe_view_default_51, t_default_25, _unsafe_view_default_60, _unsafe_view_default_9, getitem_61, t_default_28, view_default_79, view_default_19, select_int, primals_151, t_default_39, view_default_35, _softmax_default_10, getitem_62, primals_46, primals_144, add_tensor_13, view_default_14, view_default_67, _unsafe_view_default_43, primals_47, getitem_91, t_default_7, add_tensor_16, view_default_101, t_default_5, _unsafe_view_default_42, getitem_92, add_tensor_4, _unsafe_view_default_18, view_default_21, _softmax_default_3, t_default_26, _unsafe_view_default, _softmax_default_7, t_default_40, view_default_74, primals_142, primals_45, _unsafe_view_default_61, _unsafe_view_default_67, view_default_75, add_tensor_3, getitem_19, view_default_68, getitem_20, getitem_98, _unsafe_view_default_19, _unsafe_view_default_21, t_default_8, t_default_42, _unsafe_view_default_66, t_default_21, t_default_33, view_default_108, getitem_52, _unsafe_view_default_12, view_default_34, view_default_87, getitem_80, _softmax_default_11, getitem_79, getitem_53, _unsafe_view_default_69, view_default_57, primals_141, t_default_43, view_default_25, t_default_34, t_default_22, view_default_88, view_default_111, _softmax_default_2, t_default_13, view_default_58, getitem_101, getitem_34, getitem_100, _unsafe_view_default_55, add_tensor_24, _unsafe_view_default_13, getitem_35, _unsafe_view_default_54, view_default_59, view_default_24, add_tensor_7, t_default_35, t_default_44, view_default_37, _softmax_default_9, view_default_115, view_default_91, add_tensor_12, view_default_119, t_default_23, t_default_14, view_default_8, view_default_5, getitem_8, primals_130, view_default_9, view_default_11, primals_120, t_default_3, getitem_10, t_default_11, getitem_11, add_tensor_2, view_default_1, t_default_4, primals_129, primals_131, t_default_31, primals_119, t_default_29, primals_117, view_default_77, getitem_71, getitem_70, t_default_30, primals_132, view_default_78, _unsafe_view_default_3, _softmax_default_8, primals_118, _unsafe_view_default_49, getitem_7, getitem_55, getitem_44, primals_94, getitem_43, getitem_56, add_tensor_15, primals_84, view_default_61, getitem_2, t_default_18, primals_95, view_default_48, getitem_1, t_default_24, view_default_69, view_default_49, _unsafe_view_default_36, view_default_65, primals_83, t_default_19, add_tensor_14, _unsafe_view_default_37, primals_81, primals_82, t_default, getitem_46, primals_93, getitem_47, add_tensor_10, _softmax_default_6, view_default_51, t_default_20, _unsafe_view_default_1, view_default_89, view_default_81, getitem_73, getitem_74, primals_12, view_default_114, _unsafe_view_default_57, t_default_32, _unsafe_view_default_63, primals_9, primals_10, primals_108, primals_105, _unsafe_view_default_48, add_tensor_17, primals_11, t_default_45, getitem_106, view_default_117, primals_106, getitem_107, add_tensor_23, primals_107, view_default_4, view_default_84, view_default_85, add_tensor_18, t_default_46, _unsafe_view_default_15, view_default_38, t_default_1, view_default_39, add_tensor_1, view_default_109, view_default_41, t_default_9, getitem_25, t_default_15, add_tensor_22, view_default_104, getitem_26, add_tensor_5, getitem_37, view_default_27, getitem_38, _softmax_default, add_tensor_8, t_default_10, primals_96, view_default_28, t_default_16, view_default_105, _unsafe_view_default_45, getitem_97, view_default_107, t_default_2, add_tensor_6, t_default_41, add_tensor, add_tensor_21, view_default_29, primals_153, tangents_1):
        t_default_49 = torch.ops.aten.t.default(t_default_48);  t_default_48 = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_49);  t_default_49 = None
        t_default_50 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_50, select_int);  t_default_50 = select_int = None
        t_default_51 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_121 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_52 = torch.ops.aten.t.default(t_default_51);  t_default_51 = None
        select_backward_default = torch.ops.aten.select_backward.default(mm_default, [128, 197, 768], 1, 0);  mm_default = None
        slice_backward_default = torch.ops.aten.slice_backward.default(select_backward_default, [128, 197, 768], 0, 0, 9223372036854775807, 1);  select_backward_default = None
        native_layer_norm_backward_default = torch.ops.aten.native_layer_norm_backward.default(slice_backward_default, add_tensor_24, [768], getitem_109, getitem_110, primals_149, primals_148, [True, True, True]);  slice_backward_default = add_tensor_24 = getitem_109 = getitem_110 = primals_149 = primals_148 = None
        getitem_111 = native_layer_norm_backward_default[0]
        getitem_112 = native_layer_norm_backward_default[1]
        getitem_113 = native_layer_norm_backward_default[2];  native_layer_norm_backward_default = None
        view_default_122 = torch.ops.aten.view.default(getitem_111, [25216, 768])
        t_default_53 = torch.ops.aten.t.default(t_default_47);  t_default_47 = None
        mm_default_2 = torch.ops.aten.mm.default(view_default_122, t_default_53);  t_default_53 = None
        t_default_54 = torch.ops.aten.t.default(view_default_122)
        mm_default_3 = torch.ops.aten.mm.default(t_default_54, view_default_119);  t_default_54 = view_default_119 = None
        t_default_55 = torch.ops.aten.t.default(mm_default_3);  mm_default_3 = None
        sum_dim_int_list_1 = torch.ops.aten.sum.dim_IntList(view_default_122, [0], True);  view_default_122 = None
        view_default_123 = torch.ops.aten.view.default(sum_dim_int_list_1, [768]);  sum_dim_int_list_1 = None
        t_default_56 = torch.ops.aten.t.default(t_default_55);  t_default_55 = None
        view_default_124 = torch.ops.aten.view.default(mm_default_2, [128, 197, 3072]);  mm_default_2 = None
        to_dtype = torch.ops.aten.to.dtype(view_default_124, torch.float32);  view_default_124 = None
        to_dtype_1 = torch.ops.aten.to.dtype(view_default_118, torch.float32);  view_default_118 = None
        mul_tensor_12 = torch.ops.aten.mul.Tensor(to_dtype_1, 0.7071067811865476)
        erf_default = torch.ops.aten.erf.default(mul_tensor_12);  mul_tensor_12 = None
        add_tensor_25 = torch.ops.aten.add.Tensor(erf_default, 1);  erf_default = None
        mul_tensor_13 = torch.ops.aten.mul.Tensor(add_tensor_25, 0.5);  add_tensor_25 = None
        mul_tensor_14 = torch.ops.aten.mul.Tensor(to_dtype_1, to_dtype_1)
        mul_tensor_15 = torch.ops.aten.mul.Tensor(mul_tensor_14, -0.5);  mul_tensor_14 = None
        exp_default = torch.ops.aten.exp.default(mul_tensor_15);  mul_tensor_15 = None
        mul_tensor_16 = torch.ops.aten.mul.Tensor(exp_default, 0.3989422804014327);  exp_default = None
        mul_tensor_17 = torch.ops.aten.mul.Tensor(to_dtype_1, mul_tensor_16);  to_dtype_1 = mul_tensor_16 = None
        add_tensor_26 = torch.ops.aten.add.Tensor(mul_tensor_13, mul_tensor_17);  mul_tensor_13 = mul_tensor_17 = None
        mul_tensor_18 = torch.ops.aten.mul.Tensor(to_dtype, add_tensor_26);  to_dtype = add_tensor_26 = None
        to_dtype_2 = torch.ops.aten.to.dtype(mul_tensor_18, torch.float32);  mul_tensor_18 = None
        view_default_125 = torch.ops.aten.view.default(to_dtype_2, [25216, 3072]);  to_dtype_2 = None
        t_default_57 = torch.ops.aten.t.default(t_default_46);  t_default_46 = None
        mm_default_4 = torch.ops.aten.mm.default(view_default_125, t_default_57);  t_default_57 = None
        t_default_58 = torch.ops.aten.t.default(view_default_125)
        mm_default_5 = torch.ops.aten.mm.default(t_default_58, view_default_117);  t_default_58 = view_default_117 = None
        t_default_59 = torch.ops.aten.t.default(mm_default_5);  mm_default_5 = None
        sum_dim_int_list_2 = torch.ops.aten.sum.dim_IntList(view_default_125, [0], True);  view_default_125 = None
        view_default_126 = torch.ops.aten.view.default(sum_dim_int_list_2, [3072]);  sum_dim_int_list_2 = None
        t_default_60 = torch.ops.aten.t.default(t_default_59);  t_default_59 = None
        view_default_127 = torch.ops.aten.view.default(mm_default_4, [128, 197, 768]);  mm_default_4 = None
        native_layer_norm_backward_default_1 = torch.ops.aten.native_layer_norm_backward.default(view_default_127, add_tensor_23, [768], getitem_106, getitem_107, primals_36, primals_35, [True, True, True]);  view_default_127 = add_tensor_23 = getitem_106 = getitem_107 = primals_36 = primals_35 = None
        getitem_114 = native_layer_norm_backward_default_1[0]
        getitem_115 = native_layer_norm_backward_default_1[1]
        getitem_116 = native_layer_norm_backward_default_1[2];  native_layer_norm_backward_default_1 = None
        add_tensor_27 = torch.ops.aten.add.Tensor(getitem_111, getitem_114);  getitem_111 = getitem_114 = None
        view_default_128 = torch.ops.aten.view.default(add_tensor_27, [25216, 768])
        t_default_61 = torch.ops.aten.t.default(t_default_45);  t_default_45 = None
        mm_default_6 = torch.ops.aten.mm.default(view_default_128, t_default_61);  t_default_61 = None
        t_default_62 = torch.ops.aten.t.default(view_default_128)
        mm_default_7 = torch.ops.aten.mm.default(t_default_62, view_default_115);  t_default_62 = view_default_115 = None
        t_default_63 = torch.ops.aten.t.default(mm_default_7);  mm_default_7 = None
        sum_dim_int_list_3 = torch.ops.aten.sum.dim_IntList(view_default_128, [0], True);  view_default_128 = None
        view_default_129 = torch.ops.aten.view.default(sum_dim_int_list_3, [768]);  sum_dim_int_list_3 = None
        t_default_64 = torch.ops.aten.t.default(t_default_63);  t_default_63 = None
        view_default_130 = torch.ops.aten.view.default(mm_default_6, [128, 197, 768]);  mm_default_6 = None
        view_default_131 = torch.ops.aten.view.default(view_default_130, [128, 197, 12, 64]);  view_default_130 = None
        transpose_int_25 = torch.ops.aten.transpose.int(view_default_131, 1, 2);  view_default_131 = None
        clone_default_48 = torch.ops.aten.clone.default(transpose_int_25, memory_format = torch.contiguous_format);  transpose_int_25 = None
        _unsafe_view_default_72 = torch.ops.aten._unsafe_view.default(clone_default_48, [1536, 197, 64]);  clone_default_48 = None
        transpose_int_26 = torch.ops.aten.transpose.int(view_default_114, 1, 2);  view_default_114 = None
        bmm_default_24 = torch.ops.aten.bmm.default(transpose_int_26, _unsafe_view_default_72);  transpose_int_26 = None
        transpose_int_27 = torch.ops.aten.transpose.int(_unsafe_view_default_69, 1, 2);  _unsafe_view_default_69 = None
        bmm_default_25 = torch.ops.aten.bmm.default(_unsafe_view_default_72, transpose_int_27);  _unsafe_view_default_72 = transpose_int_27 = None
        view_default_132 = torch.ops.aten.view.default(bmm_default_24, [128, 12, 197, 64]);  bmm_default_24 = None
        view_default_133 = torch.ops.aten.view.default(bmm_default_25, [128, 12, 197, 197]);  bmm_default_25 = None
        _softmax_backward_data_default = torch.ops.aten._softmax_backward_data.default(view_default_133, _softmax_default_11, -1, torch.float32);  view_default_133 = _softmax_default_11 = None
        mul_tensor_19 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default, 0.125);  _softmax_backward_data_default = None
        view_default_134 = torch.ops.aten.view.default(mul_tensor_19, [1536, 197, 197]);  mul_tensor_19 = None
        transpose_int_28 = torch.ops.aten.transpose.int(_unsafe_view_default_66, 1, 2);  _unsafe_view_default_66 = None
        bmm_default_26 = torch.ops.aten.bmm.default(transpose_int_28, view_default_134);  transpose_int_28 = None
        transpose_int_29 = torch.ops.aten.transpose.int(_unsafe_view_default_67, 1, 2);  _unsafe_view_default_67 = None
        bmm_default_27 = torch.ops.aten.bmm.default(view_default_134, transpose_int_29);  view_default_134 = transpose_int_29 = None
        view_default_135 = torch.ops.aten.view.default(bmm_default_26, [128, 12, 64, 197]);  bmm_default_26 = None
        view_default_136 = torch.ops.aten.view.default(bmm_default_27, [128, 12, 197, 64]);  bmm_default_27 = None
        transpose_int_30 = torch.ops.aten.transpose.int(view_default_135, -2, -1);  view_default_135 = None
        stack_default = torch.ops.aten.stack.default([view_default_136, transpose_int_30, view_default_132]);  view_default_136 = transpose_int_30 = view_default_132 = None
        permute_default_12 = torch.ops.aten.permute.default(stack_default, [1, 3, 0, 2, 4]);  stack_default = None
        clone_default_49 = torch.ops.aten.clone.default(permute_default_12, memory_format = torch.contiguous_format);  permute_default_12 = None
        _unsafe_view_default_73 = torch.ops.aten._unsafe_view.default(clone_default_49, [128, 197, 2304]);  clone_default_49 = None
        view_default_137 = torch.ops.aten.view.default(_unsafe_view_default_73, [25216, 2304]);  _unsafe_view_default_73 = None
        t_default_65 = torch.ops.aten.t.default(t_default_44);  t_default_44 = None
        mm_default_8 = torch.ops.aten.mm.default(view_default_137, t_default_65);  t_default_65 = None
        t_default_66 = torch.ops.aten.t.default(view_default_137)
        mm_default_9 = torch.ops.aten.mm.default(t_default_66, view_default_111);  t_default_66 = view_default_111 = None
        t_default_67 = torch.ops.aten.t.default(mm_default_9);  mm_default_9 = None
        sum_dim_int_list_4 = torch.ops.aten.sum.dim_IntList(view_default_137, [0], True);  view_default_137 = None
        view_default_138 = torch.ops.aten.view.default(sum_dim_int_list_4, [2304]);  sum_dim_int_list_4 = None
        t_default_68 = torch.ops.aten.t.default(t_default_67);  t_default_67 = None
        view_default_139 = torch.ops.aten.view.default(mm_default_8, [128, 197, 768]);  mm_default_8 = None
        native_layer_norm_backward_default_2 = torch.ops.aten.native_layer_norm_backward.default(view_default_139, add_tensor_22, [768], getitem_100, getitem_101, primals_34, primals_33, [True, True, True]);  view_default_139 = add_tensor_22 = getitem_100 = getitem_101 = primals_34 = primals_33 = None
        getitem_117 = native_layer_norm_backward_default_2[0]
        getitem_118 = native_layer_norm_backward_default_2[1]
        getitem_119 = native_layer_norm_backward_default_2[2];  native_layer_norm_backward_default_2 = None
        add_tensor_28 = torch.ops.aten.add.Tensor(add_tensor_27, getitem_117);  add_tensor_27 = getitem_117 = None
        view_default_140 = torch.ops.aten.view.default(add_tensor_28, [25216, 768])
        t_default_69 = torch.ops.aten.t.default(t_default_43);  t_default_43 = None
        mm_default_10 = torch.ops.aten.mm.default(view_default_140, t_default_69);  t_default_69 = None
        t_default_70 = torch.ops.aten.t.default(view_default_140)
        mm_default_11 = torch.ops.aten.mm.default(t_default_70, view_default_109);  t_default_70 = view_default_109 = None
        t_default_71 = torch.ops.aten.t.default(mm_default_11);  mm_default_11 = None
        sum_dim_int_list_5 = torch.ops.aten.sum.dim_IntList(view_default_140, [0], True);  view_default_140 = None
        view_default_141 = torch.ops.aten.view.default(sum_dim_int_list_5, [768]);  sum_dim_int_list_5 = None
        t_default_72 = torch.ops.aten.t.default(t_default_71);  t_default_71 = None
        view_default_142 = torch.ops.aten.view.default(mm_default_10, [128, 197, 3072]);  mm_default_10 = None
        to_dtype_3 = torch.ops.aten.to.dtype(view_default_142, torch.float32);  view_default_142 = None
        to_dtype_4 = torch.ops.aten.to.dtype(view_default_108, torch.float32);  view_default_108 = None
        mul_tensor_20 = torch.ops.aten.mul.Tensor(to_dtype_4, 0.7071067811865476)
        erf_default_1 = torch.ops.aten.erf.default(mul_tensor_20);  mul_tensor_20 = None
        add_tensor_29 = torch.ops.aten.add.Tensor(erf_default_1, 1);  erf_default_1 = None
        mul_tensor_21 = torch.ops.aten.mul.Tensor(add_tensor_29, 0.5);  add_tensor_29 = None
        mul_tensor_22 = torch.ops.aten.mul.Tensor(to_dtype_4, to_dtype_4)
        mul_tensor_23 = torch.ops.aten.mul.Tensor(mul_tensor_22, -0.5);  mul_tensor_22 = None
        exp_default_1 = torch.ops.aten.exp.default(mul_tensor_23);  mul_tensor_23 = None
        mul_tensor_24 = torch.ops.aten.mul.Tensor(exp_default_1, 0.3989422804014327);  exp_default_1 = None
        mul_tensor_25 = torch.ops.aten.mul.Tensor(to_dtype_4, mul_tensor_24);  to_dtype_4 = mul_tensor_24 = None
        add_tensor_30 = torch.ops.aten.add.Tensor(mul_tensor_21, mul_tensor_25);  mul_tensor_21 = mul_tensor_25 = None
        mul_tensor_26 = torch.ops.aten.mul.Tensor(to_dtype_3, add_tensor_30);  to_dtype_3 = add_tensor_30 = None
        to_dtype_5 = torch.ops.aten.to.dtype(mul_tensor_26, torch.float32);  mul_tensor_26 = None
        view_default_143 = torch.ops.aten.view.default(to_dtype_5, [25216, 3072]);  to_dtype_5 = None
        t_default_73 = torch.ops.aten.t.default(t_default_42);  t_default_42 = None
        mm_default_12 = torch.ops.aten.mm.default(view_default_143, t_default_73);  t_default_73 = None
        t_default_74 = torch.ops.aten.t.default(view_default_143)
        mm_default_13 = torch.ops.aten.mm.default(t_default_74, view_default_107);  t_default_74 = view_default_107 = None
        t_default_75 = torch.ops.aten.t.default(mm_default_13);  mm_default_13 = None
        sum_dim_int_list_6 = torch.ops.aten.sum.dim_IntList(view_default_143, [0], True);  view_default_143 = None
        view_default_144 = torch.ops.aten.view.default(sum_dim_int_list_6, [3072]);  sum_dim_int_list_6 = None
        t_default_76 = torch.ops.aten.t.default(t_default_75);  t_default_75 = None
        view_default_145 = torch.ops.aten.view.default(mm_default_12, [128, 197, 768]);  mm_default_12 = None
        native_layer_norm_backward_default_3 = torch.ops.aten.native_layer_norm_backward.default(view_default_145, add_tensor_21, [768], getitem_97, getitem_98, primals_24, primals_23, [True, True, True]);  view_default_145 = add_tensor_21 = getitem_97 = getitem_98 = primals_24 = primals_23 = None
        getitem_120 = native_layer_norm_backward_default_3[0]
        getitem_121 = native_layer_norm_backward_default_3[1]
        getitem_122 = native_layer_norm_backward_default_3[2];  native_layer_norm_backward_default_3 = None
        add_tensor_31 = torch.ops.aten.add.Tensor(add_tensor_28, getitem_120);  add_tensor_28 = getitem_120 = None
        view_default_146 = torch.ops.aten.view.default(add_tensor_31, [25216, 768])
        t_default_77 = torch.ops.aten.t.default(t_default_41);  t_default_41 = None
        mm_default_14 = torch.ops.aten.mm.default(view_default_146, t_default_77);  t_default_77 = None
        t_default_78 = torch.ops.aten.t.default(view_default_146)
        mm_default_15 = torch.ops.aten.mm.default(t_default_78, view_default_105);  t_default_78 = view_default_105 = None
        t_default_79 = torch.ops.aten.t.default(mm_default_15);  mm_default_15 = None
        sum_dim_int_list_7 = torch.ops.aten.sum.dim_IntList(view_default_146, [0], True);  view_default_146 = None
        view_default_147 = torch.ops.aten.view.default(sum_dim_int_list_7, [768]);  sum_dim_int_list_7 = None
        t_default_80 = torch.ops.aten.t.default(t_default_79);  t_default_79 = None
        view_default_148 = torch.ops.aten.view.default(mm_default_14, [128, 197, 768]);  mm_default_14 = None
        view_default_149 = torch.ops.aten.view.default(view_default_148, [128, 197, 12, 64]);  view_default_148 = None
        transpose_int_31 = torch.ops.aten.transpose.int(view_default_149, 1, 2);  view_default_149 = None
        clone_default_50 = torch.ops.aten.clone.default(transpose_int_31, memory_format = torch.contiguous_format);  transpose_int_31 = None
        _unsafe_view_default_74 = torch.ops.aten._unsafe_view.default(clone_default_50, [1536, 197, 64]);  clone_default_50 = None
        transpose_int_32 = torch.ops.aten.transpose.int(view_default_104, 1, 2);  view_default_104 = None
        bmm_default_28 = torch.ops.aten.bmm.default(transpose_int_32, _unsafe_view_default_74);  transpose_int_32 = None
        transpose_int_33 = torch.ops.aten.transpose.int(_unsafe_view_default_63, 1, 2);  _unsafe_view_default_63 = None
        bmm_default_29 = torch.ops.aten.bmm.default(_unsafe_view_default_74, transpose_int_33);  _unsafe_view_default_74 = transpose_int_33 = None
        view_default_150 = torch.ops.aten.view.default(bmm_default_28, [128, 12, 197, 64]);  bmm_default_28 = None
        view_default_151 = torch.ops.aten.view.default(bmm_default_29, [128, 12, 197, 197]);  bmm_default_29 = None
        _softmax_backward_data_default_1 = torch.ops.aten._softmax_backward_data.default(view_default_151, _softmax_default_10, -1, torch.float32);  view_default_151 = _softmax_default_10 = None
        mul_tensor_27 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_1, 0.125);  _softmax_backward_data_default_1 = None
        view_default_152 = torch.ops.aten.view.default(mul_tensor_27, [1536, 197, 197]);  mul_tensor_27 = None
        transpose_int_34 = torch.ops.aten.transpose.int(_unsafe_view_default_60, 1, 2);  _unsafe_view_default_60 = None
        bmm_default_30 = torch.ops.aten.bmm.default(transpose_int_34, view_default_152);  transpose_int_34 = None
        transpose_int_35 = torch.ops.aten.transpose.int(_unsafe_view_default_61, 1, 2);  _unsafe_view_default_61 = None
        bmm_default_31 = torch.ops.aten.bmm.default(view_default_152, transpose_int_35);  view_default_152 = transpose_int_35 = None
        view_default_153 = torch.ops.aten.view.default(bmm_default_30, [128, 12, 64, 197]);  bmm_default_30 = None
        view_default_154 = torch.ops.aten.view.default(bmm_default_31, [128, 12, 197, 64]);  bmm_default_31 = None
        transpose_int_36 = torch.ops.aten.transpose.int(view_default_153, -2, -1);  view_default_153 = None
        stack_default_1 = torch.ops.aten.stack.default([view_default_154, transpose_int_36, view_default_150]);  view_default_154 = transpose_int_36 = view_default_150 = None
        permute_default_13 = torch.ops.aten.permute.default(stack_default_1, [1, 3, 0, 2, 4]);  stack_default_1 = None
        clone_default_51 = torch.ops.aten.clone.default(permute_default_13, memory_format = torch.contiguous_format);  permute_default_13 = None
        _unsafe_view_default_75 = torch.ops.aten._unsafe_view.default(clone_default_51, [128, 197, 2304]);  clone_default_51 = None
        view_default_155 = torch.ops.aten.view.default(_unsafe_view_default_75, [25216, 2304]);  _unsafe_view_default_75 = None
        t_default_81 = torch.ops.aten.t.default(t_default_40);  t_default_40 = None
        mm_default_16 = torch.ops.aten.mm.default(view_default_155, t_default_81);  t_default_81 = None
        t_default_82 = torch.ops.aten.t.default(view_default_155)
        mm_default_17 = torch.ops.aten.mm.default(t_default_82, view_default_101);  t_default_82 = view_default_101 = None
        t_default_83 = torch.ops.aten.t.default(mm_default_17);  mm_default_17 = None
        sum_dim_int_list_8 = torch.ops.aten.sum.dim_IntList(view_default_155, [0], True);  view_default_155 = None
        view_default_156 = torch.ops.aten.view.default(sum_dim_int_list_8, [2304]);  sum_dim_int_list_8 = None
        t_default_84 = torch.ops.aten.t.default(t_default_83);  t_default_83 = None
        view_default_157 = torch.ops.aten.view.default(mm_default_16, [128, 197, 768]);  mm_default_16 = None
        native_layer_norm_backward_default_4 = torch.ops.aten.native_layer_norm_backward.default(view_default_157, add_tensor_20, [768], getitem_91, getitem_92, primals_22, primals_21, [True, True, True]);  view_default_157 = add_tensor_20 = getitem_91 = getitem_92 = primals_22 = primals_21 = None
        getitem_123 = native_layer_norm_backward_default_4[0]
        getitem_124 = native_layer_norm_backward_default_4[1]
        getitem_125 = native_layer_norm_backward_default_4[2];  native_layer_norm_backward_default_4 = None
        add_tensor_32 = torch.ops.aten.add.Tensor(add_tensor_31, getitem_123);  add_tensor_31 = getitem_123 = None
        view_default_158 = torch.ops.aten.view.default(add_tensor_32, [25216, 768])
        t_default_85 = torch.ops.aten.t.default(t_default_39);  t_default_39 = None
        mm_default_18 = torch.ops.aten.mm.default(view_default_158, t_default_85);  t_default_85 = None
        t_default_86 = torch.ops.aten.t.default(view_default_158)
        mm_default_19 = torch.ops.aten.mm.default(t_default_86, view_default_99);  t_default_86 = view_default_99 = None
        t_default_87 = torch.ops.aten.t.default(mm_default_19);  mm_default_19 = None
        sum_dim_int_list_9 = torch.ops.aten.sum.dim_IntList(view_default_158, [0], True);  view_default_158 = None
        view_default_159 = torch.ops.aten.view.default(sum_dim_int_list_9, [768]);  sum_dim_int_list_9 = None
        t_default_88 = torch.ops.aten.t.default(t_default_87);  t_default_87 = None
        view_default_160 = torch.ops.aten.view.default(mm_default_18, [128, 197, 3072]);  mm_default_18 = None
        to_dtype_6 = torch.ops.aten.to.dtype(view_default_160, torch.float32);  view_default_160 = None
        to_dtype_7 = torch.ops.aten.to.dtype(view_default_98, torch.float32);  view_default_98 = None
        mul_tensor_28 = torch.ops.aten.mul.Tensor(to_dtype_7, 0.7071067811865476)
        erf_default_2 = torch.ops.aten.erf.default(mul_tensor_28);  mul_tensor_28 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(erf_default_2, 1);  erf_default_2 = None
        mul_tensor_29 = torch.ops.aten.mul.Tensor(add_tensor_33, 0.5);  add_tensor_33 = None
        mul_tensor_30 = torch.ops.aten.mul.Tensor(to_dtype_7, to_dtype_7)
        mul_tensor_31 = torch.ops.aten.mul.Tensor(mul_tensor_30, -0.5);  mul_tensor_30 = None
        exp_default_2 = torch.ops.aten.exp.default(mul_tensor_31);  mul_tensor_31 = None
        mul_tensor_32 = torch.ops.aten.mul.Tensor(exp_default_2, 0.3989422804014327);  exp_default_2 = None
        mul_tensor_33 = torch.ops.aten.mul.Tensor(to_dtype_7, mul_tensor_32);  to_dtype_7 = mul_tensor_32 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(mul_tensor_29, mul_tensor_33);  mul_tensor_29 = mul_tensor_33 = None
        mul_tensor_34 = torch.ops.aten.mul.Tensor(to_dtype_6, add_tensor_34);  to_dtype_6 = add_tensor_34 = None
        to_dtype_8 = torch.ops.aten.to.dtype(mul_tensor_34, torch.float32);  mul_tensor_34 = None
        view_default_161 = torch.ops.aten.view.default(to_dtype_8, [25216, 3072]);  to_dtype_8 = None
        t_default_89 = torch.ops.aten.t.default(t_default_38);  t_default_38 = None
        mm_default_20 = torch.ops.aten.mm.default(view_default_161, t_default_89);  t_default_89 = None
        t_default_90 = torch.ops.aten.t.default(view_default_161)
        mm_default_21 = torch.ops.aten.mm.default(t_default_90, view_default_97);  t_default_90 = view_default_97 = None
        t_default_91 = torch.ops.aten.t.default(mm_default_21);  mm_default_21 = None
        sum_dim_int_list_10 = torch.ops.aten.sum.dim_IntList(view_default_161, [0], True);  view_default_161 = None
        view_default_162 = torch.ops.aten.view.default(sum_dim_int_list_10, [3072]);  sum_dim_int_list_10 = None
        t_default_92 = torch.ops.aten.t.default(t_default_91);  t_default_91 = None
        view_default_163 = torch.ops.aten.view.default(mm_default_20, [128, 197, 768]);  mm_default_20 = None
        native_layer_norm_backward_default_5 = torch.ops.aten.native_layer_norm_backward.default(view_default_163, add_tensor_19, [768], getitem_88, getitem_89, primals_144, primals_143, [True, True, True]);  view_default_163 = add_tensor_19 = getitem_88 = getitem_89 = primals_144 = primals_143 = None
        getitem_126 = native_layer_norm_backward_default_5[0]
        getitem_127 = native_layer_norm_backward_default_5[1]
        getitem_128 = native_layer_norm_backward_default_5[2];  native_layer_norm_backward_default_5 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(add_tensor_32, getitem_126);  add_tensor_32 = getitem_126 = None
        view_default_164 = torch.ops.aten.view.default(add_tensor_35, [25216, 768])
        t_default_93 = torch.ops.aten.t.default(t_default_37);  t_default_37 = None
        mm_default_22 = torch.ops.aten.mm.default(view_default_164, t_default_93);  t_default_93 = None
        t_default_94 = torch.ops.aten.t.default(view_default_164)
        mm_default_23 = torch.ops.aten.mm.default(t_default_94, view_default_95);  t_default_94 = view_default_95 = None
        t_default_95 = torch.ops.aten.t.default(mm_default_23);  mm_default_23 = None
        sum_dim_int_list_11 = torch.ops.aten.sum.dim_IntList(view_default_164, [0], True);  view_default_164 = None
        view_default_165 = torch.ops.aten.view.default(sum_dim_int_list_11, [768]);  sum_dim_int_list_11 = None
        t_default_96 = torch.ops.aten.t.default(t_default_95);  t_default_95 = None
        view_default_166 = torch.ops.aten.view.default(mm_default_22, [128, 197, 768]);  mm_default_22 = None
        view_default_167 = torch.ops.aten.view.default(view_default_166, [128, 197, 12, 64]);  view_default_166 = None
        transpose_int_37 = torch.ops.aten.transpose.int(view_default_167, 1, 2);  view_default_167 = None
        clone_default_52 = torch.ops.aten.clone.default(transpose_int_37, memory_format = torch.contiguous_format);  transpose_int_37 = None
        _unsafe_view_default_76 = torch.ops.aten._unsafe_view.default(clone_default_52, [1536, 197, 64]);  clone_default_52 = None
        transpose_int_38 = torch.ops.aten.transpose.int(view_default_94, 1, 2);  view_default_94 = None
        bmm_default_32 = torch.ops.aten.bmm.default(transpose_int_38, _unsafe_view_default_76);  transpose_int_38 = None
        transpose_int_39 = torch.ops.aten.transpose.int(_unsafe_view_default_57, 1, 2);  _unsafe_view_default_57 = None
        bmm_default_33 = torch.ops.aten.bmm.default(_unsafe_view_default_76, transpose_int_39);  _unsafe_view_default_76 = transpose_int_39 = None
        view_default_168 = torch.ops.aten.view.default(bmm_default_32, [128, 12, 197, 64]);  bmm_default_32 = None
        view_default_169 = torch.ops.aten.view.default(bmm_default_33, [128, 12, 197, 197]);  bmm_default_33 = None
        _softmax_backward_data_default_2 = torch.ops.aten._softmax_backward_data.default(view_default_169, _softmax_default_9, -1, torch.float32);  view_default_169 = _softmax_default_9 = None
        mul_tensor_35 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_2, 0.125);  _softmax_backward_data_default_2 = None
        view_default_170 = torch.ops.aten.view.default(mul_tensor_35, [1536, 197, 197]);  mul_tensor_35 = None
        transpose_int_40 = torch.ops.aten.transpose.int(_unsafe_view_default_54, 1, 2);  _unsafe_view_default_54 = None
        bmm_default_34 = torch.ops.aten.bmm.default(transpose_int_40, view_default_170);  transpose_int_40 = None
        transpose_int_41 = torch.ops.aten.transpose.int(_unsafe_view_default_55, 1, 2);  _unsafe_view_default_55 = None
        bmm_default_35 = torch.ops.aten.bmm.default(view_default_170, transpose_int_41);  view_default_170 = transpose_int_41 = None
        view_default_171 = torch.ops.aten.view.default(bmm_default_34, [128, 12, 64, 197]);  bmm_default_34 = None
        view_default_172 = torch.ops.aten.view.default(bmm_default_35, [128, 12, 197, 64]);  bmm_default_35 = None
        transpose_int_42 = torch.ops.aten.transpose.int(view_default_171, -2, -1);  view_default_171 = None
        stack_default_2 = torch.ops.aten.stack.default([view_default_172, transpose_int_42, view_default_168]);  view_default_172 = transpose_int_42 = view_default_168 = None
        permute_default_14 = torch.ops.aten.permute.default(stack_default_2, [1, 3, 0, 2, 4]);  stack_default_2 = None
        clone_default_53 = torch.ops.aten.clone.default(permute_default_14, memory_format = torch.contiguous_format);  permute_default_14 = None
        _unsafe_view_default_77 = torch.ops.aten._unsafe_view.default(clone_default_53, [128, 197, 2304]);  clone_default_53 = None
        view_default_173 = torch.ops.aten.view.default(_unsafe_view_default_77, [25216, 2304]);  _unsafe_view_default_77 = None
        t_default_97 = torch.ops.aten.t.default(t_default_36);  t_default_36 = None
        mm_default_24 = torch.ops.aten.mm.default(view_default_173, t_default_97);  t_default_97 = None
        t_default_98 = torch.ops.aten.t.default(view_default_173)
        mm_default_25 = torch.ops.aten.mm.default(t_default_98, view_default_91);  t_default_98 = view_default_91 = None
        t_default_99 = torch.ops.aten.t.default(mm_default_25);  mm_default_25 = None
        sum_dim_int_list_12 = torch.ops.aten.sum.dim_IntList(view_default_173, [0], True);  view_default_173 = None
        view_default_174 = torch.ops.aten.view.default(sum_dim_int_list_12, [2304]);  sum_dim_int_list_12 = None
        t_default_100 = torch.ops.aten.t.default(t_default_99);  t_default_99 = None
        view_default_175 = torch.ops.aten.view.default(mm_default_24, [128, 197, 768]);  mm_default_24 = None
        native_layer_norm_backward_default_6 = torch.ops.aten.native_layer_norm_backward.default(view_default_175, add_tensor_18, [768], getitem_82, getitem_83, primals_142, primals_141, [True, True, True]);  view_default_175 = add_tensor_18 = getitem_82 = getitem_83 = primals_142 = primals_141 = None
        getitem_129 = native_layer_norm_backward_default_6[0]
        getitem_130 = native_layer_norm_backward_default_6[1]
        getitem_131 = native_layer_norm_backward_default_6[2];  native_layer_norm_backward_default_6 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(add_tensor_35, getitem_129);  add_tensor_35 = getitem_129 = None
        view_default_176 = torch.ops.aten.view.default(add_tensor_36, [25216, 768])
        t_default_101 = torch.ops.aten.t.default(t_default_35);  t_default_35 = None
        mm_default_26 = torch.ops.aten.mm.default(view_default_176, t_default_101);  t_default_101 = None
        t_default_102 = torch.ops.aten.t.default(view_default_176)
        mm_default_27 = torch.ops.aten.mm.default(t_default_102, view_default_89);  t_default_102 = view_default_89 = None
        t_default_103 = torch.ops.aten.t.default(mm_default_27);  mm_default_27 = None
        sum_dim_int_list_13 = torch.ops.aten.sum.dim_IntList(view_default_176, [0], True);  view_default_176 = None
        view_default_177 = torch.ops.aten.view.default(sum_dim_int_list_13, [768]);  sum_dim_int_list_13 = None
        t_default_104 = torch.ops.aten.t.default(t_default_103);  t_default_103 = None
        view_default_178 = torch.ops.aten.view.default(mm_default_26, [128, 197, 3072]);  mm_default_26 = None
        to_dtype_9 = torch.ops.aten.to.dtype(view_default_178, torch.float32);  view_default_178 = None
        to_dtype_10 = torch.ops.aten.to.dtype(view_default_88, torch.float32);  view_default_88 = None
        mul_tensor_36 = torch.ops.aten.mul.Tensor(to_dtype_10, 0.7071067811865476)
        erf_default_3 = torch.ops.aten.erf.default(mul_tensor_36);  mul_tensor_36 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(erf_default_3, 1);  erf_default_3 = None
        mul_tensor_37 = torch.ops.aten.mul.Tensor(add_tensor_37, 0.5);  add_tensor_37 = None
        mul_tensor_38 = torch.ops.aten.mul.Tensor(to_dtype_10, to_dtype_10)
        mul_tensor_39 = torch.ops.aten.mul.Tensor(mul_tensor_38, -0.5);  mul_tensor_38 = None
        exp_default_3 = torch.ops.aten.exp.default(mul_tensor_39);  mul_tensor_39 = None
        mul_tensor_40 = torch.ops.aten.mul.Tensor(exp_default_3, 0.3989422804014327);  exp_default_3 = None
        mul_tensor_41 = torch.ops.aten.mul.Tensor(to_dtype_10, mul_tensor_40);  to_dtype_10 = mul_tensor_40 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(mul_tensor_37, mul_tensor_41);  mul_tensor_37 = mul_tensor_41 = None
        mul_tensor_42 = torch.ops.aten.mul.Tensor(to_dtype_9, add_tensor_38);  to_dtype_9 = add_tensor_38 = None
        to_dtype_11 = torch.ops.aten.to.dtype(mul_tensor_42, torch.float32);  mul_tensor_42 = None
        view_default_179 = torch.ops.aten.view.default(to_dtype_11, [25216, 3072]);  to_dtype_11 = None
        t_default_105 = torch.ops.aten.t.default(t_default_34);  t_default_34 = None
        mm_default_28 = torch.ops.aten.mm.default(view_default_179, t_default_105);  t_default_105 = None
        t_default_106 = torch.ops.aten.t.default(view_default_179)
        mm_default_29 = torch.ops.aten.mm.default(t_default_106, view_default_87);  t_default_106 = view_default_87 = None
        t_default_107 = torch.ops.aten.t.default(mm_default_29);  mm_default_29 = None
        sum_dim_int_list_14 = torch.ops.aten.sum.dim_IntList(view_default_179, [0], True);  view_default_179 = None
        view_default_180 = torch.ops.aten.view.default(sum_dim_int_list_14, [3072]);  sum_dim_int_list_14 = None
        t_default_108 = torch.ops.aten.t.default(t_default_107);  t_default_107 = None
        view_default_181 = torch.ops.aten.view.default(mm_default_28, [128, 197, 768]);  mm_default_28 = None
        native_layer_norm_backward_default_7 = torch.ops.aten.native_layer_norm_backward.default(view_default_181, add_tensor_17, [768], getitem_79, getitem_80, primals_132, primals_131, [True, True, True]);  view_default_181 = add_tensor_17 = getitem_79 = getitem_80 = primals_132 = primals_131 = None
        getitem_132 = native_layer_norm_backward_default_7[0]
        getitem_133 = native_layer_norm_backward_default_7[1]
        getitem_134 = native_layer_norm_backward_default_7[2];  native_layer_norm_backward_default_7 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(add_tensor_36, getitem_132);  add_tensor_36 = getitem_132 = None
        view_default_182 = torch.ops.aten.view.default(add_tensor_39, [25216, 768])
        t_default_109 = torch.ops.aten.t.default(t_default_33);  t_default_33 = None
        mm_default_30 = torch.ops.aten.mm.default(view_default_182, t_default_109);  t_default_109 = None
        t_default_110 = torch.ops.aten.t.default(view_default_182)
        mm_default_31 = torch.ops.aten.mm.default(t_default_110, view_default_85);  t_default_110 = view_default_85 = None
        t_default_111 = torch.ops.aten.t.default(mm_default_31);  mm_default_31 = None
        sum_dim_int_list_15 = torch.ops.aten.sum.dim_IntList(view_default_182, [0], True);  view_default_182 = None
        view_default_183 = torch.ops.aten.view.default(sum_dim_int_list_15, [768]);  sum_dim_int_list_15 = None
        t_default_112 = torch.ops.aten.t.default(t_default_111);  t_default_111 = None
        view_default_184 = torch.ops.aten.view.default(mm_default_30, [128, 197, 768]);  mm_default_30 = None
        view_default_185 = torch.ops.aten.view.default(view_default_184, [128, 197, 12, 64]);  view_default_184 = None
        transpose_int_43 = torch.ops.aten.transpose.int(view_default_185, 1, 2);  view_default_185 = None
        clone_default_54 = torch.ops.aten.clone.default(transpose_int_43, memory_format = torch.contiguous_format);  transpose_int_43 = None
        _unsafe_view_default_78 = torch.ops.aten._unsafe_view.default(clone_default_54, [1536, 197, 64]);  clone_default_54 = None
        transpose_int_44 = torch.ops.aten.transpose.int(view_default_84, 1, 2);  view_default_84 = None
        bmm_default_36 = torch.ops.aten.bmm.default(transpose_int_44, _unsafe_view_default_78);  transpose_int_44 = None
        transpose_int_45 = torch.ops.aten.transpose.int(_unsafe_view_default_51, 1, 2);  _unsafe_view_default_51 = None
        bmm_default_37 = torch.ops.aten.bmm.default(_unsafe_view_default_78, transpose_int_45);  _unsafe_view_default_78 = transpose_int_45 = None
        view_default_186 = torch.ops.aten.view.default(bmm_default_36, [128, 12, 197, 64]);  bmm_default_36 = None
        view_default_187 = torch.ops.aten.view.default(bmm_default_37, [128, 12, 197, 197]);  bmm_default_37 = None
        _softmax_backward_data_default_3 = torch.ops.aten._softmax_backward_data.default(view_default_187, _softmax_default_8, -1, torch.float32);  view_default_187 = _softmax_default_8 = None
        mul_tensor_43 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_3, 0.125);  _softmax_backward_data_default_3 = None
        view_default_188 = torch.ops.aten.view.default(mul_tensor_43, [1536, 197, 197]);  mul_tensor_43 = None
        transpose_int_46 = torch.ops.aten.transpose.int(_unsafe_view_default_48, 1, 2);  _unsafe_view_default_48 = None
        bmm_default_38 = torch.ops.aten.bmm.default(transpose_int_46, view_default_188);  transpose_int_46 = None
        transpose_int_47 = torch.ops.aten.transpose.int(_unsafe_view_default_49, 1, 2);  _unsafe_view_default_49 = None
        bmm_default_39 = torch.ops.aten.bmm.default(view_default_188, transpose_int_47);  view_default_188 = transpose_int_47 = None
        view_default_189 = torch.ops.aten.view.default(bmm_default_38, [128, 12, 64, 197]);  bmm_default_38 = None
        view_default_190 = torch.ops.aten.view.default(bmm_default_39, [128, 12, 197, 64]);  bmm_default_39 = None
        transpose_int_48 = torch.ops.aten.transpose.int(view_default_189, -2, -1);  view_default_189 = None
        stack_default_3 = torch.ops.aten.stack.default([view_default_190, transpose_int_48, view_default_186]);  view_default_190 = transpose_int_48 = view_default_186 = None
        permute_default_15 = torch.ops.aten.permute.default(stack_default_3, [1, 3, 0, 2, 4]);  stack_default_3 = None
        clone_default_55 = torch.ops.aten.clone.default(permute_default_15, memory_format = torch.contiguous_format);  permute_default_15 = None
        _unsafe_view_default_79 = torch.ops.aten._unsafe_view.default(clone_default_55, [128, 197, 2304]);  clone_default_55 = None
        view_default_191 = torch.ops.aten.view.default(_unsafe_view_default_79, [25216, 2304]);  _unsafe_view_default_79 = None
        t_default_113 = torch.ops.aten.t.default(t_default_32);  t_default_32 = None
        mm_default_32 = torch.ops.aten.mm.default(view_default_191, t_default_113);  t_default_113 = None
        t_default_114 = torch.ops.aten.t.default(view_default_191)
        mm_default_33 = torch.ops.aten.mm.default(t_default_114, view_default_81);  t_default_114 = view_default_81 = None
        t_default_115 = torch.ops.aten.t.default(mm_default_33);  mm_default_33 = None
        sum_dim_int_list_16 = torch.ops.aten.sum.dim_IntList(view_default_191, [0], True);  view_default_191 = None
        view_default_192 = torch.ops.aten.view.default(sum_dim_int_list_16, [2304]);  sum_dim_int_list_16 = None
        t_default_116 = torch.ops.aten.t.default(t_default_115);  t_default_115 = None
        view_default_193 = torch.ops.aten.view.default(mm_default_32, [128, 197, 768]);  mm_default_32 = None
        native_layer_norm_backward_default_8 = torch.ops.aten.native_layer_norm_backward.default(view_default_193, add_tensor_16, [768], getitem_73, getitem_74, primals_130, primals_129, [True, True, True]);  view_default_193 = add_tensor_16 = getitem_73 = getitem_74 = primals_130 = primals_129 = None
        getitem_135 = native_layer_norm_backward_default_8[0]
        getitem_136 = native_layer_norm_backward_default_8[1]
        getitem_137 = native_layer_norm_backward_default_8[2];  native_layer_norm_backward_default_8 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_39, getitem_135);  add_tensor_39 = getitem_135 = None
        view_default_194 = torch.ops.aten.view.default(add_tensor_40, [25216, 768])
        t_default_117 = torch.ops.aten.t.default(t_default_31);  t_default_31 = None
        mm_default_34 = torch.ops.aten.mm.default(view_default_194, t_default_117);  t_default_117 = None
        t_default_118 = torch.ops.aten.t.default(view_default_194)
        mm_default_35 = torch.ops.aten.mm.default(t_default_118, view_default_79);  t_default_118 = view_default_79 = None
        t_default_119 = torch.ops.aten.t.default(mm_default_35);  mm_default_35 = None
        sum_dim_int_list_17 = torch.ops.aten.sum.dim_IntList(view_default_194, [0], True);  view_default_194 = None
        view_default_195 = torch.ops.aten.view.default(sum_dim_int_list_17, [768]);  sum_dim_int_list_17 = None
        t_default_120 = torch.ops.aten.t.default(t_default_119);  t_default_119 = None
        view_default_196 = torch.ops.aten.view.default(mm_default_34, [128, 197, 3072]);  mm_default_34 = None
        to_dtype_12 = torch.ops.aten.to.dtype(view_default_196, torch.float32);  view_default_196 = None
        to_dtype_13 = torch.ops.aten.to.dtype(view_default_78, torch.float32);  view_default_78 = None
        mul_tensor_44 = torch.ops.aten.mul.Tensor(to_dtype_13, 0.7071067811865476)
        erf_default_4 = torch.ops.aten.erf.default(mul_tensor_44);  mul_tensor_44 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(erf_default_4, 1);  erf_default_4 = None
        mul_tensor_45 = torch.ops.aten.mul.Tensor(add_tensor_41, 0.5);  add_tensor_41 = None
        mul_tensor_46 = torch.ops.aten.mul.Tensor(to_dtype_13, to_dtype_13)
        mul_tensor_47 = torch.ops.aten.mul.Tensor(mul_tensor_46, -0.5);  mul_tensor_46 = None
        exp_default_4 = torch.ops.aten.exp.default(mul_tensor_47);  mul_tensor_47 = None
        mul_tensor_48 = torch.ops.aten.mul.Tensor(exp_default_4, 0.3989422804014327);  exp_default_4 = None
        mul_tensor_49 = torch.ops.aten.mul.Tensor(to_dtype_13, mul_tensor_48);  to_dtype_13 = mul_tensor_48 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(mul_tensor_45, mul_tensor_49);  mul_tensor_45 = mul_tensor_49 = None
        mul_tensor_50 = torch.ops.aten.mul.Tensor(to_dtype_12, add_tensor_42);  to_dtype_12 = add_tensor_42 = None
        to_dtype_14 = torch.ops.aten.to.dtype(mul_tensor_50, torch.float32);  mul_tensor_50 = None
        view_default_197 = torch.ops.aten.view.default(to_dtype_14, [25216, 3072]);  to_dtype_14 = None
        t_default_121 = torch.ops.aten.t.default(t_default_30);  t_default_30 = None
        mm_default_36 = torch.ops.aten.mm.default(view_default_197, t_default_121);  t_default_121 = None
        t_default_122 = torch.ops.aten.t.default(view_default_197)
        mm_default_37 = torch.ops.aten.mm.default(t_default_122, view_default_77);  t_default_122 = view_default_77 = None
        t_default_123 = torch.ops.aten.t.default(mm_default_37);  mm_default_37 = None
        sum_dim_int_list_18 = torch.ops.aten.sum.dim_IntList(view_default_197, [0], True);  view_default_197 = None
        view_default_198 = torch.ops.aten.view.default(sum_dim_int_list_18, [3072]);  sum_dim_int_list_18 = None
        t_default_124 = torch.ops.aten.t.default(t_default_123);  t_default_123 = None
        view_default_199 = torch.ops.aten.view.default(mm_default_36, [128, 197, 768]);  mm_default_36 = None
        native_layer_norm_backward_default_9 = torch.ops.aten.native_layer_norm_backward.default(view_default_199, add_tensor_15, [768], getitem_70, getitem_71, primals_120, primals_119, [True, True, True]);  view_default_199 = add_tensor_15 = getitem_70 = getitem_71 = primals_120 = primals_119 = None
        getitem_138 = native_layer_norm_backward_default_9[0]
        getitem_139 = native_layer_norm_backward_default_9[1]
        getitem_140 = native_layer_norm_backward_default_9[2];  native_layer_norm_backward_default_9 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_40, getitem_138);  add_tensor_40 = getitem_138 = None
        view_default_200 = torch.ops.aten.view.default(add_tensor_43, [25216, 768])
        t_default_125 = torch.ops.aten.t.default(t_default_29);  t_default_29 = None
        mm_default_38 = torch.ops.aten.mm.default(view_default_200, t_default_125);  t_default_125 = None
        t_default_126 = torch.ops.aten.t.default(view_default_200)
        mm_default_39 = torch.ops.aten.mm.default(t_default_126, view_default_75);  t_default_126 = view_default_75 = None
        t_default_127 = torch.ops.aten.t.default(mm_default_39);  mm_default_39 = None
        sum_dim_int_list_19 = torch.ops.aten.sum.dim_IntList(view_default_200, [0], True);  view_default_200 = None
        view_default_201 = torch.ops.aten.view.default(sum_dim_int_list_19, [768]);  sum_dim_int_list_19 = None
        t_default_128 = torch.ops.aten.t.default(t_default_127);  t_default_127 = None
        view_default_202 = torch.ops.aten.view.default(mm_default_38, [128, 197, 768]);  mm_default_38 = None
        view_default_203 = torch.ops.aten.view.default(view_default_202, [128, 197, 12, 64]);  view_default_202 = None
        transpose_int_49 = torch.ops.aten.transpose.int(view_default_203, 1, 2);  view_default_203 = None
        clone_default_56 = torch.ops.aten.clone.default(transpose_int_49, memory_format = torch.contiguous_format);  transpose_int_49 = None
        _unsafe_view_default_80 = torch.ops.aten._unsafe_view.default(clone_default_56, [1536, 197, 64]);  clone_default_56 = None
        transpose_int_50 = torch.ops.aten.transpose.int(view_default_74, 1, 2);  view_default_74 = None
        bmm_default_40 = torch.ops.aten.bmm.default(transpose_int_50, _unsafe_view_default_80);  transpose_int_50 = None
        transpose_int_51 = torch.ops.aten.transpose.int(_unsafe_view_default_45, 1, 2);  _unsafe_view_default_45 = None
        bmm_default_41 = torch.ops.aten.bmm.default(_unsafe_view_default_80, transpose_int_51);  _unsafe_view_default_80 = transpose_int_51 = None
        view_default_204 = torch.ops.aten.view.default(bmm_default_40, [128, 12, 197, 64]);  bmm_default_40 = None
        view_default_205 = torch.ops.aten.view.default(bmm_default_41, [128, 12, 197, 197]);  bmm_default_41 = None
        _softmax_backward_data_default_4 = torch.ops.aten._softmax_backward_data.default(view_default_205, _softmax_default_7, -1, torch.float32);  view_default_205 = _softmax_default_7 = None
        mul_tensor_51 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_4, 0.125);  _softmax_backward_data_default_4 = None
        view_default_206 = torch.ops.aten.view.default(mul_tensor_51, [1536, 197, 197]);  mul_tensor_51 = None
        transpose_int_52 = torch.ops.aten.transpose.int(_unsafe_view_default_42, 1, 2);  _unsafe_view_default_42 = None
        bmm_default_42 = torch.ops.aten.bmm.default(transpose_int_52, view_default_206);  transpose_int_52 = None
        transpose_int_53 = torch.ops.aten.transpose.int(_unsafe_view_default_43, 1, 2);  _unsafe_view_default_43 = None
        bmm_default_43 = torch.ops.aten.bmm.default(view_default_206, transpose_int_53);  view_default_206 = transpose_int_53 = None
        view_default_207 = torch.ops.aten.view.default(bmm_default_42, [128, 12, 64, 197]);  bmm_default_42 = None
        view_default_208 = torch.ops.aten.view.default(bmm_default_43, [128, 12, 197, 64]);  bmm_default_43 = None
        transpose_int_54 = torch.ops.aten.transpose.int(view_default_207, -2, -1);  view_default_207 = None
        stack_default_4 = torch.ops.aten.stack.default([view_default_208, transpose_int_54, view_default_204]);  view_default_208 = transpose_int_54 = view_default_204 = None
        permute_default_16 = torch.ops.aten.permute.default(stack_default_4, [1, 3, 0, 2, 4]);  stack_default_4 = None
        clone_default_57 = torch.ops.aten.clone.default(permute_default_16, memory_format = torch.contiguous_format);  permute_default_16 = None
        _unsafe_view_default_81 = torch.ops.aten._unsafe_view.default(clone_default_57, [128, 197, 2304]);  clone_default_57 = None
        view_default_209 = torch.ops.aten.view.default(_unsafe_view_default_81, [25216, 2304]);  _unsafe_view_default_81 = None
        t_default_129 = torch.ops.aten.t.default(t_default_28);  t_default_28 = None
        mm_default_40 = torch.ops.aten.mm.default(view_default_209, t_default_129);  t_default_129 = None
        t_default_130 = torch.ops.aten.t.default(view_default_209)
        mm_default_41 = torch.ops.aten.mm.default(t_default_130, view_default_71);  t_default_130 = view_default_71 = None
        t_default_131 = torch.ops.aten.t.default(mm_default_41);  mm_default_41 = None
        sum_dim_int_list_20 = torch.ops.aten.sum.dim_IntList(view_default_209, [0], True);  view_default_209 = None
        view_default_210 = torch.ops.aten.view.default(sum_dim_int_list_20, [2304]);  sum_dim_int_list_20 = None
        t_default_132 = torch.ops.aten.t.default(t_default_131);  t_default_131 = None
        view_default_211 = torch.ops.aten.view.default(mm_default_40, [128, 197, 768]);  mm_default_40 = None
        native_layer_norm_backward_default_10 = torch.ops.aten.native_layer_norm_backward.default(view_default_211, add_tensor_14, [768], getitem_64, getitem_65, primals_118, primals_117, [True, True, True]);  view_default_211 = add_tensor_14 = getitem_64 = getitem_65 = primals_118 = primals_117 = None
        getitem_141 = native_layer_norm_backward_default_10[0]
        getitem_142 = native_layer_norm_backward_default_10[1]
        getitem_143 = native_layer_norm_backward_default_10[2];  native_layer_norm_backward_default_10 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(add_tensor_43, getitem_141);  add_tensor_43 = getitem_141 = None
        view_default_212 = torch.ops.aten.view.default(add_tensor_44, [25216, 768])
        t_default_133 = torch.ops.aten.t.default(t_default_27);  t_default_27 = None
        mm_default_42 = torch.ops.aten.mm.default(view_default_212, t_default_133);  t_default_133 = None
        t_default_134 = torch.ops.aten.t.default(view_default_212)
        mm_default_43 = torch.ops.aten.mm.default(t_default_134, view_default_69);  t_default_134 = view_default_69 = None
        t_default_135 = torch.ops.aten.t.default(mm_default_43);  mm_default_43 = None
        sum_dim_int_list_21 = torch.ops.aten.sum.dim_IntList(view_default_212, [0], True);  view_default_212 = None
        view_default_213 = torch.ops.aten.view.default(sum_dim_int_list_21, [768]);  sum_dim_int_list_21 = None
        t_default_136 = torch.ops.aten.t.default(t_default_135);  t_default_135 = None
        view_default_214 = torch.ops.aten.view.default(mm_default_42, [128, 197, 3072]);  mm_default_42 = None
        to_dtype_15 = torch.ops.aten.to.dtype(view_default_214, torch.float32);  view_default_214 = None
        to_dtype_16 = torch.ops.aten.to.dtype(view_default_68, torch.float32);  view_default_68 = None
        mul_tensor_52 = torch.ops.aten.mul.Tensor(to_dtype_16, 0.7071067811865476)
        erf_default_5 = torch.ops.aten.erf.default(mul_tensor_52);  mul_tensor_52 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(erf_default_5, 1);  erf_default_5 = None
        mul_tensor_53 = torch.ops.aten.mul.Tensor(add_tensor_45, 0.5);  add_tensor_45 = None
        mul_tensor_54 = torch.ops.aten.mul.Tensor(to_dtype_16, to_dtype_16)
        mul_tensor_55 = torch.ops.aten.mul.Tensor(mul_tensor_54, -0.5);  mul_tensor_54 = None
        exp_default_5 = torch.ops.aten.exp.default(mul_tensor_55);  mul_tensor_55 = None
        mul_tensor_56 = torch.ops.aten.mul.Tensor(exp_default_5, 0.3989422804014327);  exp_default_5 = None
        mul_tensor_57 = torch.ops.aten.mul.Tensor(to_dtype_16, mul_tensor_56);  to_dtype_16 = mul_tensor_56 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(mul_tensor_53, mul_tensor_57);  mul_tensor_53 = mul_tensor_57 = None
        mul_tensor_58 = torch.ops.aten.mul.Tensor(to_dtype_15, add_tensor_46);  to_dtype_15 = add_tensor_46 = None
        to_dtype_17 = torch.ops.aten.to.dtype(mul_tensor_58, torch.float32);  mul_tensor_58 = None
        view_default_215 = torch.ops.aten.view.default(to_dtype_17, [25216, 3072]);  to_dtype_17 = None
        t_default_137 = torch.ops.aten.t.default(t_default_26);  t_default_26 = None
        mm_default_44 = torch.ops.aten.mm.default(view_default_215, t_default_137);  t_default_137 = None
        t_default_138 = torch.ops.aten.t.default(view_default_215)
        mm_default_45 = torch.ops.aten.mm.default(t_default_138, view_default_67);  t_default_138 = view_default_67 = None
        t_default_139 = torch.ops.aten.t.default(mm_default_45);  mm_default_45 = None
        sum_dim_int_list_22 = torch.ops.aten.sum.dim_IntList(view_default_215, [0], True);  view_default_215 = None
        view_default_216 = torch.ops.aten.view.default(sum_dim_int_list_22, [3072]);  sum_dim_int_list_22 = None
        t_default_140 = torch.ops.aten.t.default(t_default_139);  t_default_139 = None
        view_default_217 = torch.ops.aten.view.default(mm_default_44, [128, 197, 768]);  mm_default_44 = None
        native_layer_norm_backward_default_11 = torch.ops.aten.native_layer_norm_backward.default(view_default_217, add_tensor_13, [768], getitem_61, getitem_62, primals_108, primals_107, [True, True, True]);  view_default_217 = add_tensor_13 = getitem_61 = getitem_62 = primals_108 = primals_107 = None
        getitem_144 = native_layer_norm_backward_default_11[0]
        getitem_145 = native_layer_norm_backward_default_11[1]
        getitem_146 = native_layer_norm_backward_default_11[2];  native_layer_norm_backward_default_11 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(add_tensor_44, getitem_144);  add_tensor_44 = getitem_144 = None
        view_default_218 = torch.ops.aten.view.default(add_tensor_47, [25216, 768])
        t_default_141 = torch.ops.aten.t.default(t_default_25);  t_default_25 = None
        mm_default_46 = torch.ops.aten.mm.default(view_default_218, t_default_141);  t_default_141 = None
        t_default_142 = torch.ops.aten.t.default(view_default_218)
        mm_default_47 = torch.ops.aten.mm.default(t_default_142, view_default_65);  t_default_142 = view_default_65 = None
        t_default_143 = torch.ops.aten.t.default(mm_default_47);  mm_default_47 = None
        sum_dim_int_list_23 = torch.ops.aten.sum.dim_IntList(view_default_218, [0], True);  view_default_218 = None
        view_default_219 = torch.ops.aten.view.default(sum_dim_int_list_23, [768]);  sum_dim_int_list_23 = None
        t_default_144 = torch.ops.aten.t.default(t_default_143);  t_default_143 = None
        view_default_220 = torch.ops.aten.view.default(mm_default_46, [128, 197, 768]);  mm_default_46 = None
        view_default_221 = torch.ops.aten.view.default(view_default_220, [128, 197, 12, 64]);  view_default_220 = None
        transpose_int_55 = torch.ops.aten.transpose.int(view_default_221, 1, 2);  view_default_221 = None
        clone_default_58 = torch.ops.aten.clone.default(transpose_int_55, memory_format = torch.contiguous_format);  transpose_int_55 = None
        _unsafe_view_default_82 = torch.ops.aten._unsafe_view.default(clone_default_58, [1536, 197, 64]);  clone_default_58 = None
        transpose_int_56 = torch.ops.aten.transpose.int(view_default_64, 1, 2);  view_default_64 = None
        bmm_default_44 = torch.ops.aten.bmm.default(transpose_int_56, _unsafe_view_default_82);  transpose_int_56 = None
        transpose_int_57 = torch.ops.aten.transpose.int(_unsafe_view_default_39, 1, 2);  _unsafe_view_default_39 = None
        bmm_default_45 = torch.ops.aten.bmm.default(_unsafe_view_default_82, transpose_int_57);  _unsafe_view_default_82 = transpose_int_57 = None
        view_default_222 = torch.ops.aten.view.default(bmm_default_44, [128, 12, 197, 64]);  bmm_default_44 = None
        view_default_223 = torch.ops.aten.view.default(bmm_default_45, [128, 12, 197, 197]);  bmm_default_45 = None
        _softmax_backward_data_default_5 = torch.ops.aten._softmax_backward_data.default(view_default_223, _softmax_default_6, -1, torch.float32);  view_default_223 = _softmax_default_6 = None
        mul_tensor_59 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_5, 0.125);  _softmax_backward_data_default_5 = None
        view_default_224 = torch.ops.aten.view.default(mul_tensor_59, [1536, 197, 197]);  mul_tensor_59 = None
        transpose_int_58 = torch.ops.aten.transpose.int(_unsafe_view_default_36, 1, 2);  _unsafe_view_default_36 = None
        bmm_default_46 = torch.ops.aten.bmm.default(transpose_int_58, view_default_224);  transpose_int_58 = None
        transpose_int_59 = torch.ops.aten.transpose.int(_unsafe_view_default_37, 1, 2);  _unsafe_view_default_37 = None
        bmm_default_47 = torch.ops.aten.bmm.default(view_default_224, transpose_int_59);  view_default_224 = transpose_int_59 = None
        view_default_225 = torch.ops.aten.view.default(bmm_default_46, [128, 12, 64, 197]);  bmm_default_46 = None
        view_default_226 = torch.ops.aten.view.default(bmm_default_47, [128, 12, 197, 64]);  bmm_default_47 = None
        transpose_int_60 = torch.ops.aten.transpose.int(view_default_225, -2, -1);  view_default_225 = None
        stack_default_5 = torch.ops.aten.stack.default([view_default_226, transpose_int_60, view_default_222]);  view_default_226 = transpose_int_60 = view_default_222 = None
        permute_default_17 = torch.ops.aten.permute.default(stack_default_5, [1, 3, 0, 2, 4]);  stack_default_5 = None
        clone_default_59 = torch.ops.aten.clone.default(permute_default_17, memory_format = torch.contiguous_format);  permute_default_17 = None
        _unsafe_view_default_83 = torch.ops.aten._unsafe_view.default(clone_default_59, [128, 197, 2304]);  clone_default_59 = None
        view_default_227 = torch.ops.aten.view.default(_unsafe_view_default_83, [25216, 2304]);  _unsafe_view_default_83 = None
        t_default_145 = torch.ops.aten.t.default(t_default_24);  t_default_24 = None
        mm_default_48 = torch.ops.aten.mm.default(view_default_227, t_default_145);  t_default_145 = None
        t_default_146 = torch.ops.aten.t.default(view_default_227)
        mm_default_49 = torch.ops.aten.mm.default(t_default_146, view_default_61);  t_default_146 = view_default_61 = None
        t_default_147 = torch.ops.aten.t.default(mm_default_49);  mm_default_49 = None
        sum_dim_int_list_24 = torch.ops.aten.sum.dim_IntList(view_default_227, [0], True);  view_default_227 = None
        view_default_228 = torch.ops.aten.view.default(sum_dim_int_list_24, [2304]);  sum_dim_int_list_24 = None
        t_default_148 = torch.ops.aten.t.default(t_default_147);  t_default_147 = None
        view_default_229 = torch.ops.aten.view.default(mm_default_48, [128, 197, 768]);  mm_default_48 = None
        native_layer_norm_backward_default_12 = torch.ops.aten.native_layer_norm_backward.default(view_default_229, add_tensor_12, [768], getitem_55, getitem_56, primals_106, primals_105, [True, True, True]);  view_default_229 = add_tensor_12 = getitem_55 = getitem_56 = primals_106 = primals_105 = None
        getitem_147 = native_layer_norm_backward_default_12[0]
        getitem_148 = native_layer_norm_backward_default_12[1]
        getitem_149 = native_layer_norm_backward_default_12[2];  native_layer_norm_backward_default_12 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_47, getitem_147);  add_tensor_47 = getitem_147 = None
        view_default_230 = torch.ops.aten.view.default(add_tensor_48, [25216, 768])
        t_default_149 = torch.ops.aten.t.default(t_default_23);  t_default_23 = None
        mm_default_50 = torch.ops.aten.mm.default(view_default_230, t_default_149);  t_default_149 = None
        t_default_150 = torch.ops.aten.t.default(view_default_230)
        mm_default_51 = torch.ops.aten.mm.default(t_default_150, view_default_59);  t_default_150 = view_default_59 = None
        t_default_151 = torch.ops.aten.t.default(mm_default_51);  mm_default_51 = None
        sum_dim_int_list_25 = torch.ops.aten.sum.dim_IntList(view_default_230, [0], True);  view_default_230 = None
        view_default_231 = torch.ops.aten.view.default(sum_dim_int_list_25, [768]);  sum_dim_int_list_25 = None
        t_default_152 = torch.ops.aten.t.default(t_default_151);  t_default_151 = None
        view_default_232 = torch.ops.aten.view.default(mm_default_50, [128, 197, 3072]);  mm_default_50 = None
        to_dtype_18 = torch.ops.aten.to.dtype(view_default_232, torch.float32);  view_default_232 = None
        to_dtype_19 = torch.ops.aten.to.dtype(view_default_58, torch.float32);  view_default_58 = None
        mul_tensor_60 = torch.ops.aten.mul.Tensor(to_dtype_19, 0.7071067811865476)
        erf_default_6 = torch.ops.aten.erf.default(mul_tensor_60);  mul_tensor_60 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(erf_default_6, 1);  erf_default_6 = None
        mul_tensor_61 = torch.ops.aten.mul.Tensor(add_tensor_49, 0.5);  add_tensor_49 = None
        mul_tensor_62 = torch.ops.aten.mul.Tensor(to_dtype_19, to_dtype_19)
        mul_tensor_63 = torch.ops.aten.mul.Tensor(mul_tensor_62, -0.5);  mul_tensor_62 = None
        exp_default_6 = torch.ops.aten.exp.default(mul_tensor_63);  mul_tensor_63 = None
        mul_tensor_64 = torch.ops.aten.mul.Tensor(exp_default_6, 0.3989422804014327);  exp_default_6 = None
        mul_tensor_65 = torch.ops.aten.mul.Tensor(to_dtype_19, mul_tensor_64);  to_dtype_19 = mul_tensor_64 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(mul_tensor_61, mul_tensor_65);  mul_tensor_61 = mul_tensor_65 = None
        mul_tensor_66 = torch.ops.aten.mul.Tensor(to_dtype_18, add_tensor_50);  to_dtype_18 = add_tensor_50 = None
        to_dtype_20 = torch.ops.aten.to.dtype(mul_tensor_66, torch.float32);  mul_tensor_66 = None
        view_default_233 = torch.ops.aten.view.default(to_dtype_20, [25216, 3072]);  to_dtype_20 = None
        t_default_153 = torch.ops.aten.t.default(t_default_22);  t_default_22 = None
        mm_default_52 = torch.ops.aten.mm.default(view_default_233, t_default_153);  t_default_153 = None
        t_default_154 = torch.ops.aten.t.default(view_default_233)
        mm_default_53 = torch.ops.aten.mm.default(t_default_154, view_default_57);  t_default_154 = view_default_57 = None
        t_default_155 = torch.ops.aten.t.default(mm_default_53);  mm_default_53 = None
        sum_dim_int_list_26 = torch.ops.aten.sum.dim_IntList(view_default_233, [0], True);  view_default_233 = None
        view_default_234 = torch.ops.aten.view.default(sum_dim_int_list_26, [3072]);  sum_dim_int_list_26 = None
        t_default_156 = torch.ops.aten.t.default(t_default_155);  t_default_155 = None
        view_default_235 = torch.ops.aten.view.default(mm_default_52, [128, 197, 768]);  mm_default_52 = None
        native_layer_norm_backward_default_13 = torch.ops.aten.native_layer_norm_backward.default(view_default_235, add_tensor_11, [768], getitem_52, getitem_53, primals_96, primals_95, [True, True, True]);  view_default_235 = add_tensor_11 = getitem_52 = getitem_53 = primals_96 = primals_95 = None
        getitem_150 = native_layer_norm_backward_default_13[0]
        getitem_151 = native_layer_norm_backward_default_13[1]
        getitem_152 = native_layer_norm_backward_default_13[2];  native_layer_norm_backward_default_13 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(add_tensor_48, getitem_150);  add_tensor_48 = getitem_150 = None
        view_default_236 = torch.ops.aten.view.default(add_tensor_51, [25216, 768])
        t_default_157 = torch.ops.aten.t.default(t_default_21);  t_default_21 = None
        mm_default_54 = torch.ops.aten.mm.default(view_default_236, t_default_157);  t_default_157 = None
        t_default_158 = torch.ops.aten.t.default(view_default_236)
        mm_default_55 = torch.ops.aten.mm.default(t_default_158, view_default_55);  t_default_158 = view_default_55 = None
        t_default_159 = torch.ops.aten.t.default(mm_default_55);  mm_default_55 = None
        sum_dim_int_list_27 = torch.ops.aten.sum.dim_IntList(view_default_236, [0], True);  view_default_236 = None
        view_default_237 = torch.ops.aten.view.default(sum_dim_int_list_27, [768]);  sum_dim_int_list_27 = None
        t_default_160 = torch.ops.aten.t.default(t_default_159);  t_default_159 = None
        view_default_238 = torch.ops.aten.view.default(mm_default_54, [128, 197, 768]);  mm_default_54 = None
        view_default_239 = torch.ops.aten.view.default(view_default_238, [128, 197, 12, 64]);  view_default_238 = None
        transpose_int_61 = torch.ops.aten.transpose.int(view_default_239, 1, 2);  view_default_239 = None
        clone_default_60 = torch.ops.aten.clone.default(transpose_int_61, memory_format = torch.contiguous_format);  transpose_int_61 = None
        _unsafe_view_default_84 = torch.ops.aten._unsafe_view.default(clone_default_60, [1536, 197, 64]);  clone_default_60 = None
        transpose_int_62 = torch.ops.aten.transpose.int(view_default_54, 1, 2);  view_default_54 = None
        bmm_default_48 = torch.ops.aten.bmm.default(transpose_int_62, _unsafe_view_default_84);  transpose_int_62 = None
        transpose_int_63 = torch.ops.aten.transpose.int(_unsafe_view_default_33, 1, 2);  _unsafe_view_default_33 = None
        bmm_default_49 = torch.ops.aten.bmm.default(_unsafe_view_default_84, transpose_int_63);  _unsafe_view_default_84 = transpose_int_63 = None
        view_default_240 = torch.ops.aten.view.default(bmm_default_48, [128, 12, 197, 64]);  bmm_default_48 = None
        view_default_241 = torch.ops.aten.view.default(bmm_default_49, [128, 12, 197, 197]);  bmm_default_49 = None
        _softmax_backward_data_default_6 = torch.ops.aten._softmax_backward_data.default(view_default_241, _softmax_default_5, -1, torch.float32);  view_default_241 = _softmax_default_5 = None
        mul_tensor_67 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_6, 0.125);  _softmax_backward_data_default_6 = None
        view_default_242 = torch.ops.aten.view.default(mul_tensor_67, [1536, 197, 197]);  mul_tensor_67 = None
        transpose_int_64 = torch.ops.aten.transpose.int(_unsafe_view_default_30, 1, 2);  _unsafe_view_default_30 = None
        bmm_default_50 = torch.ops.aten.bmm.default(transpose_int_64, view_default_242);  transpose_int_64 = None
        transpose_int_65 = torch.ops.aten.transpose.int(_unsafe_view_default_31, 1, 2);  _unsafe_view_default_31 = None
        bmm_default_51 = torch.ops.aten.bmm.default(view_default_242, transpose_int_65);  view_default_242 = transpose_int_65 = None
        view_default_243 = torch.ops.aten.view.default(bmm_default_50, [128, 12, 64, 197]);  bmm_default_50 = None
        view_default_244 = torch.ops.aten.view.default(bmm_default_51, [128, 12, 197, 64]);  bmm_default_51 = None
        transpose_int_66 = torch.ops.aten.transpose.int(view_default_243, -2, -1);  view_default_243 = None
        stack_default_6 = torch.ops.aten.stack.default([view_default_244, transpose_int_66, view_default_240]);  view_default_244 = transpose_int_66 = view_default_240 = None
        permute_default_18 = torch.ops.aten.permute.default(stack_default_6, [1, 3, 0, 2, 4]);  stack_default_6 = None
        clone_default_61 = torch.ops.aten.clone.default(permute_default_18, memory_format = torch.contiguous_format);  permute_default_18 = None
        _unsafe_view_default_85 = torch.ops.aten._unsafe_view.default(clone_default_61, [128, 197, 2304]);  clone_default_61 = None
        view_default_245 = torch.ops.aten.view.default(_unsafe_view_default_85, [25216, 2304]);  _unsafe_view_default_85 = None
        t_default_161 = torch.ops.aten.t.default(t_default_20);  t_default_20 = None
        mm_default_56 = torch.ops.aten.mm.default(view_default_245, t_default_161);  t_default_161 = None
        t_default_162 = torch.ops.aten.t.default(view_default_245)
        mm_default_57 = torch.ops.aten.mm.default(t_default_162, view_default_51);  t_default_162 = view_default_51 = None
        t_default_163 = torch.ops.aten.t.default(mm_default_57);  mm_default_57 = None
        sum_dim_int_list_28 = torch.ops.aten.sum.dim_IntList(view_default_245, [0], True);  view_default_245 = None
        view_default_246 = torch.ops.aten.view.default(sum_dim_int_list_28, [2304]);  sum_dim_int_list_28 = None
        t_default_164 = torch.ops.aten.t.default(t_default_163);  t_default_163 = None
        view_default_247 = torch.ops.aten.view.default(mm_default_56, [128, 197, 768]);  mm_default_56 = None
        native_layer_norm_backward_default_14 = torch.ops.aten.native_layer_norm_backward.default(view_default_247, add_tensor_10, [768], getitem_46, getitem_47, primals_94, primals_93, [True, True, True]);  view_default_247 = add_tensor_10 = getitem_46 = getitem_47 = primals_94 = primals_93 = None
        getitem_153 = native_layer_norm_backward_default_14[0]
        getitem_154 = native_layer_norm_backward_default_14[1]
        getitem_155 = native_layer_norm_backward_default_14[2];  native_layer_norm_backward_default_14 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_51, getitem_153);  add_tensor_51 = getitem_153 = None
        view_default_248 = torch.ops.aten.view.default(add_tensor_52, [25216, 768])
        t_default_165 = torch.ops.aten.t.default(t_default_19);  t_default_19 = None
        mm_default_58 = torch.ops.aten.mm.default(view_default_248, t_default_165);  t_default_165 = None
        t_default_166 = torch.ops.aten.t.default(view_default_248)
        mm_default_59 = torch.ops.aten.mm.default(t_default_166, view_default_49);  t_default_166 = view_default_49 = None
        t_default_167 = torch.ops.aten.t.default(mm_default_59);  mm_default_59 = None
        sum_dim_int_list_29 = torch.ops.aten.sum.dim_IntList(view_default_248, [0], True);  view_default_248 = None
        view_default_249 = torch.ops.aten.view.default(sum_dim_int_list_29, [768]);  sum_dim_int_list_29 = None
        t_default_168 = torch.ops.aten.t.default(t_default_167);  t_default_167 = None
        view_default_250 = torch.ops.aten.view.default(mm_default_58, [128, 197, 3072]);  mm_default_58 = None
        to_dtype_21 = torch.ops.aten.to.dtype(view_default_250, torch.float32);  view_default_250 = None
        to_dtype_22 = torch.ops.aten.to.dtype(view_default_48, torch.float32);  view_default_48 = None
        mul_tensor_68 = torch.ops.aten.mul.Tensor(to_dtype_22, 0.7071067811865476)
        erf_default_7 = torch.ops.aten.erf.default(mul_tensor_68);  mul_tensor_68 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(erf_default_7, 1);  erf_default_7 = None
        mul_tensor_69 = torch.ops.aten.mul.Tensor(add_tensor_53, 0.5);  add_tensor_53 = None
        mul_tensor_70 = torch.ops.aten.mul.Tensor(to_dtype_22, to_dtype_22)
        mul_tensor_71 = torch.ops.aten.mul.Tensor(mul_tensor_70, -0.5);  mul_tensor_70 = None
        exp_default_7 = torch.ops.aten.exp.default(mul_tensor_71);  mul_tensor_71 = None
        mul_tensor_72 = torch.ops.aten.mul.Tensor(exp_default_7, 0.3989422804014327);  exp_default_7 = None
        mul_tensor_73 = torch.ops.aten.mul.Tensor(to_dtype_22, mul_tensor_72);  to_dtype_22 = mul_tensor_72 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(mul_tensor_69, mul_tensor_73);  mul_tensor_69 = mul_tensor_73 = None
        mul_tensor_74 = torch.ops.aten.mul.Tensor(to_dtype_21, add_tensor_54);  to_dtype_21 = add_tensor_54 = None
        to_dtype_23 = torch.ops.aten.to.dtype(mul_tensor_74, torch.float32);  mul_tensor_74 = None
        view_default_251 = torch.ops.aten.view.default(to_dtype_23, [25216, 3072]);  to_dtype_23 = None
        t_default_169 = torch.ops.aten.t.default(t_default_18);  t_default_18 = None
        mm_default_60 = torch.ops.aten.mm.default(view_default_251, t_default_169);  t_default_169 = None
        t_default_170 = torch.ops.aten.t.default(view_default_251)
        mm_default_61 = torch.ops.aten.mm.default(t_default_170, view_default_47);  t_default_170 = view_default_47 = None
        t_default_171 = torch.ops.aten.t.default(mm_default_61);  mm_default_61 = None
        sum_dim_int_list_30 = torch.ops.aten.sum.dim_IntList(view_default_251, [0], True);  view_default_251 = None
        view_default_252 = torch.ops.aten.view.default(sum_dim_int_list_30, [3072]);  sum_dim_int_list_30 = None
        t_default_172 = torch.ops.aten.t.default(t_default_171);  t_default_171 = None
        view_default_253 = torch.ops.aten.view.default(mm_default_60, [128, 197, 768]);  mm_default_60 = None
        native_layer_norm_backward_default_15 = torch.ops.aten.native_layer_norm_backward.default(view_default_253, add_tensor_9, [768], getitem_43, getitem_44, primals_84, primals_83, [True, True, True]);  view_default_253 = add_tensor_9 = getitem_43 = getitem_44 = primals_84 = primals_83 = None
        getitem_156 = native_layer_norm_backward_default_15[0]
        getitem_157 = native_layer_norm_backward_default_15[1]
        getitem_158 = native_layer_norm_backward_default_15[2];  native_layer_norm_backward_default_15 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(add_tensor_52, getitem_156);  add_tensor_52 = getitem_156 = None
        view_default_254 = torch.ops.aten.view.default(add_tensor_55, [25216, 768])
        t_default_173 = torch.ops.aten.t.default(t_default_17);  t_default_17 = None
        mm_default_62 = torch.ops.aten.mm.default(view_default_254, t_default_173);  t_default_173 = None
        t_default_174 = torch.ops.aten.t.default(view_default_254)
        mm_default_63 = torch.ops.aten.mm.default(t_default_174, view_default_45);  t_default_174 = view_default_45 = None
        t_default_175 = torch.ops.aten.t.default(mm_default_63);  mm_default_63 = None
        sum_dim_int_list_31 = torch.ops.aten.sum.dim_IntList(view_default_254, [0], True);  view_default_254 = None
        view_default_255 = torch.ops.aten.view.default(sum_dim_int_list_31, [768]);  sum_dim_int_list_31 = None
        t_default_176 = torch.ops.aten.t.default(t_default_175);  t_default_175 = None
        view_default_256 = torch.ops.aten.view.default(mm_default_62, [128, 197, 768]);  mm_default_62 = None
        view_default_257 = torch.ops.aten.view.default(view_default_256, [128, 197, 12, 64]);  view_default_256 = None
        transpose_int_67 = torch.ops.aten.transpose.int(view_default_257, 1, 2);  view_default_257 = None
        clone_default_62 = torch.ops.aten.clone.default(transpose_int_67, memory_format = torch.contiguous_format);  transpose_int_67 = None
        _unsafe_view_default_86 = torch.ops.aten._unsafe_view.default(clone_default_62, [1536, 197, 64]);  clone_default_62 = None
        transpose_int_68 = torch.ops.aten.transpose.int(view_default_44, 1, 2);  view_default_44 = None
        bmm_default_52 = torch.ops.aten.bmm.default(transpose_int_68, _unsafe_view_default_86);  transpose_int_68 = None
        transpose_int_69 = torch.ops.aten.transpose.int(_unsafe_view_default_27, 1, 2);  _unsafe_view_default_27 = None
        bmm_default_53 = torch.ops.aten.bmm.default(_unsafe_view_default_86, transpose_int_69);  _unsafe_view_default_86 = transpose_int_69 = None
        view_default_258 = torch.ops.aten.view.default(bmm_default_52, [128, 12, 197, 64]);  bmm_default_52 = None
        view_default_259 = torch.ops.aten.view.default(bmm_default_53, [128, 12, 197, 197]);  bmm_default_53 = None
        _softmax_backward_data_default_7 = torch.ops.aten._softmax_backward_data.default(view_default_259, _softmax_default_4, -1, torch.float32);  view_default_259 = _softmax_default_4 = None
        mul_tensor_75 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_7, 0.125);  _softmax_backward_data_default_7 = None
        view_default_260 = torch.ops.aten.view.default(mul_tensor_75, [1536, 197, 197]);  mul_tensor_75 = None
        transpose_int_70 = torch.ops.aten.transpose.int(_unsafe_view_default_24, 1, 2);  _unsafe_view_default_24 = None
        bmm_default_54 = torch.ops.aten.bmm.default(transpose_int_70, view_default_260);  transpose_int_70 = None
        transpose_int_71 = torch.ops.aten.transpose.int(_unsafe_view_default_25, 1, 2);  _unsafe_view_default_25 = None
        bmm_default_55 = torch.ops.aten.bmm.default(view_default_260, transpose_int_71);  view_default_260 = transpose_int_71 = None
        view_default_261 = torch.ops.aten.view.default(bmm_default_54, [128, 12, 64, 197]);  bmm_default_54 = None
        view_default_262 = torch.ops.aten.view.default(bmm_default_55, [128, 12, 197, 64]);  bmm_default_55 = None
        transpose_int_72 = torch.ops.aten.transpose.int(view_default_261, -2, -1);  view_default_261 = None
        stack_default_7 = torch.ops.aten.stack.default([view_default_262, transpose_int_72, view_default_258]);  view_default_262 = transpose_int_72 = view_default_258 = None
        permute_default_19 = torch.ops.aten.permute.default(stack_default_7, [1, 3, 0, 2, 4]);  stack_default_7 = None
        clone_default_63 = torch.ops.aten.clone.default(permute_default_19, memory_format = torch.contiguous_format);  permute_default_19 = None
        _unsafe_view_default_87 = torch.ops.aten._unsafe_view.default(clone_default_63, [128, 197, 2304]);  clone_default_63 = None
        view_default_263 = torch.ops.aten.view.default(_unsafe_view_default_87, [25216, 2304]);  _unsafe_view_default_87 = None
        t_default_177 = torch.ops.aten.t.default(t_default_16);  t_default_16 = None
        mm_default_64 = torch.ops.aten.mm.default(view_default_263, t_default_177);  t_default_177 = None
        t_default_178 = torch.ops.aten.t.default(view_default_263)
        mm_default_65 = torch.ops.aten.mm.default(t_default_178, view_default_41);  t_default_178 = view_default_41 = None
        t_default_179 = torch.ops.aten.t.default(mm_default_65);  mm_default_65 = None
        sum_dim_int_list_32 = torch.ops.aten.sum.dim_IntList(view_default_263, [0], True);  view_default_263 = None
        view_default_264 = torch.ops.aten.view.default(sum_dim_int_list_32, [2304]);  sum_dim_int_list_32 = None
        t_default_180 = torch.ops.aten.t.default(t_default_179);  t_default_179 = None
        view_default_265 = torch.ops.aten.view.default(mm_default_64, [128, 197, 768]);  mm_default_64 = None
        native_layer_norm_backward_default_16 = torch.ops.aten.native_layer_norm_backward.default(view_default_265, add_tensor_8, [768], getitem_37, getitem_38, primals_82, primals_81, [True, True, True]);  view_default_265 = add_tensor_8 = getitem_37 = getitem_38 = primals_82 = primals_81 = None
        getitem_159 = native_layer_norm_backward_default_16[0]
        getitem_160 = native_layer_norm_backward_default_16[1]
        getitem_161 = native_layer_norm_backward_default_16[2];  native_layer_norm_backward_default_16 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(add_tensor_55, getitem_159);  add_tensor_55 = getitem_159 = None
        view_default_266 = torch.ops.aten.view.default(add_tensor_56, [25216, 768])
        t_default_181 = torch.ops.aten.t.default(t_default_15);  t_default_15 = None
        mm_default_66 = torch.ops.aten.mm.default(view_default_266, t_default_181);  t_default_181 = None
        t_default_182 = torch.ops.aten.t.default(view_default_266)
        mm_default_67 = torch.ops.aten.mm.default(t_default_182, view_default_39);  t_default_182 = view_default_39 = None
        t_default_183 = torch.ops.aten.t.default(mm_default_67);  mm_default_67 = None
        sum_dim_int_list_33 = torch.ops.aten.sum.dim_IntList(view_default_266, [0], True);  view_default_266 = None
        view_default_267 = torch.ops.aten.view.default(sum_dim_int_list_33, [768]);  sum_dim_int_list_33 = None
        t_default_184 = torch.ops.aten.t.default(t_default_183);  t_default_183 = None
        view_default_268 = torch.ops.aten.view.default(mm_default_66, [128, 197, 3072]);  mm_default_66 = None
        to_dtype_24 = torch.ops.aten.to.dtype(view_default_268, torch.float32);  view_default_268 = None
        to_dtype_25 = torch.ops.aten.to.dtype(view_default_38, torch.float32);  view_default_38 = None
        mul_tensor_76 = torch.ops.aten.mul.Tensor(to_dtype_25, 0.7071067811865476)
        erf_default_8 = torch.ops.aten.erf.default(mul_tensor_76);  mul_tensor_76 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(erf_default_8, 1);  erf_default_8 = None
        mul_tensor_77 = torch.ops.aten.mul.Tensor(add_tensor_57, 0.5);  add_tensor_57 = None
        mul_tensor_78 = torch.ops.aten.mul.Tensor(to_dtype_25, to_dtype_25)
        mul_tensor_79 = torch.ops.aten.mul.Tensor(mul_tensor_78, -0.5);  mul_tensor_78 = None
        exp_default_8 = torch.ops.aten.exp.default(mul_tensor_79);  mul_tensor_79 = None
        mul_tensor_80 = torch.ops.aten.mul.Tensor(exp_default_8, 0.3989422804014327);  exp_default_8 = None
        mul_tensor_81 = torch.ops.aten.mul.Tensor(to_dtype_25, mul_tensor_80);  to_dtype_25 = mul_tensor_80 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(mul_tensor_77, mul_tensor_81);  mul_tensor_77 = mul_tensor_81 = None
        mul_tensor_82 = torch.ops.aten.mul.Tensor(to_dtype_24, add_tensor_58);  to_dtype_24 = add_tensor_58 = None
        to_dtype_26 = torch.ops.aten.to.dtype(mul_tensor_82, torch.float32);  mul_tensor_82 = None
        view_default_269 = torch.ops.aten.view.default(to_dtype_26, [25216, 3072]);  to_dtype_26 = None
        t_default_185 = torch.ops.aten.t.default(t_default_14);  t_default_14 = None
        mm_default_68 = torch.ops.aten.mm.default(view_default_269, t_default_185);  t_default_185 = None
        t_default_186 = torch.ops.aten.t.default(view_default_269)
        mm_default_69 = torch.ops.aten.mm.default(t_default_186, view_default_37);  t_default_186 = view_default_37 = None
        t_default_187 = torch.ops.aten.t.default(mm_default_69);  mm_default_69 = None
        sum_dim_int_list_34 = torch.ops.aten.sum.dim_IntList(view_default_269, [0], True);  view_default_269 = None
        view_default_270 = torch.ops.aten.view.default(sum_dim_int_list_34, [3072]);  sum_dim_int_list_34 = None
        t_default_188 = torch.ops.aten.t.default(t_default_187);  t_default_187 = None
        view_default_271 = torch.ops.aten.view.default(mm_default_68, [128, 197, 768]);  mm_default_68 = None
        native_layer_norm_backward_default_17 = torch.ops.aten.native_layer_norm_backward.default(view_default_271, add_tensor_7, [768], getitem_34, getitem_35, primals_72, primals_71, [True, True, True]);  view_default_271 = add_tensor_7 = getitem_34 = getitem_35 = primals_72 = primals_71 = None
        getitem_162 = native_layer_norm_backward_default_17[0]
        getitem_163 = native_layer_norm_backward_default_17[1]
        getitem_164 = native_layer_norm_backward_default_17[2];  native_layer_norm_backward_default_17 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(add_tensor_56, getitem_162);  add_tensor_56 = getitem_162 = None
        view_default_272 = torch.ops.aten.view.default(add_tensor_59, [25216, 768])
        t_default_189 = torch.ops.aten.t.default(t_default_13);  t_default_13 = None
        mm_default_70 = torch.ops.aten.mm.default(view_default_272, t_default_189);  t_default_189 = None
        t_default_190 = torch.ops.aten.t.default(view_default_272)
        mm_default_71 = torch.ops.aten.mm.default(t_default_190, view_default_35);  t_default_190 = view_default_35 = None
        t_default_191 = torch.ops.aten.t.default(mm_default_71);  mm_default_71 = None
        sum_dim_int_list_35 = torch.ops.aten.sum.dim_IntList(view_default_272, [0], True);  view_default_272 = None
        view_default_273 = torch.ops.aten.view.default(sum_dim_int_list_35, [768]);  sum_dim_int_list_35 = None
        t_default_192 = torch.ops.aten.t.default(t_default_191);  t_default_191 = None
        view_default_274 = torch.ops.aten.view.default(mm_default_70, [128, 197, 768]);  mm_default_70 = None
        view_default_275 = torch.ops.aten.view.default(view_default_274, [128, 197, 12, 64]);  view_default_274 = None
        transpose_int_73 = torch.ops.aten.transpose.int(view_default_275, 1, 2);  view_default_275 = None
        clone_default_64 = torch.ops.aten.clone.default(transpose_int_73, memory_format = torch.contiguous_format);  transpose_int_73 = None
        _unsafe_view_default_88 = torch.ops.aten._unsafe_view.default(clone_default_64, [1536, 197, 64]);  clone_default_64 = None
        transpose_int_74 = torch.ops.aten.transpose.int(view_default_34, 1, 2);  view_default_34 = None
        bmm_default_56 = torch.ops.aten.bmm.default(transpose_int_74, _unsafe_view_default_88);  transpose_int_74 = None
        transpose_int_75 = torch.ops.aten.transpose.int(_unsafe_view_default_21, 1, 2);  _unsafe_view_default_21 = None
        bmm_default_57 = torch.ops.aten.bmm.default(_unsafe_view_default_88, transpose_int_75);  _unsafe_view_default_88 = transpose_int_75 = None
        view_default_276 = torch.ops.aten.view.default(bmm_default_56, [128, 12, 197, 64]);  bmm_default_56 = None
        view_default_277 = torch.ops.aten.view.default(bmm_default_57, [128, 12, 197, 197]);  bmm_default_57 = None
        _softmax_backward_data_default_8 = torch.ops.aten._softmax_backward_data.default(view_default_277, _softmax_default_3, -1, torch.float32);  view_default_277 = _softmax_default_3 = None
        mul_tensor_83 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_8, 0.125);  _softmax_backward_data_default_8 = None
        view_default_278 = torch.ops.aten.view.default(mul_tensor_83, [1536, 197, 197]);  mul_tensor_83 = None
        transpose_int_76 = torch.ops.aten.transpose.int(_unsafe_view_default_18, 1, 2);  _unsafe_view_default_18 = None
        bmm_default_58 = torch.ops.aten.bmm.default(transpose_int_76, view_default_278);  transpose_int_76 = None
        transpose_int_77 = torch.ops.aten.transpose.int(_unsafe_view_default_19, 1, 2);  _unsafe_view_default_19 = None
        bmm_default_59 = torch.ops.aten.bmm.default(view_default_278, transpose_int_77);  view_default_278 = transpose_int_77 = None
        view_default_279 = torch.ops.aten.view.default(bmm_default_58, [128, 12, 64, 197]);  bmm_default_58 = None
        view_default_280 = torch.ops.aten.view.default(bmm_default_59, [128, 12, 197, 64]);  bmm_default_59 = None
        transpose_int_78 = torch.ops.aten.transpose.int(view_default_279, -2, -1);  view_default_279 = None
        stack_default_8 = torch.ops.aten.stack.default([view_default_280, transpose_int_78, view_default_276]);  view_default_280 = transpose_int_78 = view_default_276 = None
        permute_default_20 = torch.ops.aten.permute.default(stack_default_8, [1, 3, 0, 2, 4]);  stack_default_8 = None
        clone_default_65 = torch.ops.aten.clone.default(permute_default_20, memory_format = torch.contiguous_format);  permute_default_20 = None
        _unsafe_view_default_89 = torch.ops.aten._unsafe_view.default(clone_default_65, [128, 197, 2304]);  clone_default_65 = None
        view_default_281 = torch.ops.aten.view.default(_unsafe_view_default_89, [25216, 2304]);  _unsafe_view_default_89 = None
        t_default_193 = torch.ops.aten.t.default(t_default_12);  t_default_12 = None
        mm_default_72 = torch.ops.aten.mm.default(view_default_281, t_default_193);  t_default_193 = None
        t_default_194 = torch.ops.aten.t.default(view_default_281)
        mm_default_73 = torch.ops.aten.mm.default(t_default_194, view_default_31);  t_default_194 = view_default_31 = None
        t_default_195 = torch.ops.aten.t.default(mm_default_73);  mm_default_73 = None
        sum_dim_int_list_36 = torch.ops.aten.sum.dim_IntList(view_default_281, [0], True);  view_default_281 = None
        view_default_282 = torch.ops.aten.view.default(sum_dim_int_list_36, [2304]);  sum_dim_int_list_36 = None
        t_default_196 = torch.ops.aten.t.default(t_default_195);  t_default_195 = None
        view_default_283 = torch.ops.aten.view.default(mm_default_72, [128, 197, 768]);  mm_default_72 = None
        native_layer_norm_backward_default_18 = torch.ops.aten.native_layer_norm_backward.default(view_default_283, add_tensor_6, [768], getitem_28, getitem_29, primals_70, primals_69, [True, True, True]);  view_default_283 = add_tensor_6 = getitem_28 = getitem_29 = primals_70 = primals_69 = None
        getitem_165 = native_layer_norm_backward_default_18[0]
        getitem_166 = native_layer_norm_backward_default_18[1]
        getitem_167 = native_layer_norm_backward_default_18[2];  native_layer_norm_backward_default_18 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_59, getitem_165);  add_tensor_59 = getitem_165 = None
        view_default_284 = torch.ops.aten.view.default(add_tensor_60, [25216, 768])
        t_default_197 = torch.ops.aten.t.default(t_default_11);  t_default_11 = None
        mm_default_74 = torch.ops.aten.mm.default(view_default_284, t_default_197);  t_default_197 = None
        t_default_198 = torch.ops.aten.t.default(view_default_284)
        mm_default_75 = torch.ops.aten.mm.default(t_default_198, view_default_29);  t_default_198 = view_default_29 = None
        t_default_199 = torch.ops.aten.t.default(mm_default_75);  mm_default_75 = None
        sum_dim_int_list_37 = torch.ops.aten.sum.dim_IntList(view_default_284, [0], True);  view_default_284 = None
        view_default_285 = torch.ops.aten.view.default(sum_dim_int_list_37, [768]);  sum_dim_int_list_37 = None
        t_default_200 = torch.ops.aten.t.default(t_default_199);  t_default_199 = None
        view_default_286 = torch.ops.aten.view.default(mm_default_74, [128, 197, 3072]);  mm_default_74 = None
        to_dtype_27 = torch.ops.aten.to.dtype(view_default_286, torch.float32);  view_default_286 = None
        to_dtype_28 = torch.ops.aten.to.dtype(view_default_28, torch.float32);  view_default_28 = None
        mul_tensor_84 = torch.ops.aten.mul.Tensor(to_dtype_28, 0.7071067811865476)
        erf_default_9 = torch.ops.aten.erf.default(mul_tensor_84);  mul_tensor_84 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(erf_default_9, 1);  erf_default_9 = None
        mul_tensor_85 = torch.ops.aten.mul.Tensor(add_tensor_61, 0.5);  add_tensor_61 = None
        mul_tensor_86 = torch.ops.aten.mul.Tensor(to_dtype_28, to_dtype_28)
        mul_tensor_87 = torch.ops.aten.mul.Tensor(mul_tensor_86, -0.5);  mul_tensor_86 = None
        exp_default_9 = torch.ops.aten.exp.default(mul_tensor_87);  mul_tensor_87 = None
        mul_tensor_88 = torch.ops.aten.mul.Tensor(exp_default_9, 0.3989422804014327);  exp_default_9 = None
        mul_tensor_89 = torch.ops.aten.mul.Tensor(to_dtype_28, mul_tensor_88);  to_dtype_28 = mul_tensor_88 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(mul_tensor_85, mul_tensor_89);  mul_tensor_85 = mul_tensor_89 = None
        mul_tensor_90 = torch.ops.aten.mul.Tensor(to_dtype_27, add_tensor_62);  to_dtype_27 = add_tensor_62 = None
        to_dtype_29 = torch.ops.aten.to.dtype(mul_tensor_90, torch.float32);  mul_tensor_90 = None
        view_default_287 = torch.ops.aten.view.default(to_dtype_29, [25216, 3072]);  to_dtype_29 = None
        t_default_201 = torch.ops.aten.t.default(t_default_10);  t_default_10 = None
        mm_default_76 = torch.ops.aten.mm.default(view_default_287, t_default_201);  t_default_201 = None
        t_default_202 = torch.ops.aten.t.default(view_default_287)
        mm_default_77 = torch.ops.aten.mm.default(t_default_202, view_default_27);  t_default_202 = view_default_27 = None
        t_default_203 = torch.ops.aten.t.default(mm_default_77);  mm_default_77 = None
        sum_dim_int_list_38 = torch.ops.aten.sum.dim_IntList(view_default_287, [0], True);  view_default_287 = None
        view_default_288 = torch.ops.aten.view.default(sum_dim_int_list_38, [3072]);  sum_dim_int_list_38 = None
        t_default_204 = torch.ops.aten.t.default(t_default_203);  t_default_203 = None
        view_default_289 = torch.ops.aten.view.default(mm_default_76, [128, 197, 768]);  mm_default_76 = None
        native_layer_norm_backward_default_19 = torch.ops.aten.native_layer_norm_backward.default(view_default_289, add_tensor_5, [768], getitem_25, getitem_26, primals_60, primals_59, [True, True, True]);  view_default_289 = add_tensor_5 = getitem_25 = getitem_26 = primals_60 = primals_59 = None
        getitem_168 = native_layer_norm_backward_default_19[0]
        getitem_169 = native_layer_norm_backward_default_19[1]
        getitem_170 = native_layer_norm_backward_default_19[2];  native_layer_norm_backward_default_19 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(add_tensor_60, getitem_168);  add_tensor_60 = getitem_168 = None
        view_default_290 = torch.ops.aten.view.default(add_tensor_63, [25216, 768])
        t_default_205 = torch.ops.aten.t.default(t_default_9);  t_default_9 = None
        mm_default_78 = torch.ops.aten.mm.default(view_default_290, t_default_205);  t_default_205 = None
        t_default_206 = torch.ops.aten.t.default(view_default_290)
        mm_default_79 = torch.ops.aten.mm.default(t_default_206, view_default_25);  t_default_206 = view_default_25 = None
        t_default_207 = torch.ops.aten.t.default(mm_default_79);  mm_default_79 = None
        sum_dim_int_list_39 = torch.ops.aten.sum.dim_IntList(view_default_290, [0], True);  view_default_290 = None
        view_default_291 = torch.ops.aten.view.default(sum_dim_int_list_39, [768]);  sum_dim_int_list_39 = None
        t_default_208 = torch.ops.aten.t.default(t_default_207);  t_default_207 = None
        view_default_292 = torch.ops.aten.view.default(mm_default_78, [128, 197, 768]);  mm_default_78 = None
        view_default_293 = torch.ops.aten.view.default(view_default_292, [128, 197, 12, 64]);  view_default_292 = None
        transpose_int_79 = torch.ops.aten.transpose.int(view_default_293, 1, 2);  view_default_293 = None
        clone_default_66 = torch.ops.aten.clone.default(transpose_int_79, memory_format = torch.contiguous_format);  transpose_int_79 = None
        _unsafe_view_default_90 = torch.ops.aten._unsafe_view.default(clone_default_66, [1536, 197, 64]);  clone_default_66 = None
        transpose_int_80 = torch.ops.aten.transpose.int(view_default_24, 1, 2);  view_default_24 = None
        bmm_default_60 = torch.ops.aten.bmm.default(transpose_int_80, _unsafe_view_default_90);  transpose_int_80 = None
        transpose_int_81 = torch.ops.aten.transpose.int(_unsafe_view_default_15, 1, 2);  _unsafe_view_default_15 = None
        bmm_default_61 = torch.ops.aten.bmm.default(_unsafe_view_default_90, transpose_int_81);  _unsafe_view_default_90 = transpose_int_81 = None
        view_default_294 = torch.ops.aten.view.default(bmm_default_60, [128, 12, 197, 64]);  bmm_default_60 = None
        view_default_295 = torch.ops.aten.view.default(bmm_default_61, [128, 12, 197, 197]);  bmm_default_61 = None
        _softmax_backward_data_default_9 = torch.ops.aten._softmax_backward_data.default(view_default_295, _softmax_default_2, -1, torch.float32);  view_default_295 = _softmax_default_2 = None
        mul_tensor_91 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_9, 0.125);  _softmax_backward_data_default_9 = None
        view_default_296 = torch.ops.aten.view.default(mul_tensor_91, [1536, 197, 197]);  mul_tensor_91 = None
        transpose_int_82 = torch.ops.aten.transpose.int(_unsafe_view_default_12, 1, 2);  _unsafe_view_default_12 = None
        bmm_default_62 = torch.ops.aten.bmm.default(transpose_int_82, view_default_296);  transpose_int_82 = None
        transpose_int_83 = torch.ops.aten.transpose.int(_unsafe_view_default_13, 1, 2);  _unsafe_view_default_13 = None
        bmm_default_63 = torch.ops.aten.bmm.default(view_default_296, transpose_int_83);  view_default_296 = transpose_int_83 = None
        view_default_297 = torch.ops.aten.view.default(bmm_default_62, [128, 12, 64, 197]);  bmm_default_62 = None
        view_default_298 = torch.ops.aten.view.default(bmm_default_63, [128, 12, 197, 64]);  bmm_default_63 = None
        transpose_int_84 = torch.ops.aten.transpose.int(view_default_297, -2, -1);  view_default_297 = None
        stack_default_9 = torch.ops.aten.stack.default([view_default_298, transpose_int_84, view_default_294]);  view_default_298 = transpose_int_84 = view_default_294 = None
        permute_default_21 = torch.ops.aten.permute.default(stack_default_9, [1, 3, 0, 2, 4]);  stack_default_9 = None
        clone_default_67 = torch.ops.aten.clone.default(permute_default_21, memory_format = torch.contiguous_format);  permute_default_21 = None
        _unsafe_view_default_91 = torch.ops.aten._unsafe_view.default(clone_default_67, [128, 197, 2304]);  clone_default_67 = None
        view_default_299 = torch.ops.aten.view.default(_unsafe_view_default_91, [25216, 2304]);  _unsafe_view_default_91 = None
        t_default_209 = torch.ops.aten.t.default(t_default_8);  t_default_8 = None
        mm_default_80 = torch.ops.aten.mm.default(view_default_299, t_default_209);  t_default_209 = None
        t_default_210 = torch.ops.aten.t.default(view_default_299)
        mm_default_81 = torch.ops.aten.mm.default(t_default_210, view_default_21);  t_default_210 = view_default_21 = None
        t_default_211 = torch.ops.aten.t.default(mm_default_81);  mm_default_81 = None
        sum_dim_int_list_40 = torch.ops.aten.sum.dim_IntList(view_default_299, [0], True);  view_default_299 = None
        view_default_300 = torch.ops.aten.view.default(sum_dim_int_list_40, [2304]);  sum_dim_int_list_40 = None
        t_default_212 = torch.ops.aten.t.default(t_default_211);  t_default_211 = None
        view_default_301 = torch.ops.aten.view.default(mm_default_80, [128, 197, 768]);  mm_default_80 = None
        native_layer_norm_backward_default_20 = torch.ops.aten.native_layer_norm_backward.default(view_default_301, add_tensor_4, [768], getitem_19, getitem_20, primals_58, primals_57, [True, True, True]);  view_default_301 = add_tensor_4 = getitem_19 = getitem_20 = primals_58 = primals_57 = None
        getitem_171 = native_layer_norm_backward_default_20[0]
        getitem_172 = native_layer_norm_backward_default_20[1]
        getitem_173 = native_layer_norm_backward_default_20[2];  native_layer_norm_backward_default_20 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_63, getitem_171);  add_tensor_63 = getitem_171 = None
        view_default_302 = torch.ops.aten.view.default(add_tensor_64, [25216, 768])
        t_default_213 = torch.ops.aten.t.default(t_default_7);  t_default_7 = None
        mm_default_82 = torch.ops.aten.mm.default(view_default_302, t_default_213);  t_default_213 = None
        t_default_214 = torch.ops.aten.t.default(view_default_302)
        mm_default_83 = torch.ops.aten.mm.default(t_default_214, view_default_19);  t_default_214 = view_default_19 = None
        t_default_215 = torch.ops.aten.t.default(mm_default_83);  mm_default_83 = None
        sum_dim_int_list_41 = torch.ops.aten.sum.dim_IntList(view_default_302, [0], True);  view_default_302 = None
        view_default_303 = torch.ops.aten.view.default(sum_dim_int_list_41, [768]);  sum_dim_int_list_41 = None
        t_default_216 = torch.ops.aten.t.default(t_default_215);  t_default_215 = None
        view_default_304 = torch.ops.aten.view.default(mm_default_82, [128, 197, 3072]);  mm_default_82 = None
        to_dtype_30 = torch.ops.aten.to.dtype(view_default_304, torch.float32);  view_default_304 = None
        to_dtype_31 = torch.ops.aten.to.dtype(view_default_18, torch.float32);  view_default_18 = None
        mul_tensor_92 = torch.ops.aten.mul.Tensor(to_dtype_31, 0.7071067811865476)
        erf_default_10 = torch.ops.aten.erf.default(mul_tensor_92);  mul_tensor_92 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(erf_default_10, 1);  erf_default_10 = None
        mul_tensor_93 = torch.ops.aten.mul.Tensor(add_tensor_65, 0.5);  add_tensor_65 = None
        mul_tensor_94 = torch.ops.aten.mul.Tensor(to_dtype_31, to_dtype_31)
        mul_tensor_95 = torch.ops.aten.mul.Tensor(mul_tensor_94, -0.5);  mul_tensor_94 = None
        exp_default_10 = torch.ops.aten.exp.default(mul_tensor_95);  mul_tensor_95 = None
        mul_tensor_96 = torch.ops.aten.mul.Tensor(exp_default_10, 0.3989422804014327);  exp_default_10 = None
        mul_tensor_97 = torch.ops.aten.mul.Tensor(to_dtype_31, mul_tensor_96);  to_dtype_31 = mul_tensor_96 = None
        add_tensor_66 = torch.ops.aten.add.Tensor(mul_tensor_93, mul_tensor_97);  mul_tensor_93 = mul_tensor_97 = None
        mul_tensor_98 = torch.ops.aten.mul.Tensor(to_dtype_30, add_tensor_66);  to_dtype_30 = add_tensor_66 = None
        to_dtype_32 = torch.ops.aten.to.dtype(mul_tensor_98, torch.float32);  mul_tensor_98 = None
        view_default_305 = torch.ops.aten.view.default(to_dtype_32, [25216, 3072]);  to_dtype_32 = None
        t_default_217 = torch.ops.aten.t.default(t_default_6);  t_default_6 = None
        mm_default_84 = torch.ops.aten.mm.default(view_default_305, t_default_217);  t_default_217 = None
        t_default_218 = torch.ops.aten.t.default(view_default_305)
        mm_default_85 = torch.ops.aten.mm.default(t_default_218, view_default_17);  t_default_218 = view_default_17 = None
        t_default_219 = torch.ops.aten.t.default(mm_default_85);  mm_default_85 = None
        sum_dim_int_list_42 = torch.ops.aten.sum.dim_IntList(view_default_305, [0], True);  view_default_305 = None
        view_default_306 = torch.ops.aten.view.default(sum_dim_int_list_42, [3072]);  sum_dim_int_list_42 = None
        t_default_220 = torch.ops.aten.t.default(t_default_219);  t_default_219 = None
        view_default_307 = torch.ops.aten.view.default(mm_default_84, [128, 197, 768]);  mm_default_84 = None
        native_layer_norm_backward_default_21 = torch.ops.aten.native_layer_norm_backward.default(view_default_307, add_tensor_3, [768], getitem_16, getitem_17, primals_48, primals_47, [True, True, True]);  view_default_307 = add_tensor_3 = getitem_16 = getitem_17 = primals_48 = primals_47 = None
        getitem_174 = native_layer_norm_backward_default_21[0]
        getitem_175 = native_layer_norm_backward_default_21[1]
        getitem_176 = native_layer_norm_backward_default_21[2];  native_layer_norm_backward_default_21 = None
        add_tensor_67 = torch.ops.aten.add.Tensor(add_tensor_64, getitem_174);  add_tensor_64 = getitem_174 = None
        view_default_308 = torch.ops.aten.view.default(add_tensor_67, [25216, 768])
        t_default_221 = torch.ops.aten.t.default(t_default_5);  t_default_5 = None
        mm_default_86 = torch.ops.aten.mm.default(view_default_308, t_default_221);  t_default_221 = None
        t_default_222 = torch.ops.aten.t.default(view_default_308)
        mm_default_87 = torch.ops.aten.mm.default(t_default_222, view_default_15);  t_default_222 = view_default_15 = None
        t_default_223 = torch.ops.aten.t.default(mm_default_87);  mm_default_87 = None
        sum_dim_int_list_43 = torch.ops.aten.sum.dim_IntList(view_default_308, [0], True);  view_default_308 = None
        view_default_309 = torch.ops.aten.view.default(sum_dim_int_list_43, [768]);  sum_dim_int_list_43 = None
        t_default_224 = torch.ops.aten.t.default(t_default_223);  t_default_223 = None
        view_default_310 = torch.ops.aten.view.default(mm_default_86, [128, 197, 768]);  mm_default_86 = None
        view_default_311 = torch.ops.aten.view.default(view_default_310, [128, 197, 12, 64]);  view_default_310 = None
        transpose_int_85 = torch.ops.aten.transpose.int(view_default_311, 1, 2);  view_default_311 = None
        clone_default_68 = torch.ops.aten.clone.default(transpose_int_85, memory_format = torch.contiguous_format);  transpose_int_85 = None
        _unsafe_view_default_92 = torch.ops.aten._unsafe_view.default(clone_default_68, [1536, 197, 64]);  clone_default_68 = None
        transpose_int_86 = torch.ops.aten.transpose.int(view_default_14, 1, 2);  view_default_14 = None
        bmm_default_64 = torch.ops.aten.bmm.default(transpose_int_86, _unsafe_view_default_92);  transpose_int_86 = None
        transpose_int_87 = torch.ops.aten.transpose.int(_unsafe_view_default_9, 1, 2);  _unsafe_view_default_9 = None
        bmm_default_65 = torch.ops.aten.bmm.default(_unsafe_view_default_92, transpose_int_87);  _unsafe_view_default_92 = transpose_int_87 = None
        view_default_312 = torch.ops.aten.view.default(bmm_default_64, [128, 12, 197, 64]);  bmm_default_64 = None
        view_default_313 = torch.ops.aten.view.default(bmm_default_65, [128, 12, 197, 197]);  bmm_default_65 = None
        _softmax_backward_data_default_10 = torch.ops.aten._softmax_backward_data.default(view_default_313, _softmax_default_1, -1, torch.float32);  view_default_313 = _softmax_default_1 = None
        mul_tensor_99 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_10, 0.125);  _softmax_backward_data_default_10 = None
        view_default_314 = torch.ops.aten.view.default(mul_tensor_99, [1536, 197, 197]);  mul_tensor_99 = None
        transpose_int_88 = torch.ops.aten.transpose.int(_unsafe_view_default_6, 1, 2);  _unsafe_view_default_6 = None
        bmm_default_66 = torch.ops.aten.bmm.default(transpose_int_88, view_default_314);  transpose_int_88 = None
        transpose_int_89 = torch.ops.aten.transpose.int(_unsafe_view_default_7, 1, 2);  _unsafe_view_default_7 = None
        bmm_default_67 = torch.ops.aten.bmm.default(view_default_314, transpose_int_89);  view_default_314 = transpose_int_89 = None
        view_default_315 = torch.ops.aten.view.default(bmm_default_66, [128, 12, 64, 197]);  bmm_default_66 = None
        view_default_316 = torch.ops.aten.view.default(bmm_default_67, [128, 12, 197, 64]);  bmm_default_67 = None
        transpose_int_90 = torch.ops.aten.transpose.int(view_default_315, -2, -1);  view_default_315 = None
        stack_default_10 = torch.ops.aten.stack.default([view_default_316, transpose_int_90, view_default_312]);  view_default_316 = transpose_int_90 = view_default_312 = None
        permute_default_22 = torch.ops.aten.permute.default(stack_default_10, [1, 3, 0, 2, 4]);  stack_default_10 = None
        clone_default_69 = torch.ops.aten.clone.default(permute_default_22, memory_format = torch.contiguous_format);  permute_default_22 = None
        _unsafe_view_default_93 = torch.ops.aten._unsafe_view.default(clone_default_69, [128, 197, 2304]);  clone_default_69 = None
        view_default_317 = torch.ops.aten.view.default(_unsafe_view_default_93, [25216, 2304]);  _unsafe_view_default_93 = None
        t_default_225 = torch.ops.aten.t.default(t_default_4);  t_default_4 = None
        mm_default_88 = torch.ops.aten.mm.default(view_default_317, t_default_225);  t_default_225 = None
        t_default_226 = torch.ops.aten.t.default(view_default_317)
        mm_default_89 = torch.ops.aten.mm.default(t_default_226, view_default_11);  t_default_226 = view_default_11 = None
        t_default_227 = torch.ops.aten.t.default(mm_default_89);  mm_default_89 = None
        sum_dim_int_list_44 = torch.ops.aten.sum.dim_IntList(view_default_317, [0], True);  view_default_317 = None
        view_default_318 = torch.ops.aten.view.default(sum_dim_int_list_44, [2304]);  sum_dim_int_list_44 = None
        t_default_228 = torch.ops.aten.t.default(t_default_227);  t_default_227 = None
        view_default_319 = torch.ops.aten.view.default(mm_default_88, [128, 197, 768]);  mm_default_88 = None
        native_layer_norm_backward_default_22 = torch.ops.aten.native_layer_norm_backward.default(view_default_319, add_tensor_2, [768], getitem_10, getitem_11, primals_46, primals_45, [True, True, True]);  view_default_319 = add_tensor_2 = getitem_10 = getitem_11 = primals_46 = primals_45 = None
        getitem_177 = native_layer_norm_backward_default_22[0]
        getitem_178 = native_layer_norm_backward_default_22[1]
        getitem_179 = native_layer_norm_backward_default_22[2];  native_layer_norm_backward_default_22 = None
        add_tensor_68 = torch.ops.aten.add.Tensor(add_tensor_67, getitem_177);  add_tensor_67 = getitem_177 = None
        view_default_320 = torch.ops.aten.view.default(add_tensor_68, [25216, 768])
        t_default_229 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        mm_default_90 = torch.ops.aten.mm.default(view_default_320, t_default_229);  t_default_229 = None
        t_default_230 = torch.ops.aten.t.default(view_default_320)
        mm_default_91 = torch.ops.aten.mm.default(t_default_230, view_default_9);  t_default_230 = view_default_9 = None
        t_default_231 = torch.ops.aten.t.default(mm_default_91);  mm_default_91 = None
        sum_dim_int_list_45 = torch.ops.aten.sum.dim_IntList(view_default_320, [0], True);  view_default_320 = None
        view_default_321 = torch.ops.aten.view.default(sum_dim_int_list_45, [768]);  sum_dim_int_list_45 = None
        t_default_232 = torch.ops.aten.t.default(t_default_231);  t_default_231 = None
        view_default_322 = torch.ops.aten.view.default(mm_default_90, [128, 197, 3072]);  mm_default_90 = None
        to_dtype_33 = torch.ops.aten.to.dtype(view_default_322, torch.float32);  view_default_322 = None
        to_dtype_34 = torch.ops.aten.to.dtype(view_default_8, torch.float32);  view_default_8 = None
        mul_tensor_100 = torch.ops.aten.mul.Tensor(to_dtype_34, 0.7071067811865476)
        erf_default_11 = torch.ops.aten.erf.default(mul_tensor_100);  mul_tensor_100 = None
        add_tensor_69 = torch.ops.aten.add.Tensor(erf_default_11, 1);  erf_default_11 = None
        mul_tensor_101 = torch.ops.aten.mul.Tensor(add_tensor_69, 0.5);  add_tensor_69 = None
        mul_tensor_102 = torch.ops.aten.mul.Tensor(to_dtype_34, to_dtype_34)
        mul_tensor_103 = torch.ops.aten.mul.Tensor(mul_tensor_102, -0.5);  mul_tensor_102 = None
        exp_default_11 = torch.ops.aten.exp.default(mul_tensor_103);  mul_tensor_103 = None
        mul_tensor_104 = torch.ops.aten.mul.Tensor(exp_default_11, 0.3989422804014327);  exp_default_11 = None
        mul_tensor_105 = torch.ops.aten.mul.Tensor(to_dtype_34, mul_tensor_104);  to_dtype_34 = mul_tensor_104 = None
        add_tensor_70 = torch.ops.aten.add.Tensor(mul_tensor_101, mul_tensor_105);  mul_tensor_101 = mul_tensor_105 = None
        mul_tensor_106 = torch.ops.aten.mul.Tensor(to_dtype_33, add_tensor_70);  to_dtype_33 = add_tensor_70 = None
        to_dtype_35 = torch.ops.aten.to.dtype(mul_tensor_106, torch.float32);  mul_tensor_106 = None
        view_default_323 = torch.ops.aten.view.default(to_dtype_35, [25216, 3072]);  to_dtype_35 = None
        t_default_233 = torch.ops.aten.t.default(t_default_2);  t_default_2 = None
        mm_default_92 = torch.ops.aten.mm.default(view_default_323, t_default_233);  t_default_233 = None
        t_default_234 = torch.ops.aten.t.default(view_default_323)
        mm_default_93 = torch.ops.aten.mm.default(t_default_234, view_default_7);  t_default_234 = view_default_7 = None
        t_default_235 = torch.ops.aten.t.default(mm_default_93);  mm_default_93 = None
        sum_dim_int_list_46 = torch.ops.aten.sum.dim_IntList(view_default_323, [0], True);  view_default_323 = None
        view_default_324 = torch.ops.aten.view.default(sum_dim_int_list_46, [3072]);  sum_dim_int_list_46 = None
        t_default_236 = torch.ops.aten.t.default(t_default_235);  t_default_235 = None
        view_default_325 = torch.ops.aten.view.default(mm_default_92, [128, 197, 768]);  mm_default_92 = None
        native_layer_norm_backward_default_23 = torch.ops.aten.native_layer_norm_backward.default(view_default_325, add_tensor_1, [768], getitem_7, getitem_8, primals_12, primals_11, [True, True, True]);  view_default_325 = add_tensor_1 = getitem_7 = getitem_8 = primals_12 = primals_11 = None
        getitem_180 = native_layer_norm_backward_default_23[0]
        getitem_181 = native_layer_norm_backward_default_23[1]
        getitem_182 = native_layer_norm_backward_default_23[2];  native_layer_norm_backward_default_23 = None
        add_tensor_71 = torch.ops.aten.add.Tensor(add_tensor_68, getitem_180);  add_tensor_68 = getitem_180 = None
        view_default_326 = torch.ops.aten.view.default(add_tensor_71, [25216, 768])
        t_default_237 = torch.ops.aten.t.default(t_default_1);  t_default_1 = None
        mm_default_94 = torch.ops.aten.mm.default(view_default_326, t_default_237);  t_default_237 = None
        t_default_238 = torch.ops.aten.t.default(view_default_326)
        mm_default_95 = torch.ops.aten.mm.default(t_default_238, view_default_5);  t_default_238 = view_default_5 = None
        t_default_239 = torch.ops.aten.t.default(mm_default_95);  mm_default_95 = None
        sum_dim_int_list_47 = torch.ops.aten.sum.dim_IntList(view_default_326, [0], True);  view_default_326 = None
        view_default_327 = torch.ops.aten.view.default(sum_dim_int_list_47, [768]);  sum_dim_int_list_47 = None
        t_default_240 = torch.ops.aten.t.default(t_default_239);  t_default_239 = None
        view_default_328 = torch.ops.aten.view.default(mm_default_94, [128, 197, 768]);  mm_default_94 = None
        view_default_329 = torch.ops.aten.view.default(view_default_328, [128, 197, 12, 64]);  view_default_328 = None
        transpose_int_91 = torch.ops.aten.transpose.int(view_default_329, 1, 2);  view_default_329 = None
        clone_default_70 = torch.ops.aten.clone.default(transpose_int_91, memory_format = torch.contiguous_format);  transpose_int_91 = None
        _unsafe_view_default_94 = torch.ops.aten._unsafe_view.default(clone_default_70, [1536, 197, 64]);  clone_default_70 = None
        transpose_int_92 = torch.ops.aten.transpose.int(view_default_4, 1, 2);  view_default_4 = None
        bmm_default_68 = torch.ops.aten.bmm.default(transpose_int_92, _unsafe_view_default_94);  transpose_int_92 = None
        transpose_int_93 = torch.ops.aten.transpose.int(_unsafe_view_default_3, 1, 2);  _unsafe_view_default_3 = None
        bmm_default_69 = torch.ops.aten.bmm.default(_unsafe_view_default_94, transpose_int_93);  _unsafe_view_default_94 = transpose_int_93 = None
        view_default_330 = torch.ops.aten.view.default(bmm_default_68, [128, 12, 197, 64]);  bmm_default_68 = None
        view_default_331 = torch.ops.aten.view.default(bmm_default_69, [128, 12, 197, 197]);  bmm_default_69 = None
        _softmax_backward_data_default_11 = torch.ops.aten._softmax_backward_data.default(view_default_331, _softmax_default, -1, torch.float32);  view_default_331 = _softmax_default = None
        mul_tensor_107 = torch.ops.aten.mul.Tensor(_softmax_backward_data_default_11, 0.125);  _softmax_backward_data_default_11 = None
        view_default_332 = torch.ops.aten.view.default(mul_tensor_107, [1536, 197, 197]);  mul_tensor_107 = None
        transpose_int_94 = torch.ops.aten.transpose.int(_unsafe_view_default, 1, 2);  _unsafe_view_default = None
        bmm_default_70 = torch.ops.aten.bmm.default(transpose_int_94, view_default_332);  transpose_int_94 = None
        transpose_int_95 = torch.ops.aten.transpose.int(_unsafe_view_default_1, 1, 2);  _unsafe_view_default_1 = None
        bmm_default_71 = torch.ops.aten.bmm.default(view_default_332, transpose_int_95);  view_default_332 = transpose_int_95 = None
        view_default_333 = torch.ops.aten.view.default(bmm_default_70, [128, 12, 64, 197]);  bmm_default_70 = None
        view_default_334 = torch.ops.aten.view.default(bmm_default_71, [128, 12, 197, 64]);  bmm_default_71 = None
        transpose_int_96 = torch.ops.aten.transpose.int(view_default_333, -2, -1);  view_default_333 = None
        stack_default_11 = torch.ops.aten.stack.default([view_default_334, transpose_int_96, view_default_330]);  view_default_334 = transpose_int_96 = view_default_330 = None
        permute_default_23 = torch.ops.aten.permute.default(stack_default_11, [1, 3, 0, 2, 4]);  stack_default_11 = None
        clone_default_71 = torch.ops.aten.clone.default(permute_default_23, memory_format = torch.contiguous_format);  permute_default_23 = None
        _unsafe_view_default_95 = torch.ops.aten._unsafe_view.default(clone_default_71, [128, 197, 2304]);  clone_default_71 = None
        view_default_335 = torch.ops.aten.view.default(_unsafe_view_default_95, [25216, 2304]);  _unsafe_view_default_95 = None
        t_default_241 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default_96 = torch.ops.aten.mm.default(view_default_335, t_default_241);  t_default_241 = None
        t_default_242 = torch.ops.aten.t.default(view_default_335)
        mm_default_97 = torch.ops.aten.mm.default(t_default_242, view_default_1);  t_default_242 = view_default_1 = None
        t_default_243 = torch.ops.aten.t.default(mm_default_97);  mm_default_97 = None
        sum_dim_int_list_48 = torch.ops.aten.sum.dim_IntList(view_default_335, [0], True);  view_default_335 = None
        view_default_336 = torch.ops.aten.view.default(sum_dim_int_list_48, [2304]);  sum_dim_int_list_48 = None
        t_default_244 = torch.ops.aten.t.default(t_default_243);  t_default_243 = None
        view_default_337 = torch.ops.aten.view.default(mm_default_96, [128, 197, 768]);  mm_default_96 = None
        native_layer_norm_backward_default_24 = torch.ops.aten.native_layer_norm_backward.default(view_default_337, add_tensor, [768], getitem_1, getitem_2, primals_10, primals_9, [True, True, True]);  view_default_337 = add_tensor = getitem_1 = getitem_2 = primals_10 = primals_9 = None
        getitem_183 = native_layer_norm_backward_default_24[0]
        getitem_184 = native_layer_norm_backward_default_24[1]
        getitem_185 = native_layer_norm_backward_default_24[2];  native_layer_norm_backward_default_24 = None
        add_tensor_72 = torch.ops.aten.add.Tensor(add_tensor_71, getitem_183);  add_tensor_71 = getitem_183 = None
        sum_dim_int_list_49 = torch.ops.aten.sum.dim_IntList(add_tensor_72, [0], True)
        slice_tensor_1 = torch.ops.aten.slice.Tensor(add_tensor_72, 1, 0, 1)
        slice_tensor_2 = torch.ops.aten.slice.Tensor(add_tensor_72, 1, 1, 197);  add_tensor_72 = None
        sum_dim_int_list_50 = torch.ops.aten.sum.dim_IntList(slice_tensor_1, [0], True);  slice_tensor_1 = None
        transpose_int_97 = torch.ops.aten.transpose.int(slice_tensor_2, 1, 2);  slice_tensor_2 = None
        view_default_338 = torch.ops.aten.view.default(transpose_int_97, [128, 768, 14, 14]);  transpose_int_97 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(view_default_338, primals_153, primals_151, [768], [16, 16], [0, 0], [1, 1], False, [0, 0], 1, [False, True, True]);  view_default_338 = primals_153 = primals_151 = None
        getitem_187 = convolution_backward_default[1]
        getitem_188 = convolution_backward_default[2];  convolution_backward_default = None
        return [view_default_327, t_default_240, view_default_336, t_default_244, view_default_324, t_default_236, view_default_321, t_default_232, getitem_185, getitem_184, getitem_182, getitem_181, view_default_147, t_default_80, view_default_156, t_default_84, view_default_144, t_default_76, view_default_141, t_default_72, getitem_125, getitem_124, getitem_122, getitem_121, view_default_129, t_default_64, view_default_138, t_default_68, view_default_126, t_default_60, view_default_123, t_default_56, getitem_119, getitem_118, getitem_116, getitem_115, view_default_309, t_default_224, view_default_318, t_default_228, view_default_306, t_default_220, view_default_303, t_default_216, getitem_179, getitem_178, getitem_176, getitem_175, view_default_291, t_default_208, view_default_300, t_default_212, view_default_288, t_default_204, view_default_285, t_default_200, getitem_173, getitem_172, getitem_170, getitem_169, view_default_273, t_default_192, view_default_282, t_default_196, view_default_270, t_default_188, view_default_267, t_default_184, getitem_167, getitem_166, getitem_164, getitem_163, view_default_255, t_default_176, view_default_264, t_default_180, view_default_252, t_default_172, view_default_249, t_default_168, getitem_161, getitem_160, getitem_158, getitem_157, view_default_237, t_default_160, view_default_246, t_default_164, view_default_234, t_default_156, view_default_231, t_default_152, getitem_155, getitem_154, getitem_152, getitem_151, view_default_219, t_default_144, view_default_228, t_default_148, view_default_216, t_default_140, view_default_213, t_default_136, getitem_149, getitem_148, getitem_146, getitem_145, view_default_201, t_default_128, view_default_210, t_default_132, view_default_198, t_default_124, view_default_195, t_default_120, getitem_143, getitem_142, getitem_140, getitem_139, view_default_183, t_default_112, view_default_192, t_default_116, view_default_180, t_default_108, view_default_177, t_default_104, getitem_137, getitem_136, getitem_134, getitem_133, view_default_165, t_default_96, view_default_174, t_default_100, view_default_162, t_default_92, view_default_159, t_default_88, getitem_131, getitem_130, getitem_128, getitem_127, sum_dim_int_list_50, view_default_121, t_default_52, getitem_113, getitem_112, getitem_188, getitem_187, sum_dim_int_list_49, None]
        
