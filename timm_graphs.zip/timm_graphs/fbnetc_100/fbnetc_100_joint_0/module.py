
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/fbnetc_100/fbnetc_100_joint_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307, primals_308, primals_309, primals_310, primals_311, primals_312, primals_313, primals_314, primals_315, primals_316, primals_317, primals_318, primals_319, primals_320, primals_321, primals_322, primals_323, primals_324, primals_325, primals_326, primals_327, primals_328, primals_329, primals_330, primals_331, primals_332, primals_333, primals_334, primals_335, primals_336, primals_337, primals_338, primals_339, primals_340, primals_341, primals_342, primals_343, primals_344, primals_345, primals_346, primals_347, primals_348, primals_349, primals_350, primals_351, primals_352, primals_353, primals_354, primals_355, primals_356, primals_357, primals_358, primals_359, primals_360, primals_361, primals_362, primals_363, primals_364, primals_365, primals_366, primals_367, primals_368, primals_369, primals_370, primals_371, primals_372, primals_373, primals_374, primals_375, primals_376, primals_377, primals_378, primals_379, primals_380, primals_381, primals_382, primals_383, primals_384, primals_385, primals_386, primals_387, primals_388, primals_389, primals_390, primals_391, primals_392, primals_393, tangents_1, tangents_2, tangents_3, tangents_4, tangents_5, tangents_6, tangents_7, tangents_8, tangents_9, tangents_10, tangents_11, tangents_12, tangents_13, tangents_14, tangents_15, tangents_16, tangents_17, tangents_18, tangents_19, tangents_20, tangents_21, tangents_22, tangents_23, tangents_24, tangents_25, tangents_26, tangents_27, tangents_28, tangents_29, tangents_30, tangents_31, tangents_32, tangents_33, tangents_34, tangents_35, tangents_36, tangents_37, tangents_38, tangents_39, tangents_40, tangents_41, tangents_42, tangents_43, tangents_44, tangents_45, tangents_46, tangents_47, tangents_48, tangents_49, tangents_50, tangents_51, tangents_52, tangents_53, tangents_54, tangents_55, tangents_56, tangents_57, tangents_58, tangents_59, tangents_60, tangents_61, tangents_62, tangents_63, tangents_64, tangents_65, tangents_66):
        convolution_default = torch.ops.aten.convolution.default(primals_68, primals_67, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(primals_69, 1);  primals_69 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(convolution_default, primals_72, primals_73, primals_70, primals_71, True, 0.1, 1e-05);  primals_73 = None
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        new_zeros_default = torch.ops.aten.new_zeros.default(convolution_default, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default = torch.ops.aten.relu_.default(getitem);  getitem = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, primals_2, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(primals_74, 1);  primals_74 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(convolution_default_1, primals_77, primals_78, primals_75, primals_76, True, 0.1, 1e-05);  primals_78 = None
        getitem_3 = native_batch_norm_default_1[0]
        getitem_4 = native_batch_norm_default_1[1]
        getitem_5 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(convolution_default_1, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_1 = torch.ops.aten.relu_.default(getitem_3);  getitem_3 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default_1, primals_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 16)
        add_tensor_2 = torch.ops.aten.add.Tensor(primals_79, 1);  primals_79 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(convolution_default_2, primals_82, primals_83, primals_80, primals_81, True, 0.1, 1e-05);  primals_83 = None
        getitem_6 = native_batch_norm_default_2[0]
        getitem_7 = native_batch_norm_default_2[1]
        getitem_8 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(convolution_default_2, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_2 = torch.ops.aten.relu_.default(getitem_6);  getitem_6 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_2, primals_3, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(primals_84, 1);  primals_84 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(convolution_default_3, primals_87, primals_88, primals_85, primals_86, True, 0.1, 1e-05);  primals_88 = None
        getitem_9 = native_batch_norm_default_3[0]
        getitem_10 = native_batch_norm_default_3[1]
        getitem_11 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(convolution_default_3, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_4 = torch.ops.aten.add.Tensor(getitem_9, relu__default);  getitem_9 = None
        convolution_default_4 = torch.ops.aten.convolution.default(add_tensor_4, primals_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(primals_89, 1);  primals_89 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(convolution_default_4, primals_92, primals_93, primals_90, primals_91, True, 0.1, 1e-05);  primals_93 = None
        getitem_12 = native_batch_norm_default_4[0]
        getitem_13 = native_batch_norm_default_4[1]
        getitem_14 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(convolution_default_4, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_3 = torch.ops.aten.relu_.default(getitem_12);  getitem_12 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_3, primals_4, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 96)
        add_tensor_6 = torch.ops.aten.add.Tensor(primals_94, 1);  primals_94 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(convolution_default_5, primals_97, primals_98, primals_95, primals_96, True, 0.1, 1e-05);  primals_98 = None
        getitem_15 = native_batch_norm_default_5[0]
        getitem_16 = native_batch_norm_default_5[1]
        getitem_17 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(convolution_default_5, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_4 = torch.ops.aten.relu_.default(getitem_15);  getitem_15 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, primals_6, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(primals_99, 1);  primals_99 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(convolution_default_6, primals_102, primals_103, primals_100, primals_101, True, 0.1, 1e-05);  primals_103 = None
        getitem_18 = native_batch_norm_default_6[0]
        getitem_19 = native_batch_norm_default_6[1]
        getitem_20 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(convolution_default_6, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_7 = torch.ops.aten.convolution.default(getitem_18, primals_8, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(primals_104, 1);  primals_104 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(convolution_default_7, primals_107, primals_108, primals_105, primals_106, True, 0.1, 1e-05);  primals_108 = None
        getitem_21 = native_batch_norm_default_7[0]
        getitem_22 = native_batch_norm_default_7[1]
        getitem_23 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(convolution_default_7, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_5 = torch.ops.aten.relu_.default(getitem_21);  getitem_21 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_5, primals_7, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 24)
        add_tensor_9 = torch.ops.aten.add.Tensor(primals_109, 1);  primals_109 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(convolution_default_8, primals_112, primals_113, primals_110, primals_111, True, 0.1, 1e-05);  primals_113 = None
        getitem_24 = native_batch_norm_default_8[0]
        getitem_25 = native_batch_norm_default_8[1]
        getitem_26 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(convolution_default_8, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_6 = torch.ops.aten.relu_.default(getitem_24);  getitem_24 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_6, primals_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(primals_114, 1);  primals_114 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(convolution_default_9, primals_117, primals_118, primals_115, primals_116, True, 0.1, 1e-05);  primals_118 = None
        getitem_27 = native_batch_norm_default_9[0]
        getitem_28 = native_batch_norm_default_9[1]
        getitem_29 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(convolution_default_9, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_11 = torch.ops.aten.add.Tensor(getitem_27, getitem_18);  getitem_27 = None
        convolution_default_10 = torch.ops.aten.convolution.default(add_tensor_11, primals_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(primals_119, 1);  primals_119 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(convolution_default_10, primals_122, primals_123, primals_120, primals_121, True, 0.1, 1e-05);  primals_123 = None
        getitem_30 = native_batch_norm_default_10[0]
        getitem_31 = native_batch_norm_default_10[1]
        getitem_32 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(convolution_default_10, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_7 = torch.ops.aten.relu_.default(getitem_30);  getitem_30 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_7, primals_10, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 24)
        add_tensor_13 = torch.ops.aten.add.Tensor(primals_124, 1);  primals_124 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(convolution_default_11, primals_127, primals_128, primals_125, primals_126, True, 0.1, 1e-05);  primals_128 = None
        getitem_33 = native_batch_norm_default_11[0]
        getitem_34 = native_batch_norm_default_11[1]
        getitem_35 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(convolution_default_11, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_8 = torch.ops.aten.relu_.default(getitem_33);  getitem_33 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_8, primals_12, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(primals_129, 1);  primals_129 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(convolution_default_12, primals_132, primals_133, primals_130, primals_131, True, 0.1, 1e-05);  primals_133 = None
        getitem_36 = native_batch_norm_default_12[0]
        getitem_37 = native_batch_norm_default_12[1]
        getitem_38 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(convolution_default_12, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_15 = torch.ops.aten.add.Tensor(getitem_36, add_tensor_11);  getitem_36 = None
        convolution_default_13 = torch.ops.aten.convolution.default(add_tensor_15, primals_14, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(primals_134, 1);  primals_134 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(convolution_default_13, primals_137, primals_138, primals_135, primals_136, True, 0.1, 1e-05);  primals_138 = None
        getitem_39 = native_batch_norm_default_13[0]
        getitem_40 = native_batch_norm_default_13[1]
        getitem_41 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(convolution_default_13, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_9 = torch.ops.aten.relu_.default(getitem_39);  getitem_39 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_9, primals_13, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 144)
        add_tensor_17 = torch.ops.aten.add.Tensor(primals_139, 1);  primals_139 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(convolution_default_14, primals_142, primals_143, primals_140, primals_141, True, 0.1, 1e-05);  primals_143 = None
        getitem_42 = native_batch_norm_default_14[0]
        getitem_43 = native_batch_norm_default_14[1]
        getitem_44 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(convolution_default_14, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_10 = torch.ops.aten.relu_.default(getitem_42);  getitem_42 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_10, primals_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(primals_144, 1);  primals_144 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(convolution_default_15, primals_147, primals_148, primals_145, primals_146, True, 0.1, 1e-05);  primals_148 = None
        getitem_45 = native_batch_norm_default_15[0]
        getitem_46 = native_batch_norm_default_15[1]
        getitem_47 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(convolution_default_15, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_16 = torch.ops.aten.convolution.default(getitem_45, primals_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(primals_149, 1);  primals_149 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(convolution_default_16, primals_152, primals_153, primals_150, primals_151, True, 0.1, 1e-05);  primals_153 = None
        getitem_48 = native_batch_norm_default_16[0]
        getitem_49 = native_batch_norm_default_16[1]
        getitem_50 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(convolution_default_16, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_11 = torch.ops.aten.relu_.default(getitem_48);  getitem_48 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_11, primals_16, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 96)
        add_tensor_20 = torch.ops.aten.add.Tensor(primals_154, 1);  primals_154 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(convolution_default_17, primals_157, primals_158, primals_155, primals_156, True, 0.1, 1e-05);  primals_158 = None
        getitem_51 = native_batch_norm_default_17[0]
        getitem_52 = native_batch_norm_default_17[1]
        getitem_53 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(convolution_default_17, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_12 = torch.ops.aten.relu_.default(getitem_51);  getitem_51 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_12, primals_18, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(primals_159, 1);  primals_159 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(convolution_default_18, primals_162, primals_163, primals_160, primals_161, True, 0.1, 1e-05);  primals_163 = None
        getitem_54 = native_batch_norm_default_18[0]
        getitem_55 = native_batch_norm_default_18[1]
        getitem_56 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(convolution_default_18, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_22 = torch.ops.aten.add.Tensor(getitem_54, getitem_45);  getitem_54 = None
        convolution_default_19 = torch.ops.aten.convolution.default(add_tensor_22, primals_20, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(primals_164, 1);  primals_164 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(convolution_default_19, primals_167, primals_168, primals_165, primals_166, True, 0.1, 1e-05);  primals_168 = None
        getitem_57 = native_batch_norm_default_19[0]
        getitem_58 = native_batch_norm_default_19[1]
        getitem_59 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(convolution_default_19, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_13 = torch.ops.aten.relu_.default(getitem_57);  getitem_57 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_13, primals_19, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 192)
        add_tensor_24 = torch.ops.aten.add.Tensor(primals_169, 1);  primals_169 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(convolution_default_20, primals_172, primals_173, primals_170, primals_171, True, 0.1, 1e-05);  primals_173 = None
        getitem_60 = native_batch_norm_default_20[0]
        getitem_61 = native_batch_norm_default_20[1]
        getitem_62 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(convolution_default_20, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_14 = torch.ops.aten.relu_.default(getitem_60);  getitem_60 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_14, primals_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_25 = torch.ops.aten.add.Tensor(primals_174, 1);  primals_174 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(convolution_default_21, primals_177, primals_178, primals_175, primals_176, True, 0.1, 1e-05);  primals_178 = None
        getitem_63 = native_batch_norm_default_21[0]
        getitem_64 = native_batch_norm_default_21[1]
        getitem_65 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(convolution_default_21, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_26 = torch.ops.aten.add.Tensor(getitem_63, add_tensor_22);  getitem_63 = None
        convolution_default_22 = torch.ops.aten.convolution.default(add_tensor_26, primals_23, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_27 = torch.ops.aten.add.Tensor(primals_179, 1);  primals_179 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(convolution_default_22, primals_182, primals_183, primals_180, primals_181, True, 0.1, 1e-05);  primals_183 = None
        getitem_66 = native_batch_norm_default_22[0]
        getitem_67 = native_batch_norm_default_22[1]
        getitem_68 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(convolution_default_22, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_15 = torch.ops.aten.relu_.default(getitem_66);  getitem_66 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_15, primals_22, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 192)
        add_tensor_28 = torch.ops.aten.add.Tensor(primals_184, 1);  primals_184 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(convolution_default_23, primals_187, primals_188, primals_185, primals_186, True, 0.1, 1e-05);  primals_188 = None
        getitem_69 = native_batch_norm_default_23[0]
        getitem_70 = native_batch_norm_default_23[1]
        getitem_71 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(convolution_default_23, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_16 = torch.ops.aten.relu_.default(getitem_69);  getitem_69 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_16, primals_24, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_29 = torch.ops.aten.add.Tensor(primals_189, 1);  primals_189 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(convolution_default_24, primals_192, primals_193, primals_190, primals_191, True, 0.1, 1e-05);  primals_193 = None
        getitem_72 = native_batch_norm_default_24[0]
        getitem_73 = native_batch_norm_default_24[1]
        getitem_74 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(convolution_default_24, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_30 = torch.ops.aten.add.Tensor(getitem_72, add_tensor_26);  getitem_72 = None
        convolution_default_25 = torch.ops.aten.convolution.default(add_tensor_30, primals_26, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(primals_194, 1);  primals_194 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(convolution_default_25, primals_197, primals_198, primals_195, primals_196, True, 0.1, 1e-05);  primals_198 = None
        getitem_75 = native_batch_norm_default_25[0]
        getitem_76 = native_batch_norm_default_25[1]
        getitem_77 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(convolution_default_25, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_17 = torch.ops.aten.relu_.default(getitem_75);  getitem_75 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_17, primals_25, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 192)
        add_tensor_32 = torch.ops.aten.add.Tensor(primals_199, 1);  primals_199 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(convolution_default_26, primals_202, primals_203, primals_200, primals_201, True, 0.1, 1e-05);  primals_203 = None
        getitem_78 = native_batch_norm_default_26[0]
        getitem_79 = native_batch_norm_default_26[1]
        getitem_80 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(convolution_default_26, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_18 = torch.ops.aten.relu_.default(getitem_78);  getitem_78 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_18, primals_27, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_33 = torch.ops.aten.add.Tensor(primals_204, 1);  primals_204 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(convolution_default_27, primals_207, primals_208, primals_205, primals_206, True, 0.1, 1e-05);  primals_208 = None
        getitem_81 = native_batch_norm_default_27[0]
        getitem_82 = native_batch_norm_default_27[1]
        getitem_83 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(convolution_default_27, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_28 = torch.ops.aten.convolution.default(getitem_81, primals_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_34 = torch.ops.aten.add.Tensor(primals_209, 1);  primals_209 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(convolution_default_28, primals_212, primals_213, primals_210, primals_211, True, 0.1, 1e-05);  primals_213 = None
        getitem_84 = native_batch_norm_default_28[0]
        getitem_85 = native_batch_norm_default_28[1]
        getitem_86 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(convolution_default_28, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_19 = torch.ops.aten.relu_.default(getitem_84);  getitem_84 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_19, primals_28, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 192)
        add_tensor_35 = torch.ops.aten.add.Tensor(primals_214, 1);  primals_214 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(convolution_default_29, primals_217, primals_218, primals_215, primals_216, True, 0.1, 1e-05);  primals_218 = None
        getitem_87 = native_batch_norm_default_29[0]
        getitem_88 = native_batch_norm_default_29[1]
        getitem_89 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(convolution_default_29, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_20 = torch.ops.aten.relu_.default(getitem_87);  getitem_87 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_20, primals_30, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_36 = torch.ops.aten.add.Tensor(primals_219, 1);  primals_219 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(convolution_default_30, primals_222, primals_223, primals_220, primals_221, True, 0.1, 1e-05);  primals_223 = None
        getitem_90 = native_batch_norm_default_30[0]
        getitem_91 = native_batch_norm_default_30[1]
        getitem_92 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(convolution_default_30, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_37 = torch.ops.aten.add.Tensor(getitem_90, getitem_81);  getitem_90 = None
        convolution_default_31 = torch.ops.aten.convolution.default(add_tensor_37, primals_32, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_38 = torch.ops.aten.add.Tensor(primals_224, 1);  primals_224 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(convolution_default_31, primals_227, primals_228, primals_225, primals_226, True, 0.1, 1e-05);  primals_228 = None
        getitem_93 = native_batch_norm_default_31[0]
        getitem_94 = native_batch_norm_default_31[1]
        getitem_95 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(convolution_default_31, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_21 = torch.ops.aten.relu_.default(getitem_93);  getitem_93 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_21, primals_31, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 384)
        add_tensor_39 = torch.ops.aten.add.Tensor(primals_229, 1);  primals_229 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(convolution_default_32, primals_232, primals_233, primals_230, primals_231, True, 0.1, 1e-05);  primals_233 = None
        getitem_96 = native_batch_norm_default_32[0]
        getitem_97 = native_batch_norm_default_32[1]
        getitem_98 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(convolution_default_32, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_22 = torch.ops.aten.relu_.default(getitem_96);  getitem_96 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_22, primals_33, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_40 = torch.ops.aten.add.Tensor(primals_234, 1);  primals_234 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(convolution_default_33, primals_237, primals_238, primals_235, primals_236, True, 0.1, 1e-05);  primals_238 = None
        getitem_99 = native_batch_norm_default_33[0]
        getitem_100 = native_batch_norm_default_33[1]
        getitem_101 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(convolution_default_33, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_41 = torch.ops.aten.add.Tensor(getitem_99, add_tensor_37);  getitem_99 = None
        convolution_default_34 = torch.ops.aten.convolution.default(add_tensor_41, primals_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_42 = torch.ops.aten.add.Tensor(primals_239, 1);  primals_239 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(convolution_default_34, primals_242, primals_243, primals_240, primals_241, True, 0.1, 1e-05);  primals_243 = None
        getitem_102 = native_batch_norm_default_34[0]
        getitem_103 = native_batch_norm_default_34[1]
        getitem_104 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(convolution_default_34, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_23 = torch.ops.aten.relu_.default(getitem_102);  getitem_102 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_23, primals_34, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 384)
        add_tensor_43 = torch.ops.aten.add.Tensor(primals_244, 1);  primals_244 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(convolution_default_35, primals_247, primals_248, primals_245, primals_246, True, 0.1, 1e-05);  primals_248 = None
        getitem_105 = native_batch_norm_default_35[0]
        getitem_106 = native_batch_norm_default_35[1]
        getitem_107 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(convolution_default_35, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_24 = torch.ops.aten.relu_.default(getitem_105);  getitem_105 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_24, primals_36, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_44 = torch.ops.aten.add.Tensor(primals_249, 1);  primals_249 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(convolution_default_36, primals_252, primals_253, primals_250, primals_251, True, 0.1, 1e-05);  primals_253 = None
        getitem_108 = native_batch_norm_default_36[0]
        getitem_109 = native_batch_norm_default_36[1]
        getitem_110 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(convolution_default_36, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_45 = torch.ops.aten.add.Tensor(getitem_108, add_tensor_41);  getitem_108 = None
        convolution_default_37 = torch.ops.aten.convolution.default(add_tensor_45, primals_38, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_46 = torch.ops.aten.add.Tensor(primals_254, 1);  primals_254 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(convolution_default_37, primals_257, primals_258, primals_255, primals_256, True, 0.1, 1e-05);  primals_258 = None
        getitem_111 = native_batch_norm_default_37[0]
        getitem_112 = native_batch_norm_default_37[1]
        getitem_113 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(convolution_default_37, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_25 = torch.ops.aten.relu_.default(getitem_111);  getitem_111 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_25, primals_37, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 384)
        add_tensor_47 = torch.ops.aten.add.Tensor(primals_259, 1);  primals_259 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(convolution_default_38, primals_262, primals_263, primals_260, primals_261, True, 0.1, 1e-05);  primals_263 = None
        getitem_114 = native_batch_norm_default_38[0]
        getitem_115 = native_batch_norm_default_38[1]
        getitem_116 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(convolution_default_38, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_26 = torch.ops.aten.relu_.default(getitem_114);  getitem_114 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_26, primals_39, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_48 = torch.ops.aten.add.Tensor(primals_264, 1);  primals_264 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(convolution_default_39, primals_267, primals_268, primals_265, primals_266, True, 0.1, 1e-05);  primals_268 = None
        getitem_117 = native_batch_norm_default_39[0]
        getitem_118 = native_batch_norm_default_39[1]
        getitem_119 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(convolution_default_39, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_40 = torch.ops.aten.convolution.default(getitem_117, primals_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_49 = torch.ops.aten.add.Tensor(primals_269, 1);  primals_269 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(convolution_default_40, primals_272, primals_273, primals_270, primals_271, True, 0.1, 1e-05);  primals_273 = None
        getitem_120 = native_batch_norm_default_40[0]
        getitem_121 = native_batch_norm_default_40[1]
        getitem_122 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(convolution_default_40, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_27 = torch.ops.aten.relu_.default(getitem_120);  getitem_120 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_27, primals_40, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        add_tensor_50 = torch.ops.aten.add.Tensor(primals_274, 1);  primals_274 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(convolution_default_41, primals_277, primals_278, primals_275, primals_276, True, 0.1, 1e-05);  primals_278 = None
        getitem_123 = native_batch_norm_default_41[0]
        getitem_124 = native_batch_norm_default_41[1]
        getitem_125 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(convolution_default_41, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_28 = torch.ops.aten.relu_.default(getitem_123);  getitem_123 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_28, primals_42, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_51 = torch.ops.aten.add.Tensor(primals_279, 1);  primals_279 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(convolution_default_42, primals_282, primals_283, primals_280, primals_281, True, 0.1, 1e-05);  primals_283 = None
        getitem_126 = native_batch_norm_default_42[0]
        getitem_127 = native_batch_norm_default_42[1]
        getitem_128 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(convolution_default_42, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_52 = torch.ops.aten.add.Tensor(getitem_126, getitem_117);  getitem_126 = None
        convolution_default_43 = torch.ops.aten.convolution.default(add_tensor_52, primals_44, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_53 = torch.ops.aten.add.Tensor(primals_284, 1);  primals_284 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(convolution_default_43, primals_287, primals_288, primals_285, primals_286, True, 0.1, 1e-05);  primals_288 = None
        getitem_129 = native_batch_norm_default_43[0]
        getitem_130 = native_batch_norm_default_43[1]
        getitem_131 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(convolution_default_43, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_29 = torch.ops.aten.relu_.default(getitem_129);  getitem_129 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_29, primals_43, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 672)
        add_tensor_54 = torch.ops.aten.add.Tensor(primals_289, 1);  primals_289 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(convolution_default_44, primals_292, primals_293, primals_290, primals_291, True, 0.1, 1e-05);  primals_293 = None
        getitem_132 = native_batch_norm_default_44[0]
        getitem_133 = native_batch_norm_default_44[1]
        getitem_134 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(convolution_default_44, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_30 = torch.ops.aten.relu_.default(getitem_132);  getitem_132 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_30, primals_45, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_55 = torch.ops.aten.add.Tensor(primals_294, 1);  primals_294 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(convolution_default_45, primals_297, primals_298, primals_295, primals_296, True, 0.1, 1e-05);  primals_298 = None
        getitem_135 = native_batch_norm_default_45[0]
        getitem_136 = native_batch_norm_default_45[1]
        getitem_137 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(convolution_default_45, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_56 = torch.ops.aten.add.Tensor(getitem_135, add_tensor_52);  getitem_135 = None
        convolution_default_46 = torch.ops.aten.convolution.default(add_tensor_56, primals_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_57 = torch.ops.aten.add.Tensor(primals_299, 1);  primals_299 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(convolution_default_46, primals_302, primals_303, primals_300, primals_301, True, 0.1, 1e-05);  primals_303 = None
        getitem_138 = native_batch_norm_default_46[0]
        getitem_139 = native_batch_norm_default_46[1]
        getitem_140 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(convolution_default_46, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_31 = torch.ops.aten.relu_.default(getitem_138);  getitem_138 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_31, primals_46, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 336)
        add_tensor_58 = torch.ops.aten.add.Tensor(primals_304, 1);  primals_304 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(convolution_default_47, primals_307, primals_308, primals_305, primals_306, True, 0.1, 1e-05);  primals_308 = None
        getitem_141 = native_batch_norm_default_47[0]
        getitem_142 = native_batch_norm_default_47[1]
        getitem_143 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(convolution_default_47, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_32 = torch.ops.aten.relu_.default(getitem_141);  getitem_141 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_32, primals_48, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_59 = torch.ops.aten.add.Tensor(primals_309, 1);  primals_309 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(convolution_default_48, primals_312, primals_313, primals_310, primals_311, True, 0.1, 1e-05);  primals_313 = None
        getitem_144 = native_batch_norm_default_48[0]
        getitem_145 = native_batch_norm_default_48[1]
        getitem_146 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(convolution_default_48, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_60 = torch.ops.aten.add.Tensor(getitem_144, add_tensor_56);  getitem_144 = None
        convolution_default_49 = torch.ops.aten.convolution.default(add_tensor_60, primals_50, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_61 = torch.ops.aten.add.Tensor(primals_314, 1);  primals_314 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(convolution_default_49, primals_317, primals_318, primals_315, primals_316, True, 0.1, 1e-05);  primals_318 = None
        getitem_147 = native_batch_norm_default_49[0]
        getitem_148 = native_batch_norm_default_49[1]
        getitem_149 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(convolution_default_49, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_33 = torch.ops.aten.relu_.default(getitem_147);  getitem_147 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_33, primals_49, None, [2, 2], [2, 2], [1, 1], False, [0, 0], 672)
        add_tensor_62 = torch.ops.aten.add.Tensor(primals_319, 1);  primals_319 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(convolution_default_50, primals_322, primals_323, primals_320, primals_321, True, 0.1, 1e-05);  primals_323 = None
        getitem_150 = native_batch_norm_default_50[0]
        getitem_151 = native_batch_norm_default_50[1]
        getitem_152 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(convolution_default_50, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_34 = torch.ops.aten.relu_.default(getitem_150);  getitem_150 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_34, primals_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_63 = torch.ops.aten.add.Tensor(primals_324, 1);  primals_324 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(convolution_default_51, primals_327, primals_328, primals_325, primals_326, True, 0.1, 1e-05);  primals_328 = None
        getitem_153 = native_batch_norm_default_51[0]
        getitem_154 = native_batch_norm_default_51[1]
        getitem_155 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(convolution_default_51, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_52 = torch.ops.aten.convolution.default(getitem_153, primals_53, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_64 = torch.ops.aten.add.Tensor(primals_329, 1);  primals_329 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(convolution_default_52, primals_332, primals_333, primals_330, primals_331, True, 0.1, 1e-05);  primals_333 = None
        getitem_156 = native_batch_norm_default_52[0]
        getitem_157 = native_batch_norm_default_52[1]
        getitem_158 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(convolution_default_52, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_35 = torch.ops.aten.relu_.default(getitem_156);  getitem_156 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_35, primals_52, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1104)
        add_tensor_65 = torch.ops.aten.add.Tensor(primals_334, 1);  primals_334 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(convolution_default_53, primals_337, primals_338, primals_335, primals_336, True, 0.1, 1e-05);  primals_338 = None
        getitem_159 = native_batch_norm_default_53[0]
        getitem_160 = native_batch_norm_default_53[1]
        getitem_161 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(convolution_default_53, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_36 = torch.ops.aten.relu_.default(getitem_159);  getitem_159 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_36, primals_54, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_66 = torch.ops.aten.add.Tensor(primals_339, 1);  primals_339 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(convolution_default_54, primals_342, primals_343, primals_340, primals_341, True, 0.1, 1e-05);  primals_343 = None
        getitem_162 = native_batch_norm_default_54[0]
        getitem_163 = native_batch_norm_default_54[1]
        getitem_164 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(convolution_default_54, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_67 = torch.ops.aten.add.Tensor(getitem_162, getitem_153);  getitem_162 = None
        convolution_default_55 = torch.ops.aten.convolution.default(add_tensor_67, primals_56, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_68 = torch.ops.aten.add.Tensor(primals_344, 1);  primals_344 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(convolution_default_55, primals_347, primals_348, primals_345, primals_346, True, 0.1, 1e-05);  primals_348 = None
        getitem_165 = native_batch_norm_default_55[0]
        getitem_166 = native_batch_norm_default_55[1]
        getitem_167 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(convolution_default_55, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_37 = torch.ops.aten.relu_.default(getitem_165);  getitem_165 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_37, primals_55, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1104)
        add_tensor_69 = torch.ops.aten.add.Tensor(primals_349, 1);  primals_349 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(convolution_default_56, primals_352, primals_353, primals_350, primals_351, True, 0.1, 1e-05);  primals_353 = None
        getitem_168 = native_batch_norm_default_56[0]
        getitem_169 = native_batch_norm_default_56[1]
        getitem_170 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(convolution_default_56, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_38 = torch.ops.aten.relu_.default(getitem_168);  getitem_168 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_38, primals_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_70 = torch.ops.aten.add.Tensor(primals_354, 1);  primals_354 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(convolution_default_57, primals_357, primals_358, primals_355, primals_356, True, 0.1, 1e-05);  primals_358 = None
        getitem_171 = native_batch_norm_default_57[0]
        getitem_172 = native_batch_norm_default_57[1]
        getitem_173 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(convolution_default_57, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_71 = torch.ops.aten.add.Tensor(getitem_171, add_tensor_67);  getitem_171 = None
        convolution_default_58 = torch.ops.aten.convolution.default(add_tensor_71, primals_59, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_72 = torch.ops.aten.add.Tensor(primals_359, 1);  primals_359 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(convolution_default_58, primals_362, primals_363, primals_360, primals_361, True, 0.1, 1e-05);  primals_363 = None
        getitem_174 = native_batch_norm_default_58[0]
        getitem_175 = native_batch_norm_default_58[1]
        getitem_176 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(convolution_default_58, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_39 = torch.ops.aten.relu_.default(getitem_174);  getitem_174 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_39, primals_58, None, [1, 1], [2, 2], [1, 1], False, [0, 0], 1104)
        add_tensor_73 = torch.ops.aten.add.Tensor(primals_364, 1);  primals_364 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(convolution_default_59, primals_367, primals_368, primals_365, primals_366, True, 0.1, 1e-05);  primals_368 = None
        getitem_177 = native_batch_norm_default_59[0]
        getitem_178 = native_batch_norm_default_59[1]
        getitem_179 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(convolution_default_59, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_40 = torch.ops.aten.relu_.default(getitem_177);  getitem_177 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_40, primals_60, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_74 = torch.ops.aten.add.Tensor(primals_369, 1);  primals_369 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(convolution_default_60, primals_372, primals_373, primals_370, primals_371, True, 0.1, 1e-05);  primals_373 = None
        getitem_180 = native_batch_norm_default_60[0]
        getitem_181 = native_batch_norm_default_60[1]
        getitem_182 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(convolution_default_60, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        add_tensor_75 = torch.ops.aten.add.Tensor(getitem_180, add_tensor_71);  getitem_180 = None
        convolution_default_61 = torch.ops.aten.convolution.default(add_tensor_75, primals_62, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_76 = torch.ops.aten.add.Tensor(primals_374, 1);  primals_374 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(convolution_default_61, primals_377, primals_378, primals_375, primals_376, True, 0.1, 1e-05);  primals_378 = None
        getitem_183 = native_batch_norm_default_61[0]
        getitem_184 = native_batch_norm_default_61[1]
        getitem_185 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(convolution_default_61, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_41 = torch.ops.aten.relu_.default(getitem_183);  getitem_183 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_41, primals_61, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1104)
        add_tensor_77 = torch.ops.aten.add.Tensor(primals_379, 1);  primals_379 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(convolution_default_62, primals_382, primals_383, primals_380, primals_381, True, 0.1, 1e-05);  primals_383 = None
        getitem_186 = native_batch_norm_default_62[0]
        getitem_187 = native_batch_norm_default_62[1]
        getitem_188 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(convolution_default_62, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_42 = torch.ops.aten.relu_.default(getitem_186);  getitem_186 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_42, primals_63, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_78 = torch.ops.aten.add.Tensor(primals_384, 1);  primals_384 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(convolution_default_63, primals_387, primals_388, primals_385, primals_386, True, 0.1, 1e-05);  primals_388 = None
        getitem_189 = native_batch_norm_default_63[0]
        getitem_190 = native_batch_norm_default_63[1]
        getitem_191 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(convolution_default_63, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        convolution_default_64 = torch.ops.aten.convolution.default(getitem_189, primals_66, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_79 = torch.ops.aten.add.Tensor(primals_389, 1);  primals_389 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(convolution_default_64, primals_392, primals_393, primals_390, primals_391, True, 0.1, 1e-05);  primals_393 = None
        getitem_192 = native_batch_norm_default_64[0]
        getitem_193 = native_batch_norm_default_64[1]
        getitem_194 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(convolution_default_64, [0], device = device(type='cuda', index=0), dtype = torch.uint8, layout = torch.strided, pin_memory = False)
        relu__default_43 = torch.ops.aten.relu_.default(getitem_192);  getitem_192 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_43, [-1, -2], True)
        view_default = torch.ops.aten.view.default(mean_dim, [128, 1984]);  mean_dim = None
        t_default = torch.ops.aten.t.default(primals_65);  primals_65 = None
        addmm_default = torch.ops.aten.addmm.default(primals_64, view_default, t_default);  primals_64 = None
        is_same_size_default = torch.ops.aten.is_same_size.default(addmm_default, tangents_1)
        t_default_1 = torch.ops.aten.t.default(t_default);  t_default = None
        mm_default = torch.ops.aten.mm.default(tangents_1, t_default_1);  t_default_1 = None
        t_default_2 = torch.ops.aten.t.default(tangents_1)
        mm_default_1 = torch.ops.aten.mm.default(t_default_2, view_default);  t_default_2 = view_default = None
        t_default_3 = torch.ops.aten.t.default(mm_default_1);  mm_default_1 = None
        sum_dim_int_list = torch.ops.aten.sum.dim_IntList(tangents_1, [0], True);  tangents_1 = None
        view_default_1 = torch.ops.aten.view.default(sum_dim_int_list, [1000]);  sum_dim_int_list = None
        t_default_4 = torch.ops.aten.t.default(t_default_3);  t_default_3 = None
        view_default_2 = torch.ops.aten.view.default(mm_default, [128, 1984, 1, 1]);  mm_default = None
        expand_default = torch.ops.aten.expand.default(view_default_2, [128, 1984, 7, 7]);  view_default_2 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 49);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default_65, to_dtype);  le_scalar = new_zeros_default_65 = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(to_dtype_2, convolution_default_64, primals_392, primals_390, primals_391, getitem_193, getitem_194, True, 1e-05, [True, True, True]);  to_dtype_2 = convolution_default_64 = primals_392 = primals_390 = primals_391 = getitem_193 = getitem_194 = None
        getitem_195 = native_batch_norm_backward_default[0]
        getitem_196 = native_batch_norm_backward_default[1]
        getitem_197 = native_batch_norm_backward_default[2];  native_batch_norm_backward_default = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(getitem_195, getitem_189, primals_66, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_195 = getitem_189 = primals_66 = None
        getitem_198 = convolution_backward_default[0]
        getitem_199 = convolution_backward_default[1]
        getitem_200 = convolution_backward_default[2];  convolution_backward_default = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(getitem_198, convolution_default_63, primals_387, primals_385, primals_386, getitem_190, getitem_191, True, 1e-05, [True, True, True]);  getitem_198 = convolution_default_63 = primals_387 = primals_385 = primals_386 = getitem_190 = getitem_191 = None
        getitem_201 = native_batch_norm_backward_default_1[0]
        getitem_202 = native_batch_norm_backward_default_1[1]
        getitem_203 = native_batch_norm_backward_default_1[2];  native_batch_norm_backward_default_1 = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_201, relu__default_42, primals_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_201 = primals_63 = None
        getitem_204 = convolution_backward_default_1[0]
        getitem_205 = convolution_backward_default_1[1]
        getitem_206 = convolution_backward_default_1[2];  convolution_backward_default_1 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_204, torch.float32);  getitem_204 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_66, to_dtype_3);  le_scalar_1 = new_zeros_default_66 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_5, convolution_default_62, primals_382, primals_380, primals_381, getitem_187, getitem_188, True, 1e-05, [True, True, True]);  to_dtype_5 = convolution_default_62 = primals_382 = primals_380 = primals_381 = getitem_187 = getitem_188 = None
        getitem_207 = native_batch_norm_backward_default_2[0]
        getitem_208 = native_batch_norm_backward_default_2[1]
        getitem_209 = native_batch_norm_backward_default_2[2];  native_batch_norm_backward_default_2 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_207, relu__default_41, primals_61, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1104, [True, True, False]);  getitem_207 = primals_61 = None
        getitem_210 = convolution_backward_default_2[0]
        getitem_211 = convolution_backward_default_2[1]
        getitem_212 = convolution_backward_default_2[2];  convolution_backward_default_2 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_210, torch.float32);  getitem_210 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_67, to_dtype_6);  le_scalar_2 = new_zeros_default_67 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_8, convolution_default_61, primals_377, primals_375, primals_376, getitem_184, getitem_185, True, 1e-05, [True, True, True]);  to_dtype_8 = convolution_default_61 = primals_377 = primals_375 = primals_376 = getitem_184 = getitem_185 = None
        getitem_213 = native_batch_norm_backward_default_3[0]
        getitem_214 = native_batch_norm_backward_default_3[1]
        getitem_215 = native_batch_norm_backward_default_3[2];  native_batch_norm_backward_default_3 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_213, add_tensor_75, primals_62, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_213 = add_tensor_75 = primals_62 = None
        getitem_216 = convolution_backward_default_3[0]
        getitem_217 = convolution_backward_default_3[1]
        getitem_218 = convolution_backward_default_3[2];  convolution_backward_default_3 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(getitem_216, convolution_default_60, primals_372, primals_370, primals_371, getitem_181, getitem_182, True, 1e-05, [True, True, True]);  convolution_default_60 = primals_372 = primals_370 = primals_371 = getitem_181 = getitem_182 = None
        getitem_219 = native_batch_norm_backward_default_4[0]
        getitem_220 = native_batch_norm_backward_default_4[1]
        getitem_221 = native_batch_norm_backward_default_4[2];  native_batch_norm_backward_default_4 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(getitem_219, relu__default_40, primals_60, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_219 = primals_60 = None
        getitem_222 = convolution_backward_default_4[0]
        getitem_223 = convolution_backward_default_4[1]
        getitem_224 = convolution_backward_default_4[2];  convolution_backward_default_4 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_222, torch.float32);  getitem_222 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_68, to_dtype_9);  le_scalar_3 = new_zeros_default_68 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_11, convolution_default_59, primals_367, primals_365, primals_366, getitem_178, getitem_179, True, 1e-05, [True, True, True]);  to_dtype_11 = convolution_default_59 = primals_367 = primals_365 = primals_366 = getitem_178 = getitem_179 = None
        getitem_225 = native_batch_norm_backward_default_5[0]
        getitem_226 = native_batch_norm_backward_default_5[1]
        getitem_227 = native_batch_norm_backward_default_5[2];  native_batch_norm_backward_default_5 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_225, relu__default_39, primals_58, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1104, [True, True, False]);  getitem_225 = primals_58 = None
        getitem_228 = convolution_backward_default_5[0]
        getitem_229 = convolution_backward_default_5[1]
        getitem_230 = convolution_backward_default_5[2];  convolution_backward_default_5 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_228, torch.float32);  getitem_228 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_69, to_dtype_12);  le_scalar_4 = new_zeros_default_69 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_14, convolution_default_58, primals_362, primals_360, primals_361, getitem_175, getitem_176, True, 1e-05, [True, True, True]);  to_dtype_14 = convolution_default_58 = primals_362 = primals_360 = primals_361 = getitem_175 = getitem_176 = None
        getitem_231 = native_batch_norm_backward_default_6[0]
        getitem_232 = native_batch_norm_backward_default_6[1]
        getitem_233 = native_batch_norm_backward_default_6[2];  native_batch_norm_backward_default_6 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_231, add_tensor_71, primals_59, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_231 = add_tensor_71 = primals_59 = None
        getitem_234 = convolution_backward_default_6[0]
        getitem_235 = convolution_backward_default_6[1]
        getitem_236 = convolution_backward_default_6[2];  convolution_backward_default_6 = None
        add_tensor_80 = torch.ops.aten.add.Tensor(getitem_216, getitem_234);  getitem_216 = getitem_234 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_80, convolution_default_57, primals_357, primals_355, primals_356, getitem_172, getitem_173, True, 1e-05, [True, True, True]);  convolution_default_57 = primals_357 = primals_355 = primals_356 = getitem_172 = getitem_173 = None
        getitem_237 = native_batch_norm_backward_default_7[0]
        getitem_238 = native_batch_norm_backward_default_7[1]
        getitem_239 = native_batch_norm_backward_default_7[2];  native_batch_norm_backward_default_7 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(getitem_237, relu__default_38, primals_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_237 = primals_57 = None
        getitem_240 = convolution_backward_default_7[0]
        getitem_241 = convolution_backward_default_7[1]
        getitem_242 = convolution_backward_default_7[2];  convolution_backward_default_7 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_240, torch.float32);  getitem_240 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_70, to_dtype_15);  le_scalar_5 = new_zeros_default_70 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_17, convolution_default_56, primals_352, primals_350, primals_351, getitem_169, getitem_170, True, 1e-05, [True, True, True]);  to_dtype_17 = convolution_default_56 = primals_352 = primals_350 = primals_351 = getitem_169 = getitem_170 = None
        getitem_243 = native_batch_norm_backward_default_8[0]
        getitem_244 = native_batch_norm_backward_default_8[1]
        getitem_245 = native_batch_norm_backward_default_8[2];  native_batch_norm_backward_default_8 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_243, relu__default_37, primals_55, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1104, [True, True, False]);  getitem_243 = primals_55 = None
        getitem_246 = convolution_backward_default_8[0]
        getitem_247 = convolution_backward_default_8[1]
        getitem_248 = convolution_backward_default_8[2];  convolution_backward_default_8 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_246, torch.float32);  getitem_246 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_71, to_dtype_18);  le_scalar_6 = new_zeros_default_71 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_20, convolution_default_55, primals_347, primals_345, primals_346, getitem_166, getitem_167, True, 1e-05, [True, True, True]);  to_dtype_20 = convolution_default_55 = primals_347 = primals_345 = primals_346 = getitem_166 = getitem_167 = None
        getitem_249 = native_batch_norm_backward_default_9[0]
        getitem_250 = native_batch_norm_backward_default_9[1]
        getitem_251 = native_batch_norm_backward_default_9[2];  native_batch_norm_backward_default_9 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_249, add_tensor_67, primals_56, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_249 = add_tensor_67 = primals_56 = None
        getitem_252 = convolution_backward_default_9[0]
        getitem_253 = convolution_backward_default_9[1]
        getitem_254 = convolution_backward_default_9[2];  convolution_backward_default_9 = None
        add_tensor_81 = torch.ops.aten.add.Tensor(add_tensor_80, getitem_252);  add_tensor_80 = getitem_252 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_81, convolution_default_54, primals_342, primals_340, primals_341, getitem_163, getitem_164, True, 1e-05, [True, True, True]);  convolution_default_54 = primals_342 = primals_340 = primals_341 = getitem_163 = getitem_164 = None
        getitem_255 = native_batch_norm_backward_default_10[0]
        getitem_256 = native_batch_norm_backward_default_10[1]
        getitem_257 = native_batch_norm_backward_default_10[2];  native_batch_norm_backward_default_10 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(getitem_255, relu__default_36, primals_54, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_255 = primals_54 = None
        getitem_258 = convolution_backward_default_10[0]
        getitem_259 = convolution_backward_default_10[1]
        getitem_260 = convolution_backward_default_10[2];  convolution_backward_default_10 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_258, torch.float32);  getitem_258 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_72, to_dtype_21);  le_scalar_7 = new_zeros_default_72 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_23, convolution_default_53, primals_337, primals_335, primals_336, getitem_160, getitem_161, True, 1e-05, [True, True, True]);  to_dtype_23 = convolution_default_53 = primals_337 = primals_335 = primals_336 = getitem_160 = getitem_161 = None
        getitem_261 = native_batch_norm_backward_default_11[0]
        getitem_262 = native_batch_norm_backward_default_11[1]
        getitem_263 = native_batch_norm_backward_default_11[2];  native_batch_norm_backward_default_11 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_261, relu__default_35, primals_52, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 1104, [True, True, False]);  getitem_261 = primals_52 = None
        getitem_264 = convolution_backward_default_11[0]
        getitem_265 = convolution_backward_default_11[1]
        getitem_266 = convolution_backward_default_11[2];  convolution_backward_default_11 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_264, torch.float32);  getitem_264 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_73, to_dtype_24);  le_scalar_8 = new_zeros_default_73 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_26, convolution_default_52, primals_332, primals_330, primals_331, getitem_157, getitem_158, True, 1e-05, [True, True, True]);  to_dtype_26 = convolution_default_52 = primals_332 = primals_330 = primals_331 = getitem_157 = getitem_158 = None
        getitem_267 = native_batch_norm_backward_default_12[0]
        getitem_268 = native_batch_norm_backward_default_12[1]
        getitem_269 = native_batch_norm_backward_default_12[2];  native_batch_norm_backward_default_12 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_267, getitem_153, primals_53, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_267 = getitem_153 = primals_53 = None
        getitem_270 = convolution_backward_default_12[0]
        getitem_271 = convolution_backward_default_12[1]
        getitem_272 = convolution_backward_default_12[2];  convolution_backward_default_12 = None
        add_tensor_82 = torch.ops.aten.add.Tensor(add_tensor_81, getitem_270);  add_tensor_81 = getitem_270 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_82, convolution_default_51, primals_327, primals_325, primals_326, getitem_154, getitem_155, True, 1e-05, [True, True, True]);  add_tensor_82 = convolution_default_51 = primals_327 = primals_325 = primals_326 = getitem_154 = getitem_155 = None
        getitem_273 = native_batch_norm_backward_default_13[0]
        getitem_274 = native_batch_norm_backward_default_13[1]
        getitem_275 = native_batch_norm_backward_default_13[2];  native_batch_norm_backward_default_13 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_273, relu__default_34, primals_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_273 = primals_51 = None
        getitem_276 = convolution_backward_default_13[0]
        getitem_277 = convolution_backward_default_13[1]
        getitem_278 = convolution_backward_default_13[2];  convolution_backward_default_13 = None
        to_dtype_27 = torch.ops.aten.to.dtype(getitem_276, torch.float32);  getitem_276 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_74, to_dtype_27);  le_scalar_9 = new_zeros_default_74 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_29, convolution_default_50, primals_322, primals_320, primals_321, getitem_151, getitem_152, True, 1e-05, [True, True, True]);  to_dtype_29 = convolution_default_50 = primals_322 = primals_320 = primals_321 = getitem_151 = getitem_152 = None
        getitem_279 = native_batch_norm_backward_default_14[0]
        getitem_280 = native_batch_norm_backward_default_14[1]
        getitem_281 = native_batch_norm_backward_default_14[2];  native_batch_norm_backward_default_14 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(getitem_279, relu__default_33, primals_49, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_279 = primals_49 = None
        getitem_282 = convolution_backward_default_14[0]
        getitem_283 = convolution_backward_default_14[1]
        getitem_284 = convolution_backward_default_14[2];  convolution_backward_default_14 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_282, torch.float32);  getitem_282 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_75, to_dtype_30);  le_scalar_10 = new_zeros_default_75 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_32, convolution_default_49, primals_317, primals_315, primals_316, getitem_148, getitem_149, True, 1e-05, [True, True, True]);  to_dtype_32 = convolution_default_49 = primals_317 = primals_315 = primals_316 = getitem_148 = getitem_149 = None
        getitem_285 = native_batch_norm_backward_default_15[0]
        getitem_286 = native_batch_norm_backward_default_15[1]
        getitem_287 = native_batch_norm_backward_default_15[2];  native_batch_norm_backward_default_15 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_285, add_tensor_60, primals_50, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_285 = add_tensor_60 = primals_50 = None
        getitem_288 = convolution_backward_default_15[0]
        getitem_289 = convolution_backward_default_15[1]
        getitem_290 = convolution_backward_default_15[2];  convolution_backward_default_15 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(getitem_288, convolution_default_48, primals_312, primals_310, primals_311, getitem_145, getitem_146, True, 1e-05, [True, True, True]);  convolution_default_48 = primals_312 = primals_310 = primals_311 = getitem_145 = getitem_146 = None
        getitem_291 = native_batch_norm_backward_default_16[0]
        getitem_292 = native_batch_norm_backward_default_16[1]
        getitem_293 = native_batch_norm_backward_default_16[2];  native_batch_norm_backward_default_16 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_291, relu__default_32, primals_48, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_291 = primals_48 = None
        getitem_294 = convolution_backward_default_16[0]
        getitem_295 = convolution_backward_default_16[1]
        getitem_296 = convolution_backward_default_16[2];  convolution_backward_default_16 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_294, torch.float32);  getitem_294 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_76, to_dtype_33);  le_scalar_11 = new_zeros_default_76 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_35, convolution_default_47, primals_307, primals_305, primals_306, getitem_142, getitem_143, True, 1e-05, [True, True, True]);  to_dtype_35 = convolution_default_47 = primals_307 = primals_305 = primals_306 = getitem_142 = getitem_143 = None
        getitem_297 = native_batch_norm_backward_default_17[0]
        getitem_298 = native_batch_norm_backward_default_17[1]
        getitem_299 = native_batch_norm_backward_default_17[2];  native_batch_norm_backward_default_17 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(getitem_297, relu__default_31, primals_46, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 336, [True, True, False]);  getitem_297 = primals_46 = None
        getitem_300 = convolution_backward_default_17[0]
        getitem_301 = convolution_backward_default_17[1]
        getitem_302 = convolution_backward_default_17[2];  convolution_backward_default_17 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_300, torch.float32);  getitem_300 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_77, to_dtype_36);  le_scalar_12 = new_zeros_default_77 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_38, convolution_default_46, primals_302, primals_300, primals_301, getitem_139, getitem_140, True, 1e-05, [True, True, True]);  to_dtype_38 = convolution_default_46 = primals_302 = primals_300 = primals_301 = getitem_139 = getitem_140 = None
        getitem_303 = native_batch_norm_backward_default_18[0]
        getitem_304 = native_batch_norm_backward_default_18[1]
        getitem_305 = native_batch_norm_backward_default_18[2];  native_batch_norm_backward_default_18 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_303, add_tensor_56, primals_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_303 = add_tensor_56 = primals_47 = None
        getitem_306 = convolution_backward_default_18[0]
        getitem_307 = convolution_backward_default_18[1]
        getitem_308 = convolution_backward_default_18[2];  convolution_backward_default_18 = None
        add_tensor_83 = torch.ops.aten.add.Tensor(getitem_288, getitem_306);  getitem_288 = getitem_306 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_83, convolution_default_45, primals_297, primals_295, primals_296, getitem_136, getitem_137, True, 1e-05, [True, True, True]);  convolution_default_45 = primals_297 = primals_295 = primals_296 = getitem_136 = getitem_137 = None
        getitem_309 = native_batch_norm_backward_default_19[0]
        getitem_310 = native_batch_norm_backward_default_19[1]
        getitem_311 = native_batch_norm_backward_default_19[2];  native_batch_norm_backward_default_19 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_309, relu__default_30, primals_45, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_309 = primals_45 = None
        getitem_312 = convolution_backward_default_19[0]
        getitem_313 = convolution_backward_default_19[1]
        getitem_314 = convolution_backward_default_19[2];  convolution_backward_default_19 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_312, torch.float32);  getitem_312 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_78, to_dtype_39);  le_scalar_13 = new_zeros_default_78 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_41, convolution_default_44, primals_292, primals_290, primals_291, getitem_133, getitem_134, True, 1e-05, [True, True, True]);  to_dtype_41 = convolution_default_44 = primals_292 = primals_290 = primals_291 = getitem_133 = getitem_134 = None
        getitem_315 = native_batch_norm_backward_default_20[0]
        getitem_316 = native_batch_norm_backward_default_20[1]
        getitem_317 = native_batch_norm_backward_default_20[2];  native_batch_norm_backward_default_20 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(getitem_315, relu__default_29, primals_43, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_315 = primals_43 = None
        getitem_318 = convolution_backward_default_20[0]
        getitem_319 = convolution_backward_default_20[1]
        getitem_320 = convolution_backward_default_20[2];  convolution_backward_default_20 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_318, torch.float32);  getitem_318 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_79, to_dtype_42);  le_scalar_14 = new_zeros_default_79 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_44, convolution_default_43, primals_287, primals_285, primals_286, getitem_130, getitem_131, True, 1e-05, [True, True, True]);  to_dtype_44 = convolution_default_43 = primals_287 = primals_285 = primals_286 = getitem_130 = getitem_131 = None
        getitem_321 = native_batch_norm_backward_default_21[0]
        getitem_322 = native_batch_norm_backward_default_21[1]
        getitem_323 = native_batch_norm_backward_default_21[2];  native_batch_norm_backward_default_21 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_321, add_tensor_52, primals_44, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_321 = add_tensor_52 = primals_44 = None
        getitem_324 = convolution_backward_default_21[0]
        getitem_325 = convolution_backward_default_21[1]
        getitem_326 = convolution_backward_default_21[2];  convolution_backward_default_21 = None
        add_tensor_84 = torch.ops.aten.add.Tensor(add_tensor_83, getitem_324);  add_tensor_83 = getitem_324 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_84, convolution_default_42, primals_282, primals_280, primals_281, getitem_127, getitem_128, True, 1e-05, [True, True, True]);  convolution_default_42 = primals_282 = primals_280 = primals_281 = getitem_127 = getitem_128 = None
        getitem_327 = native_batch_norm_backward_default_22[0]
        getitem_328 = native_batch_norm_backward_default_22[1]
        getitem_329 = native_batch_norm_backward_default_22[2];  native_batch_norm_backward_default_22 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_327, relu__default_28, primals_42, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_327 = primals_42 = None
        getitem_330 = convolution_backward_default_22[0]
        getitem_331 = convolution_backward_default_22[1]
        getitem_332 = convolution_backward_default_22[2];  convolution_backward_default_22 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_330, torch.float32);  getitem_330 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_80, to_dtype_45);  le_scalar_15 = new_zeros_default_80 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_47, convolution_default_41, primals_277, primals_275, primals_276, getitem_124, getitem_125, True, 1e-05, [True, True, True]);  to_dtype_47 = convolution_default_41 = primals_277 = primals_275 = primals_276 = getitem_124 = getitem_125 = None
        getitem_333 = native_batch_norm_backward_default_23[0]
        getitem_334 = native_batch_norm_backward_default_23[1]
        getitem_335 = native_batch_norm_backward_default_23[2];  native_batch_norm_backward_default_23 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(getitem_333, relu__default_27, primals_40, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 672, [True, True, False]);  getitem_333 = primals_40 = None
        getitem_336 = convolution_backward_default_23[0]
        getitem_337 = convolution_backward_default_23[1]
        getitem_338 = convolution_backward_default_23[2];  convolution_backward_default_23 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_336, torch.float32);  getitem_336 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_81, to_dtype_48);  le_scalar_16 = new_zeros_default_81 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_50, convolution_default_40, primals_272, primals_270, primals_271, getitem_121, getitem_122, True, 1e-05, [True, True, True]);  to_dtype_50 = convolution_default_40 = primals_272 = primals_270 = primals_271 = getitem_121 = getitem_122 = None
        getitem_339 = native_batch_norm_backward_default_24[0]
        getitem_340 = native_batch_norm_backward_default_24[1]
        getitem_341 = native_batch_norm_backward_default_24[2];  native_batch_norm_backward_default_24 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_339, getitem_117, primals_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_339 = getitem_117 = primals_41 = None
        getitem_342 = convolution_backward_default_24[0]
        getitem_343 = convolution_backward_default_24[1]
        getitem_344 = convolution_backward_default_24[2];  convolution_backward_default_24 = None
        add_tensor_85 = torch.ops.aten.add.Tensor(add_tensor_84, getitem_342);  add_tensor_84 = getitem_342 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_85, convolution_default_39, primals_267, primals_265, primals_266, getitem_118, getitem_119, True, 1e-05, [True, True, True]);  add_tensor_85 = convolution_default_39 = primals_267 = primals_265 = primals_266 = getitem_118 = getitem_119 = None
        getitem_345 = native_batch_norm_backward_default_25[0]
        getitem_346 = native_batch_norm_backward_default_25[1]
        getitem_347 = native_batch_norm_backward_default_25[2];  native_batch_norm_backward_default_25 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_345, relu__default_26, primals_39, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_345 = primals_39 = None
        getitem_348 = convolution_backward_default_25[0]
        getitem_349 = convolution_backward_default_25[1]
        getitem_350 = convolution_backward_default_25[2];  convolution_backward_default_25 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_348, torch.float32);  getitem_348 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_82, to_dtype_51);  le_scalar_17 = new_zeros_default_82 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_53, convolution_default_38, primals_262, primals_260, primals_261, getitem_115, getitem_116, True, 1e-05, [True, True, True]);  to_dtype_53 = convolution_default_38 = primals_262 = primals_260 = primals_261 = getitem_115 = getitem_116 = None
        getitem_351 = native_batch_norm_backward_default_26[0]
        getitem_352 = native_batch_norm_backward_default_26[1]
        getitem_353 = native_batch_norm_backward_default_26[2];  native_batch_norm_backward_default_26 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(getitem_351, relu__default_25, primals_37, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 384, [True, True, False]);  getitem_351 = primals_37 = None
        getitem_354 = convolution_backward_default_26[0]
        getitem_355 = convolution_backward_default_26[1]
        getitem_356 = convolution_backward_default_26[2];  convolution_backward_default_26 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_354, torch.float32);  getitem_354 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_83, to_dtype_54);  le_scalar_18 = new_zeros_default_83 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_56, convolution_default_37, primals_257, primals_255, primals_256, getitem_112, getitem_113, True, 1e-05, [True, True, True]);  to_dtype_56 = convolution_default_37 = primals_257 = primals_255 = primals_256 = getitem_112 = getitem_113 = None
        getitem_357 = native_batch_norm_backward_default_27[0]
        getitem_358 = native_batch_norm_backward_default_27[1]
        getitem_359 = native_batch_norm_backward_default_27[2];  native_batch_norm_backward_default_27 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_357, add_tensor_45, primals_38, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_357 = add_tensor_45 = primals_38 = None
        getitem_360 = convolution_backward_default_27[0]
        getitem_361 = convolution_backward_default_27[1]
        getitem_362 = convolution_backward_default_27[2];  convolution_backward_default_27 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(getitem_360, convolution_default_36, primals_252, primals_250, primals_251, getitem_109, getitem_110, True, 1e-05, [True, True, True]);  convolution_default_36 = primals_252 = primals_250 = primals_251 = getitem_109 = getitem_110 = None
        getitem_363 = native_batch_norm_backward_default_28[0]
        getitem_364 = native_batch_norm_backward_default_28[1]
        getitem_365 = native_batch_norm_backward_default_28[2];  native_batch_norm_backward_default_28 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_363, relu__default_24, primals_36, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_363 = primals_36 = None
        getitem_366 = convolution_backward_default_28[0]
        getitem_367 = convolution_backward_default_28[1]
        getitem_368 = convolution_backward_default_28[2];  convolution_backward_default_28 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_366, torch.float32);  getitem_366 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_84, to_dtype_57);  le_scalar_19 = new_zeros_default_84 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_59, convolution_default_35, primals_247, primals_245, primals_246, getitem_106, getitem_107, True, 1e-05, [True, True, True]);  to_dtype_59 = convolution_default_35 = primals_247 = primals_245 = primals_246 = getitem_106 = getitem_107 = None
        getitem_369 = native_batch_norm_backward_default_29[0]
        getitem_370 = native_batch_norm_backward_default_29[1]
        getitem_371 = native_batch_norm_backward_default_29[2];  native_batch_norm_backward_default_29 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(getitem_369, relu__default_23, primals_34, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 384, [True, True, False]);  getitem_369 = primals_34 = None
        getitem_372 = convolution_backward_default_29[0]
        getitem_373 = convolution_backward_default_29[1]
        getitem_374 = convolution_backward_default_29[2];  convolution_backward_default_29 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_372, torch.float32);  getitem_372 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_85, to_dtype_60);  le_scalar_20 = new_zeros_default_85 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_62, convolution_default_34, primals_242, primals_240, primals_241, getitem_103, getitem_104, True, 1e-05, [True, True, True]);  to_dtype_62 = convolution_default_34 = primals_242 = primals_240 = primals_241 = getitem_103 = getitem_104 = None
        getitem_375 = native_batch_norm_backward_default_30[0]
        getitem_376 = native_batch_norm_backward_default_30[1]
        getitem_377 = native_batch_norm_backward_default_30[2];  native_batch_norm_backward_default_30 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_375, add_tensor_41, primals_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_375 = add_tensor_41 = primals_35 = None
        getitem_378 = convolution_backward_default_30[0]
        getitem_379 = convolution_backward_default_30[1]
        getitem_380 = convolution_backward_default_30[2];  convolution_backward_default_30 = None
        add_tensor_86 = torch.ops.aten.add.Tensor(getitem_360, getitem_378);  getitem_360 = getitem_378 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_86, convolution_default_33, primals_237, primals_235, primals_236, getitem_100, getitem_101, True, 1e-05, [True, True, True]);  convolution_default_33 = primals_237 = primals_235 = primals_236 = getitem_100 = getitem_101 = None
        getitem_381 = native_batch_norm_backward_default_31[0]
        getitem_382 = native_batch_norm_backward_default_31[1]
        getitem_383 = native_batch_norm_backward_default_31[2];  native_batch_norm_backward_default_31 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_381, relu__default_22, primals_33, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_381 = primals_33 = None
        getitem_384 = convolution_backward_default_31[0]
        getitem_385 = convolution_backward_default_31[1]
        getitem_386 = convolution_backward_default_31[2];  convolution_backward_default_31 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_384, torch.float32);  getitem_384 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_86, to_dtype_63);  le_scalar_21 = new_zeros_default_86 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_65, convolution_default_32, primals_232, primals_230, primals_231, getitem_97, getitem_98, True, 1e-05, [True, True, True]);  to_dtype_65 = convolution_default_32 = primals_232 = primals_230 = primals_231 = getitem_97 = getitem_98 = None
        getitem_387 = native_batch_norm_backward_default_32[0]
        getitem_388 = native_batch_norm_backward_default_32[1]
        getitem_389 = native_batch_norm_backward_default_32[2];  native_batch_norm_backward_default_32 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(getitem_387, relu__default_21, primals_31, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 384, [True, True, False]);  getitem_387 = primals_31 = None
        getitem_390 = convolution_backward_default_32[0]
        getitem_391 = convolution_backward_default_32[1]
        getitem_392 = convolution_backward_default_32[2];  convolution_backward_default_32 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_390, torch.float32);  getitem_390 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_87, to_dtype_66);  le_scalar_22 = new_zeros_default_87 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_68, convolution_default_31, primals_227, primals_225, primals_226, getitem_94, getitem_95, True, 1e-05, [True, True, True]);  to_dtype_68 = convolution_default_31 = primals_227 = primals_225 = primals_226 = getitem_94 = getitem_95 = None
        getitem_393 = native_batch_norm_backward_default_33[0]
        getitem_394 = native_batch_norm_backward_default_33[1]
        getitem_395 = native_batch_norm_backward_default_33[2];  native_batch_norm_backward_default_33 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_393, add_tensor_37, primals_32, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_393 = add_tensor_37 = primals_32 = None
        getitem_396 = convolution_backward_default_33[0]
        getitem_397 = convolution_backward_default_33[1]
        getitem_398 = convolution_backward_default_33[2];  convolution_backward_default_33 = None
        add_tensor_87 = torch.ops.aten.add.Tensor(add_tensor_86, getitem_396);  add_tensor_86 = getitem_396 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_87, convolution_default_30, primals_222, primals_220, primals_221, getitem_91, getitem_92, True, 1e-05, [True, True, True]);  convolution_default_30 = primals_222 = primals_220 = primals_221 = getitem_91 = getitem_92 = None
        getitem_399 = native_batch_norm_backward_default_34[0]
        getitem_400 = native_batch_norm_backward_default_34[1]
        getitem_401 = native_batch_norm_backward_default_34[2];  native_batch_norm_backward_default_34 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_399, relu__default_20, primals_30, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_399 = primals_30 = None
        getitem_402 = convolution_backward_default_34[0]
        getitem_403 = convolution_backward_default_34[1]
        getitem_404 = convolution_backward_default_34[2];  convolution_backward_default_34 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_402, torch.float32);  getitem_402 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_88, to_dtype_69);  le_scalar_23 = new_zeros_default_88 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_71, convolution_default_29, primals_217, primals_215, primals_216, getitem_88, getitem_89, True, 1e-05, [True, True, True]);  to_dtype_71 = convolution_default_29 = primals_217 = primals_215 = primals_216 = getitem_88 = getitem_89 = None
        getitem_405 = native_batch_norm_backward_default_35[0]
        getitem_406 = native_batch_norm_backward_default_35[1]
        getitem_407 = native_batch_norm_backward_default_35[2];  native_batch_norm_backward_default_35 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(getitem_405, relu__default_19, primals_28, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_405 = primals_28 = None
        getitem_408 = convolution_backward_default_35[0]
        getitem_409 = convolution_backward_default_35[1]
        getitem_410 = convolution_backward_default_35[2];  convolution_backward_default_35 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_408, torch.float32);  getitem_408 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_89, to_dtype_72);  le_scalar_24 = new_zeros_default_89 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_74, convolution_default_28, primals_212, primals_210, primals_211, getitem_85, getitem_86, True, 1e-05, [True, True, True]);  to_dtype_74 = convolution_default_28 = primals_212 = primals_210 = primals_211 = getitem_85 = getitem_86 = None
        getitem_411 = native_batch_norm_backward_default_36[0]
        getitem_412 = native_batch_norm_backward_default_36[1]
        getitem_413 = native_batch_norm_backward_default_36[2];  native_batch_norm_backward_default_36 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_411, getitem_81, primals_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_411 = getitem_81 = primals_29 = None
        getitem_414 = convolution_backward_default_36[0]
        getitem_415 = convolution_backward_default_36[1]
        getitem_416 = convolution_backward_default_36[2];  convolution_backward_default_36 = None
        add_tensor_88 = torch.ops.aten.add.Tensor(add_tensor_87, getitem_414);  add_tensor_87 = getitem_414 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_88, convolution_default_27, primals_207, primals_205, primals_206, getitem_82, getitem_83, True, 1e-05, [True, True, True]);  add_tensor_88 = convolution_default_27 = primals_207 = primals_205 = primals_206 = getitem_82 = getitem_83 = None
        getitem_417 = native_batch_norm_backward_default_37[0]
        getitem_418 = native_batch_norm_backward_default_37[1]
        getitem_419 = native_batch_norm_backward_default_37[2];  native_batch_norm_backward_default_37 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_417, relu__default_18, primals_27, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_417 = primals_27 = None
        getitem_420 = convolution_backward_default_37[0]
        getitem_421 = convolution_backward_default_37[1]
        getitem_422 = convolution_backward_default_37[2];  convolution_backward_default_37 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_420, torch.float32);  getitem_420 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_90, to_dtype_75);  le_scalar_25 = new_zeros_default_90 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_77, convolution_default_26, primals_202, primals_200, primals_201, getitem_79, getitem_80, True, 1e-05, [True, True, True]);  to_dtype_77 = convolution_default_26 = primals_202 = primals_200 = primals_201 = getitem_79 = getitem_80 = None
        getitem_423 = native_batch_norm_backward_default_38[0]
        getitem_424 = native_batch_norm_backward_default_38[1]
        getitem_425 = native_batch_norm_backward_default_38[2];  native_batch_norm_backward_default_38 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(getitem_423, relu__default_17, primals_25, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_423 = primals_25 = None
        getitem_426 = convolution_backward_default_38[0]
        getitem_427 = convolution_backward_default_38[1]
        getitem_428 = convolution_backward_default_38[2];  convolution_backward_default_38 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_426, torch.float32);  getitem_426 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_91, to_dtype_78);  le_scalar_26 = new_zeros_default_91 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_80, convolution_default_25, primals_197, primals_195, primals_196, getitem_76, getitem_77, True, 1e-05, [True, True, True]);  to_dtype_80 = convolution_default_25 = primals_197 = primals_195 = primals_196 = getitem_76 = getitem_77 = None
        getitem_429 = native_batch_norm_backward_default_39[0]
        getitem_430 = native_batch_norm_backward_default_39[1]
        getitem_431 = native_batch_norm_backward_default_39[2];  native_batch_norm_backward_default_39 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_429, add_tensor_30, primals_26, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_429 = add_tensor_30 = primals_26 = None
        getitem_432 = convolution_backward_default_39[0]
        getitem_433 = convolution_backward_default_39[1]
        getitem_434 = convolution_backward_default_39[2];  convolution_backward_default_39 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(getitem_432, convolution_default_24, primals_192, primals_190, primals_191, getitem_73, getitem_74, True, 1e-05, [True, True, True]);  convolution_default_24 = primals_192 = primals_190 = primals_191 = getitem_73 = getitem_74 = None
        getitem_435 = native_batch_norm_backward_default_40[0]
        getitem_436 = native_batch_norm_backward_default_40[1]
        getitem_437 = native_batch_norm_backward_default_40[2];  native_batch_norm_backward_default_40 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_435, relu__default_16, primals_24, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_435 = primals_24 = None
        getitem_438 = convolution_backward_default_40[0]
        getitem_439 = convolution_backward_default_40[1]
        getitem_440 = convolution_backward_default_40[2];  convolution_backward_default_40 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_438, torch.float32);  getitem_438 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_92, to_dtype_81);  le_scalar_27 = new_zeros_default_92 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_83, convolution_default_23, primals_187, primals_185, primals_186, getitem_70, getitem_71, True, 1e-05, [True, True, True]);  to_dtype_83 = convolution_default_23 = primals_187 = primals_185 = primals_186 = getitem_70 = getitem_71 = None
        getitem_441 = native_batch_norm_backward_default_41[0]
        getitem_442 = native_batch_norm_backward_default_41[1]
        getitem_443 = native_batch_norm_backward_default_41[2];  native_batch_norm_backward_default_41 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(getitem_441, relu__default_15, primals_22, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_441 = primals_22 = None
        getitem_444 = convolution_backward_default_41[0]
        getitem_445 = convolution_backward_default_41[1]
        getitem_446 = convolution_backward_default_41[2];  convolution_backward_default_41 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_444, torch.float32);  getitem_444 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_93, to_dtype_84);  le_scalar_28 = new_zeros_default_93 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_86, convolution_default_22, primals_182, primals_180, primals_181, getitem_67, getitem_68, True, 1e-05, [True, True, True]);  to_dtype_86 = convolution_default_22 = primals_182 = primals_180 = primals_181 = getitem_67 = getitem_68 = None
        getitem_447 = native_batch_norm_backward_default_42[0]
        getitem_448 = native_batch_norm_backward_default_42[1]
        getitem_449 = native_batch_norm_backward_default_42[2];  native_batch_norm_backward_default_42 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_447, add_tensor_26, primals_23, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_447 = add_tensor_26 = primals_23 = None
        getitem_450 = convolution_backward_default_42[0]
        getitem_451 = convolution_backward_default_42[1]
        getitem_452 = convolution_backward_default_42[2];  convolution_backward_default_42 = None
        add_tensor_89 = torch.ops.aten.add.Tensor(getitem_432, getitem_450);  getitem_432 = getitem_450 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_89, convolution_default_21, primals_177, primals_175, primals_176, getitem_64, getitem_65, True, 1e-05, [True, True, True]);  convolution_default_21 = primals_177 = primals_175 = primals_176 = getitem_64 = getitem_65 = None
        getitem_453 = native_batch_norm_backward_default_43[0]
        getitem_454 = native_batch_norm_backward_default_43[1]
        getitem_455 = native_batch_norm_backward_default_43[2];  native_batch_norm_backward_default_43 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_453, relu__default_14, primals_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_453 = primals_21 = None
        getitem_456 = convolution_backward_default_43[0]
        getitem_457 = convolution_backward_default_43[1]
        getitem_458 = convolution_backward_default_43[2];  convolution_backward_default_43 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_456, torch.float32);  getitem_456 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_94, to_dtype_87);  le_scalar_29 = new_zeros_default_94 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_89, convolution_default_20, primals_172, primals_170, primals_171, getitem_61, getitem_62, True, 1e-05, [True, True, True]);  to_dtype_89 = convolution_default_20 = primals_172 = primals_170 = primals_171 = getitem_61 = getitem_62 = None
        getitem_459 = native_batch_norm_backward_default_44[0]
        getitem_460 = native_batch_norm_backward_default_44[1]
        getitem_461 = native_batch_norm_backward_default_44[2];  native_batch_norm_backward_default_44 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(getitem_459, relu__default_13, primals_19, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 192, [True, True, False]);  getitem_459 = primals_19 = None
        getitem_462 = convolution_backward_default_44[0]
        getitem_463 = convolution_backward_default_44[1]
        getitem_464 = convolution_backward_default_44[2];  convolution_backward_default_44 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_462, torch.float32);  getitem_462 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_95, to_dtype_90);  le_scalar_30 = new_zeros_default_95 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_92, convolution_default_19, primals_167, primals_165, primals_166, getitem_58, getitem_59, True, 1e-05, [True, True, True]);  to_dtype_92 = convolution_default_19 = primals_167 = primals_165 = primals_166 = getitem_58 = getitem_59 = None
        getitem_465 = native_batch_norm_backward_default_45[0]
        getitem_466 = native_batch_norm_backward_default_45[1]
        getitem_467 = native_batch_norm_backward_default_45[2];  native_batch_norm_backward_default_45 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_465, add_tensor_22, primals_20, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_465 = add_tensor_22 = primals_20 = None
        getitem_468 = convolution_backward_default_45[0]
        getitem_469 = convolution_backward_default_45[1]
        getitem_470 = convolution_backward_default_45[2];  convolution_backward_default_45 = None
        add_tensor_90 = torch.ops.aten.add.Tensor(add_tensor_89, getitem_468);  add_tensor_89 = getitem_468 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_90, convolution_default_18, primals_162, primals_160, primals_161, getitem_55, getitem_56, True, 1e-05, [True, True, True]);  convolution_default_18 = primals_162 = primals_160 = primals_161 = getitem_55 = getitem_56 = None
        getitem_471 = native_batch_norm_backward_default_46[0]
        getitem_472 = native_batch_norm_backward_default_46[1]
        getitem_473 = native_batch_norm_backward_default_46[2];  native_batch_norm_backward_default_46 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_471, relu__default_12, primals_18, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_471 = primals_18 = None
        getitem_474 = convolution_backward_default_46[0]
        getitem_475 = convolution_backward_default_46[1]
        getitem_476 = convolution_backward_default_46[2];  convolution_backward_default_46 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_474, torch.float32);  getitem_474 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_96, to_dtype_93);  le_scalar_31 = new_zeros_default_96 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_95, convolution_default_17, primals_157, primals_155, primals_156, getitem_52, getitem_53, True, 1e-05, [True, True, True]);  to_dtype_95 = convolution_default_17 = primals_157 = primals_155 = primals_156 = getitem_52 = getitem_53 = None
        getitem_477 = native_batch_norm_backward_default_47[0]
        getitem_478 = native_batch_norm_backward_default_47[1]
        getitem_479 = native_batch_norm_backward_default_47[2];  native_batch_norm_backward_default_47 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(getitem_477, relu__default_11, primals_16, [0], [1, 1], [2, 2], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_477 = primals_16 = None
        getitem_480 = convolution_backward_default_47[0]
        getitem_481 = convolution_backward_default_47[1]
        getitem_482 = convolution_backward_default_47[2];  convolution_backward_default_47 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_480, torch.float32);  getitem_480 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_97, to_dtype_96);  le_scalar_32 = new_zeros_default_97 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_98, convolution_default_16, primals_152, primals_150, primals_151, getitem_49, getitem_50, True, 1e-05, [True, True, True]);  to_dtype_98 = convolution_default_16 = primals_152 = primals_150 = primals_151 = getitem_49 = getitem_50 = None
        getitem_483 = native_batch_norm_backward_default_48[0]
        getitem_484 = native_batch_norm_backward_default_48[1]
        getitem_485 = native_batch_norm_backward_default_48[2];  native_batch_norm_backward_default_48 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_483, getitem_45, primals_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_483 = getitem_45 = primals_17 = None
        getitem_486 = convolution_backward_default_48[0]
        getitem_487 = convolution_backward_default_48[1]
        getitem_488 = convolution_backward_default_48[2];  convolution_backward_default_48 = None
        add_tensor_91 = torch.ops.aten.add.Tensor(add_tensor_90, getitem_486);  add_tensor_90 = getitem_486 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_91, convolution_default_15, primals_147, primals_145, primals_146, getitem_46, getitem_47, True, 1e-05, [True, True, True]);  add_tensor_91 = convolution_default_15 = primals_147 = primals_145 = primals_146 = getitem_46 = getitem_47 = None
        getitem_489 = native_batch_norm_backward_default_49[0]
        getitem_490 = native_batch_norm_backward_default_49[1]
        getitem_491 = native_batch_norm_backward_default_49[2];  native_batch_norm_backward_default_49 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_489, relu__default_10, primals_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_489 = primals_15 = None
        getitem_492 = convolution_backward_default_49[0]
        getitem_493 = convolution_backward_default_49[1]
        getitem_494 = convolution_backward_default_49[2];  convolution_backward_default_49 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_492, torch.float32);  getitem_492 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_98, to_dtype_99);  le_scalar_33 = new_zeros_default_98 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_101, convolution_default_14, primals_142, primals_140, primals_141, getitem_43, getitem_44, True, 1e-05, [True, True, True]);  to_dtype_101 = convolution_default_14 = primals_142 = primals_140 = primals_141 = getitem_43 = getitem_44 = None
        getitem_495 = native_batch_norm_backward_default_50[0]
        getitem_496 = native_batch_norm_backward_default_50[1]
        getitem_497 = native_batch_norm_backward_default_50[2];  native_batch_norm_backward_default_50 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(getitem_495, relu__default_9, primals_13, [0], [2, 2], [2, 2], [1, 1], False, [0, 0], 144, [True, True, False]);  getitem_495 = primals_13 = None
        getitem_498 = convolution_backward_default_50[0]
        getitem_499 = convolution_backward_default_50[1]
        getitem_500 = convolution_backward_default_50[2];  convolution_backward_default_50 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_498, torch.float32);  getitem_498 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_99, to_dtype_102);  le_scalar_34 = new_zeros_default_99 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_104, convolution_default_13, primals_137, primals_135, primals_136, getitem_40, getitem_41, True, 1e-05, [True, True, True]);  to_dtype_104 = convolution_default_13 = primals_137 = primals_135 = primals_136 = getitem_40 = getitem_41 = None
        getitem_501 = native_batch_norm_backward_default_51[0]
        getitem_502 = native_batch_norm_backward_default_51[1]
        getitem_503 = native_batch_norm_backward_default_51[2];  native_batch_norm_backward_default_51 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_501, add_tensor_15, primals_14, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_501 = add_tensor_15 = primals_14 = None
        getitem_504 = convolution_backward_default_51[0]
        getitem_505 = convolution_backward_default_51[1]
        getitem_506 = convolution_backward_default_51[2];  convolution_backward_default_51 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(getitem_504, convolution_default_12, primals_132, primals_130, primals_131, getitem_37, getitem_38, True, 1e-05, [True, True, True]);  convolution_default_12 = primals_132 = primals_130 = primals_131 = getitem_37 = getitem_38 = None
        getitem_507 = native_batch_norm_backward_default_52[0]
        getitem_508 = native_batch_norm_backward_default_52[1]
        getitem_509 = native_batch_norm_backward_default_52[2];  native_batch_norm_backward_default_52 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_507, relu__default_8, primals_12, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_507 = primals_12 = None
        getitem_510 = convolution_backward_default_52[0]
        getitem_511 = convolution_backward_default_52[1]
        getitem_512 = convolution_backward_default_52[2];  convolution_backward_default_52 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_510, torch.float32);  getitem_510 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_100 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_100, to_dtype_105);  le_scalar_35 = new_zeros_default_100 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_107, convolution_default_11, primals_127, primals_125, primals_126, getitem_34, getitem_35, True, 1e-05, [True, True, True]);  to_dtype_107 = convolution_default_11 = primals_127 = primals_125 = primals_126 = getitem_34 = getitem_35 = None
        getitem_513 = native_batch_norm_backward_default_53[0]
        getitem_514 = native_batch_norm_backward_default_53[1]
        getitem_515 = native_batch_norm_backward_default_53[2];  native_batch_norm_backward_default_53 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(getitem_513, relu__default_7, primals_10, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 24, [True, True, False]);  getitem_513 = primals_10 = None
        getitem_516 = convolution_backward_default_53[0]
        getitem_517 = convolution_backward_default_53[1]
        getitem_518 = convolution_backward_default_53[2];  convolution_backward_default_53 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_516, torch.float32);  getitem_516 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_101 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_101, to_dtype_108);  le_scalar_36 = new_zeros_default_101 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_110, convolution_default_10, primals_122, primals_120, primals_121, getitem_31, getitem_32, True, 1e-05, [True, True, True]);  to_dtype_110 = convolution_default_10 = primals_122 = primals_120 = primals_121 = getitem_31 = getitem_32 = None
        getitem_519 = native_batch_norm_backward_default_54[0]
        getitem_520 = native_batch_norm_backward_default_54[1]
        getitem_521 = native_batch_norm_backward_default_54[2];  native_batch_norm_backward_default_54 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_519, add_tensor_11, primals_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_519 = add_tensor_11 = primals_11 = None
        getitem_522 = convolution_backward_default_54[0]
        getitem_523 = convolution_backward_default_54[1]
        getitem_524 = convolution_backward_default_54[2];  convolution_backward_default_54 = None
        add_tensor_92 = torch.ops.aten.add.Tensor(getitem_504, getitem_522);  getitem_504 = getitem_522 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_92, convolution_default_9, primals_117, primals_115, primals_116, getitem_28, getitem_29, True, 1e-05, [True, True, True]);  convolution_default_9 = primals_117 = primals_115 = primals_116 = getitem_28 = getitem_29 = None
        getitem_525 = native_batch_norm_backward_default_55[0]
        getitem_526 = native_batch_norm_backward_default_55[1]
        getitem_527 = native_batch_norm_backward_default_55[2];  native_batch_norm_backward_default_55 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_525, relu__default_6, primals_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_525 = primals_9 = None
        getitem_528 = convolution_backward_default_55[0]
        getitem_529 = convolution_backward_default_55[1]
        getitem_530 = convolution_backward_default_55[2];  convolution_backward_default_55 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_528, torch.float32);  getitem_528 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_102 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_102, to_dtype_111);  le_scalar_37 = new_zeros_default_102 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_113, convolution_default_8, primals_112, primals_110, primals_111, getitem_25, getitem_26, True, 1e-05, [True, True, True]);  to_dtype_113 = convolution_default_8 = primals_112 = primals_110 = primals_111 = getitem_25 = getitem_26 = None
        getitem_531 = native_batch_norm_backward_default_56[0]
        getitem_532 = native_batch_norm_backward_default_56[1]
        getitem_533 = native_batch_norm_backward_default_56[2];  native_batch_norm_backward_default_56 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(getitem_531, relu__default_5, primals_7, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 24, [True, True, False]);  getitem_531 = primals_7 = None
        getitem_534 = convolution_backward_default_56[0]
        getitem_535 = convolution_backward_default_56[1]
        getitem_536 = convolution_backward_default_56[2];  convolution_backward_default_56 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_534, torch.float32);  getitem_534 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_103 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_103, to_dtype_114);  le_scalar_38 = new_zeros_default_103 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_116, convolution_default_7, primals_107, primals_105, primals_106, getitem_22, getitem_23, True, 1e-05, [True, True, True]);  to_dtype_116 = convolution_default_7 = primals_107 = primals_105 = primals_106 = getitem_22 = getitem_23 = None
        getitem_537 = native_batch_norm_backward_default_57[0]
        getitem_538 = native_batch_norm_backward_default_57[1]
        getitem_539 = native_batch_norm_backward_default_57[2];  native_batch_norm_backward_default_57 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_537, getitem_18, primals_8, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_537 = getitem_18 = primals_8 = None
        getitem_540 = convolution_backward_default_57[0]
        getitem_541 = convolution_backward_default_57[1]
        getitem_542 = convolution_backward_default_57[2];  convolution_backward_default_57 = None
        add_tensor_93 = torch.ops.aten.add.Tensor(add_tensor_92, getitem_540);  add_tensor_92 = getitem_540 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(add_tensor_93, convolution_default_6, primals_102, primals_100, primals_101, getitem_19, getitem_20, True, 1e-05, [True, True, True]);  add_tensor_93 = convolution_default_6 = primals_102 = primals_100 = primals_101 = getitem_19 = getitem_20 = None
        getitem_543 = native_batch_norm_backward_default_58[0]
        getitem_544 = native_batch_norm_backward_default_58[1]
        getitem_545 = native_batch_norm_backward_default_58[2];  native_batch_norm_backward_default_58 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_543, relu__default_4, primals_6, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_543 = primals_6 = None
        getitem_546 = convolution_backward_default_58[0]
        getitem_547 = convolution_backward_default_58[1]
        getitem_548 = convolution_backward_default_58[2];  convolution_backward_default_58 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_546, torch.float32);  getitem_546 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_104 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_104, to_dtype_117);  le_scalar_39 = new_zeros_default_104 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_119, convolution_default_5, primals_97, primals_95, primals_96, getitem_16, getitem_17, True, 1e-05, [True, True, True]);  to_dtype_119 = convolution_default_5 = primals_97 = primals_95 = primals_96 = getitem_16 = getitem_17 = None
        getitem_549 = native_batch_norm_backward_default_59[0]
        getitem_550 = native_batch_norm_backward_default_59[1]
        getitem_551 = native_batch_norm_backward_default_59[2];  native_batch_norm_backward_default_59 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(getitem_549, relu__default_3, primals_4, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 96, [True, True, False]);  getitem_549 = primals_4 = None
        getitem_552 = convolution_backward_default_59[0]
        getitem_553 = convolution_backward_default_59[1]
        getitem_554 = convolution_backward_default_59[2];  convolution_backward_default_59 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_552, torch.float32);  getitem_552 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_105 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_105, to_dtype_120);  le_scalar_40 = new_zeros_default_105 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_122, convolution_default_4, primals_92, primals_90, primals_91, getitem_13, getitem_14, True, 1e-05, [True, True, True]);  to_dtype_122 = convolution_default_4 = primals_92 = primals_90 = primals_91 = getitem_13 = getitem_14 = None
        getitem_555 = native_batch_norm_backward_default_60[0]
        getitem_556 = native_batch_norm_backward_default_60[1]
        getitem_557 = native_batch_norm_backward_default_60[2];  native_batch_norm_backward_default_60 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_555, add_tensor_4, primals_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_555 = add_tensor_4 = primals_5 = None
        getitem_558 = convolution_backward_default_60[0]
        getitem_559 = convolution_backward_default_60[1]
        getitem_560 = convolution_backward_default_60[2];  convolution_backward_default_60 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(getitem_558, convolution_default_3, primals_87, primals_85, primals_86, getitem_10, getitem_11, True, 1e-05, [True, True, True]);  convolution_default_3 = primals_87 = primals_85 = primals_86 = getitem_10 = getitem_11 = None
        getitem_561 = native_batch_norm_backward_default_61[0]
        getitem_562 = native_batch_norm_backward_default_61[1]
        getitem_563 = native_batch_norm_backward_default_61[2];  native_batch_norm_backward_default_61 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_561, relu__default_2, primals_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_561 = primals_3 = None
        getitem_564 = convolution_backward_default_61[0]
        getitem_565 = convolution_backward_default_61[1]
        getitem_566 = convolution_backward_default_61[2];  convolution_backward_default_61 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_564, torch.float32);  getitem_564 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_106 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_106, to_dtype_123);  le_scalar_41 = new_zeros_default_106 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_125, convolution_default_2, primals_82, primals_80, primals_81, getitem_7, getitem_8, True, 1e-05, [True, True, True]);  to_dtype_125 = convolution_default_2 = primals_82 = primals_80 = primals_81 = getitem_7 = getitem_8 = None
        getitem_567 = native_batch_norm_backward_default_62[0]
        getitem_568 = native_batch_norm_backward_default_62[1]
        getitem_569 = native_batch_norm_backward_default_62[2];  native_batch_norm_backward_default_62 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(getitem_567, relu__default_1, primals_1, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 16, [True, True, False]);  getitem_567 = primals_1 = None
        getitem_570 = convolution_backward_default_62[0]
        getitem_571 = convolution_backward_default_62[1]
        getitem_572 = convolution_backward_default_62[2];  convolution_backward_default_62 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_570, torch.float32);  getitem_570 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_107 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_107, to_dtype_126);  le_scalar_42 = new_zeros_default_107 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_128, convolution_default_1, primals_77, primals_75, primals_76, getitem_4, getitem_5, True, 1e-05, [True, True, True]);  to_dtype_128 = convolution_default_1 = primals_77 = primals_75 = primals_76 = getitem_4 = getitem_5 = None
        getitem_573 = native_batch_norm_backward_default_63[0]
        getitem_574 = native_batch_norm_backward_default_63[1]
        getitem_575 = native_batch_norm_backward_default_63[2];  native_batch_norm_backward_default_63 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_573, relu__default, primals_2, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_573 = primals_2 = None
        getitem_576 = convolution_backward_default_63[0]
        getitem_577 = convolution_backward_default_63[1]
        getitem_578 = convolution_backward_default_63[2];  convolution_backward_default_63 = None
        add_tensor_94 = torch.ops.aten.add.Tensor(getitem_558, getitem_576);  getitem_558 = getitem_576 = None
        to_dtype_129 = torch.ops.aten.to.dtype(add_tensor_94, torch.float32);  add_tensor_94 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_108 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_108, to_dtype_129);  le_scalar_43 = new_zeros_default_108 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(to_dtype_131, convolution_default, primals_72, primals_70, primals_71, getitem_1, getitem_2, True, 1e-05, [True, True, True]);  to_dtype_131 = convolution_default = primals_72 = primals_70 = primals_71 = getitem_1 = getitem_2 = None
        getitem_579 = native_batch_norm_backward_default_64[0]
        getitem_580 = native_batch_norm_backward_default_64[1]
        getitem_581 = native_batch_norm_backward_default_64[2];  native_batch_norm_backward_default_64 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_579, primals_68, primals_67, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [False, True, False]);  getitem_579 = primals_68 = primals_67 = None
        getitem_582 = convolution_backward_default_64[0]
        getitem_583 = convolution_backward_default_64[1]
        getitem_584 = convolution_backward_default_64[2];  convolution_backward_default_64 = None
        return [addmm_default, add_tensor, add_tensor_1, add_tensor_2, add_tensor_3, add_tensor_5, add_tensor_6, add_tensor_7, add_tensor_8, add_tensor_9, add_tensor_10, add_tensor_12, add_tensor_13, add_tensor_14, add_tensor_16, add_tensor_17, add_tensor_18, add_tensor_19, add_tensor_20, add_tensor_21, add_tensor_23, add_tensor_24, add_tensor_25, add_tensor_27, add_tensor_28, add_tensor_29, add_tensor_31, add_tensor_32, add_tensor_33, add_tensor_34, add_tensor_35, add_tensor_36, add_tensor_38, add_tensor_39, add_tensor_40, add_tensor_42, add_tensor_43, add_tensor_44, add_tensor_46, add_tensor_47, add_tensor_48, add_tensor_49, add_tensor_50, add_tensor_51, add_tensor_53, add_tensor_54, add_tensor_55, add_tensor_57, add_tensor_58, add_tensor_59, add_tensor_61, add_tensor_62, add_tensor_63, add_tensor_64, add_tensor_65, add_tensor_66, add_tensor_68, add_tensor_69, add_tensor_70, add_tensor_72, add_tensor_73, add_tensor_74, add_tensor_76, add_tensor_77, add_tensor_78, add_tensor_79, getitem_571, getitem_577, getitem_565, getitem_553, getitem_559, getitem_547, getitem_535, getitem_541, getitem_529, getitem_517, getitem_523, getitem_511, getitem_499, getitem_505, getitem_493, getitem_481, getitem_487, getitem_475, getitem_463, getitem_469, getitem_457, getitem_445, getitem_451, getitem_439, getitem_427, getitem_433, getitem_421, getitem_409, getitem_415, getitem_403, getitem_391, getitem_397, getitem_385, getitem_373, getitem_379, getitem_367, getitem_355, getitem_361, getitem_349, getitem_337, getitem_343, getitem_331, getitem_319, getitem_325, getitem_313, getitem_301, getitem_307, getitem_295, getitem_283, getitem_289, getitem_277, getitem_265, getitem_271, getitem_259, getitem_247, getitem_253, getitem_241, getitem_229, getitem_235, getitem_223, getitem_211, getitem_217, getitem_205, view_default_1, t_default_4, getitem_199, getitem_583, None, None, None, None, getitem_580, getitem_581, None, None, None, getitem_574, getitem_575, None, None, None, getitem_568, getitem_569, None, None, None, getitem_562, getitem_563, None, None, None, getitem_556, getitem_557, None, None, None, getitem_550, getitem_551, None, None, None, getitem_544, getitem_545, None, None, None, getitem_538, getitem_539, None, None, None, getitem_532, getitem_533, None, None, None, getitem_526, getitem_527, None, None, None, getitem_520, getitem_521, None, None, None, getitem_514, getitem_515, None, None, None, getitem_508, getitem_509, None, None, None, getitem_502, getitem_503, None, None, None, getitem_496, getitem_497, None, None, None, getitem_490, getitem_491, None, None, None, getitem_484, getitem_485, None, None, None, getitem_478, getitem_479, None, None, None, getitem_472, getitem_473, None, None, None, getitem_466, getitem_467, None, None, None, getitem_460, getitem_461, None, None, None, getitem_454, getitem_455, None, None, None, getitem_448, getitem_449, None, None, None, getitem_442, getitem_443, None, None, None, getitem_436, getitem_437, None, None, None, getitem_430, getitem_431, None, None, None, getitem_424, getitem_425, None, None, None, getitem_418, getitem_419, None, None, None, getitem_412, getitem_413, None, None, None, getitem_406, getitem_407, None, None, None, getitem_400, getitem_401, None, None, None, getitem_394, getitem_395, None, None, None, getitem_388, getitem_389, None, None, None, getitem_382, getitem_383, None, None, None, getitem_376, getitem_377, None, None, None, getitem_370, getitem_371, None, None, None, getitem_364, getitem_365, None, None, None, getitem_358, getitem_359, None, None, None, getitem_352, getitem_353, None, None, None, getitem_346, getitem_347, None, None, None, getitem_340, getitem_341, None, None, None, getitem_334, getitem_335, None, None, None, getitem_328, getitem_329, None, None, None, getitem_322, getitem_323, None, None, None, getitem_316, getitem_317, None, None, None, getitem_310, getitem_311, None, None, None, getitem_304, getitem_305, None, None, None, getitem_298, getitem_299, None, None, None, getitem_292, getitem_293, None, None, None, getitem_286, getitem_287, None, None, None, getitem_280, getitem_281, None, None, None, getitem_274, getitem_275, None, None, None, getitem_268, getitem_269, None, None, None, getitem_262, getitem_263, None, None, None, getitem_256, getitem_257, None, None, None, getitem_250, getitem_251, None, None, None, getitem_244, getitem_245, None, None, None, getitem_238, getitem_239, None, None, None, getitem_232, getitem_233, None, None, None, getitem_226, getitem_227, None, None, None, getitem_220, getitem_221, None, None, None, getitem_214, getitem_215, None, None, None, getitem_208, getitem_209, None, None, None, getitem_202, getitem_203, None, None, None, getitem_196, getitem_197]
        
