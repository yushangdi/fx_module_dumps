
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/resnetv2_101x1_bitm/resnetv2_101x1_bitm_forward_0/state_dict.pt'))

    
    
    def forward(self, primals_1, primals_2, primals_3, primals_4, primals_5, primals_6, primals_7, primals_8, primals_9, primals_10, primals_11, primals_12, primals_13, primals_14, primals_15, primals_16, primals_17, primals_18, primals_19, primals_20, primals_21, primals_22, primals_23, primals_24, primals_25, primals_26, primals_27, primals_28, primals_29, primals_30, primals_31, primals_32, primals_33, primals_34, primals_35, primals_36, primals_37, primals_38, primals_39, primals_40, primals_41, primals_42, primals_43, primals_44, primals_45, primals_46, primals_47, primals_48, primals_49, primals_50, primals_51, primals_52, primals_53, primals_54, primals_55, primals_56, primals_57, primals_58, primals_59, primals_60, primals_61, primals_62, primals_63, primals_64, primals_65, primals_66, primals_67, primals_68, primals_69, primals_70, primals_71, primals_72, primals_73, primals_74, primals_75, primals_76, primals_77, primals_78, primals_79, primals_80, primals_81, primals_82, primals_83, primals_84, primals_85, primals_86, primals_87, primals_88, primals_89, primals_90, primals_91, primals_92, primals_93, primals_94, primals_95, primals_96, primals_97, primals_98, primals_99, primals_100, primals_101, primals_102, primals_103, primals_104, primals_105, primals_106, primals_107, primals_108, primals_109, primals_110, primals_111, primals_112, primals_113, primals_114, primals_115, primals_116, primals_117, primals_118, primals_119, primals_120, primals_121, primals_122, primals_123, primals_124, primals_125, primals_126, primals_127, primals_128, primals_129, primals_130, primals_131, primals_132, primals_133, primals_134, primals_135, primals_136, primals_137, primals_138, primals_139, primals_140, primals_141, primals_142, primals_143, primals_144, primals_145, primals_146, primals_147, primals_148, primals_149, primals_150, primals_151, primals_152, primals_153, primals_154, primals_155, primals_156, primals_157, primals_158, primals_159, primals_160, primals_161, primals_162, primals_163, primals_164, primals_165, primals_166, primals_167, primals_168, primals_169, primals_170, primals_171, primals_172, primals_173, primals_174, primals_175, primals_176, primals_177, primals_178, primals_179, primals_180, primals_181, primals_182, primals_183, primals_184, primals_185, primals_186, primals_187, primals_188, primals_189, primals_190, primals_191, primals_192, primals_193, primals_194, primals_195, primals_196, primals_197, primals_198, primals_199, primals_200, primals_201, primals_202, primals_203, primals_204, primals_205, primals_206, primals_207, primals_208, primals_209, primals_210, primals_211, primals_212, primals_213, primals_214, primals_215, primals_216, primals_217, primals_218, primals_219, primals_220, primals_221, primals_222, primals_223, primals_224, primals_225, primals_226, primals_227, primals_228, primals_229, primals_230, primals_231, primals_232, primals_233, primals_234, primals_235, primals_236, primals_237, primals_238, primals_239, primals_240, primals_241, primals_242, primals_243, primals_244, primals_245, primals_246, primals_247, primals_248, primals_249, primals_250, primals_251, primals_252, primals_253, primals_254, primals_255, primals_256, primals_257, primals_258, primals_259, primals_260, primals_261, primals_262, primals_263, primals_264, primals_265, primals_266, primals_267, primals_268, primals_269, primals_270, primals_271, primals_272, primals_273, primals_274, primals_275, primals_276, primals_277, primals_278, primals_279, primals_280, primals_281, primals_282, primals_283, primals_284, primals_285, primals_286, primals_287, primals_288, primals_289, primals_290, primals_291, primals_292, primals_293, primals_294, primals_295, primals_296, primals_297, primals_298, primals_299, primals_300, primals_301, primals_302, primals_303, primals_304, primals_305, primals_306, primals_307):
        view_default = torch.ops.aten.view.default(primals_306, [1, 64, 147]);  primals_306 = None
        native_batch_norm_default = torch.ops.aten.native_batch_norm.default(view_default, None, None, None, None, True, 0.0, 1e-08)
        getitem = native_batch_norm_default[0]
        getitem_1 = native_batch_norm_default[1]
        getitem_2 = native_batch_norm_default[2];  native_batch_norm_default = None
        view_default_1 = torch.ops.aten.view.default(getitem, [64, 3, 7, 7]);  getitem = None
        convolution_default = torch.ops.aten.convolution.default(primals_307, view_default_1, None, [2, 2], [3, 3], [1, 1], False, [0, 0], 1)
        constant_pad_nd_default = torch.ops.aten.constant_pad_nd.default(convolution_default, [1, 1, 1, 1], 0.0);  convolution_default = None
        max_pool2d_with_indices_default = torch.ops.aten.max_pool2d_with_indices.default(constant_pad_nd_default, [3, 3], [2, 2])
        getitem_3 = max_pool2d_with_indices_default[0]
        getitem_4 = max_pool2d_with_indices_default[1];  max_pool2d_with_indices_default = None
        native_group_norm_default = torch.ops.aten.native_group_norm.default(getitem_3, primals_10, primals_9, 64, 64, 12544, 32, 1e-05);  primals_9 = None
        getitem_5 = native_group_norm_default[0]
        getitem_6 = native_group_norm_default[1]
        getitem_7 = native_group_norm_default[2];  native_group_norm_default = None
        relu__default = torch.ops.aten.relu_.default(getitem_5);  getitem_5 = None
        view_default_2 = torch.ops.aten.view.default(primals_8, [1, 256, 64]);  primals_8 = None
        native_batch_norm_default_1 = torch.ops.aten.native_batch_norm.default(view_default_2, None, None, None, None, True, 0.0, 1e-08)
        getitem_8 = native_batch_norm_default_1[0]
        getitem_9 = native_batch_norm_default_1[1]
        getitem_10 = native_batch_norm_default_1[2];  native_batch_norm_default_1 = None
        view_default_3 = torch.ops.aten.view.default(getitem_8, [256, 64, 1, 1]);  getitem_8 = None
        convolution_default_1 = torch.ops.aten.convolution.default(relu__default, view_default_3, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_4 = torch.ops.aten.view.default(primals_5, [1, 64, 64]);  primals_5 = None
        native_batch_norm_default_2 = torch.ops.aten.native_batch_norm.default(view_default_4, None, None, None, None, True, 0.0, 1e-08)
        getitem_11 = native_batch_norm_default_2[0]
        getitem_12 = native_batch_norm_default_2[1]
        getitem_13 = native_batch_norm_default_2[2];  native_batch_norm_default_2 = None
        view_default_5 = torch.ops.aten.view.default(getitem_11, [64, 64, 1, 1]);  getitem_11 = None
        convolution_default_2 = torch.ops.aten.convolution.default(relu__default, view_default_5, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_1 = torch.ops.aten.native_group_norm.default(convolution_default_2, primals_12, primals_11, 64, 64, 12544, 32, 1e-05);  primals_11 = None
        getitem_14 = native_group_norm_default_1[0]
        getitem_15 = native_group_norm_default_1[1]
        getitem_16 = native_group_norm_default_1[2];  native_group_norm_default_1 = None
        relu__default_1 = torch.ops.aten.relu_.default(getitem_14);  getitem_14 = None
        view_default_6 = torch.ops.aten.view.default(primals_6, [1, 64, 576]);  primals_6 = None
        native_batch_norm_default_3 = torch.ops.aten.native_batch_norm.default(view_default_6, None, None, None, None, True, 0.0, 1e-08)
        getitem_17 = native_batch_norm_default_3[0]
        getitem_18 = native_batch_norm_default_3[1]
        getitem_19 = native_batch_norm_default_3[2];  native_batch_norm_default_3 = None
        view_default_7 = torch.ops.aten.view.default(getitem_17, [64, 64, 3, 3]);  getitem_17 = None
        convolution_default_3 = torch.ops.aten.convolution.default(relu__default_1, view_default_7, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_2 = torch.ops.aten.native_group_norm.default(convolution_default_3, primals_14, primals_13, 64, 64, 12544, 32, 1e-05);  primals_13 = None
        getitem_20 = native_group_norm_default_2[0]
        getitem_21 = native_group_norm_default_2[1]
        getitem_22 = native_group_norm_default_2[2];  native_group_norm_default_2 = None
        relu__default_2 = torch.ops.aten.relu_.default(getitem_20);  getitem_20 = None
        view_default_8 = torch.ops.aten.view.default(primals_7, [1, 256, 64]);  primals_7 = None
        native_batch_norm_default_4 = torch.ops.aten.native_batch_norm.default(view_default_8, None, None, None, None, True, 0.0, 1e-08)
        getitem_23 = native_batch_norm_default_4[0]
        getitem_24 = native_batch_norm_default_4[1]
        getitem_25 = native_batch_norm_default_4[2];  native_batch_norm_default_4 = None
        view_default_9 = torch.ops.aten.view.default(getitem_23, [256, 64, 1, 1]);  getitem_23 = None
        convolution_default_4 = torch.ops.aten.convolution.default(relu__default_2, view_default_9, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor = torch.ops.aten.add.Tensor(convolution_default_4, convolution_default_1);  convolution_default_4 = convolution_default_1 = None
        native_group_norm_default_3 = torch.ops.aten.native_group_norm.default(add_tensor, primals_19, primals_18, 64, 256, 12544, 32, 1e-05);  primals_18 = None
        getitem_26 = native_group_norm_default_3[0]
        getitem_27 = native_group_norm_default_3[1]
        getitem_28 = native_group_norm_default_3[2];  native_group_norm_default_3 = None
        relu__default_3 = torch.ops.aten.relu_.default(getitem_26);  getitem_26 = None
        view_default_10 = torch.ops.aten.view.default(primals_15, [1, 64, 256]);  primals_15 = None
        native_batch_norm_default_5 = torch.ops.aten.native_batch_norm.default(view_default_10, None, None, None, None, True, 0.0, 1e-08)
        getitem_29 = native_batch_norm_default_5[0]
        getitem_30 = native_batch_norm_default_5[1]
        getitem_31 = native_batch_norm_default_5[2];  native_batch_norm_default_5 = None
        view_default_11 = torch.ops.aten.view.default(getitem_29, [64, 256, 1, 1]);  getitem_29 = None
        convolution_default_5 = torch.ops.aten.convolution.default(relu__default_3, view_default_11, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_4 = torch.ops.aten.native_group_norm.default(convolution_default_5, primals_21, primals_20, 64, 64, 12544, 32, 1e-05);  primals_20 = None
        getitem_32 = native_group_norm_default_4[0]
        getitem_33 = native_group_norm_default_4[1]
        getitem_34 = native_group_norm_default_4[2];  native_group_norm_default_4 = None
        relu__default_4 = torch.ops.aten.relu_.default(getitem_32);  getitem_32 = None
        view_default_12 = torch.ops.aten.view.default(primals_16, [1, 64, 576]);  primals_16 = None
        native_batch_norm_default_6 = torch.ops.aten.native_batch_norm.default(view_default_12, None, None, None, None, True, 0.0, 1e-08)
        getitem_35 = native_batch_norm_default_6[0]
        getitem_36 = native_batch_norm_default_6[1]
        getitem_37 = native_batch_norm_default_6[2];  native_batch_norm_default_6 = None
        view_default_13 = torch.ops.aten.view.default(getitem_35, [64, 64, 3, 3]);  getitem_35 = None
        convolution_default_6 = torch.ops.aten.convolution.default(relu__default_4, view_default_13, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_5 = torch.ops.aten.native_group_norm.default(convolution_default_6, primals_23, primals_22, 64, 64, 12544, 32, 1e-05);  primals_22 = None
        getitem_38 = native_group_norm_default_5[0]
        getitem_39 = native_group_norm_default_5[1]
        getitem_40 = native_group_norm_default_5[2];  native_group_norm_default_5 = None
        relu__default_5 = torch.ops.aten.relu_.default(getitem_38);  getitem_38 = None
        view_default_14 = torch.ops.aten.view.default(primals_17, [1, 256, 64]);  primals_17 = None
        native_batch_norm_default_7 = torch.ops.aten.native_batch_norm.default(view_default_14, None, None, None, None, True, 0.0, 1e-08)
        getitem_41 = native_batch_norm_default_7[0]
        getitem_42 = native_batch_norm_default_7[1]
        getitem_43 = native_batch_norm_default_7[2];  native_batch_norm_default_7 = None
        view_default_15 = torch.ops.aten.view.default(getitem_41, [256, 64, 1, 1]);  getitem_41 = None
        convolution_default_7 = torch.ops.aten.convolution.default(relu__default_5, view_default_15, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_1 = torch.ops.aten.add.Tensor(convolution_default_7, add_tensor);  convolution_default_7 = None
        native_group_norm_default_6 = torch.ops.aten.native_group_norm.default(add_tensor_1, primals_28, primals_27, 64, 256, 12544, 32, 1e-05);  primals_27 = None
        getitem_44 = native_group_norm_default_6[0]
        getitem_45 = native_group_norm_default_6[1]
        getitem_46 = native_group_norm_default_6[2];  native_group_norm_default_6 = None
        relu__default_6 = torch.ops.aten.relu_.default(getitem_44);  getitem_44 = None
        view_default_16 = torch.ops.aten.view.default(primals_24, [1, 64, 256]);  primals_24 = None
        native_batch_norm_default_8 = torch.ops.aten.native_batch_norm.default(view_default_16, None, None, None, None, True, 0.0, 1e-08)
        getitem_47 = native_batch_norm_default_8[0]
        getitem_48 = native_batch_norm_default_8[1]
        getitem_49 = native_batch_norm_default_8[2];  native_batch_norm_default_8 = None
        view_default_17 = torch.ops.aten.view.default(getitem_47, [64, 256, 1, 1]);  getitem_47 = None
        convolution_default_8 = torch.ops.aten.convolution.default(relu__default_6, view_default_17, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_7 = torch.ops.aten.native_group_norm.default(convolution_default_8, primals_30, primals_29, 64, 64, 12544, 32, 1e-05);  primals_29 = None
        getitem_50 = native_group_norm_default_7[0]
        getitem_51 = native_group_norm_default_7[1]
        getitem_52 = native_group_norm_default_7[2];  native_group_norm_default_7 = None
        relu__default_7 = torch.ops.aten.relu_.default(getitem_50);  getitem_50 = None
        view_default_18 = torch.ops.aten.view.default(primals_25, [1, 64, 576]);  primals_25 = None
        native_batch_norm_default_9 = torch.ops.aten.native_batch_norm.default(view_default_18, None, None, None, None, True, 0.0, 1e-08)
        getitem_53 = native_batch_norm_default_9[0]
        getitem_54 = native_batch_norm_default_9[1]
        getitem_55 = native_batch_norm_default_9[2];  native_batch_norm_default_9 = None
        view_default_19 = torch.ops.aten.view.default(getitem_53, [64, 64, 3, 3]);  getitem_53 = None
        convolution_default_9 = torch.ops.aten.convolution.default(relu__default_7, view_default_19, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_8 = torch.ops.aten.native_group_norm.default(convolution_default_9, primals_32, primals_31, 64, 64, 12544, 32, 1e-05);  primals_31 = None
        getitem_56 = native_group_norm_default_8[0]
        getitem_57 = native_group_norm_default_8[1]
        getitem_58 = native_group_norm_default_8[2];  native_group_norm_default_8 = None
        relu__default_8 = torch.ops.aten.relu_.default(getitem_56);  getitem_56 = None
        view_default_20 = torch.ops.aten.view.default(primals_26, [1, 256, 64]);  primals_26 = None
        native_batch_norm_default_10 = torch.ops.aten.native_batch_norm.default(view_default_20, None, None, None, None, True, 0.0, 1e-08)
        getitem_59 = native_batch_norm_default_10[0]
        getitem_60 = native_batch_norm_default_10[1]
        getitem_61 = native_batch_norm_default_10[2];  native_batch_norm_default_10 = None
        view_default_21 = torch.ops.aten.view.default(getitem_59, [256, 64, 1, 1]);  getitem_59 = None
        convolution_default_10 = torch.ops.aten.convolution.default(relu__default_8, view_default_21, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_2 = torch.ops.aten.add.Tensor(convolution_default_10, add_tensor_1);  convolution_default_10 = None
        native_group_norm_default_9 = torch.ops.aten.native_group_norm.default(add_tensor_2, primals_38, primals_37, 64, 256, 12544, 32, 1e-05);  primals_37 = None
        getitem_62 = native_group_norm_default_9[0]
        getitem_63 = native_group_norm_default_9[1]
        getitem_64 = native_group_norm_default_9[2];  native_group_norm_default_9 = None
        relu__default_9 = torch.ops.aten.relu_.default(getitem_62);  getitem_62 = None
        view_default_22 = torch.ops.aten.view.default(primals_36, [1, 512, 256]);  primals_36 = None
        native_batch_norm_default_11 = torch.ops.aten.native_batch_norm.default(view_default_22, None, None, None, None, True, 0.0, 1e-08)
        getitem_65 = native_batch_norm_default_11[0]
        getitem_66 = native_batch_norm_default_11[1]
        getitem_67 = native_batch_norm_default_11[2];  native_batch_norm_default_11 = None
        view_default_23 = torch.ops.aten.view.default(getitem_65, [512, 256, 1, 1]);  getitem_65 = None
        convolution_default_11 = torch.ops.aten.convolution.default(relu__default_9, view_default_23, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_24 = torch.ops.aten.view.default(primals_33, [1, 128, 256]);  primals_33 = None
        native_batch_norm_default_12 = torch.ops.aten.native_batch_norm.default(view_default_24, None, None, None, None, True, 0.0, 1e-08)
        getitem_68 = native_batch_norm_default_12[0]
        getitem_69 = native_batch_norm_default_12[1]
        getitem_70 = native_batch_norm_default_12[2];  native_batch_norm_default_12 = None
        view_default_25 = torch.ops.aten.view.default(getitem_68, [128, 256, 1, 1]);  getitem_68 = None
        convolution_default_12 = torch.ops.aten.convolution.default(relu__default_9, view_default_25, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_10 = torch.ops.aten.native_group_norm.default(convolution_default_12, primals_40, primals_39, 64, 128, 12544, 32, 1e-05);  primals_39 = None
        getitem_71 = native_group_norm_default_10[0]
        getitem_72 = native_group_norm_default_10[1]
        getitem_73 = native_group_norm_default_10[2];  native_group_norm_default_10 = None
        relu__default_10 = torch.ops.aten.relu_.default(getitem_71);  getitem_71 = None
        view_default_26 = torch.ops.aten.view.default(primals_34, [1, 128, 1152]);  primals_34 = None
        native_batch_norm_default_13 = torch.ops.aten.native_batch_norm.default(view_default_26, None, None, None, None, True, 0.0, 1e-08)
        getitem_74 = native_batch_norm_default_13[0]
        getitem_75 = native_batch_norm_default_13[1]
        getitem_76 = native_batch_norm_default_13[2];  native_batch_norm_default_13 = None
        view_default_27 = torch.ops.aten.view.default(getitem_74, [128, 128, 3, 3]);  getitem_74 = None
        convolution_default_13 = torch.ops.aten.convolution.default(relu__default_10, view_default_27, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_11 = torch.ops.aten.native_group_norm.default(convolution_default_13, primals_42, primals_41, 64, 128, 3136, 32, 1e-05);  primals_41 = None
        getitem_77 = native_group_norm_default_11[0]
        getitem_78 = native_group_norm_default_11[1]
        getitem_79 = native_group_norm_default_11[2];  native_group_norm_default_11 = None
        relu__default_11 = torch.ops.aten.relu_.default(getitem_77);  getitem_77 = None
        view_default_28 = torch.ops.aten.view.default(primals_35, [1, 512, 128]);  primals_35 = None
        native_batch_norm_default_14 = torch.ops.aten.native_batch_norm.default(view_default_28, None, None, None, None, True, 0.0, 1e-08)
        getitem_80 = native_batch_norm_default_14[0]
        getitem_81 = native_batch_norm_default_14[1]
        getitem_82 = native_batch_norm_default_14[2];  native_batch_norm_default_14 = None
        view_default_29 = torch.ops.aten.view.default(getitem_80, [512, 128, 1, 1]);  getitem_80 = None
        convolution_default_14 = torch.ops.aten.convolution.default(relu__default_11, view_default_29, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_3 = torch.ops.aten.add.Tensor(convolution_default_14, convolution_default_11);  convolution_default_14 = convolution_default_11 = None
        native_group_norm_default_12 = torch.ops.aten.native_group_norm.default(add_tensor_3, primals_47, primals_46, 64, 512, 3136, 32, 1e-05);  primals_46 = None
        getitem_83 = native_group_norm_default_12[0]
        getitem_84 = native_group_norm_default_12[1]
        getitem_85 = native_group_norm_default_12[2];  native_group_norm_default_12 = None
        relu__default_12 = torch.ops.aten.relu_.default(getitem_83);  getitem_83 = None
        view_default_30 = torch.ops.aten.view.default(primals_43, [1, 128, 512]);  primals_43 = None
        native_batch_norm_default_15 = torch.ops.aten.native_batch_norm.default(view_default_30, None, None, None, None, True, 0.0, 1e-08)
        getitem_86 = native_batch_norm_default_15[0]
        getitem_87 = native_batch_norm_default_15[1]
        getitem_88 = native_batch_norm_default_15[2];  native_batch_norm_default_15 = None
        view_default_31 = torch.ops.aten.view.default(getitem_86, [128, 512, 1, 1]);  getitem_86 = None
        convolution_default_15 = torch.ops.aten.convolution.default(relu__default_12, view_default_31, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_13 = torch.ops.aten.native_group_norm.default(convolution_default_15, primals_49, primals_48, 64, 128, 3136, 32, 1e-05);  primals_48 = None
        getitem_89 = native_group_norm_default_13[0]
        getitem_90 = native_group_norm_default_13[1]
        getitem_91 = native_group_norm_default_13[2];  native_group_norm_default_13 = None
        relu__default_13 = torch.ops.aten.relu_.default(getitem_89);  getitem_89 = None
        view_default_32 = torch.ops.aten.view.default(primals_44, [1, 128, 1152]);  primals_44 = None
        native_batch_norm_default_16 = torch.ops.aten.native_batch_norm.default(view_default_32, None, None, None, None, True, 0.0, 1e-08)
        getitem_92 = native_batch_norm_default_16[0]
        getitem_93 = native_batch_norm_default_16[1]
        getitem_94 = native_batch_norm_default_16[2];  native_batch_norm_default_16 = None
        view_default_33 = torch.ops.aten.view.default(getitem_92, [128, 128, 3, 3]);  getitem_92 = None
        convolution_default_16 = torch.ops.aten.convolution.default(relu__default_13, view_default_33, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_14 = torch.ops.aten.native_group_norm.default(convolution_default_16, primals_51, primals_50, 64, 128, 3136, 32, 1e-05);  primals_50 = None
        getitem_95 = native_group_norm_default_14[0]
        getitem_96 = native_group_norm_default_14[1]
        getitem_97 = native_group_norm_default_14[2];  native_group_norm_default_14 = None
        relu__default_14 = torch.ops.aten.relu_.default(getitem_95);  getitem_95 = None
        view_default_34 = torch.ops.aten.view.default(primals_45, [1, 512, 128]);  primals_45 = None
        native_batch_norm_default_17 = torch.ops.aten.native_batch_norm.default(view_default_34, None, None, None, None, True, 0.0, 1e-08)
        getitem_98 = native_batch_norm_default_17[0]
        getitem_99 = native_batch_norm_default_17[1]
        getitem_100 = native_batch_norm_default_17[2];  native_batch_norm_default_17 = None
        view_default_35 = torch.ops.aten.view.default(getitem_98, [512, 128, 1, 1]);  getitem_98 = None
        convolution_default_17 = torch.ops.aten.convolution.default(relu__default_14, view_default_35, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_4 = torch.ops.aten.add.Tensor(convolution_default_17, add_tensor_3);  convolution_default_17 = None
        native_group_norm_default_15 = torch.ops.aten.native_group_norm.default(add_tensor_4, primals_56, primals_55, 64, 512, 3136, 32, 1e-05);  primals_55 = None
        getitem_101 = native_group_norm_default_15[0]
        getitem_102 = native_group_norm_default_15[1]
        getitem_103 = native_group_norm_default_15[2];  native_group_norm_default_15 = None
        relu__default_15 = torch.ops.aten.relu_.default(getitem_101);  getitem_101 = None
        view_default_36 = torch.ops.aten.view.default(primals_52, [1, 128, 512]);  primals_52 = None
        native_batch_norm_default_18 = torch.ops.aten.native_batch_norm.default(view_default_36, None, None, None, None, True, 0.0, 1e-08)
        getitem_104 = native_batch_norm_default_18[0]
        getitem_105 = native_batch_norm_default_18[1]
        getitem_106 = native_batch_norm_default_18[2];  native_batch_norm_default_18 = None
        view_default_37 = torch.ops.aten.view.default(getitem_104, [128, 512, 1, 1]);  getitem_104 = None
        convolution_default_18 = torch.ops.aten.convolution.default(relu__default_15, view_default_37, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_16 = torch.ops.aten.native_group_norm.default(convolution_default_18, primals_58, primals_57, 64, 128, 3136, 32, 1e-05);  primals_57 = None
        getitem_107 = native_group_norm_default_16[0]
        getitem_108 = native_group_norm_default_16[1]
        getitem_109 = native_group_norm_default_16[2];  native_group_norm_default_16 = None
        relu__default_16 = torch.ops.aten.relu_.default(getitem_107);  getitem_107 = None
        view_default_38 = torch.ops.aten.view.default(primals_53, [1, 128, 1152]);  primals_53 = None
        native_batch_norm_default_19 = torch.ops.aten.native_batch_norm.default(view_default_38, None, None, None, None, True, 0.0, 1e-08)
        getitem_110 = native_batch_norm_default_19[0]
        getitem_111 = native_batch_norm_default_19[1]
        getitem_112 = native_batch_norm_default_19[2];  native_batch_norm_default_19 = None
        view_default_39 = torch.ops.aten.view.default(getitem_110, [128, 128, 3, 3]);  getitem_110 = None
        convolution_default_19 = torch.ops.aten.convolution.default(relu__default_16, view_default_39, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_17 = torch.ops.aten.native_group_norm.default(convolution_default_19, primals_60, primals_59, 64, 128, 3136, 32, 1e-05);  primals_59 = None
        getitem_113 = native_group_norm_default_17[0]
        getitem_114 = native_group_norm_default_17[1]
        getitem_115 = native_group_norm_default_17[2];  native_group_norm_default_17 = None
        relu__default_17 = torch.ops.aten.relu_.default(getitem_113);  getitem_113 = None
        view_default_40 = torch.ops.aten.view.default(primals_54, [1, 512, 128]);  primals_54 = None
        native_batch_norm_default_20 = torch.ops.aten.native_batch_norm.default(view_default_40, None, None, None, None, True, 0.0, 1e-08)
        getitem_116 = native_batch_norm_default_20[0]
        getitem_117 = native_batch_norm_default_20[1]
        getitem_118 = native_batch_norm_default_20[2];  native_batch_norm_default_20 = None
        view_default_41 = torch.ops.aten.view.default(getitem_116, [512, 128, 1, 1]);  getitem_116 = None
        convolution_default_20 = torch.ops.aten.convolution.default(relu__default_17, view_default_41, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_5 = torch.ops.aten.add.Tensor(convolution_default_20, add_tensor_4);  convolution_default_20 = None
        native_group_norm_default_18 = torch.ops.aten.native_group_norm.default(add_tensor_5, primals_65, primals_64, 64, 512, 3136, 32, 1e-05);  primals_64 = None
        getitem_119 = native_group_norm_default_18[0]
        getitem_120 = native_group_norm_default_18[1]
        getitem_121 = native_group_norm_default_18[2];  native_group_norm_default_18 = None
        relu__default_18 = torch.ops.aten.relu_.default(getitem_119);  getitem_119 = None
        view_default_42 = torch.ops.aten.view.default(primals_61, [1, 128, 512]);  primals_61 = None
        native_batch_norm_default_21 = torch.ops.aten.native_batch_norm.default(view_default_42, None, None, None, None, True, 0.0, 1e-08)
        getitem_122 = native_batch_norm_default_21[0]
        getitem_123 = native_batch_norm_default_21[1]
        getitem_124 = native_batch_norm_default_21[2];  native_batch_norm_default_21 = None
        view_default_43 = torch.ops.aten.view.default(getitem_122, [128, 512, 1, 1]);  getitem_122 = None
        convolution_default_21 = torch.ops.aten.convolution.default(relu__default_18, view_default_43, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_19 = torch.ops.aten.native_group_norm.default(convolution_default_21, primals_67, primals_66, 64, 128, 3136, 32, 1e-05);  primals_66 = None
        getitem_125 = native_group_norm_default_19[0]
        getitem_126 = native_group_norm_default_19[1]
        getitem_127 = native_group_norm_default_19[2];  native_group_norm_default_19 = None
        relu__default_19 = torch.ops.aten.relu_.default(getitem_125);  getitem_125 = None
        view_default_44 = torch.ops.aten.view.default(primals_62, [1, 128, 1152]);  primals_62 = None
        native_batch_norm_default_22 = torch.ops.aten.native_batch_norm.default(view_default_44, None, None, None, None, True, 0.0, 1e-08)
        getitem_128 = native_batch_norm_default_22[0]
        getitem_129 = native_batch_norm_default_22[1]
        getitem_130 = native_batch_norm_default_22[2];  native_batch_norm_default_22 = None
        view_default_45 = torch.ops.aten.view.default(getitem_128, [128, 128, 3, 3]);  getitem_128 = None
        convolution_default_22 = torch.ops.aten.convolution.default(relu__default_19, view_default_45, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_20 = torch.ops.aten.native_group_norm.default(convolution_default_22, primals_69, primals_68, 64, 128, 3136, 32, 1e-05);  primals_68 = None
        getitem_131 = native_group_norm_default_20[0]
        getitem_132 = native_group_norm_default_20[1]
        getitem_133 = native_group_norm_default_20[2];  native_group_norm_default_20 = None
        relu__default_20 = torch.ops.aten.relu_.default(getitem_131);  getitem_131 = None
        view_default_46 = torch.ops.aten.view.default(primals_63, [1, 512, 128]);  primals_63 = None
        native_batch_norm_default_23 = torch.ops.aten.native_batch_norm.default(view_default_46, None, None, None, None, True, 0.0, 1e-08)
        getitem_134 = native_batch_norm_default_23[0]
        getitem_135 = native_batch_norm_default_23[1]
        getitem_136 = native_batch_norm_default_23[2];  native_batch_norm_default_23 = None
        view_default_47 = torch.ops.aten.view.default(getitem_134, [512, 128, 1, 1]);  getitem_134 = None
        convolution_default_23 = torch.ops.aten.convolution.default(relu__default_20, view_default_47, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_6 = torch.ops.aten.add.Tensor(convolution_default_23, add_tensor_5);  convolution_default_23 = None
        native_group_norm_default_21 = torch.ops.aten.native_group_norm.default(add_tensor_6, primals_75, primals_74, 64, 512, 3136, 32, 1e-05);  primals_74 = None
        getitem_137 = native_group_norm_default_21[0]
        getitem_138 = native_group_norm_default_21[1]
        getitem_139 = native_group_norm_default_21[2];  native_group_norm_default_21 = None
        relu__default_21 = torch.ops.aten.relu_.default(getitem_137);  getitem_137 = None
        view_default_48 = torch.ops.aten.view.default(primals_73, [1, 1024, 512]);  primals_73 = None
        native_batch_norm_default_24 = torch.ops.aten.native_batch_norm.default(view_default_48, None, None, None, None, True, 0.0, 1e-08)
        getitem_140 = native_batch_norm_default_24[0]
        getitem_141 = native_batch_norm_default_24[1]
        getitem_142 = native_batch_norm_default_24[2];  native_batch_norm_default_24 = None
        view_default_49 = torch.ops.aten.view.default(getitem_140, [1024, 512, 1, 1]);  getitem_140 = None
        convolution_default_24 = torch.ops.aten.convolution.default(relu__default_21, view_default_49, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_50 = torch.ops.aten.view.default(primals_70, [1, 256, 512]);  primals_70 = None
        native_batch_norm_default_25 = torch.ops.aten.native_batch_norm.default(view_default_50, None, None, None, None, True, 0.0, 1e-08)
        getitem_143 = native_batch_norm_default_25[0]
        getitem_144 = native_batch_norm_default_25[1]
        getitem_145 = native_batch_norm_default_25[2];  native_batch_norm_default_25 = None
        view_default_51 = torch.ops.aten.view.default(getitem_143, [256, 512, 1, 1]);  getitem_143 = None
        convolution_default_25 = torch.ops.aten.convolution.default(relu__default_21, view_default_51, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_22 = torch.ops.aten.native_group_norm.default(convolution_default_25, primals_77, primals_76, 64, 256, 3136, 32, 1e-05);  primals_76 = None
        getitem_146 = native_group_norm_default_22[0]
        getitem_147 = native_group_norm_default_22[1]
        getitem_148 = native_group_norm_default_22[2];  native_group_norm_default_22 = None
        relu__default_22 = torch.ops.aten.relu_.default(getitem_146);  getitem_146 = None
        view_default_52 = torch.ops.aten.view.default(primals_71, [1, 256, 2304]);  primals_71 = None
        native_batch_norm_default_26 = torch.ops.aten.native_batch_norm.default(view_default_52, None, None, None, None, True, 0.0, 1e-08)
        getitem_149 = native_batch_norm_default_26[0]
        getitem_150 = native_batch_norm_default_26[1]
        getitem_151 = native_batch_norm_default_26[2];  native_batch_norm_default_26 = None
        view_default_53 = torch.ops.aten.view.default(getitem_149, [256, 256, 3, 3]);  getitem_149 = None
        convolution_default_26 = torch.ops.aten.convolution.default(relu__default_22, view_default_53, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_23 = torch.ops.aten.native_group_norm.default(convolution_default_26, primals_79, primals_78, 64, 256, 784, 32, 1e-05);  primals_78 = None
        getitem_152 = native_group_norm_default_23[0]
        getitem_153 = native_group_norm_default_23[1]
        getitem_154 = native_group_norm_default_23[2];  native_group_norm_default_23 = None
        relu__default_23 = torch.ops.aten.relu_.default(getitem_152);  getitem_152 = None
        view_default_54 = torch.ops.aten.view.default(primals_72, [1, 1024, 256]);  primals_72 = None
        native_batch_norm_default_27 = torch.ops.aten.native_batch_norm.default(view_default_54, None, None, None, None, True, 0.0, 1e-08)
        getitem_155 = native_batch_norm_default_27[0]
        getitem_156 = native_batch_norm_default_27[1]
        getitem_157 = native_batch_norm_default_27[2];  native_batch_norm_default_27 = None
        view_default_55 = torch.ops.aten.view.default(getitem_155, [1024, 256, 1, 1]);  getitem_155 = None
        convolution_default_27 = torch.ops.aten.convolution.default(relu__default_23, view_default_55, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_7 = torch.ops.aten.add.Tensor(convolution_default_27, convolution_default_24);  convolution_default_27 = convolution_default_24 = None
        native_group_norm_default_24 = torch.ops.aten.native_group_norm.default(add_tensor_7, primals_174, primals_173, 64, 1024, 784, 32, 1e-05);  primals_173 = None
        getitem_158 = native_group_norm_default_24[0]
        getitem_159 = native_group_norm_default_24[1]
        getitem_160 = native_group_norm_default_24[2];  native_group_norm_default_24 = None
        relu__default_24 = torch.ops.aten.relu_.default(getitem_158);  getitem_158 = None
        view_default_56 = torch.ops.aten.view.default(primals_170, [1, 256, 1024]);  primals_170 = None
        native_batch_norm_default_28 = torch.ops.aten.native_batch_norm.default(view_default_56, None, None, None, None, True, 0.0, 1e-08)
        getitem_161 = native_batch_norm_default_28[0]
        getitem_162 = native_batch_norm_default_28[1]
        getitem_163 = native_batch_norm_default_28[2];  native_batch_norm_default_28 = None
        view_default_57 = torch.ops.aten.view.default(getitem_161, [256, 1024, 1, 1]);  getitem_161 = None
        convolution_default_28 = torch.ops.aten.convolution.default(relu__default_24, view_default_57, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_25 = torch.ops.aten.native_group_norm.default(convolution_default_28, primals_176, primals_175, 64, 256, 784, 32, 1e-05);  primals_175 = None
        getitem_164 = native_group_norm_default_25[0]
        getitem_165 = native_group_norm_default_25[1]
        getitem_166 = native_group_norm_default_25[2];  native_group_norm_default_25 = None
        relu__default_25 = torch.ops.aten.relu_.default(getitem_164);  getitem_164 = None
        view_default_58 = torch.ops.aten.view.default(primals_171, [1, 256, 2304]);  primals_171 = None
        native_batch_norm_default_29 = torch.ops.aten.native_batch_norm.default(view_default_58, None, None, None, None, True, 0.0, 1e-08)
        getitem_167 = native_batch_norm_default_29[0]
        getitem_168 = native_batch_norm_default_29[1]
        getitem_169 = native_batch_norm_default_29[2];  native_batch_norm_default_29 = None
        view_default_59 = torch.ops.aten.view.default(getitem_167, [256, 256, 3, 3]);  getitem_167 = None
        convolution_default_29 = torch.ops.aten.convolution.default(relu__default_25, view_default_59, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_26 = torch.ops.aten.native_group_norm.default(convolution_default_29, primals_178, primals_177, 64, 256, 784, 32, 1e-05);  primals_177 = None
        getitem_170 = native_group_norm_default_26[0]
        getitem_171 = native_group_norm_default_26[1]
        getitem_172 = native_group_norm_default_26[2];  native_group_norm_default_26 = None
        relu__default_26 = torch.ops.aten.relu_.default(getitem_170);  getitem_170 = None
        view_default_60 = torch.ops.aten.view.default(primals_172, [1, 1024, 256]);  primals_172 = None
        native_batch_norm_default_30 = torch.ops.aten.native_batch_norm.default(view_default_60, None, None, None, None, True, 0.0, 1e-08)
        getitem_173 = native_batch_norm_default_30[0]
        getitem_174 = native_batch_norm_default_30[1]
        getitem_175 = native_batch_norm_default_30[2];  native_batch_norm_default_30 = None
        view_default_61 = torch.ops.aten.view.default(getitem_173, [1024, 256, 1, 1]);  getitem_173 = None
        convolution_default_30 = torch.ops.aten.convolution.default(relu__default_26, view_default_61, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_8 = torch.ops.aten.add.Tensor(convolution_default_30, add_tensor_7);  convolution_default_30 = None
        native_group_norm_default_27 = torch.ops.aten.native_group_norm.default(add_tensor_8, primals_210, primals_209, 64, 1024, 784, 32, 1e-05);  primals_209 = None
        getitem_176 = native_group_norm_default_27[0]
        getitem_177 = native_group_norm_default_27[1]
        getitem_178 = native_group_norm_default_27[2];  native_group_norm_default_27 = None
        relu__default_27 = torch.ops.aten.relu_.default(getitem_176);  getitem_176 = None
        view_default_62 = torch.ops.aten.view.default(primals_206, [1, 256, 1024]);  primals_206 = None
        native_batch_norm_default_31 = torch.ops.aten.native_batch_norm.default(view_default_62, None, None, None, None, True, 0.0, 1e-08)
        getitem_179 = native_batch_norm_default_31[0]
        getitem_180 = native_batch_norm_default_31[1]
        getitem_181 = native_batch_norm_default_31[2];  native_batch_norm_default_31 = None
        view_default_63 = torch.ops.aten.view.default(getitem_179, [256, 1024, 1, 1]);  getitem_179 = None
        convolution_default_31 = torch.ops.aten.convolution.default(relu__default_27, view_default_63, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_28 = torch.ops.aten.native_group_norm.default(convolution_default_31, primals_212, primals_211, 64, 256, 784, 32, 1e-05);  primals_211 = None
        getitem_182 = native_group_norm_default_28[0]
        getitem_183 = native_group_norm_default_28[1]
        getitem_184 = native_group_norm_default_28[2];  native_group_norm_default_28 = None
        relu__default_28 = torch.ops.aten.relu_.default(getitem_182);  getitem_182 = None
        view_default_64 = torch.ops.aten.view.default(primals_207, [1, 256, 2304]);  primals_207 = None
        native_batch_norm_default_32 = torch.ops.aten.native_batch_norm.default(view_default_64, None, None, None, None, True, 0.0, 1e-08)
        getitem_185 = native_batch_norm_default_32[0]
        getitem_186 = native_batch_norm_default_32[1]
        getitem_187 = native_batch_norm_default_32[2];  native_batch_norm_default_32 = None
        view_default_65 = torch.ops.aten.view.default(getitem_185, [256, 256, 3, 3]);  getitem_185 = None
        convolution_default_32 = torch.ops.aten.convolution.default(relu__default_28, view_default_65, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_29 = torch.ops.aten.native_group_norm.default(convolution_default_32, primals_214, primals_213, 64, 256, 784, 32, 1e-05);  primals_213 = None
        getitem_188 = native_group_norm_default_29[0]
        getitem_189 = native_group_norm_default_29[1]
        getitem_190 = native_group_norm_default_29[2];  native_group_norm_default_29 = None
        relu__default_29 = torch.ops.aten.relu_.default(getitem_188);  getitem_188 = None
        view_default_66 = torch.ops.aten.view.default(primals_208, [1, 1024, 256]);  primals_208 = None
        native_batch_norm_default_33 = torch.ops.aten.native_batch_norm.default(view_default_66, None, None, None, None, True, 0.0, 1e-08)
        getitem_191 = native_batch_norm_default_33[0]
        getitem_192 = native_batch_norm_default_33[1]
        getitem_193 = native_batch_norm_default_33[2];  native_batch_norm_default_33 = None
        view_default_67 = torch.ops.aten.view.default(getitem_191, [1024, 256, 1, 1]);  getitem_191 = None
        convolution_default_33 = torch.ops.aten.convolution.default(relu__default_29, view_default_67, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_9 = torch.ops.aten.add.Tensor(convolution_default_33, add_tensor_8);  convolution_default_33 = None
        native_group_norm_default_30 = torch.ops.aten.native_group_norm.default(add_tensor_9, primals_219, primals_218, 64, 1024, 784, 32, 1e-05);  primals_218 = None
        getitem_194 = native_group_norm_default_30[0]
        getitem_195 = native_group_norm_default_30[1]
        getitem_196 = native_group_norm_default_30[2];  native_group_norm_default_30 = None
        relu__default_30 = torch.ops.aten.relu_.default(getitem_194);  getitem_194 = None
        view_default_68 = torch.ops.aten.view.default(primals_215, [1, 256, 1024]);  primals_215 = None
        native_batch_norm_default_34 = torch.ops.aten.native_batch_norm.default(view_default_68, None, None, None, None, True, 0.0, 1e-08)
        getitem_197 = native_batch_norm_default_34[0]
        getitem_198 = native_batch_norm_default_34[1]
        getitem_199 = native_batch_norm_default_34[2];  native_batch_norm_default_34 = None
        view_default_69 = torch.ops.aten.view.default(getitem_197, [256, 1024, 1, 1]);  getitem_197 = None
        convolution_default_34 = torch.ops.aten.convolution.default(relu__default_30, view_default_69, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_31 = torch.ops.aten.native_group_norm.default(convolution_default_34, primals_221, primals_220, 64, 256, 784, 32, 1e-05);  primals_220 = None
        getitem_200 = native_group_norm_default_31[0]
        getitem_201 = native_group_norm_default_31[1]
        getitem_202 = native_group_norm_default_31[2];  native_group_norm_default_31 = None
        relu__default_31 = torch.ops.aten.relu_.default(getitem_200);  getitem_200 = None
        view_default_70 = torch.ops.aten.view.default(primals_216, [1, 256, 2304]);  primals_216 = None
        native_batch_norm_default_35 = torch.ops.aten.native_batch_norm.default(view_default_70, None, None, None, None, True, 0.0, 1e-08)
        getitem_203 = native_batch_norm_default_35[0]
        getitem_204 = native_batch_norm_default_35[1]
        getitem_205 = native_batch_norm_default_35[2];  native_batch_norm_default_35 = None
        view_default_71 = torch.ops.aten.view.default(getitem_203, [256, 256, 3, 3]);  getitem_203 = None
        convolution_default_35 = torch.ops.aten.convolution.default(relu__default_31, view_default_71, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_32 = torch.ops.aten.native_group_norm.default(convolution_default_35, primals_223, primals_222, 64, 256, 784, 32, 1e-05);  primals_222 = None
        getitem_206 = native_group_norm_default_32[0]
        getitem_207 = native_group_norm_default_32[1]
        getitem_208 = native_group_norm_default_32[2];  native_group_norm_default_32 = None
        relu__default_32 = torch.ops.aten.relu_.default(getitem_206);  getitem_206 = None
        view_default_72 = torch.ops.aten.view.default(primals_217, [1, 1024, 256]);  primals_217 = None
        native_batch_norm_default_36 = torch.ops.aten.native_batch_norm.default(view_default_72, None, None, None, None, True, 0.0, 1e-08)
        getitem_209 = native_batch_norm_default_36[0]
        getitem_210 = native_batch_norm_default_36[1]
        getitem_211 = native_batch_norm_default_36[2];  native_batch_norm_default_36 = None
        view_default_73 = torch.ops.aten.view.default(getitem_209, [1024, 256, 1, 1]);  getitem_209 = None
        convolution_default_36 = torch.ops.aten.convolution.default(relu__default_32, view_default_73, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_10 = torch.ops.aten.add.Tensor(convolution_default_36, add_tensor_9);  convolution_default_36 = None
        native_group_norm_default_33 = torch.ops.aten.native_group_norm.default(add_tensor_10, primals_228, primals_227, 64, 1024, 784, 32, 1e-05);  primals_227 = None
        getitem_212 = native_group_norm_default_33[0]
        getitem_213 = native_group_norm_default_33[1]
        getitem_214 = native_group_norm_default_33[2];  native_group_norm_default_33 = None
        relu__default_33 = torch.ops.aten.relu_.default(getitem_212);  getitem_212 = None
        view_default_74 = torch.ops.aten.view.default(primals_224, [1, 256, 1024]);  primals_224 = None
        native_batch_norm_default_37 = torch.ops.aten.native_batch_norm.default(view_default_74, None, None, None, None, True, 0.0, 1e-08)
        getitem_215 = native_batch_norm_default_37[0]
        getitem_216 = native_batch_norm_default_37[1]
        getitem_217 = native_batch_norm_default_37[2];  native_batch_norm_default_37 = None
        view_default_75 = torch.ops.aten.view.default(getitem_215, [256, 1024, 1, 1]);  getitem_215 = None
        convolution_default_37 = torch.ops.aten.convolution.default(relu__default_33, view_default_75, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_34 = torch.ops.aten.native_group_norm.default(convolution_default_37, primals_230, primals_229, 64, 256, 784, 32, 1e-05);  primals_229 = None
        getitem_218 = native_group_norm_default_34[0]
        getitem_219 = native_group_norm_default_34[1]
        getitem_220 = native_group_norm_default_34[2];  native_group_norm_default_34 = None
        relu__default_34 = torch.ops.aten.relu_.default(getitem_218);  getitem_218 = None
        view_default_76 = torch.ops.aten.view.default(primals_225, [1, 256, 2304]);  primals_225 = None
        native_batch_norm_default_38 = torch.ops.aten.native_batch_norm.default(view_default_76, None, None, None, None, True, 0.0, 1e-08)
        getitem_221 = native_batch_norm_default_38[0]
        getitem_222 = native_batch_norm_default_38[1]
        getitem_223 = native_batch_norm_default_38[2];  native_batch_norm_default_38 = None
        view_default_77 = torch.ops.aten.view.default(getitem_221, [256, 256, 3, 3]);  getitem_221 = None
        convolution_default_38 = torch.ops.aten.convolution.default(relu__default_34, view_default_77, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_35 = torch.ops.aten.native_group_norm.default(convolution_default_38, primals_232, primals_231, 64, 256, 784, 32, 1e-05);  primals_231 = None
        getitem_224 = native_group_norm_default_35[0]
        getitem_225 = native_group_norm_default_35[1]
        getitem_226 = native_group_norm_default_35[2];  native_group_norm_default_35 = None
        relu__default_35 = torch.ops.aten.relu_.default(getitem_224);  getitem_224 = None
        view_default_78 = torch.ops.aten.view.default(primals_226, [1, 1024, 256]);  primals_226 = None
        native_batch_norm_default_39 = torch.ops.aten.native_batch_norm.default(view_default_78, None, None, None, None, True, 0.0, 1e-08)
        getitem_227 = native_batch_norm_default_39[0]
        getitem_228 = native_batch_norm_default_39[1]
        getitem_229 = native_batch_norm_default_39[2];  native_batch_norm_default_39 = None
        view_default_79 = torch.ops.aten.view.default(getitem_227, [1024, 256, 1, 1]);  getitem_227 = None
        convolution_default_39 = torch.ops.aten.convolution.default(relu__default_35, view_default_79, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_11 = torch.ops.aten.add.Tensor(convolution_default_39, add_tensor_10);  convolution_default_39 = None
        native_group_norm_default_36 = torch.ops.aten.native_group_norm.default(add_tensor_11, primals_237, primals_236, 64, 1024, 784, 32, 1e-05);  primals_236 = None
        getitem_230 = native_group_norm_default_36[0]
        getitem_231 = native_group_norm_default_36[1]
        getitem_232 = native_group_norm_default_36[2];  native_group_norm_default_36 = None
        relu__default_36 = torch.ops.aten.relu_.default(getitem_230);  getitem_230 = None
        view_default_80 = torch.ops.aten.view.default(primals_233, [1, 256, 1024]);  primals_233 = None
        native_batch_norm_default_40 = torch.ops.aten.native_batch_norm.default(view_default_80, None, None, None, None, True, 0.0, 1e-08)
        getitem_233 = native_batch_norm_default_40[0]
        getitem_234 = native_batch_norm_default_40[1]
        getitem_235 = native_batch_norm_default_40[2];  native_batch_norm_default_40 = None
        view_default_81 = torch.ops.aten.view.default(getitem_233, [256, 1024, 1, 1]);  getitem_233 = None
        convolution_default_40 = torch.ops.aten.convolution.default(relu__default_36, view_default_81, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_37 = torch.ops.aten.native_group_norm.default(convolution_default_40, primals_239, primals_238, 64, 256, 784, 32, 1e-05);  primals_238 = None
        getitem_236 = native_group_norm_default_37[0]
        getitem_237 = native_group_norm_default_37[1]
        getitem_238 = native_group_norm_default_37[2];  native_group_norm_default_37 = None
        relu__default_37 = torch.ops.aten.relu_.default(getitem_236);  getitem_236 = None
        view_default_82 = torch.ops.aten.view.default(primals_234, [1, 256, 2304]);  primals_234 = None
        native_batch_norm_default_41 = torch.ops.aten.native_batch_norm.default(view_default_82, None, None, None, None, True, 0.0, 1e-08)
        getitem_239 = native_batch_norm_default_41[0]
        getitem_240 = native_batch_norm_default_41[1]
        getitem_241 = native_batch_norm_default_41[2];  native_batch_norm_default_41 = None
        view_default_83 = torch.ops.aten.view.default(getitem_239, [256, 256, 3, 3]);  getitem_239 = None
        convolution_default_41 = torch.ops.aten.convolution.default(relu__default_37, view_default_83, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_38 = torch.ops.aten.native_group_norm.default(convolution_default_41, primals_241, primals_240, 64, 256, 784, 32, 1e-05);  primals_240 = None
        getitem_242 = native_group_norm_default_38[0]
        getitem_243 = native_group_norm_default_38[1]
        getitem_244 = native_group_norm_default_38[2];  native_group_norm_default_38 = None
        relu__default_38 = torch.ops.aten.relu_.default(getitem_242);  getitem_242 = None
        view_default_84 = torch.ops.aten.view.default(primals_235, [1, 1024, 256]);  primals_235 = None
        native_batch_norm_default_42 = torch.ops.aten.native_batch_norm.default(view_default_84, None, None, None, None, True, 0.0, 1e-08)
        getitem_245 = native_batch_norm_default_42[0]
        getitem_246 = native_batch_norm_default_42[1]
        getitem_247 = native_batch_norm_default_42[2];  native_batch_norm_default_42 = None
        view_default_85 = torch.ops.aten.view.default(getitem_245, [1024, 256, 1, 1]);  getitem_245 = None
        convolution_default_42 = torch.ops.aten.convolution.default(relu__default_38, view_default_85, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_12 = torch.ops.aten.add.Tensor(convolution_default_42, add_tensor_11);  convolution_default_42 = None
        native_group_norm_default_39 = torch.ops.aten.native_group_norm.default(add_tensor_12, primals_246, primals_245, 64, 1024, 784, 32, 1e-05);  primals_245 = None
        getitem_248 = native_group_norm_default_39[0]
        getitem_249 = native_group_norm_default_39[1]
        getitem_250 = native_group_norm_default_39[2];  native_group_norm_default_39 = None
        relu__default_39 = torch.ops.aten.relu_.default(getitem_248);  getitem_248 = None
        view_default_86 = torch.ops.aten.view.default(primals_242, [1, 256, 1024]);  primals_242 = None
        native_batch_norm_default_43 = torch.ops.aten.native_batch_norm.default(view_default_86, None, None, None, None, True, 0.0, 1e-08)
        getitem_251 = native_batch_norm_default_43[0]
        getitem_252 = native_batch_norm_default_43[1]
        getitem_253 = native_batch_norm_default_43[2];  native_batch_norm_default_43 = None
        view_default_87 = torch.ops.aten.view.default(getitem_251, [256, 1024, 1, 1]);  getitem_251 = None
        convolution_default_43 = torch.ops.aten.convolution.default(relu__default_39, view_default_87, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_40 = torch.ops.aten.native_group_norm.default(convolution_default_43, primals_248, primals_247, 64, 256, 784, 32, 1e-05);  primals_247 = None
        getitem_254 = native_group_norm_default_40[0]
        getitem_255 = native_group_norm_default_40[1]
        getitem_256 = native_group_norm_default_40[2];  native_group_norm_default_40 = None
        relu__default_40 = torch.ops.aten.relu_.default(getitem_254);  getitem_254 = None
        view_default_88 = torch.ops.aten.view.default(primals_243, [1, 256, 2304]);  primals_243 = None
        native_batch_norm_default_44 = torch.ops.aten.native_batch_norm.default(view_default_88, None, None, None, None, True, 0.0, 1e-08)
        getitem_257 = native_batch_norm_default_44[0]
        getitem_258 = native_batch_norm_default_44[1]
        getitem_259 = native_batch_norm_default_44[2];  native_batch_norm_default_44 = None
        view_default_89 = torch.ops.aten.view.default(getitem_257, [256, 256, 3, 3]);  getitem_257 = None
        convolution_default_44 = torch.ops.aten.convolution.default(relu__default_40, view_default_89, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_41 = torch.ops.aten.native_group_norm.default(convolution_default_44, primals_250, primals_249, 64, 256, 784, 32, 1e-05);  primals_249 = None
        getitem_260 = native_group_norm_default_41[0]
        getitem_261 = native_group_norm_default_41[1]
        getitem_262 = native_group_norm_default_41[2];  native_group_norm_default_41 = None
        relu__default_41 = torch.ops.aten.relu_.default(getitem_260);  getitem_260 = None
        view_default_90 = torch.ops.aten.view.default(primals_244, [1, 1024, 256]);  primals_244 = None
        native_batch_norm_default_45 = torch.ops.aten.native_batch_norm.default(view_default_90, None, None, None, None, True, 0.0, 1e-08)
        getitem_263 = native_batch_norm_default_45[0]
        getitem_264 = native_batch_norm_default_45[1]
        getitem_265 = native_batch_norm_default_45[2];  native_batch_norm_default_45 = None
        view_default_91 = torch.ops.aten.view.default(getitem_263, [1024, 256, 1, 1]);  getitem_263 = None
        convolution_default_45 = torch.ops.aten.convolution.default(relu__default_41, view_default_91, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_13 = torch.ops.aten.add.Tensor(convolution_default_45, add_tensor_12);  convolution_default_45 = None
        native_group_norm_default_42 = torch.ops.aten.native_group_norm.default(add_tensor_13, primals_255, primals_254, 64, 1024, 784, 32, 1e-05);  primals_254 = None
        getitem_266 = native_group_norm_default_42[0]
        getitem_267 = native_group_norm_default_42[1]
        getitem_268 = native_group_norm_default_42[2];  native_group_norm_default_42 = None
        relu__default_42 = torch.ops.aten.relu_.default(getitem_266);  getitem_266 = None
        view_default_92 = torch.ops.aten.view.default(primals_251, [1, 256, 1024]);  primals_251 = None
        native_batch_norm_default_46 = torch.ops.aten.native_batch_norm.default(view_default_92, None, None, None, None, True, 0.0, 1e-08)
        getitem_269 = native_batch_norm_default_46[0]
        getitem_270 = native_batch_norm_default_46[1]
        getitem_271 = native_batch_norm_default_46[2];  native_batch_norm_default_46 = None
        view_default_93 = torch.ops.aten.view.default(getitem_269, [256, 1024, 1, 1]);  getitem_269 = None
        convolution_default_46 = torch.ops.aten.convolution.default(relu__default_42, view_default_93, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_43 = torch.ops.aten.native_group_norm.default(convolution_default_46, primals_257, primals_256, 64, 256, 784, 32, 1e-05);  primals_256 = None
        getitem_272 = native_group_norm_default_43[0]
        getitem_273 = native_group_norm_default_43[1]
        getitem_274 = native_group_norm_default_43[2];  native_group_norm_default_43 = None
        relu__default_43 = torch.ops.aten.relu_.default(getitem_272);  getitem_272 = None
        view_default_94 = torch.ops.aten.view.default(primals_252, [1, 256, 2304]);  primals_252 = None
        native_batch_norm_default_47 = torch.ops.aten.native_batch_norm.default(view_default_94, None, None, None, None, True, 0.0, 1e-08)
        getitem_275 = native_batch_norm_default_47[0]
        getitem_276 = native_batch_norm_default_47[1]
        getitem_277 = native_batch_norm_default_47[2];  native_batch_norm_default_47 = None
        view_default_95 = torch.ops.aten.view.default(getitem_275, [256, 256, 3, 3]);  getitem_275 = None
        convolution_default_47 = torch.ops.aten.convolution.default(relu__default_43, view_default_95, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_44 = torch.ops.aten.native_group_norm.default(convolution_default_47, primals_259, primals_258, 64, 256, 784, 32, 1e-05);  primals_258 = None
        getitem_278 = native_group_norm_default_44[0]
        getitem_279 = native_group_norm_default_44[1]
        getitem_280 = native_group_norm_default_44[2];  native_group_norm_default_44 = None
        relu__default_44 = torch.ops.aten.relu_.default(getitem_278);  getitem_278 = None
        view_default_96 = torch.ops.aten.view.default(primals_253, [1, 1024, 256]);  primals_253 = None
        native_batch_norm_default_48 = torch.ops.aten.native_batch_norm.default(view_default_96, None, None, None, None, True, 0.0, 1e-08)
        getitem_281 = native_batch_norm_default_48[0]
        getitem_282 = native_batch_norm_default_48[1]
        getitem_283 = native_batch_norm_default_48[2];  native_batch_norm_default_48 = None
        view_default_97 = torch.ops.aten.view.default(getitem_281, [1024, 256, 1, 1]);  getitem_281 = None
        convolution_default_48 = torch.ops.aten.convolution.default(relu__default_44, view_default_97, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_14 = torch.ops.aten.add.Tensor(convolution_default_48, add_tensor_13);  convolution_default_48 = None
        native_group_norm_default_45 = torch.ops.aten.native_group_norm.default(add_tensor_14, primals_264, primals_263, 64, 1024, 784, 32, 1e-05);  primals_263 = None
        getitem_284 = native_group_norm_default_45[0]
        getitem_285 = native_group_norm_default_45[1]
        getitem_286 = native_group_norm_default_45[2];  native_group_norm_default_45 = None
        relu__default_45 = torch.ops.aten.relu_.default(getitem_284);  getitem_284 = None
        view_default_98 = torch.ops.aten.view.default(primals_260, [1, 256, 1024]);  primals_260 = None
        native_batch_norm_default_49 = torch.ops.aten.native_batch_norm.default(view_default_98, None, None, None, None, True, 0.0, 1e-08)
        getitem_287 = native_batch_norm_default_49[0]
        getitem_288 = native_batch_norm_default_49[1]
        getitem_289 = native_batch_norm_default_49[2];  native_batch_norm_default_49 = None
        view_default_99 = torch.ops.aten.view.default(getitem_287, [256, 1024, 1, 1]);  getitem_287 = None
        convolution_default_49 = torch.ops.aten.convolution.default(relu__default_45, view_default_99, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_46 = torch.ops.aten.native_group_norm.default(convolution_default_49, primals_266, primals_265, 64, 256, 784, 32, 1e-05);  primals_265 = None
        getitem_290 = native_group_norm_default_46[0]
        getitem_291 = native_group_norm_default_46[1]
        getitem_292 = native_group_norm_default_46[2];  native_group_norm_default_46 = None
        relu__default_46 = torch.ops.aten.relu_.default(getitem_290);  getitem_290 = None
        view_default_100 = torch.ops.aten.view.default(primals_261, [1, 256, 2304]);  primals_261 = None
        native_batch_norm_default_50 = torch.ops.aten.native_batch_norm.default(view_default_100, None, None, None, None, True, 0.0, 1e-08)
        getitem_293 = native_batch_norm_default_50[0]
        getitem_294 = native_batch_norm_default_50[1]
        getitem_295 = native_batch_norm_default_50[2];  native_batch_norm_default_50 = None
        view_default_101 = torch.ops.aten.view.default(getitem_293, [256, 256, 3, 3]);  getitem_293 = None
        convolution_default_50 = torch.ops.aten.convolution.default(relu__default_46, view_default_101, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_47 = torch.ops.aten.native_group_norm.default(convolution_default_50, primals_268, primals_267, 64, 256, 784, 32, 1e-05);  primals_267 = None
        getitem_296 = native_group_norm_default_47[0]
        getitem_297 = native_group_norm_default_47[1]
        getitem_298 = native_group_norm_default_47[2];  native_group_norm_default_47 = None
        relu__default_47 = torch.ops.aten.relu_.default(getitem_296);  getitem_296 = None
        view_default_102 = torch.ops.aten.view.default(primals_262, [1, 1024, 256]);  primals_262 = None
        native_batch_norm_default_51 = torch.ops.aten.native_batch_norm.default(view_default_102, None, None, None, None, True, 0.0, 1e-08)
        getitem_299 = native_batch_norm_default_51[0]
        getitem_300 = native_batch_norm_default_51[1]
        getitem_301 = native_batch_norm_default_51[2];  native_batch_norm_default_51 = None
        view_default_103 = torch.ops.aten.view.default(getitem_299, [1024, 256, 1, 1]);  getitem_299 = None
        convolution_default_51 = torch.ops.aten.convolution.default(relu__default_47, view_default_103, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_15 = torch.ops.aten.add.Tensor(convolution_default_51, add_tensor_14);  convolution_default_51 = None
        native_group_norm_default_48 = torch.ops.aten.native_group_norm.default(add_tensor_15, primals_273, primals_272, 64, 1024, 784, 32, 1e-05);  primals_272 = None
        getitem_302 = native_group_norm_default_48[0]
        getitem_303 = native_group_norm_default_48[1]
        getitem_304 = native_group_norm_default_48[2];  native_group_norm_default_48 = None
        relu__default_48 = torch.ops.aten.relu_.default(getitem_302);  getitem_302 = None
        view_default_104 = torch.ops.aten.view.default(primals_269, [1, 256, 1024]);  primals_269 = None
        native_batch_norm_default_52 = torch.ops.aten.native_batch_norm.default(view_default_104, None, None, None, None, True, 0.0, 1e-08)
        getitem_305 = native_batch_norm_default_52[0]
        getitem_306 = native_batch_norm_default_52[1]
        getitem_307 = native_batch_norm_default_52[2];  native_batch_norm_default_52 = None
        view_default_105 = torch.ops.aten.view.default(getitem_305, [256, 1024, 1, 1]);  getitem_305 = None
        convolution_default_52 = torch.ops.aten.convolution.default(relu__default_48, view_default_105, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_49 = torch.ops.aten.native_group_norm.default(convolution_default_52, primals_275, primals_274, 64, 256, 784, 32, 1e-05);  primals_274 = None
        getitem_308 = native_group_norm_default_49[0]
        getitem_309 = native_group_norm_default_49[1]
        getitem_310 = native_group_norm_default_49[2];  native_group_norm_default_49 = None
        relu__default_49 = torch.ops.aten.relu_.default(getitem_308);  getitem_308 = None
        view_default_106 = torch.ops.aten.view.default(primals_270, [1, 256, 2304]);  primals_270 = None
        native_batch_norm_default_53 = torch.ops.aten.native_batch_norm.default(view_default_106, None, None, None, None, True, 0.0, 1e-08)
        getitem_311 = native_batch_norm_default_53[0]
        getitem_312 = native_batch_norm_default_53[1]
        getitem_313 = native_batch_norm_default_53[2];  native_batch_norm_default_53 = None
        view_default_107 = torch.ops.aten.view.default(getitem_311, [256, 256, 3, 3]);  getitem_311 = None
        convolution_default_53 = torch.ops.aten.convolution.default(relu__default_49, view_default_107, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_50 = torch.ops.aten.native_group_norm.default(convolution_default_53, primals_277, primals_276, 64, 256, 784, 32, 1e-05);  primals_276 = None
        getitem_314 = native_group_norm_default_50[0]
        getitem_315 = native_group_norm_default_50[1]
        getitem_316 = native_group_norm_default_50[2];  native_group_norm_default_50 = None
        relu__default_50 = torch.ops.aten.relu_.default(getitem_314);  getitem_314 = None
        view_default_108 = torch.ops.aten.view.default(primals_271, [1, 1024, 256]);  primals_271 = None
        native_batch_norm_default_54 = torch.ops.aten.native_batch_norm.default(view_default_108, None, None, None, None, True, 0.0, 1e-08)
        getitem_317 = native_batch_norm_default_54[0]
        getitem_318 = native_batch_norm_default_54[1]
        getitem_319 = native_batch_norm_default_54[2];  native_batch_norm_default_54 = None
        view_default_109 = torch.ops.aten.view.default(getitem_317, [1024, 256, 1, 1]);  getitem_317 = None
        convolution_default_54 = torch.ops.aten.convolution.default(relu__default_50, view_default_109, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_16 = torch.ops.aten.add.Tensor(convolution_default_54, add_tensor_15);  convolution_default_54 = None
        native_group_norm_default_51 = torch.ops.aten.native_group_norm.default(add_tensor_16, primals_84, primals_83, 64, 1024, 784, 32, 1e-05);  primals_83 = None
        getitem_320 = native_group_norm_default_51[0]
        getitem_321 = native_group_norm_default_51[1]
        getitem_322 = native_group_norm_default_51[2];  native_group_norm_default_51 = None
        relu__default_51 = torch.ops.aten.relu_.default(getitem_320);  getitem_320 = None
        view_default_110 = torch.ops.aten.view.default(primals_80, [1, 256, 1024]);  primals_80 = None
        native_batch_norm_default_55 = torch.ops.aten.native_batch_norm.default(view_default_110, None, None, None, None, True, 0.0, 1e-08)
        getitem_323 = native_batch_norm_default_55[0]
        getitem_324 = native_batch_norm_default_55[1]
        getitem_325 = native_batch_norm_default_55[2];  native_batch_norm_default_55 = None
        view_default_111 = torch.ops.aten.view.default(getitem_323, [256, 1024, 1, 1]);  getitem_323 = None
        convolution_default_55 = torch.ops.aten.convolution.default(relu__default_51, view_default_111, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_52 = torch.ops.aten.native_group_norm.default(convolution_default_55, primals_86, primals_85, 64, 256, 784, 32, 1e-05);  primals_85 = None
        getitem_326 = native_group_norm_default_52[0]
        getitem_327 = native_group_norm_default_52[1]
        getitem_328 = native_group_norm_default_52[2];  native_group_norm_default_52 = None
        relu__default_52 = torch.ops.aten.relu_.default(getitem_326);  getitem_326 = None
        view_default_112 = torch.ops.aten.view.default(primals_81, [1, 256, 2304]);  primals_81 = None
        native_batch_norm_default_56 = torch.ops.aten.native_batch_norm.default(view_default_112, None, None, None, None, True, 0.0, 1e-08)
        getitem_329 = native_batch_norm_default_56[0]
        getitem_330 = native_batch_norm_default_56[1]
        getitem_331 = native_batch_norm_default_56[2];  native_batch_norm_default_56 = None
        view_default_113 = torch.ops.aten.view.default(getitem_329, [256, 256, 3, 3]);  getitem_329 = None
        convolution_default_56 = torch.ops.aten.convolution.default(relu__default_52, view_default_113, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_53 = torch.ops.aten.native_group_norm.default(convolution_default_56, primals_88, primals_87, 64, 256, 784, 32, 1e-05);  primals_87 = None
        getitem_332 = native_group_norm_default_53[0]
        getitem_333 = native_group_norm_default_53[1]
        getitem_334 = native_group_norm_default_53[2];  native_group_norm_default_53 = None
        relu__default_53 = torch.ops.aten.relu_.default(getitem_332);  getitem_332 = None
        view_default_114 = torch.ops.aten.view.default(primals_82, [1, 1024, 256]);  primals_82 = None
        native_batch_norm_default_57 = torch.ops.aten.native_batch_norm.default(view_default_114, None, None, None, None, True, 0.0, 1e-08)
        getitem_335 = native_batch_norm_default_57[0]
        getitem_336 = native_batch_norm_default_57[1]
        getitem_337 = native_batch_norm_default_57[2];  native_batch_norm_default_57 = None
        view_default_115 = torch.ops.aten.view.default(getitem_335, [1024, 256, 1, 1]);  getitem_335 = None
        convolution_default_57 = torch.ops.aten.convolution.default(relu__default_53, view_default_115, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_17 = torch.ops.aten.add.Tensor(convolution_default_57, add_tensor_16);  convolution_default_57 = None
        native_group_norm_default_54 = torch.ops.aten.native_group_norm.default(add_tensor_17, primals_93, primals_92, 64, 1024, 784, 32, 1e-05);  primals_92 = None
        getitem_338 = native_group_norm_default_54[0]
        getitem_339 = native_group_norm_default_54[1]
        getitem_340 = native_group_norm_default_54[2];  native_group_norm_default_54 = None
        relu__default_54 = torch.ops.aten.relu_.default(getitem_338);  getitem_338 = None
        view_default_116 = torch.ops.aten.view.default(primals_89, [1, 256, 1024]);  primals_89 = None
        native_batch_norm_default_58 = torch.ops.aten.native_batch_norm.default(view_default_116, None, None, None, None, True, 0.0, 1e-08)
        getitem_341 = native_batch_norm_default_58[0]
        getitem_342 = native_batch_norm_default_58[1]
        getitem_343 = native_batch_norm_default_58[2];  native_batch_norm_default_58 = None
        view_default_117 = torch.ops.aten.view.default(getitem_341, [256, 1024, 1, 1]);  getitem_341 = None
        convolution_default_58 = torch.ops.aten.convolution.default(relu__default_54, view_default_117, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_55 = torch.ops.aten.native_group_norm.default(convolution_default_58, primals_95, primals_94, 64, 256, 784, 32, 1e-05);  primals_94 = None
        getitem_344 = native_group_norm_default_55[0]
        getitem_345 = native_group_norm_default_55[1]
        getitem_346 = native_group_norm_default_55[2];  native_group_norm_default_55 = None
        relu__default_55 = torch.ops.aten.relu_.default(getitem_344);  getitem_344 = None
        view_default_118 = torch.ops.aten.view.default(primals_90, [1, 256, 2304]);  primals_90 = None
        native_batch_norm_default_59 = torch.ops.aten.native_batch_norm.default(view_default_118, None, None, None, None, True, 0.0, 1e-08)
        getitem_347 = native_batch_norm_default_59[0]
        getitem_348 = native_batch_norm_default_59[1]
        getitem_349 = native_batch_norm_default_59[2];  native_batch_norm_default_59 = None
        view_default_119 = torch.ops.aten.view.default(getitem_347, [256, 256, 3, 3]);  getitem_347 = None
        convolution_default_59 = torch.ops.aten.convolution.default(relu__default_55, view_default_119, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_56 = torch.ops.aten.native_group_norm.default(convolution_default_59, primals_97, primals_96, 64, 256, 784, 32, 1e-05);  primals_96 = None
        getitem_350 = native_group_norm_default_56[0]
        getitem_351 = native_group_norm_default_56[1]
        getitem_352 = native_group_norm_default_56[2];  native_group_norm_default_56 = None
        relu__default_56 = torch.ops.aten.relu_.default(getitem_350);  getitem_350 = None
        view_default_120 = torch.ops.aten.view.default(primals_91, [1, 1024, 256]);  primals_91 = None
        native_batch_norm_default_60 = torch.ops.aten.native_batch_norm.default(view_default_120, None, None, None, None, True, 0.0, 1e-08)
        getitem_353 = native_batch_norm_default_60[0]
        getitem_354 = native_batch_norm_default_60[1]
        getitem_355 = native_batch_norm_default_60[2];  native_batch_norm_default_60 = None
        view_default_121 = torch.ops.aten.view.default(getitem_353, [1024, 256, 1, 1]);  getitem_353 = None
        convolution_default_60 = torch.ops.aten.convolution.default(relu__default_56, view_default_121, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_18 = torch.ops.aten.add.Tensor(convolution_default_60, add_tensor_17);  convolution_default_60 = None
        native_group_norm_default_57 = torch.ops.aten.native_group_norm.default(add_tensor_18, primals_102, primals_101, 64, 1024, 784, 32, 1e-05);  primals_101 = None
        getitem_356 = native_group_norm_default_57[0]
        getitem_357 = native_group_norm_default_57[1]
        getitem_358 = native_group_norm_default_57[2];  native_group_norm_default_57 = None
        relu__default_57 = torch.ops.aten.relu_.default(getitem_356);  getitem_356 = None
        view_default_122 = torch.ops.aten.view.default(primals_98, [1, 256, 1024]);  primals_98 = None
        native_batch_norm_default_61 = torch.ops.aten.native_batch_norm.default(view_default_122, None, None, None, None, True, 0.0, 1e-08)
        getitem_359 = native_batch_norm_default_61[0]
        getitem_360 = native_batch_norm_default_61[1]
        getitem_361 = native_batch_norm_default_61[2];  native_batch_norm_default_61 = None
        view_default_123 = torch.ops.aten.view.default(getitem_359, [256, 1024, 1, 1]);  getitem_359 = None
        convolution_default_61 = torch.ops.aten.convolution.default(relu__default_57, view_default_123, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_58 = torch.ops.aten.native_group_norm.default(convolution_default_61, primals_104, primals_103, 64, 256, 784, 32, 1e-05);  primals_103 = None
        getitem_362 = native_group_norm_default_58[0]
        getitem_363 = native_group_norm_default_58[1]
        getitem_364 = native_group_norm_default_58[2];  native_group_norm_default_58 = None
        relu__default_58 = torch.ops.aten.relu_.default(getitem_362);  getitem_362 = None
        view_default_124 = torch.ops.aten.view.default(primals_99, [1, 256, 2304]);  primals_99 = None
        native_batch_norm_default_62 = torch.ops.aten.native_batch_norm.default(view_default_124, None, None, None, None, True, 0.0, 1e-08)
        getitem_365 = native_batch_norm_default_62[0]
        getitem_366 = native_batch_norm_default_62[1]
        getitem_367 = native_batch_norm_default_62[2];  native_batch_norm_default_62 = None
        view_default_125 = torch.ops.aten.view.default(getitem_365, [256, 256, 3, 3]);  getitem_365 = None
        convolution_default_62 = torch.ops.aten.convolution.default(relu__default_58, view_default_125, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_59 = torch.ops.aten.native_group_norm.default(convolution_default_62, primals_106, primals_105, 64, 256, 784, 32, 1e-05);  primals_105 = None
        getitem_368 = native_group_norm_default_59[0]
        getitem_369 = native_group_norm_default_59[1]
        getitem_370 = native_group_norm_default_59[2];  native_group_norm_default_59 = None
        relu__default_59 = torch.ops.aten.relu_.default(getitem_368);  getitem_368 = None
        view_default_126 = torch.ops.aten.view.default(primals_100, [1, 1024, 256]);  primals_100 = None
        native_batch_norm_default_63 = torch.ops.aten.native_batch_norm.default(view_default_126, None, None, None, None, True, 0.0, 1e-08)
        getitem_371 = native_batch_norm_default_63[0]
        getitem_372 = native_batch_norm_default_63[1]
        getitem_373 = native_batch_norm_default_63[2];  native_batch_norm_default_63 = None
        view_default_127 = torch.ops.aten.view.default(getitem_371, [1024, 256, 1, 1]);  getitem_371 = None
        convolution_default_63 = torch.ops.aten.convolution.default(relu__default_59, view_default_127, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_19 = torch.ops.aten.add.Tensor(convolution_default_63, add_tensor_18);  convolution_default_63 = None
        native_group_norm_default_60 = torch.ops.aten.native_group_norm.default(add_tensor_19, primals_111, primals_110, 64, 1024, 784, 32, 1e-05);  primals_110 = None
        getitem_374 = native_group_norm_default_60[0]
        getitem_375 = native_group_norm_default_60[1]
        getitem_376 = native_group_norm_default_60[2];  native_group_norm_default_60 = None
        relu__default_60 = torch.ops.aten.relu_.default(getitem_374);  getitem_374 = None
        view_default_128 = torch.ops.aten.view.default(primals_107, [1, 256, 1024]);  primals_107 = None
        native_batch_norm_default_64 = torch.ops.aten.native_batch_norm.default(view_default_128, None, None, None, None, True, 0.0, 1e-08)
        getitem_377 = native_batch_norm_default_64[0]
        getitem_378 = native_batch_norm_default_64[1]
        getitem_379 = native_batch_norm_default_64[2];  native_batch_norm_default_64 = None
        view_default_129 = torch.ops.aten.view.default(getitem_377, [256, 1024, 1, 1]);  getitem_377 = None
        convolution_default_64 = torch.ops.aten.convolution.default(relu__default_60, view_default_129, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_61 = torch.ops.aten.native_group_norm.default(convolution_default_64, primals_113, primals_112, 64, 256, 784, 32, 1e-05);  primals_112 = None
        getitem_380 = native_group_norm_default_61[0]
        getitem_381 = native_group_norm_default_61[1]
        getitem_382 = native_group_norm_default_61[2];  native_group_norm_default_61 = None
        relu__default_61 = torch.ops.aten.relu_.default(getitem_380);  getitem_380 = None
        view_default_130 = torch.ops.aten.view.default(primals_108, [1, 256, 2304]);  primals_108 = None
        native_batch_norm_default_65 = torch.ops.aten.native_batch_norm.default(view_default_130, None, None, None, None, True, 0.0, 1e-08)
        getitem_383 = native_batch_norm_default_65[0]
        getitem_384 = native_batch_norm_default_65[1]
        getitem_385 = native_batch_norm_default_65[2];  native_batch_norm_default_65 = None
        view_default_131 = torch.ops.aten.view.default(getitem_383, [256, 256, 3, 3]);  getitem_383 = None
        convolution_default_65 = torch.ops.aten.convolution.default(relu__default_61, view_default_131, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_62 = torch.ops.aten.native_group_norm.default(convolution_default_65, primals_115, primals_114, 64, 256, 784, 32, 1e-05);  primals_114 = None
        getitem_386 = native_group_norm_default_62[0]
        getitem_387 = native_group_norm_default_62[1]
        getitem_388 = native_group_norm_default_62[2];  native_group_norm_default_62 = None
        relu__default_62 = torch.ops.aten.relu_.default(getitem_386);  getitem_386 = None
        view_default_132 = torch.ops.aten.view.default(primals_109, [1, 1024, 256]);  primals_109 = None
        native_batch_norm_default_66 = torch.ops.aten.native_batch_norm.default(view_default_132, None, None, None, None, True, 0.0, 1e-08)
        getitem_389 = native_batch_norm_default_66[0]
        getitem_390 = native_batch_norm_default_66[1]
        getitem_391 = native_batch_norm_default_66[2];  native_batch_norm_default_66 = None
        view_default_133 = torch.ops.aten.view.default(getitem_389, [1024, 256, 1, 1]);  getitem_389 = None
        convolution_default_66 = torch.ops.aten.convolution.default(relu__default_62, view_default_133, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_20 = torch.ops.aten.add.Tensor(convolution_default_66, add_tensor_19);  convolution_default_66 = None
        native_group_norm_default_63 = torch.ops.aten.native_group_norm.default(add_tensor_20, primals_120, primals_119, 64, 1024, 784, 32, 1e-05);  primals_119 = None
        getitem_392 = native_group_norm_default_63[0]
        getitem_393 = native_group_norm_default_63[1]
        getitem_394 = native_group_norm_default_63[2];  native_group_norm_default_63 = None
        relu__default_63 = torch.ops.aten.relu_.default(getitem_392);  getitem_392 = None
        view_default_134 = torch.ops.aten.view.default(primals_116, [1, 256, 1024]);  primals_116 = None
        native_batch_norm_default_67 = torch.ops.aten.native_batch_norm.default(view_default_134, None, None, None, None, True, 0.0, 1e-08)
        getitem_395 = native_batch_norm_default_67[0]
        getitem_396 = native_batch_norm_default_67[1]
        getitem_397 = native_batch_norm_default_67[2];  native_batch_norm_default_67 = None
        view_default_135 = torch.ops.aten.view.default(getitem_395, [256, 1024, 1, 1]);  getitem_395 = None
        convolution_default_67 = torch.ops.aten.convolution.default(relu__default_63, view_default_135, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_64 = torch.ops.aten.native_group_norm.default(convolution_default_67, primals_122, primals_121, 64, 256, 784, 32, 1e-05);  primals_121 = None
        getitem_398 = native_group_norm_default_64[0]
        getitem_399 = native_group_norm_default_64[1]
        getitem_400 = native_group_norm_default_64[2];  native_group_norm_default_64 = None
        relu__default_64 = torch.ops.aten.relu_.default(getitem_398);  getitem_398 = None
        view_default_136 = torch.ops.aten.view.default(primals_117, [1, 256, 2304]);  primals_117 = None
        native_batch_norm_default_68 = torch.ops.aten.native_batch_norm.default(view_default_136, None, None, None, None, True, 0.0, 1e-08)
        getitem_401 = native_batch_norm_default_68[0]
        getitem_402 = native_batch_norm_default_68[1]
        getitem_403 = native_batch_norm_default_68[2];  native_batch_norm_default_68 = None
        view_default_137 = torch.ops.aten.view.default(getitem_401, [256, 256, 3, 3]);  getitem_401 = None
        convolution_default_68 = torch.ops.aten.convolution.default(relu__default_64, view_default_137, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_65 = torch.ops.aten.native_group_norm.default(convolution_default_68, primals_124, primals_123, 64, 256, 784, 32, 1e-05);  primals_123 = None
        getitem_404 = native_group_norm_default_65[0]
        getitem_405 = native_group_norm_default_65[1]
        getitem_406 = native_group_norm_default_65[2];  native_group_norm_default_65 = None
        relu__default_65 = torch.ops.aten.relu_.default(getitem_404);  getitem_404 = None
        view_default_138 = torch.ops.aten.view.default(primals_118, [1, 1024, 256]);  primals_118 = None
        native_batch_norm_default_69 = torch.ops.aten.native_batch_norm.default(view_default_138, None, None, None, None, True, 0.0, 1e-08)
        getitem_407 = native_batch_norm_default_69[0]
        getitem_408 = native_batch_norm_default_69[1]
        getitem_409 = native_batch_norm_default_69[2];  native_batch_norm_default_69 = None
        view_default_139 = torch.ops.aten.view.default(getitem_407, [1024, 256, 1, 1]);  getitem_407 = None
        convolution_default_69 = torch.ops.aten.convolution.default(relu__default_65, view_default_139, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_21 = torch.ops.aten.add.Tensor(convolution_default_69, add_tensor_20);  convolution_default_69 = None
        native_group_norm_default_66 = torch.ops.aten.native_group_norm.default(add_tensor_21, primals_129, primals_128, 64, 1024, 784, 32, 1e-05);  primals_128 = None
        getitem_410 = native_group_norm_default_66[0]
        getitem_411 = native_group_norm_default_66[1]
        getitem_412 = native_group_norm_default_66[2];  native_group_norm_default_66 = None
        relu__default_66 = torch.ops.aten.relu_.default(getitem_410);  getitem_410 = None
        view_default_140 = torch.ops.aten.view.default(primals_125, [1, 256, 1024]);  primals_125 = None
        native_batch_norm_default_70 = torch.ops.aten.native_batch_norm.default(view_default_140, None, None, None, None, True, 0.0, 1e-08)
        getitem_413 = native_batch_norm_default_70[0]
        getitem_414 = native_batch_norm_default_70[1]
        getitem_415 = native_batch_norm_default_70[2];  native_batch_norm_default_70 = None
        view_default_141 = torch.ops.aten.view.default(getitem_413, [256, 1024, 1, 1]);  getitem_413 = None
        convolution_default_70 = torch.ops.aten.convolution.default(relu__default_66, view_default_141, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_67 = torch.ops.aten.native_group_norm.default(convolution_default_70, primals_131, primals_130, 64, 256, 784, 32, 1e-05);  primals_130 = None
        getitem_416 = native_group_norm_default_67[0]
        getitem_417 = native_group_norm_default_67[1]
        getitem_418 = native_group_norm_default_67[2];  native_group_norm_default_67 = None
        relu__default_67 = torch.ops.aten.relu_.default(getitem_416);  getitem_416 = None
        view_default_142 = torch.ops.aten.view.default(primals_126, [1, 256, 2304]);  primals_126 = None
        native_batch_norm_default_71 = torch.ops.aten.native_batch_norm.default(view_default_142, None, None, None, None, True, 0.0, 1e-08)
        getitem_419 = native_batch_norm_default_71[0]
        getitem_420 = native_batch_norm_default_71[1]
        getitem_421 = native_batch_norm_default_71[2];  native_batch_norm_default_71 = None
        view_default_143 = torch.ops.aten.view.default(getitem_419, [256, 256, 3, 3]);  getitem_419 = None
        convolution_default_71 = torch.ops.aten.convolution.default(relu__default_67, view_default_143, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_68 = torch.ops.aten.native_group_norm.default(convolution_default_71, primals_133, primals_132, 64, 256, 784, 32, 1e-05);  primals_132 = None
        getitem_422 = native_group_norm_default_68[0]
        getitem_423 = native_group_norm_default_68[1]
        getitem_424 = native_group_norm_default_68[2];  native_group_norm_default_68 = None
        relu__default_68 = torch.ops.aten.relu_.default(getitem_422);  getitem_422 = None
        view_default_144 = torch.ops.aten.view.default(primals_127, [1, 1024, 256]);  primals_127 = None
        native_batch_norm_default_72 = torch.ops.aten.native_batch_norm.default(view_default_144, None, None, None, None, True, 0.0, 1e-08)
        getitem_425 = native_batch_norm_default_72[0]
        getitem_426 = native_batch_norm_default_72[1]
        getitem_427 = native_batch_norm_default_72[2];  native_batch_norm_default_72 = None
        view_default_145 = torch.ops.aten.view.default(getitem_425, [1024, 256, 1, 1]);  getitem_425 = None
        convolution_default_72 = torch.ops.aten.convolution.default(relu__default_68, view_default_145, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_22 = torch.ops.aten.add.Tensor(convolution_default_72, add_tensor_21);  convolution_default_72 = None
        native_group_norm_default_69 = torch.ops.aten.native_group_norm.default(add_tensor_22, primals_138, primals_137, 64, 1024, 784, 32, 1e-05);  primals_137 = None
        getitem_428 = native_group_norm_default_69[0]
        getitem_429 = native_group_norm_default_69[1]
        getitem_430 = native_group_norm_default_69[2];  native_group_norm_default_69 = None
        relu__default_69 = torch.ops.aten.relu_.default(getitem_428);  getitem_428 = None
        view_default_146 = torch.ops.aten.view.default(primals_134, [1, 256, 1024]);  primals_134 = None
        native_batch_norm_default_73 = torch.ops.aten.native_batch_norm.default(view_default_146, None, None, None, None, True, 0.0, 1e-08)
        getitem_431 = native_batch_norm_default_73[0]
        getitem_432 = native_batch_norm_default_73[1]
        getitem_433 = native_batch_norm_default_73[2];  native_batch_norm_default_73 = None
        view_default_147 = torch.ops.aten.view.default(getitem_431, [256, 1024, 1, 1]);  getitem_431 = None
        convolution_default_73 = torch.ops.aten.convolution.default(relu__default_69, view_default_147, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_70 = torch.ops.aten.native_group_norm.default(convolution_default_73, primals_140, primals_139, 64, 256, 784, 32, 1e-05);  primals_139 = None
        getitem_434 = native_group_norm_default_70[0]
        getitem_435 = native_group_norm_default_70[1]
        getitem_436 = native_group_norm_default_70[2];  native_group_norm_default_70 = None
        relu__default_70 = torch.ops.aten.relu_.default(getitem_434);  getitem_434 = None
        view_default_148 = torch.ops.aten.view.default(primals_135, [1, 256, 2304]);  primals_135 = None
        native_batch_norm_default_74 = torch.ops.aten.native_batch_norm.default(view_default_148, None, None, None, None, True, 0.0, 1e-08)
        getitem_437 = native_batch_norm_default_74[0]
        getitem_438 = native_batch_norm_default_74[1]
        getitem_439 = native_batch_norm_default_74[2];  native_batch_norm_default_74 = None
        view_default_149 = torch.ops.aten.view.default(getitem_437, [256, 256, 3, 3]);  getitem_437 = None
        convolution_default_74 = torch.ops.aten.convolution.default(relu__default_70, view_default_149, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_71 = torch.ops.aten.native_group_norm.default(convolution_default_74, primals_142, primals_141, 64, 256, 784, 32, 1e-05);  primals_141 = None
        getitem_440 = native_group_norm_default_71[0]
        getitem_441 = native_group_norm_default_71[1]
        getitem_442 = native_group_norm_default_71[2];  native_group_norm_default_71 = None
        relu__default_71 = torch.ops.aten.relu_.default(getitem_440);  getitem_440 = None
        view_default_150 = torch.ops.aten.view.default(primals_136, [1, 1024, 256]);  primals_136 = None
        native_batch_norm_default_75 = torch.ops.aten.native_batch_norm.default(view_default_150, None, None, None, None, True, 0.0, 1e-08)
        getitem_443 = native_batch_norm_default_75[0]
        getitem_444 = native_batch_norm_default_75[1]
        getitem_445 = native_batch_norm_default_75[2];  native_batch_norm_default_75 = None
        view_default_151 = torch.ops.aten.view.default(getitem_443, [1024, 256, 1, 1]);  getitem_443 = None
        convolution_default_75 = torch.ops.aten.convolution.default(relu__default_71, view_default_151, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_23 = torch.ops.aten.add.Tensor(convolution_default_75, add_tensor_22);  convolution_default_75 = None
        native_group_norm_default_72 = torch.ops.aten.native_group_norm.default(add_tensor_23, primals_147, primals_146, 64, 1024, 784, 32, 1e-05);  primals_146 = None
        getitem_446 = native_group_norm_default_72[0]
        getitem_447 = native_group_norm_default_72[1]
        getitem_448 = native_group_norm_default_72[2];  native_group_norm_default_72 = None
        relu__default_72 = torch.ops.aten.relu_.default(getitem_446);  getitem_446 = None
        view_default_152 = torch.ops.aten.view.default(primals_143, [1, 256, 1024]);  primals_143 = None
        native_batch_norm_default_76 = torch.ops.aten.native_batch_norm.default(view_default_152, None, None, None, None, True, 0.0, 1e-08)
        getitem_449 = native_batch_norm_default_76[0]
        getitem_450 = native_batch_norm_default_76[1]
        getitem_451 = native_batch_norm_default_76[2];  native_batch_norm_default_76 = None
        view_default_153 = torch.ops.aten.view.default(getitem_449, [256, 1024, 1, 1]);  getitem_449 = None
        convolution_default_76 = torch.ops.aten.convolution.default(relu__default_72, view_default_153, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_73 = torch.ops.aten.native_group_norm.default(convolution_default_76, primals_149, primals_148, 64, 256, 784, 32, 1e-05);  primals_148 = None
        getitem_452 = native_group_norm_default_73[0]
        getitem_453 = native_group_norm_default_73[1]
        getitem_454 = native_group_norm_default_73[2];  native_group_norm_default_73 = None
        relu__default_73 = torch.ops.aten.relu_.default(getitem_452);  getitem_452 = None
        view_default_154 = torch.ops.aten.view.default(primals_144, [1, 256, 2304]);  primals_144 = None
        native_batch_norm_default_77 = torch.ops.aten.native_batch_norm.default(view_default_154, None, None, None, None, True, 0.0, 1e-08)
        getitem_455 = native_batch_norm_default_77[0]
        getitem_456 = native_batch_norm_default_77[1]
        getitem_457 = native_batch_norm_default_77[2];  native_batch_norm_default_77 = None
        view_default_155 = torch.ops.aten.view.default(getitem_455, [256, 256, 3, 3]);  getitem_455 = None
        convolution_default_77 = torch.ops.aten.convolution.default(relu__default_73, view_default_155, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_74 = torch.ops.aten.native_group_norm.default(convolution_default_77, primals_151, primals_150, 64, 256, 784, 32, 1e-05);  primals_150 = None
        getitem_458 = native_group_norm_default_74[0]
        getitem_459 = native_group_norm_default_74[1]
        getitem_460 = native_group_norm_default_74[2];  native_group_norm_default_74 = None
        relu__default_74 = torch.ops.aten.relu_.default(getitem_458);  getitem_458 = None
        view_default_156 = torch.ops.aten.view.default(primals_145, [1, 1024, 256]);  primals_145 = None
        native_batch_norm_default_78 = torch.ops.aten.native_batch_norm.default(view_default_156, None, None, None, None, True, 0.0, 1e-08)
        getitem_461 = native_batch_norm_default_78[0]
        getitem_462 = native_batch_norm_default_78[1]
        getitem_463 = native_batch_norm_default_78[2];  native_batch_norm_default_78 = None
        view_default_157 = torch.ops.aten.view.default(getitem_461, [1024, 256, 1, 1]);  getitem_461 = None
        convolution_default_78 = torch.ops.aten.convolution.default(relu__default_74, view_default_157, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_24 = torch.ops.aten.add.Tensor(convolution_default_78, add_tensor_23);  convolution_default_78 = None
        native_group_norm_default_75 = torch.ops.aten.native_group_norm.default(add_tensor_24, primals_156, primals_155, 64, 1024, 784, 32, 1e-05);  primals_155 = None
        getitem_464 = native_group_norm_default_75[0]
        getitem_465 = native_group_norm_default_75[1]
        getitem_466 = native_group_norm_default_75[2];  native_group_norm_default_75 = None
        relu__default_75 = torch.ops.aten.relu_.default(getitem_464);  getitem_464 = None
        view_default_158 = torch.ops.aten.view.default(primals_152, [1, 256, 1024]);  primals_152 = None
        native_batch_norm_default_79 = torch.ops.aten.native_batch_norm.default(view_default_158, None, None, None, None, True, 0.0, 1e-08)
        getitem_467 = native_batch_norm_default_79[0]
        getitem_468 = native_batch_norm_default_79[1]
        getitem_469 = native_batch_norm_default_79[2];  native_batch_norm_default_79 = None
        view_default_159 = torch.ops.aten.view.default(getitem_467, [256, 1024, 1, 1]);  getitem_467 = None
        convolution_default_79 = torch.ops.aten.convolution.default(relu__default_75, view_default_159, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_76 = torch.ops.aten.native_group_norm.default(convolution_default_79, primals_158, primals_157, 64, 256, 784, 32, 1e-05);  primals_157 = None
        getitem_470 = native_group_norm_default_76[0]
        getitem_471 = native_group_norm_default_76[1]
        getitem_472 = native_group_norm_default_76[2];  native_group_norm_default_76 = None
        relu__default_76 = torch.ops.aten.relu_.default(getitem_470);  getitem_470 = None
        view_default_160 = torch.ops.aten.view.default(primals_153, [1, 256, 2304]);  primals_153 = None
        native_batch_norm_default_80 = torch.ops.aten.native_batch_norm.default(view_default_160, None, None, None, None, True, 0.0, 1e-08)
        getitem_473 = native_batch_norm_default_80[0]
        getitem_474 = native_batch_norm_default_80[1]
        getitem_475 = native_batch_norm_default_80[2];  native_batch_norm_default_80 = None
        view_default_161 = torch.ops.aten.view.default(getitem_473, [256, 256, 3, 3]);  getitem_473 = None
        convolution_default_80 = torch.ops.aten.convolution.default(relu__default_76, view_default_161, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_77 = torch.ops.aten.native_group_norm.default(convolution_default_80, primals_160, primals_159, 64, 256, 784, 32, 1e-05);  primals_159 = None
        getitem_476 = native_group_norm_default_77[0]
        getitem_477 = native_group_norm_default_77[1]
        getitem_478 = native_group_norm_default_77[2];  native_group_norm_default_77 = None
        relu__default_77 = torch.ops.aten.relu_.default(getitem_476);  getitem_476 = None
        view_default_162 = torch.ops.aten.view.default(primals_154, [1, 1024, 256]);  primals_154 = None
        native_batch_norm_default_81 = torch.ops.aten.native_batch_norm.default(view_default_162, None, None, None, None, True, 0.0, 1e-08)
        getitem_479 = native_batch_norm_default_81[0]
        getitem_480 = native_batch_norm_default_81[1]
        getitem_481 = native_batch_norm_default_81[2];  native_batch_norm_default_81 = None
        view_default_163 = torch.ops.aten.view.default(getitem_479, [1024, 256, 1, 1]);  getitem_479 = None
        convolution_default_81 = torch.ops.aten.convolution.default(relu__default_77, view_default_163, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_25 = torch.ops.aten.add.Tensor(convolution_default_81, add_tensor_24);  convolution_default_81 = None
        native_group_norm_default_78 = torch.ops.aten.native_group_norm.default(add_tensor_25, primals_165, primals_164, 64, 1024, 784, 32, 1e-05);  primals_164 = None
        getitem_482 = native_group_norm_default_78[0]
        getitem_483 = native_group_norm_default_78[1]
        getitem_484 = native_group_norm_default_78[2];  native_group_norm_default_78 = None
        relu__default_78 = torch.ops.aten.relu_.default(getitem_482);  getitem_482 = None
        view_default_164 = torch.ops.aten.view.default(primals_161, [1, 256, 1024]);  primals_161 = None
        native_batch_norm_default_82 = torch.ops.aten.native_batch_norm.default(view_default_164, None, None, None, None, True, 0.0, 1e-08)
        getitem_485 = native_batch_norm_default_82[0]
        getitem_486 = native_batch_norm_default_82[1]
        getitem_487 = native_batch_norm_default_82[2];  native_batch_norm_default_82 = None
        view_default_165 = torch.ops.aten.view.default(getitem_485, [256, 1024, 1, 1]);  getitem_485 = None
        convolution_default_82 = torch.ops.aten.convolution.default(relu__default_78, view_default_165, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_79 = torch.ops.aten.native_group_norm.default(convolution_default_82, primals_167, primals_166, 64, 256, 784, 32, 1e-05);  primals_166 = None
        getitem_488 = native_group_norm_default_79[0]
        getitem_489 = native_group_norm_default_79[1]
        getitem_490 = native_group_norm_default_79[2];  native_group_norm_default_79 = None
        relu__default_79 = torch.ops.aten.relu_.default(getitem_488);  getitem_488 = None
        view_default_166 = torch.ops.aten.view.default(primals_162, [1, 256, 2304]);  primals_162 = None
        native_batch_norm_default_83 = torch.ops.aten.native_batch_norm.default(view_default_166, None, None, None, None, True, 0.0, 1e-08)
        getitem_491 = native_batch_norm_default_83[0]
        getitem_492 = native_batch_norm_default_83[1]
        getitem_493 = native_batch_norm_default_83[2];  native_batch_norm_default_83 = None
        view_default_167 = torch.ops.aten.view.default(getitem_491, [256, 256, 3, 3]);  getitem_491 = None
        convolution_default_83 = torch.ops.aten.convolution.default(relu__default_79, view_default_167, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_80 = torch.ops.aten.native_group_norm.default(convolution_default_83, primals_169, primals_168, 64, 256, 784, 32, 1e-05);  primals_168 = None
        getitem_494 = native_group_norm_default_80[0]
        getitem_495 = native_group_norm_default_80[1]
        getitem_496 = native_group_norm_default_80[2];  native_group_norm_default_80 = None
        relu__default_80 = torch.ops.aten.relu_.default(getitem_494);  getitem_494 = None
        view_default_168 = torch.ops.aten.view.default(primals_163, [1, 1024, 256]);  primals_163 = None
        native_batch_norm_default_84 = torch.ops.aten.native_batch_norm.default(view_default_168, None, None, None, None, True, 0.0, 1e-08)
        getitem_497 = native_batch_norm_default_84[0]
        getitem_498 = native_batch_norm_default_84[1]
        getitem_499 = native_batch_norm_default_84[2];  native_batch_norm_default_84 = None
        view_default_169 = torch.ops.aten.view.default(getitem_497, [1024, 256, 1, 1]);  getitem_497 = None
        convolution_default_84 = torch.ops.aten.convolution.default(relu__default_80, view_default_169, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_26 = torch.ops.aten.add.Tensor(convolution_default_84, add_tensor_25);  convolution_default_84 = None
        native_group_norm_default_81 = torch.ops.aten.native_group_norm.default(add_tensor_26, primals_183, primals_182, 64, 1024, 784, 32, 1e-05);  primals_182 = None
        getitem_500 = native_group_norm_default_81[0]
        getitem_501 = native_group_norm_default_81[1]
        getitem_502 = native_group_norm_default_81[2];  native_group_norm_default_81 = None
        relu__default_81 = torch.ops.aten.relu_.default(getitem_500);  getitem_500 = None
        view_default_170 = torch.ops.aten.view.default(primals_179, [1, 256, 1024]);  primals_179 = None
        native_batch_norm_default_85 = torch.ops.aten.native_batch_norm.default(view_default_170, None, None, None, None, True, 0.0, 1e-08)
        getitem_503 = native_batch_norm_default_85[0]
        getitem_504 = native_batch_norm_default_85[1]
        getitem_505 = native_batch_norm_default_85[2];  native_batch_norm_default_85 = None
        view_default_171 = torch.ops.aten.view.default(getitem_503, [256, 1024, 1, 1]);  getitem_503 = None
        convolution_default_85 = torch.ops.aten.convolution.default(relu__default_81, view_default_171, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_82 = torch.ops.aten.native_group_norm.default(convolution_default_85, primals_185, primals_184, 64, 256, 784, 32, 1e-05);  primals_184 = None
        getitem_506 = native_group_norm_default_82[0]
        getitem_507 = native_group_norm_default_82[1]
        getitem_508 = native_group_norm_default_82[2];  native_group_norm_default_82 = None
        relu__default_82 = torch.ops.aten.relu_.default(getitem_506);  getitem_506 = None
        view_default_172 = torch.ops.aten.view.default(primals_180, [1, 256, 2304]);  primals_180 = None
        native_batch_norm_default_86 = torch.ops.aten.native_batch_norm.default(view_default_172, None, None, None, None, True, 0.0, 1e-08)
        getitem_509 = native_batch_norm_default_86[0]
        getitem_510 = native_batch_norm_default_86[1]
        getitem_511 = native_batch_norm_default_86[2];  native_batch_norm_default_86 = None
        view_default_173 = torch.ops.aten.view.default(getitem_509, [256, 256, 3, 3]);  getitem_509 = None
        convolution_default_86 = torch.ops.aten.convolution.default(relu__default_82, view_default_173, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_83 = torch.ops.aten.native_group_norm.default(convolution_default_86, primals_187, primals_186, 64, 256, 784, 32, 1e-05);  primals_186 = None
        getitem_512 = native_group_norm_default_83[0]
        getitem_513 = native_group_norm_default_83[1]
        getitem_514 = native_group_norm_default_83[2];  native_group_norm_default_83 = None
        relu__default_83 = torch.ops.aten.relu_.default(getitem_512);  getitem_512 = None
        view_default_174 = torch.ops.aten.view.default(primals_181, [1, 1024, 256]);  primals_181 = None
        native_batch_norm_default_87 = torch.ops.aten.native_batch_norm.default(view_default_174, None, None, None, None, True, 0.0, 1e-08)
        getitem_515 = native_batch_norm_default_87[0]
        getitem_516 = native_batch_norm_default_87[1]
        getitem_517 = native_batch_norm_default_87[2];  native_batch_norm_default_87 = None
        view_default_175 = torch.ops.aten.view.default(getitem_515, [1024, 256, 1, 1]);  getitem_515 = None
        convolution_default_87 = torch.ops.aten.convolution.default(relu__default_83, view_default_175, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_27 = torch.ops.aten.add.Tensor(convolution_default_87, add_tensor_26);  convolution_default_87 = None
        native_group_norm_default_84 = torch.ops.aten.native_group_norm.default(add_tensor_27, primals_192, primals_191, 64, 1024, 784, 32, 1e-05);  primals_191 = None
        getitem_518 = native_group_norm_default_84[0]
        getitem_519 = native_group_norm_default_84[1]
        getitem_520 = native_group_norm_default_84[2];  native_group_norm_default_84 = None
        relu__default_84 = torch.ops.aten.relu_.default(getitem_518);  getitem_518 = None
        view_default_176 = torch.ops.aten.view.default(primals_188, [1, 256, 1024]);  primals_188 = None
        native_batch_norm_default_88 = torch.ops.aten.native_batch_norm.default(view_default_176, None, None, None, None, True, 0.0, 1e-08)
        getitem_521 = native_batch_norm_default_88[0]
        getitem_522 = native_batch_norm_default_88[1]
        getitem_523 = native_batch_norm_default_88[2];  native_batch_norm_default_88 = None
        view_default_177 = torch.ops.aten.view.default(getitem_521, [256, 1024, 1, 1]);  getitem_521 = None
        convolution_default_88 = torch.ops.aten.convolution.default(relu__default_84, view_default_177, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_85 = torch.ops.aten.native_group_norm.default(convolution_default_88, primals_194, primals_193, 64, 256, 784, 32, 1e-05);  primals_193 = None
        getitem_524 = native_group_norm_default_85[0]
        getitem_525 = native_group_norm_default_85[1]
        getitem_526 = native_group_norm_default_85[2];  native_group_norm_default_85 = None
        relu__default_85 = torch.ops.aten.relu_.default(getitem_524);  getitem_524 = None
        view_default_178 = torch.ops.aten.view.default(primals_189, [1, 256, 2304]);  primals_189 = None
        native_batch_norm_default_89 = torch.ops.aten.native_batch_norm.default(view_default_178, None, None, None, None, True, 0.0, 1e-08)
        getitem_527 = native_batch_norm_default_89[0]
        getitem_528 = native_batch_norm_default_89[1]
        getitem_529 = native_batch_norm_default_89[2];  native_batch_norm_default_89 = None
        view_default_179 = torch.ops.aten.view.default(getitem_527, [256, 256, 3, 3]);  getitem_527 = None
        convolution_default_89 = torch.ops.aten.convolution.default(relu__default_85, view_default_179, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_86 = torch.ops.aten.native_group_norm.default(convolution_default_89, primals_196, primals_195, 64, 256, 784, 32, 1e-05);  primals_195 = None
        getitem_530 = native_group_norm_default_86[0]
        getitem_531 = native_group_norm_default_86[1]
        getitem_532 = native_group_norm_default_86[2];  native_group_norm_default_86 = None
        relu__default_86 = torch.ops.aten.relu_.default(getitem_530);  getitem_530 = None
        view_default_180 = torch.ops.aten.view.default(primals_190, [1, 1024, 256]);  primals_190 = None
        native_batch_norm_default_90 = torch.ops.aten.native_batch_norm.default(view_default_180, None, None, None, None, True, 0.0, 1e-08)
        getitem_533 = native_batch_norm_default_90[0]
        getitem_534 = native_batch_norm_default_90[1]
        getitem_535 = native_batch_norm_default_90[2];  native_batch_norm_default_90 = None
        view_default_181 = torch.ops.aten.view.default(getitem_533, [1024, 256, 1, 1]);  getitem_533 = None
        convolution_default_90 = torch.ops.aten.convolution.default(relu__default_86, view_default_181, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_28 = torch.ops.aten.add.Tensor(convolution_default_90, add_tensor_27);  convolution_default_90 = None
        native_group_norm_default_87 = torch.ops.aten.native_group_norm.default(add_tensor_28, primals_201, primals_200, 64, 1024, 784, 32, 1e-05);  primals_200 = None
        getitem_536 = native_group_norm_default_87[0]
        getitem_537 = native_group_norm_default_87[1]
        getitem_538 = native_group_norm_default_87[2];  native_group_norm_default_87 = None
        relu__default_87 = torch.ops.aten.relu_.default(getitem_536);  getitem_536 = None
        view_default_182 = torch.ops.aten.view.default(primals_197, [1, 256, 1024]);  primals_197 = None
        native_batch_norm_default_91 = torch.ops.aten.native_batch_norm.default(view_default_182, None, None, None, None, True, 0.0, 1e-08)
        getitem_539 = native_batch_norm_default_91[0]
        getitem_540 = native_batch_norm_default_91[1]
        getitem_541 = native_batch_norm_default_91[2];  native_batch_norm_default_91 = None
        view_default_183 = torch.ops.aten.view.default(getitem_539, [256, 1024, 1, 1]);  getitem_539 = None
        convolution_default_91 = torch.ops.aten.convolution.default(relu__default_87, view_default_183, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_88 = torch.ops.aten.native_group_norm.default(convolution_default_91, primals_203, primals_202, 64, 256, 784, 32, 1e-05);  primals_202 = None
        getitem_542 = native_group_norm_default_88[0]
        getitem_543 = native_group_norm_default_88[1]
        getitem_544 = native_group_norm_default_88[2];  native_group_norm_default_88 = None
        relu__default_88 = torch.ops.aten.relu_.default(getitem_542);  getitem_542 = None
        view_default_184 = torch.ops.aten.view.default(primals_198, [1, 256, 2304]);  primals_198 = None
        native_batch_norm_default_92 = torch.ops.aten.native_batch_norm.default(view_default_184, None, None, None, None, True, 0.0, 1e-08)
        getitem_545 = native_batch_norm_default_92[0]
        getitem_546 = native_batch_norm_default_92[1]
        getitem_547 = native_batch_norm_default_92[2];  native_batch_norm_default_92 = None
        view_default_185 = torch.ops.aten.view.default(getitem_545, [256, 256, 3, 3]);  getitem_545 = None
        convolution_default_92 = torch.ops.aten.convolution.default(relu__default_88, view_default_185, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_89 = torch.ops.aten.native_group_norm.default(convolution_default_92, primals_205, primals_204, 64, 256, 784, 32, 1e-05);  primals_204 = None
        getitem_548 = native_group_norm_default_89[0]
        getitem_549 = native_group_norm_default_89[1]
        getitem_550 = native_group_norm_default_89[2];  native_group_norm_default_89 = None
        relu__default_89 = torch.ops.aten.relu_.default(getitem_548);  getitem_548 = None
        view_default_186 = torch.ops.aten.view.default(primals_199, [1, 1024, 256]);  primals_199 = None
        native_batch_norm_default_93 = torch.ops.aten.native_batch_norm.default(view_default_186, None, None, None, None, True, 0.0, 1e-08)
        getitem_551 = native_batch_norm_default_93[0]
        getitem_552 = native_batch_norm_default_93[1]
        getitem_553 = native_batch_norm_default_93[2];  native_batch_norm_default_93 = None
        view_default_187 = torch.ops.aten.view.default(getitem_551, [1024, 256, 1, 1]);  getitem_551 = None
        convolution_default_93 = torch.ops.aten.convolution.default(relu__default_89, view_default_187, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_29 = torch.ops.aten.add.Tensor(convolution_default_93, add_tensor_28);  convolution_default_93 = None
        native_group_norm_default_90 = torch.ops.aten.native_group_norm.default(add_tensor_29, primals_283, primals_282, 64, 1024, 784, 32, 1e-05);  primals_282 = None
        getitem_554 = native_group_norm_default_90[0]
        getitem_555 = native_group_norm_default_90[1]
        getitem_556 = native_group_norm_default_90[2];  native_group_norm_default_90 = None
        relu__default_90 = torch.ops.aten.relu_.default(getitem_554);  getitem_554 = None
        view_default_188 = torch.ops.aten.view.default(primals_281, [1, 2048, 1024]);  primals_281 = None
        native_batch_norm_default_94 = torch.ops.aten.native_batch_norm.default(view_default_188, None, None, None, None, True, 0.0, 1e-08)
        getitem_557 = native_batch_norm_default_94[0]
        getitem_558 = native_batch_norm_default_94[1]
        getitem_559 = native_batch_norm_default_94[2];  native_batch_norm_default_94 = None
        view_default_189 = torch.ops.aten.view.default(getitem_557, [2048, 1024, 1, 1]);  getitem_557 = None
        convolution_default_94 = torch.ops.aten.convolution.default(relu__default_90, view_default_189, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 1)
        view_default_190 = torch.ops.aten.view.default(primals_278, [1, 512, 1024]);  primals_278 = None
        native_batch_norm_default_95 = torch.ops.aten.native_batch_norm.default(view_default_190, None, None, None, None, True, 0.0, 1e-08)
        getitem_560 = native_batch_norm_default_95[0]
        getitem_561 = native_batch_norm_default_95[1]
        getitem_562 = native_batch_norm_default_95[2];  native_batch_norm_default_95 = None
        view_default_191 = torch.ops.aten.view.default(getitem_560, [512, 1024, 1, 1]);  getitem_560 = None
        convolution_default_95 = torch.ops.aten.convolution.default(relu__default_90, view_default_191, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_91 = torch.ops.aten.native_group_norm.default(convolution_default_95, primals_285, primals_284, 64, 512, 784, 32, 1e-05);  primals_284 = None
        getitem_563 = native_group_norm_default_91[0]
        getitem_564 = native_group_norm_default_91[1]
        getitem_565 = native_group_norm_default_91[2];  native_group_norm_default_91 = None
        relu__default_91 = torch.ops.aten.relu_.default(getitem_563);  getitem_563 = None
        view_default_192 = torch.ops.aten.view.default(primals_279, [1, 512, 4608]);  primals_279 = None
        native_batch_norm_default_96 = torch.ops.aten.native_batch_norm.default(view_default_192, None, None, None, None, True, 0.0, 1e-08)
        getitem_566 = native_batch_norm_default_96[0]
        getitem_567 = native_batch_norm_default_96[1]
        getitem_568 = native_batch_norm_default_96[2];  native_batch_norm_default_96 = None
        view_default_193 = torch.ops.aten.view.default(getitem_566, [512, 512, 3, 3]);  getitem_566 = None
        convolution_default_96 = torch.ops.aten.convolution.default(relu__default_91, view_default_193, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_92 = torch.ops.aten.native_group_norm.default(convolution_default_96, primals_287, primals_286, 64, 512, 196, 32, 1e-05);  primals_286 = None
        getitem_569 = native_group_norm_default_92[0]
        getitem_570 = native_group_norm_default_92[1]
        getitem_571 = native_group_norm_default_92[2];  native_group_norm_default_92 = None
        relu__default_92 = torch.ops.aten.relu_.default(getitem_569);  getitem_569 = None
        view_default_194 = torch.ops.aten.view.default(primals_280, [1, 2048, 512]);  primals_280 = None
        native_batch_norm_default_97 = torch.ops.aten.native_batch_norm.default(view_default_194, None, None, None, None, True, 0.0, 1e-08)
        getitem_572 = native_batch_norm_default_97[0]
        getitem_573 = native_batch_norm_default_97[1]
        getitem_574 = native_batch_norm_default_97[2];  native_batch_norm_default_97 = None
        view_default_195 = torch.ops.aten.view.default(getitem_572, [2048, 512, 1, 1]);  getitem_572 = None
        convolution_default_97 = torch.ops.aten.convolution.default(relu__default_92, view_default_195, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_30 = torch.ops.aten.add.Tensor(convolution_default_97, convolution_default_94);  convolution_default_97 = convolution_default_94 = None
        native_group_norm_default_93 = torch.ops.aten.native_group_norm.default(add_tensor_30, primals_292, primals_291, 64, 2048, 196, 32, 1e-05);  primals_291 = None
        getitem_575 = native_group_norm_default_93[0]
        getitem_576 = native_group_norm_default_93[1]
        getitem_577 = native_group_norm_default_93[2];  native_group_norm_default_93 = None
        relu__default_93 = torch.ops.aten.relu_.default(getitem_575);  getitem_575 = None
        view_default_196 = torch.ops.aten.view.default(primals_288, [1, 512, 2048]);  primals_288 = None
        native_batch_norm_default_98 = torch.ops.aten.native_batch_norm.default(view_default_196, None, None, None, None, True, 0.0, 1e-08)
        getitem_578 = native_batch_norm_default_98[0]
        getitem_579 = native_batch_norm_default_98[1]
        getitem_580 = native_batch_norm_default_98[2];  native_batch_norm_default_98 = None
        view_default_197 = torch.ops.aten.view.default(getitem_578, [512, 2048, 1, 1]);  getitem_578 = None
        convolution_default_98 = torch.ops.aten.convolution.default(relu__default_93, view_default_197, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_94 = torch.ops.aten.native_group_norm.default(convolution_default_98, primals_294, primals_293, 64, 512, 196, 32, 1e-05);  primals_293 = None
        getitem_581 = native_group_norm_default_94[0]
        getitem_582 = native_group_norm_default_94[1]
        getitem_583 = native_group_norm_default_94[2];  native_group_norm_default_94 = None
        relu__default_94 = torch.ops.aten.relu_.default(getitem_581);  getitem_581 = None
        view_default_198 = torch.ops.aten.view.default(primals_289, [1, 512, 4608]);  primals_289 = None
        native_batch_norm_default_99 = torch.ops.aten.native_batch_norm.default(view_default_198, None, None, None, None, True, 0.0, 1e-08)
        getitem_584 = native_batch_norm_default_99[0]
        getitem_585 = native_batch_norm_default_99[1]
        getitem_586 = native_batch_norm_default_99[2];  native_batch_norm_default_99 = None
        view_default_199 = torch.ops.aten.view.default(getitem_584, [512, 512, 3, 3]);  getitem_584 = None
        convolution_default_99 = torch.ops.aten.convolution.default(relu__default_94, view_default_199, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_95 = torch.ops.aten.native_group_norm.default(convolution_default_99, primals_296, primals_295, 64, 512, 196, 32, 1e-05);  primals_295 = None
        getitem_587 = native_group_norm_default_95[0]
        getitem_588 = native_group_norm_default_95[1]
        getitem_589 = native_group_norm_default_95[2];  native_group_norm_default_95 = None
        relu__default_95 = torch.ops.aten.relu_.default(getitem_587);  getitem_587 = None
        view_default_200 = torch.ops.aten.view.default(primals_290, [1, 2048, 512]);  primals_290 = None
        native_batch_norm_default_100 = torch.ops.aten.native_batch_norm.default(view_default_200, None, None, None, None, True, 0.0, 1e-08)
        getitem_590 = native_batch_norm_default_100[0]
        getitem_591 = native_batch_norm_default_100[1]
        getitem_592 = native_batch_norm_default_100[2];  native_batch_norm_default_100 = None
        view_default_201 = torch.ops.aten.view.default(getitem_590, [2048, 512, 1, 1]);  getitem_590 = None
        convolution_default_100 = torch.ops.aten.convolution.default(relu__default_95, view_default_201, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_31 = torch.ops.aten.add.Tensor(convolution_default_100, add_tensor_30);  convolution_default_100 = None
        native_group_norm_default_96 = torch.ops.aten.native_group_norm.default(add_tensor_31, primals_301, primals_300, 64, 2048, 196, 32, 1e-05);  primals_300 = None
        getitem_593 = native_group_norm_default_96[0]
        getitem_594 = native_group_norm_default_96[1]
        getitem_595 = native_group_norm_default_96[2];  native_group_norm_default_96 = None
        relu__default_96 = torch.ops.aten.relu_.default(getitem_593);  getitem_593 = None
        view_default_202 = torch.ops.aten.view.default(primals_297, [1, 512, 2048]);  primals_297 = None
        native_batch_norm_default_101 = torch.ops.aten.native_batch_norm.default(view_default_202, None, None, None, None, True, 0.0, 1e-08)
        getitem_596 = native_batch_norm_default_101[0]
        getitem_597 = native_batch_norm_default_101[1]
        getitem_598 = native_batch_norm_default_101[2];  native_batch_norm_default_101 = None
        view_default_203 = torch.ops.aten.view.default(getitem_596, [512, 2048, 1, 1]);  getitem_596 = None
        convolution_default_101 = torch.ops.aten.convolution.default(relu__default_96, view_default_203, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        native_group_norm_default_97 = torch.ops.aten.native_group_norm.default(convolution_default_101, primals_303, primals_302, 64, 512, 196, 32, 1e-05);  primals_302 = None
        getitem_599 = native_group_norm_default_97[0]
        getitem_600 = native_group_norm_default_97[1]
        getitem_601 = native_group_norm_default_97[2];  native_group_norm_default_97 = None
        relu__default_97 = torch.ops.aten.relu_.default(getitem_599);  getitem_599 = None
        view_default_204 = torch.ops.aten.view.default(primals_298, [1, 512, 4608]);  primals_298 = None
        native_batch_norm_default_102 = torch.ops.aten.native_batch_norm.default(view_default_204, None, None, None, None, True, 0.0, 1e-08)
        getitem_602 = native_batch_norm_default_102[0]
        getitem_603 = native_batch_norm_default_102[1]
        getitem_604 = native_batch_norm_default_102[2];  native_batch_norm_default_102 = None
        view_default_205 = torch.ops.aten.view.default(getitem_602, [512, 512, 3, 3]);  getitem_602 = None
        convolution_default_102 = torch.ops.aten.convolution.default(relu__default_97, view_default_205, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1)
        native_group_norm_default_98 = torch.ops.aten.native_group_norm.default(convolution_default_102, primals_305, primals_304, 64, 512, 196, 32, 1e-05);  primals_304 = None
        getitem_605 = native_group_norm_default_98[0]
        getitem_606 = native_group_norm_default_98[1]
        getitem_607 = native_group_norm_default_98[2];  native_group_norm_default_98 = None
        relu__default_98 = torch.ops.aten.relu_.default(getitem_605);  getitem_605 = None
        view_default_206 = torch.ops.aten.view.default(primals_299, [1, 2048, 512]);  primals_299 = None
        native_batch_norm_default_103 = torch.ops.aten.native_batch_norm.default(view_default_206, None, None, None, None, True, 0.0, 1e-08)
        getitem_608 = native_batch_norm_default_103[0]
        getitem_609 = native_batch_norm_default_103[1]
        getitem_610 = native_batch_norm_default_103[2];  native_batch_norm_default_103 = None
        view_default_207 = torch.ops.aten.view.default(getitem_608, [2048, 512, 1, 1]);  getitem_608 = None
        convolution_default_103 = torch.ops.aten.convolution.default(relu__default_98, view_default_207, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1)
        add_tensor_32 = torch.ops.aten.add.Tensor(convolution_default_103, add_tensor_31);  convolution_default_103 = None
        native_group_norm_default_99 = torch.ops.aten.native_group_norm.default(add_tensor_32, primals_4, primals_3, 64, 2048, 196, 32, 1e-05);  primals_3 = None
        getitem_611 = native_group_norm_default_99[0]
        getitem_612 = native_group_norm_default_99[1]
        getitem_613 = native_group_norm_default_99[2];  native_group_norm_default_99 = None
        relu__default_99 = torch.ops.aten.relu_.default(getitem_611);  getitem_611 = None
        mean_dim = torch.ops.aten.mean.dim(relu__default_99, [-1, -2], True)
        convolution_default_104 = torch.ops.aten.convolution.default(mean_dim, primals_2, primals_1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1);  primals_1 = None
        view_default_208 = torch.ops.aten.view.default(convolution_default_104, [64, 1000]);  convolution_default_104 = None
        return [view_default_208, view_default_173, relu__default_2, view_default_175, add_tensor, getitem_511, view_default_10, view_default_180, getitem_297, getitem_507, relu__default_47, getitem_514, view_default_178, convolution_default_86, getitem_21, getitem_27, getitem_24, view_default_8, getitem_295, getitem_510, getitem_25, getitem_294, getitem_22, getitem_513, getitem_508, getitem_298, view_default_9, relu__default_83, relu__default_82, view_default_103, getitem_30, getitem_28, view_default_11, getitem_31, convolution_default_5, getitem_33, view_default_12, relu__default_3, view_default_204, view_default_99, getitem_576, getitem_571, primals_169, getitem_268, relu__default_45, getitem_267, view_default_195, getitem_286, getitem_273, getitem_292, relu__default_92, primals_174, getitem_270, view_default_197, primals_176, view_default_94, add_tensor_30, getitem_271, getitem_577, getitem_288, view_default_93, getitem_274, convolution_default_98, primals_165, getitem_285, view_default_101, view_default_104, getitem_570, getitem_573, primals_160, getitem_289, relu__default_43, view_default_96, getitem_291, view_default_200, relu__default_42, primals_167, convolution_default_46, getitem_574, relu__default_46, convolution_default_50, convolution_default_49, view_default_92, relu__default_93, primals_60, primals_237, add_tensor_7, getitem_159, primals_232, add_tensor_1, getitem_43, getitem_45, primals_241, getitem_46, view_default_57, getitem_156, view_default_16, primals_69, primals_67, primals_228, relu__default_6, primals_65, view_default_55, primals_75, primals_239, relu__default_24, view_default_56, primals_230, view_default_15, getitem_157, convolution_default_28, getitem_42, getitem_160, relu__default_49, getitem_316, getitem_504, getitem_313, view_default_114, getitem_505, convolution_default_85, view_default_172, view_default_107, getitem_498, getitem_502, getitem_315, view_default_110, getitem_499, view_default_171, getitem_501, view_default_109, view_default_176, relu__default_50, add_tensor_26, convolution_default_53, relu__default_81, getitem_310, getitem_309, getitem_312, relu__default_41, view_default_98, getitem_262, add_tensor_13, view_default_90, getitem_265, getitem_264, getitem_261, view_default_91, getitem_91, view_default_32, convolution_default_16, getitem_93, getitem_94, relu__default_13, convolution_default_15, getitem_88, view_default_33, getitem_87, getitem_90, primals_259, getitem_126, getitem_133, view_default_125, getitem_462, primals_4, view_default_159, view_default_45, getitem_360, getitem_465, convolution_default_22, getitem_141, getitem_364, convolution_default_79, view_default_51, view_default_123, primals_10, getitem_127, primals_268, add_tensor_24, getitem_142, view_default_128, getitem_132, primals_266, view_default_162, relu__default_19, getitem_129, getitem_145, getitem_363, primals_12, getitem_130, getitem_463, view_default_49, view_default_44, view_default_46, primals_273, getitem_361, view_default_50, primals_14, convolution_default_25, getitem_357, relu__default_57, getitem_358, getitem_144, convolution_default_61, add_tensor_18, getitem_469, relu__default_75, getitem_468, primals_2, primals_19, getitem_466, primals_264, view_default_22, convolution_default_70, relu__default_8, getitem_454, getitem_459, convolution_default_77, getitem_63, view_default_21, getitem_405, view_default_139, view_default_20, view_default_144, getitem_406, view_default_160, relu__default_66, getitem_58, getitem_456, relu__default_74, relu__default_73, primals_307, view_default_164, getitem_409, add_tensor_2, getitem_60, getitem_460, add_tensor_21, getitem_61, getitem_57, getitem_408, getitem_412, getitem_457, getitem_64, view_default_146, getitem_453, view_default_157, primals_305, view_default_141, getitem_411, getitem_414, relu__default_65, view_default_155, primals_47, primals_49, primals_51, relu__default_15, relu__default_16, convolution_default_18, getitem_105, view_default_37, getitem_109, primals_56, getitem_106, view_default_38, primals_58, primals_42, primals_40, primals_38, getitem_108, view_default_127, view_default_134, getitem_378, convolution_default_58, getitem_369, relu__default_59, view_default_119, getitem_340, relu__default_54, view_default_129, convolution_default_62, getitem_345, add_tensor_19, getitem_343, getitem_375, add_tensor_17, getitem_370, getitem_346, getitem_342, getitem_366, view_default_132, relu__default_58, getitem_372, convolution_default_64, getitem_339, getitem_379, view_default_122, getitem_373, getitem_376, view_default_130, getitem_367, view_default_117, relu__default_60, relu__default_31, getitem_226, primals_111, view_default_6, getitem_18, view_default_5, getitem_16, view_default_71, relu__default_30, relu__default_1, convolution_default_3, primals_124, getitem_222, primals_140, getitem_199, convolution_default_38, primals_131, primals_120, relu__default_35, primals_296, primals_113, view_default_69, primals_133, view_default_79, getitem_15, getitem_225, view_default_7, getitem_202, relu__default_34, primals_138, getitem_19, view_default_78, primals_294, view_default_77, primals_115, getitem_13, primals_106, convolution_default_35, primals_292, getitem_201, primals_129, getitem_198, convolution_default_2, getitem_12, convolution_default_34, view_default_70, primals_303, primals_122, primals_301, getitem_223, view_default_86, view_default_202, relu__default_94, view_default_85, getitem_246, getitem_585, getitem_582, convolution_default_99, getitem_580, getitem_244, getitem_583, relu__default_38, view_default_199, add_tensor_12, relu__default_39, getitem_579, getitem_249, getitem_250, getitem_586, getitem_247, view_default_174, primals_183, relu__default_9, getitem_70, convolution_default_55, getitem_69, view_default_113, getitem_322, getitem_490, getitem_67, getitem_321, getitem_318, add_tensor_16, view_default_169, getitem_324, view_default_120, getitem_66, getitem_496, view_default_23, getitem_493, view_default_24, getitem_489, getitem_492, getitem_325, convolution_default_83, primals_178, getitem_327, getitem_319, view_default_111, relu__default_80, convolution_default_12, relu__default_51, view_default_25, view_default_167, getitem_328, primals_185, primals_187, relu__default_79, getitem_495, getitem_387, getitem_394, getitem_604, view_default_205, relu__default_62, primals_250, getitem_606, getitem_388, view_default_140, convolution_default_102, view_default_135, view_default_207, view_default_138, getitem_603, getitem_598, getitem_601, getitem_393, relu__default_97, getitem_600, primals_255, primals_257, getitem_391, getitem_597, relu__default_63, getitem_390, view_default_133, add_tensor_20, primals_246, convolution_default_101, primals_248, getitem_183, view_default_87, view_default_89, relu__default_40, getitem_48, convolution_default_31, primals_77, convolution_default_43, getitem_180, primals_86, relu__default_7, getitem_259, convolution_default_44, view_default_19, relu__default_28, view_default_88, getitem_52, getitem_252, convolution_default_8, getitem_255, view_default_18, primals_84, view_default_63, getitem_54, primals_88, getitem_55, getitem_49, getitem_51, primals_79, getitem_186, view_default_64, getitem_184, view_default_17, getitem_253, getitem_181, getitem_258, view_default_65, getitem_187, getitem_256, convolution_default_9, convolution_default_32, primals_196, view_default_147, relu__default_72, view_default_196, primals_203, getitem_540, getitem_553, primals_201, relu__default_69, getitem_543, relu__default_68, view_default_154, view_default_26, view_default_188, convolution_default_13, getitem_427, getitem_448, getitem_534, getitem_432, relu__default_10, getitem_429, getitem_445, relu__default_90, getitem_72, relu__default_87, view_default_152, primals_205, getitem_78, getitem_558, view_default_150, getitem_556, view_default_153, getitem_75, getitem_541, getitem_447, getitem_424, getitem_450, getitem_538, view_default_183, view_default_189, getitem_73, add_tensor_22, view_default_190, getitem_559, primals_192, convolution_default_76, getitem_76, add_tensor_28, getitem_535, add_tensor_23, view_default_158, view_default_185, getitem_430, convolution_default_91, getitem_555, view_default_28, view_default_27, getitem_451, getitem_444, view_default_194, convolution_default_73, primals_194, getitem_79, getitem_537, add_tensor_29, getitem_426, getitem_552, getitem_97, getitem_216, getitem_213, view_default_39, view_default_47, getitem_220, view_default_14, getitem_39, getitem_114, view_default_48, getitem_100, convolution_default_19, view_default_74, getitem_34, view_default_34, view_default_40, view_default_36, view_default_41, getitem_139, getitem_117, getitem_136, getitem_214, getitem_115, getitem_135, view_default_75, getitem_103, relu__default_21, convolution_default_6, relu__default_17, getitem_217, view_default_13, relu__default_14, relu__default_4, getitem_102, getitem_96, getitem_99, view_default_35, add_tensor_6, convolution_default_37, getitem_36, getitem_219, add_tensor_4, getitem_111, getitem_138, getitem_37, getitem_112, view_default_76, relu__default_33, relu__default_20, getitem_40, relu__default_5, relu__default_36, getitem_591, getitem_229, getitem_486, view_default_203, getitem_234, getitem_592, convolution_default_82, view_default_68, getitem_190, getitem_595, view_default_165, relu__default_95, getitem_195, mean_dim, relu__default_96, view_default_66, view_default_206, relu__default_29, getitem_193, add_tensor_25, getitem_484, add_tensor_9, add_tensor_11, getitem_589, getitem_480, getitem_594, getitem_487, view_default_67, view_default_80, getitem_192, view_default_168, getitem_483, getitem_232, getitem_231, view_default_170, convolution_default_40, relu__default_78, add_tensor_31, getitem_588, getitem_196, getitem_481, view_default_81, getitem_189, getitem_228, view_default_201, view_default_163, primals_102, getitem_415, getitem_241, convolution_default_41, view_default_161, getitem_423, getitem_235, primals_30, view_default_143, view_default_83, view_default_145, view_default_84, view_default_148, primals_104, getitem_477, primals_95, convolution_default_80, view_default_82, getitem_237, getitem_475, relu__default_37, convolution_default_71, getitem_471, primals_23, getitem_240, getitem_421, primals_97, primals_21, primals_28, getitem_474, relu__default_67, primals_93, getitem_418, getitem_472, getitem_243, relu__default_77, primals_32, view_default_166, getitem_417, getitem_238, relu__default_76, getitem_478, getitem_420, add_tensor_27, view_default_182, getitem_517, getitem_523, view_default_177, relu__default_84, getitem_522, getitem_519, getitem_520, convolution_default_88, getitem_516, getitem_168, getitem_162, view_default_59, getitem_165, getitem_120, relu__default_25, convolution_default_29, getitem_166, view_default_43, getitem_118, getitem_121, view_default_58, add_tensor_5, view_default_42, getitem_163, getitem_123, relu__default_18, getitem_124, convolution_default_21, getitem_169, view_default, primals_210, primals_212, primals_223, primals_221, primals_214, primals_219, primals_275, relu__default_85, view_default_179, add_tensor_32, primals_277, getitem_526, getitem_528, view_default_186, getitem_607, getitem_610, relu__default_86, getitem_531, getitem_609, primals_287, primals_283, view_default_181, getitem_529, view_default_184, getitem_532, getitem_613, relu__default_98, relu__default_99, getitem_612, primals_285, convolution_default_89, getitem_525, add_tensor_3, add_tensor_15, relu__default_12, view_default_31, getitem_300, getitem_307, view_default_112, getitem_303, getitem_381, primals_142, convolution_default_52, view_default_30, view_default_106, view_default_131, getitem_384, convolution_default_65, primals_158, relu__default_61, primals_156, getitem_301, view_default_29, relu__default_11, view_default_108, view_default_105, primals_147, view_default_136, getitem_385, getitem_306, getitem_82, getitem_304, primals_151, getitem_81, getitem_382, relu__default_48, primals_149, getitem_85, getitem_84, getitem_151, getitem_154, relu__default_23, getitem_150, view_default_52, view_default_53, getitem_147, getitem_148, view_default_54, convolution_default_26, getitem_153, relu__default_22, view_default_60, getitem_349, relu__default_26, view_default_126, relu__default_56, getitem_178, getitem_177, getitem_352, getitem_174, getitem_348, view_default_121, getitem_355, relu__default_27, view_default_124, getitem_171, relu__default_55, add_tensor_8, getitem_172, getitem_351, getitem_175, convolution_default_59, view_default_61, getitem_354, view_default_62, view_default_137, view_default_4, getitem_4, getitem_438, getitem_397, relu__default, getitem_441, getitem_7, constant_pad_nd_default, relu__default_71, view_default_2, getitem_396, relu__default_70, view_default_142, getitem_436, getitem_208, getitem_435, getitem_211, convolution_default_74, getitem_3, convolution_default_67, getitem_210, view_default_3, view_default_151, getitem_2, getitem_9, view_default_156, getitem_10, getitem_1, relu__default_64, getitem_442, relu__default_32, getitem_399, convolution_default_68, view_default_72, view_default_1, getitem_205, add_tensor_10, getitem_433, view_default_73, getitem_207, view_default_149, getitem_6, getitem_400, getitem_204, getitem_402, getitem_403, getitem_439, relu__default_91, getitem_564, view_default_102, getitem_561, relu__default_44, add_tensor_14, getitem_279, view_default_193, view_default_97, getitem_567, convolution_default_95, convolution_default_47, view_default_100, view_default_95, getitem_565, getitem_568, getitem_280, convolution_default_96, getitem_277, view_default_191, getitem_282, getitem_562, getitem_283, getitem_276, view_default_198, getitem_546, getitem_333, getitem_336, convolution_default_92, convolution_default_56, getitem_549, getitem_550, view_default_192, relu__default_88, view_default_118, view_default_116, getitem_331, getitem_544, relu__default_52, getitem_337, relu__default_89, view_default_115, relu__default_53, view_default_187, getitem_330, getitem_547, getitem_334]
        
