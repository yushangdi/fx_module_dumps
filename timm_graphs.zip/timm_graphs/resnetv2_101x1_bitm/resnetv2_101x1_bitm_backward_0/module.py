
import torch
from math import inf
from math import nan
NoneType = type(None)
import torch
from torch import device
import torch.fx._pytree as fx_pytree
import torch.utils._pytree as pytree
from torch.nn import *
class FxModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.load_state_dict(torch.load(r'timm_graphs/resnetv2_101x1_bitm/resnetv2_101x1_bitm_backward_0/state_dict.pt'))

    
    
    def forward(self, view_default_173, relu__default_2, view_default_175, add_tensor, getitem_511, view_default_10, view_default_180, getitem_297, getitem_507, relu__default_47, getitem_514, view_default_178, convolution_default_86, getitem_21, getitem_27, getitem_24, view_default_8, getitem_295, getitem_510, getitem_25, getitem_294, getitem_22, getitem_513, getitem_508, getitem_298, view_default_9, relu__default_83, relu__default_82, view_default_103, getitem_30, getitem_28, view_default_11, getitem_31, convolution_default_5, getitem_33, view_default_12, relu__default_3, view_default_204, view_default_99, getitem_576, getitem_571, primals_169, getitem_268, relu__default_45, getitem_267, view_default_195, getitem_286, getitem_273, getitem_292, relu__default_92, primals_174, getitem_270, view_default_197, primals_176, view_default_94, add_tensor_30, getitem_271, getitem_577, getitem_288, view_default_93, getitem_274, convolution_default_98, primals_165, getitem_285, view_default_101, view_default_104, getitem_570, getitem_573, primals_160, getitem_289, relu__default_43, view_default_96, getitem_291, view_default_200, relu__default_42, primals_167, convolution_default_46, getitem_574, relu__default_46, convolution_default_50, convolution_default_49, view_default_92, relu__default_93, primals_60, primals_237, add_tensor_7, getitem_159, primals_232, add_tensor_1, getitem_43, getitem_45, primals_241, getitem_46, view_default_57, getitem_156, view_default_16, primals_69, primals_67, primals_228, relu__default_6, primals_65, view_default_55, primals_75, primals_239, relu__default_24, view_default_56, primals_230, view_default_15, getitem_157, convolution_default_28, getitem_42, getitem_160, relu__default_49, getitem_316, getitem_504, getitem_313, view_default_114, getitem_505, convolution_default_85, view_default_172, view_default_107, getitem_498, getitem_502, getitem_315, view_default_110, getitem_499, view_default_171, getitem_501, view_default_109, view_default_176, relu__default_50, add_tensor_26, convolution_default_53, relu__default_81, getitem_310, getitem_309, getitem_312, relu__default_41, view_default_98, getitem_262, add_tensor_13, view_default_90, getitem_265, getitem_264, getitem_261, view_default_91, getitem_91, view_default_32, convolution_default_16, getitem_93, getitem_94, relu__default_13, convolution_default_15, getitem_88, view_default_33, getitem_87, getitem_90, primals_259, getitem_126, getitem_133, view_default_125, getitem_462, primals_4, view_default_159, view_default_45, getitem_360, getitem_465, convolution_default_22, getitem_141, getitem_364, convolution_default_79, view_default_51, view_default_123, primals_10, getitem_127, primals_268, add_tensor_24, getitem_142, view_default_128, getitem_132, primals_266, view_default_162, relu__default_19, getitem_129, getitem_145, getitem_363, primals_12, getitem_130, getitem_463, view_default_49, view_default_44, view_default_46, primals_273, getitem_361, view_default_50, primals_14, convolution_default_25, getitem_357, relu__default_57, getitem_358, getitem_144, convolution_default_61, add_tensor_18, getitem_469, relu__default_75, getitem_468, primals_2, primals_19, getitem_466, primals_264, view_default_22, convolution_default_70, relu__default_8, getitem_454, getitem_459, convolution_default_77, getitem_63, view_default_21, getitem_405, view_default_139, view_default_20, view_default_144, getitem_406, view_default_160, relu__default_66, getitem_58, getitem_456, relu__default_74, relu__default_73, primals_307, view_default_164, getitem_409, add_tensor_2, getitem_60, getitem_460, add_tensor_21, getitem_61, getitem_57, getitem_408, getitem_412, getitem_457, getitem_64, view_default_146, getitem_453, view_default_157, primals_305, view_default_141, getitem_411, getitem_414, relu__default_65, view_default_155, primals_47, primals_49, primals_51, relu__default_15, relu__default_16, convolution_default_18, getitem_105, view_default_37, getitem_109, primals_56, getitem_106, view_default_38, primals_58, primals_42, primals_40, primals_38, getitem_108, view_default_127, view_default_134, getitem_378, convolution_default_58, getitem_369, relu__default_59, view_default_119, getitem_340, relu__default_54, view_default_129, convolution_default_62, getitem_345, add_tensor_19, getitem_343, getitem_375, add_tensor_17, getitem_370, getitem_346, getitem_342, getitem_366, view_default_132, relu__default_58, getitem_372, convolution_default_64, getitem_339, getitem_379, view_default_122, getitem_373, getitem_376, view_default_130, getitem_367, view_default_117, relu__default_60, relu__default_31, getitem_226, primals_111, view_default_6, getitem_18, view_default_5, getitem_16, view_default_71, relu__default_30, relu__default_1, convolution_default_3, primals_124, getitem_222, primals_140, getitem_199, convolution_default_38, primals_131, primals_120, relu__default_35, primals_296, primals_113, view_default_69, primals_133, view_default_79, getitem_15, getitem_225, view_default_7, getitem_202, relu__default_34, primals_138, getitem_19, view_default_78, primals_294, view_default_77, primals_115, getitem_13, primals_106, convolution_default_35, primals_292, getitem_201, primals_129, getitem_198, convolution_default_2, getitem_12, convolution_default_34, view_default_70, primals_303, primals_122, primals_301, getitem_223, view_default_86, view_default_202, relu__default_94, view_default_85, getitem_246, getitem_585, getitem_582, convolution_default_99, getitem_580, getitem_244, getitem_583, relu__default_38, view_default_199, add_tensor_12, relu__default_39, getitem_579, getitem_249, getitem_250, getitem_586, getitem_247, view_default_174, primals_183, relu__default_9, getitem_70, convolution_default_55, getitem_69, view_default_113, getitem_322, getitem_490, getitem_67, getitem_321, getitem_318, add_tensor_16, view_default_169, getitem_324, view_default_120, getitem_66, getitem_496, view_default_23, getitem_493, view_default_24, getitem_489, getitem_492, getitem_325, convolution_default_83, primals_178, getitem_327, getitem_319, view_default_111, relu__default_80, convolution_default_12, relu__default_51, view_default_25, view_default_167, getitem_328, primals_185, primals_187, relu__default_79, getitem_495, getitem_387, getitem_394, getitem_604, view_default_205, relu__default_62, primals_250, getitem_606, getitem_388, view_default_140, convolution_default_102, view_default_135, view_default_207, view_default_138, getitem_603, getitem_598, getitem_601, getitem_393, relu__default_97, getitem_600, primals_255, primals_257, getitem_391, getitem_597, relu__default_63, getitem_390, view_default_133, add_tensor_20, primals_246, convolution_default_101, primals_248, getitem_183, view_default_87, view_default_89, relu__default_40, getitem_48, convolution_default_31, primals_77, convolution_default_43, getitem_180, primals_86, relu__default_7, getitem_259, convolution_default_44, view_default_19, relu__default_28, view_default_88, getitem_52, getitem_252, convolution_default_8, getitem_255, view_default_18, primals_84, view_default_63, getitem_54, primals_88, getitem_55, getitem_49, getitem_51, primals_79, getitem_186, view_default_64, getitem_184, view_default_17, getitem_253, getitem_181, getitem_258, view_default_65, getitem_187, getitem_256, convolution_default_9, convolution_default_32, primals_196, view_default_147, relu__default_72, view_default_196, primals_203, getitem_540, getitem_553, primals_201, relu__default_69, getitem_543, relu__default_68, view_default_154, view_default_26, view_default_188, convolution_default_13, getitem_427, getitem_448, getitem_534, getitem_432, relu__default_10, getitem_429, getitem_445, relu__default_90, getitem_72, relu__default_87, view_default_152, primals_205, getitem_78, getitem_558, view_default_150, getitem_556, view_default_153, getitem_75, getitem_541, getitem_447, getitem_424, getitem_450, getitem_538, view_default_183, view_default_189, getitem_73, add_tensor_22, view_default_190, getitem_559, primals_192, convolution_default_76, getitem_76, add_tensor_28, getitem_535, add_tensor_23, view_default_158, view_default_185, getitem_430, convolution_default_91, getitem_555, view_default_28, view_default_27, getitem_451, getitem_444, view_default_194, convolution_default_73, primals_194, getitem_79, getitem_537, add_tensor_29, getitem_426, getitem_552, getitem_97, getitem_216, getitem_213, view_default_39, view_default_47, getitem_220, view_default_14, getitem_39, getitem_114, view_default_48, getitem_100, convolution_default_19, view_default_74, getitem_34, view_default_34, view_default_40, view_default_36, view_default_41, getitem_139, getitem_117, getitem_136, getitem_214, getitem_115, getitem_135, view_default_75, getitem_103, relu__default_21, convolution_default_6, relu__default_17, getitem_217, view_default_13, relu__default_14, relu__default_4, getitem_102, getitem_96, getitem_99, view_default_35, add_tensor_6, convolution_default_37, getitem_36, getitem_219, add_tensor_4, getitem_111, getitem_138, getitem_37, getitem_112, view_default_76, relu__default_33, relu__default_20, getitem_40, relu__default_5, relu__default_36, getitem_591, getitem_229, getitem_486, view_default_203, getitem_234, getitem_592, convolution_default_82, view_default_68, getitem_190, getitem_595, view_default_165, relu__default_95, getitem_195, mean_dim, relu__default_96, view_default_66, view_default_206, relu__default_29, getitem_193, add_tensor_25, getitem_484, add_tensor_9, add_tensor_11, getitem_589, getitem_480, getitem_594, getitem_487, view_default_67, view_default_80, getitem_192, view_default_168, getitem_483, getitem_232, getitem_231, view_default_170, convolution_default_40, relu__default_78, add_tensor_31, getitem_588, getitem_196, getitem_481, view_default_81, getitem_189, getitem_228, view_default_201, view_default_163, primals_102, getitem_415, getitem_241, convolution_default_41, view_default_161, getitem_423, getitem_235, primals_30, view_default_143, view_default_83, view_default_145, view_default_84, view_default_148, primals_104, getitem_477, primals_95, convolution_default_80, view_default_82, getitem_237, getitem_475, relu__default_37, convolution_default_71, getitem_471, primals_23, getitem_240, getitem_421, primals_97, primals_21, primals_28, getitem_474, relu__default_67, primals_93, getitem_418, getitem_472, getitem_243, relu__default_77, primals_32, view_default_166, getitem_417, getitem_238, relu__default_76, getitem_478, getitem_420, add_tensor_27, view_default_182, getitem_517, getitem_523, view_default_177, relu__default_84, getitem_522, getitem_519, getitem_520, convolution_default_88, getitem_516, getitem_168, getitem_162, view_default_59, getitem_165, getitem_120, relu__default_25, convolution_default_29, getitem_166, view_default_43, getitem_118, getitem_121, view_default_58, add_tensor_5, view_default_42, getitem_163, getitem_123, relu__default_18, getitem_124, convolution_default_21, getitem_169, view_default, primals_210, primals_212, primals_223, primals_221, primals_214, primals_219, primals_275, relu__default_85, view_default_179, add_tensor_32, primals_277, getitem_526, getitem_528, view_default_186, getitem_607, getitem_610, relu__default_86, getitem_531, getitem_609, primals_287, primals_283, view_default_181, getitem_529, view_default_184, getitem_532, getitem_613, relu__default_98, relu__default_99, getitem_612, primals_285, convolution_default_89, getitem_525, add_tensor_3, add_tensor_15, relu__default_12, view_default_31, getitem_300, getitem_307, view_default_112, getitem_303, getitem_381, primals_142, convolution_default_52, view_default_30, view_default_106, view_default_131, getitem_384, convolution_default_65, primals_158, relu__default_61, primals_156, getitem_301, view_default_29, relu__default_11, view_default_108, view_default_105, primals_147, view_default_136, getitem_385, getitem_306, getitem_82, getitem_304, primals_151, getitem_81, getitem_382, relu__default_48, primals_149, getitem_85, getitem_84, getitem_151, getitem_154, relu__default_23, getitem_150, view_default_52, view_default_53, getitem_147, getitem_148, view_default_54, convolution_default_26, getitem_153, relu__default_22, view_default_60, getitem_349, relu__default_26, view_default_126, relu__default_56, getitem_178, getitem_177, getitem_352, getitem_174, getitem_348, view_default_121, getitem_355, relu__default_27, view_default_124, getitem_171, relu__default_55, add_tensor_8, getitem_172, getitem_351, getitem_175, convolution_default_59, view_default_61, getitem_354, view_default_62, view_default_137, view_default_4, getitem_4, getitem_438, getitem_397, relu__default, getitem_441, getitem_7, constant_pad_nd_default, relu__default_71, view_default_2, getitem_396, relu__default_70, view_default_142, getitem_436, getitem_208, getitem_435, getitem_211, convolution_default_74, getitem_3, convolution_default_67, getitem_210, view_default_3, view_default_151, getitem_2, getitem_9, view_default_156, getitem_10, getitem_1, relu__default_64, getitem_442, relu__default_32, getitem_399, convolution_default_68, view_default_72, view_default_1, getitem_205, add_tensor_10, getitem_433, view_default_73, getitem_207, view_default_149, getitem_6, getitem_400, getitem_204, getitem_402, getitem_403, getitem_439, relu__default_91, getitem_564, view_default_102, getitem_561, relu__default_44, add_tensor_14, getitem_279, view_default_193, view_default_97, getitem_567, convolution_default_95, convolution_default_47, view_default_100, view_default_95, getitem_565, getitem_568, getitem_280, convolution_default_96, getitem_277, view_default_191, getitem_282, getitem_562, getitem_283, getitem_276, view_default_198, getitem_546, getitem_333, getitem_336, convolution_default_92, convolution_default_56, getitem_549, getitem_550, view_default_192, relu__default_88, view_default_118, view_default_116, getitem_331, getitem_544, relu__default_52, getitem_337, relu__default_89, view_default_115, relu__default_53, view_default_187, getitem_330, getitem_547, getitem_334, tangents_1):
        view_default_209 = torch.ops.aten.view.default(tangents_1, [64, 1000, 1, 1]);  tangents_1 = None
        convolution_backward_default = torch.ops.aten.convolution_backward.default(view_default_209, mean_dim, primals_2, [1000], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, True]);  view_default_209 = mean_dim = primals_2 = None
        getitem_614 = convolution_backward_default[0]
        getitem_615 = convolution_backward_default[1]
        getitem_616 = convolution_backward_default[2];  convolution_backward_default = None
        expand_default = torch.ops.aten.expand.default(getitem_614, [64, 2048, 14, 14]);  getitem_614 = None
        div_scalar = torch.ops.aten.div.Scalar(expand_default, 196);  expand_default = None
        to_dtype = torch.ops.aten.to.dtype(div_scalar, torch.float32);  div_scalar = None
        to_dtype_1 = torch.ops.aten.to.dtype(relu__default_99, torch.float32);  relu__default_99 = None
        le_scalar = torch.ops.aten.le.Scalar(to_dtype_1, 0);  to_dtype_1 = None
        new_zeros_default = torch.ops.aten.new_zeros.default(to_dtype, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self = torch.ops.aten.where.self(le_scalar, new_zeros_default, to_dtype);  le_scalar = new_zeros_default = to_dtype = None
        to_dtype_2 = torch.ops.aten.to.dtype(where_self, torch.float32);  where_self = None
        native_group_norm_backward_default = torch.ops.aten.native_group_norm_backward.default(to_dtype_2, add_tensor_32, getitem_612, getitem_613, primals_4, 64, 2048, 196, 32, [True, True, True]);  to_dtype_2 = add_tensor_32 = getitem_612 = getitem_613 = primals_4 = None
        getitem_617 = native_group_norm_backward_default[0]
        getitem_618 = native_group_norm_backward_default[1]
        getitem_619 = native_group_norm_backward_default[2];  native_group_norm_backward_default = None
        convolution_backward_default_1 = torch.ops.aten.convolution_backward.default(getitem_617, relu__default_98, view_default_207, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_207 = None
        getitem_620 = convolution_backward_default_1[0]
        getitem_621 = convolution_backward_default_1[1];  convolution_backward_default_1 = None
        view_default_210 = torch.ops.aten.view.default(getitem_621, [1, 2048, 512]);  getitem_621 = None
        native_batch_norm_backward_default = torch.ops.aten.native_batch_norm_backward.default(view_default_210, view_default_206, None, None, None, getitem_609, getitem_610, True, 1e-08, [True, False, False]);  view_default_210 = view_default_206 = getitem_609 = getitem_610 = None
        getitem_623 = native_batch_norm_backward_default[0];  native_batch_norm_backward_default = None
        view_default_211 = torch.ops.aten.view.default(getitem_623, [2048, 512, 1, 1]);  getitem_623 = None
        to_dtype_3 = torch.ops.aten.to.dtype(getitem_620, torch.float32);  getitem_620 = None
        to_dtype_4 = torch.ops.aten.to.dtype(relu__default_98, torch.float32);  relu__default_98 = None
        le_scalar_1 = torch.ops.aten.le.Scalar(to_dtype_4, 0);  to_dtype_4 = None
        new_zeros_default_1 = torch.ops.aten.new_zeros.default(to_dtype_3, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_1 = torch.ops.aten.where.self(le_scalar_1, new_zeros_default_1, to_dtype_3);  le_scalar_1 = new_zeros_default_1 = to_dtype_3 = None
        to_dtype_5 = torch.ops.aten.to.dtype(where_self_1, torch.float32);  where_self_1 = None
        native_group_norm_backward_default_1 = torch.ops.aten.native_group_norm_backward.default(to_dtype_5, convolution_default_102, getitem_606, getitem_607, primals_305, 64, 512, 196, 32, [True, True, True]);  to_dtype_5 = convolution_default_102 = getitem_606 = getitem_607 = primals_305 = None
        getitem_626 = native_group_norm_backward_default_1[0]
        getitem_627 = native_group_norm_backward_default_1[1]
        getitem_628 = native_group_norm_backward_default_1[2];  native_group_norm_backward_default_1 = None
        convolution_backward_default_2 = torch.ops.aten.convolution_backward.default(getitem_626, relu__default_97, view_default_205, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_626 = view_default_205 = None
        getitem_629 = convolution_backward_default_2[0]
        getitem_630 = convolution_backward_default_2[1];  convolution_backward_default_2 = None
        view_default_212 = torch.ops.aten.view.default(getitem_630, [1, 512, 4608]);  getitem_630 = None
        native_batch_norm_backward_default_1 = torch.ops.aten.native_batch_norm_backward.default(view_default_212, view_default_204, None, None, None, getitem_603, getitem_604, True, 1e-08, [True, False, False]);  view_default_212 = view_default_204 = getitem_603 = getitem_604 = None
        getitem_632 = native_batch_norm_backward_default_1[0];  native_batch_norm_backward_default_1 = None
        view_default_213 = torch.ops.aten.view.default(getitem_632, [512, 512, 3, 3]);  getitem_632 = None
        to_dtype_6 = torch.ops.aten.to.dtype(getitem_629, torch.float32);  getitem_629 = None
        to_dtype_7 = torch.ops.aten.to.dtype(relu__default_97, torch.float32);  relu__default_97 = None
        le_scalar_2 = torch.ops.aten.le.Scalar(to_dtype_7, 0);  to_dtype_7 = None
        new_zeros_default_2 = torch.ops.aten.new_zeros.default(to_dtype_6, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_2 = torch.ops.aten.where.self(le_scalar_2, new_zeros_default_2, to_dtype_6);  le_scalar_2 = new_zeros_default_2 = to_dtype_6 = None
        to_dtype_8 = torch.ops.aten.to.dtype(where_self_2, torch.float32);  where_self_2 = None
        native_group_norm_backward_default_2 = torch.ops.aten.native_group_norm_backward.default(to_dtype_8, convolution_default_101, getitem_600, getitem_601, primals_303, 64, 512, 196, 32, [True, True, True]);  to_dtype_8 = convolution_default_101 = getitem_600 = getitem_601 = primals_303 = None
        getitem_635 = native_group_norm_backward_default_2[0]
        getitem_636 = native_group_norm_backward_default_2[1]
        getitem_637 = native_group_norm_backward_default_2[2];  native_group_norm_backward_default_2 = None
        convolution_backward_default_3 = torch.ops.aten.convolution_backward.default(getitem_635, relu__default_96, view_default_203, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_635 = view_default_203 = None
        getitem_638 = convolution_backward_default_3[0]
        getitem_639 = convolution_backward_default_3[1];  convolution_backward_default_3 = None
        view_default_214 = torch.ops.aten.view.default(getitem_639, [1, 512, 2048]);  getitem_639 = None
        native_batch_norm_backward_default_2 = torch.ops.aten.native_batch_norm_backward.default(view_default_214, view_default_202, None, None, None, getitem_597, getitem_598, True, 1e-08, [True, False, False]);  view_default_214 = view_default_202 = getitem_597 = getitem_598 = None
        getitem_641 = native_batch_norm_backward_default_2[0];  native_batch_norm_backward_default_2 = None
        view_default_215 = torch.ops.aten.view.default(getitem_641, [512, 2048, 1, 1]);  getitem_641 = None
        to_dtype_9 = torch.ops.aten.to.dtype(getitem_638, torch.float32);  getitem_638 = None
        to_dtype_10 = torch.ops.aten.to.dtype(relu__default_96, torch.float32);  relu__default_96 = None
        le_scalar_3 = torch.ops.aten.le.Scalar(to_dtype_10, 0);  to_dtype_10 = None
        new_zeros_default_3 = torch.ops.aten.new_zeros.default(to_dtype_9, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_3 = torch.ops.aten.where.self(le_scalar_3, new_zeros_default_3, to_dtype_9);  le_scalar_3 = new_zeros_default_3 = to_dtype_9 = None
        to_dtype_11 = torch.ops.aten.to.dtype(where_self_3, torch.float32);  where_self_3 = None
        native_group_norm_backward_default_3 = torch.ops.aten.native_group_norm_backward.default(to_dtype_11, add_tensor_31, getitem_594, getitem_595, primals_301, 64, 2048, 196, 32, [True, True, True]);  to_dtype_11 = add_tensor_31 = getitem_594 = getitem_595 = primals_301 = None
        getitem_644 = native_group_norm_backward_default_3[0]
        getitem_645 = native_group_norm_backward_default_3[1]
        getitem_646 = native_group_norm_backward_default_3[2];  native_group_norm_backward_default_3 = None
        add_tensor_33 = torch.ops.aten.add.Tensor(getitem_617, getitem_644);  getitem_617 = getitem_644 = None
        convolution_backward_default_4 = torch.ops.aten.convolution_backward.default(add_tensor_33, relu__default_95, view_default_201, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_201 = None
        getitem_647 = convolution_backward_default_4[0]
        getitem_648 = convolution_backward_default_4[1];  convolution_backward_default_4 = None
        view_default_216 = torch.ops.aten.view.default(getitem_648, [1, 2048, 512]);  getitem_648 = None
        native_batch_norm_backward_default_3 = torch.ops.aten.native_batch_norm_backward.default(view_default_216, view_default_200, None, None, None, getitem_591, getitem_592, True, 1e-08, [True, False, False]);  view_default_216 = view_default_200 = getitem_591 = getitem_592 = None
        getitem_650 = native_batch_norm_backward_default_3[0];  native_batch_norm_backward_default_3 = None
        view_default_217 = torch.ops.aten.view.default(getitem_650, [2048, 512, 1, 1]);  getitem_650 = None
        to_dtype_12 = torch.ops.aten.to.dtype(getitem_647, torch.float32);  getitem_647 = None
        to_dtype_13 = torch.ops.aten.to.dtype(relu__default_95, torch.float32);  relu__default_95 = None
        le_scalar_4 = torch.ops.aten.le.Scalar(to_dtype_13, 0);  to_dtype_13 = None
        new_zeros_default_4 = torch.ops.aten.new_zeros.default(to_dtype_12, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_4 = torch.ops.aten.where.self(le_scalar_4, new_zeros_default_4, to_dtype_12);  le_scalar_4 = new_zeros_default_4 = to_dtype_12 = None
        to_dtype_14 = torch.ops.aten.to.dtype(where_self_4, torch.float32);  where_self_4 = None
        native_group_norm_backward_default_4 = torch.ops.aten.native_group_norm_backward.default(to_dtype_14, convolution_default_99, getitem_588, getitem_589, primals_296, 64, 512, 196, 32, [True, True, True]);  to_dtype_14 = convolution_default_99 = getitem_588 = getitem_589 = primals_296 = None
        getitem_653 = native_group_norm_backward_default_4[0]
        getitem_654 = native_group_norm_backward_default_4[1]
        getitem_655 = native_group_norm_backward_default_4[2];  native_group_norm_backward_default_4 = None
        convolution_backward_default_5 = torch.ops.aten.convolution_backward.default(getitem_653, relu__default_94, view_default_199, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_653 = view_default_199 = None
        getitem_656 = convolution_backward_default_5[0]
        getitem_657 = convolution_backward_default_5[1];  convolution_backward_default_5 = None
        view_default_218 = torch.ops.aten.view.default(getitem_657, [1, 512, 4608]);  getitem_657 = None
        native_batch_norm_backward_default_4 = torch.ops.aten.native_batch_norm_backward.default(view_default_218, view_default_198, None, None, None, getitem_585, getitem_586, True, 1e-08, [True, False, False]);  view_default_218 = view_default_198 = getitem_585 = getitem_586 = None
        getitem_659 = native_batch_norm_backward_default_4[0];  native_batch_norm_backward_default_4 = None
        view_default_219 = torch.ops.aten.view.default(getitem_659, [512, 512, 3, 3]);  getitem_659 = None
        to_dtype_15 = torch.ops.aten.to.dtype(getitem_656, torch.float32);  getitem_656 = None
        to_dtype_16 = torch.ops.aten.to.dtype(relu__default_94, torch.float32);  relu__default_94 = None
        le_scalar_5 = torch.ops.aten.le.Scalar(to_dtype_16, 0);  to_dtype_16 = None
        new_zeros_default_5 = torch.ops.aten.new_zeros.default(to_dtype_15, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_5 = torch.ops.aten.where.self(le_scalar_5, new_zeros_default_5, to_dtype_15);  le_scalar_5 = new_zeros_default_5 = to_dtype_15 = None
        to_dtype_17 = torch.ops.aten.to.dtype(where_self_5, torch.float32);  where_self_5 = None
        native_group_norm_backward_default_5 = torch.ops.aten.native_group_norm_backward.default(to_dtype_17, convolution_default_98, getitem_582, getitem_583, primals_294, 64, 512, 196, 32, [True, True, True]);  to_dtype_17 = convolution_default_98 = getitem_582 = getitem_583 = primals_294 = None
        getitem_662 = native_group_norm_backward_default_5[0]
        getitem_663 = native_group_norm_backward_default_5[1]
        getitem_664 = native_group_norm_backward_default_5[2];  native_group_norm_backward_default_5 = None
        convolution_backward_default_6 = torch.ops.aten.convolution_backward.default(getitem_662, relu__default_93, view_default_197, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_662 = view_default_197 = None
        getitem_665 = convolution_backward_default_6[0]
        getitem_666 = convolution_backward_default_6[1];  convolution_backward_default_6 = None
        view_default_220 = torch.ops.aten.view.default(getitem_666, [1, 512, 2048]);  getitem_666 = None
        native_batch_norm_backward_default_5 = torch.ops.aten.native_batch_norm_backward.default(view_default_220, view_default_196, None, None, None, getitem_579, getitem_580, True, 1e-08, [True, False, False]);  view_default_220 = view_default_196 = getitem_579 = getitem_580 = None
        getitem_668 = native_batch_norm_backward_default_5[0];  native_batch_norm_backward_default_5 = None
        view_default_221 = torch.ops.aten.view.default(getitem_668, [512, 2048, 1, 1]);  getitem_668 = None
        to_dtype_18 = torch.ops.aten.to.dtype(getitem_665, torch.float32);  getitem_665 = None
        to_dtype_19 = torch.ops.aten.to.dtype(relu__default_93, torch.float32);  relu__default_93 = None
        le_scalar_6 = torch.ops.aten.le.Scalar(to_dtype_19, 0);  to_dtype_19 = None
        new_zeros_default_6 = torch.ops.aten.new_zeros.default(to_dtype_18, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_6 = torch.ops.aten.where.self(le_scalar_6, new_zeros_default_6, to_dtype_18);  le_scalar_6 = new_zeros_default_6 = to_dtype_18 = None
        to_dtype_20 = torch.ops.aten.to.dtype(where_self_6, torch.float32);  where_self_6 = None
        native_group_norm_backward_default_6 = torch.ops.aten.native_group_norm_backward.default(to_dtype_20, add_tensor_30, getitem_576, getitem_577, primals_292, 64, 2048, 196, 32, [True, True, True]);  to_dtype_20 = add_tensor_30 = getitem_576 = getitem_577 = primals_292 = None
        getitem_671 = native_group_norm_backward_default_6[0]
        getitem_672 = native_group_norm_backward_default_6[1]
        getitem_673 = native_group_norm_backward_default_6[2];  native_group_norm_backward_default_6 = None
        add_tensor_34 = torch.ops.aten.add.Tensor(add_tensor_33, getitem_671);  add_tensor_33 = getitem_671 = None
        convolution_backward_default_7 = torch.ops.aten.convolution_backward.default(add_tensor_34, relu__default_92, view_default_195, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_195 = None
        getitem_674 = convolution_backward_default_7[0]
        getitem_675 = convolution_backward_default_7[1];  convolution_backward_default_7 = None
        view_default_222 = torch.ops.aten.view.default(getitem_675, [1, 2048, 512]);  getitem_675 = None
        native_batch_norm_backward_default_6 = torch.ops.aten.native_batch_norm_backward.default(view_default_222, view_default_194, None, None, None, getitem_573, getitem_574, True, 1e-08, [True, False, False]);  view_default_222 = view_default_194 = getitem_573 = getitem_574 = None
        getitem_677 = native_batch_norm_backward_default_6[0];  native_batch_norm_backward_default_6 = None
        view_default_223 = torch.ops.aten.view.default(getitem_677, [2048, 512, 1, 1]);  getitem_677 = None
        to_dtype_21 = torch.ops.aten.to.dtype(getitem_674, torch.float32);  getitem_674 = None
        to_dtype_22 = torch.ops.aten.to.dtype(relu__default_92, torch.float32);  relu__default_92 = None
        le_scalar_7 = torch.ops.aten.le.Scalar(to_dtype_22, 0);  to_dtype_22 = None
        new_zeros_default_7 = torch.ops.aten.new_zeros.default(to_dtype_21, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_7 = torch.ops.aten.where.self(le_scalar_7, new_zeros_default_7, to_dtype_21);  le_scalar_7 = new_zeros_default_7 = to_dtype_21 = None
        to_dtype_23 = torch.ops.aten.to.dtype(where_self_7, torch.float32);  where_self_7 = None
        native_group_norm_backward_default_7 = torch.ops.aten.native_group_norm_backward.default(to_dtype_23, convolution_default_96, getitem_570, getitem_571, primals_287, 64, 512, 196, 32, [True, True, True]);  to_dtype_23 = convolution_default_96 = getitem_570 = getitem_571 = primals_287 = None
        getitem_680 = native_group_norm_backward_default_7[0]
        getitem_681 = native_group_norm_backward_default_7[1]
        getitem_682 = native_group_norm_backward_default_7[2];  native_group_norm_backward_default_7 = None
        convolution_backward_default_8 = torch.ops.aten.convolution_backward.default(getitem_680, relu__default_91, view_default_193, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_680 = view_default_193 = None
        getitem_683 = convolution_backward_default_8[0]
        getitem_684 = convolution_backward_default_8[1];  convolution_backward_default_8 = None
        view_default_224 = torch.ops.aten.view.default(getitem_684, [1, 512, 4608]);  getitem_684 = None
        native_batch_norm_backward_default_7 = torch.ops.aten.native_batch_norm_backward.default(view_default_224, view_default_192, None, None, None, getitem_567, getitem_568, True, 1e-08, [True, False, False]);  view_default_224 = view_default_192 = getitem_567 = getitem_568 = None
        getitem_686 = native_batch_norm_backward_default_7[0];  native_batch_norm_backward_default_7 = None
        view_default_225 = torch.ops.aten.view.default(getitem_686, [512, 512, 3, 3]);  getitem_686 = None
        to_dtype_24 = torch.ops.aten.to.dtype(getitem_683, torch.float32);  getitem_683 = None
        to_dtype_25 = torch.ops.aten.to.dtype(relu__default_91, torch.float32);  relu__default_91 = None
        le_scalar_8 = torch.ops.aten.le.Scalar(to_dtype_25, 0);  to_dtype_25 = None
        new_zeros_default_8 = torch.ops.aten.new_zeros.default(to_dtype_24, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_8 = torch.ops.aten.where.self(le_scalar_8, new_zeros_default_8, to_dtype_24);  le_scalar_8 = new_zeros_default_8 = to_dtype_24 = None
        to_dtype_26 = torch.ops.aten.to.dtype(where_self_8, torch.float32);  where_self_8 = None
        native_group_norm_backward_default_8 = torch.ops.aten.native_group_norm_backward.default(to_dtype_26, convolution_default_95, getitem_564, getitem_565, primals_285, 64, 512, 784, 32, [True, True, True]);  to_dtype_26 = convolution_default_95 = getitem_564 = getitem_565 = primals_285 = None
        getitem_689 = native_group_norm_backward_default_8[0]
        getitem_690 = native_group_norm_backward_default_8[1]
        getitem_691 = native_group_norm_backward_default_8[2];  native_group_norm_backward_default_8 = None
        convolution_backward_default_9 = torch.ops.aten.convolution_backward.default(getitem_689, relu__default_90, view_default_191, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_689 = view_default_191 = None
        getitem_692 = convolution_backward_default_9[0]
        getitem_693 = convolution_backward_default_9[1];  convolution_backward_default_9 = None
        view_default_226 = torch.ops.aten.view.default(getitem_693, [1, 512, 1024]);  getitem_693 = None
        native_batch_norm_backward_default_8 = torch.ops.aten.native_batch_norm_backward.default(view_default_226, view_default_190, None, None, None, getitem_561, getitem_562, True, 1e-08, [True, False, False]);  view_default_226 = view_default_190 = getitem_561 = getitem_562 = None
        getitem_695 = native_batch_norm_backward_default_8[0];  native_batch_norm_backward_default_8 = None
        view_default_227 = torch.ops.aten.view.default(getitem_695, [512, 1024, 1, 1]);  getitem_695 = None
        convolution_backward_default_10 = torch.ops.aten.convolution_backward.default(add_tensor_34, relu__default_90, view_default_189, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_34 = view_default_189 = None
        getitem_698 = convolution_backward_default_10[0]
        getitem_699 = convolution_backward_default_10[1];  convolution_backward_default_10 = None
        add_tensor_35 = torch.ops.aten.add.Tensor(getitem_692, getitem_698);  getitem_692 = getitem_698 = None
        view_default_228 = torch.ops.aten.view.default(getitem_699, [1, 2048, 1024]);  getitem_699 = None
        native_batch_norm_backward_default_9 = torch.ops.aten.native_batch_norm_backward.default(view_default_228, view_default_188, None, None, None, getitem_558, getitem_559, True, 1e-08, [True, False, False]);  view_default_228 = view_default_188 = getitem_558 = getitem_559 = None
        getitem_701 = native_batch_norm_backward_default_9[0];  native_batch_norm_backward_default_9 = None
        view_default_229 = torch.ops.aten.view.default(getitem_701, [2048, 1024, 1, 1]);  getitem_701 = None
        to_dtype_27 = torch.ops.aten.to.dtype(add_tensor_35, torch.float32);  add_tensor_35 = None
        to_dtype_28 = torch.ops.aten.to.dtype(relu__default_90, torch.float32);  relu__default_90 = None
        le_scalar_9 = torch.ops.aten.le.Scalar(to_dtype_28, 0);  to_dtype_28 = None
        new_zeros_default_9 = torch.ops.aten.new_zeros.default(to_dtype_27, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_9 = torch.ops.aten.where.self(le_scalar_9, new_zeros_default_9, to_dtype_27);  le_scalar_9 = new_zeros_default_9 = to_dtype_27 = None
        to_dtype_29 = torch.ops.aten.to.dtype(where_self_9, torch.float32);  where_self_9 = None
        native_group_norm_backward_default_9 = torch.ops.aten.native_group_norm_backward.default(to_dtype_29, add_tensor_29, getitem_555, getitem_556, primals_283, 64, 1024, 784, 32, [True, True, True]);  to_dtype_29 = add_tensor_29 = getitem_555 = getitem_556 = primals_283 = None
        getitem_704 = native_group_norm_backward_default_9[0]
        getitem_705 = native_group_norm_backward_default_9[1]
        getitem_706 = native_group_norm_backward_default_9[2];  native_group_norm_backward_default_9 = None
        convolution_backward_default_11 = torch.ops.aten.convolution_backward.default(getitem_704, relu__default_89, view_default_187, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_187 = None
        getitem_707 = convolution_backward_default_11[0]
        getitem_708 = convolution_backward_default_11[1];  convolution_backward_default_11 = None
        view_default_230 = torch.ops.aten.view.default(getitem_708, [1, 1024, 256]);  getitem_708 = None
        native_batch_norm_backward_default_10 = torch.ops.aten.native_batch_norm_backward.default(view_default_230, view_default_186, None, None, None, getitem_552, getitem_553, True, 1e-08, [True, False, False]);  view_default_230 = view_default_186 = getitem_552 = getitem_553 = None
        getitem_710 = native_batch_norm_backward_default_10[0];  native_batch_norm_backward_default_10 = None
        view_default_231 = torch.ops.aten.view.default(getitem_710, [1024, 256, 1, 1]);  getitem_710 = None
        to_dtype_30 = torch.ops.aten.to.dtype(getitem_707, torch.float32);  getitem_707 = None
        to_dtype_31 = torch.ops.aten.to.dtype(relu__default_89, torch.float32);  relu__default_89 = None
        le_scalar_10 = torch.ops.aten.le.Scalar(to_dtype_31, 0);  to_dtype_31 = None
        new_zeros_default_10 = torch.ops.aten.new_zeros.default(to_dtype_30, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_10 = torch.ops.aten.where.self(le_scalar_10, new_zeros_default_10, to_dtype_30);  le_scalar_10 = new_zeros_default_10 = to_dtype_30 = None
        to_dtype_32 = torch.ops.aten.to.dtype(where_self_10, torch.float32);  where_self_10 = None
        native_group_norm_backward_default_10 = torch.ops.aten.native_group_norm_backward.default(to_dtype_32, convolution_default_92, getitem_549, getitem_550, primals_205, 64, 256, 784, 32, [True, True, True]);  to_dtype_32 = convolution_default_92 = getitem_549 = getitem_550 = primals_205 = None
        getitem_713 = native_group_norm_backward_default_10[0]
        getitem_714 = native_group_norm_backward_default_10[1]
        getitem_715 = native_group_norm_backward_default_10[2];  native_group_norm_backward_default_10 = None
        convolution_backward_default_12 = torch.ops.aten.convolution_backward.default(getitem_713, relu__default_88, view_default_185, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_713 = view_default_185 = None
        getitem_716 = convolution_backward_default_12[0]
        getitem_717 = convolution_backward_default_12[1];  convolution_backward_default_12 = None
        view_default_232 = torch.ops.aten.view.default(getitem_717, [1, 256, 2304]);  getitem_717 = None
        native_batch_norm_backward_default_11 = torch.ops.aten.native_batch_norm_backward.default(view_default_232, view_default_184, None, None, None, getitem_546, getitem_547, True, 1e-08, [True, False, False]);  view_default_232 = view_default_184 = getitem_546 = getitem_547 = None
        getitem_719 = native_batch_norm_backward_default_11[0];  native_batch_norm_backward_default_11 = None
        view_default_233 = torch.ops.aten.view.default(getitem_719, [256, 256, 3, 3]);  getitem_719 = None
        to_dtype_33 = torch.ops.aten.to.dtype(getitem_716, torch.float32);  getitem_716 = None
        to_dtype_34 = torch.ops.aten.to.dtype(relu__default_88, torch.float32);  relu__default_88 = None
        le_scalar_11 = torch.ops.aten.le.Scalar(to_dtype_34, 0);  to_dtype_34 = None
        new_zeros_default_11 = torch.ops.aten.new_zeros.default(to_dtype_33, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_11 = torch.ops.aten.where.self(le_scalar_11, new_zeros_default_11, to_dtype_33);  le_scalar_11 = new_zeros_default_11 = to_dtype_33 = None
        to_dtype_35 = torch.ops.aten.to.dtype(where_self_11, torch.float32);  where_self_11 = None
        native_group_norm_backward_default_11 = torch.ops.aten.native_group_norm_backward.default(to_dtype_35, convolution_default_91, getitem_543, getitem_544, primals_203, 64, 256, 784, 32, [True, True, True]);  to_dtype_35 = convolution_default_91 = getitem_543 = getitem_544 = primals_203 = None
        getitem_722 = native_group_norm_backward_default_11[0]
        getitem_723 = native_group_norm_backward_default_11[1]
        getitem_724 = native_group_norm_backward_default_11[2];  native_group_norm_backward_default_11 = None
        convolution_backward_default_13 = torch.ops.aten.convolution_backward.default(getitem_722, relu__default_87, view_default_183, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_722 = view_default_183 = None
        getitem_725 = convolution_backward_default_13[0]
        getitem_726 = convolution_backward_default_13[1];  convolution_backward_default_13 = None
        view_default_234 = torch.ops.aten.view.default(getitem_726, [1, 256, 1024]);  getitem_726 = None
        native_batch_norm_backward_default_12 = torch.ops.aten.native_batch_norm_backward.default(view_default_234, view_default_182, None, None, None, getitem_540, getitem_541, True, 1e-08, [True, False, False]);  view_default_234 = view_default_182 = getitem_540 = getitem_541 = None
        getitem_728 = native_batch_norm_backward_default_12[0];  native_batch_norm_backward_default_12 = None
        view_default_235 = torch.ops.aten.view.default(getitem_728, [256, 1024, 1, 1]);  getitem_728 = None
        to_dtype_36 = torch.ops.aten.to.dtype(getitem_725, torch.float32);  getitem_725 = None
        to_dtype_37 = torch.ops.aten.to.dtype(relu__default_87, torch.float32);  relu__default_87 = None
        le_scalar_12 = torch.ops.aten.le.Scalar(to_dtype_37, 0);  to_dtype_37 = None
        new_zeros_default_12 = torch.ops.aten.new_zeros.default(to_dtype_36, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_12 = torch.ops.aten.where.self(le_scalar_12, new_zeros_default_12, to_dtype_36);  le_scalar_12 = new_zeros_default_12 = to_dtype_36 = None
        to_dtype_38 = torch.ops.aten.to.dtype(where_self_12, torch.float32);  where_self_12 = None
        native_group_norm_backward_default_12 = torch.ops.aten.native_group_norm_backward.default(to_dtype_38, add_tensor_28, getitem_537, getitem_538, primals_201, 64, 1024, 784, 32, [True, True, True]);  to_dtype_38 = add_tensor_28 = getitem_537 = getitem_538 = primals_201 = None
        getitem_731 = native_group_norm_backward_default_12[0]
        getitem_732 = native_group_norm_backward_default_12[1]
        getitem_733 = native_group_norm_backward_default_12[2];  native_group_norm_backward_default_12 = None
        add_tensor_36 = torch.ops.aten.add.Tensor(getitem_704, getitem_731);  getitem_704 = getitem_731 = None
        convolution_backward_default_14 = torch.ops.aten.convolution_backward.default(add_tensor_36, relu__default_86, view_default_181, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_181 = None
        getitem_734 = convolution_backward_default_14[0]
        getitem_735 = convolution_backward_default_14[1];  convolution_backward_default_14 = None
        view_default_236 = torch.ops.aten.view.default(getitem_735, [1, 1024, 256]);  getitem_735 = None
        native_batch_norm_backward_default_13 = torch.ops.aten.native_batch_norm_backward.default(view_default_236, view_default_180, None, None, None, getitem_534, getitem_535, True, 1e-08, [True, False, False]);  view_default_236 = view_default_180 = getitem_534 = getitem_535 = None
        getitem_737 = native_batch_norm_backward_default_13[0];  native_batch_norm_backward_default_13 = None
        view_default_237 = torch.ops.aten.view.default(getitem_737, [1024, 256, 1, 1]);  getitem_737 = None
        to_dtype_39 = torch.ops.aten.to.dtype(getitem_734, torch.float32);  getitem_734 = None
        to_dtype_40 = torch.ops.aten.to.dtype(relu__default_86, torch.float32);  relu__default_86 = None
        le_scalar_13 = torch.ops.aten.le.Scalar(to_dtype_40, 0);  to_dtype_40 = None
        new_zeros_default_13 = torch.ops.aten.new_zeros.default(to_dtype_39, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_13 = torch.ops.aten.where.self(le_scalar_13, new_zeros_default_13, to_dtype_39);  le_scalar_13 = new_zeros_default_13 = to_dtype_39 = None
        to_dtype_41 = torch.ops.aten.to.dtype(where_self_13, torch.float32);  where_self_13 = None
        native_group_norm_backward_default_13 = torch.ops.aten.native_group_norm_backward.default(to_dtype_41, convolution_default_89, getitem_531, getitem_532, primals_196, 64, 256, 784, 32, [True, True, True]);  to_dtype_41 = convolution_default_89 = getitem_531 = getitem_532 = primals_196 = None
        getitem_740 = native_group_norm_backward_default_13[0]
        getitem_741 = native_group_norm_backward_default_13[1]
        getitem_742 = native_group_norm_backward_default_13[2];  native_group_norm_backward_default_13 = None
        convolution_backward_default_15 = torch.ops.aten.convolution_backward.default(getitem_740, relu__default_85, view_default_179, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_740 = view_default_179 = None
        getitem_743 = convolution_backward_default_15[0]
        getitem_744 = convolution_backward_default_15[1];  convolution_backward_default_15 = None
        view_default_238 = torch.ops.aten.view.default(getitem_744, [1, 256, 2304]);  getitem_744 = None
        native_batch_norm_backward_default_14 = torch.ops.aten.native_batch_norm_backward.default(view_default_238, view_default_178, None, None, None, getitem_528, getitem_529, True, 1e-08, [True, False, False]);  view_default_238 = view_default_178 = getitem_528 = getitem_529 = None
        getitem_746 = native_batch_norm_backward_default_14[0];  native_batch_norm_backward_default_14 = None
        view_default_239 = torch.ops.aten.view.default(getitem_746, [256, 256, 3, 3]);  getitem_746 = None
        to_dtype_42 = torch.ops.aten.to.dtype(getitem_743, torch.float32);  getitem_743 = None
        to_dtype_43 = torch.ops.aten.to.dtype(relu__default_85, torch.float32);  relu__default_85 = None
        le_scalar_14 = torch.ops.aten.le.Scalar(to_dtype_43, 0);  to_dtype_43 = None
        new_zeros_default_14 = torch.ops.aten.new_zeros.default(to_dtype_42, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_14 = torch.ops.aten.where.self(le_scalar_14, new_zeros_default_14, to_dtype_42);  le_scalar_14 = new_zeros_default_14 = to_dtype_42 = None
        to_dtype_44 = torch.ops.aten.to.dtype(where_self_14, torch.float32);  where_self_14 = None
        native_group_norm_backward_default_14 = torch.ops.aten.native_group_norm_backward.default(to_dtype_44, convolution_default_88, getitem_525, getitem_526, primals_194, 64, 256, 784, 32, [True, True, True]);  to_dtype_44 = convolution_default_88 = getitem_525 = getitem_526 = primals_194 = None
        getitem_749 = native_group_norm_backward_default_14[0]
        getitem_750 = native_group_norm_backward_default_14[1]
        getitem_751 = native_group_norm_backward_default_14[2];  native_group_norm_backward_default_14 = None
        convolution_backward_default_16 = torch.ops.aten.convolution_backward.default(getitem_749, relu__default_84, view_default_177, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_749 = view_default_177 = None
        getitem_752 = convolution_backward_default_16[0]
        getitem_753 = convolution_backward_default_16[1];  convolution_backward_default_16 = None
        view_default_240 = torch.ops.aten.view.default(getitem_753, [1, 256, 1024]);  getitem_753 = None
        native_batch_norm_backward_default_15 = torch.ops.aten.native_batch_norm_backward.default(view_default_240, view_default_176, None, None, None, getitem_522, getitem_523, True, 1e-08, [True, False, False]);  view_default_240 = view_default_176 = getitem_522 = getitem_523 = None
        getitem_755 = native_batch_norm_backward_default_15[0];  native_batch_norm_backward_default_15 = None
        view_default_241 = torch.ops.aten.view.default(getitem_755, [256, 1024, 1, 1]);  getitem_755 = None
        to_dtype_45 = torch.ops.aten.to.dtype(getitem_752, torch.float32);  getitem_752 = None
        to_dtype_46 = torch.ops.aten.to.dtype(relu__default_84, torch.float32);  relu__default_84 = None
        le_scalar_15 = torch.ops.aten.le.Scalar(to_dtype_46, 0);  to_dtype_46 = None
        new_zeros_default_15 = torch.ops.aten.new_zeros.default(to_dtype_45, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_15 = torch.ops.aten.where.self(le_scalar_15, new_zeros_default_15, to_dtype_45);  le_scalar_15 = new_zeros_default_15 = to_dtype_45 = None
        to_dtype_47 = torch.ops.aten.to.dtype(where_self_15, torch.float32);  where_self_15 = None
        native_group_norm_backward_default_15 = torch.ops.aten.native_group_norm_backward.default(to_dtype_47, add_tensor_27, getitem_519, getitem_520, primals_192, 64, 1024, 784, 32, [True, True, True]);  to_dtype_47 = add_tensor_27 = getitem_519 = getitem_520 = primals_192 = None
        getitem_758 = native_group_norm_backward_default_15[0]
        getitem_759 = native_group_norm_backward_default_15[1]
        getitem_760 = native_group_norm_backward_default_15[2];  native_group_norm_backward_default_15 = None
        add_tensor_37 = torch.ops.aten.add.Tensor(add_tensor_36, getitem_758);  add_tensor_36 = getitem_758 = None
        convolution_backward_default_17 = torch.ops.aten.convolution_backward.default(add_tensor_37, relu__default_83, view_default_175, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_175 = None
        getitem_761 = convolution_backward_default_17[0]
        getitem_762 = convolution_backward_default_17[1];  convolution_backward_default_17 = None
        view_default_242 = torch.ops.aten.view.default(getitem_762, [1, 1024, 256]);  getitem_762 = None
        native_batch_norm_backward_default_16 = torch.ops.aten.native_batch_norm_backward.default(view_default_242, view_default_174, None, None, None, getitem_516, getitem_517, True, 1e-08, [True, False, False]);  view_default_242 = view_default_174 = getitem_516 = getitem_517 = None
        getitem_764 = native_batch_norm_backward_default_16[0];  native_batch_norm_backward_default_16 = None
        view_default_243 = torch.ops.aten.view.default(getitem_764, [1024, 256, 1, 1]);  getitem_764 = None
        to_dtype_48 = torch.ops.aten.to.dtype(getitem_761, torch.float32);  getitem_761 = None
        to_dtype_49 = torch.ops.aten.to.dtype(relu__default_83, torch.float32);  relu__default_83 = None
        le_scalar_16 = torch.ops.aten.le.Scalar(to_dtype_49, 0);  to_dtype_49 = None
        new_zeros_default_16 = torch.ops.aten.new_zeros.default(to_dtype_48, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_16 = torch.ops.aten.where.self(le_scalar_16, new_zeros_default_16, to_dtype_48);  le_scalar_16 = new_zeros_default_16 = to_dtype_48 = None
        to_dtype_50 = torch.ops.aten.to.dtype(where_self_16, torch.float32);  where_self_16 = None
        native_group_norm_backward_default_16 = torch.ops.aten.native_group_norm_backward.default(to_dtype_50, convolution_default_86, getitem_513, getitem_514, primals_187, 64, 256, 784, 32, [True, True, True]);  to_dtype_50 = convolution_default_86 = getitem_513 = getitem_514 = primals_187 = None
        getitem_767 = native_group_norm_backward_default_16[0]
        getitem_768 = native_group_norm_backward_default_16[1]
        getitem_769 = native_group_norm_backward_default_16[2];  native_group_norm_backward_default_16 = None
        convolution_backward_default_18 = torch.ops.aten.convolution_backward.default(getitem_767, relu__default_82, view_default_173, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_767 = view_default_173 = None
        getitem_770 = convolution_backward_default_18[0]
        getitem_771 = convolution_backward_default_18[1];  convolution_backward_default_18 = None
        view_default_244 = torch.ops.aten.view.default(getitem_771, [1, 256, 2304]);  getitem_771 = None
        native_batch_norm_backward_default_17 = torch.ops.aten.native_batch_norm_backward.default(view_default_244, view_default_172, None, None, None, getitem_510, getitem_511, True, 1e-08, [True, False, False]);  view_default_244 = view_default_172 = getitem_510 = getitem_511 = None
        getitem_773 = native_batch_norm_backward_default_17[0];  native_batch_norm_backward_default_17 = None
        view_default_245 = torch.ops.aten.view.default(getitem_773, [256, 256, 3, 3]);  getitem_773 = None
        to_dtype_51 = torch.ops.aten.to.dtype(getitem_770, torch.float32);  getitem_770 = None
        to_dtype_52 = torch.ops.aten.to.dtype(relu__default_82, torch.float32);  relu__default_82 = None
        le_scalar_17 = torch.ops.aten.le.Scalar(to_dtype_52, 0);  to_dtype_52 = None
        new_zeros_default_17 = torch.ops.aten.new_zeros.default(to_dtype_51, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_17 = torch.ops.aten.where.self(le_scalar_17, new_zeros_default_17, to_dtype_51);  le_scalar_17 = new_zeros_default_17 = to_dtype_51 = None
        to_dtype_53 = torch.ops.aten.to.dtype(where_self_17, torch.float32);  where_self_17 = None
        native_group_norm_backward_default_17 = torch.ops.aten.native_group_norm_backward.default(to_dtype_53, convolution_default_85, getitem_507, getitem_508, primals_185, 64, 256, 784, 32, [True, True, True]);  to_dtype_53 = convolution_default_85 = getitem_507 = getitem_508 = primals_185 = None
        getitem_776 = native_group_norm_backward_default_17[0]
        getitem_777 = native_group_norm_backward_default_17[1]
        getitem_778 = native_group_norm_backward_default_17[2];  native_group_norm_backward_default_17 = None
        convolution_backward_default_19 = torch.ops.aten.convolution_backward.default(getitem_776, relu__default_81, view_default_171, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_776 = view_default_171 = None
        getitem_779 = convolution_backward_default_19[0]
        getitem_780 = convolution_backward_default_19[1];  convolution_backward_default_19 = None
        view_default_246 = torch.ops.aten.view.default(getitem_780, [1, 256, 1024]);  getitem_780 = None
        native_batch_norm_backward_default_18 = torch.ops.aten.native_batch_norm_backward.default(view_default_246, view_default_170, None, None, None, getitem_504, getitem_505, True, 1e-08, [True, False, False]);  view_default_246 = view_default_170 = getitem_504 = getitem_505 = None
        getitem_782 = native_batch_norm_backward_default_18[0];  native_batch_norm_backward_default_18 = None
        view_default_247 = torch.ops.aten.view.default(getitem_782, [256, 1024, 1, 1]);  getitem_782 = None
        to_dtype_54 = torch.ops.aten.to.dtype(getitem_779, torch.float32);  getitem_779 = None
        to_dtype_55 = torch.ops.aten.to.dtype(relu__default_81, torch.float32);  relu__default_81 = None
        le_scalar_18 = torch.ops.aten.le.Scalar(to_dtype_55, 0);  to_dtype_55 = None
        new_zeros_default_18 = torch.ops.aten.new_zeros.default(to_dtype_54, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_18 = torch.ops.aten.where.self(le_scalar_18, new_zeros_default_18, to_dtype_54);  le_scalar_18 = new_zeros_default_18 = to_dtype_54 = None
        to_dtype_56 = torch.ops.aten.to.dtype(where_self_18, torch.float32);  where_self_18 = None
        native_group_norm_backward_default_18 = torch.ops.aten.native_group_norm_backward.default(to_dtype_56, add_tensor_26, getitem_501, getitem_502, primals_183, 64, 1024, 784, 32, [True, True, True]);  to_dtype_56 = add_tensor_26 = getitem_501 = getitem_502 = primals_183 = None
        getitem_785 = native_group_norm_backward_default_18[0]
        getitem_786 = native_group_norm_backward_default_18[1]
        getitem_787 = native_group_norm_backward_default_18[2];  native_group_norm_backward_default_18 = None
        add_tensor_38 = torch.ops.aten.add.Tensor(add_tensor_37, getitem_785);  add_tensor_37 = getitem_785 = None
        convolution_backward_default_20 = torch.ops.aten.convolution_backward.default(add_tensor_38, relu__default_80, view_default_169, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_169 = None
        getitem_788 = convolution_backward_default_20[0]
        getitem_789 = convolution_backward_default_20[1];  convolution_backward_default_20 = None
        view_default_248 = torch.ops.aten.view.default(getitem_789, [1, 1024, 256]);  getitem_789 = None
        native_batch_norm_backward_default_19 = torch.ops.aten.native_batch_norm_backward.default(view_default_248, view_default_168, None, None, None, getitem_498, getitem_499, True, 1e-08, [True, False, False]);  view_default_248 = view_default_168 = getitem_498 = getitem_499 = None
        getitem_791 = native_batch_norm_backward_default_19[0];  native_batch_norm_backward_default_19 = None
        view_default_249 = torch.ops.aten.view.default(getitem_791, [1024, 256, 1, 1]);  getitem_791 = None
        to_dtype_57 = torch.ops.aten.to.dtype(getitem_788, torch.float32);  getitem_788 = None
        to_dtype_58 = torch.ops.aten.to.dtype(relu__default_80, torch.float32);  relu__default_80 = None
        le_scalar_19 = torch.ops.aten.le.Scalar(to_dtype_58, 0);  to_dtype_58 = None
        new_zeros_default_19 = torch.ops.aten.new_zeros.default(to_dtype_57, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_19 = torch.ops.aten.where.self(le_scalar_19, new_zeros_default_19, to_dtype_57);  le_scalar_19 = new_zeros_default_19 = to_dtype_57 = None
        to_dtype_59 = torch.ops.aten.to.dtype(where_self_19, torch.float32);  where_self_19 = None
        native_group_norm_backward_default_19 = torch.ops.aten.native_group_norm_backward.default(to_dtype_59, convolution_default_83, getitem_495, getitem_496, primals_169, 64, 256, 784, 32, [True, True, True]);  to_dtype_59 = convolution_default_83 = getitem_495 = getitem_496 = primals_169 = None
        getitem_794 = native_group_norm_backward_default_19[0]
        getitem_795 = native_group_norm_backward_default_19[1]
        getitem_796 = native_group_norm_backward_default_19[2];  native_group_norm_backward_default_19 = None
        convolution_backward_default_21 = torch.ops.aten.convolution_backward.default(getitem_794, relu__default_79, view_default_167, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_794 = view_default_167 = None
        getitem_797 = convolution_backward_default_21[0]
        getitem_798 = convolution_backward_default_21[1];  convolution_backward_default_21 = None
        view_default_250 = torch.ops.aten.view.default(getitem_798, [1, 256, 2304]);  getitem_798 = None
        native_batch_norm_backward_default_20 = torch.ops.aten.native_batch_norm_backward.default(view_default_250, view_default_166, None, None, None, getitem_492, getitem_493, True, 1e-08, [True, False, False]);  view_default_250 = view_default_166 = getitem_492 = getitem_493 = None
        getitem_800 = native_batch_norm_backward_default_20[0];  native_batch_norm_backward_default_20 = None
        view_default_251 = torch.ops.aten.view.default(getitem_800, [256, 256, 3, 3]);  getitem_800 = None
        to_dtype_60 = torch.ops.aten.to.dtype(getitem_797, torch.float32);  getitem_797 = None
        to_dtype_61 = torch.ops.aten.to.dtype(relu__default_79, torch.float32);  relu__default_79 = None
        le_scalar_20 = torch.ops.aten.le.Scalar(to_dtype_61, 0);  to_dtype_61 = None
        new_zeros_default_20 = torch.ops.aten.new_zeros.default(to_dtype_60, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_20 = torch.ops.aten.where.self(le_scalar_20, new_zeros_default_20, to_dtype_60);  le_scalar_20 = new_zeros_default_20 = to_dtype_60 = None
        to_dtype_62 = torch.ops.aten.to.dtype(where_self_20, torch.float32);  where_self_20 = None
        native_group_norm_backward_default_20 = torch.ops.aten.native_group_norm_backward.default(to_dtype_62, convolution_default_82, getitem_489, getitem_490, primals_167, 64, 256, 784, 32, [True, True, True]);  to_dtype_62 = convolution_default_82 = getitem_489 = getitem_490 = primals_167 = None
        getitem_803 = native_group_norm_backward_default_20[0]
        getitem_804 = native_group_norm_backward_default_20[1]
        getitem_805 = native_group_norm_backward_default_20[2];  native_group_norm_backward_default_20 = None
        convolution_backward_default_22 = torch.ops.aten.convolution_backward.default(getitem_803, relu__default_78, view_default_165, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_803 = view_default_165 = None
        getitem_806 = convolution_backward_default_22[0]
        getitem_807 = convolution_backward_default_22[1];  convolution_backward_default_22 = None
        view_default_252 = torch.ops.aten.view.default(getitem_807, [1, 256, 1024]);  getitem_807 = None
        native_batch_norm_backward_default_21 = torch.ops.aten.native_batch_norm_backward.default(view_default_252, view_default_164, None, None, None, getitem_486, getitem_487, True, 1e-08, [True, False, False]);  view_default_252 = view_default_164 = getitem_486 = getitem_487 = None
        getitem_809 = native_batch_norm_backward_default_21[0];  native_batch_norm_backward_default_21 = None
        view_default_253 = torch.ops.aten.view.default(getitem_809, [256, 1024, 1, 1]);  getitem_809 = None
        to_dtype_63 = torch.ops.aten.to.dtype(getitem_806, torch.float32);  getitem_806 = None
        to_dtype_64 = torch.ops.aten.to.dtype(relu__default_78, torch.float32);  relu__default_78 = None
        le_scalar_21 = torch.ops.aten.le.Scalar(to_dtype_64, 0);  to_dtype_64 = None
        new_zeros_default_21 = torch.ops.aten.new_zeros.default(to_dtype_63, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_21 = torch.ops.aten.where.self(le_scalar_21, new_zeros_default_21, to_dtype_63);  le_scalar_21 = new_zeros_default_21 = to_dtype_63 = None
        to_dtype_65 = torch.ops.aten.to.dtype(where_self_21, torch.float32);  where_self_21 = None
        native_group_norm_backward_default_21 = torch.ops.aten.native_group_norm_backward.default(to_dtype_65, add_tensor_25, getitem_483, getitem_484, primals_165, 64, 1024, 784, 32, [True, True, True]);  to_dtype_65 = add_tensor_25 = getitem_483 = getitem_484 = primals_165 = None
        getitem_812 = native_group_norm_backward_default_21[0]
        getitem_813 = native_group_norm_backward_default_21[1]
        getitem_814 = native_group_norm_backward_default_21[2];  native_group_norm_backward_default_21 = None
        add_tensor_39 = torch.ops.aten.add.Tensor(add_tensor_38, getitem_812);  add_tensor_38 = getitem_812 = None
        convolution_backward_default_23 = torch.ops.aten.convolution_backward.default(add_tensor_39, relu__default_77, view_default_163, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_163 = None
        getitem_815 = convolution_backward_default_23[0]
        getitem_816 = convolution_backward_default_23[1];  convolution_backward_default_23 = None
        view_default_254 = torch.ops.aten.view.default(getitem_816, [1, 1024, 256]);  getitem_816 = None
        native_batch_norm_backward_default_22 = torch.ops.aten.native_batch_norm_backward.default(view_default_254, view_default_162, None, None, None, getitem_480, getitem_481, True, 1e-08, [True, False, False]);  view_default_254 = view_default_162 = getitem_480 = getitem_481 = None
        getitem_818 = native_batch_norm_backward_default_22[0];  native_batch_norm_backward_default_22 = None
        view_default_255 = torch.ops.aten.view.default(getitem_818, [1024, 256, 1, 1]);  getitem_818 = None
        to_dtype_66 = torch.ops.aten.to.dtype(getitem_815, torch.float32);  getitem_815 = None
        to_dtype_67 = torch.ops.aten.to.dtype(relu__default_77, torch.float32);  relu__default_77 = None
        le_scalar_22 = torch.ops.aten.le.Scalar(to_dtype_67, 0);  to_dtype_67 = None
        new_zeros_default_22 = torch.ops.aten.new_zeros.default(to_dtype_66, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_22 = torch.ops.aten.where.self(le_scalar_22, new_zeros_default_22, to_dtype_66);  le_scalar_22 = new_zeros_default_22 = to_dtype_66 = None
        to_dtype_68 = torch.ops.aten.to.dtype(where_self_22, torch.float32);  where_self_22 = None
        native_group_norm_backward_default_22 = torch.ops.aten.native_group_norm_backward.default(to_dtype_68, convolution_default_80, getitem_477, getitem_478, primals_160, 64, 256, 784, 32, [True, True, True]);  to_dtype_68 = convolution_default_80 = getitem_477 = getitem_478 = primals_160 = None
        getitem_821 = native_group_norm_backward_default_22[0]
        getitem_822 = native_group_norm_backward_default_22[1]
        getitem_823 = native_group_norm_backward_default_22[2];  native_group_norm_backward_default_22 = None
        convolution_backward_default_24 = torch.ops.aten.convolution_backward.default(getitem_821, relu__default_76, view_default_161, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_821 = view_default_161 = None
        getitem_824 = convolution_backward_default_24[0]
        getitem_825 = convolution_backward_default_24[1];  convolution_backward_default_24 = None
        view_default_256 = torch.ops.aten.view.default(getitem_825, [1, 256, 2304]);  getitem_825 = None
        native_batch_norm_backward_default_23 = torch.ops.aten.native_batch_norm_backward.default(view_default_256, view_default_160, None, None, None, getitem_474, getitem_475, True, 1e-08, [True, False, False]);  view_default_256 = view_default_160 = getitem_474 = getitem_475 = None
        getitem_827 = native_batch_norm_backward_default_23[0];  native_batch_norm_backward_default_23 = None
        view_default_257 = torch.ops.aten.view.default(getitem_827, [256, 256, 3, 3]);  getitem_827 = None
        to_dtype_69 = torch.ops.aten.to.dtype(getitem_824, torch.float32);  getitem_824 = None
        to_dtype_70 = torch.ops.aten.to.dtype(relu__default_76, torch.float32);  relu__default_76 = None
        le_scalar_23 = torch.ops.aten.le.Scalar(to_dtype_70, 0);  to_dtype_70 = None
        new_zeros_default_23 = torch.ops.aten.new_zeros.default(to_dtype_69, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_23 = torch.ops.aten.where.self(le_scalar_23, new_zeros_default_23, to_dtype_69);  le_scalar_23 = new_zeros_default_23 = to_dtype_69 = None
        to_dtype_71 = torch.ops.aten.to.dtype(where_self_23, torch.float32);  where_self_23 = None
        native_group_norm_backward_default_23 = torch.ops.aten.native_group_norm_backward.default(to_dtype_71, convolution_default_79, getitem_471, getitem_472, primals_158, 64, 256, 784, 32, [True, True, True]);  to_dtype_71 = convolution_default_79 = getitem_471 = getitem_472 = primals_158 = None
        getitem_830 = native_group_norm_backward_default_23[0]
        getitem_831 = native_group_norm_backward_default_23[1]
        getitem_832 = native_group_norm_backward_default_23[2];  native_group_norm_backward_default_23 = None
        convolution_backward_default_25 = torch.ops.aten.convolution_backward.default(getitem_830, relu__default_75, view_default_159, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_830 = view_default_159 = None
        getitem_833 = convolution_backward_default_25[0]
        getitem_834 = convolution_backward_default_25[1];  convolution_backward_default_25 = None
        view_default_258 = torch.ops.aten.view.default(getitem_834, [1, 256, 1024]);  getitem_834 = None
        native_batch_norm_backward_default_24 = torch.ops.aten.native_batch_norm_backward.default(view_default_258, view_default_158, None, None, None, getitem_468, getitem_469, True, 1e-08, [True, False, False]);  view_default_258 = view_default_158 = getitem_468 = getitem_469 = None
        getitem_836 = native_batch_norm_backward_default_24[0];  native_batch_norm_backward_default_24 = None
        view_default_259 = torch.ops.aten.view.default(getitem_836, [256, 1024, 1, 1]);  getitem_836 = None
        to_dtype_72 = torch.ops.aten.to.dtype(getitem_833, torch.float32);  getitem_833 = None
        to_dtype_73 = torch.ops.aten.to.dtype(relu__default_75, torch.float32);  relu__default_75 = None
        le_scalar_24 = torch.ops.aten.le.Scalar(to_dtype_73, 0);  to_dtype_73 = None
        new_zeros_default_24 = torch.ops.aten.new_zeros.default(to_dtype_72, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_24 = torch.ops.aten.where.self(le_scalar_24, new_zeros_default_24, to_dtype_72);  le_scalar_24 = new_zeros_default_24 = to_dtype_72 = None
        to_dtype_74 = torch.ops.aten.to.dtype(where_self_24, torch.float32);  where_self_24 = None
        native_group_norm_backward_default_24 = torch.ops.aten.native_group_norm_backward.default(to_dtype_74, add_tensor_24, getitem_465, getitem_466, primals_156, 64, 1024, 784, 32, [True, True, True]);  to_dtype_74 = add_tensor_24 = getitem_465 = getitem_466 = primals_156 = None
        getitem_839 = native_group_norm_backward_default_24[0]
        getitem_840 = native_group_norm_backward_default_24[1]
        getitem_841 = native_group_norm_backward_default_24[2];  native_group_norm_backward_default_24 = None
        add_tensor_40 = torch.ops.aten.add.Tensor(add_tensor_39, getitem_839);  add_tensor_39 = getitem_839 = None
        convolution_backward_default_26 = torch.ops.aten.convolution_backward.default(add_tensor_40, relu__default_74, view_default_157, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_157 = None
        getitem_842 = convolution_backward_default_26[0]
        getitem_843 = convolution_backward_default_26[1];  convolution_backward_default_26 = None
        view_default_260 = torch.ops.aten.view.default(getitem_843, [1, 1024, 256]);  getitem_843 = None
        native_batch_norm_backward_default_25 = torch.ops.aten.native_batch_norm_backward.default(view_default_260, view_default_156, None, None, None, getitem_462, getitem_463, True, 1e-08, [True, False, False]);  view_default_260 = view_default_156 = getitem_462 = getitem_463 = None
        getitem_845 = native_batch_norm_backward_default_25[0];  native_batch_norm_backward_default_25 = None
        view_default_261 = torch.ops.aten.view.default(getitem_845, [1024, 256, 1, 1]);  getitem_845 = None
        to_dtype_75 = torch.ops.aten.to.dtype(getitem_842, torch.float32);  getitem_842 = None
        to_dtype_76 = torch.ops.aten.to.dtype(relu__default_74, torch.float32);  relu__default_74 = None
        le_scalar_25 = torch.ops.aten.le.Scalar(to_dtype_76, 0);  to_dtype_76 = None
        new_zeros_default_25 = torch.ops.aten.new_zeros.default(to_dtype_75, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_25 = torch.ops.aten.where.self(le_scalar_25, new_zeros_default_25, to_dtype_75);  le_scalar_25 = new_zeros_default_25 = to_dtype_75 = None
        to_dtype_77 = torch.ops.aten.to.dtype(where_self_25, torch.float32);  where_self_25 = None
        native_group_norm_backward_default_25 = torch.ops.aten.native_group_norm_backward.default(to_dtype_77, convolution_default_77, getitem_459, getitem_460, primals_151, 64, 256, 784, 32, [True, True, True]);  to_dtype_77 = convolution_default_77 = getitem_459 = getitem_460 = primals_151 = None
        getitem_848 = native_group_norm_backward_default_25[0]
        getitem_849 = native_group_norm_backward_default_25[1]
        getitem_850 = native_group_norm_backward_default_25[2];  native_group_norm_backward_default_25 = None
        convolution_backward_default_27 = torch.ops.aten.convolution_backward.default(getitem_848, relu__default_73, view_default_155, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_848 = view_default_155 = None
        getitem_851 = convolution_backward_default_27[0]
        getitem_852 = convolution_backward_default_27[1];  convolution_backward_default_27 = None
        view_default_262 = torch.ops.aten.view.default(getitem_852, [1, 256, 2304]);  getitem_852 = None
        native_batch_norm_backward_default_26 = torch.ops.aten.native_batch_norm_backward.default(view_default_262, view_default_154, None, None, None, getitem_456, getitem_457, True, 1e-08, [True, False, False]);  view_default_262 = view_default_154 = getitem_456 = getitem_457 = None
        getitem_854 = native_batch_norm_backward_default_26[0];  native_batch_norm_backward_default_26 = None
        view_default_263 = torch.ops.aten.view.default(getitem_854, [256, 256, 3, 3]);  getitem_854 = None
        to_dtype_78 = torch.ops.aten.to.dtype(getitem_851, torch.float32);  getitem_851 = None
        to_dtype_79 = torch.ops.aten.to.dtype(relu__default_73, torch.float32);  relu__default_73 = None
        le_scalar_26 = torch.ops.aten.le.Scalar(to_dtype_79, 0);  to_dtype_79 = None
        new_zeros_default_26 = torch.ops.aten.new_zeros.default(to_dtype_78, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_26 = torch.ops.aten.where.self(le_scalar_26, new_zeros_default_26, to_dtype_78);  le_scalar_26 = new_zeros_default_26 = to_dtype_78 = None
        to_dtype_80 = torch.ops.aten.to.dtype(where_self_26, torch.float32);  where_self_26 = None
        native_group_norm_backward_default_26 = torch.ops.aten.native_group_norm_backward.default(to_dtype_80, convolution_default_76, getitem_453, getitem_454, primals_149, 64, 256, 784, 32, [True, True, True]);  to_dtype_80 = convolution_default_76 = getitem_453 = getitem_454 = primals_149 = None
        getitem_857 = native_group_norm_backward_default_26[0]
        getitem_858 = native_group_norm_backward_default_26[1]
        getitem_859 = native_group_norm_backward_default_26[2];  native_group_norm_backward_default_26 = None
        convolution_backward_default_28 = torch.ops.aten.convolution_backward.default(getitem_857, relu__default_72, view_default_153, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_857 = view_default_153 = None
        getitem_860 = convolution_backward_default_28[0]
        getitem_861 = convolution_backward_default_28[1];  convolution_backward_default_28 = None
        view_default_264 = torch.ops.aten.view.default(getitem_861, [1, 256, 1024]);  getitem_861 = None
        native_batch_norm_backward_default_27 = torch.ops.aten.native_batch_norm_backward.default(view_default_264, view_default_152, None, None, None, getitem_450, getitem_451, True, 1e-08, [True, False, False]);  view_default_264 = view_default_152 = getitem_450 = getitem_451 = None
        getitem_863 = native_batch_norm_backward_default_27[0];  native_batch_norm_backward_default_27 = None
        view_default_265 = torch.ops.aten.view.default(getitem_863, [256, 1024, 1, 1]);  getitem_863 = None
        to_dtype_81 = torch.ops.aten.to.dtype(getitem_860, torch.float32);  getitem_860 = None
        to_dtype_82 = torch.ops.aten.to.dtype(relu__default_72, torch.float32);  relu__default_72 = None
        le_scalar_27 = torch.ops.aten.le.Scalar(to_dtype_82, 0);  to_dtype_82 = None
        new_zeros_default_27 = torch.ops.aten.new_zeros.default(to_dtype_81, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_27 = torch.ops.aten.where.self(le_scalar_27, new_zeros_default_27, to_dtype_81);  le_scalar_27 = new_zeros_default_27 = to_dtype_81 = None
        to_dtype_83 = torch.ops.aten.to.dtype(where_self_27, torch.float32);  where_self_27 = None
        native_group_norm_backward_default_27 = torch.ops.aten.native_group_norm_backward.default(to_dtype_83, add_tensor_23, getitem_447, getitem_448, primals_147, 64, 1024, 784, 32, [True, True, True]);  to_dtype_83 = add_tensor_23 = getitem_447 = getitem_448 = primals_147 = None
        getitem_866 = native_group_norm_backward_default_27[0]
        getitem_867 = native_group_norm_backward_default_27[1]
        getitem_868 = native_group_norm_backward_default_27[2];  native_group_norm_backward_default_27 = None
        add_tensor_41 = torch.ops.aten.add.Tensor(add_tensor_40, getitem_866);  add_tensor_40 = getitem_866 = None
        convolution_backward_default_29 = torch.ops.aten.convolution_backward.default(add_tensor_41, relu__default_71, view_default_151, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_151 = None
        getitem_869 = convolution_backward_default_29[0]
        getitem_870 = convolution_backward_default_29[1];  convolution_backward_default_29 = None
        view_default_266 = torch.ops.aten.view.default(getitem_870, [1, 1024, 256]);  getitem_870 = None
        native_batch_norm_backward_default_28 = torch.ops.aten.native_batch_norm_backward.default(view_default_266, view_default_150, None, None, None, getitem_444, getitem_445, True, 1e-08, [True, False, False]);  view_default_266 = view_default_150 = getitem_444 = getitem_445 = None
        getitem_872 = native_batch_norm_backward_default_28[0];  native_batch_norm_backward_default_28 = None
        view_default_267 = torch.ops.aten.view.default(getitem_872, [1024, 256, 1, 1]);  getitem_872 = None
        to_dtype_84 = torch.ops.aten.to.dtype(getitem_869, torch.float32);  getitem_869 = None
        to_dtype_85 = torch.ops.aten.to.dtype(relu__default_71, torch.float32);  relu__default_71 = None
        le_scalar_28 = torch.ops.aten.le.Scalar(to_dtype_85, 0);  to_dtype_85 = None
        new_zeros_default_28 = torch.ops.aten.new_zeros.default(to_dtype_84, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_28 = torch.ops.aten.where.self(le_scalar_28, new_zeros_default_28, to_dtype_84);  le_scalar_28 = new_zeros_default_28 = to_dtype_84 = None
        to_dtype_86 = torch.ops.aten.to.dtype(where_self_28, torch.float32);  where_self_28 = None
        native_group_norm_backward_default_28 = torch.ops.aten.native_group_norm_backward.default(to_dtype_86, convolution_default_74, getitem_441, getitem_442, primals_142, 64, 256, 784, 32, [True, True, True]);  to_dtype_86 = convolution_default_74 = getitem_441 = getitem_442 = primals_142 = None
        getitem_875 = native_group_norm_backward_default_28[0]
        getitem_876 = native_group_norm_backward_default_28[1]
        getitem_877 = native_group_norm_backward_default_28[2];  native_group_norm_backward_default_28 = None
        convolution_backward_default_30 = torch.ops.aten.convolution_backward.default(getitem_875, relu__default_70, view_default_149, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_875 = view_default_149 = None
        getitem_878 = convolution_backward_default_30[0]
        getitem_879 = convolution_backward_default_30[1];  convolution_backward_default_30 = None
        view_default_268 = torch.ops.aten.view.default(getitem_879, [1, 256, 2304]);  getitem_879 = None
        native_batch_norm_backward_default_29 = torch.ops.aten.native_batch_norm_backward.default(view_default_268, view_default_148, None, None, None, getitem_438, getitem_439, True, 1e-08, [True, False, False]);  view_default_268 = view_default_148 = getitem_438 = getitem_439 = None
        getitem_881 = native_batch_norm_backward_default_29[0];  native_batch_norm_backward_default_29 = None
        view_default_269 = torch.ops.aten.view.default(getitem_881, [256, 256, 3, 3]);  getitem_881 = None
        to_dtype_87 = torch.ops.aten.to.dtype(getitem_878, torch.float32);  getitem_878 = None
        to_dtype_88 = torch.ops.aten.to.dtype(relu__default_70, torch.float32);  relu__default_70 = None
        le_scalar_29 = torch.ops.aten.le.Scalar(to_dtype_88, 0);  to_dtype_88 = None
        new_zeros_default_29 = torch.ops.aten.new_zeros.default(to_dtype_87, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_29 = torch.ops.aten.where.self(le_scalar_29, new_zeros_default_29, to_dtype_87);  le_scalar_29 = new_zeros_default_29 = to_dtype_87 = None
        to_dtype_89 = torch.ops.aten.to.dtype(where_self_29, torch.float32);  where_self_29 = None
        native_group_norm_backward_default_29 = torch.ops.aten.native_group_norm_backward.default(to_dtype_89, convolution_default_73, getitem_435, getitem_436, primals_140, 64, 256, 784, 32, [True, True, True]);  to_dtype_89 = convolution_default_73 = getitem_435 = getitem_436 = primals_140 = None
        getitem_884 = native_group_norm_backward_default_29[0]
        getitem_885 = native_group_norm_backward_default_29[1]
        getitem_886 = native_group_norm_backward_default_29[2];  native_group_norm_backward_default_29 = None
        convolution_backward_default_31 = torch.ops.aten.convolution_backward.default(getitem_884, relu__default_69, view_default_147, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_884 = view_default_147 = None
        getitem_887 = convolution_backward_default_31[0]
        getitem_888 = convolution_backward_default_31[1];  convolution_backward_default_31 = None
        view_default_270 = torch.ops.aten.view.default(getitem_888, [1, 256, 1024]);  getitem_888 = None
        native_batch_norm_backward_default_30 = torch.ops.aten.native_batch_norm_backward.default(view_default_270, view_default_146, None, None, None, getitem_432, getitem_433, True, 1e-08, [True, False, False]);  view_default_270 = view_default_146 = getitem_432 = getitem_433 = None
        getitem_890 = native_batch_norm_backward_default_30[0];  native_batch_norm_backward_default_30 = None
        view_default_271 = torch.ops.aten.view.default(getitem_890, [256, 1024, 1, 1]);  getitem_890 = None
        to_dtype_90 = torch.ops.aten.to.dtype(getitem_887, torch.float32);  getitem_887 = None
        to_dtype_91 = torch.ops.aten.to.dtype(relu__default_69, torch.float32);  relu__default_69 = None
        le_scalar_30 = torch.ops.aten.le.Scalar(to_dtype_91, 0);  to_dtype_91 = None
        new_zeros_default_30 = torch.ops.aten.new_zeros.default(to_dtype_90, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_30 = torch.ops.aten.where.self(le_scalar_30, new_zeros_default_30, to_dtype_90);  le_scalar_30 = new_zeros_default_30 = to_dtype_90 = None
        to_dtype_92 = torch.ops.aten.to.dtype(where_self_30, torch.float32);  where_self_30 = None
        native_group_norm_backward_default_30 = torch.ops.aten.native_group_norm_backward.default(to_dtype_92, add_tensor_22, getitem_429, getitem_430, primals_138, 64, 1024, 784, 32, [True, True, True]);  to_dtype_92 = add_tensor_22 = getitem_429 = getitem_430 = primals_138 = None
        getitem_893 = native_group_norm_backward_default_30[0]
        getitem_894 = native_group_norm_backward_default_30[1]
        getitem_895 = native_group_norm_backward_default_30[2];  native_group_norm_backward_default_30 = None
        add_tensor_42 = torch.ops.aten.add.Tensor(add_tensor_41, getitem_893);  add_tensor_41 = getitem_893 = None
        convolution_backward_default_32 = torch.ops.aten.convolution_backward.default(add_tensor_42, relu__default_68, view_default_145, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_145 = None
        getitem_896 = convolution_backward_default_32[0]
        getitem_897 = convolution_backward_default_32[1];  convolution_backward_default_32 = None
        view_default_272 = torch.ops.aten.view.default(getitem_897, [1, 1024, 256]);  getitem_897 = None
        native_batch_norm_backward_default_31 = torch.ops.aten.native_batch_norm_backward.default(view_default_272, view_default_144, None, None, None, getitem_426, getitem_427, True, 1e-08, [True, False, False]);  view_default_272 = view_default_144 = getitem_426 = getitem_427 = None
        getitem_899 = native_batch_norm_backward_default_31[0];  native_batch_norm_backward_default_31 = None
        view_default_273 = torch.ops.aten.view.default(getitem_899, [1024, 256, 1, 1]);  getitem_899 = None
        to_dtype_93 = torch.ops.aten.to.dtype(getitem_896, torch.float32);  getitem_896 = None
        to_dtype_94 = torch.ops.aten.to.dtype(relu__default_68, torch.float32);  relu__default_68 = None
        le_scalar_31 = torch.ops.aten.le.Scalar(to_dtype_94, 0);  to_dtype_94 = None
        new_zeros_default_31 = torch.ops.aten.new_zeros.default(to_dtype_93, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_31 = torch.ops.aten.where.self(le_scalar_31, new_zeros_default_31, to_dtype_93);  le_scalar_31 = new_zeros_default_31 = to_dtype_93 = None
        to_dtype_95 = torch.ops.aten.to.dtype(where_self_31, torch.float32);  where_self_31 = None
        native_group_norm_backward_default_31 = torch.ops.aten.native_group_norm_backward.default(to_dtype_95, convolution_default_71, getitem_423, getitem_424, primals_133, 64, 256, 784, 32, [True, True, True]);  to_dtype_95 = convolution_default_71 = getitem_423 = getitem_424 = primals_133 = None
        getitem_902 = native_group_norm_backward_default_31[0]
        getitem_903 = native_group_norm_backward_default_31[1]
        getitem_904 = native_group_norm_backward_default_31[2];  native_group_norm_backward_default_31 = None
        convolution_backward_default_33 = torch.ops.aten.convolution_backward.default(getitem_902, relu__default_67, view_default_143, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_902 = view_default_143 = None
        getitem_905 = convolution_backward_default_33[0]
        getitem_906 = convolution_backward_default_33[1];  convolution_backward_default_33 = None
        view_default_274 = torch.ops.aten.view.default(getitem_906, [1, 256, 2304]);  getitem_906 = None
        native_batch_norm_backward_default_32 = torch.ops.aten.native_batch_norm_backward.default(view_default_274, view_default_142, None, None, None, getitem_420, getitem_421, True, 1e-08, [True, False, False]);  view_default_274 = view_default_142 = getitem_420 = getitem_421 = None
        getitem_908 = native_batch_norm_backward_default_32[0];  native_batch_norm_backward_default_32 = None
        view_default_275 = torch.ops.aten.view.default(getitem_908, [256, 256, 3, 3]);  getitem_908 = None
        to_dtype_96 = torch.ops.aten.to.dtype(getitem_905, torch.float32);  getitem_905 = None
        to_dtype_97 = torch.ops.aten.to.dtype(relu__default_67, torch.float32);  relu__default_67 = None
        le_scalar_32 = torch.ops.aten.le.Scalar(to_dtype_97, 0);  to_dtype_97 = None
        new_zeros_default_32 = torch.ops.aten.new_zeros.default(to_dtype_96, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_32 = torch.ops.aten.where.self(le_scalar_32, new_zeros_default_32, to_dtype_96);  le_scalar_32 = new_zeros_default_32 = to_dtype_96 = None
        to_dtype_98 = torch.ops.aten.to.dtype(where_self_32, torch.float32);  where_self_32 = None
        native_group_norm_backward_default_32 = torch.ops.aten.native_group_norm_backward.default(to_dtype_98, convolution_default_70, getitem_417, getitem_418, primals_131, 64, 256, 784, 32, [True, True, True]);  to_dtype_98 = convolution_default_70 = getitem_417 = getitem_418 = primals_131 = None
        getitem_911 = native_group_norm_backward_default_32[0]
        getitem_912 = native_group_norm_backward_default_32[1]
        getitem_913 = native_group_norm_backward_default_32[2];  native_group_norm_backward_default_32 = None
        convolution_backward_default_34 = torch.ops.aten.convolution_backward.default(getitem_911, relu__default_66, view_default_141, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_911 = view_default_141 = None
        getitem_914 = convolution_backward_default_34[0]
        getitem_915 = convolution_backward_default_34[1];  convolution_backward_default_34 = None
        view_default_276 = torch.ops.aten.view.default(getitem_915, [1, 256, 1024]);  getitem_915 = None
        native_batch_norm_backward_default_33 = torch.ops.aten.native_batch_norm_backward.default(view_default_276, view_default_140, None, None, None, getitem_414, getitem_415, True, 1e-08, [True, False, False]);  view_default_276 = view_default_140 = getitem_414 = getitem_415 = None
        getitem_917 = native_batch_norm_backward_default_33[0];  native_batch_norm_backward_default_33 = None
        view_default_277 = torch.ops.aten.view.default(getitem_917, [256, 1024, 1, 1]);  getitem_917 = None
        to_dtype_99 = torch.ops.aten.to.dtype(getitem_914, torch.float32);  getitem_914 = None
        to_dtype_100 = torch.ops.aten.to.dtype(relu__default_66, torch.float32);  relu__default_66 = None
        le_scalar_33 = torch.ops.aten.le.Scalar(to_dtype_100, 0);  to_dtype_100 = None
        new_zeros_default_33 = torch.ops.aten.new_zeros.default(to_dtype_99, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_33 = torch.ops.aten.where.self(le_scalar_33, new_zeros_default_33, to_dtype_99);  le_scalar_33 = new_zeros_default_33 = to_dtype_99 = None
        to_dtype_101 = torch.ops.aten.to.dtype(where_self_33, torch.float32);  where_self_33 = None
        native_group_norm_backward_default_33 = torch.ops.aten.native_group_norm_backward.default(to_dtype_101, add_tensor_21, getitem_411, getitem_412, primals_129, 64, 1024, 784, 32, [True, True, True]);  to_dtype_101 = add_tensor_21 = getitem_411 = getitem_412 = primals_129 = None
        getitem_920 = native_group_norm_backward_default_33[0]
        getitem_921 = native_group_norm_backward_default_33[1]
        getitem_922 = native_group_norm_backward_default_33[2];  native_group_norm_backward_default_33 = None
        add_tensor_43 = torch.ops.aten.add.Tensor(add_tensor_42, getitem_920);  add_tensor_42 = getitem_920 = None
        convolution_backward_default_35 = torch.ops.aten.convolution_backward.default(add_tensor_43, relu__default_65, view_default_139, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_139 = None
        getitem_923 = convolution_backward_default_35[0]
        getitem_924 = convolution_backward_default_35[1];  convolution_backward_default_35 = None
        view_default_278 = torch.ops.aten.view.default(getitem_924, [1, 1024, 256]);  getitem_924 = None
        native_batch_norm_backward_default_34 = torch.ops.aten.native_batch_norm_backward.default(view_default_278, view_default_138, None, None, None, getitem_408, getitem_409, True, 1e-08, [True, False, False]);  view_default_278 = view_default_138 = getitem_408 = getitem_409 = None
        getitem_926 = native_batch_norm_backward_default_34[0];  native_batch_norm_backward_default_34 = None
        view_default_279 = torch.ops.aten.view.default(getitem_926, [1024, 256, 1, 1]);  getitem_926 = None
        to_dtype_102 = torch.ops.aten.to.dtype(getitem_923, torch.float32);  getitem_923 = None
        to_dtype_103 = torch.ops.aten.to.dtype(relu__default_65, torch.float32);  relu__default_65 = None
        le_scalar_34 = torch.ops.aten.le.Scalar(to_dtype_103, 0);  to_dtype_103 = None
        new_zeros_default_34 = torch.ops.aten.new_zeros.default(to_dtype_102, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_34 = torch.ops.aten.where.self(le_scalar_34, new_zeros_default_34, to_dtype_102);  le_scalar_34 = new_zeros_default_34 = to_dtype_102 = None
        to_dtype_104 = torch.ops.aten.to.dtype(where_self_34, torch.float32);  where_self_34 = None
        native_group_norm_backward_default_34 = torch.ops.aten.native_group_norm_backward.default(to_dtype_104, convolution_default_68, getitem_405, getitem_406, primals_124, 64, 256, 784, 32, [True, True, True]);  to_dtype_104 = convolution_default_68 = getitem_405 = getitem_406 = primals_124 = None
        getitem_929 = native_group_norm_backward_default_34[0]
        getitem_930 = native_group_norm_backward_default_34[1]
        getitem_931 = native_group_norm_backward_default_34[2];  native_group_norm_backward_default_34 = None
        convolution_backward_default_36 = torch.ops.aten.convolution_backward.default(getitem_929, relu__default_64, view_default_137, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_929 = view_default_137 = None
        getitem_932 = convolution_backward_default_36[0]
        getitem_933 = convolution_backward_default_36[1];  convolution_backward_default_36 = None
        view_default_280 = torch.ops.aten.view.default(getitem_933, [1, 256, 2304]);  getitem_933 = None
        native_batch_norm_backward_default_35 = torch.ops.aten.native_batch_norm_backward.default(view_default_280, view_default_136, None, None, None, getitem_402, getitem_403, True, 1e-08, [True, False, False]);  view_default_280 = view_default_136 = getitem_402 = getitem_403 = None
        getitem_935 = native_batch_norm_backward_default_35[0];  native_batch_norm_backward_default_35 = None
        view_default_281 = torch.ops.aten.view.default(getitem_935, [256, 256, 3, 3]);  getitem_935 = None
        to_dtype_105 = torch.ops.aten.to.dtype(getitem_932, torch.float32);  getitem_932 = None
        to_dtype_106 = torch.ops.aten.to.dtype(relu__default_64, torch.float32);  relu__default_64 = None
        le_scalar_35 = torch.ops.aten.le.Scalar(to_dtype_106, 0);  to_dtype_106 = None
        new_zeros_default_35 = torch.ops.aten.new_zeros.default(to_dtype_105, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_35 = torch.ops.aten.where.self(le_scalar_35, new_zeros_default_35, to_dtype_105);  le_scalar_35 = new_zeros_default_35 = to_dtype_105 = None
        to_dtype_107 = torch.ops.aten.to.dtype(where_self_35, torch.float32);  where_self_35 = None
        native_group_norm_backward_default_35 = torch.ops.aten.native_group_norm_backward.default(to_dtype_107, convolution_default_67, getitem_399, getitem_400, primals_122, 64, 256, 784, 32, [True, True, True]);  to_dtype_107 = convolution_default_67 = getitem_399 = getitem_400 = primals_122 = None
        getitem_938 = native_group_norm_backward_default_35[0]
        getitem_939 = native_group_norm_backward_default_35[1]
        getitem_940 = native_group_norm_backward_default_35[2];  native_group_norm_backward_default_35 = None
        convolution_backward_default_37 = torch.ops.aten.convolution_backward.default(getitem_938, relu__default_63, view_default_135, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_938 = view_default_135 = None
        getitem_941 = convolution_backward_default_37[0]
        getitem_942 = convolution_backward_default_37[1];  convolution_backward_default_37 = None
        view_default_282 = torch.ops.aten.view.default(getitem_942, [1, 256, 1024]);  getitem_942 = None
        native_batch_norm_backward_default_36 = torch.ops.aten.native_batch_norm_backward.default(view_default_282, view_default_134, None, None, None, getitem_396, getitem_397, True, 1e-08, [True, False, False]);  view_default_282 = view_default_134 = getitem_396 = getitem_397 = None
        getitem_944 = native_batch_norm_backward_default_36[0];  native_batch_norm_backward_default_36 = None
        view_default_283 = torch.ops.aten.view.default(getitem_944, [256, 1024, 1, 1]);  getitem_944 = None
        to_dtype_108 = torch.ops.aten.to.dtype(getitem_941, torch.float32);  getitem_941 = None
        to_dtype_109 = torch.ops.aten.to.dtype(relu__default_63, torch.float32);  relu__default_63 = None
        le_scalar_36 = torch.ops.aten.le.Scalar(to_dtype_109, 0);  to_dtype_109 = None
        new_zeros_default_36 = torch.ops.aten.new_zeros.default(to_dtype_108, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_36 = torch.ops.aten.where.self(le_scalar_36, new_zeros_default_36, to_dtype_108);  le_scalar_36 = new_zeros_default_36 = to_dtype_108 = None
        to_dtype_110 = torch.ops.aten.to.dtype(where_self_36, torch.float32);  where_self_36 = None
        native_group_norm_backward_default_36 = torch.ops.aten.native_group_norm_backward.default(to_dtype_110, add_tensor_20, getitem_393, getitem_394, primals_120, 64, 1024, 784, 32, [True, True, True]);  to_dtype_110 = add_tensor_20 = getitem_393 = getitem_394 = primals_120 = None
        getitem_947 = native_group_norm_backward_default_36[0]
        getitem_948 = native_group_norm_backward_default_36[1]
        getitem_949 = native_group_norm_backward_default_36[2];  native_group_norm_backward_default_36 = None
        add_tensor_44 = torch.ops.aten.add.Tensor(add_tensor_43, getitem_947);  add_tensor_43 = getitem_947 = None
        convolution_backward_default_38 = torch.ops.aten.convolution_backward.default(add_tensor_44, relu__default_62, view_default_133, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_133 = None
        getitem_950 = convolution_backward_default_38[0]
        getitem_951 = convolution_backward_default_38[1];  convolution_backward_default_38 = None
        view_default_284 = torch.ops.aten.view.default(getitem_951, [1, 1024, 256]);  getitem_951 = None
        native_batch_norm_backward_default_37 = torch.ops.aten.native_batch_norm_backward.default(view_default_284, view_default_132, None, None, None, getitem_390, getitem_391, True, 1e-08, [True, False, False]);  view_default_284 = view_default_132 = getitem_390 = getitem_391 = None
        getitem_953 = native_batch_norm_backward_default_37[0];  native_batch_norm_backward_default_37 = None
        view_default_285 = torch.ops.aten.view.default(getitem_953, [1024, 256, 1, 1]);  getitem_953 = None
        to_dtype_111 = torch.ops.aten.to.dtype(getitem_950, torch.float32);  getitem_950 = None
        to_dtype_112 = torch.ops.aten.to.dtype(relu__default_62, torch.float32);  relu__default_62 = None
        le_scalar_37 = torch.ops.aten.le.Scalar(to_dtype_112, 0);  to_dtype_112 = None
        new_zeros_default_37 = torch.ops.aten.new_zeros.default(to_dtype_111, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_37 = torch.ops.aten.where.self(le_scalar_37, new_zeros_default_37, to_dtype_111);  le_scalar_37 = new_zeros_default_37 = to_dtype_111 = None
        to_dtype_113 = torch.ops.aten.to.dtype(where_self_37, torch.float32);  where_self_37 = None
        native_group_norm_backward_default_37 = torch.ops.aten.native_group_norm_backward.default(to_dtype_113, convolution_default_65, getitem_387, getitem_388, primals_115, 64, 256, 784, 32, [True, True, True]);  to_dtype_113 = convolution_default_65 = getitem_387 = getitem_388 = primals_115 = None
        getitem_956 = native_group_norm_backward_default_37[0]
        getitem_957 = native_group_norm_backward_default_37[1]
        getitem_958 = native_group_norm_backward_default_37[2];  native_group_norm_backward_default_37 = None
        convolution_backward_default_39 = torch.ops.aten.convolution_backward.default(getitem_956, relu__default_61, view_default_131, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_956 = view_default_131 = None
        getitem_959 = convolution_backward_default_39[0]
        getitem_960 = convolution_backward_default_39[1];  convolution_backward_default_39 = None
        view_default_286 = torch.ops.aten.view.default(getitem_960, [1, 256, 2304]);  getitem_960 = None
        native_batch_norm_backward_default_38 = torch.ops.aten.native_batch_norm_backward.default(view_default_286, view_default_130, None, None, None, getitem_384, getitem_385, True, 1e-08, [True, False, False]);  view_default_286 = view_default_130 = getitem_384 = getitem_385 = None
        getitem_962 = native_batch_norm_backward_default_38[0];  native_batch_norm_backward_default_38 = None
        view_default_287 = torch.ops.aten.view.default(getitem_962, [256, 256, 3, 3]);  getitem_962 = None
        to_dtype_114 = torch.ops.aten.to.dtype(getitem_959, torch.float32);  getitem_959 = None
        to_dtype_115 = torch.ops.aten.to.dtype(relu__default_61, torch.float32);  relu__default_61 = None
        le_scalar_38 = torch.ops.aten.le.Scalar(to_dtype_115, 0);  to_dtype_115 = None
        new_zeros_default_38 = torch.ops.aten.new_zeros.default(to_dtype_114, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_38 = torch.ops.aten.where.self(le_scalar_38, new_zeros_default_38, to_dtype_114);  le_scalar_38 = new_zeros_default_38 = to_dtype_114 = None
        to_dtype_116 = torch.ops.aten.to.dtype(where_self_38, torch.float32);  where_self_38 = None
        native_group_norm_backward_default_38 = torch.ops.aten.native_group_norm_backward.default(to_dtype_116, convolution_default_64, getitem_381, getitem_382, primals_113, 64, 256, 784, 32, [True, True, True]);  to_dtype_116 = convolution_default_64 = getitem_381 = getitem_382 = primals_113 = None
        getitem_965 = native_group_norm_backward_default_38[0]
        getitem_966 = native_group_norm_backward_default_38[1]
        getitem_967 = native_group_norm_backward_default_38[2];  native_group_norm_backward_default_38 = None
        convolution_backward_default_40 = torch.ops.aten.convolution_backward.default(getitem_965, relu__default_60, view_default_129, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_965 = view_default_129 = None
        getitem_968 = convolution_backward_default_40[0]
        getitem_969 = convolution_backward_default_40[1];  convolution_backward_default_40 = None
        view_default_288 = torch.ops.aten.view.default(getitem_969, [1, 256, 1024]);  getitem_969 = None
        native_batch_norm_backward_default_39 = torch.ops.aten.native_batch_norm_backward.default(view_default_288, view_default_128, None, None, None, getitem_378, getitem_379, True, 1e-08, [True, False, False]);  view_default_288 = view_default_128 = getitem_378 = getitem_379 = None
        getitem_971 = native_batch_norm_backward_default_39[0];  native_batch_norm_backward_default_39 = None
        view_default_289 = torch.ops.aten.view.default(getitem_971, [256, 1024, 1, 1]);  getitem_971 = None
        to_dtype_117 = torch.ops.aten.to.dtype(getitem_968, torch.float32);  getitem_968 = None
        to_dtype_118 = torch.ops.aten.to.dtype(relu__default_60, torch.float32);  relu__default_60 = None
        le_scalar_39 = torch.ops.aten.le.Scalar(to_dtype_118, 0);  to_dtype_118 = None
        new_zeros_default_39 = torch.ops.aten.new_zeros.default(to_dtype_117, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_39 = torch.ops.aten.where.self(le_scalar_39, new_zeros_default_39, to_dtype_117);  le_scalar_39 = new_zeros_default_39 = to_dtype_117 = None
        to_dtype_119 = torch.ops.aten.to.dtype(where_self_39, torch.float32);  where_self_39 = None
        native_group_norm_backward_default_39 = torch.ops.aten.native_group_norm_backward.default(to_dtype_119, add_tensor_19, getitem_375, getitem_376, primals_111, 64, 1024, 784, 32, [True, True, True]);  to_dtype_119 = add_tensor_19 = getitem_375 = getitem_376 = primals_111 = None
        getitem_974 = native_group_norm_backward_default_39[0]
        getitem_975 = native_group_norm_backward_default_39[1]
        getitem_976 = native_group_norm_backward_default_39[2];  native_group_norm_backward_default_39 = None
        add_tensor_45 = torch.ops.aten.add.Tensor(add_tensor_44, getitem_974);  add_tensor_44 = getitem_974 = None
        convolution_backward_default_41 = torch.ops.aten.convolution_backward.default(add_tensor_45, relu__default_59, view_default_127, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_127 = None
        getitem_977 = convolution_backward_default_41[0]
        getitem_978 = convolution_backward_default_41[1];  convolution_backward_default_41 = None
        view_default_290 = torch.ops.aten.view.default(getitem_978, [1, 1024, 256]);  getitem_978 = None
        native_batch_norm_backward_default_40 = torch.ops.aten.native_batch_norm_backward.default(view_default_290, view_default_126, None, None, None, getitem_372, getitem_373, True, 1e-08, [True, False, False]);  view_default_290 = view_default_126 = getitem_372 = getitem_373 = None
        getitem_980 = native_batch_norm_backward_default_40[0];  native_batch_norm_backward_default_40 = None
        view_default_291 = torch.ops.aten.view.default(getitem_980, [1024, 256, 1, 1]);  getitem_980 = None
        to_dtype_120 = torch.ops.aten.to.dtype(getitem_977, torch.float32);  getitem_977 = None
        to_dtype_121 = torch.ops.aten.to.dtype(relu__default_59, torch.float32);  relu__default_59 = None
        le_scalar_40 = torch.ops.aten.le.Scalar(to_dtype_121, 0);  to_dtype_121 = None
        new_zeros_default_40 = torch.ops.aten.new_zeros.default(to_dtype_120, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_40 = torch.ops.aten.where.self(le_scalar_40, new_zeros_default_40, to_dtype_120);  le_scalar_40 = new_zeros_default_40 = to_dtype_120 = None
        to_dtype_122 = torch.ops.aten.to.dtype(where_self_40, torch.float32);  where_self_40 = None
        native_group_norm_backward_default_40 = torch.ops.aten.native_group_norm_backward.default(to_dtype_122, convolution_default_62, getitem_369, getitem_370, primals_106, 64, 256, 784, 32, [True, True, True]);  to_dtype_122 = convolution_default_62 = getitem_369 = getitem_370 = primals_106 = None
        getitem_983 = native_group_norm_backward_default_40[0]
        getitem_984 = native_group_norm_backward_default_40[1]
        getitem_985 = native_group_norm_backward_default_40[2];  native_group_norm_backward_default_40 = None
        convolution_backward_default_42 = torch.ops.aten.convolution_backward.default(getitem_983, relu__default_58, view_default_125, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_983 = view_default_125 = None
        getitem_986 = convolution_backward_default_42[0]
        getitem_987 = convolution_backward_default_42[1];  convolution_backward_default_42 = None
        view_default_292 = torch.ops.aten.view.default(getitem_987, [1, 256, 2304]);  getitem_987 = None
        native_batch_norm_backward_default_41 = torch.ops.aten.native_batch_norm_backward.default(view_default_292, view_default_124, None, None, None, getitem_366, getitem_367, True, 1e-08, [True, False, False]);  view_default_292 = view_default_124 = getitem_366 = getitem_367 = None
        getitem_989 = native_batch_norm_backward_default_41[0];  native_batch_norm_backward_default_41 = None
        view_default_293 = torch.ops.aten.view.default(getitem_989, [256, 256, 3, 3]);  getitem_989 = None
        to_dtype_123 = torch.ops.aten.to.dtype(getitem_986, torch.float32);  getitem_986 = None
        to_dtype_124 = torch.ops.aten.to.dtype(relu__default_58, torch.float32);  relu__default_58 = None
        le_scalar_41 = torch.ops.aten.le.Scalar(to_dtype_124, 0);  to_dtype_124 = None
        new_zeros_default_41 = torch.ops.aten.new_zeros.default(to_dtype_123, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_41 = torch.ops.aten.where.self(le_scalar_41, new_zeros_default_41, to_dtype_123);  le_scalar_41 = new_zeros_default_41 = to_dtype_123 = None
        to_dtype_125 = torch.ops.aten.to.dtype(where_self_41, torch.float32);  where_self_41 = None
        native_group_norm_backward_default_41 = torch.ops.aten.native_group_norm_backward.default(to_dtype_125, convolution_default_61, getitem_363, getitem_364, primals_104, 64, 256, 784, 32, [True, True, True]);  to_dtype_125 = convolution_default_61 = getitem_363 = getitem_364 = primals_104 = None
        getitem_992 = native_group_norm_backward_default_41[0]
        getitem_993 = native_group_norm_backward_default_41[1]
        getitem_994 = native_group_norm_backward_default_41[2];  native_group_norm_backward_default_41 = None
        convolution_backward_default_43 = torch.ops.aten.convolution_backward.default(getitem_992, relu__default_57, view_default_123, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_992 = view_default_123 = None
        getitem_995 = convolution_backward_default_43[0]
        getitem_996 = convolution_backward_default_43[1];  convolution_backward_default_43 = None
        view_default_294 = torch.ops.aten.view.default(getitem_996, [1, 256, 1024]);  getitem_996 = None
        native_batch_norm_backward_default_42 = torch.ops.aten.native_batch_norm_backward.default(view_default_294, view_default_122, None, None, None, getitem_360, getitem_361, True, 1e-08, [True, False, False]);  view_default_294 = view_default_122 = getitem_360 = getitem_361 = None
        getitem_998 = native_batch_norm_backward_default_42[0];  native_batch_norm_backward_default_42 = None
        view_default_295 = torch.ops.aten.view.default(getitem_998, [256, 1024, 1, 1]);  getitem_998 = None
        to_dtype_126 = torch.ops.aten.to.dtype(getitem_995, torch.float32);  getitem_995 = None
        to_dtype_127 = torch.ops.aten.to.dtype(relu__default_57, torch.float32);  relu__default_57 = None
        le_scalar_42 = torch.ops.aten.le.Scalar(to_dtype_127, 0);  to_dtype_127 = None
        new_zeros_default_42 = torch.ops.aten.new_zeros.default(to_dtype_126, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_42 = torch.ops.aten.where.self(le_scalar_42, new_zeros_default_42, to_dtype_126);  le_scalar_42 = new_zeros_default_42 = to_dtype_126 = None
        to_dtype_128 = torch.ops.aten.to.dtype(where_self_42, torch.float32);  where_self_42 = None
        native_group_norm_backward_default_42 = torch.ops.aten.native_group_norm_backward.default(to_dtype_128, add_tensor_18, getitem_357, getitem_358, primals_102, 64, 1024, 784, 32, [True, True, True]);  to_dtype_128 = add_tensor_18 = getitem_357 = getitem_358 = primals_102 = None
        getitem_1001 = native_group_norm_backward_default_42[0]
        getitem_1002 = native_group_norm_backward_default_42[1]
        getitem_1003 = native_group_norm_backward_default_42[2];  native_group_norm_backward_default_42 = None
        add_tensor_46 = torch.ops.aten.add.Tensor(add_tensor_45, getitem_1001);  add_tensor_45 = getitem_1001 = None
        convolution_backward_default_44 = torch.ops.aten.convolution_backward.default(add_tensor_46, relu__default_56, view_default_121, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_121 = None
        getitem_1004 = convolution_backward_default_44[0]
        getitem_1005 = convolution_backward_default_44[1];  convolution_backward_default_44 = None
        view_default_296 = torch.ops.aten.view.default(getitem_1005, [1, 1024, 256]);  getitem_1005 = None
        native_batch_norm_backward_default_43 = torch.ops.aten.native_batch_norm_backward.default(view_default_296, view_default_120, None, None, None, getitem_354, getitem_355, True, 1e-08, [True, False, False]);  view_default_296 = view_default_120 = getitem_354 = getitem_355 = None
        getitem_1007 = native_batch_norm_backward_default_43[0];  native_batch_norm_backward_default_43 = None
        view_default_297 = torch.ops.aten.view.default(getitem_1007, [1024, 256, 1, 1]);  getitem_1007 = None
        to_dtype_129 = torch.ops.aten.to.dtype(getitem_1004, torch.float32);  getitem_1004 = None
        to_dtype_130 = torch.ops.aten.to.dtype(relu__default_56, torch.float32);  relu__default_56 = None
        le_scalar_43 = torch.ops.aten.le.Scalar(to_dtype_130, 0);  to_dtype_130 = None
        new_zeros_default_43 = torch.ops.aten.new_zeros.default(to_dtype_129, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_43 = torch.ops.aten.where.self(le_scalar_43, new_zeros_default_43, to_dtype_129);  le_scalar_43 = new_zeros_default_43 = to_dtype_129 = None
        to_dtype_131 = torch.ops.aten.to.dtype(where_self_43, torch.float32);  where_self_43 = None
        native_group_norm_backward_default_43 = torch.ops.aten.native_group_norm_backward.default(to_dtype_131, convolution_default_59, getitem_351, getitem_352, primals_97, 64, 256, 784, 32, [True, True, True]);  to_dtype_131 = convolution_default_59 = getitem_351 = getitem_352 = primals_97 = None
        getitem_1010 = native_group_norm_backward_default_43[0]
        getitem_1011 = native_group_norm_backward_default_43[1]
        getitem_1012 = native_group_norm_backward_default_43[2];  native_group_norm_backward_default_43 = None
        convolution_backward_default_45 = torch.ops.aten.convolution_backward.default(getitem_1010, relu__default_55, view_default_119, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1010 = view_default_119 = None
        getitem_1013 = convolution_backward_default_45[0]
        getitem_1014 = convolution_backward_default_45[1];  convolution_backward_default_45 = None
        view_default_298 = torch.ops.aten.view.default(getitem_1014, [1, 256, 2304]);  getitem_1014 = None
        native_batch_norm_backward_default_44 = torch.ops.aten.native_batch_norm_backward.default(view_default_298, view_default_118, None, None, None, getitem_348, getitem_349, True, 1e-08, [True, False, False]);  view_default_298 = view_default_118 = getitem_348 = getitem_349 = None
        getitem_1016 = native_batch_norm_backward_default_44[0];  native_batch_norm_backward_default_44 = None
        view_default_299 = torch.ops.aten.view.default(getitem_1016, [256, 256, 3, 3]);  getitem_1016 = None
        to_dtype_132 = torch.ops.aten.to.dtype(getitem_1013, torch.float32);  getitem_1013 = None
        to_dtype_133 = torch.ops.aten.to.dtype(relu__default_55, torch.float32);  relu__default_55 = None
        le_scalar_44 = torch.ops.aten.le.Scalar(to_dtype_133, 0);  to_dtype_133 = None
        new_zeros_default_44 = torch.ops.aten.new_zeros.default(to_dtype_132, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_44 = torch.ops.aten.where.self(le_scalar_44, new_zeros_default_44, to_dtype_132);  le_scalar_44 = new_zeros_default_44 = to_dtype_132 = None
        to_dtype_134 = torch.ops.aten.to.dtype(where_self_44, torch.float32);  where_self_44 = None
        native_group_norm_backward_default_44 = torch.ops.aten.native_group_norm_backward.default(to_dtype_134, convolution_default_58, getitem_345, getitem_346, primals_95, 64, 256, 784, 32, [True, True, True]);  to_dtype_134 = convolution_default_58 = getitem_345 = getitem_346 = primals_95 = None
        getitem_1019 = native_group_norm_backward_default_44[0]
        getitem_1020 = native_group_norm_backward_default_44[1]
        getitem_1021 = native_group_norm_backward_default_44[2];  native_group_norm_backward_default_44 = None
        convolution_backward_default_46 = torch.ops.aten.convolution_backward.default(getitem_1019, relu__default_54, view_default_117, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1019 = view_default_117 = None
        getitem_1022 = convolution_backward_default_46[0]
        getitem_1023 = convolution_backward_default_46[1];  convolution_backward_default_46 = None
        view_default_300 = torch.ops.aten.view.default(getitem_1023, [1, 256, 1024]);  getitem_1023 = None
        native_batch_norm_backward_default_45 = torch.ops.aten.native_batch_norm_backward.default(view_default_300, view_default_116, None, None, None, getitem_342, getitem_343, True, 1e-08, [True, False, False]);  view_default_300 = view_default_116 = getitem_342 = getitem_343 = None
        getitem_1025 = native_batch_norm_backward_default_45[0];  native_batch_norm_backward_default_45 = None
        view_default_301 = torch.ops.aten.view.default(getitem_1025, [256, 1024, 1, 1]);  getitem_1025 = None
        to_dtype_135 = torch.ops.aten.to.dtype(getitem_1022, torch.float32);  getitem_1022 = None
        to_dtype_136 = torch.ops.aten.to.dtype(relu__default_54, torch.float32);  relu__default_54 = None
        le_scalar_45 = torch.ops.aten.le.Scalar(to_dtype_136, 0);  to_dtype_136 = None
        new_zeros_default_45 = torch.ops.aten.new_zeros.default(to_dtype_135, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_45 = torch.ops.aten.where.self(le_scalar_45, new_zeros_default_45, to_dtype_135);  le_scalar_45 = new_zeros_default_45 = to_dtype_135 = None
        to_dtype_137 = torch.ops.aten.to.dtype(where_self_45, torch.float32);  where_self_45 = None
        native_group_norm_backward_default_45 = torch.ops.aten.native_group_norm_backward.default(to_dtype_137, add_tensor_17, getitem_339, getitem_340, primals_93, 64, 1024, 784, 32, [True, True, True]);  to_dtype_137 = add_tensor_17 = getitem_339 = getitem_340 = primals_93 = None
        getitem_1028 = native_group_norm_backward_default_45[0]
        getitem_1029 = native_group_norm_backward_default_45[1]
        getitem_1030 = native_group_norm_backward_default_45[2];  native_group_norm_backward_default_45 = None
        add_tensor_47 = torch.ops.aten.add.Tensor(add_tensor_46, getitem_1028);  add_tensor_46 = getitem_1028 = None
        convolution_backward_default_47 = torch.ops.aten.convolution_backward.default(add_tensor_47, relu__default_53, view_default_115, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_115 = None
        getitem_1031 = convolution_backward_default_47[0]
        getitem_1032 = convolution_backward_default_47[1];  convolution_backward_default_47 = None
        view_default_302 = torch.ops.aten.view.default(getitem_1032, [1, 1024, 256]);  getitem_1032 = None
        native_batch_norm_backward_default_46 = torch.ops.aten.native_batch_norm_backward.default(view_default_302, view_default_114, None, None, None, getitem_336, getitem_337, True, 1e-08, [True, False, False]);  view_default_302 = view_default_114 = getitem_336 = getitem_337 = None
        getitem_1034 = native_batch_norm_backward_default_46[0];  native_batch_norm_backward_default_46 = None
        view_default_303 = torch.ops.aten.view.default(getitem_1034, [1024, 256, 1, 1]);  getitem_1034 = None
        to_dtype_138 = torch.ops.aten.to.dtype(getitem_1031, torch.float32);  getitem_1031 = None
        to_dtype_139 = torch.ops.aten.to.dtype(relu__default_53, torch.float32);  relu__default_53 = None
        le_scalar_46 = torch.ops.aten.le.Scalar(to_dtype_139, 0);  to_dtype_139 = None
        new_zeros_default_46 = torch.ops.aten.new_zeros.default(to_dtype_138, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_46 = torch.ops.aten.where.self(le_scalar_46, new_zeros_default_46, to_dtype_138);  le_scalar_46 = new_zeros_default_46 = to_dtype_138 = None
        to_dtype_140 = torch.ops.aten.to.dtype(where_self_46, torch.float32);  where_self_46 = None
        native_group_norm_backward_default_46 = torch.ops.aten.native_group_norm_backward.default(to_dtype_140, convolution_default_56, getitem_333, getitem_334, primals_88, 64, 256, 784, 32, [True, True, True]);  to_dtype_140 = convolution_default_56 = getitem_333 = getitem_334 = primals_88 = None
        getitem_1037 = native_group_norm_backward_default_46[0]
        getitem_1038 = native_group_norm_backward_default_46[1]
        getitem_1039 = native_group_norm_backward_default_46[2];  native_group_norm_backward_default_46 = None
        convolution_backward_default_48 = torch.ops.aten.convolution_backward.default(getitem_1037, relu__default_52, view_default_113, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1037 = view_default_113 = None
        getitem_1040 = convolution_backward_default_48[0]
        getitem_1041 = convolution_backward_default_48[1];  convolution_backward_default_48 = None
        view_default_304 = torch.ops.aten.view.default(getitem_1041, [1, 256, 2304]);  getitem_1041 = None
        native_batch_norm_backward_default_47 = torch.ops.aten.native_batch_norm_backward.default(view_default_304, view_default_112, None, None, None, getitem_330, getitem_331, True, 1e-08, [True, False, False]);  view_default_304 = view_default_112 = getitem_330 = getitem_331 = None
        getitem_1043 = native_batch_norm_backward_default_47[0];  native_batch_norm_backward_default_47 = None
        view_default_305 = torch.ops.aten.view.default(getitem_1043, [256, 256, 3, 3]);  getitem_1043 = None
        to_dtype_141 = torch.ops.aten.to.dtype(getitem_1040, torch.float32);  getitem_1040 = None
        to_dtype_142 = torch.ops.aten.to.dtype(relu__default_52, torch.float32);  relu__default_52 = None
        le_scalar_47 = torch.ops.aten.le.Scalar(to_dtype_142, 0);  to_dtype_142 = None
        new_zeros_default_47 = torch.ops.aten.new_zeros.default(to_dtype_141, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_47 = torch.ops.aten.where.self(le_scalar_47, new_zeros_default_47, to_dtype_141);  le_scalar_47 = new_zeros_default_47 = to_dtype_141 = None
        to_dtype_143 = torch.ops.aten.to.dtype(where_self_47, torch.float32);  where_self_47 = None
        native_group_norm_backward_default_47 = torch.ops.aten.native_group_norm_backward.default(to_dtype_143, convolution_default_55, getitem_327, getitem_328, primals_86, 64, 256, 784, 32, [True, True, True]);  to_dtype_143 = convolution_default_55 = getitem_327 = getitem_328 = primals_86 = None
        getitem_1046 = native_group_norm_backward_default_47[0]
        getitem_1047 = native_group_norm_backward_default_47[1]
        getitem_1048 = native_group_norm_backward_default_47[2];  native_group_norm_backward_default_47 = None
        convolution_backward_default_49 = torch.ops.aten.convolution_backward.default(getitem_1046, relu__default_51, view_default_111, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1046 = view_default_111 = None
        getitem_1049 = convolution_backward_default_49[0]
        getitem_1050 = convolution_backward_default_49[1];  convolution_backward_default_49 = None
        view_default_306 = torch.ops.aten.view.default(getitem_1050, [1, 256, 1024]);  getitem_1050 = None
        native_batch_norm_backward_default_48 = torch.ops.aten.native_batch_norm_backward.default(view_default_306, view_default_110, None, None, None, getitem_324, getitem_325, True, 1e-08, [True, False, False]);  view_default_306 = view_default_110 = getitem_324 = getitem_325 = None
        getitem_1052 = native_batch_norm_backward_default_48[0];  native_batch_norm_backward_default_48 = None
        view_default_307 = torch.ops.aten.view.default(getitem_1052, [256, 1024, 1, 1]);  getitem_1052 = None
        to_dtype_144 = torch.ops.aten.to.dtype(getitem_1049, torch.float32);  getitem_1049 = None
        to_dtype_145 = torch.ops.aten.to.dtype(relu__default_51, torch.float32);  relu__default_51 = None
        le_scalar_48 = torch.ops.aten.le.Scalar(to_dtype_145, 0);  to_dtype_145 = None
        new_zeros_default_48 = torch.ops.aten.new_zeros.default(to_dtype_144, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_48 = torch.ops.aten.where.self(le_scalar_48, new_zeros_default_48, to_dtype_144);  le_scalar_48 = new_zeros_default_48 = to_dtype_144 = None
        to_dtype_146 = torch.ops.aten.to.dtype(where_self_48, torch.float32);  where_self_48 = None
        native_group_norm_backward_default_48 = torch.ops.aten.native_group_norm_backward.default(to_dtype_146, add_tensor_16, getitem_321, getitem_322, primals_84, 64, 1024, 784, 32, [True, True, True]);  to_dtype_146 = add_tensor_16 = getitem_321 = getitem_322 = primals_84 = None
        getitem_1055 = native_group_norm_backward_default_48[0]
        getitem_1056 = native_group_norm_backward_default_48[1]
        getitem_1057 = native_group_norm_backward_default_48[2];  native_group_norm_backward_default_48 = None
        add_tensor_48 = torch.ops.aten.add.Tensor(add_tensor_47, getitem_1055);  add_tensor_47 = getitem_1055 = None
        convolution_backward_default_50 = torch.ops.aten.convolution_backward.default(add_tensor_48, relu__default_50, view_default_109, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_109 = None
        getitem_1058 = convolution_backward_default_50[0]
        getitem_1059 = convolution_backward_default_50[1];  convolution_backward_default_50 = None
        view_default_308 = torch.ops.aten.view.default(getitem_1059, [1, 1024, 256]);  getitem_1059 = None
        native_batch_norm_backward_default_49 = torch.ops.aten.native_batch_norm_backward.default(view_default_308, view_default_108, None, None, None, getitem_318, getitem_319, True, 1e-08, [True, False, False]);  view_default_308 = view_default_108 = getitem_318 = getitem_319 = None
        getitem_1061 = native_batch_norm_backward_default_49[0];  native_batch_norm_backward_default_49 = None
        view_default_309 = torch.ops.aten.view.default(getitem_1061, [1024, 256, 1, 1]);  getitem_1061 = None
        to_dtype_147 = torch.ops.aten.to.dtype(getitem_1058, torch.float32);  getitem_1058 = None
        to_dtype_148 = torch.ops.aten.to.dtype(relu__default_50, torch.float32);  relu__default_50 = None
        le_scalar_49 = torch.ops.aten.le.Scalar(to_dtype_148, 0);  to_dtype_148 = None
        new_zeros_default_49 = torch.ops.aten.new_zeros.default(to_dtype_147, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_49 = torch.ops.aten.where.self(le_scalar_49, new_zeros_default_49, to_dtype_147);  le_scalar_49 = new_zeros_default_49 = to_dtype_147 = None
        to_dtype_149 = torch.ops.aten.to.dtype(where_self_49, torch.float32);  where_self_49 = None
        native_group_norm_backward_default_49 = torch.ops.aten.native_group_norm_backward.default(to_dtype_149, convolution_default_53, getitem_315, getitem_316, primals_277, 64, 256, 784, 32, [True, True, True]);  to_dtype_149 = convolution_default_53 = getitem_315 = getitem_316 = primals_277 = None
        getitem_1064 = native_group_norm_backward_default_49[0]
        getitem_1065 = native_group_norm_backward_default_49[1]
        getitem_1066 = native_group_norm_backward_default_49[2];  native_group_norm_backward_default_49 = None
        convolution_backward_default_51 = torch.ops.aten.convolution_backward.default(getitem_1064, relu__default_49, view_default_107, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1064 = view_default_107 = None
        getitem_1067 = convolution_backward_default_51[0]
        getitem_1068 = convolution_backward_default_51[1];  convolution_backward_default_51 = None
        view_default_310 = torch.ops.aten.view.default(getitem_1068, [1, 256, 2304]);  getitem_1068 = None
        native_batch_norm_backward_default_50 = torch.ops.aten.native_batch_norm_backward.default(view_default_310, view_default_106, None, None, None, getitem_312, getitem_313, True, 1e-08, [True, False, False]);  view_default_310 = view_default_106 = getitem_312 = getitem_313 = None
        getitem_1070 = native_batch_norm_backward_default_50[0];  native_batch_norm_backward_default_50 = None
        view_default_311 = torch.ops.aten.view.default(getitem_1070, [256, 256, 3, 3]);  getitem_1070 = None
        to_dtype_150 = torch.ops.aten.to.dtype(getitem_1067, torch.float32);  getitem_1067 = None
        to_dtype_151 = torch.ops.aten.to.dtype(relu__default_49, torch.float32);  relu__default_49 = None
        le_scalar_50 = torch.ops.aten.le.Scalar(to_dtype_151, 0);  to_dtype_151 = None
        new_zeros_default_50 = torch.ops.aten.new_zeros.default(to_dtype_150, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_50 = torch.ops.aten.where.self(le_scalar_50, new_zeros_default_50, to_dtype_150);  le_scalar_50 = new_zeros_default_50 = to_dtype_150 = None
        to_dtype_152 = torch.ops.aten.to.dtype(where_self_50, torch.float32);  where_self_50 = None
        native_group_norm_backward_default_50 = torch.ops.aten.native_group_norm_backward.default(to_dtype_152, convolution_default_52, getitem_309, getitem_310, primals_275, 64, 256, 784, 32, [True, True, True]);  to_dtype_152 = convolution_default_52 = getitem_309 = getitem_310 = primals_275 = None
        getitem_1073 = native_group_norm_backward_default_50[0]
        getitem_1074 = native_group_norm_backward_default_50[1]
        getitem_1075 = native_group_norm_backward_default_50[2];  native_group_norm_backward_default_50 = None
        convolution_backward_default_52 = torch.ops.aten.convolution_backward.default(getitem_1073, relu__default_48, view_default_105, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1073 = view_default_105 = None
        getitem_1076 = convolution_backward_default_52[0]
        getitem_1077 = convolution_backward_default_52[1];  convolution_backward_default_52 = None
        view_default_312 = torch.ops.aten.view.default(getitem_1077, [1, 256, 1024]);  getitem_1077 = None
        native_batch_norm_backward_default_51 = torch.ops.aten.native_batch_norm_backward.default(view_default_312, view_default_104, None, None, None, getitem_306, getitem_307, True, 1e-08, [True, False, False]);  view_default_312 = view_default_104 = getitem_306 = getitem_307 = None
        getitem_1079 = native_batch_norm_backward_default_51[0];  native_batch_norm_backward_default_51 = None
        view_default_313 = torch.ops.aten.view.default(getitem_1079, [256, 1024, 1, 1]);  getitem_1079 = None
        to_dtype_153 = torch.ops.aten.to.dtype(getitem_1076, torch.float32);  getitem_1076 = None
        to_dtype_154 = torch.ops.aten.to.dtype(relu__default_48, torch.float32);  relu__default_48 = None
        le_scalar_51 = torch.ops.aten.le.Scalar(to_dtype_154, 0);  to_dtype_154 = None
        new_zeros_default_51 = torch.ops.aten.new_zeros.default(to_dtype_153, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_51 = torch.ops.aten.where.self(le_scalar_51, new_zeros_default_51, to_dtype_153);  le_scalar_51 = new_zeros_default_51 = to_dtype_153 = None
        to_dtype_155 = torch.ops.aten.to.dtype(where_self_51, torch.float32);  where_self_51 = None
        native_group_norm_backward_default_51 = torch.ops.aten.native_group_norm_backward.default(to_dtype_155, add_tensor_15, getitem_303, getitem_304, primals_273, 64, 1024, 784, 32, [True, True, True]);  to_dtype_155 = add_tensor_15 = getitem_303 = getitem_304 = primals_273 = None
        getitem_1082 = native_group_norm_backward_default_51[0]
        getitem_1083 = native_group_norm_backward_default_51[1]
        getitem_1084 = native_group_norm_backward_default_51[2];  native_group_norm_backward_default_51 = None
        add_tensor_49 = torch.ops.aten.add.Tensor(add_tensor_48, getitem_1082);  add_tensor_48 = getitem_1082 = None
        convolution_backward_default_53 = torch.ops.aten.convolution_backward.default(add_tensor_49, relu__default_47, view_default_103, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_103 = None
        getitem_1085 = convolution_backward_default_53[0]
        getitem_1086 = convolution_backward_default_53[1];  convolution_backward_default_53 = None
        view_default_314 = torch.ops.aten.view.default(getitem_1086, [1, 1024, 256]);  getitem_1086 = None
        native_batch_norm_backward_default_52 = torch.ops.aten.native_batch_norm_backward.default(view_default_314, view_default_102, None, None, None, getitem_300, getitem_301, True, 1e-08, [True, False, False]);  view_default_314 = view_default_102 = getitem_300 = getitem_301 = None
        getitem_1088 = native_batch_norm_backward_default_52[0];  native_batch_norm_backward_default_52 = None
        view_default_315 = torch.ops.aten.view.default(getitem_1088, [1024, 256, 1, 1]);  getitem_1088 = None
        to_dtype_156 = torch.ops.aten.to.dtype(getitem_1085, torch.float32);  getitem_1085 = None
        to_dtype_157 = torch.ops.aten.to.dtype(relu__default_47, torch.float32);  relu__default_47 = None
        le_scalar_52 = torch.ops.aten.le.Scalar(to_dtype_157, 0);  to_dtype_157 = None
        new_zeros_default_52 = torch.ops.aten.new_zeros.default(to_dtype_156, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_52 = torch.ops.aten.where.self(le_scalar_52, new_zeros_default_52, to_dtype_156);  le_scalar_52 = new_zeros_default_52 = to_dtype_156 = None
        to_dtype_158 = torch.ops.aten.to.dtype(where_self_52, torch.float32);  where_self_52 = None
        native_group_norm_backward_default_52 = torch.ops.aten.native_group_norm_backward.default(to_dtype_158, convolution_default_50, getitem_297, getitem_298, primals_268, 64, 256, 784, 32, [True, True, True]);  to_dtype_158 = convolution_default_50 = getitem_297 = getitem_298 = primals_268 = None
        getitem_1091 = native_group_norm_backward_default_52[0]
        getitem_1092 = native_group_norm_backward_default_52[1]
        getitem_1093 = native_group_norm_backward_default_52[2];  native_group_norm_backward_default_52 = None
        convolution_backward_default_54 = torch.ops.aten.convolution_backward.default(getitem_1091, relu__default_46, view_default_101, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1091 = view_default_101 = None
        getitem_1094 = convolution_backward_default_54[0]
        getitem_1095 = convolution_backward_default_54[1];  convolution_backward_default_54 = None
        view_default_316 = torch.ops.aten.view.default(getitem_1095, [1, 256, 2304]);  getitem_1095 = None
        native_batch_norm_backward_default_53 = torch.ops.aten.native_batch_norm_backward.default(view_default_316, view_default_100, None, None, None, getitem_294, getitem_295, True, 1e-08, [True, False, False]);  view_default_316 = view_default_100 = getitem_294 = getitem_295 = None
        getitem_1097 = native_batch_norm_backward_default_53[0];  native_batch_norm_backward_default_53 = None
        view_default_317 = torch.ops.aten.view.default(getitem_1097, [256, 256, 3, 3]);  getitem_1097 = None
        to_dtype_159 = torch.ops.aten.to.dtype(getitem_1094, torch.float32);  getitem_1094 = None
        to_dtype_160 = torch.ops.aten.to.dtype(relu__default_46, torch.float32);  relu__default_46 = None
        le_scalar_53 = torch.ops.aten.le.Scalar(to_dtype_160, 0);  to_dtype_160 = None
        new_zeros_default_53 = torch.ops.aten.new_zeros.default(to_dtype_159, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_53 = torch.ops.aten.where.self(le_scalar_53, new_zeros_default_53, to_dtype_159);  le_scalar_53 = new_zeros_default_53 = to_dtype_159 = None
        to_dtype_161 = torch.ops.aten.to.dtype(where_self_53, torch.float32);  where_self_53 = None
        native_group_norm_backward_default_53 = torch.ops.aten.native_group_norm_backward.default(to_dtype_161, convolution_default_49, getitem_291, getitem_292, primals_266, 64, 256, 784, 32, [True, True, True]);  to_dtype_161 = convolution_default_49 = getitem_291 = getitem_292 = primals_266 = None
        getitem_1100 = native_group_norm_backward_default_53[0]
        getitem_1101 = native_group_norm_backward_default_53[1]
        getitem_1102 = native_group_norm_backward_default_53[2];  native_group_norm_backward_default_53 = None
        convolution_backward_default_55 = torch.ops.aten.convolution_backward.default(getitem_1100, relu__default_45, view_default_99, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1100 = view_default_99 = None
        getitem_1103 = convolution_backward_default_55[0]
        getitem_1104 = convolution_backward_default_55[1];  convolution_backward_default_55 = None
        view_default_318 = torch.ops.aten.view.default(getitem_1104, [1, 256, 1024]);  getitem_1104 = None
        native_batch_norm_backward_default_54 = torch.ops.aten.native_batch_norm_backward.default(view_default_318, view_default_98, None, None, None, getitem_288, getitem_289, True, 1e-08, [True, False, False]);  view_default_318 = view_default_98 = getitem_288 = getitem_289 = None
        getitem_1106 = native_batch_norm_backward_default_54[0];  native_batch_norm_backward_default_54 = None
        view_default_319 = torch.ops.aten.view.default(getitem_1106, [256, 1024, 1, 1]);  getitem_1106 = None
        to_dtype_162 = torch.ops.aten.to.dtype(getitem_1103, torch.float32);  getitem_1103 = None
        to_dtype_163 = torch.ops.aten.to.dtype(relu__default_45, torch.float32);  relu__default_45 = None
        le_scalar_54 = torch.ops.aten.le.Scalar(to_dtype_163, 0);  to_dtype_163 = None
        new_zeros_default_54 = torch.ops.aten.new_zeros.default(to_dtype_162, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_54 = torch.ops.aten.where.self(le_scalar_54, new_zeros_default_54, to_dtype_162);  le_scalar_54 = new_zeros_default_54 = to_dtype_162 = None
        to_dtype_164 = torch.ops.aten.to.dtype(where_self_54, torch.float32);  where_self_54 = None
        native_group_norm_backward_default_54 = torch.ops.aten.native_group_norm_backward.default(to_dtype_164, add_tensor_14, getitem_285, getitem_286, primals_264, 64, 1024, 784, 32, [True, True, True]);  to_dtype_164 = add_tensor_14 = getitem_285 = getitem_286 = primals_264 = None
        getitem_1109 = native_group_norm_backward_default_54[0]
        getitem_1110 = native_group_norm_backward_default_54[1]
        getitem_1111 = native_group_norm_backward_default_54[2];  native_group_norm_backward_default_54 = None
        add_tensor_50 = torch.ops.aten.add.Tensor(add_tensor_49, getitem_1109);  add_tensor_49 = getitem_1109 = None
        convolution_backward_default_56 = torch.ops.aten.convolution_backward.default(add_tensor_50, relu__default_44, view_default_97, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_97 = None
        getitem_1112 = convolution_backward_default_56[0]
        getitem_1113 = convolution_backward_default_56[1];  convolution_backward_default_56 = None
        view_default_320 = torch.ops.aten.view.default(getitem_1113, [1, 1024, 256]);  getitem_1113 = None
        native_batch_norm_backward_default_55 = torch.ops.aten.native_batch_norm_backward.default(view_default_320, view_default_96, None, None, None, getitem_282, getitem_283, True, 1e-08, [True, False, False]);  view_default_320 = view_default_96 = getitem_282 = getitem_283 = None
        getitem_1115 = native_batch_norm_backward_default_55[0];  native_batch_norm_backward_default_55 = None
        view_default_321 = torch.ops.aten.view.default(getitem_1115, [1024, 256, 1, 1]);  getitem_1115 = None
        to_dtype_165 = torch.ops.aten.to.dtype(getitem_1112, torch.float32);  getitem_1112 = None
        to_dtype_166 = torch.ops.aten.to.dtype(relu__default_44, torch.float32);  relu__default_44 = None
        le_scalar_55 = torch.ops.aten.le.Scalar(to_dtype_166, 0);  to_dtype_166 = None
        new_zeros_default_55 = torch.ops.aten.new_zeros.default(to_dtype_165, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_55 = torch.ops.aten.where.self(le_scalar_55, new_zeros_default_55, to_dtype_165);  le_scalar_55 = new_zeros_default_55 = to_dtype_165 = None
        to_dtype_167 = torch.ops.aten.to.dtype(where_self_55, torch.float32);  where_self_55 = None
        native_group_norm_backward_default_55 = torch.ops.aten.native_group_norm_backward.default(to_dtype_167, convolution_default_47, getitem_279, getitem_280, primals_259, 64, 256, 784, 32, [True, True, True]);  to_dtype_167 = convolution_default_47 = getitem_279 = getitem_280 = primals_259 = None
        getitem_1118 = native_group_norm_backward_default_55[0]
        getitem_1119 = native_group_norm_backward_default_55[1]
        getitem_1120 = native_group_norm_backward_default_55[2];  native_group_norm_backward_default_55 = None
        convolution_backward_default_57 = torch.ops.aten.convolution_backward.default(getitem_1118, relu__default_43, view_default_95, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1118 = view_default_95 = None
        getitem_1121 = convolution_backward_default_57[0]
        getitem_1122 = convolution_backward_default_57[1];  convolution_backward_default_57 = None
        view_default_322 = torch.ops.aten.view.default(getitem_1122, [1, 256, 2304]);  getitem_1122 = None
        native_batch_norm_backward_default_56 = torch.ops.aten.native_batch_norm_backward.default(view_default_322, view_default_94, None, None, None, getitem_276, getitem_277, True, 1e-08, [True, False, False]);  view_default_322 = view_default_94 = getitem_276 = getitem_277 = None
        getitem_1124 = native_batch_norm_backward_default_56[0];  native_batch_norm_backward_default_56 = None
        view_default_323 = torch.ops.aten.view.default(getitem_1124, [256, 256, 3, 3]);  getitem_1124 = None
        to_dtype_168 = torch.ops.aten.to.dtype(getitem_1121, torch.float32);  getitem_1121 = None
        to_dtype_169 = torch.ops.aten.to.dtype(relu__default_43, torch.float32);  relu__default_43 = None
        le_scalar_56 = torch.ops.aten.le.Scalar(to_dtype_169, 0);  to_dtype_169 = None
        new_zeros_default_56 = torch.ops.aten.new_zeros.default(to_dtype_168, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_56 = torch.ops.aten.where.self(le_scalar_56, new_zeros_default_56, to_dtype_168);  le_scalar_56 = new_zeros_default_56 = to_dtype_168 = None
        to_dtype_170 = torch.ops.aten.to.dtype(where_self_56, torch.float32);  where_self_56 = None
        native_group_norm_backward_default_56 = torch.ops.aten.native_group_norm_backward.default(to_dtype_170, convolution_default_46, getitem_273, getitem_274, primals_257, 64, 256, 784, 32, [True, True, True]);  to_dtype_170 = convolution_default_46 = getitem_273 = getitem_274 = primals_257 = None
        getitem_1127 = native_group_norm_backward_default_56[0]
        getitem_1128 = native_group_norm_backward_default_56[1]
        getitem_1129 = native_group_norm_backward_default_56[2];  native_group_norm_backward_default_56 = None
        convolution_backward_default_58 = torch.ops.aten.convolution_backward.default(getitem_1127, relu__default_42, view_default_93, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1127 = view_default_93 = None
        getitem_1130 = convolution_backward_default_58[0]
        getitem_1131 = convolution_backward_default_58[1];  convolution_backward_default_58 = None
        view_default_324 = torch.ops.aten.view.default(getitem_1131, [1, 256, 1024]);  getitem_1131 = None
        native_batch_norm_backward_default_57 = torch.ops.aten.native_batch_norm_backward.default(view_default_324, view_default_92, None, None, None, getitem_270, getitem_271, True, 1e-08, [True, False, False]);  view_default_324 = view_default_92 = getitem_270 = getitem_271 = None
        getitem_1133 = native_batch_norm_backward_default_57[0];  native_batch_norm_backward_default_57 = None
        view_default_325 = torch.ops.aten.view.default(getitem_1133, [256, 1024, 1, 1]);  getitem_1133 = None
        to_dtype_171 = torch.ops.aten.to.dtype(getitem_1130, torch.float32);  getitem_1130 = None
        to_dtype_172 = torch.ops.aten.to.dtype(relu__default_42, torch.float32);  relu__default_42 = None
        le_scalar_57 = torch.ops.aten.le.Scalar(to_dtype_172, 0);  to_dtype_172 = None
        new_zeros_default_57 = torch.ops.aten.new_zeros.default(to_dtype_171, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_57 = torch.ops.aten.where.self(le_scalar_57, new_zeros_default_57, to_dtype_171);  le_scalar_57 = new_zeros_default_57 = to_dtype_171 = None
        to_dtype_173 = torch.ops.aten.to.dtype(where_self_57, torch.float32);  where_self_57 = None
        native_group_norm_backward_default_57 = torch.ops.aten.native_group_norm_backward.default(to_dtype_173, add_tensor_13, getitem_267, getitem_268, primals_255, 64, 1024, 784, 32, [True, True, True]);  to_dtype_173 = add_tensor_13 = getitem_267 = getitem_268 = primals_255 = None
        getitem_1136 = native_group_norm_backward_default_57[0]
        getitem_1137 = native_group_norm_backward_default_57[1]
        getitem_1138 = native_group_norm_backward_default_57[2];  native_group_norm_backward_default_57 = None
        add_tensor_51 = torch.ops.aten.add.Tensor(add_tensor_50, getitem_1136);  add_tensor_50 = getitem_1136 = None
        convolution_backward_default_59 = torch.ops.aten.convolution_backward.default(add_tensor_51, relu__default_41, view_default_91, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_91 = None
        getitem_1139 = convolution_backward_default_59[0]
        getitem_1140 = convolution_backward_default_59[1];  convolution_backward_default_59 = None
        view_default_326 = torch.ops.aten.view.default(getitem_1140, [1, 1024, 256]);  getitem_1140 = None
        native_batch_norm_backward_default_58 = torch.ops.aten.native_batch_norm_backward.default(view_default_326, view_default_90, None, None, None, getitem_264, getitem_265, True, 1e-08, [True, False, False]);  view_default_326 = view_default_90 = getitem_264 = getitem_265 = None
        getitem_1142 = native_batch_norm_backward_default_58[0];  native_batch_norm_backward_default_58 = None
        view_default_327 = torch.ops.aten.view.default(getitem_1142, [1024, 256, 1, 1]);  getitem_1142 = None
        to_dtype_174 = torch.ops.aten.to.dtype(getitem_1139, torch.float32);  getitem_1139 = None
        to_dtype_175 = torch.ops.aten.to.dtype(relu__default_41, torch.float32);  relu__default_41 = None
        le_scalar_58 = torch.ops.aten.le.Scalar(to_dtype_175, 0);  to_dtype_175 = None
        new_zeros_default_58 = torch.ops.aten.new_zeros.default(to_dtype_174, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_58 = torch.ops.aten.where.self(le_scalar_58, new_zeros_default_58, to_dtype_174);  le_scalar_58 = new_zeros_default_58 = to_dtype_174 = None
        to_dtype_176 = torch.ops.aten.to.dtype(where_self_58, torch.float32);  where_self_58 = None
        native_group_norm_backward_default_58 = torch.ops.aten.native_group_norm_backward.default(to_dtype_176, convolution_default_44, getitem_261, getitem_262, primals_250, 64, 256, 784, 32, [True, True, True]);  to_dtype_176 = convolution_default_44 = getitem_261 = getitem_262 = primals_250 = None
        getitem_1145 = native_group_norm_backward_default_58[0]
        getitem_1146 = native_group_norm_backward_default_58[1]
        getitem_1147 = native_group_norm_backward_default_58[2];  native_group_norm_backward_default_58 = None
        convolution_backward_default_60 = torch.ops.aten.convolution_backward.default(getitem_1145, relu__default_40, view_default_89, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1145 = view_default_89 = None
        getitem_1148 = convolution_backward_default_60[0]
        getitem_1149 = convolution_backward_default_60[1];  convolution_backward_default_60 = None
        view_default_328 = torch.ops.aten.view.default(getitem_1149, [1, 256, 2304]);  getitem_1149 = None
        native_batch_norm_backward_default_59 = torch.ops.aten.native_batch_norm_backward.default(view_default_328, view_default_88, None, None, None, getitem_258, getitem_259, True, 1e-08, [True, False, False]);  view_default_328 = view_default_88 = getitem_258 = getitem_259 = None
        getitem_1151 = native_batch_norm_backward_default_59[0];  native_batch_norm_backward_default_59 = None
        view_default_329 = torch.ops.aten.view.default(getitem_1151, [256, 256, 3, 3]);  getitem_1151 = None
        to_dtype_177 = torch.ops.aten.to.dtype(getitem_1148, torch.float32);  getitem_1148 = None
        to_dtype_178 = torch.ops.aten.to.dtype(relu__default_40, torch.float32);  relu__default_40 = None
        le_scalar_59 = torch.ops.aten.le.Scalar(to_dtype_178, 0);  to_dtype_178 = None
        new_zeros_default_59 = torch.ops.aten.new_zeros.default(to_dtype_177, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_59 = torch.ops.aten.where.self(le_scalar_59, new_zeros_default_59, to_dtype_177);  le_scalar_59 = new_zeros_default_59 = to_dtype_177 = None
        to_dtype_179 = torch.ops.aten.to.dtype(where_self_59, torch.float32);  where_self_59 = None
        native_group_norm_backward_default_59 = torch.ops.aten.native_group_norm_backward.default(to_dtype_179, convolution_default_43, getitem_255, getitem_256, primals_248, 64, 256, 784, 32, [True, True, True]);  to_dtype_179 = convolution_default_43 = getitem_255 = getitem_256 = primals_248 = None
        getitem_1154 = native_group_norm_backward_default_59[0]
        getitem_1155 = native_group_norm_backward_default_59[1]
        getitem_1156 = native_group_norm_backward_default_59[2];  native_group_norm_backward_default_59 = None
        convolution_backward_default_61 = torch.ops.aten.convolution_backward.default(getitem_1154, relu__default_39, view_default_87, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1154 = view_default_87 = None
        getitem_1157 = convolution_backward_default_61[0]
        getitem_1158 = convolution_backward_default_61[1];  convolution_backward_default_61 = None
        view_default_330 = torch.ops.aten.view.default(getitem_1158, [1, 256, 1024]);  getitem_1158 = None
        native_batch_norm_backward_default_60 = torch.ops.aten.native_batch_norm_backward.default(view_default_330, view_default_86, None, None, None, getitem_252, getitem_253, True, 1e-08, [True, False, False]);  view_default_330 = view_default_86 = getitem_252 = getitem_253 = None
        getitem_1160 = native_batch_norm_backward_default_60[0];  native_batch_norm_backward_default_60 = None
        view_default_331 = torch.ops.aten.view.default(getitem_1160, [256, 1024, 1, 1]);  getitem_1160 = None
        to_dtype_180 = torch.ops.aten.to.dtype(getitem_1157, torch.float32);  getitem_1157 = None
        to_dtype_181 = torch.ops.aten.to.dtype(relu__default_39, torch.float32);  relu__default_39 = None
        le_scalar_60 = torch.ops.aten.le.Scalar(to_dtype_181, 0);  to_dtype_181 = None
        new_zeros_default_60 = torch.ops.aten.new_zeros.default(to_dtype_180, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_60 = torch.ops.aten.where.self(le_scalar_60, new_zeros_default_60, to_dtype_180);  le_scalar_60 = new_zeros_default_60 = to_dtype_180 = None
        to_dtype_182 = torch.ops.aten.to.dtype(where_self_60, torch.float32);  where_self_60 = None
        native_group_norm_backward_default_60 = torch.ops.aten.native_group_norm_backward.default(to_dtype_182, add_tensor_12, getitem_249, getitem_250, primals_246, 64, 1024, 784, 32, [True, True, True]);  to_dtype_182 = add_tensor_12 = getitem_249 = getitem_250 = primals_246 = None
        getitem_1163 = native_group_norm_backward_default_60[0]
        getitem_1164 = native_group_norm_backward_default_60[1]
        getitem_1165 = native_group_norm_backward_default_60[2];  native_group_norm_backward_default_60 = None
        add_tensor_52 = torch.ops.aten.add.Tensor(add_tensor_51, getitem_1163);  add_tensor_51 = getitem_1163 = None
        convolution_backward_default_62 = torch.ops.aten.convolution_backward.default(add_tensor_52, relu__default_38, view_default_85, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_85 = None
        getitem_1166 = convolution_backward_default_62[0]
        getitem_1167 = convolution_backward_default_62[1];  convolution_backward_default_62 = None
        view_default_332 = torch.ops.aten.view.default(getitem_1167, [1, 1024, 256]);  getitem_1167 = None
        native_batch_norm_backward_default_61 = torch.ops.aten.native_batch_norm_backward.default(view_default_332, view_default_84, None, None, None, getitem_246, getitem_247, True, 1e-08, [True, False, False]);  view_default_332 = view_default_84 = getitem_246 = getitem_247 = None
        getitem_1169 = native_batch_norm_backward_default_61[0];  native_batch_norm_backward_default_61 = None
        view_default_333 = torch.ops.aten.view.default(getitem_1169, [1024, 256, 1, 1]);  getitem_1169 = None
        to_dtype_183 = torch.ops.aten.to.dtype(getitem_1166, torch.float32);  getitem_1166 = None
        to_dtype_184 = torch.ops.aten.to.dtype(relu__default_38, torch.float32);  relu__default_38 = None
        le_scalar_61 = torch.ops.aten.le.Scalar(to_dtype_184, 0);  to_dtype_184 = None
        new_zeros_default_61 = torch.ops.aten.new_zeros.default(to_dtype_183, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_61 = torch.ops.aten.where.self(le_scalar_61, new_zeros_default_61, to_dtype_183);  le_scalar_61 = new_zeros_default_61 = to_dtype_183 = None
        to_dtype_185 = torch.ops.aten.to.dtype(where_self_61, torch.float32);  where_self_61 = None
        native_group_norm_backward_default_61 = torch.ops.aten.native_group_norm_backward.default(to_dtype_185, convolution_default_41, getitem_243, getitem_244, primals_241, 64, 256, 784, 32, [True, True, True]);  to_dtype_185 = convolution_default_41 = getitem_243 = getitem_244 = primals_241 = None
        getitem_1172 = native_group_norm_backward_default_61[0]
        getitem_1173 = native_group_norm_backward_default_61[1]
        getitem_1174 = native_group_norm_backward_default_61[2];  native_group_norm_backward_default_61 = None
        convolution_backward_default_63 = torch.ops.aten.convolution_backward.default(getitem_1172, relu__default_37, view_default_83, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1172 = view_default_83 = None
        getitem_1175 = convolution_backward_default_63[0]
        getitem_1176 = convolution_backward_default_63[1];  convolution_backward_default_63 = None
        view_default_334 = torch.ops.aten.view.default(getitem_1176, [1, 256, 2304]);  getitem_1176 = None
        native_batch_norm_backward_default_62 = torch.ops.aten.native_batch_norm_backward.default(view_default_334, view_default_82, None, None, None, getitem_240, getitem_241, True, 1e-08, [True, False, False]);  view_default_334 = view_default_82 = getitem_240 = getitem_241 = None
        getitem_1178 = native_batch_norm_backward_default_62[0];  native_batch_norm_backward_default_62 = None
        view_default_335 = torch.ops.aten.view.default(getitem_1178, [256, 256, 3, 3]);  getitem_1178 = None
        to_dtype_186 = torch.ops.aten.to.dtype(getitem_1175, torch.float32);  getitem_1175 = None
        to_dtype_187 = torch.ops.aten.to.dtype(relu__default_37, torch.float32);  relu__default_37 = None
        le_scalar_62 = torch.ops.aten.le.Scalar(to_dtype_187, 0);  to_dtype_187 = None
        new_zeros_default_62 = torch.ops.aten.new_zeros.default(to_dtype_186, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_62 = torch.ops.aten.where.self(le_scalar_62, new_zeros_default_62, to_dtype_186);  le_scalar_62 = new_zeros_default_62 = to_dtype_186 = None
        to_dtype_188 = torch.ops.aten.to.dtype(where_self_62, torch.float32);  where_self_62 = None
        native_group_norm_backward_default_62 = torch.ops.aten.native_group_norm_backward.default(to_dtype_188, convolution_default_40, getitem_237, getitem_238, primals_239, 64, 256, 784, 32, [True, True, True]);  to_dtype_188 = convolution_default_40 = getitem_237 = getitem_238 = primals_239 = None
        getitem_1181 = native_group_norm_backward_default_62[0]
        getitem_1182 = native_group_norm_backward_default_62[1]
        getitem_1183 = native_group_norm_backward_default_62[2];  native_group_norm_backward_default_62 = None
        convolution_backward_default_64 = torch.ops.aten.convolution_backward.default(getitem_1181, relu__default_36, view_default_81, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1181 = view_default_81 = None
        getitem_1184 = convolution_backward_default_64[0]
        getitem_1185 = convolution_backward_default_64[1];  convolution_backward_default_64 = None
        view_default_336 = torch.ops.aten.view.default(getitem_1185, [1, 256, 1024]);  getitem_1185 = None
        native_batch_norm_backward_default_63 = torch.ops.aten.native_batch_norm_backward.default(view_default_336, view_default_80, None, None, None, getitem_234, getitem_235, True, 1e-08, [True, False, False]);  view_default_336 = view_default_80 = getitem_234 = getitem_235 = None
        getitem_1187 = native_batch_norm_backward_default_63[0];  native_batch_norm_backward_default_63 = None
        view_default_337 = torch.ops.aten.view.default(getitem_1187, [256, 1024, 1, 1]);  getitem_1187 = None
        to_dtype_189 = torch.ops.aten.to.dtype(getitem_1184, torch.float32);  getitem_1184 = None
        to_dtype_190 = torch.ops.aten.to.dtype(relu__default_36, torch.float32);  relu__default_36 = None
        le_scalar_63 = torch.ops.aten.le.Scalar(to_dtype_190, 0);  to_dtype_190 = None
        new_zeros_default_63 = torch.ops.aten.new_zeros.default(to_dtype_189, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_63 = torch.ops.aten.where.self(le_scalar_63, new_zeros_default_63, to_dtype_189);  le_scalar_63 = new_zeros_default_63 = to_dtype_189 = None
        to_dtype_191 = torch.ops.aten.to.dtype(where_self_63, torch.float32);  where_self_63 = None
        native_group_norm_backward_default_63 = torch.ops.aten.native_group_norm_backward.default(to_dtype_191, add_tensor_11, getitem_231, getitem_232, primals_237, 64, 1024, 784, 32, [True, True, True]);  to_dtype_191 = add_tensor_11 = getitem_231 = getitem_232 = primals_237 = None
        getitem_1190 = native_group_norm_backward_default_63[0]
        getitem_1191 = native_group_norm_backward_default_63[1]
        getitem_1192 = native_group_norm_backward_default_63[2];  native_group_norm_backward_default_63 = None
        add_tensor_53 = torch.ops.aten.add.Tensor(add_tensor_52, getitem_1190);  add_tensor_52 = getitem_1190 = None
        convolution_backward_default_65 = torch.ops.aten.convolution_backward.default(add_tensor_53, relu__default_35, view_default_79, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_79 = None
        getitem_1193 = convolution_backward_default_65[0]
        getitem_1194 = convolution_backward_default_65[1];  convolution_backward_default_65 = None
        view_default_338 = torch.ops.aten.view.default(getitem_1194, [1, 1024, 256]);  getitem_1194 = None
        native_batch_norm_backward_default_64 = torch.ops.aten.native_batch_norm_backward.default(view_default_338, view_default_78, None, None, None, getitem_228, getitem_229, True, 1e-08, [True, False, False]);  view_default_338 = view_default_78 = getitem_228 = getitem_229 = None
        getitem_1196 = native_batch_norm_backward_default_64[0];  native_batch_norm_backward_default_64 = None
        view_default_339 = torch.ops.aten.view.default(getitem_1196, [1024, 256, 1, 1]);  getitem_1196 = None
        to_dtype_192 = torch.ops.aten.to.dtype(getitem_1193, torch.float32);  getitem_1193 = None
        to_dtype_193 = torch.ops.aten.to.dtype(relu__default_35, torch.float32);  relu__default_35 = None
        le_scalar_64 = torch.ops.aten.le.Scalar(to_dtype_193, 0);  to_dtype_193 = None
        new_zeros_default_64 = torch.ops.aten.new_zeros.default(to_dtype_192, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_64 = torch.ops.aten.where.self(le_scalar_64, new_zeros_default_64, to_dtype_192);  le_scalar_64 = new_zeros_default_64 = to_dtype_192 = None
        to_dtype_194 = torch.ops.aten.to.dtype(where_self_64, torch.float32);  where_self_64 = None
        native_group_norm_backward_default_64 = torch.ops.aten.native_group_norm_backward.default(to_dtype_194, convolution_default_38, getitem_225, getitem_226, primals_232, 64, 256, 784, 32, [True, True, True]);  to_dtype_194 = convolution_default_38 = getitem_225 = getitem_226 = primals_232 = None
        getitem_1199 = native_group_norm_backward_default_64[0]
        getitem_1200 = native_group_norm_backward_default_64[1]
        getitem_1201 = native_group_norm_backward_default_64[2];  native_group_norm_backward_default_64 = None
        convolution_backward_default_66 = torch.ops.aten.convolution_backward.default(getitem_1199, relu__default_34, view_default_77, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1199 = view_default_77 = None
        getitem_1202 = convolution_backward_default_66[0]
        getitem_1203 = convolution_backward_default_66[1];  convolution_backward_default_66 = None
        view_default_340 = torch.ops.aten.view.default(getitem_1203, [1, 256, 2304]);  getitem_1203 = None
        native_batch_norm_backward_default_65 = torch.ops.aten.native_batch_norm_backward.default(view_default_340, view_default_76, None, None, None, getitem_222, getitem_223, True, 1e-08, [True, False, False]);  view_default_340 = view_default_76 = getitem_222 = getitem_223 = None
        getitem_1205 = native_batch_norm_backward_default_65[0];  native_batch_norm_backward_default_65 = None
        view_default_341 = torch.ops.aten.view.default(getitem_1205, [256, 256, 3, 3]);  getitem_1205 = None
        to_dtype_195 = torch.ops.aten.to.dtype(getitem_1202, torch.float32);  getitem_1202 = None
        to_dtype_196 = torch.ops.aten.to.dtype(relu__default_34, torch.float32);  relu__default_34 = None
        le_scalar_65 = torch.ops.aten.le.Scalar(to_dtype_196, 0);  to_dtype_196 = None
        new_zeros_default_65 = torch.ops.aten.new_zeros.default(to_dtype_195, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_65 = torch.ops.aten.where.self(le_scalar_65, new_zeros_default_65, to_dtype_195);  le_scalar_65 = new_zeros_default_65 = to_dtype_195 = None
        to_dtype_197 = torch.ops.aten.to.dtype(where_self_65, torch.float32);  where_self_65 = None
        native_group_norm_backward_default_65 = torch.ops.aten.native_group_norm_backward.default(to_dtype_197, convolution_default_37, getitem_219, getitem_220, primals_230, 64, 256, 784, 32, [True, True, True]);  to_dtype_197 = convolution_default_37 = getitem_219 = getitem_220 = primals_230 = None
        getitem_1208 = native_group_norm_backward_default_65[0]
        getitem_1209 = native_group_norm_backward_default_65[1]
        getitem_1210 = native_group_norm_backward_default_65[2];  native_group_norm_backward_default_65 = None
        convolution_backward_default_67 = torch.ops.aten.convolution_backward.default(getitem_1208, relu__default_33, view_default_75, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1208 = view_default_75 = None
        getitem_1211 = convolution_backward_default_67[0]
        getitem_1212 = convolution_backward_default_67[1];  convolution_backward_default_67 = None
        view_default_342 = torch.ops.aten.view.default(getitem_1212, [1, 256, 1024]);  getitem_1212 = None
        native_batch_norm_backward_default_66 = torch.ops.aten.native_batch_norm_backward.default(view_default_342, view_default_74, None, None, None, getitem_216, getitem_217, True, 1e-08, [True, False, False]);  view_default_342 = view_default_74 = getitem_216 = getitem_217 = None
        getitem_1214 = native_batch_norm_backward_default_66[0];  native_batch_norm_backward_default_66 = None
        view_default_343 = torch.ops.aten.view.default(getitem_1214, [256, 1024, 1, 1]);  getitem_1214 = None
        to_dtype_198 = torch.ops.aten.to.dtype(getitem_1211, torch.float32);  getitem_1211 = None
        to_dtype_199 = torch.ops.aten.to.dtype(relu__default_33, torch.float32);  relu__default_33 = None
        le_scalar_66 = torch.ops.aten.le.Scalar(to_dtype_199, 0);  to_dtype_199 = None
        new_zeros_default_66 = torch.ops.aten.new_zeros.default(to_dtype_198, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_66 = torch.ops.aten.where.self(le_scalar_66, new_zeros_default_66, to_dtype_198);  le_scalar_66 = new_zeros_default_66 = to_dtype_198 = None
        to_dtype_200 = torch.ops.aten.to.dtype(where_self_66, torch.float32);  where_self_66 = None
        native_group_norm_backward_default_66 = torch.ops.aten.native_group_norm_backward.default(to_dtype_200, add_tensor_10, getitem_213, getitem_214, primals_228, 64, 1024, 784, 32, [True, True, True]);  to_dtype_200 = add_tensor_10 = getitem_213 = getitem_214 = primals_228 = None
        getitem_1217 = native_group_norm_backward_default_66[0]
        getitem_1218 = native_group_norm_backward_default_66[1]
        getitem_1219 = native_group_norm_backward_default_66[2];  native_group_norm_backward_default_66 = None
        add_tensor_54 = torch.ops.aten.add.Tensor(add_tensor_53, getitem_1217);  add_tensor_53 = getitem_1217 = None
        convolution_backward_default_68 = torch.ops.aten.convolution_backward.default(add_tensor_54, relu__default_32, view_default_73, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_73 = None
        getitem_1220 = convolution_backward_default_68[0]
        getitem_1221 = convolution_backward_default_68[1];  convolution_backward_default_68 = None
        view_default_344 = torch.ops.aten.view.default(getitem_1221, [1, 1024, 256]);  getitem_1221 = None
        native_batch_norm_backward_default_67 = torch.ops.aten.native_batch_norm_backward.default(view_default_344, view_default_72, None, None, None, getitem_210, getitem_211, True, 1e-08, [True, False, False]);  view_default_344 = view_default_72 = getitem_210 = getitem_211 = None
        getitem_1223 = native_batch_norm_backward_default_67[0];  native_batch_norm_backward_default_67 = None
        view_default_345 = torch.ops.aten.view.default(getitem_1223, [1024, 256, 1, 1]);  getitem_1223 = None
        to_dtype_201 = torch.ops.aten.to.dtype(getitem_1220, torch.float32);  getitem_1220 = None
        to_dtype_202 = torch.ops.aten.to.dtype(relu__default_32, torch.float32);  relu__default_32 = None
        le_scalar_67 = torch.ops.aten.le.Scalar(to_dtype_202, 0);  to_dtype_202 = None
        new_zeros_default_67 = torch.ops.aten.new_zeros.default(to_dtype_201, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_67 = torch.ops.aten.where.self(le_scalar_67, new_zeros_default_67, to_dtype_201);  le_scalar_67 = new_zeros_default_67 = to_dtype_201 = None
        to_dtype_203 = torch.ops.aten.to.dtype(where_self_67, torch.float32);  where_self_67 = None
        native_group_norm_backward_default_67 = torch.ops.aten.native_group_norm_backward.default(to_dtype_203, convolution_default_35, getitem_207, getitem_208, primals_223, 64, 256, 784, 32, [True, True, True]);  to_dtype_203 = convolution_default_35 = getitem_207 = getitem_208 = primals_223 = None
        getitem_1226 = native_group_norm_backward_default_67[0]
        getitem_1227 = native_group_norm_backward_default_67[1]
        getitem_1228 = native_group_norm_backward_default_67[2];  native_group_norm_backward_default_67 = None
        convolution_backward_default_69 = torch.ops.aten.convolution_backward.default(getitem_1226, relu__default_31, view_default_71, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1226 = view_default_71 = None
        getitem_1229 = convolution_backward_default_69[0]
        getitem_1230 = convolution_backward_default_69[1];  convolution_backward_default_69 = None
        view_default_346 = torch.ops.aten.view.default(getitem_1230, [1, 256, 2304]);  getitem_1230 = None
        native_batch_norm_backward_default_68 = torch.ops.aten.native_batch_norm_backward.default(view_default_346, view_default_70, None, None, None, getitem_204, getitem_205, True, 1e-08, [True, False, False]);  view_default_346 = view_default_70 = getitem_204 = getitem_205 = None
        getitem_1232 = native_batch_norm_backward_default_68[0];  native_batch_norm_backward_default_68 = None
        view_default_347 = torch.ops.aten.view.default(getitem_1232, [256, 256, 3, 3]);  getitem_1232 = None
        to_dtype_204 = torch.ops.aten.to.dtype(getitem_1229, torch.float32);  getitem_1229 = None
        to_dtype_205 = torch.ops.aten.to.dtype(relu__default_31, torch.float32);  relu__default_31 = None
        le_scalar_68 = torch.ops.aten.le.Scalar(to_dtype_205, 0);  to_dtype_205 = None
        new_zeros_default_68 = torch.ops.aten.new_zeros.default(to_dtype_204, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_68 = torch.ops.aten.where.self(le_scalar_68, new_zeros_default_68, to_dtype_204);  le_scalar_68 = new_zeros_default_68 = to_dtype_204 = None
        to_dtype_206 = torch.ops.aten.to.dtype(where_self_68, torch.float32);  where_self_68 = None
        native_group_norm_backward_default_68 = torch.ops.aten.native_group_norm_backward.default(to_dtype_206, convolution_default_34, getitem_201, getitem_202, primals_221, 64, 256, 784, 32, [True, True, True]);  to_dtype_206 = convolution_default_34 = getitem_201 = getitem_202 = primals_221 = None
        getitem_1235 = native_group_norm_backward_default_68[0]
        getitem_1236 = native_group_norm_backward_default_68[1]
        getitem_1237 = native_group_norm_backward_default_68[2];  native_group_norm_backward_default_68 = None
        convolution_backward_default_70 = torch.ops.aten.convolution_backward.default(getitem_1235, relu__default_30, view_default_69, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1235 = view_default_69 = None
        getitem_1238 = convolution_backward_default_70[0]
        getitem_1239 = convolution_backward_default_70[1];  convolution_backward_default_70 = None
        view_default_348 = torch.ops.aten.view.default(getitem_1239, [1, 256, 1024]);  getitem_1239 = None
        native_batch_norm_backward_default_69 = torch.ops.aten.native_batch_norm_backward.default(view_default_348, view_default_68, None, None, None, getitem_198, getitem_199, True, 1e-08, [True, False, False]);  view_default_348 = view_default_68 = getitem_198 = getitem_199 = None
        getitem_1241 = native_batch_norm_backward_default_69[0];  native_batch_norm_backward_default_69 = None
        view_default_349 = torch.ops.aten.view.default(getitem_1241, [256, 1024, 1, 1]);  getitem_1241 = None
        to_dtype_207 = torch.ops.aten.to.dtype(getitem_1238, torch.float32);  getitem_1238 = None
        to_dtype_208 = torch.ops.aten.to.dtype(relu__default_30, torch.float32);  relu__default_30 = None
        le_scalar_69 = torch.ops.aten.le.Scalar(to_dtype_208, 0);  to_dtype_208 = None
        new_zeros_default_69 = torch.ops.aten.new_zeros.default(to_dtype_207, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_69 = torch.ops.aten.where.self(le_scalar_69, new_zeros_default_69, to_dtype_207);  le_scalar_69 = new_zeros_default_69 = to_dtype_207 = None
        to_dtype_209 = torch.ops.aten.to.dtype(where_self_69, torch.float32);  where_self_69 = None
        native_group_norm_backward_default_69 = torch.ops.aten.native_group_norm_backward.default(to_dtype_209, add_tensor_9, getitem_195, getitem_196, primals_219, 64, 1024, 784, 32, [True, True, True]);  to_dtype_209 = add_tensor_9 = getitem_195 = getitem_196 = primals_219 = None
        getitem_1244 = native_group_norm_backward_default_69[0]
        getitem_1245 = native_group_norm_backward_default_69[1]
        getitem_1246 = native_group_norm_backward_default_69[2];  native_group_norm_backward_default_69 = None
        add_tensor_55 = torch.ops.aten.add.Tensor(add_tensor_54, getitem_1244);  add_tensor_54 = getitem_1244 = None
        convolution_backward_default_71 = torch.ops.aten.convolution_backward.default(add_tensor_55, relu__default_29, view_default_67, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_67 = None
        getitem_1247 = convolution_backward_default_71[0]
        getitem_1248 = convolution_backward_default_71[1];  convolution_backward_default_71 = None
        view_default_350 = torch.ops.aten.view.default(getitem_1248, [1, 1024, 256]);  getitem_1248 = None
        native_batch_norm_backward_default_70 = torch.ops.aten.native_batch_norm_backward.default(view_default_350, view_default_66, None, None, None, getitem_192, getitem_193, True, 1e-08, [True, False, False]);  view_default_350 = view_default_66 = getitem_192 = getitem_193 = None
        getitem_1250 = native_batch_norm_backward_default_70[0];  native_batch_norm_backward_default_70 = None
        view_default_351 = torch.ops.aten.view.default(getitem_1250, [1024, 256, 1, 1]);  getitem_1250 = None
        to_dtype_210 = torch.ops.aten.to.dtype(getitem_1247, torch.float32);  getitem_1247 = None
        to_dtype_211 = torch.ops.aten.to.dtype(relu__default_29, torch.float32);  relu__default_29 = None
        le_scalar_70 = torch.ops.aten.le.Scalar(to_dtype_211, 0);  to_dtype_211 = None
        new_zeros_default_70 = torch.ops.aten.new_zeros.default(to_dtype_210, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_70 = torch.ops.aten.where.self(le_scalar_70, new_zeros_default_70, to_dtype_210);  le_scalar_70 = new_zeros_default_70 = to_dtype_210 = None
        to_dtype_212 = torch.ops.aten.to.dtype(where_self_70, torch.float32);  where_self_70 = None
        native_group_norm_backward_default_70 = torch.ops.aten.native_group_norm_backward.default(to_dtype_212, convolution_default_32, getitem_189, getitem_190, primals_214, 64, 256, 784, 32, [True, True, True]);  to_dtype_212 = convolution_default_32 = getitem_189 = getitem_190 = primals_214 = None
        getitem_1253 = native_group_norm_backward_default_70[0]
        getitem_1254 = native_group_norm_backward_default_70[1]
        getitem_1255 = native_group_norm_backward_default_70[2];  native_group_norm_backward_default_70 = None
        convolution_backward_default_72 = torch.ops.aten.convolution_backward.default(getitem_1253, relu__default_28, view_default_65, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1253 = view_default_65 = None
        getitem_1256 = convolution_backward_default_72[0]
        getitem_1257 = convolution_backward_default_72[1];  convolution_backward_default_72 = None
        view_default_352 = torch.ops.aten.view.default(getitem_1257, [1, 256, 2304]);  getitem_1257 = None
        native_batch_norm_backward_default_71 = torch.ops.aten.native_batch_norm_backward.default(view_default_352, view_default_64, None, None, None, getitem_186, getitem_187, True, 1e-08, [True, False, False]);  view_default_352 = view_default_64 = getitem_186 = getitem_187 = None
        getitem_1259 = native_batch_norm_backward_default_71[0];  native_batch_norm_backward_default_71 = None
        view_default_353 = torch.ops.aten.view.default(getitem_1259, [256, 256, 3, 3]);  getitem_1259 = None
        to_dtype_213 = torch.ops.aten.to.dtype(getitem_1256, torch.float32);  getitem_1256 = None
        to_dtype_214 = torch.ops.aten.to.dtype(relu__default_28, torch.float32);  relu__default_28 = None
        le_scalar_71 = torch.ops.aten.le.Scalar(to_dtype_214, 0);  to_dtype_214 = None
        new_zeros_default_71 = torch.ops.aten.new_zeros.default(to_dtype_213, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_71 = torch.ops.aten.where.self(le_scalar_71, new_zeros_default_71, to_dtype_213);  le_scalar_71 = new_zeros_default_71 = to_dtype_213 = None
        to_dtype_215 = torch.ops.aten.to.dtype(where_self_71, torch.float32);  where_self_71 = None
        native_group_norm_backward_default_71 = torch.ops.aten.native_group_norm_backward.default(to_dtype_215, convolution_default_31, getitem_183, getitem_184, primals_212, 64, 256, 784, 32, [True, True, True]);  to_dtype_215 = convolution_default_31 = getitem_183 = getitem_184 = primals_212 = None
        getitem_1262 = native_group_norm_backward_default_71[0]
        getitem_1263 = native_group_norm_backward_default_71[1]
        getitem_1264 = native_group_norm_backward_default_71[2];  native_group_norm_backward_default_71 = None
        convolution_backward_default_73 = torch.ops.aten.convolution_backward.default(getitem_1262, relu__default_27, view_default_63, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1262 = view_default_63 = None
        getitem_1265 = convolution_backward_default_73[0]
        getitem_1266 = convolution_backward_default_73[1];  convolution_backward_default_73 = None
        view_default_354 = torch.ops.aten.view.default(getitem_1266, [1, 256, 1024]);  getitem_1266 = None
        native_batch_norm_backward_default_72 = torch.ops.aten.native_batch_norm_backward.default(view_default_354, view_default_62, None, None, None, getitem_180, getitem_181, True, 1e-08, [True, False, False]);  view_default_354 = view_default_62 = getitem_180 = getitem_181 = None
        getitem_1268 = native_batch_norm_backward_default_72[0];  native_batch_norm_backward_default_72 = None
        view_default_355 = torch.ops.aten.view.default(getitem_1268, [256, 1024, 1, 1]);  getitem_1268 = None
        to_dtype_216 = torch.ops.aten.to.dtype(getitem_1265, torch.float32);  getitem_1265 = None
        to_dtype_217 = torch.ops.aten.to.dtype(relu__default_27, torch.float32);  relu__default_27 = None
        le_scalar_72 = torch.ops.aten.le.Scalar(to_dtype_217, 0);  to_dtype_217 = None
        new_zeros_default_72 = torch.ops.aten.new_zeros.default(to_dtype_216, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_72 = torch.ops.aten.where.self(le_scalar_72, new_zeros_default_72, to_dtype_216);  le_scalar_72 = new_zeros_default_72 = to_dtype_216 = None
        to_dtype_218 = torch.ops.aten.to.dtype(where_self_72, torch.float32);  where_self_72 = None
        native_group_norm_backward_default_72 = torch.ops.aten.native_group_norm_backward.default(to_dtype_218, add_tensor_8, getitem_177, getitem_178, primals_210, 64, 1024, 784, 32, [True, True, True]);  to_dtype_218 = add_tensor_8 = getitem_177 = getitem_178 = primals_210 = None
        getitem_1271 = native_group_norm_backward_default_72[0]
        getitem_1272 = native_group_norm_backward_default_72[1]
        getitem_1273 = native_group_norm_backward_default_72[2];  native_group_norm_backward_default_72 = None
        add_tensor_56 = torch.ops.aten.add.Tensor(add_tensor_55, getitem_1271);  add_tensor_55 = getitem_1271 = None
        convolution_backward_default_74 = torch.ops.aten.convolution_backward.default(add_tensor_56, relu__default_26, view_default_61, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_61 = None
        getitem_1274 = convolution_backward_default_74[0]
        getitem_1275 = convolution_backward_default_74[1];  convolution_backward_default_74 = None
        view_default_356 = torch.ops.aten.view.default(getitem_1275, [1, 1024, 256]);  getitem_1275 = None
        native_batch_norm_backward_default_73 = torch.ops.aten.native_batch_norm_backward.default(view_default_356, view_default_60, None, None, None, getitem_174, getitem_175, True, 1e-08, [True, False, False]);  view_default_356 = view_default_60 = getitem_174 = getitem_175 = None
        getitem_1277 = native_batch_norm_backward_default_73[0];  native_batch_norm_backward_default_73 = None
        view_default_357 = torch.ops.aten.view.default(getitem_1277, [1024, 256, 1, 1]);  getitem_1277 = None
        to_dtype_219 = torch.ops.aten.to.dtype(getitem_1274, torch.float32);  getitem_1274 = None
        to_dtype_220 = torch.ops.aten.to.dtype(relu__default_26, torch.float32);  relu__default_26 = None
        le_scalar_73 = torch.ops.aten.le.Scalar(to_dtype_220, 0);  to_dtype_220 = None
        new_zeros_default_73 = torch.ops.aten.new_zeros.default(to_dtype_219, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_73 = torch.ops.aten.where.self(le_scalar_73, new_zeros_default_73, to_dtype_219);  le_scalar_73 = new_zeros_default_73 = to_dtype_219 = None
        to_dtype_221 = torch.ops.aten.to.dtype(where_self_73, torch.float32);  where_self_73 = None
        native_group_norm_backward_default_73 = torch.ops.aten.native_group_norm_backward.default(to_dtype_221, convolution_default_29, getitem_171, getitem_172, primals_178, 64, 256, 784, 32, [True, True, True]);  to_dtype_221 = convolution_default_29 = getitem_171 = getitem_172 = primals_178 = None
        getitem_1280 = native_group_norm_backward_default_73[0]
        getitem_1281 = native_group_norm_backward_default_73[1]
        getitem_1282 = native_group_norm_backward_default_73[2];  native_group_norm_backward_default_73 = None
        convolution_backward_default_75 = torch.ops.aten.convolution_backward.default(getitem_1280, relu__default_25, view_default_59, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1280 = view_default_59 = None
        getitem_1283 = convolution_backward_default_75[0]
        getitem_1284 = convolution_backward_default_75[1];  convolution_backward_default_75 = None
        view_default_358 = torch.ops.aten.view.default(getitem_1284, [1, 256, 2304]);  getitem_1284 = None
        native_batch_norm_backward_default_74 = torch.ops.aten.native_batch_norm_backward.default(view_default_358, view_default_58, None, None, None, getitem_168, getitem_169, True, 1e-08, [True, False, False]);  view_default_358 = view_default_58 = getitem_168 = getitem_169 = None
        getitem_1286 = native_batch_norm_backward_default_74[0];  native_batch_norm_backward_default_74 = None
        view_default_359 = torch.ops.aten.view.default(getitem_1286, [256, 256, 3, 3]);  getitem_1286 = None
        to_dtype_222 = torch.ops.aten.to.dtype(getitem_1283, torch.float32);  getitem_1283 = None
        to_dtype_223 = torch.ops.aten.to.dtype(relu__default_25, torch.float32);  relu__default_25 = None
        le_scalar_74 = torch.ops.aten.le.Scalar(to_dtype_223, 0);  to_dtype_223 = None
        new_zeros_default_74 = torch.ops.aten.new_zeros.default(to_dtype_222, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_74 = torch.ops.aten.where.self(le_scalar_74, new_zeros_default_74, to_dtype_222);  le_scalar_74 = new_zeros_default_74 = to_dtype_222 = None
        to_dtype_224 = torch.ops.aten.to.dtype(where_self_74, torch.float32);  where_self_74 = None
        native_group_norm_backward_default_74 = torch.ops.aten.native_group_norm_backward.default(to_dtype_224, convolution_default_28, getitem_165, getitem_166, primals_176, 64, 256, 784, 32, [True, True, True]);  to_dtype_224 = convolution_default_28 = getitem_165 = getitem_166 = primals_176 = None
        getitem_1289 = native_group_norm_backward_default_74[0]
        getitem_1290 = native_group_norm_backward_default_74[1]
        getitem_1291 = native_group_norm_backward_default_74[2];  native_group_norm_backward_default_74 = None
        convolution_backward_default_76 = torch.ops.aten.convolution_backward.default(getitem_1289, relu__default_24, view_default_57, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1289 = view_default_57 = None
        getitem_1292 = convolution_backward_default_76[0]
        getitem_1293 = convolution_backward_default_76[1];  convolution_backward_default_76 = None
        view_default_360 = torch.ops.aten.view.default(getitem_1293, [1, 256, 1024]);  getitem_1293 = None
        native_batch_norm_backward_default_75 = torch.ops.aten.native_batch_norm_backward.default(view_default_360, view_default_56, None, None, None, getitem_162, getitem_163, True, 1e-08, [True, False, False]);  view_default_360 = view_default_56 = getitem_162 = getitem_163 = None
        getitem_1295 = native_batch_norm_backward_default_75[0];  native_batch_norm_backward_default_75 = None
        view_default_361 = torch.ops.aten.view.default(getitem_1295, [256, 1024, 1, 1]);  getitem_1295 = None
        to_dtype_225 = torch.ops.aten.to.dtype(getitem_1292, torch.float32);  getitem_1292 = None
        to_dtype_226 = torch.ops.aten.to.dtype(relu__default_24, torch.float32);  relu__default_24 = None
        le_scalar_75 = torch.ops.aten.le.Scalar(to_dtype_226, 0);  to_dtype_226 = None
        new_zeros_default_75 = torch.ops.aten.new_zeros.default(to_dtype_225, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_75 = torch.ops.aten.where.self(le_scalar_75, new_zeros_default_75, to_dtype_225);  le_scalar_75 = new_zeros_default_75 = to_dtype_225 = None
        to_dtype_227 = torch.ops.aten.to.dtype(where_self_75, torch.float32);  where_self_75 = None
        native_group_norm_backward_default_75 = torch.ops.aten.native_group_norm_backward.default(to_dtype_227, add_tensor_7, getitem_159, getitem_160, primals_174, 64, 1024, 784, 32, [True, True, True]);  to_dtype_227 = add_tensor_7 = getitem_159 = getitem_160 = primals_174 = None
        getitem_1298 = native_group_norm_backward_default_75[0]
        getitem_1299 = native_group_norm_backward_default_75[1]
        getitem_1300 = native_group_norm_backward_default_75[2];  native_group_norm_backward_default_75 = None
        add_tensor_57 = torch.ops.aten.add.Tensor(add_tensor_56, getitem_1298);  add_tensor_56 = getitem_1298 = None
        convolution_backward_default_77 = torch.ops.aten.convolution_backward.default(add_tensor_57, relu__default_23, view_default_55, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_55 = None
        getitem_1301 = convolution_backward_default_77[0]
        getitem_1302 = convolution_backward_default_77[1];  convolution_backward_default_77 = None
        view_default_362 = torch.ops.aten.view.default(getitem_1302, [1, 1024, 256]);  getitem_1302 = None
        native_batch_norm_backward_default_76 = torch.ops.aten.native_batch_norm_backward.default(view_default_362, view_default_54, None, None, None, getitem_156, getitem_157, True, 1e-08, [True, False, False]);  view_default_362 = view_default_54 = getitem_156 = getitem_157 = None
        getitem_1304 = native_batch_norm_backward_default_76[0];  native_batch_norm_backward_default_76 = None
        view_default_363 = torch.ops.aten.view.default(getitem_1304, [1024, 256, 1, 1]);  getitem_1304 = None
        to_dtype_228 = torch.ops.aten.to.dtype(getitem_1301, torch.float32);  getitem_1301 = None
        to_dtype_229 = torch.ops.aten.to.dtype(relu__default_23, torch.float32);  relu__default_23 = None
        le_scalar_76 = torch.ops.aten.le.Scalar(to_dtype_229, 0);  to_dtype_229 = None
        new_zeros_default_76 = torch.ops.aten.new_zeros.default(to_dtype_228, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_76 = torch.ops.aten.where.self(le_scalar_76, new_zeros_default_76, to_dtype_228);  le_scalar_76 = new_zeros_default_76 = to_dtype_228 = None
        to_dtype_230 = torch.ops.aten.to.dtype(where_self_76, torch.float32);  where_self_76 = None
        native_group_norm_backward_default_76 = torch.ops.aten.native_group_norm_backward.default(to_dtype_230, convolution_default_26, getitem_153, getitem_154, primals_79, 64, 256, 784, 32, [True, True, True]);  to_dtype_230 = convolution_default_26 = getitem_153 = getitem_154 = primals_79 = None
        getitem_1307 = native_group_norm_backward_default_76[0]
        getitem_1308 = native_group_norm_backward_default_76[1]
        getitem_1309 = native_group_norm_backward_default_76[2];  native_group_norm_backward_default_76 = None
        convolution_backward_default_78 = torch.ops.aten.convolution_backward.default(getitem_1307, relu__default_22, view_default_53, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1307 = view_default_53 = None
        getitem_1310 = convolution_backward_default_78[0]
        getitem_1311 = convolution_backward_default_78[1];  convolution_backward_default_78 = None
        view_default_364 = torch.ops.aten.view.default(getitem_1311, [1, 256, 2304]);  getitem_1311 = None
        native_batch_norm_backward_default_77 = torch.ops.aten.native_batch_norm_backward.default(view_default_364, view_default_52, None, None, None, getitem_150, getitem_151, True, 1e-08, [True, False, False]);  view_default_364 = view_default_52 = getitem_150 = getitem_151 = None
        getitem_1313 = native_batch_norm_backward_default_77[0];  native_batch_norm_backward_default_77 = None
        view_default_365 = torch.ops.aten.view.default(getitem_1313, [256, 256, 3, 3]);  getitem_1313 = None
        to_dtype_231 = torch.ops.aten.to.dtype(getitem_1310, torch.float32);  getitem_1310 = None
        to_dtype_232 = torch.ops.aten.to.dtype(relu__default_22, torch.float32);  relu__default_22 = None
        le_scalar_77 = torch.ops.aten.le.Scalar(to_dtype_232, 0);  to_dtype_232 = None
        new_zeros_default_77 = torch.ops.aten.new_zeros.default(to_dtype_231, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_77 = torch.ops.aten.where.self(le_scalar_77, new_zeros_default_77, to_dtype_231);  le_scalar_77 = new_zeros_default_77 = to_dtype_231 = None
        to_dtype_233 = torch.ops.aten.to.dtype(where_self_77, torch.float32);  where_self_77 = None
        native_group_norm_backward_default_77 = torch.ops.aten.native_group_norm_backward.default(to_dtype_233, convolution_default_25, getitem_147, getitem_148, primals_77, 64, 256, 3136, 32, [True, True, True]);  to_dtype_233 = convolution_default_25 = getitem_147 = getitem_148 = primals_77 = None
        getitem_1316 = native_group_norm_backward_default_77[0]
        getitem_1317 = native_group_norm_backward_default_77[1]
        getitem_1318 = native_group_norm_backward_default_77[2];  native_group_norm_backward_default_77 = None
        convolution_backward_default_79 = torch.ops.aten.convolution_backward.default(getitem_1316, relu__default_21, view_default_51, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1316 = view_default_51 = None
        getitem_1319 = convolution_backward_default_79[0]
        getitem_1320 = convolution_backward_default_79[1];  convolution_backward_default_79 = None
        view_default_366 = torch.ops.aten.view.default(getitem_1320, [1, 256, 512]);  getitem_1320 = None
        native_batch_norm_backward_default_78 = torch.ops.aten.native_batch_norm_backward.default(view_default_366, view_default_50, None, None, None, getitem_144, getitem_145, True, 1e-08, [True, False, False]);  view_default_366 = view_default_50 = getitem_144 = getitem_145 = None
        getitem_1322 = native_batch_norm_backward_default_78[0];  native_batch_norm_backward_default_78 = None
        view_default_367 = torch.ops.aten.view.default(getitem_1322, [256, 512, 1, 1]);  getitem_1322 = None
        convolution_backward_default_80 = torch.ops.aten.convolution_backward.default(add_tensor_57, relu__default_21, view_default_49, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_57 = view_default_49 = None
        getitem_1325 = convolution_backward_default_80[0]
        getitem_1326 = convolution_backward_default_80[1];  convolution_backward_default_80 = None
        add_tensor_58 = torch.ops.aten.add.Tensor(getitem_1319, getitem_1325);  getitem_1319 = getitem_1325 = None
        view_default_368 = torch.ops.aten.view.default(getitem_1326, [1, 1024, 512]);  getitem_1326 = None
        native_batch_norm_backward_default_79 = torch.ops.aten.native_batch_norm_backward.default(view_default_368, view_default_48, None, None, None, getitem_141, getitem_142, True, 1e-08, [True, False, False]);  view_default_368 = view_default_48 = getitem_141 = getitem_142 = None
        getitem_1328 = native_batch_norm_backward_default_79[0];  native_batch_norm_backward_default_79 = None
        view_default_369 = torch.ops.aten.view.default(getitem_1328, [1024, 512, 1, 1]);  getitem_1328 = None
        to_dtype_234 = torch.ops.aten.to.dtype(add_tensor_58, torch.float32);  add_tensor_58 = None
        to_dtype_235 = torch.ops.aten.to.dtype(relu__default_21, torch.float32);  relu__default_21 = None
        le_scalar_78 = torch.ops.aten.le.Scalar(to_dtype_235, 0);  to_dtype_235 = None
        new_zeros_default_78 = torch.ops.aten.new_zeros.default(to_dtype_234, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_78 = torch.ops.aten.where.self(le_scalar_78, new_zeros_default_78, to_dtype_234);  le_scalar_78 = new_zeros_default_78 = to_dtype_234 = None
        to_dtype_236 = torch.ops.aten.to.dtype(where_self_78, torch.float32);  where_self_78 = None
        native_group_norm_backward_default_78 = torch.ops.aten.native_group_norm_backward.default(to_dtype_236, add_tensor_6, getitem_138, getitem_139, primals_75, 64, 512, 3136, 32, [True, True, True]);  to_dtype_236 = add_tensor_6 = getitem_138 = getitem_139 = primals_75 = None
        getitem_1331 = native_group_norm_backward_default_78[0]
        getitem_1332 = native_group_norm_backward_default_78[1]
        getitem_1333 = native_group_norm_backward_default_78[2];  native_group_norm_backward_default_78 = None
        convolution_backward_default_81 = torch.ops.aten.convolution_backward.default(getitem_1331, relu__default_20, view_default_47, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_47 = None
        getitem_1334 = convolution_backward_default_81[0]
        getitem_1335 = convolution_backward_default_81[1];  convolution_backward_default_81 = None
        view_default_370 = torch.ops.aten.view.default(getitem_1335, [1, 512, 128]);  getitem_1335 = None
        native_batch_norm_backward_default_80 = torch.ops.aten.native_batch_norm_backward.default(view_default_370, view_default_46, None, None, None, getitem_135, getitem_136, True, 1e-08, [True, False, False]);  view_default_370 = view_default_46 = getitem_135 = getitem_136 = None
        getitem_1337 = native_batch_norm_backward_default_80[0];  native_batch_norm_backward_default_80 = None
        view_default_371 = torch.ops.aten.view.default(getitem_1337, [512, 128, 1, 1]);  getitem_1337 = None
        to_dtype_237 = torch.ops.aten.to.dtype(getitem_1334, torch.float32);  getitem_1334 = None
        to_dtype_238 = torch.ops.aten.to.dtype(relu__default_20, torch.float32);  relu__default_20 = None
        le_scalar_79 = torch.ops.aten.le.Scalar(to_dtype_238, 0);  to_dtype_238 = None
        new_zeros_default_79 = torch.ops.aten.new_zeros.default(to_dtype_237, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_79 = torch.ops.aten.where.self(le_scalar_79, new_zeros_default_79, to_dtype_237);  le_scalar_79 = new_zeros_default_79 = to_dtype_237 = None
        to_dtype_239 = torch.ops.aten.to.dtype(where_self_79, torch.float32);  where_self_79 = None
        native_group_norm_backward_default_79 = torch.ops.aten.native_group_norm_backward.default(to_dtype_239, convolution_default_22, getitem_132, getitem_133, primals_69, 64, 128, 3136, 32, [True, True, True]);  to_dtype_239 = convolution_default_22 = getitem_132 = getitem_133 = primals_69 = None
        getitem_1340 = native_group_norm_backward_default_79[0]
        getitem_1341 = native_group_norm_backward_default_79[1]
        getitem_1342 = native_group_norm_backward_default_79[2];  native_group_norm_backward_default_79 = None
        convolution_backward_default_82 = torch.ops.aten.convolution_backward.default(getitem_1340, relu__default_19, view_default_45, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1340 = view_default_45 = None
        getitem_1343 = convolution_backward_default_82[0]
        getitem_1344 = convolution_backward_default_82[1];  convolution_backward_default_82 = None
        view_default_372 = torch.ops.aten.view.default(getitem_1344, [1, 128, 1152]);  getitem_1344 = None
        native_batch_norm_backward_default_81 = torch.ops.aten.native_batch_norm_backward.default(view_default_372, view_default_44, None, None, None, getitem_129, getitem_130, True, 1e-08, [True, False, False]);  view_default_372 = view_default_44 = getitem_129 = getitem_130 = None
        getitem_1346 = native_batch_norm_backward_default_81[0];  native_batch_norm_backward_default_81 = None
        view_default_373 = torch.ops.aten.view.default(getitem_1346, [128, 128, 3, 3]);  getitem_1346 = None
        to_dtype_240 = torch.ops.aten.to.dtype(getitem_1343, torch.float32);  getitem_1343 = None
        to_dtype_241 = torch.ops.aten.to.dtype(relu__default_19, torch.float32);  relu__default_19 = None
        le_scalar_80 = torch.ops.aten.le.Scalar(to_dtype_241, 0);  to_dtype_241 = None
        new_zeros_default_80 = torch.ops.aten.new_zeros.default(to_dtype_240, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_80 = torch.ops.aten.where.self(le_scalar_80, new_zeros_default_80, to_dtype_240);  le_scalar_80 = new_zeros_default_80 = to_dtype_240 = None
        to_dtype_242 = torch.ops.aten.to.dtype(where_self_80, torch.float32);  where_self_80 = None
        native_group_norm_backward_default_80 = torch.ops.aten.native_group_norm_backward.default(to_dtype_242, convolution_default_21, getitem_126, getitem_127, primals_67, 64, 128, 3136, 32, [True, True, True]);  to_dtype_242 = convolution_default_21 = getitem_126 = getitem_127 = primals_67 = None
        getitem_1349 = native_group_norm_backward_default_80[0]
        getitem_1350 = native_group_norm_backward_default_80[1]
        getitem_1351 = native_group_norm_backward_default_80[2];  native_group_norm_backward_default_80 = None
        convolution_backward_default_83 = torch.ops.aten.convolution_backward.default(getitem_1349, relu__default_18, view_default_43, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1349 = view_default_43 = None
        getitem_1352 = convolution_backward_default_83[0]
        getitem_1353 = convolution_backward_default_83[1];  convolution_backward_default_83 = None
        view_default_374 = torch.ops.aten.view.default(getitem_1353, [1, 128, 512]);  getitem_1353 = None
        native_batch_norm_backward_default_82 = torch.ops.aten.native_batch_norm_backward.default(view_default_374, view_default_42, None, None, None, getitem_123, getitem_124, True, 1e-08, [True, False, False]);  view_default_374 = view_default_42 = getitem_123 = getitem_124 = None
        getitem_1355 = native_batch_norm_backward_default_82[0];  native_batch_norm_backward_default_82 = None
        view_default_375 = torch.ops.aten.view.default(getitem_1355, [128, 512, 1, 1]);  getitem_1355 = None
        to_dtype_243 = torch.ops.aten.to.dtype(getitem_1352, torch.float32);  getitem_1352 = None
        to_dtype_244 = torch.ops.aten.to.dtype(relu__default_18, torch.float32);  relu__default_18 = None
        le_scalar_81 = torch.ops.aten.le.Scalar(to_dtype_244, 0);  to_dtype_244 = None
        new_zeros_default_81 = torch.ops.aten.new_zeros.default(to_dtype_243, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_81 = torch.ops.aten.where.self(le_scalar_81, new_zeros_default_81, to_dtype_243);  le_scalar_81 = new_zeros_default_81 = to_dtype_243 = None
        to_dtype_245 = torch.ops.aten.to.dtype(where_self_81, torch.float32);  where_self_81 = None
        native_group_norm_backward_default_81 = torch.ops.aten.native_group_norm_backward.default(to_dtype_245, add_tensor_5, getitem_120, getitem_121, primals_65, 64, 512, 3136, 32, [True, True, True]);  to_dtype_245 = add_tensor_5 = getitem_120 = getitem_121 = primals_65 = None
        getitem_1358 = native_group_norm_backward_default_81[0]
        getitem_1359 = native_group_norm_backward_default_81[1]
        getitem_1360 = native_group_norm_backward_default_81[2];  native_group_norm_backward_default_81 = None
        add_tensor_59 = torch.ops.aten.add.Tensor(getitem_1331, getitem_1358);  getitem_1331 = getitem_1358 = None
        convolution_backward_default_84 = torch.ops.aten.convolution_backward.default(add_tensor_59, relu__default_17, view_default_41, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_41 = None
        getitem_1361 = convolution_backward_default_84[0]
        getitem_1362 = convolution_backward_default_84[1];  convolution_backward_default_84 = None
        view_default_376 = torch.ops.aten.view.default(getitem_1362, [1, 512, 128]);  getitem_1362 = None
        native_batch_norm_backward_default_83 = torch.ops.aten.native_batch_norm_backward.default(view_default_376, view_default_40, None, None, None, getitem_117, getitem_118, True, 1e-08, [True, False, False]);  view_default_376 = view_default_40 = getitem_117 = getitem_118 = None
        getitem_1364 = native_batch_norm_backward_default_83[0];  native_batch_norm_backward_default_83 = None
        view_default_377 = torch.ops.aten.view.default(getitem_1364, [512, 128, 1, 1]);  getitem_1364 = None
        to_dtype_246 = torch.ops.aten.to.dtype(getitem_1361, torch.float32);  getitem_1361 = None
        to_dtype_247 = torch.ops.aten.to.dtype(relu__default_17, torch.float32);  relu__default_17 = None
        le_scalar_82 = torch.ops.aten.le.Scalar(to_dtype_247, 0);  to_dtype_247 = None
        new_zeros_default_82 = torch.ops.aten.new_zeros.default(to_dtype_246, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_82 = torch.ops.aten.where.self(le_scalar_82, new_zeros_default_82, to_dtype_246);  le_scalar_82 = new_zeros_default_82 = to_dtype_246 = None
        to_dtype_248 = torch.ops.aten.to.dtype(where_self_82, torch.float32);  where_self_82 = None
        native_group_norm_backward_default_82 = torch.ops.aten.native_group_norm_backward.default(to_dtype_248, convolution_default_19, getitem_114, getitem_115, primals_60, 64, 128, 3136, 32, [True, True, True]);  to_dtype_248 = convolution_default_19 = getitem_114 = getitem_115 = primals_60 = None
        getitem_1367 = native_group_norm_backward_default_82[0]
        getitem_1368 = native_group_norm_backward_default_82[1]
        getitem_1369 = native_group_norm_backward_default_82[2];  native_group_norm_backward_default_82 = None
        convolution_backward_default_85 = torch.ops.aten.convolution_backward.default(getitem_1367, relu__default_16, view_default_39, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1367 = view_default_39 = None
        getitem_1370 = convolution_backward_default_85[0]
        getitem_1371 = convolution_backward_default_85[1];  convolution_backward_default_85 = None
        view_default_378 = torch.ops.aten.view.default(getitem_1371, [1, 128, 1152]);  getitem_1371 = None
        native_batch_norm_backward_default_84 = torch.ops.aten.native_batch_norm_backward.default(view_default_378, view_default_38, None, None, None, getitem_111, getitem_112, True, 1e-08, [True, False, False]);  view_default_378 = view_default_38 = getitem_111 = getitem_112 = None
        getitem_1373 = native_batch_norm_backward_default_84[0];  native_batch_norm_backward_default_84 = None
        view_default_379 = torch.ops.aten.view.default(getitem_1373, [128, 128, 3, 3]);  getitem_1373 = None
        to_dtype_249 = torch.ops.aten.to.dtype(getitem_1370, torch.float32);  getitem_1370 = None
        to_dtype_250 = torch.ops.aten.to.dtype(relu__default_16, torch.float32);  relu__default_16 = None
        le_scalar_83 = torch.ops.aten.le.Scalar(to_dtype_250, 0);  to_dtype_250 = None
        new_zeros_default_83 = torch.ops.aten.new_zeros.default(to_dtype_249, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_83 = torch.ops.aten.where.self(le_scalar_83, new_zeros_default_83, to_dtype_249);  le_scalar_83 = new_zeros_default_83 = to_dtype_249 = None
        to_dtype_251 = torch.ops.aten.to.dtype(where_self_83, torch.float32);  where_self_83 = None
        native_group_norm_backward_default_83 = torch.ops.aten.native_group_norm_backward.default(to_dtype_251, convolution_default_18, getitem_108, getitem_109, primals_58, 64, 128, 3136, 32, [True, True, True]);  to_dtype_251 = convolution_default_18 = getitem_108 = getitem_109 = primals_58 = None
        getitem_1376 = native_group_norm_backward_default_83[0]
        getitem_1377 = native_group_norm_backward_default_83[1]
        getitem_1378 = native_group_norm_backward_default_83[2];  native_group_norm_backward_default_83 = None
        convolution_backward_default_86 = torch.ops.aten.convolution_backward.default(getitem_1376, relu__default_15, view_default_37, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1376 = view_default_37 = None
        getitem_1379 = convolution_backward_default_86[0]
        getitem_1380 = convolution_backward_default_86[1];  convolution_backward_default_86 = None
        view_default_380 = torch.ops.aten.view.default(getitem_1380, [1, 128, 512]);  getitem_1380 = None
        native_batch_norm_backward_default_85 = torch.ops.aten.native_batch_norm_backward.default(view_default_380, view_default_36, None, None, None, getitem_105, getitem_106, True, 1e-08, [True, False, False]);  view_default_380 = view_default_36 = getitem_105 = getitem_106 = None
        getitem_1382 = native_batch_norm_backward_default_85[0];  native_batch_norm_backward_default_85 = None
        view_default_381 = torch.ops.aten.view.default(getitem_1382, [128, 512, 1, 1]);  getitem_1382 = None
        to_dtype_252 = torch.ops.aten.to.dtype(getitem_1379, torch.float32);  getitem_1379 = None
        to_dtype_253 = torch.ops.aten.to.dtype(relu__default_15, torch.float32);  relu__default_15 = None
        le_scalar_84 = torch.ops.aten.le.Scalar(to_dtype_253, 0);  to_dtype_253 = None
        new_zeros_default_84 = torch.ops.aten.new_zeros.default(to_dtype_252, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_84 = torch.ops.aten.where.self(le_scalar_84, new_zeros_default_84, to_dtype_252);  le_scalar_84 = new_zeros_default_84 = to_dtype_252 = None
        to_dtype_254 = torch.ops.aten.to.dtype(where_self_84, torch.float32);  where_self_84 = None
        native_group_norm_backward_default_84 = torch.ops.aten.native_group_norm_backward.default(to_dtype_254, add_tensor_4, getitem_102, getitem_103, primals_56, 64, 512, 3136, 32, [True, True, True]);  to_dtype_254 = add_tensor_4 = getitem_102 = getitem_103 = primals_56 = None
        getitem_1385 = native_group_norm_backward_default_84[0]
        getitem_1386 = native_group_norm_backward_default_84[1]
        getitem_1387 = native_group_norm_backward_default_84[2];  native_group_norm_backward_default_84 = None
        add_tensor_60 = torch.ops.aten.add.Tensor(add_tensor_59, getitem_1385);  add_tensor_59 = getitem_1385 = None
        convolution_backward_default_87 = torch.ops.aten.convolution_backward.default(add_tensor_60, relu__default_14, view_default_35, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_35 = None
        getitem_1388 = convolution_backward_default_87[0]
        getitem_1389 = convolution_backward_default_87[1];  convolution_backward_default_87 = None
        view_default_382 = torch.ops.aten.view.default(getitem_1389, [1, 512, 128]);  getitem_1389 = None
        native_batch_norm_backward_default_86 = torch.ops.aten.native_batch_norm_backward.default(view_default_382, view_default_34, None, None, None, getitem_99, getitem_100, True, 1e-08, [True, False, False]);  view_default_382 = view_default_34 = getitem_99 = getitem_100 = None
        getitem_1391 = native_batch_norm_backward_default_86[0];  native_batch_norm_backward_default_86 = None
        view_default_383 = torch.ops.aten.view.default(getitem_1391, [512, 128, 1, 1]);  getitem_1391 = None
        to_dtype_255 = torch.ops.aten.to.dtype(getitem_1388, torch.float32);  getitem_1388 = None
        to_dtype_256 = torch.ops.aten.to.dtype(relu__default_14, torch.float32);  relu__default_14 = None
        le_scalar_85 = torch.ops.aten.le.Scalar(to_dtype_256, 0);  to_dtype_256 = None
        new_zeros_default_85 = torch.ops.aten.new_zeros.default(to_dtype_255, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_85 = torch.ops.aten.where.self(le_scalar_85, new_zeros_default_85, to_dtype_255);  le_scalar_85 = new_zeros_default_85 = to_dtype_255 = None
        to_dtype_257 = torch.ops.aten.to.dtype(where_self_85, torch.float32);  where_self_85 = None
        native_group_norm_backward_default_85 = torch.ops.aten.native_group_norm_backward.default(to_dtype_257, convolution_default_16, getitem_96, getitem_97, primals_51, 64, 128, 3136, 32, [True, True, True]);  to_dtype_257 = convolution_default_16 = getitem_96 = getitem_97 = primals_51 = None
        getitem_1394 = native_group_norm_backward_default_85[0]
        getitem_1395 = native_group_norm_backward_default_85[1]
        getitem_1396 = native_group_norm_backward_default_85[2];  native_group_norm_backward_default_85 = None
        convolution_backward_default_88 = torch.ops.aten.convolution_backward.default(getitem_1394, relu__default_13, view_default_33, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1394 = view_default_33 = None
        getitem_1397 = convolution_backward_default_88[0]
        getitem_1398 = convolution_backward_default_88[1];  convolution_backward_default_88 = None
        view_default_384 = torch.ops.aten.view.default(getitem_1398, [1, 128, 1152]);  getitem_1398 = None
        native_batch_norm_backward_default_87 = torch.ops.aten.native_batch_norm_backward.default(view_default_384, view_default_32, None, None, None, getitem_93, getitem_94, True, 1e-08, [True, False, False]);  view_default_384 = view_default_32 = getitem_93 = getitem_94 = None
        getitem_1400 = native_batch_norm_backward_default_87[0];  native_batch_norm_backward_default_87 = None
        view_default_385 = torch.ops.aten.view.default(getitem_1400, [128, 128, 3, 3]);  getitem_1400 = None
        to_dtype_258 = torch.ops.aten.to.dtype(getitem_1397, torch.float32);  getitem_1397 = None
        to_dtype_259 = torch.ops.aten.to.dtype(relu__default_13, torch.float32);  relu__default_13 = None
        le_scalar_86 = torch.ops.aten.le.Scalar(to_dtype_259, 0);  to_dtype_259 = None
        new_zeros_default_86 = torch.ops.aten.new_zeros.default(to_dtype_258, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_86 = torch.ops.aten.where.self(le_scalar_86, new_zeros_default_86, to_dtype_258);  le_scalar_86 = new_zeros_default_86 = to_dtype_258 = None
        to_dtype_260 = torch.ops.aten.to.dtype(where_self_86, torch.float32);  where_self_86 = None
        native_group_norm_backward_default_86 = torch.ops.aten.native_group_norm_backward.default(to_dtype_260, convolution_default_15, getitem_90, getitem_91, primals_49, 64, 128, 3136, 32, [True, True, True]);  to_dtype_260 = convolution_default_15 = getitem_90 = getitem_91 = primals_49 = None
        getitem_1403 = native_group_norm_backward_default_86[0]
        getitem_1404 = native_group_norm_backward_default_86[1]
        getitem_1405 = native_group_norm_backward_default_86[2];  native_group_norm_backward_default_86 = None
        convolution_backward_default_89 = torch.ops.aten.convolution_backward.default(getitem_1403, relu__default_12, view_default_31, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1403 = view_default_31 = None
        getitem_1406 = convolution_backward_default_89[0]
        getitem_1407 = convolution_backward_default_89[1];  convolution_backward_default_89 = None
        view_default_386 = torch.ops.aten.view.default(getitem_1407, [1, 128, 512]);  getitem_1407 = None
        native_batch_norm_backward_default_88 = torch.ops.aten.native_batch_norm_backward.default(view_default_386, view_default_30, None, None, None, getitem_87, getitem_88, True, 1e-08, [True, False, False]);  view_default_386 = view_default_30 = getitem_87 = getitem_88 = None
        getitem_1409 = native_batch_norm_backward_default_88[0];  native_batch_norm_backward_default_88 = None
        view_default_387 = torch.ops.aten.view.default(getitem_1409, [128, 512, 1, 1]);  getitem_1409 = None
        to_dtype_261 = torch.ops.aten.to.dtype(getitem_1406, torch.float32);  getitem_1406 = None
        to_dtype_262 = torch.ops.aten.to.dtype(relu__default_12, torch.float32);  relu__default_12 = None
        le_scalar_87 = torch.ops.aten.le.Scalar(to_dtype_262, 0);  to_dtype_262 = None
        new_zeros_default_87 = torch.ops.aten.new_zeros.default(to_dtype_261, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_87 = torch.ops.aten.where.self(le_scalar_87, new_zeros_default_87, to_dtype_261);  le_scalar_87 = new_zeros_default_87 = to_dtype_261 = None
        to_dtype_263 = torch.ops.aten.to.dtype(where_self_87, torch.float32);  where_self_87 = None
        native_group_norm_backward_default_87 = torch.ops.aten.native_group_norm_backward.default(to_dtype_263, add_tensor_3, getitem_84, getitem_85, primals_47, 64, 512, 3136, 32, [True, True, True]);  to_dtype_263 = add_tensor_3 = getitem_84 = getitem_85 = primals_47 = None
        getitem_1412 = native_group_norm_backward_default_87[0]
        getitem_1413 = native_group_norm_backward_default_87[1]
        getitem_1414 = native_group_norm_backward_default_87[2];  native_group_norm_backward_default_87 = None
        add_tensor_61 = torch.ops.aten.add.Tensor(add_tensor_60, getitem_1412);  add_tensor_60 = getitem_1412 = None
        convolution_backward_default_90 = torch.ops.aten.convolution_backward.default(add_tensor_61, relu__default_11, view_default_29, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_29 = None
        getitem_1415 = convolution_backward_default_90[0]
        getitem_1416 = convolution_backward_default_90[1];  convolution_backward_default_90 = None
        view_default_388 = torch.ops.aten.view.default(getitem_1416, [1, 512, 128]);  getitem_1416 = None
        native_batch_norm_backward_default_89 = torch.ops.aten.native_batch_norm_backward.default(view_default_388, view_default_28, None, None, None, getitem_81, getitem_82, True, 1e-08, [True, False, False]);  view_default_388 = view_default_28 = getitem_81 = getitem_82 = None
        getitem_1418 = native_batch_norm_backward_default_89[0];  native_batch_norm_backward_default_89 = None
        view_default_389 = torch.ops.aten.view.default(getitem_1418, [512, 128, 1, 1]);  getitem_1418 = None
        to_dtype_264 = torch.ops.aten.to.dtype(getitem_1415, torch.float32);  getitem_1415 = None
        to_dtype_265 = torch.ops.aten.to.dtype(relu__default_11, torch.float32);  relu__default_11 = None
        le_scalar_88 = torch.ops.aten.le.Scalar(to_dtype_265, 0);  to_dtype_265 = None
        new_zeros_default_88 = torch.ops.aten.new_zeros.default(to_dtype_264, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_88 = torch.ops.aten.where.self(le_scalar_88, new_zeros_default_88, to_dtype_264);  le_scalar_88 = new_zeros_default_88 = to_dtype_264 = None
        to_dtype_266 = torch.ops.aten.to.dtype(where_self_88, torch.float32);  where_self_88 = None
        native_group_norm_backward_default_88 = torch.ops.aten.native_group_norm_backward.default(to_dtype_266, convolution_default_13, getitem_78, getitem_79, primals_42, 64, 128, 3136, 32, [True, True, True]);  to_dtype_266 = convolution_default_13 = getitem_78 = getitem_79 = primals_42 = None
        getitem_1421 = native_group_norm_backward_default_88[0]
        getitem_1422 = native_group_norm_backward_default_88[1]
        getitem_1423 = native_group_norm_backward_default_88[2];  native_group_norm_backward_default_88 = None
        convolution_backward_default_91 = torch.ops.aten.convolution_backward.default(getitem_1421, relu__default_10, view_default_27, [0], [2, 2], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1421 = view_default_27 = None
        getitem_1424 = convolution_backward_default_91[0]
        getitem_1425 = convolution_backward_default_91[1];  convolution_backward_default_91 = None
        view_default_390 = torch.ops.aten.view.default(getitem_1425, [1, 128, 1152]);  getitem_1425 = None
        native_batch_norm_backward_default_90 = torch.ops.aten.native_batch_norm_backward.default(view_default_390, view_default_26, None, None, None, getitem_75, getitem_76, True, 1e-08, [True, False, False]);  view_default_390 = view_default_26 = getitem_75 = getitem_76 = None
        getitem_1427 = native_batch_norm_backward_default_90[0];  native_batch_norm_backward_default_90 = None
        view_default_391 = torch.ops.aten.view.default(getitem_1427, [128, 128, 3, 3]);  getitem_1427 = None
        to_dtype_267 = torch.ops.aten.to.dtype(getitem_1424, torch.float32);  getitem_1424 = None
        to_dtype_268 = torch.ops.aten.to.dtype(relu__default_10, torch.float32);  relu__default_10 = None
        le_scalar_89 = torch.ops.aten.le.Scalar(to_dtype_268, 0);  to_dtype_268 = None
        new_zeros_default_89 = torch.ops.aten.new_zeros.default(to_dtype_267, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_89 = torch.ops.aten.where.self(le_scalar_89, new_zeros_default_89, to_dtype_267);  le_scalar_89 = new_zeros_default_89 = to_dtype_267 = None
        to_dtype_269 = torch.ops.aten.to.dtype(where_self_89, torch.float32);  where_self_89 = None
        native_group_norm_backward_default_89 = torch.ops.aten.native_group_norm_backward.default(to_dtype_269, convolution_default_12, getitem_72, getitem_73, primals_40, 64, 128, 12544, 32, [True, True, True]);  to_dtype_269 = convolution_default_12 = getitem_72 = getitem_73 = primals_40 = None
        getitem_1430 = native_group_norm_backward_default_89[0]
        getitem_1431 = native_group_norm_backward_default_89[1]
        getitem_1432 = native_group_norm_backward_default_89[2];  native_group_norm_backward_default_89 = None
        convolution_backward_default_92 = torch.ops.aten.convolution_backward.default(getitem_1430, relu__default_9, view_default_25, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1430 = view_default_25 = None
        getitem_1433 = convolution_backward_default_92[0]
        getitem_1434 = convolution_backward_default_92[1];  convolution_backward_default_92 = None
        view_default_392 = torch.ops.aten.view.default(getitem_1434, [1, 128, 256]);  getitem_1434 = None
        native_batch_norm_backward_default_91 = torch.ops.aten.native_batch_norm_backward.default(view_default_392, view_default_24, None, None, None, getitem_69, getitem_70, True, 1e-08, [True, False, False]);  view_default_392 = view_default_24 = getitem_69 = getitem_70 = None
        getitem_1436 = native_batch_norm_backward_default_91[0];  native_batch_norm_backward_default_91 = None
        view_default_393 = torch.ops.aten.view.default(getitem_1436, [128, 256, 1, 1]);  getitem_1436 = None
        convolution_backward_default_93 = torch.ops.aten.convolution_backward.default(add_tensor_61, relu__default_9, view_default_23, [0], [2, 2], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_61 = view_default_23 = None
        getitem_1439 = convolution_backward_default_93[0]
        getitem_1440 = convolution_backward_default_93[1];  convolution_backward_default_93 = None
        add_tensor_62 = torch.ops.aten.add.Tensor(getitem_1433, getitem_1439);  getitem_1433 = getitem_1439 = None
        view_default_394 = torch.ops.aten.view.default(getitem_1440, [1, 512, 256]);  getitem_1440 = None
        native_batch_norm_backward_default_92 = torch.ops.aten.native_batch_norm_backward.default(view_default_394, view_default_22, None, None, None, getitem_66, getitem_67, True, 1e-08, [True, False, False]);  view_default_394 = view_default_22 = getitem_66 = getitem_67 = None
        getitem_1442 = native_batch_norm_backward_default_92[0];  native_batch_norm_backward_default_92 = None
        view_default_395 = torch.ops.aten.view.default(getitem_1442, [512, 256, 1, 1]);  getitem_1442 = None
        to_dtype_270 = torch.ops.aten.to.dtype(add_tensor_62, torch.float32);  add_tensor_62 = None
        to_dtype_271 = torch.ops.aten.to.dtype(relu__default_9, torch.float32);  relu__default_9 = None
        le_scalar_90 = torch.ops.aten.le.Scalar(to_dtype_271, 0);  to_dtype_271 = None
        new_zeros_default_90 = torch.ops.aten.new_zeros.default(to_dtype_270, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_90 = torch.ops.aten.where.self(le_scalar_90, new_zeros_default_90, to_dtype_270);  le_scalar_90 = new_zeros_default_90 = to_dtype_270 = None
        to_dtype_272 = torch.ops.aten.to.dtype(where_self_90, torch.float32);  where_self_90 = None
        native_group_norm_backward_default_90 = torch.ops.aten.native_group_norm_backward.default(to_dtype_272, add_tensor_2, getitem_63, getitem_64, primals_38, 64, 256, 12544, 32, [True, True, True]);  to_dtype_272 = add_tensor_2 = getitem_63 = getitem_64 = primals_38 = None
        getitem_1445 = native_group_norm_backward_default_90[0]
        getitem_1446 = native_group_norm_backward_default_90[1]
        getitem_1447 = native_group_norm_backward_default_90[2];  native_group_norm_backward_default_90 = None
        convolution_backward_default_94 = torch.ops.aten.convolution_backward.default(getitem_1445, relu__default_8, view_default_21, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_21 = None
        getitem_1448 = convolution_backward_default_94[0]
        getitem_1449 = convolution_backward_default_94[1];  convolution_backward_default_94 = None
        view_default_396 = torch.ops.aten.view.default(getitem_1449, [1, 256, 64]);  getitem_1449 = None
        native_batch_norm_backward_default_93 = torch.ops.aten.native_batch_norm_backward.default(view_default_396, view_default_20, None, None, None, getitem_60, getitem_61, True, 1e-08, [True, False, False]);  view_default_396 = view_default_20 = getitem_60 = getitem_61 = None
        getitem_1451 = native_batch_norm_backward_default_93[0];  native_batch_norm_backward_default_93 = None
        view_default_397 = torch.ops.aten.view.default(getitem_1451, [256, 64, 1, 1]);  getitem_1451 = None
        to_dtype_273 = torch.ops.aten.to.dtype(getitem_1448, torch.float32);  getitem_1448 = None
        to_dtype_274 = torch.ops.aten.to.dtype(relu__default_8, torch.float32);  relu__default_8 = None
        le_scalar_91 = torch.ops.aten.le.Scalar(to_dtype_274, 0);  to_dtype_274 = None
        new_zeros_default_91 = torch.ops.aten.new_zeros.default(to_dtype_273, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_91 = torch.ops.aten.where.self(le_scalar_91, new_zeros_default_91, to_dtype_273);  le_scalar_91 = new_zeros_default_91 = to_dtype_273 = None
        to_dtype_275 = torch.ops.aten.to.dtype(where_self_91, torch.float32);  where_self_91 = None
        native_group_norm_backward_default_91 = torch.ops.aten.native_group_norm_backward.default(to_dtype_275, convolution_default_9, getitem_57, getitem_58, primals_32, 64, 64, 12544, 32, [True, True, True]);  to_dtype_275 = convolution_default_9 = getitem_57 = getitem_58 = primals_32 = None
        getitem_1454 = native_group_norm_backward_default_91[0]
        getitem_1455 = native_group_norm_backward_default_91[1]
        getitem_1456 = native_group_norm_backward_default_91[2];  native_group_norm_backward_default_91 = None
        convolution_backward_default_95 = torch.ops.aten.convolution_backward.default(getitem_1454, relu__default_7, view_default_19, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1454 = view_default_19 = None
        getitem_1457 = convolution_backward_default_95[0]
        getitem_1458 = convolution_backward_default_95[1];  convolution_backward_default_95 = None
        view_default_398 = torch.ops.aten.view.default(getitem_1458, [1, 64, 576]);  getitem_1458 = None
        native_batch_norm_backward_default_94 = torch.ops.aten.native_batch_norm_backward.default(view_default_398, view_default_18, None, None, None, getitem_54, getitem_55, True, 1e-08, [True, False, False]);  view_default_398 = view_default_18 = getitem_54 = getitem_55 = None
        getitem_1460 = native_batch_norm_backward_default_94[0];  native_batch_norm_backward_default_94 = None
        view_default_399 = torch.ops.aten.view.default(getitem_1460, [64, 64, 3, 3]);  getitem_1460 = None
        to_dtype_276 = torch.ops.aten.to.dtype(getitem_1457, torch.float32);  getitem_1457 = None
        to_dtype_277 = torch.ops.aten.to.dtype(relu__default_7, torch.float32);  relu__default_7 = None
        le_scalar_92 = torch.ops.aten.le.Scalar(to_dtype_277, 0);  to_dtype_277 = None
        new_zeros_default_92 = torch.ops.aten.new_zeros.default(to_dtype_276, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_92 = torch.ops.aten.where.self(le_scalar_92, new_zeros_default_92, to_dtype_276);  le_scalar_92 = new_zeros_default_92 = to_dtype_276 = None
        to_dtype_278 = torch.ops.aten.to.dtype(where_self_92, torch.float32);  where_self_92 = None
        native_group_norm_backward_default_92 = torch.ops.aten.native_group_norm_backward.default(to_dtype_278, convolution_default_8, getitem_51, getitem_52, primals_30, 64, 64, 12544, 32, [True, True, True]);  to_dtype_278 = convolution_default_8 = getitem_51 = getitem_52 = primals_30 = None
        getitem_1463 = native_group_norm_backward_default_92[0]
        getitem_1464 = native_group_norm_backward_default_92[1]
        getitem_1465 = native_group_norm_backward_default_92[2];  native_group_norm_backward_default_92 = None
        convolution_backward_default_96 = torch.ops.aten.convolution_backward.default(getitem_1463, relu__default_6, view_default_17, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1463 = view_default_17 = None
        getitem_1466 = convolution_backward_default_96[0]
        getitem_1467 = convolution_backward_default_96[1];  convolution_backward_default_96 = None
        view_default_400 = torch.ops.aten.view.default(getitem_1467, [1, 64, 256]);  getitem_1467 = None
        native_batch_norm_backward_default_95 = torch.ops.aten.native_batch_norm_backward.default(view_default_400, view_default_16, None, None, None, getitem_48, getitem_49, True, 1e-08, [True, False, False]);  view_default_400 = view_default_16 = getitem_48 = getitem_49 = None
        getitem_1469 = native_batch_norm_backward_default_95[0];  native_batch_norm_backward_default_95 = None
        view_default_401 = torch.ops.aten.view.default(getitem_1469, [64, 256, 1, 1]);  getitem_1469 = None
        to_dtype_279 = torch.ops.aten.to.dtype(getitem_1466, torch.float32);  getitem_1466 = None
        to_dtype_280 = torch.ops.aten.to.dtype(relu__default_6, torch.float32);  relu__default_6 = None
        le_scalar_93 = torch.ops.aten.le.Scalar(to_dtype_280, 0);  to_dtype_280 = None
        new_zeros_default_93 = torch.ops.aten.new_zeros.default(to_dtype_279, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_93 = torch.ops.aten.where.self(le_scalar_93, new_zeros_default_93, to_dtype_279);  le_scalar_93 = new_zeros_default_93 = to_dtype_279 = None
        to_dtype_281 = torch.ops.aten.to.dtype(where_self_93, torch.float32);  where_self_93 = None
        native_group_norm_backward_default_93 = torch.ops.aten.native_group_norm_backward.default(to_dtype_281, add_tensor_1, getitem_45, getitem_46, primals_28, 64, 256, 12544, 32, [True, True, True]);  to_dtype_281 = add_tensor_1 = getitem_45 = getitem_46 = primals_28 = None
        getitem_1472 = native_group_norm_backward_default_93[0]
        getitem_1473 = native_group_norm_backward_default_93[1]
        getitem_1474 = native_group_norm_backward_default_93[2];  native_group_norm_backward_default_93 = None
        add_tensor_63 = torch.ops.aten.add.Tensor(getitem_1445, getitem_1472);  getitem_1445 = getitem_1472 = None
        convolution_backward_default_97 = torch.ops.aten.convolution_backward.default(add_tensor_63, relu__default_5, view_default_15, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_15 = None
        getitem_1475 = convolution_backward_default_97[0]
        getitem_1476 = convolution_backward_default_97[1];  convolution_backward_default_97 = None
        view_default_402 = torch.ops.aten.view.default(getitem_1476, [1, 256, 64]);  getitem_1476 = None
        native_batch_norm_backward_default_96 = torch.ops.aten.native_batch_norm_backward.default(view_default_402, view_default_14, None, None, None, getitem_42, getitem_43, True, 1e-08, [True, False, False]);  view_default_402 = view_default_14 = getitem_42 = getitem_43 = None
        getitem_1478 = native_batch_norm_backward_default_96[0];  native_batch_norm_backward_default_96 = None
        view_default_403 = torch.ops.aten.view.default(getitem_1478, [256, 64, 1, 1]);  getitem_1478 = None
        to_dtype_282 = torch.ops.aten.to.dtype(getitem_1475, torch.float32);  getitem_1475 = None
        to_dtype_283 = torch.ops.aten.to.dtype(relu__default_5, torch.float32);  relu__default_5 = None
        le_scalar_94 = torch.ops.aten.le.Scalar(to_dtype_283, 0);  to_dtype_283 = None
        new_zeros_default_94 = torch.ops.aten.new_zeros.default(to_dtype_282, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_94 = torch.ops.aten.where.self(le_scalar_94, new_zeros_default_94, to_dtype_282);  le_scalar_94 = new_zeros_default_94 = to_dtype_282 = None
        to_dtype_284 = torch.ops.aten.to.dtype(where_self_94, torch.float32);  where_self_94 = None
        native_group_norm_backward_default_94 = torch.ops.aten.native_group_norm_backward.default(to_dtype_284, convolution_default_6, getitem_39, getitem_40, primals_23, 64, 64, 12544, 32, [True, True, True]);  to_dtype_284 = convolution_default_6 = getitem_39 = getitem_40 = primals_23 = None
        getitem_1481 = native_group_norm_backward_default_94[0]
        getitem_1482 = native_group_norm_backward_default_94[1]
        getitem_1483 = native_group_norm_backward_default_94[2];  native_group_norm_backward_default_94 = None
        convolution_backward_default_98 = torch.ops.aten.convolution_backward.default(getitem_1481, relu__default_4, view_default_13, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1481 = view_default_13 = None
        getitem_1484 = convolution_backward_default_98[0]
        getitem_1485 = convolution_backward_default_98[1];  convolution_backward_default_98 = None
        view_default_404 = torch.ops.aten.view.default(getitem_1485, [1, 64, 576]);  getitem_1485 = None
        native_batch_norm_backward_default_97 = torch.ops.aten.native_batch_norm_backward.default(view_default_404, view_default_12, None, None, None, getitem_36, getitem_37, True, 1e-08, [True, False, False]);  view_default_404 = view_default_12 = getitem_36 = getitem_37 = None
        getitem_1487 = native_batch_norm_backward_default_97[0];  native_batch_norm_backward_default_97 = None
        view_default_405 = torch.ops.aten.view.default(getitem_1487, [64, 64, 3, 3]);  getitem_1487 = None
        to_dtype_285 = torch.ops.aten.to.dtype(getitem_1484, torch.float32);  getitem_1484 = None
        to_dtype_286 = torch.ops.aten.to.dtype(relu__default_4, torch.float32);  relu__default_4 = None
        le_scalar_95 = torch.ops.aten.le.Scalar(to_dtype_286, 0);  to_dtype_286 = None
        new_zeros_default_95 = torch.ops.aten.new_zeros.default(to_dtype_285, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_95 = torch.ops.aten.where.self(le_scalar_95, new_zeros_default_95, to_dtype_285);  le_scalar_95 = new_zeros_default_95 = to_dtype_285 = None
        to_dtype_287 = torch.ops.aten.to.dtype(where_self_95, torch.float32);  where_self_95 = None
        native_group_norm_backward_default_95 = torch.ops.aten.native_group_norm_backward.default(to_dtype_287, convolution_default_5, getitem_33, getitem_34, primals_21, 64, 64, 12544, 32, [True, True, True]);  to_dtype_287 = convolution_default_5 = getitem_33 = getitem_34 = primals_21 = None
        getitem_1490 = native_group_norm_backward_default_95[0]
        getitem_1491 = native_group_norm_backward_default_95[1]
        getitem_1492 = native_group_norm_backward_default_95[2];  native_group_norm_backward_default_95 = None
        convolution_backward_default_99 = torch.ops.aten.convolution_backward.default(getitem_1490, relu__default_3, view_default_11, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1490 = view_default_11 = None
        getitem_1493 = convolution_backward_default_99[0]
        getitem_1494 = convolution_backward_default_99[1];  convolution_backward_default_99 = None
        view_default_406 = torch.ops.aten.view.default(getitem_1494, [1, 64, 256]);  getitem_1494 = None
        native_batch_norm_backward_default_98 = torch.ops.aten.native_batch_norm_backward.default(view_default_406, view_default_10, None, None, None, getitem_30, getitem_31, True, 1e-08, [True, False, False]);  view_default_406 = view_default_10 = getitem_30 = getitem_31 = None
        getitem_1496 = native_batch_norm_backward_default_98[0];  native_batch_norm_backward_default_98 = None
        view_default_407 = torch.ops.aten.view.default(getitem_1496, [64, 256, 1, 1]);  getitem_1496 = None
        to_dtype_288 = torch.ops.aten.to.dtype(getitem_1493, torch.float32);  getitem_1493 = None
        to_dtype_289 = torch.ops.aten.to.dtype(relu__default_3, torch.float32);  relu__default_3 = None
        le_scalar_96 = torch.ops.aten.le.Scalar(to_dtype_289, 0);  to_dtype_289 = None
        new_zeros_default_96 = torch.ops.aten.new_zeros.default(to_dtype_288, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_96 = torch.ops.aten.where.self(le_scalar_96, new_zeros_default_96, to_dtype_288);  le_scalar_96 = new_zeros_default_96 = to_dtype_288 = None
        to_dtype_290 = torch.ops.aten.to.dtype(where_self_96, torch.float32);  where_self_96 = None
        native_group_norm_backward_default_96 = torch.ops.aten.native_group_norm_backward.default(to_dtype_290, add_tensor, getitem_27, getitem_28, primals_19, 64, 256, 12544, 32, [True, True, True]);  to_dtype_290 = add_tensor = getitem_27 = getitem_28 = primals_19 = None
        getitem_1499 = native_group_norm_backward_default_96[0]
        getitem_1500 = native_group_norm_backward_default_96[1]
        getitem_1501 = native_group_norm_backward_default_96[2];  native_group_norm_backward_default_96 = None
        add_tensor_64 = torch.ops.aten.add.Tensor(add_tensor_63, getitem_1499);  add_tensor_63 = getitem_1499 = None
        convolution_backward_default_100 = torch.ops.aten.convolution_backward.default(add_tensor_64, relu__default_2, view_default_9, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  view_default_9 = None
        getitem_1502 = convolution_backward_default_100[0]
        getitem_1503 = convolution_backward_default_100[1];  convolution_backward_default_100 = None
        view_default_408 = torch.ops.aten.view.default(getitem_1503, [1, 256, 64]);  getitem_1503 = None
        native_batch_norm_backward_default_99 = torch.ops.aten.native_batch_norm_backward.default(view_default_408, view_default_8, None, None, None, getitem_24, getitem_25, True, 1e-08, [True, False, False]);  view_default_408 = view_default_8 = getitem_24 = getitem_25 = None
        getitem_1505 = native_batch_norm_backward_default_99[0];  native_batch_norm_backward_default_99 = None
        view_default_409 = torch.ops.aten.view.default(getitem_1505, [256, 64, 1, 1]);  getitem_1505 = None
        to_dtype_291 = torch.ops.aten.to.dtype(getitem_1502, torch.float32);  getitem_1502 = None
        to_dtype_292 = torch.ops.aten.to.dtype(relu__default_2, torch.float32);  relu__default_2 = None
        le_scalar_97 = torch.ops.aten.le.Scalar(to_dtype_292, 0);  to_dtype_292 = None
        new_zeros_default_97 = torch.ops.aten.new_zeros.default(to_dtype_291, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_97 = torch.ops.aten.where.self(le_scalar_97, new_zeros_default_97, to_dtype_291);  le_scalar_97 = new_zeros_default_97 = to_dtype_291 = None
        to_dtype_293 = torch.ops.aten.to.dtype(where_self_97, torch.float32);  where_self_97 = None
        native_group_norm_backward_default_97 = torch.ops.aten.native_group_norm_backward.default(to_dtype_293, convolution_default_3, getitem_21, getitem_22, primals_14, 64, 64, 12544, 32, [True, True, True]);  to_dtype_293 = convolution_default_3 = getitem_21 = getitem_22 = primals_14 = None
        getitem_1508 = native_group_norm_backward_default_97[0]
        getitem_1509 = native_group_norm_backward_default_97[1]
        getitem_1510 = native_group_norm_backward_default_97[2];  native_group_norm_backward_default_97 = None
        convolution_backward_default_101 = torch.ops.aten.convolution_backward.default(getitem_1508, relu__default_1, view_default_7, [0], [1, 1], [1, 1], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1508 = view_default_7 = None
        getitem_1511 = convolution_backward_default_101[0]
        getitem_1512 = convolution_backward_default_101[1];  convolution_backward_default_101 = None
        view_default_410 = torch.ops.aten.view.default(getitem_1512, [1, 64, 576]);  getitem_1512 = None
        native_batch_norm_backward_default_100 = torch.ops.aten.native_batch_norm_backward.default(view_default_410, view_default_6, None, None, None, getitem_18, getitem_19, True, 1e-08, [True, False, False]);  view_default_410 = view_default_6 = getitem_18 = getitem_19 = None
        getitem_1514 = native_batch_norm_backward_default_100[0];  native_batch_norm_backward_default_100 = None
        view_default_411 = torch.ops.aten.view.default(getitem_1514, [64, 64, 3, 3]);  getitem_1514 = None
        to_dtype_294 = torch.ops.aten.to.dtype(getitem_1511, torch.float32);  getitem_1511 = None
        to_dtype_295 = torch.ops.aten.to.dtype(relu__default_1, torch.float32);  relu__default_1 = None
        le_scalar_98 = torch.ops.aten.le.Scalar(to_dtype_295, 0);  to_dtype_295 = None
        new_zeros_default_98 = torch.ops.aten.new_zeros.default(to_dtype_294, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_98 = torch.ops.aten.where.self(le_scalar_98, new_zeros_default_98, to_dtype_294);  le_scalar_98 = new_zeros_default_98 = to_dtype_294 = None
        to_dtype_296 = torch.ops.aten.to.dtype(where_self_98, torch.float32);  where_self_98 = None
        native_group_norm_backward_default_98 = torch.ops.aten.native_group_norm_backward.default(to_dtype_296, convolution_default_2, getitem_15, getitem_16, primals_12, 64, 64, 12544, 32, [True, True, True]);  to_dtype_296 = convolution_default_2 = getitem_15 = getitem_16 = primals_12 = None
        getitem_1517 = native_group_norm_backward_default_98[0]
        getitem_1518 = native_group_norm_backward_default_98[1]
        getitem_1519 = native_group_norm_backward_default_98[2];  native_group_norm_backward_default_98 = None
        convolution_backward_default_102 = torch.ops.aten.convolution_backward.default(getitem_1517, relu__default, view_default_5, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  getitem_1517 = view_default_5 = None
        getitem_1520 = convolution_backward_default_102[0]
        getitem_1521 = convolution_backward_default_102[1];  convolution_backward_default_102 = None
        view_default_412 = torch.ops.aten.view.default(getitem_1521, [1, 64, 64]);  getitem_1521 = None
        native_batch_norm_backward_default_101 = torch.ops.aten.native_batch_norm_backward.default(view_default_412, view_default_4, None, None, None, getitem_12, getitem_13, True, 1e-08, [True, False, False]);  view_default_412 = view_default_4 = getitem_12 = getitem_13 = None
        getitem_1523 = native_batch_norm_backward_default_101[0];  native_batch_norm_backward_default_101 = None
        view_default_413 = torch.ops.aten.view.default(getitem_1523, [64, 64, 1, 1]);  getitem_1523 = None
        convolution_backward_default_103 = torch.ops.aten.convolution_backward.default(add_tensor_64, relu__default, view_default_3, [0], [1, 1], [0, 0], [1, 1], False, [0, 0], 1, [True, True, False]);  add_tensor_64 = view_default_3 = None
        getitem_1526 = convolution_backward_default_103[0]
        getitem_1527 = convolution_backward_default_103[1];  convolution_backward_default_103 = None
        add_tensor_65 = torch.ops.aten.add.Tensor(getitem_1520, getitem_1526);  getitem_1520 = getitem_1526 = None
        view_default_414 = torch.ops.aten.view.default(getitem_1527, [1, 256, 64]);  getitem_1527 = None
        native_batch_norm_backward_default_102 = torch.ops.aten.native_batch_norm_backward.default(view_default_414, view_default_2, None, None, None, getitem_9, getitem_10, True, 1e-08, [True, False, False]);  view_default_414 = view_default_2 = getitem_9 = getitem_10 = None
        getitem_1529 = native_batch_norm_backward_default_102[0];  native_batch_norm_backward_default_102 = None
        view_default_415 = torch.ops.aten.view.default(getitem_1529, [256, 64, 1, 1]);  getitem_1529 = None
        to_dtype_297 = torch.ops.aten.to.dtype(add_tensor_65, torch.float32);  add_tensor_65 = None
        to_dtype_298 = torch.ops.aten.to.dtype(relu__default, torch.float32);  relu__default = None
        le_scalar_99 = torch.ops.aten.le.Scalar(to_dtype_298, 0);  to_dtype_298 = None
        new_zeros_default_99 = torch.ops.aten.new_zeros.default(to_dtype_297, [], device = device(type='cuda', index=0), dtype = torch.float32, layout = torch.strided, pin_memory = False)
        where_self_99 = torch.ops.aten.where.self(le_scalar_99, new_zeros_default_99, to_dtype_297);  le_scalar_99 = new_zeros_default_99 = to_dtype_297 = None
        to_dtype_299 = torch.ops.aten.to.dtype(where_self_99, torch.float32);  where_self_99 = None
        native_group_norm_backward_default_99 = torch.ops.aten.native_group_norm_backward.default(to_dtype_299, getitem_3, getitem_6, getitem_7, primals_10, 64, 64, 12544, 32, [True, True, True]);  to_dtype_299 = getitem_3 = getitem_6 = getitem_7 = primals_10 = None
        getitem_1532 = native_group_norm_backward_default_99[0]
        getitem_1533 = native_group_norm_backward_default_99[1]
        getitem_1534 = native_group_norm_backward_default_99[2];  native_group_norm_backward_default_99 = None
        max_pool2d_with_indices_backward_default = torch.ops.aten.max_pool2d_with_indices_backward.default(getitem_1532, constant_pad_nd_default, [3, 3], [2, 2], [0, 0], [1, 1], False, getitem_4);  getitem_1532 = constant_pad_nd_default = getitem_4 = None
        constant_pad_nd_default_1 = torch.ops.aten.constant_pad_nd.default(max_pool2d_with_indices_backward_default, [-1, -1, -1, -1]);  max_pool2d_with_indices_backward_default = None
        convolution_backward_default_104 = torch.ops.aten.convolution_backward.default(constant_pad_nd_default_1, primals_307, view_default_1, [0], [2, 2], [3, 3], [1, 1], False, [0, 0], 1, [False, True, False]);  constant_pad_nd_default_1 = primals_307 = view_default_1 = None
        getitem_1536 = convolution_backward_default_104[1];  convolution_backward_default_104 = None
        view_default_416 = torch.ops.aten.view.default(getitem_1536, [1, 64, 147]);  getitem_1536 = None
        native_batch_norm_backward_default_103 = torch.ops.aten.native_batch_norm_backward.default(view_default_416, view_default, None, None, None, getitem_1, getitem_2, True, 1e-08, [True, False, False]);  view_default_416 = view_default = getitem_1 = getitem_2 = None
        getitem_1538 = native_batch_norm_backward_default_103[0];  native_batch_norm_backward_default_103 = None
        view_default_417 = torch.ops.aten.view.default(getitem_1538, [64, 3, 7, 7]);  getitem_1538 = None
        return [getitem_616, getitem_615, getitem_619, getitem_618, view_default_413, view_default_411, view_default_409, view_default_415, getitem_1534, getitem_1533, getitem_1519, getitem_1518, getitem_1510, getitem_1509, view_default_407, view_default_405, view_default_403, getitem_1501, getitem_1500, getitem_1492, getitem_1491, getitem_1483, getitem_1482, view_default_401, view_default_399, view_default_397, getitem_1474, getitem_1473, getitem_1465, getitem_1464, getitem_1456, getitem_1455, view_default_393, view_default_391, view_default_389, view_default_395, getitem_1447, getitem_1446, getitem_1432, getitem_1431, getitem_1423, getitem_1422, view_default_387, view_default_385, view_default_383, getitem_1414, getitem_1413, getitem_1405, getitem_1404, getitem_1396, getitem_1395, view_default_381, view_default_379, view_default_377, getitem_1387, getitem_1386, getitem_1378, getitem_1377, getitem_1369, getitem_1368, view_default_375, view_default_373, view_default_371, getitem_1360, getitem_1359, getitem_1351, getitem_1350, getitem_1342, getitem_1341, view_default_367, view_default_365, view_default_363, view_default_369, getitem_1333, getitem_1332, getitem_1318, getitem_1317, getitem_1309, getitem_1308, view_default_307, view_default_305, view_default_303, getitem_1057, getitem_1056, getitem_1048, getitem_1047, getitem_1039, getitem_1038, view_default_301, view_default_299, view_default_297, getitem_1030, getitem_1029, getitem_1021, getitem_1020, getitem_1012, getitem_1011, view_default_295, view_default_293, view_default_291, getitem_1003, getitem_1002, getitem_994, getitem_993, getitem_985, getitem_984, view_default_289, view_default_287, view_default_285, getitem_976, getitem_975, getitem_967, getitem_966, getitem_958, getitem_957, view_default_283, view_default_281, view_default_279, getitem_949, getitem_948, getitem_940, getitem_939, getitem_931, getitem_930, view_default_277, view_default_275, view_default_273, getitem_922, getitem_921, getitem_913, getitem_912, getitem_904, getitem_903, view_default_271, view_default_269, view_default_267, getitem_895, getitem_894, getitem_886, getitem_885, getitem_877, getitem_876, view_default_265, view_default_263, view_default_261, getitem_868, getitem_867, getitem_859, getitem_858, getitem_850, getitem_849, view_default_259, view_default_257, view_default_255, getitem_841, getitem_840, getitem_832, getitem_831, getitem_823, getitem_822, view_default_253, view_default_251, view_default_249, getitem_814, getitem_813, getitem_805, getitem_804, getitem_796, getitem_795, view_default_361, view_default_359, view_default_357, getitem_1300, getitem_1299, getitem_1291, getitem_1290, getitem_1282, getitem_1281, view_default_247, view_default_245, view_default_243, getitem_787, getitem_786, getitem_778, getitem_777, getitem_769, getitem_768, view_default_241, view_default_239, view_default_237, getitem_760, getitem_759, getitem_751, getitem_750, getitem_742, getitem_741, view_default_235, view_default_233, view_default_231, getitem_733, getitem_732, getitem_724, getitem_723, getitem_715, getitem_714, view_default_355, view_default_353, view_default_351, getitem_1273, getitem_1272, getitem_1264, getitem_1263, getitem_1255, getitem_1254, view_default_349, view_default_347, view_default_345, getitem_1246, getitem_1245, getitem_1237, getitem_1236, getitem_1228, getitem_1227, view_default_343, view_default_341, view_default_339, getitem_1219, getitem_1218, getitem_1210, getitem_1209, getitem_1201, getitem_1200, view_default_337, view_default_335, view_default_333, getitem_1192, getitem_1191, getitem_1183, getitem_1182, getitem_1174, getitem_1173, view_default_331, view_default_329, view_default_327, getitem_1165, getitem_1164, getitem_1156, getitem_1155, getitem_1147, getitem_1146, view_default_325, view_default_323, view_default_321, getitem_1138, getitem_1137, getitem_1129, getitem_1128, getitem_1120, getitem_1119, view_default_319, view_default_317, view_default_315, getitem_1111, getitem_1110, getitem_1102, getitem_1101, getitem_1093, getitem_1092, view_default_313, view_default_311, view_default_309, getitem_1084, getitem_1083, getitem_1075, getitem_1074, getitem_1066, getitem_1065, view_default_227, view_default_225, view_default_223, view_default_229, getitem_706, getitem_705, getitem_691, getitem_690, getitem_682, getitem_681, view_default_221, view_default_219, view_default_217, getitem_673, getitem_672, getitem_664, getitem_663, getitem_655, getitem_654, view_default_215, view_default_213, view_default_211, getitem_646, getitem_645, getitem_637, getitem_636, getitem_628, getitem_627, view_default_417, None]
        
